const application = require('./dist');
module.exports = application;

const dotenv = require('dotenv');

dotenv.config();

if (require.main === module) {
  // Run the application
  const config = {
    rest: {
      host: process.env.HOST,
      port: process.env.PORT || 5055,
      openApiSpec: {
        // useful when used with OpenAPI-to-GraphQL to locate your application
        setServersFromRequest: true,
        endpointMapping: {
          '/openapi.json': {version: '3.0.0', format: 'json'},
          '/openapi.yaml': {version: '3.0.0', format: 'yaml'},
        },
      },
    },
    websocket: {
      port: process.env.PORT || 5055,
    },
  };
  application.main(config).catch(err => {
    console.error('Cannot start the application.', err);
    process.exit(1);
  });
}
