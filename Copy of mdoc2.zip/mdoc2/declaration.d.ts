declare module 'pdf-creator-node';
