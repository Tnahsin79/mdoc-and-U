import { DefaultCrudRepository, BelongsToAccessor, repository } from '@loopback/repository';
import { BasicHealthInformation, BasicHealthInformationRelations, HealthQuestion } from '../models';
import { DbDataSource } from '../datasources';
import { inject, Getter } from '@loopback/core';
import { HealthQuestionRepository } from './health-question.repository';

export class BasicHealthInformationRepository extends DefaultCrudRepository<BasicHealthInformation, typeof BasicHealthInformation.prototype.id, BasicHealthInformationRelations> {
  // public readonly question: BelongsToAccessor<HealthQuestion, typeof HealthQuestion.prototype.id>;
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    // @repository.getter('HealthQuestionRepository') public healthQuestionRepositoryGitter: Getter<HealthQuestionRepository>,
  ) {
    super(BasicHealthInformation, dataSource);

    // this.question = this.createBelongsToAccessorFor('question', healthQuestionRepositoryGitter);

    // this.registerInclusionResolver('question', this.question.inclusionResolver);

    (this.modelClass as any).observe('persist', async (ctx: any) => {
      ctx.data.modified = new Date();
    });
  }
}
