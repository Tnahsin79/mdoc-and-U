import {
  repository,
  BelongsToAccessor,
  DefaultCrudRepository,
  HasOneRepositoryFactory,
  HasManyRepositoryFactory,
} from '@loopback/repository';
import {
  Admin,
  Programs,
  Benefits,
  ChangeStages,
  ProgramPlans,
  CoachPrograms,
  ProgramsRelations,
  UserSubscriptions,
} from '../models';
import {DbDataSource} from '../datasources';
import {inject, Getter} from '@loopback/core';
import {AdminRepository} from './admin.repository';
import {BenefitsRepository} from './benefits.repository';
import {ChangeStagesRepository} from './change-stages.repository';
import {ProgramPlansRepository} from './program-plans.repository';
import {CoachProgramsRepository} from './coach-programs.repository';
import {UserSubscriptionsRepository} from './user-subscriptions.repository';

export class ProgramsRepository extends DefaultCrudRepository<
  Programs,
  typeof Programs.prototype.id,
  ProgramsRelations
> {
  public readonly plans: HasManyRepositoryFactory<
    ProgramPlans,
    typeof ProgramPlans.prototype.id
  >;
  public readonly benefits: HasManyRepositoryFactory<
    Benefits,
    typeof Benefits.prototype.id
  >;
  public readonly admin: BelongsToAccessor<Admin, typeof Admin.prototype.id>;
  public readonly approver: BelongsToAccessor<Admin, typeof Admin.prototype.id>;
  public readonly coachPrograms: HasManyRepositoryFactory<
    CoachPrograms,
    typeof CoachPrograms.prototype.id
  >;
  public readonly subscriptions: HasManyRepositoryFactory<
    UserSubscriptions,
    typeof UserSubscriptions.prototype.id
  >;
  public readonly changeStages: HasOneRepositoryFactory<
    ChangeStages,
    typeof ChangeStages.prototype.id
  >;
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('ProgramPlansRepository')
    plansRepositoryGetter: Getter<ProgramPlansRepository>,
    @repository.getter('BenefitsRepository')
    benefitsRepositoryGetter: Getter<BenefitsRepository>,
    @repository.getter('AdminRepository')
    adminRepositoryGetter: Getter<AdminRepository>,
    @repository.getter('CoachProgramsRepository')
    coachProgramsRepositoryGetter: Getter<CoachProgramsRepository>,
    @repository.getter('UserSubscriptionsRepository')
    subscriptionsRepositoryGetter: Getter<UserSubscriptionsRepository>,
    @repository.getter('ChangeStagesRepository')
    changeStagesRepositoryGetter: Getter<ChangeStagesRepository>,
  ) {
    super(Programs, dataSource);
    this.plans = this.createHasManyRepositoryFactoryFor(
      'plans',
      plansRepositoryGetter,
    );
    this.benefits = this.createHasManyRepositoryFactoryFor(
      'benefits',
      benefitsRepositoryGetter,
    );
    this.admin = this.createBelongsToAccessorFor(
      'admin',
      adminRepositoryGetter,
    );
    this.approver = this.createBelongsToAccessorFor(
      'approver',
      adminRepositoryGetter,
    );
    this.coachPrograms = this.createHasManyRepositoryFactoryFor(
      'coachPrograms',
      coachProgramsRepositoryGetter,
    );
    this.changeStages = this.createHasOneRepositoryFactoryFor(
      'changeStages',
      changeStagesRepositoryGetter,
    );
    this.subscriptions = this.createHasManyRepositoryFactoryFor(
      'subscriptions',
      subscriptionsRepositoryGetter,
    );
    this.registerInclusionResolver('plans', this.plans.inclusionResolver);
    this.registerInclusionResolver('benefits', this.benefits.inclusionResolver);
    this.registerInclusionResolver('admin', this.admin.inclusionResolver);
    this.registerInclusionResolver('approver', this.approver.inclusionResolver);
    this.registerInclusionResolver(
      'coachPrograms',
      this.coachPrograms.inclusionResolver,
    );
    this.registerInclusionResolver(
      'subscriptions',
      this.subscriptions.inclusionResolver,
    );
    this.registerInclusionResolver(
      'changeStages',
      this.changeStages.inclusionResolver,
    );
  }
}
