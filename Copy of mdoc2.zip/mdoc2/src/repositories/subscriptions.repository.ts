import { DefaultCrudRepository } from '@loopback/repository';
import { Subscriptions, SubscriptionsRelations } from '../models';
import { DbDataSource } from '../datasources';
import { inject } from '@loopback/core';

export class SubscriptionsRepository extends DefaultCrudRepository<
  Subscriptions,
  typeof Subscriptions.prototype.id,
  SubscriptionsRelations
> {
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
  ) {
    super(Subscriptions, dataSource);
  }
}
