import {DefaultCrudRepository} from '@loopback/repository';
import {Children, ChildrenRelations} from '../models';
import {DbDataSource} from '../datasources';
import {inject} from '@loopback/core';

export class ChildrenRepository extends DefaultCrudRepository<
  Children,
  typeof Children.prototype.id,
  ChildrenRelations
> {
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
  ) {
    super(Children, dataSource);
  }
}
