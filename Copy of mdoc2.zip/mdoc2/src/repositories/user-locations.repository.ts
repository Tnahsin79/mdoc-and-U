import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {UserLocations, UserLocationsRelations} from '../models';

export class UserLocationsRepository extends DefaultCrudRepository<
  UserLocations,
  typeof UserLocations.prototype.id,
  UserLocationsRelations
> {
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
  ) {
    super(UserLocations, dataSource);
  }
}
