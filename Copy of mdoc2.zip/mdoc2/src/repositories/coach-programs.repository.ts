import {
  BelongsToAccessor,
  DefaultCrudRepository,
  repository,
} from '@loopback/repository';
import {Coach, CoachPrograms, CoachProgramsRelations, Programs} from '../models';
import {DbDataSource} from '../datasources';
import {Getter, inject} from '@loopback/core';
import {ProgramsRepository} from './programs.repository';
import { CoachRepository } from './coach.repository';

export class CoachProgramsRepository extends DefaultCrudRepository<
  CoachPrograms,
  typeof CoachPrograms.prototype.id,
  CoachProgramsRelations
> {
  public readonly program: BelongsToAccessor<
    Programs,
    typeof Programs.prototype.id
  >;
  public readonly coach: BelongsToAccessor<
    Coach,
    typeof Coach.prototype.id
  >;
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('ProgramsRepository')
    programsRepositoryGetter: Getter<ProgramsRepository>,
    @repository.getter('CoachRepository')
    coachRepositoryGetter: Getter<CoachRepository>,
  ) {
    super(CoachPrograms, dataSource);
    this.program = this.createBelongsToAccessorFor(
      'program',
      programsRepositoryGetter,
    );
    this.coach = this.createBelongsToAccessorFor(
      'coach',
      coachRepositoryGetter,
    );
    this.registerInclusionResolver('program', this.program.inclusionResolver);
    this.registerInclusionResolver('coach', this.coach.inclusionResolver);
  }
}
