import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Exercises, ExercisesRelations} from '../models';

export class ExercisesRepository extends DefaultCrudRepository<
  Exercises,
  typeof Exercises.prototype.id,
  ExercisesRelations
> {
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
  ) {
    super(Exercises, dataSource);
  }
}
