import {
  DefaultCrudRepository,
  juggler,
  HasManyRepositoryFactory,
  BelongsToAccessor,
  repository,
} from '@loopback/repository';
import {
  Coach,
  CoachRelations,
  Users,
  CoachType,
  CoachPrograms,
  CoachSpeciality,
  CoachUserSubscriptions,
  Partner,
} from '../models';
import {UsersRepository} from './users.repository';
import {CoachTypeRepository} from './coach-type.repository';
import {DbDataSource} from '../datasources';
import {inject, Getter} from '@loopback/core';
import {CoachProgramsRepository} from './coach-programs.repository';
import {CoachSpecialityRepository} from './coach-speciality.repository';
import { CoachUserSubscriptionsRepository } from './coach-user-subscriptions.repository';
import { PartnerRepository } from './partner.repository';

export class CoachRepository extends DefaultCrudRepository<
  Coach,
  typeof Coach.prototype.id,
  CoachRelations
> {
  public readonly users: HasManyRepositoryFactory<
    Users,
    typeof Coach.prototype.id
  >;
  public readonly coachType: BelongsToAccessor<
    CoachType,
    typeof Coach.prototype.id
  >;
  public readonly partner: BelongsToAccessor<
    Partner,
    typeof Partner.prototype.id
  >;
  public readonly coachPrograms: HasManyRepositoryFactory<
    CoachPrograms,
    typeof CoachPrograms.prototype.id
  >;
  public readonly coachSpecialities: HasManyRepositoryFactory<
    CoachSpeciality,
    typeof CoachSpeciality.prototype.id
  >;
  public readonly assignedMembers: HasManyRepositoryFactory<
    CoachUserSubscriptions,
    typeof CoachUserSubscriptions.prototype.id
  >;
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('UsersRepository')
    userRepositoryGetter: Getter<UsersRepository>,
    @repository.getter('CoachTypeRepository')
    coachTypeRepositoryGetter: Getter<CoachTypeRepository>,
    @repository.getter('PartnerRepository')
    partnerRepositoryGetter: Getter<PartnerRepository>,
    @repository.getter('CoachProgramsRepository')
    coachProgramsRepositoryGetter: Getter<CoachProgramsRepository>,
    @repository.getter('CoachSpecialityRepository')
    coachSpecialityRepositoryGetter: Getter<CoachSpecialityRepository>,
    @repository.getter('CoachUserSubscriptionsRepository')
    coachUserSubscriptionsRepositoryGetter: Getter<CoachUserSubscriptionsRepository>,
  ) {
    super(Coach, dataSource);
    this.users = this.createHasManyRepositoryFactoryFor(
      'users',
      userRepositoryGetter,
    );
    this.assignedMembers = this.createHasManyRepositoryFactoryFor(
      'assignedMembers',
      coachUserSubscriptionsRepositoryGetter,
    );
    this.coachType = this.createBelongsToAccessorFor(
      'coachType',
      coachTypeRepositoryGetter,
    );
    this.partner = this.createBelongsToAccessorFor(
      'partner',
      partnerRepositoryGetter,
    );
    this.coachPrograms = this.createHasManyRepositoryFactoryFor(
      'coachPrograms',
      coachProgramsRepositoryGetter,
    );
    this.coachSpecialities = this.createHasManyRepositoryFactoryFor(
      'coachSpecialities',
      coachSpecialityRepositoryGetter,
    );
    this.registerInclusionResolver(
      'coachType',
      this.coachType.inclusionResolver,
    );
    this.registerInclusionResolver('users', this.users.inclusionResolver);
    this.registerInclusionResolver(
      'coachPrograms',
      this.coachPrograms.inclusionResolver,
    );

    this.registerInclusionResolver(
      'coachSpecialities',
      this.coachSpecialities.inclusionResolver,
    );

    this.registerInclusionResolver(
      'assignedMembers',
      this.assignedMembers.inclusionResolver,
    );
    this.registerInclusionResolver(
      'partner',
      this.partner.inclusionResolver,
    );
  }
}
