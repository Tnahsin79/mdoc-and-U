import {DefaultCrudRepository} from '@loopback/repository';
import {Coupons, CouponsRelations} from '../models';
import {DbDataSource} from '../datasources';
import {inject} from '@loopback/core';

export class CouponsRepository extends DefaultCrudRepository<
  Coupons,
  typeof Coupons.prototype.id,
  CouponsRelations
> {
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
  ) {
    super(Coupons, dataSource);
  }
}
