import {
  BelongsToAccessor,
  DefaultCrudRepository,
  repository,
  HasManyRepositoryFactory,
} from '@loopback/repository';
import {
  PlansBenefit,
  ProgramPlans,
  ProgramPlansRelations,
  Programs,
} from '../models';
import {DbDataSource} from '../datasources';
import {Getter, inject} from '@loopback/core';
import {ProgramsRepository} from './programs.repository';
import {PlansBenefitRepository} from './plans-benefits.repository';

export class ProgramPlansRepository extends DefaultCrudRepository<
  ProgramPlans,
  typeof ProgramPlans.prototype.id,
  ProgramPlansRelations
> {
  public readonly program: BelongsToAccessor<
    Programs,
    typeof Programs.prototype.id
  >;
  public readonly plansBenefit: HasManyRepositoryFactory<
    PlansBenefit,
    typeof PlansBenefit.prototype.id
  >;
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('ProgramsRepository')
    programsRepositoryGetter: Getter<ProgramsRepository>,
    @repository.getter('PlansBenefitRepository')
    plansBenefitRepositoryGetter: Getter<PlansBenefitRepository>,
  ) {
    super(ProgramPlans, dataSource);
    this.program = this.createBelongsToAccessorFor(
      'program',
      programsRepositoryGetter,
    );
    this.registerInclusionResolver('program', this.program.inclusionResolver);
    this.plansBenefit = this.createHasManyRepositoryFactoryFor(
      'plansBenefit',
      plansBenefitRepositoryGetter,
    );
    this.registerInclusionResolver(
      'plansBenefit',
      this.plansBenefit.inclusionResolver,
    );
  }
}
