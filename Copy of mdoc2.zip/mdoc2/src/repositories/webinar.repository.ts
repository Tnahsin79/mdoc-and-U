import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Webinar, WebinarRelations} from '../models';

export class WebinarRepository extends DefaultCrudRepository<
  Webinar,
  typeof Webinar.prototype.id,
  WebinarRelations
> {
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
  ) {
    super(Webinar, dataSource);
  }
}
