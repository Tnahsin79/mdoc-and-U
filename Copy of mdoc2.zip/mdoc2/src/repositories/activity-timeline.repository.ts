import {
  repository,
  BelongsToAccessor,
  DefaultCrudRepository,
} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Getter, inject} from '@loopback/core';
import {UsersRepository} from './users.repository';
import {ActivityTimeline, ActivityTimelineRelations, Users} from '../models';

export class ActivityTimelineRepository extends DefaultCrudRepository<
  ActivityTimeline,
  typeof ActivityTimeline.prototype.id,
  ActivityTimelineRelations
> {
  public readonly user: BelongsToAccessor<Users, typeof Users.prototype.id>;
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('UsersRepository')
    usersRepositoryGetter: Getter<UsersRepository>,
  ) {
    super(ActivityTimeline, dataSource);
    this.user = this.createBelongsToAccessorFor('user', usersRepositoryGetter);
    this.registerInclusionResolver('user', this.user.inclusionResolver);
  }
}
