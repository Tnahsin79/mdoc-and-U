import {
  DefaultCrudRepository,
  HasManyRepositoryFactory,
  repository,
} from '@loopback/repository';
import {Disease, DiseaseRelations, UserDisease} from '../models';
import {DbDataSource} from '../datasources';
import {Getter, inject} from '@loopback/core';
import {UserDiseaseRepository} from './user-disease.repository';

export class DiseaseRepository extends DefaultCrudRepository<
  Disease,
  typeof Disease.prototype.id,
  DiseaseRelations
> {
  public readonly users: HasManyRepositoryFactory<
    UserDisease,
    typeof UserDisease.prototype.id
  >;

  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('UserDiseaseRepository')
    userDiseaseRepositoryGetter: Getter<UserDiseaseRepository>,
  ) {
    super(Disease, dataSource);
    this.users = this.createHasManyRepositoryFactoryFor(
      'users',
      userDiseaseRepositoryGetter,
    );
    this.registerInclusionResolver('users', this.users.inclusionResolver);
  }
}
