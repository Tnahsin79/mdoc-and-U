import {
  Option,
  Question,
  UserFeedback,
  UserFeedbackAnswer,
  UserFeedbackAnswerRelations,
} from '../models';
import {
  repository,
  BelongsToAccessor,
  DefaultCrudRepository,
} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Getter, inject} from '@loopback/core';
import {OptionRepository} from './option.repository';
import {QuestionRepository} from './question.repository';
import {UserFeedbackRepository} from './user-feedback.repository';

export class UserFeedbackAnswerRepository extends DefaultCrudRepository<
  UserFeedbackAnswer,
  typeof UserFeedbackAnswer.prototype.id,
  UserFeedbackAnswerRelations
> {
  public readonly userFeedback: BelongsToAccessor<
    UserFeedback,
    typeof UserFeedback.prototype.id
  >;
  public readonly question: BelongsToAccessor<
    Question,
    typeof Question.prototype.id
  >;
  public readonly selectedOption: BelongsToAccessor<
    Option,
    typeof Option.prototype.id
  >;
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('UserFeedbackRepository')
    userFeedbackRepositoryGetter: Getter<UserFeedbackRepository>,
    @repository.getter('QuestionRepository')
    questionRepositoryGetter: Getter<QuestionRepository>,
    @repository.getter('OptionRepository')
    optionRepositoryGetter: Getter<OptionRepository>,
  ) {
    super(UserFeedbackAnswer, dataSource);

    this.userFeedback = this.createBelongsToAccessorFor(
      'userFeedback',
      userFeedbackRepositoryGetter,
    );
    this.question = this.createBelongsToAccessorFor(
      'question',
      questionRepositoryGetter,
    );
    this.selectedOption = this.createBelongsToAccessorFor(
      'selectedOption',
      optionRepositoryGetter,
    );

    this.registerInclusionResolver(
      'userFeedback',
      this.userFeedback.inclusionResolver,
    );
    this.registerInclusionResolver('question', this.question.inclusionResolver);
    this.registerInclusionResolver(
      'selectedOption',
      this.selectedOption.inclusionResolver,
    );
  }
}
