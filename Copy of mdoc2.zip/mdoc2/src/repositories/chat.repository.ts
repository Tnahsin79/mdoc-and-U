import {
  BelongsToAccessor,
  DefaultCrudRepository,
  repository,
} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Getter, inject} from '@loopback/core';
import {UsersRepository} from './users.repository';
import {CoachRepository} from './coach.repository';
import {Chat, ChatRelations, ChatRoom, Coach, Users} from '../models';
import { ChatRoomRepository } from './chat-room.repository';

export class ChatRepository extends DefaultCrudRepository<
  Chat,
  typeof Chat.prototype.id,
  ChatRelations
> {
  public readonly user: BelongsToAccessor<Users, typeof Users.prototype.id>;
  public readonly coach: BelongsToAccessor<Coach, typeof Coach.prototype.id>;
  public readonly chatRoom: BelongsToAccessor<ChatRoom, typeof ChatRoom.prototype.id>;
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('UsersRepository')
    usersRepositoryGetter: Getter<UsersRepository>,
    @repository.getter('CoachRepository')
    coachRepositoryGetter: Getter<CoachRepository>,
    @repository.getter('ChatRoomRepository')
    chatRoomRepositoryGetter: Getter<ChatRoomRepository>,
  ) {
    super(Chat, dataSource);
    this.user = this.createBelongsToAccessorFor('user', usersRepositoryGetter);
    this.registerInclusionResolver('user', this.user.inclusionResolver);
    this.coach = this.createBelongsToAccessorFor(
      'coach',
      coachRepositoryGetter,
    );
    this.chatRoom = this.createBelongsToAccessorFor(
      'chatRoom',
      chatRoomRepositoryGetter,
    );
    this.registerInclusionResolver('coach', this.coach.inclusionResolver);
    this.registerInclusionResolver('chatRoom', this.chatRoom.inclusionResolver);

    (this.modelClass as any).observe('persist', async (ctx: any) => {
      ctx.data.modified = new Date();
    });
  }
}
