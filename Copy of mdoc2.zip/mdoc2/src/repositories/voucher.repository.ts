import {
    BelongsToAccessor,
    DefaultCrudRepository,
    HasManyRepositoryFactory,
    HasOneRepositoryFactory,
    repository,
  } from '@loopback/repository';
  import {Programs, ProgramsRelations, Benefits, ProgramPlans, Admin, CoachPrograms, ChangeStages, Voucher, VoucherRelations} from '../models';
  import {ProgramPlansRepository} from './program-plans.repository';
  import {BenefitsRepository} from './benefits.repository';
  import {DbDataSource} from '../datasources';
  import {inject, Getter} from '@loopback/core';
  import { AdminRepository } from './admin.repository';
  import { CoachProgramsRepository } from './coach-programs.repository';
  import { ChangeStagesRepository } from './change-stages.repository';
import { ProgramsRepository } from './programs.repository';
  
  export class VoucherRepository extends DefaultCrudRepository<
    Voucher,
    typeof Voucher.prototype.id,
    VoucherRelations
  > {
    public readonly plan: BelongsToAccessor<
      ProgramPlans,
      typeof ProgramPlans.prototype.id
    >;
    public readonly createdBy: BelongsToAccessor<
    Admin,
    typeof Admin.prototype.id
  >;
    public readonly program: BelongsToAccessor<
    Programs,
    typeof Programs.prototype.id
  >;
    
    constructor(
      @inject('datasources.db') dataSource: DbDataSource,
      @repository.getter('ProgramPlansRepository')
      plansRepositoryGetter: Getter<ProgramPlansRepository>,
      @repository.getter('ProgramsRepository')
      programRepositoryGetter: Getter<ProgramsRepository>,
      @repository.getter('AdminRepository')
      adminRepositoryGetter: Getter<AdminRepository>,
    ) {
      super(Voucher, dataSource);
      this.plan = this.createBelongsToAccessorFor(
        'plan',
        plansRepositoryGetter,
      );
      this.program = this.createBelongsToAccessorFor(
        'program',
        programRepositoryGetter,
      );
      this.createdBy = this.createBelongsToAccessorFor(
        'createdBy',
        adminRepositoryGetter,
      );
      this.registerInclusionResolver('plan', this.plan.inclusionResolver);
      this.registerInclusionResolver('program', this.program.inclusionResolver);
      this.registerInclusionResolver('createdBy', this.createdBy.inclusionResolver)
    }
  }
  