import {Getter, inject} from '@loopback/core';
import {BelongsToAccessor, DefaultCrudRepository, repository} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Privilege, Role, RolePrivilege, RolePrivilegeRelations} from '../models';
import { RoleRepository } from './role.repository';
import { PrivilegeRepository } from './privilege.repository';

export class RolePrivilegeRepository extends DefaultCrudRepository<
  RolePrivilege,
  typeof RolePrivilege.prototype.id,
  RolePrivilegeRelations

> {
   public readonly role: BelongsToAccessor<Role, typeof Role.prototype.id>;
   public readonly privilege: BelongsToAccessor<Privilege, typeof Privilege.prototype.id>;
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('RoleRepository') public  roleRepositoryGetter: Getter<RoleRepository>,
    @repository.getter('PrivilegeRepository') public privilegeRepositoryGetter: Getter<PrivilegeRepository>,
  ) {
    super(RolePrivilege, dataSource);
    this.role = this.createBelongsToAccessorFor('role', roleRepositoryGetter);
    this.privilege = this.createBelongsToAccessorFor('privilege', privilegeRepositoryGetter);
    this.registerInclusionResolver('role', this.role.inclusionResolver);
    this.registerInclusionResolver('privilege', this.privilege.inclusionResolver);
  }
}
