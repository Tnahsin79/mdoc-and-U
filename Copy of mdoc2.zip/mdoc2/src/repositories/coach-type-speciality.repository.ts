import {
  CoachType,
  CoachTypeSpeciality,
  CoachTypeSpecialityRelations,
  Speciality,
} from '../models';
import {
  BelongsToAccessor,
  DefaultCrudRepository,
  repository,
} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Getter, inject} from '@loopback/core';
import {CoachTypeRepository} from './coach-type.repository';
import {SpecialityRepository} from './speciality.repository';

export class CoachTypeSpecialityRepository extends DefaultCrudRepository<
  CoachTypeSpeciality,
  typeof CoachTypeSpeciality.prototype.id,
  CoachTypeSpecialityRelations
> {
  public readonly coachType: BelongsToAccessor<
    CoachType,
    typeof CoachType.prototype.id
  >;
  public readonly speciality: BelongsToAccessor<
    Speciality,
    typeof Speciality.prototype.id
  >;

  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('CoachTypeRepository')
    coachTypeRepositoryGetter: Getter<CoachTypeRepository>,
    @repository.getter('SpecialityRepository')
    specialityRepositoryGetter: Getter<SpecialityRepository>,
  ) {
    super(CoachTypeSpeciality, dataSource);
    this.coachType = this.createBelongsToAccessorFor(
      'coachType',
      coachTypeRepositoryGetter,
    );
    this.speciality = this.createBelongsToAccessorFor(
      'speciality',
      specialityRepositoryGetter,
    );
    this.registerInclusionResolver(
      'coachType',
      this.coachType.inclusionResolver,
    );
    this.registerInclusionResolver(
      'speciality',
      this.speciality.inclusionResolver,
    );
  }
}
