import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {ExerciseTypes, ExerciseTypesRelations} from '../models';

export class ExerciseTypesRepository extends DefaultCrudRepository<
  ExerciseTypes,
  typeof ExerciseTypes.prototype.id,
  ExerciseTypesRelations
> {
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
  ) {
    super(ExerciseTypes, dataSource);
  }
}
