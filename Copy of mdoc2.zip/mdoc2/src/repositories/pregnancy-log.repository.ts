import {
  BelongsToAccessor,
  DefaultCrudRepository,
  repository,
} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Getter, inject} from '@loopback/core';
import {PregnancyCycleRepository} from './pregnancy-cycle.repository';
import {PregnancyCycle, PregnancyLog, PregnancyLogRelations} from '../models';

export class PregnancyLogRepository extends DefaultCrudRepository<
  PregnancyLog,
  typeof PregnancyLog.prototype.id,
  PregnancyLogRelations
> {
  public readonly pregnancyCycle: BelongsToAccessor<
    PregnancyCycle,
    typeof PregnancyCycle.prototype.id
  >;
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('PregnancyCycleRepository')
    public pregnancyCycleRepositoryGetter: Getter<PregnancyCycleRepository>,
  ) {
    super(PregnancyLog, dataSource);
    this.pregnancyCycle = this.createBelongsToAccessorFor(
      'pregnancyCycle',
      pregnancyCycleRepositoryGetter,
    );
    this.registerInclusionResolver(
      'pregnancyCycle',
      this.pregnancyCycle.inclusionResolver,
    );
  }
}
