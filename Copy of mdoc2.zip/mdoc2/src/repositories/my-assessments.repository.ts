import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {MyAssessments, MyAssessmentsRelations} from '../models';

export class MyAssessmentsRepository extends DefaultCrudRepository<
  MyAssessments,
  typeof MyAssessments.prototype.id,
  MyAssessmentsRelations
> {
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
  ) {
    super(MyAssessments, dataSource);
  }
}
