import { DefaultCrudRepository, BelongsToAccessor, repository } from '@loopback/repository';
import { Symptoms, SymptomsRelations, Admin } from '../models';
import { DbDataSource } from '../datasources';
import { inject, Getter } from '@loopback/core';
import { AdminRepository } from './admin.repository';

export class SymptomsRepository extends DefaultCrudRepository<Symptoms, typeof Symptoms.prototype.id, SymptomsRelations> {
  public readonly admin: BelongsToAccessor<
  Admin,
  typeof Admin.prototype.id
>;
  public readonly approver: BelongsToAccessor<
  Admin,
  typeof Admin.prototype.id
>;
 
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('AdminRepository')
    adminRepositoryGetter: Getter<AdminRepository>,
  ) {
    super(Symptoms, dataSource);

    this.admin = this.createBelongsToAccessorFor(
      'admin',
      adminRepositoryGetter,
    );
    this.approver = this.createBelongsToAccessorFor(
      'approver',
      adminRepositoryGetter,
    );
    
    this.registerInclusionResolver('admin', this.admin.inclusionResolver);
    this.registerInclusionResolver('approver', this.approver.inclusionResolver);


    (this.modelClass as any).observe('persist', async (ctx: any) => {
      ctx.data.modified = new Date();
    });
  }
}
