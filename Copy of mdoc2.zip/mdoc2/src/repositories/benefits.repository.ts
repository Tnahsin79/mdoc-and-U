import {
  DefaultCrudRepository,
  BelongsToAccessor,
  repository,
} from '@loopback/repository';
import {Benefits, BenefitsRelations, Programs} from '../models';
import {DbDataSource} from '../datasources';
import {Getter, inject} from '@loopback/core';
import {ProgramsRepository} from './programs.repository';

export class BenefitsRepository extends DefaultCrudRepository<
  Benefits,
  typeof Benefits.prototype.id,
  BenefitsRelations
> {
  public readonly program: BelongsToAccessor<
    Programs,
    typeof Programs.prototype.id
  >;
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('ProgramsRepository')
    programsRepositoryGetter: Getter<ProgramsRepository>,
  ) {
    super(Benefits, dataSource);
    this.program = this.createBelongsToAccessorFor(
      'program',
      programsRepositoryGetter,
    );
    this.registerInclusionResolver('program', this.program.inclusionResolver);
  }
}
