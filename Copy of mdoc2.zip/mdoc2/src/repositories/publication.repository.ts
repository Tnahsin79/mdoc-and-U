import {
  Admin,
  Publication,
  PublicationRelations,
} from '../models';
import {
  repository,
  BelongsToAccessor,
  DefaultCrudRepository,
} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Getter, inject} from '@loopback/core';
import {AdminRepository} from './admin.repository';

export class PublicationRepository extends DefaultCrudRepository<
  Publication,
  typeof Publication.prototype.id,
  PublicationRelations
> {
  public readonly creator: BelongsToAccessor<Admin, typeof Admin.prototype.id>;
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('AdminRepository')
    creatorRepositoryGetter: Getter<AdminRepository>,
  ) {
    super(Publication, dataSource);
    this.creator = this.createBelongsToAccessorFor(
      'creator',
      creatorRepositoryGetter,
    );
    this.registerInclusionResolver('creator', this.creator.inclusionResolver);
  }
}
