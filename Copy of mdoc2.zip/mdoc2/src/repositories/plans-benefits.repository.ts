import {BelongsToAccessor, DefaultCrudRepository, repository} from '@loopback/repository';
import {Benefits, PlansBenefit, PlansBenefitRelations} from '../models';
import {DbDataSource} from '../datasources';
import {Getter, inject} from '@loopback/core';
import { BenefitsRepository } from './benefits.repository';

export class PlansBenefitRepository extends DefaultCrudRepository<
  PlansBenefit,
  typeof PlansBenefit.prototype.id,
  PlansBenefitRelations
> {
  public readonly benefit: BelongsToAccessor<
    Benefits,
    typeof Benefits.prototype.id
  >;
  constructor(@inject('datasources.db') dataSource: DbDataSource,
  @repository.getter('BenefitsRepository')
  benefitsRepositoryGetter: Getter<BenefitsRepository>,) {
    super(PlansBenefit, dataSource);
    this.benefit = this.createBelongsToAccessorFor(
      'benefit',
      benefitsRepositoryGetter,
    );
    this.registerInclusionResolver('benefit', this.benefit.inclusionResolver);
  }
}
