import {
    BelongsToAccessor,
    DefaultCrudRepository,
    repository,
  } from '@loopback/repository';
  import {DbDataSource} from '../datasources';
  import {Getter, inject} from '@loopback/core';
  import {ChangeStages, ChangeStagesRelations, Programs, Admin} from '../models';
import { ProgramsRepository } from './programs.repository';
import { AdminRepository } from './admin.repository';
  
  export class ChangeStagesRepository extends DefaultCrudRepository<
    ChangeStages,
    typeof ChangeStages.prototype.id,
    ChangeStagesRelations
  > {
    public readonly program: BelongsToAccessor<Programs, typeof Programs.prototype.id>;
    public readonly createdBy: BelongsToAccessor<Admin, typeof Admin.prototype.id>;
    constructor(
      @inject('datasources.db') dataSource: DbDataSource,
      @repository.getter('ProgramsRepository')
      programsRepositoryGetter: Getter<ProgramsRepository>,
      @repository.getter('AdminRepository')
      adminRepositoryGetter: Getter<AdminRepository>,
    ) {
      super(ChangeStages, dataSource);
      this.program = this.createBelongsToAccessorFor('program', programsRepositoryGetter);
      this.registerInclusionResolver('program', this.program.inclusionResolver);
      this.createdBy = this.createBelongsToAccessorFor(
        'createdBy',
        adminRepositoryGetter,
      );
      this.registerInclusionResolver('createdBy', this.createdBy.inclusionResolver);
    }
  }
  