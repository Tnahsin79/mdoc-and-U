import {
  Users,
  PregnancyLog,
  PregnancyCycle,
  PregnancyCycleRelations,
} from '../models';
import {
  repository,
  BelongsToAccessor,
  DefaultCrudRepository,
  HasManyRepositoryFactory,
} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Getter, inject} from '@loopback/core';
import {UsersRepository} from './users.repository';
import {PregnancyLogRepository} from './pregnancy-log.repository';

export class PregnancyCycleRepository extends DefaultCrudRepository<
  PregnancyCycle,
  typeof PregnancyCycle.prototype.id,
  PregnancyCycleRelations
> {
  public readonly user: BelongsToAccessor<Users, typeof Users.prototype.id>;
  public readonly pregnancyLogs: HasManyRepositoryFactory<
    PregnancyLog,
    typeof PregnancyLog.prototype.id
  >;
  constructor(
    @inject('datasources.db')
    dataSource: DbDataSource,
    @repository.getter('UsersRepository')
    public usersRepositoryGetter: Getter<UsersRepository>,
    @repository.getter('PregnancyLogRepository')
    public pregnancyLogRepositoryGetter: Getter<PregnancyLogRepository>,
  ) {
    super(PregnancyCycle, dataSource);
    this.user = this.createBelongsToAccessorFor('user', usersRepositoryGetter);
    this.pregnancyLogs = this.createHasManyRepositoryFactoryFor(
      'pregnancyLogs',
      pregnancyLogRepositoryGetter,
    );
    this.registerInclusionResolver('user', this.user.inclusionResolver);
    this.registerInclusionResolver(
      'pregnancyLogs',
      this.pregnancyLogs.inclusionResolver,
    );
  }
}
