import {
    BelongsToAccessor,
    DefaultCrudRepository,
    HasManyRepositoryFactory,
    repository,
  } from '@loopback/repository';
  import {Admin, Option, Programs, Question, QuestionRelations} from '../models';
  import {DbDataSource} from '../datasources';
  import {Getter, inject} from '@loopback/core';
import { ProgramsRepository } from './programs.repository';
import { AdminRepository } from './admin.repository';
import { OptionRepository } from './option.repository';
  
  export class QuestionRepository extends DefaultCrudRepository<
    Question,
    typeof Question.prototype.id,
    QuestionRelations
  > {
    public readonly admin: BelongsToAccessor<
      Admin,
      typeof Admin.prototype.id
    >;
    public readonly program: BelongsToAccessor<
      Programs,
      typeof Programs.prototype.id
    >;
    public readonly options: HasManyRepositoryFactory<
      Option,
      typeof Option.prototype.id
    >;
    constructor(
      @inject('datasources.db') dataSource: DbDataSource,
      @repository.getter('AdminRepository')
      adminRepositoryGetter: Getter<AdminRepository>,
      @repository.getter('ProgramsRepository')
      programRepositoryGetter: Getter<ProgramsRepository>,
      @repository.getter('OptionRepository')
      optionRepositoryGetter: Getter<OptionRepository>,
    ) {
      super(Question, dataSource);
      this.admin = this.createBelongsToAccessorFor(
        'createdBy',
        adminRepositoryGetter,
      );
      this.program = this.createBelongsToAccessorFor(
        'program',
        programRepositoryGetter,
      );
      this.options = this.createHasManyRepositoryFactoryFor(
        'options',
        optionRepositoryGetter,
      );
      this.registerInclusionResolver('createdBy', this.admin.inclusionResolver);
      this.registerInclusionResolver('program', this.program.inclusionResolver);
      this.registerInclusionResolver('options', this.options.inclusionResolver);
    }
  }
  