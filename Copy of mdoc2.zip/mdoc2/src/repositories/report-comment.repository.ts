import {
  BelongsToAccessor,
  DefaultCrudRepository,
  repository,
} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Getter, inject} from '@loopback/core';
import {UsersRepository} from './users.repository';
import {CommentRepository} from './comment.repository';
import {Comment, ReportComment, ReportCommentRelations, Users} from '../models';
export class ReportCommmentRepository extends DefaultCrudRepository<
  ReportComment,
  typeof ReportComment.prototype.id,
  ReportCommentRelations
> {
  public readonly comment: BelongsToAccessor<
    Comment,
    typeof Comment.prototype.id
  >;
  public readonly user: BelongsToAccessor<Users, typeof Users.prototype.id>;
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('CommentRepository')
    CommentRepositoryGetter: Getter<CommentRepository>,
    @repository.getter('UsersRepository')
    usersRepositoryGetter: Getter<UsersRepository>,
  ) {
    super(ReportComment, dataSource);
    this.comment = this.createBelongsToAccessorFor(
      'comment',
      CommentRepositoryGetter,
    );
    this.user = this.createBelongsToAccessorFor('user', usersRepositoryGetter);
    this.registerInclusionResolver('comment', this.comment.inclusionResolver);
    this.registerInclusionResolver('user', this.user.inclusionResolver);
  }
}
