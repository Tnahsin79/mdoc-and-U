import { DefaultCrudRepository } from '@loopback/repository';
import { Pharmacy, PharmacyRelations } from '../models';
import { DbDataSource } from '../datasources';
import { inject } from '@loopback/core';

export class PharmacyRepository extends DefaultCrudRepository<
  Pharmacy,
  typeof Pharmacy.prototype.id,
  PharmacyRelations
  > {
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
  ) {
    super(Pharmacy, dataSource);


    (this.modelClass as any).observe('persist', async (ctx: any) => {
      ctx.data.modified = new Date();
    });
  }
}
