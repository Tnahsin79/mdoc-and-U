import { DefaultCrudRepository } from '@loopback/repository';
import { HealthDiary, HealthDiaryRelations } from '../models';
import { DbDataSource } from '../datasources';
import { inject } from '@loopback/core';

export class HealthDiaryRepository extends DefaultCrudRepository<
  HealthDiary,
  typeof HealthDiary.prototype.id,
  HealthDiaryRelations
  > {
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
  ) {
    super(HealthDiary, dataSource);

    (this.modelClass as any).observe('persist', async (ctx: any) => {
      ctx.data.modified = new Date();
    });
  }
}
