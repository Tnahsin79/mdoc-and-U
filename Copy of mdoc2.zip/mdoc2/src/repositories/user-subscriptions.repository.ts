import {
  Users,
  Voucher,
  Programs,
  Payments,
  ProgramPlans,
  UserSubscriptions,
  CoachUserSubscriptions,
  UserSubscriptionsRelations,
} from '../models';
import {
  repository,
  BelongsToAccessor,
  DefaultCrudRepository,
  HasOneRepositoryFactory,
} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Getter, inject} from '@loopback/core';
import {UsersRepository} from './users.repository';
import {ProgramsRepository} from './programs.repository';
import {PaymentsRepository} from './payments.repository';
import { VoucherRepository } from './voucher.repository';
import {ProgramPlansRepository} from './program-plans.repository';
import {CoachUserSubscriptionsRepository} from './coach-user-subscriptions.repository';

export class UserSubscriptionsRepository extends DefaultCrudRepository<
  UserSubscriptions,
  typeof UserSubscriptions.prototype.id,
  UserSubscriptionsRelations
> {
  public readonly program: BelongsToAccessor<
    Programs,
    typeof Programs.prototype.id
  >;
  public readonly plan: BelongsToAccessor<
    ProgramPlans,
    typeof ProgramPlans.prototype.id
  >;
  public readonly user: BelongsToAccessor<Users, typeof Users.prototype.id>;
  public readonly voucher: BelongsToAccessor<Voucher, typeof Voucher.prototype.id>;
  public readonly payment: BelongsToAccessor<
    Payments,
    typeof Payments.prototype.id
  >;

  public readonly coach: HasOneRepositoryFactory<
    CoachUserSubscriptions,
    typeof CoachUserSubscriptions.prototype.id
  >;
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('ProgramsRepository')
    programsRepositoryGetter: Getter<ProgramsRepository>,
    @repository.getter('ProgramPlansRepository')
    programPlansRepositoryGetter: Getter<ProgramPlansRepository>,
    @repository.getter('UsersRepository')
    usersRepositoryGetter: Getter<UsersRepository>,
    @repository.getter('PaymentsRepository')
    paymentRepositoryGetter: Getter<PaymentsRepository>,
    @repository.getter('CoachUserSubscriptionsRepository')
    coachUserSubscriptionsRepositoryGetter: Getter<
      CoachUserSubscriptionsRepository
    >,
    @repository.getter('VoucherRepository')
    voucherRepositoryGetter: Getter<
      VoucherRepository
    >,
  ) {
    super(UserSubscriptions, dataSource);
    this.program = this.createBelongsToAccessorFor(
      'program',
      programsRepositoryGetter,
    );
    this.plan = this.createBelongsToAccessorFor(
      'plan',
      programPlansRepositoryGetter,
    );
    this.user = this.createBelongsToAccessorFor('user', usersRepositoryGetter);
    this.payment = this.createBelongsToAccessorFor(
      'payment',
      paymentRepositoryGetter,
    );
    this.coach = this.createHasOneRepositoryFactoryFor(
      'coach',
      coachUserSubscriptionsRepositoryGetter,
    );
    this.voucher = this.createBelongsToAccessorFor(
      'voucher',
      voucherRepositoryGetter,
    );
    this.registerInclusionResolver('program', this.program.inclusionResolver);
    this.registerInclusionResolver('plan', this.plan.inclusionResolver);
    this.registerInclusionResolver('user', this.user.inclusionResolver);
    this.registerInclusionResolver('payment', this.payment.inclusionResolver);
    this.registerInclusionResolver('coach', this.coach.inclusionResolver);
    this.registerInclusionResolver('voucher', this.voucher.inclusionResolver);
  }
}
