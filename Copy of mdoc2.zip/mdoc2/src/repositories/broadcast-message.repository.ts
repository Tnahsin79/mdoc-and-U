import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {BroadcastMessage, BroadcastMessageRelations} from '../models';

export class BroadcastMessageRepository extends DefaultCrudRepository<
  BroadcastMessage,
  typeof BroadcastMessage.prototype.id,
  BroadcastMessageRelations
> {
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
  ) {
    super(BroadcastMessage, dataSource);
  }
}
