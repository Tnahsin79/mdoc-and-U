import {
  DefaultCrudRepository,
  BelongsToAccessor,
  repository,
  HasManyRepositoryFactory,
} from '@loopback/repository';
import {
  Medication,
  MedicationRelations,
  Users,
  MedicationPassport,
} from '../models';
import {DbDataSource} from '../datasources';
import {inject, Getter} from '@loopback/core';
import {UsersRepository} from './users.repository';
import {MedicationPassportRepository} from './medication-passport.repository';

export class MedicationRepository extends DefaultCrudRepository<
  Medication,
  typeof Medication.prototype.id,
  MedicationRelations
> {
  // public readonly medicine: BelongsToAccessor<MedicationPassport, typeof MedicationPassport.prototype.id>;
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,

    // @repository.getter('UsersRepository') public usersRepositoryGitter: Getter<UsersRepository>,
    // @repository.getter('MedicationPassportRepository') public MedicationPassportRepositoryGitter: Getter<MedicationPassportRepository>,
  ) {
    super(Medication, dataSource);

    // this.user = this.createBelongsToAccessorFor('user', usersRepositoryGitter);
    // this.medicine = this.createBelongsToAccessorFor('medicine', MedicationPassportRepositoryGitter);

    // this.registerInclusionResolver('user', this.user.inclusionResolver);
    // this.registerInclusionResolver('medicine', this.medicine.inclusionResolver);

    (this.modelClass as any).observe('persist', async (ctx: any) => {
      ctx.data.modified = new Date();
    });
  }
}
