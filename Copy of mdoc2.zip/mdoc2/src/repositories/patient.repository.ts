import { DefaultCrudRepository, BelongsToAccessor, repository } from '@loopback/repository';
import { Patient, PatientRelations, Users } from '../models';
import { DbDataSource } from '../datasources';
import { inject, Getter } from '@loopback/core';
import { UsersRepository } from './users.repository';

export class PatientRepository extends DefaultCrudRepository<Patient, typeof Patient.prototype.id, PatientRelations> {
  public readonly patientDetail: BelongsToAccessor<Users, typeof Users.prototype.id>;
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('UsersRepository') public usersRepositoryGitter: Getter<UsersRepository>,
  ) {
    super(Patient, dataSource);

    this.patientDetail = this.createBelongsToAccessorFor('patientDetail', usersRepositoryGitter);

    this.registerInclusionResolver('patientDetail', this.patientDetail.inclusionResolver);

    (this.modelClass as any).observe('persist', async (ctx: any) => {
      ctx.data.modified = new Date();
    });

  }
}
