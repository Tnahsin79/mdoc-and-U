import {
  repository,
  BelongsToAccessor,
  DefaultCrudRepository,
} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Getter, inject} from '@loopback/core';
import {GoalRepository} from './goal.repository';
import {UsersRepository} from './users.repository';
import {GoalActionRepository} from './goal-actions.repository';
import {Goal, GoalAction, GoalLogs, GoalLogsRelations, Users} from '../models';

export class GoalLogsRepository extends DefaultCrudRepository<
  GoalLogs,
  typeof GoalLogs.prototype.id,
  GoalLogsRelations
> {
  public readonly goal: BelongsToAccessor<Goal, typeof Goal.prototype.id>;
  public readonly user: BelongsToAccessor<Users, typeof Users.prototype.id>;
  public readonly goalAction: BelongsToAccessor<
    GoalAction,
    typeof GoalAction.prototype.id
  >;
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('UsersRepository')
    usersRepositoryGetter: Getter<UsersRepository>,
    @repository.getter('GoalRepository')
    goalRepositoryGetter: Getter<GoalRepository>,
    @repository.getter('GoalActionRepository')
    goalActionRepositoryGetter: Getter<GoalActionRepository>,
  ) {
    super(GoalLogs, dataSource);

    this.user = this.createBelongsToAccessorFor('user', usersRepositoryGetter);
    this.goal = this.createBelongsToAccessorFor('goal', goalRepositoryGetter);
    this.goalAction = this.createBelongsToAccessorFor(
      'goalAction',
      goalActionRepositoryGetter,
    );
    this.registerInclusionResolver('user', this.user.inclusionResolver);
    this.registerInclusionResolver('goal', this.goal.inclusionResolver);
    this.registerInclusionResolver(
      'goalAction',
      this.goalAction.inclusionResolver,
    );
  }
}
