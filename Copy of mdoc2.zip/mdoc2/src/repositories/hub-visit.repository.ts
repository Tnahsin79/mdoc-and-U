import {
  BelongsToAccessor,
  DefaultCrudRepository,
  HasManyRepositoryFactory,
  repository,
} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Getter, inject} from '@loopback/core';
import { ActionPlan, Coach, DependentList, HubUserFeedback, HubVisit, HubVisitRelations, NudgeHubs, Users} from '../models';
import { UsersRepository } from './users.repository';
import { ActionPlanRepository } from './action-plan.repository';
import { CoachRepository } from './coach.repository';
import { DependentListRepository } from './dependent-list.repository';
import { HubUserFeedbackRepository } from './hub-user-feedback.repository';
import { NudgeHubsRepository } from './nudge-hubs.repository';

export class HubVisitRepository extends DefaultCrudRepository<
  HubVisit,
  typeof HubVisit.prototype.id,
  HubVisitRelations
> {
  public readonly user: BelongsToAccessor<Users, typeof Users.prototype.id>;
  public readonly coach: BelongsToAccessor<Coach, typeof Coach.prototype.id>;
  public readonly nudgeHub: BelongsToAccessor<NudgeHubs, typeof NudgeHubs.prototype.id>;
  public readonly actionPlan: BelongsToAccessor<ActionPlan, typeof ActionPlan.prototype.id>;
  public readonly hubUserFeedbacks: HasManyRepositoryFactory<HubUserFeedback, typeof HubUserFeedback.prototype.id>;
  public readonly dependentList: HasManyRepositoryFactory<DependentList, typeof DependentList.prototype.id>;
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('UsersRepository')
    userRepositoryGetter: Getter<UsersRepository>,
    @repository.getter('ActionPlanRepository')
    actionPlanRepositoryGetter: Getter<ActionPlanRepository>,
    @repository.getter('CoachRepository')
    coachRepositoryGetter: Getter<CoachRepository>,
    @repository.getter('NudgeHubsRepository')
    nudgeHubsRepositoryGetter: Getter<NudgeHubsRepository>,
    @repository.getter('HubUserFeedbackRepository') 
    public hubUserFeedbackRepositoryGetter: Getter<HubUserFeedbackRepository>,
    @repository.getter('DependentListRepository') 
    public dependentListRepositoryGetter: Getter<DependentListRepository>,
  ) {
    super(HubVisit, dataSource);
    this.user = this.createBelongsToAccessorFor('user', userRepositoryGetter);
    this.actionPlan = this.createBelongsToAccessorFor('actionPlan', actionPlanRepositoryGetter);
    this.coach = this.createBelongsToAccessorFor('coach', coachRepositoryGetter);
    this.nudgeHub = this.createBelongsToAccessorFor('nudgeHub', nudgeHubsRepositoryGetter);
    this.hubUserFeedbacks = this.createHasManyRepositoryFactoryFor('hubUserFeedbacks', hubUserFeedbackRepositoryGetter);
    this.dependentList = this.createHasManyRepositoryFactoryFor('dependentList', dependentListRepositoryGetter);

    this.registerInclusionResolver('user', this.user.inclusionResolver);
    this.registerInclusionResolver('actionPlan', this.actionPlan.inclusionResolver);
    this.registerInclusionResolver('coach', this.coach.inclusionResolver);
    this.registerInclusionResolver('nudgeHub', this.nudgeHub.inclusionResolver);
    this.registerInclusionResolver('hubUserFeedbacks', this.hubUserFeedbacks.inclusionResolver);
    this.registerInclusionResolver('dependentList', this.dependentList.inclusionResolver);
  }
}
