import {
  repository,
  BelongsToAccessor,
  DefaultCrudRepository,
} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Getter, inject} from '@loopback/core';
import {UsersRepository} from './users.repository';
import {BlogPostRepository} from './blog-post.repository';
import {BlogPost, ReportPost, ReportPostRelations, Users} from '../models';

export class ReportPostRepository extends DefaultCrudRepository<
  ReportPost,
  typeof ReportPost.prototype.id,
  ReportPostRelations
> {
  public readonly blogPost: BelongsToAccessor<
    BlogPost,
    typeof BlogPost.prototype.id
  >;
  public readonly user: BelongsToAccessor<Users, typeof Users.prototype.id>;

  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('BlogPostRepository')
    PostRepositoryGetter: Getter<BlogPostRepository>,
    @repository.getter('UsersRepository')
    UsersRepositoryGetter: Getter<UsersRepository>,
  ) {
    super(ReportPost, dataSource);
    this.blogPost = this.createBelongsToAccessorFor(
      'blogPost',
      PostRepositoryGetter,
    );
    this.user = this.createBelongsToAccessorFor('user', UsersRepositoryGetter);
    this.registerInclusionResolver('blogPost', this.blogPost.inclusionResolver);
    this.registerInclusionResolver('user', this.user.inclusionResolver);
  }
}
