import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Waistgoal, WaistgoalRelations} from '../models';

export class WaistgoalRepository extends DefaultCrudRepository<
  Waistgoal,
  typeof Waistgoal.prototype.id,
  WaistgoalRelations
> {
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
  ) {
    super(Waistgoal, dataSource);
  }
}
