import {
  CoachSpeciality,
  CoachTypeSpeciality,
  Speciality,
  SpecialityRelations,
} from '../models';
import {
  DefaultCrudRepository,
  HasManyRepositoryFactory,
  repository,
} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Getter, inject} from '@loopback/core';
import {CoachSpecialityRepository} from './coach-speciality.repository';
import {CoachTypeSpecialityRepository} from './coach-type-speciality.repository';

export class SpecialityRepository extends DefaultCrudRepository<
  Speciality,
  typeof Speciality.prototype.id,
  SpecialityRelations
> {
  public readonly coachTypeSpeciality: HasManyRepositoryFactory<
    CoachTypeSpeciality,
    typeof CoachTypeSpeciality.prototype.id
  >;
  public readonly coaches: HasManyRepositoryFactory<
    CoachSpeciality,
    typeof CoachSpeciality.prototype.id
  >;
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('CoachTypeSpecialityRepository')
    coachTypeSpecialityRepositoryGetter: Getter<CoachTypeSpecialityRepository>,
    @repository.getter('CoachSpecialityRepository')
    coachSpecialityRepositoryGetter: Getter<CoachSpecialityRepository>,
  ) {
    super(Speciality, dataSource);
    this.coachTypeSpeciality = this.createHasManyRepositoryFactoryFor(
      'coachTypeSpeciality',
      coachTypeSpecialityRepositoryGetter,
    );

    this.registerInclusionResolver(
      'coachTypeSpeciality',
      this.coachTypeSpeciality.inclusionResolver,
    );

    this.coaches = this.createHasManyRepositoryFactoryFor(
      'coaches',
      coachSpecialityRepositoryGetter,
    );

    this.registerInclusionResolver(
      'coaches',
      this.coaches.inclusionResolver,
    );
  }
}
