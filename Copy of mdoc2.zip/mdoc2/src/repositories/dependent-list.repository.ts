import {
  BelongsToAccessor,
  DefaultCrudRepository,
  repository,
} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Getter, inject} from '@loopback/core';
import { DependentList, DependentListRelations, Users} from '../models';
import { UsersRepository } from './users.repository';

export class DependentListRepository extends DefaultCrudRepository<
  DependentList,
  typeof DependentList.prototype.id,
  DependentListRelations
> {
  public readonly user: BelongsToAccessor<Users, typeof Users.prototype.id>;
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('UsersRepository')
    userRepositoryGetter: Getter<UsersRepository>,
  ) {
    super(DependentList, dataSource);
    this.user = this.createBelongsToAccessorFor('user', userRepositoryGetter);

    this.registerInclusionResolver('user', this.user.inclusionResolver);
  }
}
