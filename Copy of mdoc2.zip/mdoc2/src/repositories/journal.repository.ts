import { DefaultCrudRepository, BelongsToAccessor, repository } from '@loopback/repository';
import { Journal, JournalRelations, Users } from '../models';
import { DbDataSource } from '../datasources';
import { inject, Getter } from '@loopback/core';
import { UsersRepository } from './users.repository';

export class JournalRepository extends DefaultCrudRepository<Journal, typeof Journal.prototype.id, JournalRelations> {
  public readonly user: BelongsToAccessor<Users, typeof Users.prototype.id>;
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('UsersRepository') public usersRepositoryGitter: Getter<UsersRepository>,
  ) {
    super(Journal, dataSource);

    this.user = this.createBelongsToAccessorFor('user', usersRepositoryGitter);

    this.registerInclusionResolver('user', this.user.inclusionResolver);

    (this.modelClass as any).observe('persist', async (ctx: any) => {
      ctx.data.modified = new Date();
    });
  }
}
