import {
  repository,
  BelongsToAccessor,
  DefaultCrudRepository,
} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Getter, inject} from '@loopback/core';
import {GoalRepository} from './goal.repository';
import {CoachRepository} from './coach.repository';
import {UsersRepository} from './users.repository';
import {Coach, Goal, GoalAction, GoalActionRelations, Users} from '../models';

export class GoalActionRepository extends DefaultCrudRepository<
  GoalAction,
  typeof GoalAction.prototype.id,
  GoalActionRelations
> {
  public readonly user: BelongsToAccessor<Users, typeof Users.prototype.id>;
  public readonly goal: BelongsToAccessor<Goal, typeof Goal.prototype.id>;
  public readonly coach: BelongsToAccessor<Coach, typeof Coach.prototype.id>;
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('UsersRepository')
    usersRepositoryGetter: Getter<UsersRepository>,
    @repository.getter('GoalRepository')
    goalRepositoryGetter: Getter<GoalRepository>,
    @repository.getter('CoachRepository')
    coachRepositoryGetter: Getter<CoachRepository>,
  ) {
    super(GoalAction, dataSource);
    this.user = this.createBelongsToAccessorFor('user', usersRepositoryGetter);
    this.registerInclusionResolver('user', this.user.inclusionResolver);
    this.goal = this.createBelongsToAccessorFor('goal', goalRepositoryGetter);
    this.coach = this.createBelongsToAccessorFor(
      'coach',
      coachRepositoryGetter,
    );
    this.registerInclusionResolver('user', this.user.inclusionResolver);
    this.registerInclusionResolver('goal', this.goal.inclusionResolver);
    this.registerInclusionResolver('coach', this.coach.inclusionResolver);
  }
}
