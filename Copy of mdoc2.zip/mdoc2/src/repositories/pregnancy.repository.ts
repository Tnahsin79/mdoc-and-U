import { DefaultCrudRepository, BelongsToAccessor, repository } from '@loopback/repository';
import { Pregnancy, PregnancyRelations, HealthQuestion } from '../models';
import { DbDataSource } from '../datasources';
import { inject, Getter } from '@loopback/core';

export class PregnancyRepository extends DefaultCrudRepository<Pregnancy, typeof Pregnancy.prototype.id, PregnancyRelations> {
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
  ) {
    super(Pregnancy, dataSource);


    (this.modelClass as any).observe('persist', async (ctx: any) => {
      ctx.data.modified = new Date();
    });
  }
}
