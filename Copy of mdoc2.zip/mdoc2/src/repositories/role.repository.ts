import {
  DefaultCrudRepository,
  HasManyRepositoryFactory,
  repository,
} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Getter, inject} from '@loopback/core';
import {AdminRole, Role, RolePrivilege, RoleRelations} from '../models';
import {AdminRoleRepository} from './admin-role.repository';
import { RolePrivilegeRepository } from './role-privilege.repository';

export class RoleRepository extends DefaultCrudRepository<
  Role,
  typeof Role.prototype.id,
  RoleRelations
> {
  public readonly admins: HasManyRepositoryFactory<
    AdminRole,
    typeof AdminRole.prototype.id
  >;
  public readonly rolePrivileges: HasManyRepositoryFactory<
    RolePrivilege,
    typeof RolePrivilege.prototype.id>;
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('AdminRoleRepository') public adminRoleRepositoryGetter: Getter<AdminRoleRepository>,
    @repository.getter('RolePrivilegeRepository') public rolePrivilegeRepositoryGetter: Getter<RolePrivilegeRepository>,
  ) {
    super(Role, dataSource);
    this.admins = this.createHasManyRepositoryFactoryFor(
      'admins',
      adminRoleRepositoryGetter,
    );
    this.registerInclusionResolver('admins', this.admins.inclusionResolver);
    this.rolePrivileges = this.createHasManyRepositoryFactoryFor(
      'rolePrivileges',
      rolePrivilegeRepositoryGetter,
    );
    this.registerInclusionResolver('rolePrivileges', this.rolePrivileges.inclusionResolver);
  }
}
