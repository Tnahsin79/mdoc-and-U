import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {MyAssessmentsInformation, MyAssessmentsInformationRelations} from '../models';

export class MyAssessmentsInformationRepository extends DefaultCrudRepository<
  MyAssessmentsInformation,
  typeof MyAssessmentsInformation.prototype.id,
  MyAssessmentsInformationRelations
> {
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
  ) {
    super(MyAssessmentsInformation, dataSource);
  }
}
