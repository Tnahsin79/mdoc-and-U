import {inject, Getter} from '@loopback/core';
import {ChatRoom, Coach, Users} from '../models';
import {ChatRoomUser} from '../models/chat-room-user.model';
import {
  BelongsToAccessor,
  DefaultCrudRepository,
  repository,
} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {UsersRepository} from './users.repository';
import {ChatRoomRepository} from './chat-room.repository';
import {CoachRepository} from './coach.repository';

export class ChatRoomUserRepository extends DefaultCrudRepository<
  ChatRoomUser,
  typeof ChatRoomUser.prototype.id
> {
  public readonly user: BelongsToAccessor<Users, typeof Users.prototype.id>;
  public readonly coach: BelongsToAccessor<Coach, typeof Coach.prototype.id>;
  public readonly chatRoom: BelongsToAccessor<
    ChatRoom,
    typeof ChatRoom.prototype.id
  >;

  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('UsersRepository')
    public usersRepositoryGetter: Getter<UsersRepository>,
    @repository.getter('CoachRepository')
    public coachRepositoryGetter: Getter<CoachRepository>,
    @repository.getter('ChatRoomRepository')
    public chatRoomRepositoryGetter: Getter<ChatRoomRepository>,
  ) {
    super(ChatRoomUser, dataSource);

    this.user = this.createBelongsToAccessorFor('user', usersRepositoryGetter);
    this.coach = this.createBelongsToAccessorFor(
      'coach',
      coachRepositoryGetter,
    );
    this.chatRoom = this.createBelongsToAccessorFor(
      'chatRoom',
      chatRoomRepositoryGetter,
    );
    this.registerInclusionResolver('user', this.user.inclusionResolver);
    this.registerInclusionResolver('coach', this.coach.inclusionResolver);
    this.registerInclusionResolver('chatRoom', this.chatRoom.inclusionResolver);
  }
}
