import { DefaultCrudRepository } from '@loopback/repository';
import { HealthQuestion, HealthQuestionRelations } from '../models';
import { DbDataSource } from '../datasources';
import { inject } from '@loopback/core';

export class HealthQuestionRepository extends DefaultCrudRepository<
  HealthQuestion,
  typeof HealthQuestion.prototype.id,
  HealthQuestionRelations
  > {
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
  ) {
    super(HealthQuestion, dataSource);

    // (this.modelClass as any).observe('persist', async (ctx: any) => {
    //   ctx.data.modified = new Date();
    // });
  }
}
