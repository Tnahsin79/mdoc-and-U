import {DefaultCrudRepository} from '@loopback/repository';
import {Lab, LabRelations} from '../models';
import {DbDataSource} from '../datasources';
import {inject} from '@loopback/core';

export class LabRepository extends DefaultCrudRepository<
  Lab,
  typeof Lab.prototype.id,
  LabRelations
> {
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
  ) {
    super(Lab, dataSource);
  }
}
