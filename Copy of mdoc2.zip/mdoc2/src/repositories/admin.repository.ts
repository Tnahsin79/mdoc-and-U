import {BelongsToAccessor, DefaultCrudRepository, HasManyRepository, HasManyRepositoryFactory, repository} from '@loopback/repository';
import {Admin, AdminRelations, AdminRole, Role} from '../models';
import {DbDataSource} from '../datasources';
import {inject, Getter} from '@loopback/core';
import { RoleRepository } from './role.repository';
import { AdminRoleRepository } from './admin-role.repository';

export class AdminRepository extends DefaultCrudRepository<
  Admin,
  typeof Admin.prototype.id,
  AdminRelations
> {
  public readonly roles: HasManyRepositoryFactory<AdminRole, typeof AdminRole.prototype.id>;
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('AdminRoleRepository') public adminRoleRepositoryGetter: Getter<AdminRoleRepository>,
  ) {
    super(Admin, dataSource);
    this.roles = this.createHasManyRepositoryFactoryFor('roles', adminRoleRepositoryGetter);
    this.registerInclusionResolver('roles', this.roles.inclusionResolver);
  }
}
