import {
    BelongsToAccessor,
    DefaultCrudRepository,
    repository,
  } from '@loopback/repository';
  import {DbDataSource} from '../datasources';
  import {Getter, inject} from '@loopback/core';
  import {UsersRepository} from './users.repository';
  import {CoachRepository} from './coach.repository';
  import { ConsultRepository } from './consult.repository';
  import {Coach, Users, Temperature, TemperatureRelations, Consult} from '../models';
  
  export class TemperatureRepository extends DefaultCrudRepository<
    Temperature,
    typeof Temperature.prototype.id,
    TemperatureRelations
  > {
    public readonly user: BelongsToAccessor<Users, typeof Users.prototype.id>;
    public readonly coach: BelongsToAccessor<Coach, typeof Coach.prototype.id>;
    public readonly consult: BelongsToAccessor<Consult, typeof Consult.prototype.id>;
    constructor(
      @inject('datasources.db') dataSource: DbDataSource,
      @repository.getter('UsersRepository')
      usersRepositoryGetter: Getter<UsersRepository>,
      @repository.getter('CoachRepository')
      coachRepositoryGetter: Getter<CoachRepository>,
      @repository.getter('ConsultRepository')
      consultRepositoryGetter: Getter<ConsultRepository>,
    ) {
      super(Temperature, dataSource);
      this.user = this.createBelongsToAccessorFor('user', usersRepositoryGetter);
      this.registerInclusionResolver('user', this.user.inclusionResolver);
      this.coach = this.createBelongsToAccessorFor(
        'coach',
        coachRepositoryGetter,
      );
      this.registerInclusionResolver('coach', this.coach.inclusionResolver);
      this.consult = this.createBelongsToAccessorFor(
        'consult',
        consultRepositoryGetter,
      );
      this.registerInclusionResolver('consult', this.consult.inclusionResolver);
    }
  }
  