import {
  Users,
  Feedback,
  HubVisit,
  UserFeedback,
  UserFeedbackAnswer,
  UserFeedbackRelations,
} from '../models';
import {
  repository,
  BelongsToAccessor,
  DefaultCrudRepository,
  HasManyRepositoryFactory,
} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Getter, inject} from '@loopback/core';
import {UsersRepository} from './users.repository';
import {FeedbackRepository} from './feedback.repository';
import {HubVisitRepository} from './hub-visit.repository';
import {UserFeedbackAnswerRepository} from './user-feedback-answer.repository';

export class UserFeedbackRepository extends DefaultCrudRepository<
  UserFeedback,
  typeof UserFeedback.prototype.id,
  UserFeedbackRelations
> {
  public readonly user: BelongsToAccessor<Users, typeof Users.prototype.id>;
  public readonly feedback: BelongsToAccessor<
    Feedback,
    typeof Feedback.prototype.id
  >;
  public readonly hubVisit: BelongsToAccessor<
    HubVisit,
    typeof HubVisit.prototype.id
  >;
  public readonly userFeedbackAnswers: HasManyRepositoryFactory<
    UserFeedbackAnswer,
    typeof UserFeedbackAnswer.prototype.id
  >;
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('UsersRepository')
    userRepositoryGetter: Getter<UsersRepository>,
    @repository.getter('FeedbackRepository')
    feedbackRepositoryGetter: Getter<FeedbackRepository>,
    @repository.getter('HubVisitRepository')
    hubVisitRepositoryGetter: Getter<HubVisitRepository>,
    @repository.getter('UserFeedbackAnswerRepository')
    userFeedbackAnswerRepository: Getter<UserFeedbackAnswerRepository>,
  ) {
    super(UserFeedback, dataSource);
    this.user = this.createBelongsToAccessorFor('user', userRepositoryGetter);
    this.feedback = this.createBelongsToAccessorFor(
      'feedback',
      feedbackRepositoryGetter,
    );
    this.hubVisit = this.createBelongsToAccessorFor(
      'hubVisit',
      hubVisitRepositoryGetter,
    );
    this.userFeedbackAnswers = this.createHasManyRepositoryFactoryFor(
      'userFeedbackAnswers',
      userFeedbackAnswerRepository,
    );
    this.registerInclusionResolver('user', this.user.inclusionResolver);
    this.registerInclusionResolver('feedback', this.feedback.inclusionResolver);
    this.registerInclusionResolver('hubVisit', this.hubVisit.inclusionResolver);
    this.registerInclusionResolver(
      'userFeedbackAnswers',
      this.userFeedbackAnswers.inclusionResolver,
    );
  }
}
