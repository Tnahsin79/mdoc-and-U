import {
  Coach,
  Users,
  Weight,
  Consult,
  HubVisit,
  GoalAction,
  WeightRelations,
} from '../models';
import {
  repository,
  BelongsToAccessor,
  DefaultCrudRepository,
} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Getter, inject} from '@loopback/core';
import {UsersRepository} from './users.repository';
import {CoachRepository} from './coach.repository';
import {ConsultRepository} from './consult.repository';
import {HubVisitRepository} from './hub-visit.repository';
import {GoalActionRepository} from './goal-actions.repository';

export class WeightRepository extends DefaultCrudRepository<
  Weight,
  typeof Weight.prototype.id,
  WeightRelations
> {
  public readonly user: BelongsToAccessor<Users, typeof Users.prototype.id>;
  public readonly coach: BelongsToAccessor<Coach, typeof Coach.prototype.id>;
  public readonly consult: BelongsToAccessor<
    Consult,
    typeof Consult.prototype.id
  >;
  public readonly goalAction: BelongsToAccessor<
    GoalAction,
    typeof GoalAction.prototype.id
  >;
  public readonly hubVisit: BelongsToAccessor<
    HubVisit,
    typeof HubVisit.prototype.id
  >;

  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('UsersRepository')
    usersRepositoryGetter: Getter<UsersRepository>,
    @repository.getter('CoachRepository')
    coachRepositoryGetter: Getter<CoachRepository>,
    @repository.getter('ConsultRepository')
    consultRepositoryGetter: Getter<ConsultRepository>,
    @repository.getter('GoalActionRepository')
    goalActionRepositoryGetter: Getter<GoalActionRepository>,
    @repository.getter('HubVisitRepository')
    hubVisitRepositoryGetter: Getter<HubVisitRepository>,
  ) {
    super(Weight, dataSource);
    this.user = this.createBelongsToAccessorFor('user', usersRepositoryGetter);
    this.registerInclusionResolver('user', this.user.inclusionResolver);
    this.coach = this.createBelongsToAccessorFor(
      'coach',
      coachRepositoryGetter,
    );
    this.registerInclusionResolver('coach', this.coach.inclusionResolver);
    this.consult = this.createBelongsToAccessorFor(
      'consult',
      consultRepositoryGetter,
    );
    this.registerInclusionResolver('consult', this.consult.inclusionResolver);
    this.goalAction = this.createBelongsToAccessorFor(
      'goalAction',
      goalActionRepositoryGetter,
    );
    this.registerInclusionResolver(
      'goalAction',
      this.goalAction.inclusionResolver,
    );
    this.hubVisit = this.createBelongsToAccessorFor(
      'hubVisit',
      hubVisitRepositoryGetter,
    );
    this.registerInclusionResolver('hubVisit', this.hubVisit.inclusionResolver);
  }
}
