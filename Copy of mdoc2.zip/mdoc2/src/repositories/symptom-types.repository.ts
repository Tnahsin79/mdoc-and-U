import { DefaultCrudRepository } from '@loopback/repository';
import { SymptomTypes, SymptomTypesRelations } from '../models';
import { DbDataSource } from '../datasources';
import { inject } from '@loopback/core';

export class SymptomTypesRepository extends DefaultCrudRepository<
  SymptomTypes,
  typeof SymptomTypes.prototype.id,
  SymptomTypesRelations
  > {
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
  ) {
    super(SymptomTypes, dataSource);
  }
}
