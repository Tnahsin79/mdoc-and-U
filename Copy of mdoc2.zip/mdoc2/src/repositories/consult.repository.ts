import {
  BelongsToAccessor,
  DefaultCrudRepository,
  HasOneRepositoryFactory,
  repository,
} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Getter, inject} from '@loopback/core';
import {UsersRepository} from './users.repository';
import {CoachRepository} from './coach.repository';
import {
  Coach,
  Users,
  Consult,
  ConsultRelations,
  Partner,
  Height,
  Cholestrol,
  Weight,
  BloodPressure,
  Hbaic,
  EyeExamination,
  Temperature,
  Exercise,
  Note,
  BloodSugar,
  MedicationPassport,
  HubVisit,
} from '../models';
import {PartnerRepository} from './partner.repository';
import {HeightRepository} from './height.repository';
import {WeightRepository} from './weight.repository';
import {CholestrolRepository} from './cholestrol.repository';
import {BloodPressureRepository} from './blood-pressure.repository';
import {HbaicRepository} from './hbaic.repository';
import {EyeExaminationRepository} from './eye-examination.repository';
import {TemperatureRepository} from './temperature.repository';
import {ExerciseRepository} from './exercise.repository';
import {NoteRepository} from './note.repository';
import {BloodSugarRepository} from './blood-sugar.repository';
import {MedicationPassportRepository} from './medication-passport.repository';
import { HubVisitRepository } from './hub-visit.repository';

export class ConsultRepository extends DefaultCrudRepository<
  Consult,
  typeof Consult.prototype.id,
  ConsultRelations
> {
  public readonly user: BelongsToAccessor<Users, typeof Users.prototype.id>;
  public readonly coach: BelongsToAccessor<Coach, typeof Coach.prototype.id>;
  public readonly partner: BelongsToAccessor<
    Partner,
    typeof Partner.prototype.id
  >;
  public readonly hubVisit: BelongsToAccessor<
    HubVisit,
    typeof HubVisit.prototype.id
  >;
  public readonly changeStages: HasOneRepositoryFactory<
    Height,
    typeof Height.prototype.id
  >;
  public readonly bloodPressure: HasOneRepositoryFactory<
    BloodPressure,
    typeof BloodPressure.prototype.id
  >;
  public readonly bloodSugar: HasOneRepositoryFactory<
    BloodSugar,
    typeof BloodSugar.prototype.id
  >;
  public readonly hbaic: HasOneRepositoryFactory<
    Hbaic,
    typeof Hbaic.prototype.id
  >;
  public readonly eyeExamination: HasOneRepositoryFactory<
    EyeExamination,
    typeof EyeExamination.prototype.id
  >;
  public readonly temperature: HasOneRepositoryFactory<
    Temperature,
    typeof Temperature.prototype.id
  >;
  public readonly exercise: HasOneRepositoryFactory<
    Exercise,
    typeof Exercise.prototype.id
  >;
  public readonly note: HasOneRepositoryFactory<Note, typeof Note.prototype.id>;
  public readonly cholestrol: HasOneRepositoryFactory<
    Cholestrol,
    typeof Cholestrol.prototype.id
  >;
  public readonly weight: HasOneRepositoryFactory<
    Weight,
    typeof Weight.prototype.id
  >;
  public readonly height: HasOneRepositoryFactory<
    Height,
    typeof Height.prototype.id
  >;
  public readonly medication: HasOneRepositoryFactory<
    MedicationPassport,
    typeof MedicationPassport.prototype.id
  >;

  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('UsersRepository')
    usersRepositoryGetter: Getter<UsersRepository>,
    @repository.getter('CoachRepository')
    coachRepositoryGetter: Getter<CoachRepository>,
    @repository.getter('PartnerRepository')
    partnerRepositoryGetter: Getter<PartnerRepository>,
    @repository.getter('HubVisitRepository')
    hubVisitRepositoryGetter: Getter<HubVisitRepository>,
    @repository.getter('HeightRepository')
    heightRepositoryGetter: Getter<HeightRepository>,
    @repository.getter('WeightRepository')
    weightRepositoryGetter: Getter<WeightRepository>,
    @repository.getter('BloodPressureRepository')
    bloodPressureRepositoryGetter: Getter<BloodPressureRepository>,
    @repository.getter('HbaicRepository')
    hbaicRepositoryGetter: Getter<HbaicRepository>,
    @repository.getter('EyeExaminationRepository')
    eyeExaminationRepositoryGetter: Getter<EyeExaminationRepository>,
    @repository.getter('TemperatureRepository')
    temperatureRepositoryGetter: Getter<TemperatureRepository>,
    @repository.getter('ExerciseRepository')
    exerciseRepositoryGetter: Getter<ExerciseRepository>,
    @repository.getter('NoteRepository')
    noteRepositoryGetter: Getter<NoteRepository>,
    @repository.getter('CholestrolRepository')
    cholestrolRepositoryGetter: Getter<CholestrolRepository>,
    @repository.getter('BloodSugarRepository')
    bloodSugarRepositoryGetter: Getter<BloodSugarRepository>,
    @repository.getter('MedicationPassportRepository')
    medicationPassportRepositoryGetter: Getter<MedicationPassportRepository>,
  ) {
    super(Consult, dataSource);
    this.user = this.createBelongsToAccessorFor('user', usersRepositoryGetter);
    this.registerInclusionResolver('user', this.user.inclusionResolver);
    this.medication = this.createHasOneRepositoryFactoryFor(
      'medication',
      medicationPassportRepositoryGetter,
    );
    this.registerInclusionResolver(
      'medication',
      this.medication.inclusionResolver,
    );
    this.partner = this.createBelongsToAccessorFor(
      'partner',
      partnerRepositoryGetter,
    );
    this.registerInclusionResolver('partner', this.partner.inclusionResolver);
    this.hubVisit = this.createBelongsToAccessorFor(
      'hubVisit',
      hubVisitRepositoryGetter,
    );
    this.registerInclusionResolver('hubVisit', this.hubVisit.inclusionResolver);
    this.coach = this.createBelongsToAccessorFor(
      'coach',
      coachRepositoryGetter,
    );
    this.registerInclusionResolver('coach', this.coach.inclusionResolver);
    this.height = this.createHasOneRepositoryFactoryFor(
      'height',
      heightRepositoryGetter,
    );
    this.registerInclusionResolver('height', this.height.inclusionResolver);
    this.weight = this.createHasOneRepositoryFactoryFor(
      'weight',
      weightRepositoryGetter,
    );
    this.registerInclusionResolver('weight', this.weight.inclusionResolver);
    this.bloodPressure = this.createHasOneRepositoryFactoryFor(
      'bloodPressure',
      bloodPressureRepositoryGetter,
    );
    this.registerInclusionResolver(
      'bloodPressure',
      this.bloodPressure.inclusionResolver,
    );
    this.bloodSugar = this.createHasOneRepositoryFactoryFor(
      'bloodSugar',
      bloodSugarRepositoryGetter,
    );
    this.registerInclusionResolver(
      'bloodSugar',
      this.bloodSugar.inclusionResolver,
    );
    this.hbaic = this.createHasOneRepositoryFactoryFor(
      'hbaic',
      hbaicRepositoryGetter,
    );
    this.registerInclusionResolver('hbaic', this.hbaic.inclusionResolver);
    this.eyeExamination = this.createHasOneRepositoryFactoryFor(
      'eyeExamination',
      eyeExaminationRepositoryGetter,
    );
    this.registerInclusionResolver(
      'eyeExamination',
      this.eyeExamination.inclusionResolver,
    );
    this.temperature = this.createHasOneRepositoryFactoryFor(
      'temperature',
      temperatureRepositoryGetter,
    );
    this.registerInclusionResolver(
      'temperature',
      this.temperature.inclusionResolver,
    );
    this.exercise = this.createHasOneRepositoryFactoryFor(
      'exercise',
      exerciseRepositoryGetter,
    );
    this.registerInclusionResolver('exercise', this.exercise.inclusionResolver);
    this.note = this.createHasOneRepositoryFactoryFor(
      'note',
      noteRepositoryGetter,
    );
    this.registerInclusionResolver('note', this.note.inclusionResolver);
    this.cholestrol = this.createHasOneRepositoryFactoryFor(
      'cholestrol',
      cholestrolRepositoryGetter,
    );
    this.registerInclusionResolver(
      'cholestrol',
      this.cholestrol.inclusionResolver,
    );
  }
}
