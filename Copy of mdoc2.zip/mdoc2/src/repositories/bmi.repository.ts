import {
  repository,
  BelongsToAccessor,
  DefaultCrudRepository,
} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Getter, inject} from '@loopback/core';
import {UsersRepository} from './users.repository';
import {CoachRepository} from './coach.repository';
import {WeightRepository} from './weight.repository';
import {HeightRepository} from './height.repository';
import {Coach, Users, Bmi, BmiRelations, Height, Weight} from '../models';

export class BmiRepository extends DefaultCrudRepository<
  Bmi,
  typeof Bmi.prototype.id,
  BmiRelations
> {
  public readonly user: BelongsToAccessor<Users, typeof Users.prototype.id>;
  public readonly coach: BelongsToAccessor<Coach, typeof Coach.prototype.id>;
  public readonly weight: BelongsToAccessor<Weight, typeof Weight.prototype.id>;
  public readonly height: BelongsToAccessor<Height, typeof Height.prototype.id>;
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('UsersRepository')
    usersRepositoryGetter: Getter<UsersRepository>,
    @repository.getter('CoachRepository')
    coachRepositoryGetter: Getter<CoachRepository>,
    @repository.getter('WeightRepository')
    weightRepositoryGetter: Getter<WeightRepository>,
    @repository.getter('HeightRepository')
    heightRepositoryGetter: Getter<HeightRepository>,
  ) {
    super(Bmi, dataSource);
    this.user = this.createBelongsToAccessorFor('user', usersRepositoryGetter);
    this.coach = this.createBelongsToAccessorFor(
      'coach',
      coachRepositoryGetter,
    );
    this.weight = this.createBelongsToAccessorFor(
      'weight',
      weightRepositoryGetter,
    );
    this.height = this.createBelongsToAccessorFor(
      'height',
      heightRepositoryGetter,
    );
    this.registerInclusionResolver('user', this.user.inclusionResolver);
    this.registerInclusionResolver('coach', this.coach.inclusionResolver);
    this.registerInclusionResolver('weight', this.weight.inclusionResolver);
    this.registerInclusionResolver('height', this.height.inclusionResolver);
  }
}
