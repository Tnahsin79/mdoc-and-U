import {
  Admin,
  Coach,
  Users,
  Feedback,
  Referral,
  HubVisit,
  Speciality,
  ReferralRelations,
} from '../models';
import {
  repository,
  BelongsToAccessor,
  DefaultCrudRepository,
} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Getter, inject} from '@loopback/core';
import {UsersRepository} from './users.repository';
import {CoachRepository} from './coach.repository';
import {AdminRepository} from './admin.repository';
import { HubVisitRepository } from './hub-visit.repository';
import {SpecialityRepository} from './speciality.repository';

export class ReferralRepository extends DefaultCrudRepository<
  Referral,
  typeof Referral.prototype.id,
  ReferralRelations
> {
  public readonly senderCoach: BelongsToAccessor<
    Coach,
    typeof Coach.prototype.id
  >;
  public readonly receiverCoach: BelongsToAccessor<
    Coach,
    typeof Coach.prototype.id
  >;
  public readonly approvedBy: BelongsToAccessor<
    Admin,
    typeof Admin.prototype.id
  >;
  public readonly admin: BelongsToAccessor<Admin, typeof Admin.prototype.id>;
  public readonly feedback: BelongsToAccessor<
    Feedback,
    typeof Feedback.prototype.id
  >;
  public readonly user: BelongsToAccessor<Users, typeof Users.prototype.id>;

  public readonly specialty: BelongsToAccessor<
    Speciality,
    typeof Speciality.prototype.id
  >;
  public readonly hubVisit: BelongsToAccessor<
    HubVisit,
    typeof HubVisit.prototype.id
  >;

  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('CoachRepository')
    public coachRepositoryGetter: Getter<CoachRepository>,
    @repository.getter('AdminRepository')
    public adminRepositoryGetter: Getter<AdminRepository>,
    @repository.getter('UsersRepository')
    public userRepositoryGetter: Getter<UsersRepository>,
    @repository.getter('SpecialityRepository')
    public specialityRepositoryGetter: Getter<SpecialityRepository>,
    @repository.getter('HubVisitRepository')
    hubVisitRepositoryGetter: Getter<HubVisitRepository>,
  ) {
    super(Referral, dataSource);

    this.senderCoach = this.createBelongsToAccessorFor(
      'senderCoach',
      coachRepositoryGetter,
    );
    this.receiverCoach = this.createBelongsToAccessorFor(
      'receiverCoach',
      coachRepositoryGetter,
    );
    this.user = this.createBelongsToAccessorFor('user', userRepositoryGetter);
    this.approvedBy = this.createBelongsToAccessorFor(
      'approvedBy',
      adminRepositoryGetter,
    );
    this.admin = this.createBelongsToAccessorFor(
      'admin',
      adminRepositoryGetter,
    );
    this.specialty = this.createBelongsToAccessorFor(
      'specialty',
      specialityRepositoryGetter,
    );

    this.registerInclusionResolver(
      'senderCoach',
      this.senderCoach.inclusionResolver,
    );
    this.registerInclusionResolver(
      'receiverCoach',
      this.receiverCoach.inclusionResolver,
    );
    this.registerInclusionResolver(
      'approvedBy',
      this.approvedBy.inclusionResolver,
    );
    this.registerInclusionResolver('admin', this.admin.inclusionResolver);
    this.registerInclusionResolver(
      'specialty',
      this.specialty.inclusionResolver,
    );
    this.registerInclusionResolver('user', this.user.inclusionResolver);
    this.hubVisit = this.createBelongsToAccessorFor(
      'hubVisit',
      hubVisitRepositoryGetter,
    );
    this.registerInclusionResolver('hubVisit', this.hubVisit.inclusionResolver);
  }
}
