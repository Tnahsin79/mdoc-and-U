import {
  DefaultCrudRepository,
  HasManyRepositoryFactory,
  repository,
} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Getter, inject} from '@loopback/core';
import {UserDiseaseRepository} from './user-disease.repository';
import {UserSubscriptionsRepository} from './user-subscriptions.repository';
import {UserDisease, UserSubscriptions, Users, UsersRelations} from '../models';

export class UsersRepository extends DefaultCrudRepository<
  Users,
  typeof Users.prototype.id,
  UsersRelations
> {
  public readonly subscriptions: HasManyRepositoryFactory<
    UserSubscriptions,
    typeof UserSubscriptions.prototype.id
  >;

  public readonly diseases: HasManyRepositoryFactory<
    UserDisease,
    typeof UserDisease.prototype.id
  >;

  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('UserSubscriptionsRepository')
    subscriptionsRepositoryGetter: Getter<UserSubscriptionsRepository>,
    @repository.getter('UserDiseaseRepository')
    userDiseaseRepositoryGetter: Getter<UserDiseaseRepository>,
  ) {
    super(Users, dataSource);

    this.subscriptions = this.createHasManyRepositoryFactoryFor(
      'subscriptions',
      subscriptionsRepositoryGetter,
    );
    this.registerInclusionResolver(
      'subscriptions',
      this.subscriptions.inclusionResolver,
    );

    this.diseases = this.createHasManyRepositoryFactoryFor(
      'diseases',
      userDiseaseRepositoryGetter,
    );
    this.registerInclusionResolver('diseases', this.diseases.inclusionResolver);

    (this.modelClass as any).observe('persist', async (ctx: any) => {
      ctx.data.modified = new Date();
    });
  }
}
