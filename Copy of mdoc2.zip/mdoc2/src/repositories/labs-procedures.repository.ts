import { DefaultCrudRepository, BelongsToAccessor, repository } from '@loopback/repository';
import { LabsProcedures, LabsProceduresRelations, Users, Lab } from '../models';
import { DbDataSource } from '../datasources';
import { inject, Getter } from '@loopback/core';
import { UsersRepository } from './users.repository';
import { LabRepository } from './lab.repository';

export class LabsProceduresRepository extends DefaultCrudRepository<LabsProcedures, typeof LabsProcedures.prototype.id, LabsProceduresRelations> {
  public readonly user: BelongsToAccessor<Users, typeof Users.prototype.id>;
  public readonly lab: BelongsToAccessor<Lab, typeof Lab.prototype.id>;
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('UsersRepository') public usersRepositoryGitter: Getter<UsersRepository>,
    @repository.getter('LabRepository') public labRepositoryGitter: Getter<LabRepository>,
  ) {
    super(LabsProcedures, dataSource);


    this.user = this.createBelongsToAccessorFor('user', usersRepositoryGitter);
    this.lab = this.createBelongsToAccessorFor('lab', labRepositoryGitter);

    this.registerInclusionResolver('user', this.user.inclusionResolver);
    this.registerInclusionResolver('lab', this.lab.inclusionResolver);

    (this.modelClass as any).observe('persist', async (ctx: any) => {
      ctx.data.modified = new Date();
    });
  }
}
