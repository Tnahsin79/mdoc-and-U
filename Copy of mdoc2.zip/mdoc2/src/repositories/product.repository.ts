import {BelongsToAccessor, DefaultCrudRepository, repository} from '@loopback/repository';
import {Admin, Product, ProductRelations} from '../models';
import {DbDataSource} from '../datasources';
import {Getter, inject} from '@loopback/core';
import { AdminRepository } from './admin.repository';

export class ProductRepository extends DefaultCrudRepository<
  Product,
  typeof Product.prototype.id,
  ProductRelations
> {
    public readonly creator: BelongsToAccessor<Admin, typeof Admin.prototype.id>;
    constructor(
        @inject('datasources.db') dataSource: DbDataSource,
        @repository.getter('AdminRepository')
        creatorRepositoryGetter: Getter<AdminRepository>,
    ) {
        super(Product, dataSource);
        this.creator = this.createBelongsToAccessorFor(
        'creator',
        creatorRepositoryGetter,
    );
    this.registerInclusionResolver('creator', this.creator.inclusionResolver);
    }
}
