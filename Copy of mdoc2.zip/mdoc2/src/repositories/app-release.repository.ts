import {DefaultCrudRepository} from '@loopback/repository';
import {AppRelease, AppReleaseRelations} from '../models';
import {DbDataSource} from '../datasources';
import {inject} from '@loopback/core';

export class AppReleaseRepository extends DefaultCrudRepository<
  AppRelease,
  typeof AppRelease.prototype.id,
  AppReleaseRelations
> {
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
  ) {
    super(AppRelease, dataSource);
  }
}
