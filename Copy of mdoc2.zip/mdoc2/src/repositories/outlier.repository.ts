import {
  repository,
  BelongsToAccessor,
  DefaultCrudRepository,
} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Getter, inject} from '@loopback/core';
import {UsersRepository} from './users.repository';
import {CoachRepository} from './coach.repository';
import {Admin, Coach, Outlier, OutlierRelations, Users} from '../models';
import {AdminRepository} from './admin.repository';

export class OutlierRepository extends DefaultCrudRepository<
  Outlier,
  typeof Outlier.prototype.id,
  OutlierRelations
> {
  public readonly user: BelongsToAccessor<Users, typeof Users.prototype.id>;
  public readonly coach: BelongsToAccessor<Coach, typeof Coach.prototype.id>;
  public readonly admin: BelongsToAccessor<Admin, typeof Admin.prototype.id>;
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('UsersRepository')
    usersRepositoryGetter: Getter<UsersRepository>,
    @repository.getter('CoachRepository')
    coachRepositoryGetter: Getter<CoachRepository>,
    @repository.getter('AdminRepository')
    adminRepositoryGetter: Getter<AdminRepository>,
  ) {
    super(Outlier, dataSource);
    this.user = this.createBelongsToAccessorFor('user', usersRepositoryGetter);
    this.admin = this.createBelongsToAccessorFor(
      'admin',
      adminRepositoryGetter,
    );

    this.coach = this.createBelongsToAccessorFor(
      'coach',
      coachRepositoryGetter,
    );
    this.registerInclusionResolver('user', this.user.inclusionResolver);
    this.registerInclusionResolver('admin', this.admin.inclusionResolver);
    this.registerInclusionResolver('coach', this.coach.inclusionResolver);
  }
}
