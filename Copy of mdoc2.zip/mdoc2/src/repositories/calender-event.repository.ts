import {
  Admin,
  Users,
  Coach,
  CalenderEvent,
  CalenderEventRelations,
} from '../models';
import {
  repository,
  BelongsToAccessor,
  DefaultCrudRepository,
} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Getter, inject} from '@loopback/core';
import {UsersRepository} from './users.repository';
import {CoachRepository} from './coach.repository';
import {AdminRepository} from './admin.repository';

export class CalenderEventRepository extends DefaultCrudRepository<
  CalenderEvent,
  typeof CalenderEvent.prototype.id,
  CalenderEventRelations
> {
  public readonly member: BelongsToAccessor<Users, typeof Users.prototype.id>;
  public readonly coach: BelongsToAccessor<Coach, typeof Coach.prototype.id>;
  public readonly creatorAdmin: BelongsToAccessor<
    Admin,
    typeof Admin.prototype.id
  >;

  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('UsersRepository')
    public usersRepositoryGetter: Getter<UsersRepository>,
    @repository.getter('CoachRepository')
    public coachRepositoryGetter: Getter<CoachRepository>,
    @repository.getter('AdminRepository')
    creatorAdminRepositoryGetter: Getter<AdminRepository>,
  ) {
    super(CalenderEvent, dataSource);

    this.member = this.createBelongsToAccessorFor(
      'member',
      usersRepositoryGetter,
    );
    this.coach = this.createBelongsToAccessorFor(
      'coach',
      coachRepositoryGetter,
    );
    this.creatorAdmin = this.createBelongsToAccessorFor(
      'creatorAdmin',
      creatorAdminRepositoryGetter,
    );

    this.registerInclusionResolver(
      'creatorAdmin',
      this.creatorAdmin.inclusionResolver,
    );
    this.registerInclusionResolver('member', this.member.inclusionResolver);
    this.registerInclusionResolver('coach', this.coach.inclusionResolver);
  }
}
