import {DefaultCrudRepository} from '@loopback/repository';
import {Plans, PlansRelations} from '../models';
import {DbDataSource} from '../datasources';
import {inject} from '@loopback/core';

export class PlansRepository extends DefaultCrudRepository<
  Plans,
  typeof Plans.prototype.id,
  PlansRelations
> {
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
  ) {
    super(Plans, dataSource);
  }
}
