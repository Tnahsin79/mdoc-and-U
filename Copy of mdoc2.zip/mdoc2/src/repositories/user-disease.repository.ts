import {
  BelongsToAccessor,
  DefaultCrudRepository,
  repository,
} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Getter, inject} from '@loopback/core';
import {UsersRepository} from './users.repository';
import {DiseaseRepository} from './disease.repository';
import {UserDisease, UserDiseaseRelations, Users, Disease} from '../models';

export class UserDiseaseRepository extends DefaultCrudRepository<
  UserDisease,
  typeof UserDisease.prototype.id,
  UserDiseaseRelations
> {
  public readonly user: BelongsToAccessor<Users, typeof Users.prototype.id>;
  public readonly disease: BelongsToAccessor<
    Disease,
    typeof Disease.prototype.id
  >;
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('UsersRepository')
    usersRepositoryGetter: Getter<UsersRepository>,
    @repository.getter('DiseaseRepository')
    diseaseRepositoryGetter: Getter<DiseaseRepository>,
  ) {
    super(UserDisease, dataSource);
    this.user = this.createBelongsToAccessorFor('user', usersRepositoryGetter);
    this.disease = this.createBelongsToAccessorFor(
      'disease',
      diseaseRepositoryGetter,
    );
    this.registerInclusionResolver('user', this.user.inclusionResolver);
    this.registerInclusionResolver('disease', this.disease.inclusionResolver);
  }
}
