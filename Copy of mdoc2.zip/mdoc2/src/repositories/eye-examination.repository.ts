import { DefaultCrudRepository, BelongsToAccessor, repository } from '@loopback/repository';
import { EyeExamination, EyeExaminationRelations, Users, Provider, Consult } from '../models';
import { DbDataSource } from '../datasources';
import { inject, Getter } from '@loopback/core';
import { UsersRepository } from './users.repository';
import { ProviderRepository } from './provider.repository';
import { ConsultRepository } from './consult.repository';

export class EyeExaminationRepository extends DefaultCrudRepository<EyeExamination, typeof EyeExamination.prototype.id, EyeExaminationRelations> {
  public readonly user: BelongsToAccessor<Users, typeof Users.prototype.id>;
  public readonly consult: BelongsToAccessor<Consult, typeof Consult.prototype.id>;
  
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('UsersRepository') public usersRepositoryGitter: Getter<UsersRepository>,
    @repository.getter('ConsultRepository') public consultRepositoryGetter: Getter<ConsultRepository>,
  ) {
    super(EyeExamination, dataSource);
    this.user = this.createBelongsToAccessorFor('user', usersRepositoryGitter);

    this.registerInclusionResolver('user', this.user.inclusionResolver);

    this.consult = this.createBelongsToAccessorFor('consult', consultRepositoryGetter);
    this.registerInclusionResolver('consult', this.consult.inclusionResolver);

    (this.modelClass as any).observe('persist', async (ctx: any) => {
      ctx.data.modified = new Date();
    });
  }
}
