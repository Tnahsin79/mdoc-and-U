import {
  DefaultCrudRepository,
  BelongsToAccessor,
  repository,
} from '@loopback/repository';
import {Appointment, AppointmentRelations, Coach, Users} from '../models';
import {DbDataSource} from '../datasources';
import {inject, Getter} from '@loopback/core';
import {CoachRepository} from './coach.repository';
import { UsersRepository } from './users.repository';

export class AppointmentRepository extends DefaultCrudRepository<
  Appointment,
  typeof Appointment.prototype.id,
  AppointmentRelations
> {
  public readonly coach: BelongsToAccessor<Coach, typeof Coach.prototype.id>;
  public readonly user: BelongsToAccessor<Users, typeof Users.prototype.id>;

  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('CoachRepository')
    public coachRepositoryGitter: Getter<CoachRepository>,
    @repository.getter('UsersRepository')
    public usersRepositoryGitter: Getter<UsersRepository>,
  ) {
    super(Appointment, dataSource);
    this.coach = this.createBelongsToAccessorFor(
      'coach',
      coachRepositoryGitter,
    );
    this.user = this.createBelongsToAccessorFor(
      'user',
      usersRepositoryGitter,
    );

    this.registerInclusionResolver('coach', this.coach.inclusionResolver);
    this.registerInclusionResolver('user', this.user.inclusionResolver);

    (this.modelClass as any).observe('persist', async (ctx: any) => {
      ctx.data.modified = new Date();
    });
  }
}
