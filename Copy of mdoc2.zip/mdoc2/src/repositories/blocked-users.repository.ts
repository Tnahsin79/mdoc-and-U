import { DbDataSource } from '../datasources';
import { inject, Getter } from '@loopback/core';
import { BelongsToAccessor, DefaultCrudRepository, repository } from '@loopback/repository';
import { CoachRepository, CommentRepository, BlogPostRepository, UsersRepository } from '.';
import { BlockedUsers, BlockedUsersRelations, Coach, Comment, BlogPost, Users } from '../models';

export class BlockedUsersRepository extends DefaultCrudRepository<BlockedUsers, typeof BlockedUsers.prototype.id, BlockedUsersRelations> {
  public readonly user: BelongsToAccessor<Users, typeof Users.prototype.id>;
  public readonly blockUser: BelongsToAccessor<Users, typeof Users.prototype.id>;
  public readonly coach: BelongsToAccessor<Coach, typeof Coach.prototype.id>;
  public readonly blockCoach: BelongsToAccessor<Coach, typeof Coach.prototype.id>;
  public readonly blogPost: BelongsToAccessor<BlogPost, typeof BlogPost.prototype.id>;
  public readonly comment: BelongsToAccessor<Comment, typeof Comment.prototype.id>;
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('UsersRepository') public usersRepositoryGitter: Getter<UsersRepository>,
    @repository.getter('CoachRepository') public coachRepositoryGitter: Getter<CoachRepository>,
    @repository.getter('BlogPostRepository') public blogPostRepositoryGitter: Getter<BlogPostRepository>,
    @repository.getter('CommentRepository') public commentRepositoryGitter: Getter<CommentRepository>,
  ) {
    super(BlockedUsers, dataSource);

    this.user = this.createBelongsToAccessorFor('user', usersRepositoryGitter);
    this.blockUser = this.createBelongsToAccessorFor('blockUser', usersRepositoryGitter);

    this.coach = this.createBelongsToAccessorFor('coach', coachRepositoryGitter);
    this.blockCoach = this.createBelongsToAccessorFor('blockCoach', coachRepositoryGitter);

    this.blogPost = this.createBelongsToAccessorFor('blogPost', blogPostRepositoryGitter);
    this.comment = this.createBelongsToAccessorFor('comment', commentRepositoryGitter);


    this.registerInclusionResolver('user', this.user.inclusionResolver);
    this.registerInclusionResolver('blockUser', this.blockUser.inclusionResolver);

    this.registerInclusionResolver('coach', this.coach.inclusionResolver);
    this.registerInclusionResolver('blockCoach', this.blockCoach.inclusionResolver);

    this.registerInclusionResolver('blogPost', this.blogPost.inclusionResolver);
    this.registerInclusionResolver('comment', this.comment.inclusionResolver);

  }
}
