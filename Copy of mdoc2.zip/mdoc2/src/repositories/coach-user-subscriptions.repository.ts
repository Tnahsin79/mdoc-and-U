import {
  Coach,
  UserSubscriptions,
  CoachUserSubscriptions,
  CoachUserSubscriptionsRelations,
} from '../models';
import {
  repository,
  BelongsToAccessor,
  DefaultCrudRepository,
} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Getter, inject} from '@loopback/core';
import {CoachRepository} from './coach.repository';
import {UserSubscriptionsRepository} from './user-subscriptions.repository';

export class CoachUserSubscriptionsRepository extends DefaultCrudRepository<
  CoachUserSubscriptions,
  typeof CoachUserSubscriptions.prototype.id,
  CoachUserSubscriptionsRelations
> {
  public readonly subscription: BelongsToAccessor<
    UserSubscriptions,
    typeof UserSubscriptions.prototype.id
  >;
  public readonly coach: BelongsToAccessor<Coach, typeof Coach.prototype.id>;
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('UserSubscriptionsRepository')
    userSubscriptionsRepositoryGetter: Getter<UserSubscriptionsRepository>,
    @repository.getter('CoachRepository')
    coachRepositoryGetter: Getter<CoachRepository>,
  ) {
    super(CoachUserSubscriptions, dataSource);
    this.subscription = this.createBelongsToAccessorFor(
      'subscription',
      userSubscriptionsRepositoryGetter,
    );
    this.coach = this.createBelongsToAccessorFor(
      'coach',
      coachRepositoryGetter,
    );
    this.registerInclusionResolver(
      'subscription',
      this.subscription.inclusionResolver,
    );
    this.registerInclusionResolver('coach', this.coach.inclusionResolver);
  }
}
