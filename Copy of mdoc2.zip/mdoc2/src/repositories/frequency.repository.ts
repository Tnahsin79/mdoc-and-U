import {DefaultCrudRepository} from '@loopback/repository';
import {Frequency, FrequencyRelations} from '../models';
import {DbDataSource} from '../datasources';
import {inject} from '@loopback/core';

export class FrequencyRepository extends DefaultCrudRepository<
  Frequency,
  typeof Frequency.prototype.id,
  FrequencyRelations
> {
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
  ) {
    super(Frequency, dataSource);
  }
}
