import { DefaultCrudRepository, BelongsToAccessor, repository } from '@loopback/repository';
import { MedicationPassport, MedicationPassportRelations, Users, MedicationWithRelations, Medication } from '../models';
import { DbDataSource } from '../datasources';
import { inject, Getter } from '@loopback/core';
import { UsersRepository } from './users.repository';
import { MedicationRepository } from './medication.repository';
export class MedicationPassportRepository extends DefaultCrudRepository<MedicationPassport, typeof MedicationPassport.prototype.id, MedicationPassportRelations> {
  public readonly user: BelongsToAccessor<Users, typeof Users.prototype.id>;
  public readonly medicine: BelongsToAccessor<Medication, typeof Medication.prototype.id>;
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('UsersRepository') public usersRepositoryGitter: Getter<UsersRepository>,
    @repository.getter('MedicationRepository') public medicationRepositoryGitter: Getter<MedicationRepository>,
  ) {
    super(MedicationPassport, dataSource);

    this.user = this.createBelongsToAccessorFor('user', usersRepositoryGitter);
    this.medicine = this.createBelongsToAccessorFor('medicine', medicationRepositoryGitter);

    this.registerInclusionResolver('user', this.user.inclusionResolver);
    this.registerInclusionResolver('medicine', this.medicine.inclusionResolver);
  }
}
