import { DefaultCrudRepository } from '@loopback/repository';
import { Treatment, TreatmentRelations } from '../models';
import { DbDataSource } from '../datasources';
import { inject } from '@loopback/core';

export class TreatmentRepository extends DefaultCrudRepository<
  Treatment,
  typeof Treatment.prototype.id,
  TreatmentRelations
  > {
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
  ) {
    super(Treatment, dataSource);


    (this.modelClass as any).observe('persist', async (ctx: any) => {
      ctx.data.modified = new Date();
    });
  }
}
