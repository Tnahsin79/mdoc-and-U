import {
  BelongsToAccessor,
  DefaultCrudRepository,
  repository,
} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Getter, inject} from '@loopback/core';
import {UsersRepository} from './users.repository';
import {CoachRepository} from './coach.repository';
import {Coach, Users, WeightGoal, WeightGoalRelations} from '../models';

export class WeightGoalRepository extends DefaultCrudRepository<
  WeightGoal,
  typeof WeightGoal.prototype.id,
  WeightGoalRelations
> {
  public readonly user: BelongsToAccessor<Users, typeof Users.prototype.id>;
  public readonly coach: BelongsToAccessor<Coach, typeof Coach.prototype.id>;
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('UsersRepository')
    usersRepositoryGetter: Getter<UsersRepository>,
    @repository.getter('CoachRepository')
    coachRepositoryGetter: Getter<CoachRepository>,
  ) {
    super(WeightGoal, dataSource);
    this.user = this.createBelongsToAccessorFor('user', usersRepositoryGetter);
    this.registerInclusionResolver('user', this.user.inclusionResolver);
    this.coach = this.createBelongsToAccessorFor(
      'coach',
      coachRepositoryGetter,
    );
    this.registerInclusionResolver('coach', this.coach.inclusionResolver);
  }
}
