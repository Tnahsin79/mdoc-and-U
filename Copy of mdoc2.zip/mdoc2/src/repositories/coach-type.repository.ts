import {
  DefaultCrudRepository,
  HasManyRepositoryFactory,
  repository,
} from '@loopback/repository';
import {CoachType, CoachTypeRelations} from '../models/coach-type.model';
import {DbDataSource} from '../datasources';
import {Getter, inject} from '@loopback/core';
import {CoachTypeSpeciality} from '../models';
import {CoachTypeSpecialityRepository} from './coach-type-speciality.repository';

export class CoachTypeRepository extends DefaultCrudRepository<
  CoachType,
  typeof CoachType.prototype.id,
  CoachTypeRelations
> {
  public readonly specialities: HasManyRepositoryFactory<
    CoachTypeSpeciality,
    typeof CoachTypeSpeciality.prototype.id
  >;
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('CoachTypeSpecialityRepository')
    coachTypeSpecialityRepositoryGetter: Getter<CoachTypeSpecialityRepository>,
  ) {
    super(CoachType, dataSource);
    this.specialities = this.createHasManyRepositoryFactoryFor(
      'specialities',
      coachTypeSpecialityRepositoryGetter,
    );

    this.registerInclusionResolver(
      'specialities',
      this.specialities.inclusionResolver,
    );
  }
}
