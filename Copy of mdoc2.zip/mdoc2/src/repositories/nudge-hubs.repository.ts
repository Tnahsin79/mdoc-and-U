import {Getter, inject} from '@loopback/core';
import {BelongsToAccessor, DefaultCrudRepository, repository} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Admin, NudgeHubs, NudgeHubsRelations} from '../models';
import { AdminRepository } from './admin.repository';

export class NudgeHubsRepository extends DefaultCrudRepository<
  NudgeHubs,
  typeof NudgeHubs.prototype.id,
  NudgeHubsRelations
> {
  public readonly createdBy: BelongsToAccessor<Admin, typeof Admin.prototype.id>;
  public readonly updatedBy: BelongsToAccessor<Admin, typeof Admin.prototype.id>;
  
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('AdminRepository')
    AdminRepositoryGetter: Getter<AdminRepository>,
  ) {
    super(NudgeHubs, dataSource);
    this.createdBy = this.createBelongsToAccessorFor('createdBy', AdminRepositoryGetter);
    this.registerInclusionResolver('createdBy', this.createdBy.inclusionResolver);
    this.updatedBy = this.createBelongsToAccessorFor('updatedBy', AdminRepositoryGetter);
    this.registerInclusionResolver('updatedBy', this.updatedBy.inclusionResolver);
  }
}
