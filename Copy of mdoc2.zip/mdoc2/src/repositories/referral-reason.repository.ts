import {DefaultCrudRepository} from '@loopback/repository';
import {ReferralReason, ReferralReasonRelations} from '../models';
import {DbDataSource} from '../datasources';
import {inject} from '@loopback/core';

export class ReferralReasonRepository extends DefaultCrudRepository<
  ReferralReason,
  typeof ReferralReason.prototype.id,
  ReferralReasonRelations
> {
  constructor(@inject('datasources.db') dataSource: DbDataSource) {
    super(ReferralReason, dataSource);
  }
}
