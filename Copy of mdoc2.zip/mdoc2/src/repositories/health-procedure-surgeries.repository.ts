import {
  DefaultCrudRepository,
  BelongsToAccessor,
  repository,
} from '@loopback/repository';
import {
  HealthProcedureSurgeries,
  HealthProcedureSurgeriesRelations,
  Users,
  ProcedureList,
} from '../models';
import {DbDataSource} from '../datasources';
import {inject, Getter} from '@loopback/core';
import {UsersRepository} from './users.repository';
import {ProcedureListRepository} from './procedure-list.repository';

export class HealthProcedureSurgeriesRepository extends DefaultCrudRepository<
  HealthProcedureSurgeries,
  typeof HealthProcedureSurgeries.prototype.id,
  HealthProcedureSurgeriesRelations
> {
  public readonly user: BelongsToAccessor<Users, typeof Users.prototype.id>;
  public readonly procedure: BelongsToAccessor<
    ProcedureList,
    typeof ProcedureList.prototype.id
  >;
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('UsersRepository')
    public usersRepositoryGitter: Getter<UsersRepository>,
    @repository.getter('ProcedureListRepository')
    public procedureRepositoryGitter: Getter<ProcedureListRepository>,
  ) {
    super(HealthProcedureSurgeries, dataSource);

    this.user = this.createBelongsToAccessorFor('user', usersRepositoryGitter);
    this.procedure = this.createBelongsToAccessorFor(
      'procedure',
      procedureRepositoryGitter,
    );

    this.registerInclusionResolver('user', this.user.inclusionResolver);
    this.registerInclusionResolver(
      'procedure',
      this.procedure.inclusionResolver,
    );

    (this.modelClass as any).observe('persist', async (ctx: any) => {
      ctx.data.modified = new Date();
    });
  }
}
