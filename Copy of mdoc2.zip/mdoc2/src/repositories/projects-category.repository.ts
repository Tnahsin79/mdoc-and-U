import { inject } from '@loopback/core';
import { DefaultCrudRepository } from '@loopback/repository';
import { DbDataSource } from '../datasources';
import { ProjectsCategory, ProjectsCategoryRelations } from '../models';

export class ProjectsCategoryRepository extends DefaultCrudRepository<
  ProjectsCategory,
  typeof ProjectsCategory.prototype.id,
  ProjectsCategoryRelations
> {
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
  ) {
    super(ProjectsCategory, dataSource);
  }
}
