import {
  repository,
  BelongsToAccessor,
  DefaultCrudRepository,
} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Getter, inject} from '@loopback/core';
import {UsersRepository} from './users.repository';
import {CommentRepository} from './comment.repository';
import {Comment, CommentReply, CommentReplyRelations, Users} from '../models';

export class CommentReplyRepository extends DefaultCrudRepository<
  CommentReply,
  typeof CommentReply.prototype.id,
  CommentReplyRelations
> {
  public readonly user: BelongsToAccessor<Users, typeof Users.prototype.id>;
  public readonly parentComment: BelongsToAccessor<
    Comment,
    typeof Comment.prototype.id
  >;
  public readonly replyComment: BelongsToAccessor<
    Comment,
    typeof Comment.prototype.id
  >;
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('UsersRepository')
    public usersRepositoryGitter: Getter<UsersRepository>,
    @repository.getter('CommentRepository')
    public commentRepositoryGetter: Getter<CommentRepository>,
  ) {
    super(CommentReply, dataSource);
    this.user = this.createBelongsToAccessorFor('user', usersRepositoryGitter);
    this.parentComment = this.createBelongsToAccessorFor(
      'parentComment',
      commentRepositoryGetter,
    );
    this.replyComment = this.createBelongsToAccessorFor(
      'replyComment',
      commentRepositoryGetter,
    );

    this.registerInclusionResolver('user', this.user.inclusionResolver);
    this.registerInclusionResolver(
      'parentComment',
      this.parentComment.inclusionResolver,
    );
    this.registerInclusionResolver(
      'replyComment',
      this.replyComment.inclusionResolver,
    );
  }
}
