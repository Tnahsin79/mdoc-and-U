import {
  repository,
  BelongsToAccessor,
  DefaultCrudRepository,
} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Getter, inject} from '@loopback/core';
import {AdminRepository} from './admin.repository';
import {UsersRepository} from './users.repository';
import {ProgramsRepository} from './programs.repository';
import {Admin, Goal, GoalRelations, Programs, Users} from '../models';

export class GoalRepository extends DefaultCrudRepository<
  Goal,
  typeof Goal.prototype.id,
  GoalRelations
> {
  public readonly user: BelongsToAccessor<Users, typeof Users.prototype.id>;
  public readonly admin: BelongsToAccessor<Admin, typeof Admin.prototype.id>;
  public readonly program: BelongsToAccessor<
    Programs,
    typeof Programs.prototype.id
  >;
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('UsersRepository')
    usersRepositoryGetter: Getter<UsersRepository>,
    @repository.getter('AdminRepository')
    adminRepositoryGetter: Getter<AdminRepository>,
    @repository.getter('ProgramsRepository')
    programRepositoryGetter: Getter<ProgramsRepository>,
  ) {
    super(Goal, dataSource);
    this.user = this.createBelongsToAccessorFor('user', usersRepositoryGetter);
    this.admin = this.createBelongsToAccessorFor(
      'admin',
      adminRepositoryGetter,
    );
    this.program = this.createBelongsToAccessorFor(
      'program',
      programRepositoryGetter,
    );
    this.registerInclusionResolver('user', this.user.inclusionResolver);
    this.registerInclusionResolver('admin', this.admin.inclusionResolver);
    this.registerInclusionResolver('program', this.program.inclusionResolver);
  }
}
