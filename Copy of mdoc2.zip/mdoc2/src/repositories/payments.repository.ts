import {
  Users,
  Payments,
  Programs,
  ProgramPlans,
  PaymentsRelations,
  HubVisit,
  Coach,
} from '../models';
import {
  repository,
  BelongsToAccessor,
  DefaultCrudRepository,
} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Getter, inject} from '@loopback/core';
import {UsersRepository} from './users.repository';
import {ProgramsRepository} from './programs.repository';
import {ProgramPlansRepository} from './program-plans.repository';
import {HubVisitRepository} from './hub-visit.repository';
import {CoachRepository} from './coach.repository';

export class PaymentsRepository extends DefaultCrudRepository<
  Payments,
  typeof Payments.prototype.id,
  PaymentsRelations
> {
  public readonly user: BelongsToAccessor<Users, typeof Users.prototype.id>;
  public readonly program: BelongsToAccessor<
    Programs,
    typeof Programs.prototype.id
  >;
  public readonly plan: BelongsToAccessor<
    ProgramPlans,
    typeof ProgramPlans.prototype.id
  >;
  public readonly hubVisit: BelongsToAccessor<
    HubVisit,
    typeof HubVisit.prototype.id
  >;
  public readonly coach: BelongsToAccessor<Coach, typeof Coach.prototype.id>;
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('UsersRepository')
    userRepositoryGetter: Getter<UsersRepository>,
    @repository.getter('ProgramsRepository')
    programRepositoryGetter: Getter<ProgramsRepository>,
    @repository.getter('ProgramPlansRepository')
    planRepositoryGetter: Getter<ProgramPlansRepository>,
    @repository.getter('HubVisitRepository')
    hubVisitRepositoryGetter: Getter<HubVisitRepository>,
    @repository.getter('CoachRepository')
    coachRepositoryGetter: Getter<CoachRepository>,
  ) {
    super(Payments, dataSource);
    this.user = this.createBelongsToAccessorFor('user', userRepositoryGetter);
    this.program = this.createBelongsToAccessorFor(
      'program',
      programRepositoryGetter,
    );
    this.plan = this.createBelongsToAccessorFor('plan', planRepositoryGetter);
    this.registerInclusionResolver('user', this.user.inclusionResolver);
    this.registerInclusionResolver('plan', this.plan.inclusionResolver);
    this.registerInclusionResolver('program', this.program.inclusionResolver);
    this.hubVisit = this.createBelongsToAccessorFor(
      'hubVisit',
      hubVisitRepositoryGetter,
    );
    this.registerInclusionResolver('hubVisit', this.hubVisit.inclusionResolver);
    this.coach = this.createBelongsToAccessorFor(
      'coach',
      coachRepositoryGetter,
    );
    this.registerInclusionResolver('coach', this.coach.inclusionResolver);
  }
}
