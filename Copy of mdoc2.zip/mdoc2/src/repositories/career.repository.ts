import {
  BelongsToAccessor,
  DefaultCrudRepository,
  repository,
} from "@loopback/repository";
import { Admin, Career, CareerRelations } from "../models";
import { DbDataSource } from "../datasources";
import { Getter, inject } from "@loopback/core";
import { AdminRepository } from "./admin.repository";

export class CareerRepository extends DefaultCrudRepository<
  Career,
  typeof Career.prototype.id,
  CareerRelations
> {
  public readonly creator: BelongsToAccessor<Admin, typeof Admin.prototype.id>;
  constructor(
    @inject("datasources.db") dataSource: DbDataSource,
    @repository.getter("AdminRepository")
    creatorRepositoryGetter: Getter<AdminRepository>
  ) {
    super(Career, dataSource);
    this.creator = this.createBelongsToAccessorFor(
      "creator",
      creatorRepositoryGetter
    );
    this.registerInclusionResolver("creator", this.creator.inclusionResolver);
  }
}
