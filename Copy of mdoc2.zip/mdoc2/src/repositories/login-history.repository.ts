import {
  Admin,
  Coach,
  Users,
  LoginHistory,
  LoginHistoryRelations,
} from '../models';
import {
  repository,
  BelongsToAccessor,
  DefaultCrudRepository,
} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Getter, inject} from '@loopback/core';
import {UsersRepository} from './users.repository';
import {AdminRepository} from './admin.repository';
import {CoachRepository} from './coach.repository';

export class LoginHistoryRepository extends DefaultCrudRepository<
  LoginHistory,
  typeof LoginHistory.prototype.id,
  LoginHistoryRelations
> {
  public readonly user: BelongsToAccessor<Users, typeof Users.prototype.id>;
  public readonly admin: BelongsToAccessor<Admin, typeof Admin.prototype.id>;
  public readonly coach: BelongsToAccessor<Coach, typeof Coach.prototype.id>;
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('UsersRepository')
    usersRepositoryGetter: Getter<UsersRepository>,
    @repository.getter('AdminRepository')
    adminRepositoryGetter: Getter<AdminRepository>,
    @repository.getter('CoachRepository')
    coachRepositoryGetter: Getter<CoachRepository>,
  ) {
    super(LoginHistory, dataSource);
    this.user = this.createBelongsToAccessorFor('user', usersRepositoryGetter);
    this.admin = this.createBelongsToAccessorFor(
      'admin',
      adminRepositoryGetter,
    );
    this.coach = this.createBelongsToAccessorFor(
      'coach',
      coachRepositoryGetter,
    );
    this.registerInclusionResolver('user', this.user.inclusionResolver);
    this.registerInclusionResolver('admin', this.admin.inclusionResolver);
    this.registerInclusionResolver('coach', this.coach.inclusionResolver);
  }
}
