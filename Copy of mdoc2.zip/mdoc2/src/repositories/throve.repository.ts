import {DefaultCrudRepository} from '@loopback/repository';
import {Throve, ThroveRelations} from '../models';
import {DbDataSource} from '../datasources';
import {inject} from '@loopback/core';

export class ThroveRepository extends DefaultCrudRepository<
  Throve,
  typeof Throve.prototype.id,
  ThroveRelations
> {
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
  ) {
    super(Throve, dataSource);
  }
}
