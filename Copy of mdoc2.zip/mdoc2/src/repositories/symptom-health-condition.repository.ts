import {BelongsToAccessor, DefaultCrudRepository, repository} from '@loopback/repository';
import {HealthCondition, Medication, SymptomHealthCondition, SymptomHealthConditionRelations, Symptoms, Users} from '../models';
import {DbDataSource} from '../datasources';
import {Getter, inject} from '@loopback/core';
import { UsersRepository } from './users.repository';
import { MedicationRepository } from './medication.repository';
import { HealthConditionRepository } from './health-condition.repository';
import { SymptomsRepository } from './symptoms.repository';

export class SymptomHealthConditionRepository extends DefaultCrudRepository<
  SymptomHealthCondition,
  typeof SymptomHealthCondition.prototype.id,
  SymptomHealthConditionRelations
> {
  
  public readonly user: BelongsToAccessor<
  Users,
  typeof Users.prototype.id
>;
  public readonly medication: BelongsToAccessor<
  Medication,
  typeof Medication.prototype.id
>;
  public readonly healthCondition: BelongsToAccessor<
  HealthCondition,
  typeof HealthCondition.prototype.id
>;
  public readonly symptom: BelongsToAccessor<
  Symptoms,
  typeof Symptoms.prototype.id
>;
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('UsersRepository')
    userRepositoryGetter: Getter<UsersRepository>,
    @repository.getter('MedicationRepository')
    medicationRepositoryGetter: Getter<MedicationRepository>,
    @repository.getter('HealthConditionRepository')
    healthConditionRepositoryGetter: Getter<HealthConditionRepository>,
    @repository.getter('SymptomsRepository')
    symptomRepositoryGetter: Getter<SymptomsRepository>,
  ) {
    super(SymptomHealthCondition, dataSource);
    this.user = this.createBelongsToAccessorFor(
      'user',
      userRepositoryGetter,
    );
    this.medication = this.createBelongsToAccessorFor(
      'medication',
      medicationRepositoryGetter,
    );
    this.healthCondition = this.createBelongsToAccessorFor(
      'healthCondition',
      healthConditionRepositoryGetter,
    );
    this.symptom = this.createBelongsToAccessorFor(
      'symptom',
      symptomRepositoryGetter,
    );
    
    this.registerInclusionResolver('user', this.user.inclusionResolver);
    this.registerInclusionResolver('medication', this.medication.inclusionResolver);
    this.registerInclusionResolver('healthCondition', this.healthCondition.inclusionResolver);
    this.registerInclusionResolver('symptom', this.symptom.inclusionResolver);
  }
}
