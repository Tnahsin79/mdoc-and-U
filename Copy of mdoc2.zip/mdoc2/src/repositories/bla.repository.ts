import {
  Bla,
  Users,
  Option,
  Programs,
  Question,
  BlaRecord,
  BlaRelations,
} from '../models';
import {
  repository,
  BelongsToAccessor,
  DefaultCrudRepository,
} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Getter, inject} from '@loopback/core';
import {UsersRepository} from './users.repository';
import {OptionRepository} from './option.repository';
import {ProgramsRepository} from './programs.repository';
import {QuestionRepository} from './question.repository';
import {BlaRecordRepository} from './bla-record.repository';

export class BlaRepository extends DefaultCrudRepository<
  Bla,
  typeof Bla.prototype.id,
  BlaRelations
> {
  public readonly user: BelongsToAccessor<Users, typeof Users.prototype.id>;
  public readonly program: BelongsToAccessor<
    Programs,
    typeof Programs.prototype.id
  >;
  public readonly option: BelongsToAccessor<Option, typeof Option.prototype.id>;
  public readonly question: BelongsToAccessor<
    Question,
    typeof Question.prototype.id
  >;
  public readonly blaRecord: BelongsToAccessor<
    BlaRecord,
    typeof BlaRecord.prototype.id
  >;
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('UsersRepository')
    userRepositoryGetter: Getter<UsersRepository>,
    @repository.getter('ProgramsRepository')
    programRepositoryGetter: Getter<ProgramsRepository>,
    @repository.getter('OptionRepository')
    optionRepositoryGetter: Getter<OptionRepository>,
    @repository.getter('QuestionRepository')
    questionRepositoryGetter: Getter<QuestionRepository>,
    @repository.getter('BlaRecordRepository')
    blaRecordRepositoryGetter: Getter<BlaRecordRepository>,
  ) {
    super(Bla, dataSource);
    this.user = this.createBelongsToAccessorFor('user', userRepositoryGetter);
    this.program = this.createBelongsToAccessorFor(
      'program',
      programRepositoryGetter,
    );
    this.option = this.createBelongsToAccessorFor(
      'option',
      optionRepositoryGetter,
    );
    this.question = this.createBelongsToAccessorFor(
      'question',
      questionRepositoryGetter,
    );
    this.blaRecord = this.createBelongsToAccessorFor(
      'blaRecord',
      blaRecordRepositoryGetter,
    );
    this.registerInclusionResolver('question', this.question.inclusionResolver);
    this.registerInclusionResolver('user', this.user.inclusionResolver);
    this.registerInclusionResolver('program', this.program.inclusionResolver);
    this.registerInclusionResolver('option', this.option.inclusionResolver);
    this.registerInclusionResolver(
      'blaRecord',
      this.blaRecord.inclusionResolver,
    );
  }
}
