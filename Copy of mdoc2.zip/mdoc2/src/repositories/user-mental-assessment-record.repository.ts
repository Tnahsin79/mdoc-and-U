import {
  Users,
  UserMentalAssessment,
  UserMentalAssessmentRecord,
  UserMentalAssessmentRecordRelations,
} from '../models';
import {
  repository,
  BelongsToAccessor,
  DefaultCrudRepository,
  HasManyRepositoryFactory,
} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {inject, Getter} from '@loopback/core';
import {UsersRepository} from './users.repository';
import {UserMentalAssessmentRepository} from './user-mental-assessment.repository';

export class UserMentalAssessmentRecordRepository extends DefaultCrudRepository<
  UserMentalAssessmentRecord,
  typeof UserMentalAssessmentRecord.prototype.id,
  UserMentalAssessmentRecordRelations
> {
  public readonly user: BelongsToAccessor<Users, typeof Users.prototype.id>;
  public readonly userMentalAssessments: HasManyRepositoryFactory<
    UserMentalAssessment,
    typeof UserMentalAssessment.prototype.id
  >;
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('UsersRepository')
    usersRepositoryGetter: Getter<UsersRepository>,
    @repository.getter('UserMentalAssessmentRepository')
    userMentalAssessmentRepositoryGetter: Getter<
      UserMentalAssessmentRepository
    >,
  ) {
    super(UserMentalAssessmentRecord, dataSource);
    this.user = this.createBelongsToAccessorFor('user', usersRepositoryGetter);
    this.userMentalAssessments = this.createHasManyRepositoryFactoryFor(
      'userMentalAssessments',
      userMentalAssessmentRepositoryGetter,
    );
    this.registerInclusionResolver('user', this.user.inclusionResolver);
    this.registerInclusionResolver(
      'userMentalAssessments',
      this.userMentalAssessments.inclusionResolver,
    );
  }
}
