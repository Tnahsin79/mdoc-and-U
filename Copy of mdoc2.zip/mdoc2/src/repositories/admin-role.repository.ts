import {Getter, inject} from '@loopback/core';
import {BelongsToAccessor, DefaultCrudRepository, repository} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Admin, AdminRole, AdminRoleRelations, Role} from '../models';
import { RoleRepository } from './role.repository';
import { AdminRepository } from './admin.repository';

export class AdminRoleRepository extends DefaultCrudRepository<
  AdminRole,
  typeof AdminRole.prototype.id,
  AdminRoleRelations
> {
  public readonly admin: BelongsToAccessor<Admin, typeof Admin.prototype.id>;
  public readonly role: BelongsToAccessor<Role, typeof Role.prototype.id>;
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('AdminRepository') public adminRepositoryGetter: Getter<AdminRepository>,
    @repository.getter('RoleRepository') public roleRepositoryGetter: Getter<RoleRepository>,
  ) {
    super(AdminRole, dataSource);
    this.role = this.createBelongsToAccessorFor('role', roleRepositoryGetter);
    this.registerInclusionResolver('role', this.role.inclusionResolver);
    this.admin = this.createBelongsToAccessorFor('admin', adminRepositoryGetter);
    this.registerInclusionResolver('admin', this.admin.inclusionResolver);
  }
}
