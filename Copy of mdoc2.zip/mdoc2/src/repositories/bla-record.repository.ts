import {
  repository,
  BelongsToAccessor,
  DefaultCrudRepository,
  HasManyRepositoryFactory,
} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Getter, inject} from '@loopback/core';
import {BlaRepository} from './bla.repository';
import {UsersRepository} from './users.repository';
import {ProgramsRepository} from './programs.repository';
import {Bla, Users, Programs, BlaRecord, BlaRecordRelations} from '../models';

export class BlaRecordRepository extends DefaultCrudRepository<
  BlaRecord,
  typeof BlaRecord.prototype.id,
  BlaRecordRelations
> {
  public readonly user: BelongsToAccessor<Users, typeof Users.prototype.id>;
  public readonly program: BelongsToAccessor<
    Programs,
    typeof Programs.prototype.id
  >;
  public readonly blas: HasManyRepositoryFactory<Bla, typeof Bla.prototype.id>;
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('BlaRepository')
    blaRepositoryGetter: Getter<BlaRepository>,
    @repository.getter('UsersRepository')
    userRepositoryGetter: Getter<UsersRepository>,
    @repository.getter('ProgramsRepository')
    programRepositoryGetter: Getter<ProgramsRepository>,
  ) {
    super(BlaRecord, dataSource);
    this.user = this.createBelongsToAccessorFor('user', userRepositoryGetter);
    this.program = this.createBelongsToAccessorFor(
      'program',
      programRepositoryGetter,
    );
    this.blas = this.createHasManyRepositoryFactoryFor(
      'blas',
      blaRepositoryGetter,
    );
    this.registerInclusionResolver('user', this.user.inclusionResolver);
    this.registerInclusionResolver('program', this.program.inclusionResolver);
    this.registerInclusionResolver('blas', this.blas.inclusionResolver);
  }
}
