import {
  repository,
  BelongsToAccessor,
  DefaultCrudRepository,
} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Getter, inject} from '@loopback/core';
import {UsersRepository} from './users.repository';
import { Coach, HubVisit, LabTest, LabTestRelations, Users} from '../models';
import { CoachRepository } from './coach.repository';
import { HubVisitRepository } from './hub-visit.repository';

export class LabTestRepository extends DefaultCrudRepository<
  LabTest,
  typeof LabTest.prototype.id,
  LabTestRelations
> {
  public readonly user: BelongsToAccessor<Users, typeof Users.prototype.id>;
  public readonly createdByCoach: BelongsToAccessor<Coach, typeof Coach.prototype.id>;
  public readonly hubVisit: BelongsToAccessor<HubVisit, typeof HubVisit.prototype.id>;
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('UsersRepository') usersRepositoryGetter: Getter<UsersRepository>,
    @repository.getter('CoachRepository') coachRepositoryGetter: Getter<CoachRepository>,
    @repository.getter('HubVisitRepository') hubVisitRepositoryGetter: Getter<HubVisitRepository>,
  ) {
    super(LabTest, dataSource);
    this.user = this.createBelongsToAccessorFor('user', usersRepositoryGetter);
    this.registerInclusionResolver('user', this.user.inclusionResolver);

    this.createdByCoach = this.createBelongsToAccessorFor('createdByCoach', coachRepositoryGetter);
    this.registerInclusionResolver('createdByCoach', this.createdByCoach.inclusionResolver);

    this.hubVisit = this.createBelongsToAccessorFor('hubVisit', hubVisitRepositoryGetter);
    this.registerInclusionResolver('hubVisit', this.hubVisit.inclusionResolver);
  }
}
