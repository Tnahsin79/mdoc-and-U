import { DefaultCrudRepository } from '@loopback/repository';
import { Affordablity, AffordablityRelations } from '../models';
import { DbDataSource } from '../datasources';
import { inject } from '@loopback/core';

export class AffordablityRepository extends DefaultCrudRepository<
  Affordablity,
  typeof Affordablity.prototype.id,
  AffordablityRelations
  > {
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
  ) {
    super(Affordablity, dataSource);

    (this.modelClass as any).observe('persist', async (ctx: any) => {
      ctx.data.modified = new Date();
    });

  }
}
