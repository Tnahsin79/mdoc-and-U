import {DefaultCrudRepository} from '@loopback/repository';
import {Resources, ResourcesRelations} from '../models';
import {DbDataSource} from '../datasources';
import {inject} from '@loopback/core';

export class ResourcesRepository extends DefaultCrudRepository<
  Resources,
  typeof Resources.prototype.id,
  ResourcesRelations
> {
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
  ) {
    super(Resources, dataSource);
  }
}
