import {
  repository,
  BelongsToAccessor,
  DefaultCrudRepository,
} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {inject, Getter} from '@loopback/core';
import {UsersRepository} from './users.repository';
import {BlogPostRepository} from './blog-post.repository';
import {Like, LikeRelations, Users, BlogPost} from '../models';

export class LikeRepository extends DefaultCrudRepository<
  Like,
  typeof Like.prototype.id,
  LikeRelations
> {
  public readonly user: BelongsToAccessor<Users, typeof Users.prototype.id>;
  public readonly blogPost: BelongsToAccessor<
    BlogPost,
    typeof BlogPost.prototype.id
  >;
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('UsersRepository')
    public usersRepositoryGitter: Getter<UsersRepository>,
    @repository.getter('BlogPostRepository')
    public blogPostRepositoryGitter: Getter<BlogPostRepository>,
  ) {
    super(Like, dataSource);

    this.user = this.createBelongsToAccessorFor('user', usersRepositoryGitter);
    this.blogPost = this.createBelongsToAccessorFor(
      'blogPost',
      blogPostRepositoryGitter,
    );

    this.registerInclusionResolver('user', this.user.inclusionResolver);
    this.registerInclusionResolver('blogPost', this.blogPost.inclusionResolver);

    (this.modelClass as any).observe('persist', async (ctx: any) => {
      ctx.data.modified = new Date();
    });
  }
}
