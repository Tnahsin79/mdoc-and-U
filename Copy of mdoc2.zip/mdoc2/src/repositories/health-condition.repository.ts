import {
  Users,
  Disease,
  HubVisit,
  HealthCondition,
  HealthConditionRelations,
} from '../models';
import {
  repository,
  BelongsToAccessor,
  DefaultCrudRepository,
} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {inject, Getter} from '@loopback/core';
import {UsersRepository} from './users.repository';
import {DiseaseRepository} from './disease.repository';
import { HubVisitRepository } from './hub-visit.repository';

export class HealthConditionRepository extends DefaultCrudRepository<
  HealthCondition,
  typeof HealthCondition.prototype.id,
  HealthConditionRelations
> {
  public readonly user: BelongsToAccessor<Users, typeof Users.prototype.id>;
  public readonly disease: BelongsToAccessor<
    Disease,
    typeof Disease.prototype.id
  >;
  public readonly hubVisit: BelongsToAccessor<
    HubVisit,
    typeof HubVisit.prototype.id
  >;
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('UsersRepository')
    public usersRepositoryGitter: Getter<UsersRepository>,
    @repository.getter('DiseaseRepository')
    public diseaseRepositoryGitter: Getter<DiseaseRepository>,
    @repository.getter('HubVisitRepository')
    hubVisitRepositoryGetter: Getter<HubVisitRepository>,
  ) {
    super(HealthCondition, dataSource);

    this.user = this.createBelongsToAccessorFor('user', usersRepositoryGitter);
    this.disease = this.createBelongsToAccessorFor(
      'disease',
      diseaseRepositoryGitter,
    );

    this.registerInclusionResolver('user', this.user.inclusionResolver);
    this.registerInclusionResolver('disease', this.disease.inclusionResolver);
    this.hubVisit = this.createBelongsToAccessorFor(
      'hubVisit',
      hubVisitRepositoryGetter,
    );
    this.registerInclusionResolver('hubVisit', this.hubVisit.inclusionResolver);

    (this.modelClass as any).observe('persist', async (ctx: any) => {
      ctx.data.modified = new Date();
    });
  }
}
