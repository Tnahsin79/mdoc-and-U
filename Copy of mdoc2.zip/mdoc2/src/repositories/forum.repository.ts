import {
  BelongsToAccessor,
  DefaultCrudRepository,
  HasManyRepositoryFactory,
  repository,
} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Getter, inject} from '@loopback/core';
import {CoachRepository} from './coach.repository';
import {AdminRepository} from './admin.repository';
import {ForumUserRepository} from './forum-user.repository';
import {Admin, Coach, Forum, ForumRelations, ForumUser, Programs} from '../models';
import { ProgramsRepository } from './programs.repository';

export class ForumRepository extends DefaultCrudRepository<
  Forum,
  typeof Forum.prototype.id,
  ForumRelations
> {
  public readonly createdBy: BelongsToAccessor<
    Coach,
    typeof Coach.prototype.id
  >;
  public readonly approver: BelongsToAccessor<Admin, typeof Admin.prototype.id>;
  public readonly program: BelongsToAccessor<Programs, typeof Programs.prototype.id>;
  public readonly participants: HasManyRepositoryFactory<
    ForumUser,
    typeof ForumUser.prototype.id
  >;
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('CoachRepository')
    public coachRepositoryGetter: Getter<CoachRepository>,
    @repository.getter('AdminRepository')
    public adminRepositoryGetter: Getter<AdminRepository>,
    @repository.getter('ForumUserRepository')
    forumUserRepositoryGetter: Getter<ForumUserRepository>,
    @repository.getter('ProgramsRepository')
    programsRepositoryGetter: Getter<ProgramsRepository>,
  ) {
    super(Forum, dataSource);

    this.program = this.createBelongsToAccessorFor(
      'program',
      programsRepositoryGetter,
    );
    this.createdBy = this.createBelongsToAccessorFor(
      'createdBy',
      coachRepositoryGetter,
    );
    this.approver = this.createBelongsToAccessorFor(
      'approver',
      adminRepositoryGetter,
    );
    this.participants = this.createHasManyRepositoryFactoryFor(
      'participants',
      forumUserRepositoryGetter,
    );
    this.registerInclusionResolver(
      'createdBy',
      this.createdBy.inclusionResolver,
    );
    this.registerInclusionResolver('approver', this.approver.inclusionResolver);
    this.registerInclusionResolver('program', this.program.inclusionResolver);
    this.registerInclusionResolver(
      'participants',
      this.participants.inclusionResolver,
    );
  }
}
