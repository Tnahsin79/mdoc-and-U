import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {BroadcastGroup, BroadcastGroupRelations} from '../models';

export class BroadcastGroupRepository extends DefaultCrudRepository<
  BroadcastGroup,
  typeof BroadcastGroup.prototype.id,
  BroadcastGroupRelations
> {
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
  ) {
    super(BroadcastGroup, dataSource);
  }
}
