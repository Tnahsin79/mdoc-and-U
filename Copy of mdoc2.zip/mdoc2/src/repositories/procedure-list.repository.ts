import {inject} from '@loopback/core';
import {DbDataSource} from '../datasources';
import {DefaultCrudRepository} from '@loopback/repository';
import {ProcedureList, ProcedureListRelations} from '../models';

export class ProcedureListRepository extends DefaultCrudRepository<
  ProcedureList,
  typeof ProcedureList.prototype.id,
  ProcedureListRelations
> {
  constructor(@inject('datasources.db') dataSource: DbDataSource) {
    super(ProcedureList, dataSource);
  }
}
