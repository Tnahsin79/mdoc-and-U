import {
  Coach,
  Users,
  Comment,
  BlogPost,
  CommentReply,
  CommentRelations,
} from '../models';
import {
  repository,
  BelongsToAccessor,
  DefaultCrudRepository,
  HasManyRepositoryFactory,
} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {inject, Getter} from '@loopback/core';
import {UsersRepository} from './users.repository';
import {CoachRepository} from './coach.repository';
import {BlogPostRepository} from './blog-post.repository';
import {CommentReplyRepository} from './comment-reply.repository';

export class CommentRepository extends DefaultCrudRepository<
  Comment,
  typeof Comment.prototype.id,
  CommentRelations
> {
  public readonly user: BelongsToAccessor<Users, typeof Users.prototype.id>;
  public readonly blogPost: BelongsToAccessor<
    BlogPost,
    typeof BlogPost.prototype.id
  >;
  public readonly coach: BelongsToAccessor<Coach, typeof Coach.prototype.id>;
  public readonly replies: HasManyRepositoryFactory<
    CommentReply,
    typeof CommentReply.prototype.id
  >;
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('UsersRepository')
    public usersRepositoryGitter: Getter<UsersRepository>,
    @repository.getter('BlogPostRepository')
    public blogPostRepositoryGitter: Getter<BlogPostRepository>,
    @repository.getter('CoachRepository')
    public coachRepositoryGetter: Getter<CoachRepository>,
    @repository.getter('CommentReplyRepository')
    public commentReplyRepositoryGetter: Getter<CommentReplyRepository>,
  ) {
    super(Comment, dataSource);

    this.user = this.createBelongsToAccessorFor('user', usersRepositoryGitter);
    this.blogPost = this.createBelongsToAccessorFor(
      'blogPost',
      blogPostRepositoryGitter,
    );
    this.coach = this.createBelongsToAccessorFor(
      'coach',
      coachRepositoryGetter,
    );
    this.replies = this.createHasManyRepositoryFactoryFor(
      'replies',
      commentReplyRepositoryGetter,
    );
    this.registerInclusionResolver('user', this.user.inclusionResolver);
    this.registerInclusionResolver('blogPost', this.blogPost.inclusionResolver);
    this.registerInclusionResolver('coach', this.coach.inclusionResolver);
    this.registerInclusionResolver('replies', this.replies.inclusionResolver);

    (this.modelClass as any).observe('persist', async (ctx: any) => {
      ctx.data.modified = new Date();
    });
  }
}
