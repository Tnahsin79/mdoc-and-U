import {Getter, inject} from '@loopback/core';
import {DefaultCrudRepository, HasManyRepositoryFactory, repository} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Privilege, PrivilegeGroup, PrivilegeGroupRelations} from '../models';
import { PrivilegeRepository } from './privilege.repository';

export class PrivilegeGroupRepository extends DefaultCrudRepository<
  PrivilegeGroup,
  typeof PrivilegeGroup.prototype.id,
  PrivilegeGroupRelations
> {
  public readonly privileges: HasManyRepositoryFactory<
    Privilege,
    typeof Privilege.prototype.id>;
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('PrivilegeRepository') public privilegeRepositoryGetter: Getter<PrivilegeRepository>,

  ) {
    super(PrivilegeGroup, dataSource);
    this.privileges = this.createHasManyRepositoryFactoryFor(
      'privileges',
      privilegeRepositoryGetter,
    );
    this.registerInclusionResolver('privileges', this.privileges.inclusionResolver);
  }
}
