import {
  Like,
  Admin,
  Comment,
  BlogPost,
  ReportPost,
  BlogPostRelations,
} from '../models';
import {
  repository,
  BelongsToAccessor,
  DefaultCrudRepository,
  HasManyRepositoryFactory,
} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Getter, inject} from '@loopback/core';
import {LikeRepository} from './like.repository';
import {AdminRepository} from './admin.repository';
import {CommentRepository} from './comment.repository';
import {ReportPostRepository} from './report-post.repository';

export class BlogPostRepository extends DefaultCrudRepository<
  BlogPost,
  typeof BlogPost.prototype.id,
  BlogPostRelations
> {
  public readonly creator: BelongsToAccessor<Admin, typeof Admin.prototype.id>;
  public readonly likes: HasManyRepositoryFactory<
    Like,
    typeof Like.prototype.id
  >;
  public readonly comments: HasManyRepositoryFactory<
    Comment,
    typeof Comment.prototype.id
  >;
  public readonly reportPost: HasManyRepositoryFactory<
    ReportPost,
    typeof ReportPost.prototype.id
  >;
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('AdminRepository')
    creatorRepositoryGetter: Getter<AdminRepository>,
    @repository.getter('LikeRepository')
    likesRepositoryGetter: Getter<LikeRepository>,
    @repository.getter('CommentRepository')
    commentsRepositoryGetter: Getter<CommentRepository>,
    @repository.getter('ReportPostRepository')
    reportPostRepositoryGetter: Getter<ReportPostRepository>,
  ) {
    super(BlogPost, dataSource);
    this.creator = this.createBelongsToAccessorFor(
      'creator',
      creatorRepositoryGetter,
    );
    this.likes = this.createHasManyRepositoryFactoryFor(
      'likes',
      likesRepositoryGetter,
    );
    this.comments = this.createHasManyRepositoryFactoryFor(
      'comments',
      commentsRepositoryGetter,
    );
    this.reportPost = this.createHasManyRepositoryFactoryFor(
      'reportPost',
      reportPostRepositoryGetter,
    );
    this.registerInclusionResolver('creator', this.creator.inclusionResolver);
    this.registerInclusionResolver('likes', this.likes.inclusionResolver);
    this.registerInclusionResolver('comments', this.comments.inclusionResolver);
    this.registerInclusionResolver(
      'reportPost',
      this.reportPost.inclusionResolver,
    );
  }
}
