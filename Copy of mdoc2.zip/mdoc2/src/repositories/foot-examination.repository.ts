import {DefaultCrudRepository} from '@loopback/repository';
import {FootExamination, FootExaminationRelations} from '../models';
import {DbDataSource} from '../datasources';
import {inject} from '@loopback/core';

export class FootExaminationRepository extends DefaultCrudRepository<
  FootExamination,
  typeof FootExamination.prototype.id,
  FootExaminationRelations
> {
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
  ) {
    super(FootExamination, dataSource);
  }
}
