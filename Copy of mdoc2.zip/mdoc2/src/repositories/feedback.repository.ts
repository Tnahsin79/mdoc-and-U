import {
  Admin,
  Feedback,
  FeedbackRelations,
  Programs,
  Question,
} from '../models';
import {
  BelongsToAccessor,
  DefaultCrudRepository,
  HasManyRepositoryFactory,
  repository,
} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Getter, inject} from '@loopback/core';
import {AdminRepository} from './admin.repository';
import {ProgramsRepository} from './programs.repository';
import {QuestionRepository} from './question.repository';

export class FeedbackRepository extends DefaultCrudRepository<
  Feedback,
  typeof Feedback.prototype.id,
  FeedbackRelations
> {
  public readonly creator: BelongsToAccessor<Admin, typeof Admin.prototype.id>;
  public readonly program: BelongsToAccessor<
    Programs,
    typeof Programs.prototype.id
  >;
  public readonly approvedBy: BelongsToAccessor<
    Admin,
    typeof Admin.prototype.id
  >;
  public readonly questions: HasManyRepositoryFactory<
    Question,
    typeof Question.prototype.id
  >;
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('AdminRepository')
    adminRepositoryGetter: Getter<AdminRepository>,
    @repository.getter('ProgramsRepository')
    programsRepositoryGetter: Getter<ProgramsRepository>,
    @repository.getter('QuestionRepository')
    questionsRepositoryGetter: Getter<QuestionRepository>,
  ) {
    super(Feedback, dataSource);
    this.creator = this.createBelongsToAccessorFor(
      'creator',
      adminRepositoryGetter,
    );
    this.program = this.createBelongsToAccessorFor(
      'program',
      programsRepositoryGetter,
    );
    this.approvedBy = this.createBelongsToAccessorFor(
      'approvedBy',
      adminRepositoryGetter,
    );
    this.questions = this.createHasManyRepositoryFactoryFor(
      'questions',
      questionsRepositoryGetter,
    );

    this.registerInclusionResolver('creator', this.creator.inclusionResolver);
    this.registerInclusionResolver('program', this.program.inclusionResolver);
    this.registerInclusionResolver(
      'approvedBy',
      this.approvedBy.inclusionResolver,
    );
    this.registerInclusionResolver(
      'questions',
      this.questions.inclusionResolver,
    );
  }
}
