import {
  BelongsToAccessor,
  DefaultCrudRepository,
  repository,
} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Getter, inject} from '@loopback/core';
import {UsersRepository} from './users.repository';
import {ForumRepository} from './forum.repository';
import {Forum, ForumUser, ForumUserRelations, Users} from '../models';

export class ForumUserRepository extends DefaultCrudRepository<
  ForumUser,
  typeof ForumUser.prototype.id,
  ForumUserRelations
> {
  public readonly forum: BelongsToAccessor<Forum, typeof Forum.prototype.id>;
  public readonly user: BelongsToAccessor<Users, typeof Users.prototype.id>;
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('UsersRepository')
    public usersRepositoryGetter: Getter<UsersRepository>,
    @repository.getter('ForumRepository')
    public forumRepositoryGetter: Getter<ForumRepository>,
  ) {
    super(ForumUser, dataSource);
    this.forum = this.createBelongsToAccessorFor(
      'forum',
      forumRepositoryGetter,
    );
    this.user = this.createBelongsToAccessorFor('user', usersRepositoryGetter);

    this.registerInclusionResolver('forum', this.forum.inclusionResolver);
    this.registerInclusionResolver('user', this.user.inclusionResolver);
  }
}
