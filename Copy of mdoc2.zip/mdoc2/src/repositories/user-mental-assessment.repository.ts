import {
  Users,
  Question,
  UserMentalAssessment,
  UserMentalAssessmentRecord,
} from '../models';
import {
  repository,
  BelongsToAccessor,
  DefaultCrudRepository,
} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Getter, inject} from '@loopback/core';
import {UsersRepository} from './users.repository';
import {QuestionRepository} from './question.repository';
import {UserMentalAssessmentRecordRepository} from './user-mental-assessment-record.repository';

export class UserMentalAssessmentRepository extends DefaultCrudRepository<
  UserMentalAssessment,
  typeof UserMentalAssessment.prototype.id
> {
  public readonly user: BelongsToAccessor<Users, typeof Users.prototype.id>;
  public readonly question: BelongsToAccessor<
    Question,
    typeof Question.prototype.id
  >;
  public readonly userMentalAssessmentRecord: BelongsToAccessor<
    UserMentalAssessmentRecord,
    typeof UserMentalAssessmentRecord.prototype.id
  >;
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('UsersRepository')
    usersRepositoryGetter: Getter<UsersRepository>,
    @repository.getter('QuestionRepository')
    questionRepositoryGetter: Getter<QuestionRepository>,
    @repository.getter('UserMentalAssessmentRecordRepository')
    userMentalAssessmentRecordRepositoryGetter: Getter<
      UserMentalAssessmentRecordRepository
    >,
  ) {
    super(UserMentalAssessment, dataSource);
    this.user = this.createBelongsToAccessorFor('user', usersRepositoryGetter);
    this.question = this.createBelongsToAccessorFor(
      'question',
      questionRepositoryGetter,
    );
    this.userMentalAssessmentRecord = this.createBelongsToAccessorFor(
      'userMentalAssessmentRecord',
      userMentalAssessmentRecordRepositoryGetter,
    );
    this.registerInclusionResolver('user', this.user.inclusionResolver);
    this.registerInclusionResolver('question', this.question.inclusionResolver);
    this.registerInclusionResolver(
      'userMentalAssessmentRecord',
      this.userMentalAssessmentRecord.inclusionResolver,
    );
  }
}
