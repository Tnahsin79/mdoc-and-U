import {
    BelongsToAccessor,
    DefaultCrudRepository,
    HasManyRepositoryFactory,
    repository,
  } from '@loopback/repository';
  import {Admin, Programs, Option, OptionRelations, Question} from '../models';
  import {DbDataSource} from '../datasources';
  import {Getter, inject} from '@loopback/core';
import { QuestionRepository } from './question.repository';
  
  export class OptionRepository extends DefaultCrudRepository<
    Option,
    typeof Option.prototype.id,
    OptionRelations
  > {
    public readonly admin: BelongsToAccessor<
      Admin,
      typeof Admin.prototype.id
    >;
    public readonly program: BelongsToAccessor<
      Programs,
      typeof Programs.prototype.id
    >;
    public readonly question: BelongsToAccessor<
      Question,
      typeof Question.prototype.id
    >;
    constructor(
      @inject('datasources.db') dataSource: DbDataSource,
      @repository.getter('QuestionRepository')
      questionRepositoryGetter: Getter<QuestionRepository>,
    ) {
      super(Option, dataSource);
      this.question = this.createBelongsToAccessorFor(
        'question',
        questionRepositoryGetter,
      );
      this.registerInclusionResolver('question', this.question.inclusionResolver);
    }
  }
  