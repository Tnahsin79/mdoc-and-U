import { DefaultCrudRepository, BelongsToAccessor, repository } from '@loopback/repository';
import { Review, ReviewRelations, Users } from '../models';
import { DbDataSource } from '../datasources';
import { inject, Getter } from '@loopback/core';
import { UsersRepository } from './users.repository';

export class ReviewRepository extends DefaultCrudRepository<Review, typeof Review.prototype.id, ReviewRelations> {
  public readonly reviewer: BelongsToAccessor<Users, typeof Users.prototype.id>;
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('UsersRepository') public usersRepositoryGitter: Getter<UsersRepository>,
  ) {
    super(Review, dataSource);

    this.reviewer = this.createBelongsToAccessorFor('reviewer', usersRepositoryGitter);

    this.registerInclusionResolver('reviewer', this.reviewer.inclusionResolver);

    (this.modelClass as any).observe('persist', async (ctx: any) => {
      ctx.data.modified = new Date();
    });
  }
}
