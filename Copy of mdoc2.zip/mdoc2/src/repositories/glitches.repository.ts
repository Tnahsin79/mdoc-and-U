import {
  repository,
  BelongsToAccessor,
  DefaultCrudRepository,
} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Getter, inject} from '@loopback/core';
import {Coach, Consult, Glitches, GlitchesRelations} from '../models';
import { ConsultRepository } from './consult.repository';
import { CoachRepository } from './coach.repository';

export class GlitchRepository extends DefaultCrudRepository<
  Glitches,
  typeof Glitches.prototype.id,
  GlitchesRelations
> {
  public readonly consult: BelongsToAccessor<Consult, typeof Consult.prototype.id>;
  public readonly createdByCoach: BelongsToAccessor<Coach, typeof Coach.prototype.id>;
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('ConsultRepository')
    consultRepositoryGetter: Getter<ConsultRepository>,
    @repository.getter('CoachRepository')
    adminRepositoryGetter: Getter<CoachRepository>,
  ) {
    super(Glitches, dataSource);
    this.consult = this.createBelongsToAccessorFor('consult', consultRepositoryGetter);
    this.createdByCoach = this.createBelongsToAccessorFor('createdByCoach',adminRepositoryGetter);

    this.registerInclusionResolver('consult', this.consult.inclusionResolver);
    this.registerInclusionResolver('createdByCoach', this.createdByCoach.inclusionResolver);
  }
}
