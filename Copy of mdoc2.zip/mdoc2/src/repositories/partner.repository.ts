import {
  DefaultCrudRepository, HasOneRepositoryFactory, repository,
} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Getter, inject} from '@loopback/core';
import {Coach, Partner, PartnerRelations} from '../models';
import { CoachRepository } from './coach.repository';

export class PartnerRepository extends DefaultCrudRepository<
  Partner,
  typeof Partner.prototype.id,
  PartnerRelations
> {
  public readonly coachAccount: HasOneRepositoryFactory<
    Coach,
    typeof Coach.prototype.id
  >;
  constructor(@inject('datasources.db') dataSource: DbDataSource,
  @repository.getter('CoachRepository')
  coachRepositoryGetter: Getter<CoachRepository>,) {
    super(Partner, dataSource);
    this.coachAccount = this.createHasOneRepositoryFactoryFor(
      'coachAccount',
      coachRepositoryGetter,
    );
    this.registerInclusionResolver(
      'coachAccount',
      this.coachAccount.inclusionResolver,
    );
  }
}
