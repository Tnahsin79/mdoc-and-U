import {
  BelongsToAccessor,
  DefaultCrudRepository,
  repository,
} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Getter, inject} from '@loopback/core';
import { HubUserFeedback, HubUserFeedbackRelations, HubVisit, UserFeedback, Users} from '../models';
import { UserFeedbackRepository } from './user-feedback.repository';
import { HubVisitRepository } from './hub-visit.repository';

export class HubUserFeedbackRepository extends DefaultCrudRepository<
  HubUserFeedback,
  typeof HubUserFeedback.prototype.id,
  HubUserFeedbackRelations
> {
  public readonly userFeedback: BelongsToAccessor<UserFeedback, typeof Users.prototype.id>;
  public readonly hubVisit: BelongsToAccessor<HubVisit, typeof HubVisit.prototype.id>;
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('UserFeedbackRepository')
    userfeedbackRepositoryGetter: Getter<UserFeedbackRepository>,

    @repository.getter('HubVisitRepository')
    hubVisitRepositoryGetter: Getter<HubVisitRepository>,
  ) {
    super(HubUserFeedback, dataSource);
    this.userFeedback = this.createBelongsToAccessorFor('userFeedback', userfeedbackRepositoryGetter);
    this.registerInclusionResolver('userFeedback', this.userFeedback.inclusionResolver);

    this.hubVisit = this.createBelongsToAccessorFor('hubVisit', hubVisitRepositoryGetter);
    this.registerInclusionResolver('hubVisit', this.hubVisit.inclusionResolver);
  }
}
