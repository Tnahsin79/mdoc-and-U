import {
  BelongsToAccessor,
  DefaultCrudRepository,
  HasManyRepositoryFactory,
  repository,
} from '@loopback/repository';
import {Chat, ChatRoom, ChatRoomRelations, Coach, Users} from '../models';
import {DbDataSource} from '../datasources';
import {Getter, inject} from '@loopback/core';
import {ChatRoomUser} from '../models/chat-room-user.model';
import {ChatRoomUserRepository} from './chat-room-user.repository';
import {CoachRepository} from './coach.repository';
import {ChatRepository} from './chat.repository';
import { UsersRepository } from './users.repository';

export class ChatRoomRepository extends DefaultCrudRepository<
  ChatRoom,
  typeof ChatRoom.prototype.id,
  ChatRoomRelations
> {
  // public readonly chatRoomUser: HasManyRepositoryFactory<
  //   ChatRoomUser,
  //   typeof ChatRoomUser.prototype.id
  // >;
  public readonly receiverCoach: BelongsToAccessor<
    Coach,
    typeof Coach.prototype.id
  >;
  public readonly receiverMember: BelongsToAccessor<
    Users,
    typeof Users.prototype.id
  >;
  public readonly chats: HasManyRepositoryFactory<
    Chat,
    typeof Chat.prototype.id
  >;
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('ChatRoomUserRepository')
    public chatRoomUserRepositoryGetter: Getter<ChatRoomUserRepository>,
    @repository.getter('CoachRepository')
    public coachRepositoryGetter: Getter<CoachRepository>,
    @repository.getter('ChatRepository')
    public chatRepository: Getter<ChatRepository>,
    @repository.getter('UsersRepository')
    public usersRepository: Getter<UsersRepository>,
  ) {
    super(ChatRoom, dataSource);
    this.receiverCoach = this.createBelongsToAccessorFor(
      'receiverCoach',
      coachRepositoryGetter,
    );
    this.registerInclusionResolver(
      'receiverCoach',
      this.receiverCoach.inclusionResolver,
    );
    this.receiverMember = this.createBelongsToAccessorFor(
      'receiverMember',
      usersRepository,
    );
    this.registerInclusionResolver(
      'receiverMember',
      this.receiverMember.inclusionResolver,
    );
    this.chats = this.createHasManyRepositoryFactoryFor(
      'chats',
      chatRepository,
    );
    this.registerInclusionResolver('chats', this.chats.inclusionResolver);
    // this.chatRoomUser = this.createHasManyRepositoryFactoryFor(
    //   'roomIds',
    //   chatRoomUserRepositoryGetter,
    // );
    // this.registerInclusionResolver(
    //   'roomIds',
    //   this.chatRoomUser.inclusionResolver,
    // );
  }
}
