import {DefaultCrudRepository, repository, BelongsToAccessor} from '@loopback/repository';
import { Notice, UserNotice, UserNoticeRelations,Users,} from '../models';
import {DbDataSource} from '../datasources';
import {Getter, inject} from '@loopback/core';
import { UsersRepository } from './users.repository';
import { NoticeRepository } from './notice.repository';

export class UserNoticeRepository extends DefaultCrudRepository<
  UserNotice,
  typeof UserNotice.prototype.id,
  UserNoticeRelations
> {
    public readonly user: BelongsToAccessor<Users, typeof Users.prototype.id>;
    public readonly notice: BelongsToAccessor<Notice, typeof Notice.prototype.id>;
    constructor(
        @inject('datasources.db') dataSource: DbDataSource,
        @repository.getter('UsersRepository')
        userRepositoryGetter: Getter<UsersRepository>,
        @repository.getter('NoticeRepository')
        noticeRepositoryGetter: Getter<NoticeRepository>,
    ) {
        super(UserNotice, dataSource);
        this.user = this.createBelongsToAccessorFor(
        'user',
        userRepositoryGetter,
        );
        this.notice = this.createBelongsToAccessorFor(
        'notice',
        noticeRepositoryGetter,
        );
        this.registerInclusionResolver('notice', this.notice.inclusionResolver);
        this.registerInclusionResolver('user', this.user.inclusionResolver)
    }
}
