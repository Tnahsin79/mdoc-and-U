import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {OutlierLogs, OutlierLogsRelations} from '../models';

export class OutlierLogsRepository extends DefaultCrudRepository<
  OutlierLogs,
  typeof OutlierLogs.prototype.id,
  OutlierLogsRelations
> {
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
  ) {
    super(OutlierLogs, dataSource);
  }
}
