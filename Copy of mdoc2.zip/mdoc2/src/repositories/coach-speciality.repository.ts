import {
  Coach,
  CoachSpeciality,
  CoachSpecialityRelations,
  Speciality,
} from '../models';
import {
  BelongsToAccessor,
  DefaultCrudRepository,
  repository,
} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {inject, Getter} from '@loopback/core';
import {CoachRepository} from './coach.repository';
import {SpecialityRepository} from './speciality.repository';

export class CoachSpecialityRepository extends DefaultCrudRepository<
  CoachSpeciality,
  typeof CoachSpeciality.prototype.id,
  CoachSpecialityRelations
> {
  public readonly coach: BelongsToAccessor<Coach, typeof Coach.prototype.id>;
  public readonly speciality: BelongsToAccessor<
    Speciality,
    typeof Speciality.prototype.id
  >;

  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('CoachRepository')
    public coachRepositoryGetter: Getter<CoachRepository>,
    @repository.getter('SpecialityRepository')
    public specialityRepositoryGetter: Getter<SpecialityRepository>,
  ) {
    super(CoachSpeciality, dataSource);
    this.coach = this.createBelongsToAccessorFor(
      'coach',
      coachRepositoryGetter,
    );
    this.speciality = this.createBelongsToAccessorFor(
      'speciality',
      specialityRepositoryGetter,
    );
    this.registerInclusionResolver('coach', this.coach.inclusionResolver);
    this.registerInclusionResolver(
      'speciality',
      this.speciality.inclusionResolver,
    );
  }
}
