import { DefaultCrudRepository, BelongsToAccessor, repository } from '@loopback/repository';
import { Champions, ChampionsRelations, Users } from '../models';
import { DbDataSource } from '../datasources';
import { inject, Getter } from '@loopback/core';
import { UsersRepository } from './users.repository';

export class ChampionsRepository extends DefaultCrudRepository<Champions, typeof Champions.prototype.id, ChampionsRelations> {
  public readonly champion: BelongsToAccessor<Users, typeof Users.prototype.id>;
  public readonly star: BelongsToAccessor<Users, typeof Users.prototype.id>;
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('UsersRepository') public usersRepositoryGitter: Getter<UsersRepository>,
  ) {
    super(Champions, dataSource);

    this.champion = this.createBelongsToAccessorFor('champion', usersRepositoryGitter);
    this.star = this.createBelongsToAccessorFor('star', usersRepositoryGitter);

    this.registerInclusionResolver('champion', this.champion.inclusionResolver);
    this.registerInclusionResolver('star', this.star.inclusionResolver);

    (this.modelClass as any).observe('persist', async (ctx: any) => {
      ctx.data.modified = new Date();
    });
  }
}
