import {
  Goal,
  Users,
  GroupGoalParticipant,
  GroupGoalParticipantRelations,
} from '../models';
import {
  repository,
  BelongsToAccessor,
  DefaultCrudRepository,
} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Getter, inject} from '@loopback/core';
import {GoalRepository} from './goal.repository';
import {UsersRepository} from './users.repository';

export class GroupGoalParticipantRepository extends DefaultCrudRepository<
  GroupGoalParticipant,
  typeof GroupGoalParticipant.prototype.id,
  GroupGoalParticipantRelations
> {
  public readonly goal: BelongsToAccessor<Goal, typeof Goal.prototype.id>;
  public readonly user: BelongsToAccessor<Users, typeof Users.prototype.id>;
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
    @repository.getter('UsersRepository')
    usersRepositoryGetter: Getter<UsersRepository>,
    @repository.getter('GoalRepository')
    goalRepositoryGetter: Getter<GoalRepository>,
  ) {
    super(GroupGoalParticipant, dataSource);

    this.user = this.createBelongsToAccessorFor('user', usersRepositoryGetter);
    this.goal = this.createBelongsToAccessorFor('goal', goalRepositoryGetter);
    this.registerInclusionResolver('user', this.user.inclusionResolver);
    this.registerInclusionResolver('goal', this.goal.inclusionResolver);
  }
}
