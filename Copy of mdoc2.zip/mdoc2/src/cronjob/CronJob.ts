import { CronController } from '../controllers/cron.controller';
const cron = require('node-cron');

export class CronJob {
  constructor(
    protected cronController: CronController,
  ) {
  }

  async start() {
    this.eachMinute();
  }

  private async eachMinute() {
    console.log('Start Cron Jobs');

    cron.schedule('0 0 * * *', async () => {
      await this.cronController.subscriptionNotification()
      console.log('Updating notification in every mid night');
    })
  }
}
