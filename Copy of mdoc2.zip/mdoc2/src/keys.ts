import {Users} from './models';
import {Credentials} from './type-schema';
import {BindingKey} from '@loopback/context';
import {ControllerService} from './services/controller.service';
import {FCMService} from './services/fcm.service';
import {MigrationService} from './services/migration.service';
import {MigrationServiceV2} from './services/migration-v2.service';
import {TokenService, UserService} from '@loopback/authentication';
import {
  EmailService,
  PdfService,
  PasswordHasher,
  AdminService,
  AppReleaseService,
  BloodPressureService,
  BloodSugarService,
  BroadcastGroupService,
  BroadcastMessageService,
  CholestrolService,
  CoachUserSubscriptionsService,
  ExerciseService,
  ForumService,
  ForumUserService,
  HbaicService,
  HeightService,
  PregnancyLogService,
  PsaService,
  ReferralReasonService,
  ReportPostService,
  WaistCircumferenceService,
  WeightService,
  PrivilegeGroupService,
  PrivilegeService,
  RoleService,
  CommentReplyService,
  CalenderEventService,
  FeedbackService,
  HealthDairyMigrationService,
  UserFeedbackService,
  UserMentalAssessmentService,
  ActivityTimelineService,
  VoucherService,
  OutlierService,
  DashboardStatisticsService,
  BmiService,
  KemMessageService,
  ProductService,
  TemperatureService,
  ThroveService,
  CareerService,
  PublicationService,
  NoticeService,
  UserNoticeService,
  GoalService,
  GoalActionService,
  LabTestService,
  ConsultGlitchesService,
} from './services';
import {HealthDiaryService} from './services/health-diary.service';
import {CoachService} from './services/coach.service';
import {AppointmentService} from './services/appointment.service';
import {FrequencyService} from './services/frequency.service';
import {ProgramsService} from './services/programs.service';
import {SpecialityService} from './services/speciality.service';
import {UserServiceExtention} from './services/usersServiceExtended';
import {NoteService} from './services/note.service';
import {CommunicationLogService} from './services/communication-log.service';
import {UserSubscriptionsService} from './services/user-subscriptions.service';
import {HealthConditionService} from './services/health-condition.service';
import {AffordablityService} from './services/affordability.service';
import {BasicHealthInformationService} from './services/basic-health-information.service';
import {BlaService} from './services/bla.service';
import {BlockedUsersService} from './services/blocked-users.service';
import {CategoryService} from './services/category.service';
import {ChampionsService} from './services/champions.service';
import {ChatRoomService} from './services/chat-room.service';
import {ChatService} from './services/chat.service';
import {ChatServiceWs} from './services/chat.service.ws';
import {ChildrenService} from './services/children.service';
import {CoachTypeService} from './services/coach-type.service';
import {CommentService} from './services/comment.service';
import {CouponsService} from './services/coupons.service';
import {DiseaseService} from './services/disease.service';
import {ExerciseTypesService} from './services/exercise-types.service';
import {ExercisesService} from './services/exercises.service';
import {EyeExaminationService} from './services/eye-examination.service';
import {FootExaminationService} from './services/foot-examination.service';
import {HealthProcedureSurgeriesService} from './services/health-procedure-surgeries.service';
import {HealthQuestionService} from './services/health-question.service';
import {InsuranceService} from './services/insurance.service';
import {InterestSevice} from './services/interest.service';
import {JournalService} from './services/journal.service';
import {LabService} from './services/lab.service';
import {LabsProceduresService} from './services/labs-procedures.service';
import {LanguageService} from './services/language.service';
import {LikeService} from './services/like.service';
import {MedicationService} from './services/medication.service';
import {MedicationPassportService} from './services/medication-passport.service';
import {MyAssessmentsInformationService} from './services/my-assessments-information.service';
import {MyAssessmentsService} from './services/my-assessments.service';
import {NotificationService} from './services/notification.service';
import {NudgeHubsService} from './services/nudge-hubs.service';
import {OutlierLogsService} from './services/outlier-logs.service';
import {PatientService} from './services/patient.service';
import {PaymentsService} from './services/payments.service';
import {PharmacyService} from './services/pharmacy.service';
import {PlansService} from './services/plans.service';
import {BlogPostService} from './services/blog-post.service';
import {PregnancyService} from './services/pregnancy.service';
import {ProcedureSurgeriesService} from './services/procedure-surgeries.service';
import {ProjectsCategoryService} from './services/projects-category.service';
import {ProviderService} from './services/provider.service';
import {ReferralService} from './services/referral.service';
import {ReminderService} from './services/reminder.service';
import {ResourcesService} from './services/resources.service';
import {ReviewService} from './services/review.service';
import {SubscriptionService} from './services/subscription.service';
import {SymptomHealthConditionService} from './services/symptom-health-condition.service';
import {SymptomTypeService} from './services/symptom-type.service';
import {SymptomsService} from './services/symptoms.service';
import {TagService} from './services/tag.service';
import {TreatmentService} from './services/treatment.service';
import {UserDoctorsService} from './services/user-doctors.service';
import {UserLocationsService} from './services/user-locations.service';
import {UserPharmacyRecordsService} from './services/user-phamacy-records.service';
import {WaistgoalService} from './services/waistgoal.service';
import {WebinarService} from './services/webinars.service';
import {ReportCommentService} from './services/report-comment.service';
import {PregnancyCycleService} from './services/pregnancy-cycle.service';
import {QuestionService} from './services/question.service';
import {ProcedureListService} from './services/procedure-list.service';
import {ConsultService} from './services/consult.service';
import {HubVisitService} from './services';
import {PartnerService} from './services/partner.service';
import {SettingService} from './services/setting.service';
import {GoalLogsService} from './services/goal-logs.service';


export namespace TokenServiceConstants {
  export const TOKEN_SECRET_VALUE = 'amp13T0k3nS3cr3t';
  // export const TOKEN_EXPIRES_IN_VALUE = '31536000'; // 365 days(365 * 60 * 60 * 24)
  // export const TOKEN_EXPIRES_IN_VALUE = '120'; // 6 hours
  export const TOKEN_EXPIRES_IN_VALUE = '2592000'; // 30 days(30 * 60 * 60 * 24)
}

export namespace TokenServiceBindings {
  export const TOKEN_SECRET = BindingKey.create<string>(
    'authentication.jwt.secret',
  );
  export const TOKEN_EXPIRES_IN = BindingKey.create<string>(
    'authentication.jwt.expires.in.seconds',
  );
  export const TOKEN_SERVICE = BindingKey.create<TokenService>(
    'services.authentication.jwt.tokenservice',
  );
}

export namespace PasswordHasherBindings {
  export const PASSWORD_HASHER = BindingKey.create<PasswordHasher>(
    'services.hasher',
  );
  export const ROUNDS = BindingKey.create<number>('services.hasher.round');
}

export namespace UserServiceBindings {
  export const USER_SERVICE = BindingKey.create<
    UserService<Users, Credentials>
  >('services.user.service');
}

export namespace UserServiceExtensionBindings {
  export const USER_SERVICE_EXT = BindingKey.create<UserServiceExtention>(
    'usersserviceextended.service',
  );
}

export namespace EmailServiceBindings {
  export const MAIL_SERVICE = BindingKey.create<EmailService>(
    'mailer.services',
  );
}

export namespace PdfServiceBindings {
  export const PDF_SERVICE = BindingKey.create<PdfService>('pdf.services');
}

export namespace FCMServiceBindings {
  export const FCM_SERVICE = BindingKey.create<FCMService>('fcm.push.services');
}

export namespace ControllerServiceBindings {
  export const CONTROLLER_SERVICE = BindingKey.create<ControllerService>(
    'controller.service',
  );
}

export namespace MigrationServiceBindings {
  export const MIGRATION_SERVICE = BindingKey.create<MigrationService>(
    'migration.service',
  );
}

export namespace MigrationServiceV2Bindings {
  export const MIGRATION_SERVICE = BindingKey.create<MigrationServiceV2>(
    'migration.service.v2',
  );
}

export namespace HealthDairyMigrationServiceBindings {
  export const HEALTHDAIRY_MIGRATION_SERVICE = BindingKey.create<
    HealthDairyMigrationService
  >('healthDairyMigration.service');
}

export namespace AdminServiceBindings {
  export const ADMIN_SERVICE = BindingKey.create<AdminService>('admin.service');
}

export namespace AppReleaseServiceBindings {
  export const APP_RELEASE_SERVICE = BindingKey.create<AppReleaseService>(
    'app-release.service',
  );
}

export namespace ReferralReasonServiceBindings {
  export const REFERRAL_REASON_SERVICE = BindingKey.create<
    ReferralReasonService
  >('referralReason.service');
}

export namespace HealthDiaryServiceBindings {
  export const HEALTH_DIARY_SERVICE = BindingKey.create<HealthDiaryService>(
    'health-diary.service',
  );
}
export namespace CoachServiceBindings {
  export const COACH_SERVICE = BindingKey.create<CoachService>('coach.service');
}
export namespace BroadcastGroupServiceBinding {
  export const BROADCAST_GROUP_SERVICE_BINDING = BindingKey.create<
    BroadcastGroupService
  >('broadcast-group.service');
}

export namespace BroadcastMessageServiceBinding {
  export const BROADCAST_SERVICE_BINDING = BindingKey.create<
    BroadcastMessageService
  >('broadcast.service');
}
export namespace AppointmentServiceBindings {
  export const APPOINTMENT_SERVICE = BindingKey.create<AppointmentService>(
    'appointment.service',
  );
}
export namespace FrequencyServiceBindings {
  export const FREQUENCY_SERVICE = BindingKey.create<FrequencyService>(
    'frequency.service',
  );
}
export namespace ProgramsServiceBindings {
  export const PROGRAMS_SERVICE = BindingKey.create<ProgramsService>(
    'programs.service',
  );
}
export namespace SpecialityServiceBindings {
  export const SPECIALITY_SERVICE = BindingKey.create<SpecialityService>(
    'specialty.service',
  );
}
export namespace NoteServiceBindings {
  export const NOTES_SERVICE = BindingKey.create<NoteService>('notes.service');
}
export namespace CommunicationLogServiceBindings {
  export const COMMUNICATION_LOG = BindingKey.create<CommunicationLogService>(
    'communication-log.service',
  );
}

export namespace HealthConditionServiceBindings {
  export const HEALTH_CONDITION_SERVICE = BindingKey.create<
    HealthConditionService
  >('health-condition.service');
}

export namespace AffordablityServiceBindings {
  export const AFFORDABILITY_SERVICE = BindingKey.create<AffordablityService>(
    'affordablity.ervice',
  );
}

export namespace BasicHealthInformationServiceBindings {
  export const BASIC_HEALTH_INFORMATION_SERVICE = BindingKey.create<
    BasicHealthInformationService
  >('basic-health-information.service');
}

export namespace BlaServiceBindings {
  export const BLA_SERVICE = BindingKey.create<BlaService>('bla.service');
}

export namespace BlockedUsersServiceBindings {
  export const BLOCKED_USERS_SERVICE = BindingKey.create<BlockedUsersService>(
    'blocked-users.service',
  );
}

export namespace CategoryServiceBindings {
  export const CATEGORY_SERVICE = BindingKey.create<CategoryService>(
    'category.service',
  );
}

export namespace ChampionsServiceBindings {
  export const CHAMPIONS_SERVICE = BindingKey.create<ChampionsService>(
    'champions.service',
  );
}

export namespace ChatRoomServiceBindings {
  export const CHAT_ROOM_SERVICE = BindingKey.create<ChatRoomService>(
    'chat-room.service',
  );
}

export namespace ChatServiceBindings {
  export const CHAT_SERVICE = BindingKey.create<ChatService>('chat.service');
}

export namespace ChatServiceWsBindings {
  export const CHAT_WS_SERVICE = BindingKey.create<ChatServiceWs>(
    'chat-ws.service',
  );
}

export namespace ChildrenServiceBindings {
  export const CHILDREN_SERVICE = BindingKey.create<ChildrenService>(
    'children.service',
  );
}

export namespace CoachTypeServiceBindings {
  export const COACH_TYPE_SERVICE = BindingKey.create<CoachTypeService>(
    'coach-type.service',
  );
}

export namespace CommentServiceBindings {
  export const COMMENT_SERVICE = BindingKey.create<CommentService>(
    'comment.service',
  );
}
export namespace CouponsServiceBindings {
  export const COUPONS_SERVICE = BindingKey.create<CouponsService>(
    'coupons.service',
  );
}

export namespace DiseaseServiceBindings {
  export const DISEASE_SERVICE = BindingKey.create<DiseaseService>(
    'disease.service',
  );
}

export namespace ExerciseTypesServiceBindings {
  export const EXERCISE_TYPES_SERVICE = BindingKey.create<ExerciseTypesService>(
    'exercise-types.service',
  );
}

export namespace ExercisesServiceBindings {
  export const EXERCISES_SERVICE = BindingKey.create<ExercisesService>(
    'exercise.service',
  );
}

export namespace EyeExaminationServiceBindings {
  export const EYE_EXAMINATION_SERVICE = BindingKey.create<
    EyeExaminationService
  >('eye-examination.service');
}

export namespace FootExaminationServiceBindings {
  export const FOOT_EXAMINATION_SERVICE = BindingKey.create<
    FootExaminationService
  >('foot-examination.service');
}

export namespace HealthProcedureSurgeriesServiceBindings {
  export const HEALTH_PROCEDURE_SURGERIES_SERVICE = BindingKey.create<
    HealthProcedureSurgeriesService
  >('health-procedure-surgeries.service');
}

export namespace HealthQuestionServiceBindings {
  export const HEALTH_QUESTIONS_SERVICE = BindingKey.create<
    HealthQuestionService
  >('health-question.ervice');
}

export namespace QuestionServiceBindings {
  export const QUESTION_SERVICE = BindingKey.create<QuestionService>(
    'question.ervice',
  );
}

export namespace InsuranceServiceBindings {
  export const INSURANCE_SERVICE = BindingKey.create<InsuranceService>(
    'insurance.service',
  );
}

export namespace InterestSeviceBindings {
  export const INTEREST_SERVICE = BindingKey.create<InterestSevice>(
    'interest.sevice',
  );
}

export namespace JournalServiceBindings {
  export const JOURNAL_SERVICE = BindingKey.create<JournalService>(
    'journal.service',
  );
}

export namespace LabServiceBindings {
  export const LAB_SERVICE = BindingKey.create<LabService>('lab.service');
}

export namespace LabsProceduresServiceBindings {
  export const LABS_PROCEDURES_SERVICE = BindingKey.create<
    LabsProceduresService
  >('labsprocedures.service');
}

export namespace LanguageServiceBindings {
  export const LANGUAGE_SERVICE = BindingKey.create<LanguageService>(
    'language.service',
  );
}

export namespace LikeServiceBindings {
  export const LIKE_SERVICE = BindingKey.create<LikeService>('like.service');
}

export namespace MedicationServiceBindings {
  export const MEDICATION_SERVICE = BindingKey.create<MedicationService>(
    'medication.service',
  );
}

export namespace MedicationPassportServiceBindings {
  export const MEDICATION_PASSPORT_SERVICE = BindingKey.create<
    MedicationPassportService
  >('medication-passport.service');
}

export namespace MyAssessmentsInformationServiceBindings {
  export const MY_ASSESSMENT_INFORMATION_SERVICE_BINDINGS = BindingKey.create<
    MyAssessmentsInformationService
  >('my-assessments-information.service');
}

export namespace MyAssessmentsServiceBindings {
  export const MY_ASSESSMENT_SERVICE_BINDINGS = BindingKey.create<
    MyAssessmentsService
  >('my-assessments.service');
}

export namespace NotificationServiceBindings {
  export const NOTIFICATION_SERVICE = BindingKey.create<NotificationService>(
    'notification.service',
  );
}

export namespace NudgeHubsServiceBindings {
  export const NUDGE_HUBS_SERVICE = BindingKey.create<NudgeHubsService>(
    'nudge-hubs.service',
  );
}

export namespace OutlierLogsServiceBindings {
  export const OUTLIER_LOGS_SERVICE = BindingKey.create<OutlierLogsService>(
    'outlier-logs.service',
  );
}

export namespace PatientServiceBindings {
  export const PATIENT_SERVICE = BindingKey.create<PatientService>(
    'patient.service',
  );
}

export namespace PaymentsServiceBindings {
  export const PAYMENTS_SERVICE = BindingKey.create<PaymentsService>(
    'payemnts.service',
  );
}

export namespace PharmacyServiceBindings {
  export const PHARMACY_SERVICE = BindingKey.create<PharmacyService>(
    'pharmacy.service',
  );
}

export namespace PlansServiceBindings {
  export const PLANS_SERVICE = BindingKey.create<PlansService>('plans.service');
}

export namespace BlogPostServiceBindings {
  export const BLOG_POST_SERVICE = BindingKey.create<BlogPostService>(
    'post.service',
  );
}

export namespace PregnancyServiceBindings {
  export const PREGNANCY_SERVICE = BindingKey.create<PregnancyService>(
    'pregnancy.service',
  );
}

export namespace ProcedureSurgeriesServiceBindings {
  export const PROCEDURE_SURGERIES_SERVICE = BindingKey.create<
    ProcedureSurgeriesService
  >('procedure-surgeries.service');
}

export namespace ProjectsCategoryServiceBindings {
  export const PROJECTS_CATEGORY_SERVICE = BindingKey.create<
    ProjectsCategoryService
  >('projects-category.service');
}

export namespace ProviderServiceBindings {
  export const PROVIDER_SERVICE = BindingKey.create<ProviderService>(
    'provider.service',
  );
}

export namespace ReferralServiceBindings {
  export const REFERRAL_SERVICE = BindingKey.create<ReferralService>(
    'referral.service',
  );
}

export namespace ReminderServiceBindings {
  export const REMINDER_SERVICE = BindingKey.create<ReminderService>(
    'reminder.service',
  );
}

export namespace ResourcesServiceBindings {
  export const RESOURCES_SERVICE = BindingKey.create<ResourcesService>(
    'resources.service',
  );
}

export namespace ReviewServiceBindings {
  export const REVIEW_SERVICE = BindingKey.create<ReviewService>(
    'review.service',
  );
}

export namespace SubscriptionServiceBindings {
  export const SUBSCRIPTION_SERVICE = BindingKey.create<SubscriptionService>(
    'subscription.service',
  );
}

export namespace SymptomHealthConditionServiceBindings {
  export const SYMPTOM_HEALTH_CONDITION_SERVICE = BindingKey.create<
    SymptomHealthConditionService
  >('symptom-health-condition.service');
}

export namespace SymptomTypeServiceBindings {
  export const SYMPTOM_TYPE_SERVICE = BindingKey.create<SymptomTypeService>(
    'symptom-type.service',
  );
}

export namespace SymptomsServiceBindings {
  export const SYMPTOMS_SERVICE = BindingKey.create<SymptomsService>(
    'symptoms.service',
  );
}

export namespace TagServiceBindings {
  export const TAG_SERVICE = BindingKey.create<TagService>('tag.service');
}

export namespace TreatmentServiceBindings {
  export const TREATMENT_SERVICE = BindingKey.create<TreatmentService>(
    'treatment.service',
  );
}

export namespace UserDoctorsServiceBindings {
  export const USER_DOCTORS_SERVICE = BindingKey.create<UserDoctorsService>(
    'user-doctors.service',
  );
}

export namespace UserLocationsServiceBindings {
  export const USER_LOCATIONS_SERVICE = BindingKey.create<UserLocationsService>(
    'user-locations.service',
  );
}

export namespace UserPharmacyRecordsServiceBindings {
  export const USER_PHARMACY_RECORDS_SERVICE = BindingKey.create<
    UserPharmacyRecordsService
  >('user-pharmacy-records.service');
}

export namespace WaistgoalServiceBindings {
  export const WAISTGOAL_SERVICE = BindingKey.create<WaistgoalService>(
    'waistgoal.service',
  );
}

export namespace WebinarServiceBindings {
  export const WEBINAR_SERVICE = BindingKey.create<WebinarService>(
    'webinar.service',
  );
}

export namespace UserSubscriptionsServiceBindings {
  export const USER_SUBSCRIPTIONS = BindingKey.create<UserSubscriptionsService>(
    'user-subscriptions.service',
  );
}

export namespace ReportCommentServiceBindings {
  export const REPORT_COMMENT = BindingKey.create<ReportCommentService>(
    'report-comment.service',
  );
}

export namespace ReportPostServiceBindings {
  export const REPORT_POST = BindingKey.create<ReportPostService>(
    'report-post.service',
  );
}

export namespace HeightServiceBindings {
  export const HEIGHT_SERVICE = BindingKey.create<HeightService>(
    'height.service',
  );
}

export namespace TemperatureServiceBindings {
  export const TEMPERATURE_SERVICE = BindingKey.create<TemperatureService>(
    'temperature.service',
  );
}

export namespace PartnerServiceBindings {
  export const PARTNER_SERVICE = BindingKey.create<PartnerService>(
    'partner.service',
  );
}

export namespace ConsultServiceBindings {
  export const CONSULT_SERVICE = BindingKey.create<ConsultService>(
    'consult.service',
  );
}

export namespace HubVisitServiceBindings {
  export const HUB_VISIT_SERVICE = BindingKey.create<HubVisitService>(
    'hub-visit.service',
  );
}

export namespace WeightServiceBindings {
  export const WEIGHT_SERVICE = BindingKey.create<WeightService>(
    'weight.service',
  );
}

export namespace PsaServiceBindings {
  export const PSA_SERVICE = BindingKey.create<PsaService>('psa.service');
}

export namespace BloodSugarServiceBindings {
  export const BLOODSUGAR_SERVICE = BindingKey.create<BloodSugarService>(
    'blood-sugar.service',
  );
}

export namespace BloodPressureServiceBindings {
  export const BLOODPRESSURE_SERVICE = BindingKey.create<BloodPressureService>(
    'blood-pressure.service',
  );
}

export namespace CholestrolServiceBindings {
  export const CHOLESTROL_SERVICE = BindingKey.create<CholestrolService>(
    'cholestrol.service',
  );
}

export namespace HbaicServiceBindings {
  export const HBAIC_SERVICE = BindingKey.create<HbaicService>('hbaic.service');
}

export namespace WaistCirumferenceServiceBindings {
  export const WAISTCIRCUMGERENCE_SERVICE = BindingKey.create<
    WaistCircumferenceService
  >('waist-cirumference.service');
}

export namespace CoachUserSubscriptionsServiceBindings {
  export const COACHUSERSUBSCRIPTIONS_SERVICE = BindingKey.create<
    CoachUserSubscriptionsService
  >('coach-user-subscriptions.service');
}

export namespace ForumServiceBindings {
  export const FORUM_SERVICE = BindingKey.create<ForumService>('forum.service');
}

export namespace ForumUserServiceBindings {
  export const FORUMUSER_SERVICE = BindingKey.create<ForumUserService>(
    'forum-user.service',
  );
}

export namespace PregnancyCycleServiceBindings {
  export const PREGNANCY_CYCLE = BindingKey.create<PregnancyCycleService>(
    'pregnancy-cycle.service',
  );
}

export namespace PregnancyLogServiceBindings {
  export const PREGNANCY_LOG = BindingKey.create<PregnancyLogService>(
    'pregnancy-log.service',
  );
}

export namespace ExerciseServiceBindings {
  export const EXERCISE_SERVICE = BindingKey.create<ExerciseService>(
    'exercise.service',
  );
}

export namespace PrivilegeGroupServiceBindings {
  export const PRIVILEGE_GROUP_SERVICE = BindingKey.create<
    PrivilegeGroupService
  >('privilege-group.service');
}

export namespace PrivilegeServiceBindings {
  export const PRIVILEGE_SERVICE = BindingKey.create<PrivilegeService>(
    'privilege.service',
  );
}

export namespace RoleServiceBindings {
  export const ROLE_SERVICE = BindingKey.create<RoleService>('role.service');
}

export namespace CommentReplyServiceBindings {
  export const COMMENT_REPLY_SERVICE = BindingKey.create<CommentReplyService>(
    'comment-reply.service',
  );
}

export namespace CalenderEventServiceBindings {
  export const CALENDER_EVENT_SERVICE = BindingKey.create<CalenderEventService>(
    'calender-event.service',
  );
}

export namespace FeedbackServiceBindings {
  export const FEEDBACK_SERVICE = BindingKey.create<FeedbackService>(
    'feedback.service',
  );
}

export namespace UserFeedbackServiceBindings {
  export const USER_FEEDBACK_SERVICE = BindingKey.create<UserFeedbackService>(
    'user-feedback.service',
  );
}

export namespace ActivityTimelineServiceBindings {
  export const ACTIVITY_TIMELINE_SERVICE = BindingKey.create<
    ActivityTimelineService
  >('activity-timeline.service');
}

export namespace UserMentalAssessmentServiceBindings {
  export const USER_MENTAL_ASSESSMENT_SERVICE = BindingKey.create<
    UserMentalAssessmentService
  >('user-mental-assessment.service');
}

export namespace VoucherServiceBindings {
  export const VOUCHER_SERVICE = BindingKey.create<VoucherService>(
    'voucher.service',
  );
}

export namespace ProcedureListServiceBindings {
  export const PROCEDURE_LIST_SERVICE = BindingKey.create<ProcedureListService>(
    'procedure-list.service',
  );
}

export namespace OutlierServiceBindings {
  export const OUTLIER_SERVICE = BindingKey.create<OutlierService>(
    'outlier.service',
  );
}

export namespace DashboardStatisticsServiceBindings {
  export const DASHBOARD_STATISTICS_SERVICE = BindingKey.create<
    DashboardStatisticsService
  >('dashboard-statistics.service');
}

export namespace BmiServiceBindings {
  export const BMI_SERVICE = BindingKey.create<BmiService>('bmi.service');
}

export namespace KemMessageSerivceBindings {
  export const KEM_MESSAGE = BindingKey.create<KemMessageService>(
    'kem-message.service',
  );
}

export namespace ProductServiceBindings {
  export const PRODUCT_SERVICE = BindingKey.create<ProductService>(
    'product.service',
  );
}
export namespace ThroveSerivceBindings {
  export const THROVE_SERVICE = BindingKey.create<ThroveService>(
    'throve.service',
  );
}

export namespace CareerServiceBindings {
  export const CAREER_SERVICE = BindingKey.create<CareerService>(
    'career.service',
  );
}

export namespace PublicationServiceBindings {
  export const PUBLICATION_SERVICE = BindingKey.create<PublicationService>(
    'publication.service',
  );
}

export namespace SettingServiceBindings {
  export const SETTING_SERVICE = BindingKey.create<SettingService>(
    'setting.service',
  );
}

export namespace NoticeServiceBindings {
  export const NOTICE_SERVICE = BindingKey.create<NoticeService>("notice.service");
}

export namespace UserNoticeServiceBindings {
  export const USER_NOTICE_SERVICE = BindingKey.create<UserNoticeService>("user-notice.service");
}

export namespace GoalServiceBindings {
  export const GOAL_SERVICE = BindingKey.create<GoalService>('goal.service');
}

export namespace GoalActionServiceBindings {
  export const GOAL_ACTION_SERVICE = BindingKey.create<GoalActionService>(
    'goal-action.service',
  );
}
export namespace GoalLogsServiceBindings {
  export const GOAL_LOGS_SERVICE = BindingKey.create<GoalLogsService>(
    'goal-logs.service',
  );
}
export namespace LabTestServiceBindings {
  export const LAB_TEST_SERVICE = BindingKey.create<LabTestService>(
    'lab-test.service',
  );
}

export namespace ConsultGlitchesServiceBindings {
  export const CONSULT_GLITCHES_SERVICE = BindingKey.create<ConsultGlitchesService>(
    'consult-glitches.service',
  );
}
