import {
  ActivityTimelineRepository,
  WaistCircumferenceRepository,
} from '../repositories';
import {HttpErrors} from '@loopback/rest';
import {
  returnValues,
  userPreferredWaist,
  inchesToCentimeters,
} from '../utils/health-metrics-functions';
import {OutlierServiceBindings} from '../keys';
import {OutlierService} from './outlier.service';
import {HealthMetricsTypeEnum} from '../utils/enums';
import {Filter, repository} from '@loopback/repository';
import {BindingScope, bind, inject} from '@loopback/context';
import {PaginatedResponse, activityTypeObj} from '../type-schema';
import {WaistCircumference, WaistCircumferenceWithRelations} from '../models';

@bind({scope: BindingScope.CONTEXT})
export class WaistCircumferenceService {
  constructor(
    @inject(OutlierServiceBindings.OUTLIER_SERVICE)
    public outlierService: OutlierService,
    @repository(WaistCircumferenceRepository)
    public waistCircumferenceRepository: WaistCircumferenceRepository,
    @repository(ActivityTimelineRepository)
    public activityTimelineRepository: ActivityTimelineRepository,
  ) {}

  async create(
    payload: Omit<WaistCircumference, 'id'>,
  ): Promise<WaistCircumference> {
    let defaultValue = payload.currentWaist;
    if (payload.unit === 'IN') {
      defaultValue = inchesToCentimeters(payload.currentWaist);
    }
    if (defaultValue < 50 || defaultValue > 150)
      throw new HttpErrors[409]('Please provide a valid value');
    const data = await this.waistCircumferenceRepository.create({
      ...payload,
      defaultValue,
      defaultUnit: 'CM',
    });
    await this.activityTimelineRepository.create({
      activityType: activityTypeObj.WAIST_CIRCUMFERENCE,
      userId: data.userId,
      metadata: data.id,
    });

    try {
      const minMaxValue = returnValues(
        HealthMetricsTypeEnum.Waist,
        payload.unit,
      );
      if (
        data.currentWaist <= minMaxValue.minCritical ||
        data.currentWaist >= minMaxValue.maxCritical
      ) {
        const outlier = {
          userId: payload.userId,
          metricType: HealthMetricsTypeEnum.Waist,
          metricId: data.id,
          metricValue: `${data.currentWaist}${data.unit}`,
        };
        await this.outlierService.create(outlier);
      }
    } catch (error) {}
    return data;
  }

  async findAll(
    filter: Filter<WaistCircumference>,
    page: number,
  ): Promise<PaginatedResponse<WaistCircumferenceWithRelations>> {
    const limit = filter?.limit ? filter?.limit : 25;
    const pageNum = page ? page : 1;
    const skip = (pageNum - 1) * limit;
    const content = await this.waistCircumferenceRepository.find({
      where: filter?.where,
      include: [
        {
          relation: 'coach',
          scope: {
            fields: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              phone: true,
            },
          },
        },
        {
          relation: 'user',
          scope: {
            fields: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              phone: true,
              waistUnit: true,
            },
          },
        },
      ],
      order: ['created_at DESC'],
      skip,
      limit,
    });
    const count = await this.waistCircumferenceRepository.count(filter?.where);
    const totalPages = Math.ceil(count.count / limit);

    content.map(waist => {
      const response = userPreferredWaist(
        waist.currentWaist,
        waist.waistGoal,
        waist.unit,
        waist.user.waistUnit,
      );
      waist.currentWaist = response.requiredWaist;
      waist.waistGoal = response.requiredWaistGoal;
      waist.unit = response.requiredUnit;
    });

    return {
      data: content,
      count: count.count,
      totalPages,
      currentPage: page,
      status: 'success',
    };
  }

  async findById(id: string, filter: Filter<WaistCircumference>) {
    const data = this.waistCircumferenceRepository.findById(id, {
      where: filter?.where,
      include: [
        {
          relation: 'coach',
          scope: {
            fields: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              phone: true,
            },
          },
        },
        {
          relation: 'user',
          scope: {
            fields: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              phone: true,
            },
          },
        },
      ],
    });
    return data;
  }

  async updateById(
    id: string,
    waistCircumference: WaistCircumference,
  ): Promise<void> {
    const data = await this.waistCircumferenceRepository.updateById(
      id,
      waistCircumference,
    );
    return data;
  }

  async deleteById(id: string): Promise<void> {
    return await this.waistCircumferenceRepository.deleteById(id);
  }
}
