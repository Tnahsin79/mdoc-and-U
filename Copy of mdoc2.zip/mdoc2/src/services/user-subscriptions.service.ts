import {
  Payments,
  UserSubscriptions,
  CoachUserSubscriptions,
  UserSubscriptionsWithRelations,
} from '../models';
import {
  PaginatedResponse,
  ActiveInactiveEnum,
  NotificationTypeEnum,
  NotificationPriorityEnum,
} from '../type-schema';
import {
  UsersRepository,
  VoucherRepository,
  PaymentsRepository,
  ChatRoomRepository,
  ProgramsRepository,
  ProgramPlansRepository,
  NotificationRepository,
  CoachProgramsRepository,
  UserSubscriptionsRepository,
  CoachUserSubscriptionsRepository,
} from '../repositories';
import moment from 'moment';
import Utils from '../utils';
import paystack from 'paystack';
import {HttpErrors} from '@loopback/rest';
import {EmailService} from './email.service';
import {ControllerService} from './controller.service';
import {Filter, repository} from '@loopback/repository';
const payStack = paystack(process.env.PAYSTACK_SECRET_KEY);
import {bind, BindingScope, inject} from '@loopback/context';
import {PaymentTypeEnum, VoucherTypeEnum} from '../utils/enums';
import {ControllerServiceBindings, EmailServiceBindings} from '../keys';

@bind({scope: BindingScope.TRANSIENT})
export class UserSubscriptionsService {
  constructor(
    @inject(EmailServiceBindings.MAIL_SERVICE)
    public emailService: EmailService,
    @repository(UsersRepository)
    public usersRepository: UsersRepository,
    @repository(ProgramsRepository)
    public programsRepository: ProgramsRepository,
    @repository(PaymentsRepository)
    public paymentsRepository: PaymentsRepository,
    @repository(VoucherRepository)
    public voucherRepository: VoucherRepository,
    @repository(ProgramPlansRepository)
    public plansRepository: ProgramPlansRepository,
    @repository(UserSubscriptionsRepository)
    public userSubscriptionsRepository: UserSubscriptionsRepository,
    @repository(CoachUserSubscriptionsRepository)
    public coachUserSubscriptionsRepository: CoachUserSubscriptionsRepository,
    @repository(CoachProgramsRepository)
    public coachProgramsRepository: CoachProgramsRepository,
    @repository(ChatRoomRepository)
    public chatRoomRepository: ChatRoomRepository,
    @inject(ControllerServiceBindings.CONTROLLER_SERVICE)
    public controllerService: ControllerService,
    @repository(NotificationRepository)
    public notificationRepository: NotificationRepository,
  ) {}

  async create(
    payload: Omit<UserSubscriptions, 'id'>,
  ): Promise<UserSubscriptions> {
    return await this.userSubscriptionsRepository.create(payload);
  }

  async recordNewSubscription(
    payment: Payments,
  ): Promise<UserSubscriptions | paystack.Response> {
    const paymentData = await this.paymentsRepository.findOne({
      where: {
        or: [{id: payment.id}, {reference: payment.reference}],
      },
    });
    if (!paymentData) {
      throw new HttpErrors[409](
        "This payment doesn't seem to exist. If this is a mistake, please contact support at info@mymdoc.com with the payment receipt that was sent to your email.",
      );
    }
    try {
      let res: any = {status: true};
      const errorMessage =
        'Your payment was not successful. If this is an error, please contact support to resolve the transaction.';
      if (paymentData.amount > 0 && paymentData.payer === 'paystack') {
        const res = await payStack.transaction.verify(paymentData.reference);
        if (res?.status) {
          await this.paymentsRepository.updateById(paymentData.id, {
            transactionId: res.data.id ?? '',
            status: res?.data?.status,
          });

          if (res?.data?.status !== 'success') {
            throw new HttpErrors[409](errorMessage);
          }
        } else {
          throw new HttpErrors[409](errorMessage);
        }
      }

      const plan = await this.plansRepository.findById(paymentData.planId, {
        include: [
          {relation: 'program', scope: {fields: {id: true, title: true}}},
        ],
      });
      if (!plan) {
        throw new HttpErrors[409](
          'The plan you subscribed to does not exist. Please contact support with your payment reference.',
        );
      }

      // Get all existing subscriptions with the same user and program

      const existingSubscriptions = await this.userSubscriptionsRepository.find(
        {
          where: {
            programId: paymentData.programId,
            userId: paymentData.userId,
            endDate: {
              gt: moment()
                .utc()
                .toDate(),
            },
          },
        },
      );

      // Don't allow subscription for an active program
      const existingSubscription = existingSubscriptions?.find(item =>
        moment(item.endDate).isAfter(moment()),
      );

      if (existingSubscription) {
        throw new HttpErrors[409](
          'You currently have an active subscription for this service.',
        );
      }
      const payload: any = {
        paymentId: paymentData?.id,
        programId: paymentData.programId,
        userId: paymentData.userId,
        planId: paymentData.planId,
        voucherId: paymentData.voucherId,
        created: new Date(),
        startDate: new Date(),
      };
      const dayCount = plan.duration;
      payload.endDate = moment
        .utc()
        .add(dayCount, 'days')
        .toDate();
      const user = await this.usersRepository.findById(payload.userId);
      if (paymentData?.id) {
        await this.paymentsRepository.updateById(paymentData?.id, {
          status: 'success',
        });
      }
      const subscription = await this.userSubscriptionsRepository.create({
        ...payload,
        userFullName: `${user?.firstName} ${user?.lastName}`,
      });

      // Assign to a coach here

      // If this was a subscription renewal, reassign member to the same coach
      const existingCoach = await this.coachUserSubscriptionsRepository.findOne(
        {
          where: {
            userSubscriptionId: {
              inq: existingSubscriptions?.map(item => item.id),
            },
          },
        },
      );

      const program = await this.programsRepository.findById(
        subscription.programId,
      );
      let assignedCoach: CoachUserSubscriptions;

      if (existingCoach) {
        await this.coachUserSubscriptionsRepository.updateById(
          existingCoach.id,
          {status: ActiveInactiveEnum.INACTIVE},
        );
        assignedCoach = await this.coachUserSubscriptionsRepository.create({
          coachId: existingCoach.coachId,
          userSubscriptionId: subscription.id,
          status: ActiveInactiveEnum.ACTIVE,
        });
        const notificationPayloadForCoach = {
          resourceId: assignedCoach.id,
          notificationObject: assignedCoach,
          coachId: existingCoach.id,
          notificationType: NotificationTypeEnum.SUBSCRIPTION_RENEWAL,
          priority: NotificationPriorityEnum.HIGH,
          title: 'Subscription Renewal',
          body: `New subscription renewal by ${user.firstName} on ${program.title}.`,
        };
        await this.notificationRepository.create(notificationPayloadForCoach);
      } else {
        const coaches = await this.coachProgramsRepository.find({
          where: {programId: paymentData.programId, status: 'active'},
        });

        // Get coach with fewest members
        const coachWithFewestMembers = coaches.reduce((acc, curr) => {
          return curr.totalMembers < acc.totalMembers ? curr : acc;
        }, coaches[0]);

        if (coachWithFewestMembers) {
          assignedCoach = await this.coachUserSubscriptionsRepository.create({
            coachId: coachWithFewestMembers.coachId,
            userSubscriptionId: subscription.id,
          });

          await this.coachProgramsRepository.updateById(
            coachWithFewestMembers?.id,
            {totalMembers: (coachWithFewestMembers?.totalMembers || 0) + 1},
          );

          const notificationPayloadForCoach = {
            resourceId: assignedCoach.id,
            notificationObject: assignedCoach,
            coachId: coachWithFewestMembers.id,
            notificationType: NotificationTypeEnum.NEW_SUBSCRIPTION,
            priority: NotificationPriorityEnum.HIGH,
            title: 'New Member Assignment',
            body: ' You have been assigned a new member!! ',
          };
          await this.notificationRepository.create(notificationPayloadForCoach);

          const notificationPayloadForUser = {
            resourceId: subscription.id,
            notificationObject: assignedCoach,
            userId: subscription.userId,
            notificationType: NotificationTypeEnum.NEW_SUBSCRIPTION,
            priority: NotificationPriorityEnum.HIGH,
            title: 'New Coach Assignment',
            body: ' You have been assigned a new coach!! ',
          };
          await this.notificationRepository.create(notificationPayloadForUser);

          // Assign coach end
        }

        // Create a chatroom for coach and user
        if (assignedCoach) {
          const existingChatRoom = await this.chatRoomRepository.findOne({
            where: {
              receiverCoachId: assignedCoach?.coachId,
              receiverMemberId: user?.id,
            },
          });
          if (!existingChatRoom) {
            await this.chatRoomRepository.create({
              creatorId: assignedCoach?.coachId,
              receiverCoachId: assignedCoach?.coachId,
              receiverMemberId: user?.id,
              creatorType: 'system',
              userFullName: `${user?.firstName} ${user?.lastName}`,
              receiverIds: [user?.id],
              type: 'direct',
            });
          }
        }
        // Create chatroom end
      }

      if (user?.email) {
        await this.emailService.sendMail({
          to: user.email,
          slug: 'new_member_subscription',
          message: {firstName: user.firstName, programName: plan.program.title},
        });
      } else {
        const body =
          'Congratulations on joining mDoc CompleteHealth tm! You have taken the first step toward a healthier you. Your journey has officially begun, and mDoc is here to support you every step of the way. Welcome aboard!';
        await this.controllerService.sendOtpService(user?.phone, body);
      }

      return subscription;
    } catch (error) {
      throw error;
    }
  }

  async getSubscriptionById(
    id: string,
  ): Promise<UserSubscriptionsWithRelations> {
    return await this.userSubscriptionsRepository.findById(id, {
      include: [
        {
          relation: 'program',
          scope: {
            fields: {
              id: true,
              title: true,
            },
          },
        },
        {relation: 'plan'},
        {relation: 'payment'},
        {
          relation: 'user',
          scope: {
            fields: {
              id: true,
              name: true,
              image: true,
              email: true,
              phone: true,
            },
          },
        },
        // This points to the CoachUserSubscriptions
        {
          relation: 'coach',
          scope: {
            include: [
              {
                relation: 'coach',
                scope: {
                  fields: {
                    id: true,
                    name: true,
                    image: true,
                  },
                },
              },
            ],
          },
        },
      ],
    });
  }

  async getAllSubscriptions(
    limit?: number,
    page?: number,
    startDate?: string,
    endDate?: string,
    search?: string,
    programId?: string,
    status?: string,
  ): Promise<any> {
    const pageSize = Utils.getLimit(limit);
    const pageNum = page ? page : 1;
    const skip = (pageNum - 1) * pageSize;
    const where = {};

    if (startDate && endDate) {
      const _startDate = moment(startDate)
        .utc()
        .toDate();
      const _endDate = moment(endDate)
        .utc()
        .toDate();
      where['created'] = {between: [_startDate, _endDate]};
    }

    if (startDate && !endDate) {
      const _startDate = moment(startDate)
        .utc()
        .toDate();
      where['created'] = {gte: _startDate};
    }

    if (endDate && !startDate) {
      const _endDate = moment(endDate)
        .utc()
        .toDate();
      where['created'] = {lte: _endDate};
    }

    if (programId) {
      where['programId'] = programId;
    }

    if (status) {
      const key = status === 'active' ? 'gte' : 'lt';
      where['endDate'] = {
        [key]: moment()
          .utc()
          .toDate(),
      };
    }

    let searchString = search;
    if (searchString?.includes('+')) {
      searchString = searchString.replace('+', '');
    }

    if (search) {
      where['userFullName'] = new RegExp('.*' + searchString + '.*', 'i');
    }

    const result = await this.userSubscriptionsRepository.find({
      where,
      order: ['created ASC'],
      include: [
        // This points to the CoachUserSubscriptions
        {
          relation: 'coach',
          scope: {
            include: [
              {
                relation: 'coach',
                scope: {
                  fields: {
                    id: true,
                    name: true,
                    image: true,
                  },
                },
              },
            ],
          },
        },
        {
          relation: 'program',
          scope: {
            fields: {
              id: true,
              title: true,
              tags: true,
            },
          },
        },
        {relation: 'plan'},
        {relation: 'payment'},
        {
          relation: 'user',
          scope: {
            fields: {
              id: true,
              name: true,
              image: true,
              email: true,
              phone: true,
            },
          },
        },
      ],
      limit: pageSize,
      skip: skip,
    });

    const count = await this.userSubscriptionsRepository.count(where);
    const totalPages = Math.ceil(count.count / pageSize);

    return {
      data: result,
      count: count.count,
      totalPages: totalPages,
      currentPage: pageNum,
      status: 'success',
    };
  }

  async getSubscriptionPageStats() {
    const subscriptions = await this.userSubscriptionsRepository.find();
    const totalActive = subscriptions.filter(item =>
      moment(item.endDate).isAfter(moment(), 'day'),
    ).length;
    const totalInactive = subscriptions.filter(item =>
      moment(item.endDate).isBefore(moment(), 'day'),
    ).length;
    const total = subscriptions.length;
    return {
      total,
      totalActive,
      totalInactive,
    };
  }

  async getUserSubscriptions(userId: string) {
    const subscriptions = await this.userSubscriptionsRepository.find({
      where: {userId},
      include: [
        {
          relation: 'coach',
          scope: {
            include: [
              {
                relation: 'coach',
                scope: {
                  fields: {
                    id: true,
                    name: true,
                    image: true,
                    firstName: true,
                    lastName: true,
                    description: true,
                  },
                },
              },
            ],
          },
        },
        {
          relation: 'program',
          scope: {
            fields: {
              id: true,
              title: true,
            },
          },
        },
        {relation: 'plan'},
        {relation: 'payment'},
      ],
      order: ['created_at DESC'],
    });
    return subscriptions;
  }

  async updateStageOfChange(id: string, changeStage: string) {
    const subscription = await this.userSubscriptionsRepository.findById(id);
    if (!subscription) {
      throw new HttpErrors[404]('Subscription record does not exist');
    }
    await this.userSubscriptionsRepository.updateById(id, {
      changeStage,
    });
  }

  async updateUserSubscription(id: string, data: Partial<UserSubscriptions>) {
    const subscription = await this.userSubscriptionsRepository.findById(id);
    if (!subscription) {
      throw new HttpErrors[404]('Subscription record does not exist');
    }
    await this.userSubscriptionsRepository.updateById(id, data);
  }

  async programStatistics(programIds: string[]) {
    const programs = await this.programsRepository.find({
      where: {id: {inq: programIds}},
      include: [
        {
          relation: 'subscriptions',
          scope: {
            include: [
              {relation: 'payment', scope: {fields: {id: true, amount: true}}},
            ],
          },
        },
        {
          relation: 'coachPrograms',
          scope: {fields: {id: true}},
        },
      ],
    });
    const response = programs.map(program => {
      const subscriptions = program.subscriptions || [];
      const coaches = program.coachPrograms || [];
      delete program.subscriptions;
      delete program.coachPrograms;
      const payments = subscriptions?.map(pay => pay.payment.amount || 0);
      const revenue = payments?.reduce((t, a) => t + a, 0);
      return {
        program,
        totalSubscriptions: subscriptions.length,
        totalRevenue: revenue,
        totalCoaches: coaches?.length || 0,
      };
    });
    return response;
  }

  async getUserSubscriptionsWithoutCoaches(
    programId: string,
  ): Promise<UserSubscriptions[]> {
    const userSubscriptions = await this.userSubscriptionsRepository.find({
      where: {programId},
      include: [{relation: 'user'}, {relation: 'program'}],
    });

    const coachUserSubscriptions = await this.coachUserSubscriptionsRepository.find(
      {
        where: {
          userSubscriptionId: {inq: userSubscriptions.map(data => data.id)},
        },
      },
    );

    const allCoachUserSubscriptionsId = coachUserSubscriptions.map(
      coachUserSubscription =>
        coachUserSubscription.userSubscriptionId.toString(),
    );

    const userSubscriptionsWithoutCoaches = userSubscriptions.filter(item =>
      allCoachUserSubscriptionsId.includes(item.id.toString()) ? false : true,
    );
    return userSubscriptionsWithoutCoaches;
  }

  async getCoachUserSubscription(
    coachId: string,
    search?: string,
    filter?: Filter<UserSubscriptions>,
    page?: number,
    limit?: number,
    startDate?: string,
    endDate?: string,
  ): Promise<PaginatedResponse<UserSubscriptions>> {
    const pageSize = Utils.getLimit(limit);
    const pageNum = page ? page : 1;
    const skip = (pageNum - 1) * pageSize;
    const coachUserSubscriptions = await this.coachUserSubscriptionsRepository.find(
      {
        where: {
          coachId,
        },
      },
    );
    const userSubscriptionIds = coachUserSubscriptions.map(
      data => data.userSubscriptionId,
    );

    const where = {...(filter.where || {}), id: {inq: userSubscriptionIds}};
    if (search) {
      where['userFullName'] = new RegExp('.*' + search + '.*', 'i');
    }
    if (startDate && endDate) {
      const _startDate = moment(startDate)
        .utc()
        .toDate();
      const _endDate = moment(endDate)
        .utc()
        .toDate();
      where['created'] = {between: [_startDate, _endDate]};
    }

    if (startDate && !endDate) {
      const _startDate = moment(startDate)
        .utc()
        .toDate();
      where['created'] = {gte: _startDate};
    }

    if (endDate && !startDate) {
      const _endDate = moment(endDate)
        .utc()
        .toDate();
      where['created'] = {lte: _endDate};
    }

    const userSubscriptions = await this.userSubscriptionsRepository.find({
      where,
      include: [
        {
          relation: 'user',
          scope: {
            fields: {
              id: true,
              email: true,
              phone: true,
              firstName: true,
              lastName: true,
              gender: true,
              created: true,
              dob: true,
            },
          },
        },
      ],
      limit,
      skip,
    });

    const count = await this.userSubscriptionsRepository.count(where);
    const totalPages = Math.ceil(count.count / pageSize);

    return {
      data: userSubscriptions,
      count: count.count,
      totalPages: totalPages,
      currentPage: pageNum,
      status: 'success',
    };
  }

  async recordOfflinePayment(
    payload: {
      programId: string;
      planId: string;
      userId: string;
      reference: string;
      paymentType: PaymentTypeEnum;
      paymentDate: string;
    },
    adminId: string,
  ) {
    const {
      userId,
      programId,
      planId,
      paymentType,
      reference,
      paymentDate,
    } = payload;
    const user = await this.usersRepository.findById(userId);
    if (!user) {
      throw new HttpErrors[409]('User does not exist');
    }
    const program = await this.programsRepository.findById(programId);
    if (!program) {
      throw new HttpErrors[409]('Program does not exist');
    }
    const plan = await this.plansRepository.findById(planId);
    if (!plan) {
      throw new HttpErrors[409]('Plan does not exist');
    }

    // Check if a valid voucher has already been created for this user, plan and program.
    const offlineVoucher = await this.voucherRepository.findOne({
      where: {
        voucherType: VoucherTypeEnum.SINGLE,
        createdForUserId: userId,
        programId,
        planId,
        endDate: {
          gt: moment()
            .utc()
            .toDate(),
        },
      },
    });
    if (offlineVoucher) {
      throw new HttpErrors[409](
        'A valid voucher exists for this user, plan and program.',
      );
    }

    const code = `${user.firstName.substring(
      0,
      3,
    )}-${Utils.generateRandomCode()}`;

    const voucher = await this.voucherRepository.create({
      title: `${user?.firstName}-${program.title}-${plan.title} voucher`,
      createdForUserId: userId,
      code,
      programId,
      planId,
      amount: plan.basePrice,
      voucherType: VoucherTypeEnum.SINGLE,
      status: 'active',
      discountType: 'fixed',
      paymentDate,
      paymentType,
      reference,
      approvalStatus: 'approved',
      startDate: moment().toISOString(),
      endDate: moment()
        .add(1, 'year')
        .toISOString(),
      createdById: adminId,
    });

    if (user?.email) {
      await this.emailService.sendMail({
        to: user.email,
        slug: 'new_offline_payment',
        message: {
          firstName: user.firstName,
          program: program.title,
          plan: plan.title,
          amount: plan.basePrice,
          voucher: voucher.code,
          reference: voucher.reference,
          date: moment(voucher.paymentDate).format('Do MMM, YYYY HH:mm'),
        },
      });
    } else {
      const body = `Your payment of ${plan.basePrice} was successful! Use the voucher code ${voucher.code} to subscribe.`;
      await this.controllerService.sendOtpService(user?.phone, body);
    }

    return voucher;
  }
}
