import Utils from '../utils';
import {GoalAction} from '../models';
import {PaginatedResponse} from '../type-schema';
import {GoalActionRepository} from '../repositories';
import {BindingScope, bind} from '@loopback/context';
import {Filter, repository} from '@loopback/repository';

@bind({scope: BindingScope.CONTEXT})
export class GoalActionService {
  constructor(
    @repository(GoalActionRepository)
    public goalActionRepository: GoalActionRepository,
  ) {}

  async create(goal: Omit<GoalAction, 'id'>): Promise<GoalAction> {
    return await this.goalActionRepository.create(goal);
  }

  async find(
    filter: Filter<GoalAction>,
    page: number,
  ): Promise<PaginatedResponse<GoalAction>> {
    const limit = Utils.getLimit(filter?.limit);
    const pageNum = page ? page : 1;
    const skip = (pageNum - 1) * limit;
    const content = await this.goalActionRepository.find({
      where: filter?.where,
      include: [
        {
          relation: 'user',
          scope: {
            fields: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              phone: true,
            },
          },
        },
        {
          relation: 'goal',
          scope: {
            fields: {
              id: true,
              title: true,
              description: true,
            },
          },
        },
        {
          relation: 'coach',
          scope: {
            fields: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              phone: true,
            },
          },
        },
      ],
      order: ['created_at DESC'],
      skip,
      limit,
    });
    const count = await this.goalActionRepository.count(filter?.where);
    const totalPages = Math.ceil(count.count / limit);

    return {
      data: content,
      count: count.count,
      totalPages,
      currentPage: page,
      status: 'success',
    };
  }

  async findById(id: string, filter: Filter<GoalAction>) {
    return await this.goalActionRepository.findById(id, {
      where: filter?.where,
      include: [
        {
          relation: 'user',
          scope: {
            fields: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              phone: true,
            },
          },
        },
        {
          relation: 'goal',
          scope: {
            fields: {
              id: true,
              title: true,
              description: true,
            },
          },
        },
        {
          relation: 'coach',
          scope: {
            fields: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              phone: true,
            },
          },
        },
      ],
    });
  }

  async updateById(id: string, goal: GoalAction): Promise<void> {
    return await this.goalActionRepository.updateById(id, goal);
  }

  async deleteById(id: string): Promise<void> {
    return await this.goalActionRepository.deleteById(id);
  }
}
