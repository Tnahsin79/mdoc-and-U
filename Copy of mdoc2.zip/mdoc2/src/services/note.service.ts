import {bind, BindingScope} from '@loopback/context';
import {repository} from '@loopback/repository';
import {Note, NoteWithRelations} from '../models';
import {NoteRepository} from '../repositories';
import {PaginatedResponse} from '../type-schema';

@bind({scope: BindingScope.TRANSIENT})
export class NoteService {
  constructor(
    @repository(NoteRepository)
    public noteRepository: NoteRepository,
  ) {}

  async create(payload: Omit<Note, 'id'>): Promise<Note> {
    return await this.noteRepository.create(payload);
  }

  async updateById(id: string, payload: Partial<Note>): Promise<void> {
    return await this.noteRepository.updateById(id, payload);
  }

  async deleteById(id: string): Promise<void> {
    return await this.noteRepository.deleteById(id);
  }

  async getByUserId(id: string): Promise<NoteWithRelations[]> {
    return await this.noteRepository.find({
      where: {
        userId: id,
      },
      include: [
        {
          relation: 'coach',
          scope: {
            fields: {
              id: true,
              name: true,
              image: true,
              email: true,
              phone: true,
              address: true,
            },
          },
        },
      ],
      order: ['created DESC'],
    });
  }

  async getByCoachId(
    id: string,
    limit: number,
    page?: number,
  ): Promise<PaginatedResponse<NoteWithRelations>> {
    const pageNum = page ? page : 1;
    const skip = (pageNum - 1) * limit;
    const content = await this.noteRepository.find({
      where: {
        coachId: id,
      },
      include: [
        {
          relation: 'user',
          scope: {
            fields: {
              id: true,
              name: true,
              image: true,
              email: true,
              phone: true,
              locationInfo: true,
            },
          },
        },
      ],
      limit,
      skip,
      order: ['createdAt DESC'],
    });

    const count = await this.noteRepository.count({coachId: id});
    const totalPages = Math.ceil(count.count / limit);

    return {
      data: content,
      count: count.count,
      totalPages,
      currentPage: page,
      status: 'success',
    };
  }

  async getByUserIdAndCoachId(
    id: string,
    coachId: string,
  ): Promise<NoteWithRelations[]> {
    return await this.noteRepository.find({
      where: {
        userId: id,
        coachId,
      },
      include: [{relation: 'user'}, {relation: 'coach'}],
      order: ['createdAt DESC'],
    });
  }
}
