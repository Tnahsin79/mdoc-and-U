import {
  Forum,
  ForumUser,
  ForumWithRelations,
  ForumUserWithRelations,
} from '../models';
import {
  ForumRepository,
  ForumUserRepository,
  NotificationRepository,
} from '../repositories';
import Utils from '../utils';
import {BindingScope, bind} from '@loopback/context';
import {Filter, repository} from '@loopback/repository';
import {NotificationTypeEnum, PaginatedResponse} from '../type-schema';

@bind({scope: BindingScope.CONTEXT})
export class ForumService {
  constructor(
    @repository(ForumRepository)
    public forumRepository: ForumRepository,
    @repository(ForumUserRepository)
    public forumUserRepository: ForumUserRepository,
    @repository(NotificationRepository)
    public notificationRepository: NotificationRepository,
  ) {}

  async create(payload: Omit<Forum, 'id'>): Promise<Forum> {
    const forum = await this.forumRepository.create(payload);
    return await this.forumRepository.findById(forum?.id, {
      include: [
        {relation: 'program'},
        {
          relation: 'createdBy',
          scope: {
            fields: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              phone: true,
            },
          },
        },
        {
          relation: 'approver',
          scope: {
            fields: {
              id: true,
              name: true,
              email: true,
              role: true,
              status: true,
            },
          },
        },
      ],
    });
  }

  async findAll(
    filter: Filter<Forum>,
    page: number,
  ): Promise<PaginatedResponse<ForumWithRelations>> {
    const limit = Utils.getLimit(filter?.limit);
    const pageNum = page ? page : 1;
    const skip = (pageNum - 1) * limit;
    const content = await this.forumRepository.find({
      where: filter?.where,
      include: [
        {relation: 'program'},
        {
          relation: 'participants',
          scope: {
            include: [
              {
                relation: 'user',
                scope: {
                  fields: {
                    id: true,
                    name: true,
                    firstName: true,
                    lastName: true,
                    image: true,
                    email: true,
                    phone: true,
                  },
                },
              },
            ],
          },
        },
        {
          relation: 'createdBy',
          scope: {
            fields: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              phone: true,
            },
          },
        },
        {
          relation: 'approver',
          scope: {
            fields: {
              id: true,
              name: true,
              email: true,
              role: true,
              status: true,
            },
          },
        },
      ],
      limit,
      skip,
    });
    const count = await this.forumRepository.count(filter?.where);
    const totalPages = Math.ceil(count.count / limit);
    return {
      data: content,
      count: count.count,
      totalPages,
      currentPage: page,
      status: 'success',
    };
  }

  async findById(id: string, filter: Filter<Forum>) {
    const data = this.forumRepository.findById(id, {
      where: filter?.where,
      include: [
        {relation: 'program'},
        {
          relation: 'participants',
          scope: {
            include: [
              {
                relation: 'user',
                scope: {
                  fields: {
                    id: true,
                    name: true,
                    firstName: true,
                    lastName: true,
                    image: true,
                    email: true,
                    phone: true,
                  },
                },
              },
            ],
          },
        },
        {
          relation: 'createdBy',
          scope: {
            fields: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              phone: true,
            },
          },
        },
        {
          relation: 'approver',
          scope: {
            fields: {
              id: true,
              name: true,
              email: true,
              role: true,
              status: true,
            },
          },
        },
      ],
    });
    return data;
  }

  async updateById(id: string, forum: Forum): Promise<void> {
    const data = await this.forumRepository.updateById(id, forum);
    return data;
  }

  async deleteById(id: string): Promise<void> {
    return await this.forumRepository.deleteById(id);
  }

  async updateForumParticipants(
    id: string,
    payload: Omit<ForumUser, 'id'>[],
  ): Promise<ForumUserWithRelations[]> {
    let users = [];
    const existingForum = await this.forumUserRepository.find({
      where: {
        forumId: id,
      },
    });
    if (existingForum.length) {
      users = existingForum.map(data => data.userId);
      await this.forumUserRepository.deleteAll({
        forumId: id,
      });
    }
    const results = await this.forumUserRepository.createAll(payload);
    const newUsers = payload.map(data => {
      if (!users.includes(data.userId)) {
        return data;
      }
    });
    const notificationPayload = newUsers.map(data => ({
      userId: data.userId,
      notificationType: NotificationTypeEnum.NEW_FORUM,
      resourceId: results.reduce((acc, crr) => {
        if (crr.userId === data.userId) {
          acc = crr.userId;
        }
        return acc;
      }, ''),
      title: 'New Forum Found',
      body: 'You have been added to the New Forum',
      notificationObject: data,
    }));
    await this.notificationRepository.createAll(notificationPayload);

    return await this.forumUserRepository.find({
      where: {
        id: {inq: payload.map(i => i.userId)},
      },
      include: [
        {
          relation: 'forum',
          scope: {
            fields: {
              id: true,
              coachId: true,
              topic: true,
              cohorts: true,
              approvalStatus: true,
            },
          },
        },
        {
          relation: 'user',
          scope: {
            fields: {
              id: true,
              image: true,
              firstName: true,
              lastName: true,
              email: true,
              phone: true,
            },
          },
        },
      ],
    });
  }

  async getUserForums(userId: string) {
    const forumUsers = await this.forumUserRepository.find({
      where: {userId},
    });

    return await this.forumRepository.find({
      where: {
        id: {inq: forumUsers?.map(item => item.forumId)},
      },
      include: [
        {
          relation: 'participants',
          scope: {
            include: [
              {
                relation: 'user',
                scope: {
                  fields: {
                    id: true,
                    name: true,
                    image: true,
                  },
                },
              },
            ],
          },
        },
      ],
    });
  }
}
