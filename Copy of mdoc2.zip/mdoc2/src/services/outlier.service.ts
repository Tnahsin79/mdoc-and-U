import {
  CLINICALS_EMAIL,
  OutlierStatusEnum,
  healthMetricsObject,
} from '../utils/enums';
import {
  PaginatedResponse,
  NotificationTypeEnum,
  NotificationPriorityEnum,
} from '../type-schema';
import {
  UsersRepository,
  OutlierRepository,
  ProgramsRepository,
  CoachProgramsRepository,
  UserSubscriptionsRepository,
  NotificationRepository,
} from '../repositories';
import Utils from '../utils';
import {Outlier} from '../models';
import {HttpErrors} from '@loopback/rest';
import {EmailServiceBindings} from '../keys';
import {EmailService} from './email.service';
import {Filter, repository} from '@loopback/repository';
import {BindingScope, bind, inject} from '@loopback/context';
import {CoachUserSubscriptionsRepository} from '../repositories/coach-user-subscriptions.repository';

@bind({scope: BindingScope.CONTEXT})
export class OutlierService {
  constructor(
    @repository(OutlierRepository)
    public outlierRepository: OutlierRepository,
    @repository(UsersRepository)
    public usersRepository: UsersRepository,
    @repository(ProgramsRepository)
    public programsRepository: ProgramsRepository,
    @repository(UserSubscriptionsRepository)
    public userSubscriptionsRepository: UserSubscriptionsRepository,
    @repository(CoachUserSubscriptionsRepository)
    public coachUserSubscriptionsRepository: CoachUserSubscriptionsRepository,
    @repository(CoachProgramsRepository)
    public coachProgramsRepository: CoachProgramsRepository,
    @inject(EmailServiceBindings.MAIL_SERVICE)
    public emailService: EmailService,
    @repository(NotificationRepository)
    public notificationRepository: NotificationRepository,
  ) {}

  async create(payload: Partial<Outlier>): Promise<Outlier> {
    try {
      const user = await this.usersRepository.findById(payload.userId);
      if (!user)
        throw new HttpErrors.Conflict('User with this id does not exist');
      else {
        const userFullName = `${user.firstName} ${user.lastName}`;
        const userSubscriptions = await this.userSubscriptionsRepository.find({
          where: {userId: payload.userId, endDate: {gt: new Date()}},
        });

        if (userSubscriptions.length) {
          const existingRecords = await this.outlierRepository.findOne({
            where: {
              userId: payload.userId,
              metricType: payload.metricType,
              or: [
                {status: OutlierStatusEnum.IN_REVIEW},
                {status: OutlierStatusEnum.PENDING},
              ],
            },
          });

          if (!existingRecords) {
            const data = await this.outlierRepository.create({
              ...payload,
              userFullName,
              userSubscriptionIds: userSubscriptions.map(item => item.id),
              programIds: userSubscriptions.map(data => data.programId),
            });

            const coaches = await this.coachUserSubscriptionsRepository.find({
              where: {
                userSubscriptionId: {
                  inq: userSubscriptions.map(data => data.id),
                },
              },
              include: [
                {
                  relation: 'coach',
                  scope: {fields: {id: true, email: true, firstName: true}},
                },
              ],
            });
            const admins = await this.programsRepository.find({
              where: {id: {inq: userSubscriptions.map(data => data.programId)}},
              include: [
                {
                  relation: 'admin',
                  scope: {fields: {id: true, email: true, name: true}},
                },
              ],
            });

            const coachesEmail = coaches.map(coach => {
              if (coach?.coach?.email) {
                return {
                  email: coach?.coach?.email,
                  name: coach?.coach?.firstName,
                };
              }
            });
            const adminsEmail = admins.map(admin => {
              if (admin?.admin?.email) {
                return {email: admin?.admin?.email, name: admin?.admin?.name};
              }
            });

            const notificationPayload = {
              resourceId: data.id,
              notificationObject: {
                type: healthMetricsObject[payload.metricType],
                data,
              },
              notificationType: NotificationTypeEnum.NEW_OUTLIER,
              priority: NotificationPriorityEnum.HIGH,
              title: 'New Outlier Record',
              body: 'New outlier record has been logged!!',
            };
            const coachesNotificationsPayload = coaches.map(data => {
              notificationPayload['coachId'] = data.id;
              return notificationPayload;
            });
            const adminsNotificationsPayload = admins.map(data => {
              notificationPayload['adminId'] = data.id;
              return notificationPayload;
            });

            await this.notificationRepository.createAll([
              ...coachesNotificationsPayload,
              ...adminsNotificationsPayload,
            ]);

            if (coachesEmail?.length || adminsEmail?.length) {
              //log the data of failed email into some collection for example 'FailedEmails' so that we can run a cronjob to send the mail again
              await this.emailService.sendMail({
                to: [
                  ...(coachesEmail || []),
                  ...(adminsEmail || []),
                  {email: CLINICALS_EMAIL, name: 'clinical email'},
                ],
                slug: 'new_outlier_record',
                message: {
                  name: userFullName,
                  metricType: healthMetricsObject[payload.metricType],
                  metricValue: payload.metricValue,
                },
              });
            }
            return data;
          }
        }
      }
    } catch (error) {
      console.log(error.message);
      throw new HttpErrors.BadRequest(error.message);
    }
  }

  async findAll(
    page?: number,
    search?: string,
    filter?: any,
  ): Promise<PaginatedResponse<Outlier>> {
    const limit = Utils.getLimit(filter?.limit);
    const pageNum = page ? page : 1;
    const skip = (pageNum - 1) * limit;
    let where = filter?.where || {};
    if (search) {
      where['userFullName'] = {regexp: `/^${search}/i`};
    }

    if (
      (where?.status === OutlierStatusEnum.PENDING || !where?.status) &&
      where?.reviewerId
    ) {
      const subscriptionIds = await this.coachUserSubscriptionsRepository.find({
        where: {coachId: where?.reviewerId},
      });
      const userSubscriptionIds = subscriptionIds.map(
        item => item.userSubscriptionId,
      );
      where = {
        userSubscriptionIds: {inq: userSubscriptionIds},
        status: where?.status,
      };
    }
    const content = await this.outlierRepository.find({
      where,
      include: [
        {
          relation: 'user',
          scope: {
            fields: {
              id: true,
              name: true,
              city: true,
              image: true,
              phone: true,
              email: true,
              country: true,
            },
          },
        },
        {
          relation: 'coach',
          scope: {fields: {id: true, name: true, image: true, email: true}},
        },
        {
          relation: 'admin',
          scope: {fields: {id: true, name: true, image: true, email: true}},
        },
      ],
      order: ['created_at DESC'],
      skip,
      limit,
    });
    const count = await this.outlierRepository.count(where);
    const totalPages = Math.ceil(count.count / limit);
    return {
      data: content,
      count: count.count,
      totalPages,
      currentPage: page,
      status: 'success',
    };
  }

  async findById(id: string, filter: Filter<Outlier>) {
    const data = this.outlierRepository.findById(id, {
      where: filter?.where,
      include: [
        {
          relation: 'user',
          scope: {
            fields: {
              id: true,
              name: true,
              city: true,
              image: true,
              phone: true,
              email: true,
              country: true,
            },
          },
        },
        {
          relation: 'coach',
          scope: {fields: {id: true, name: true, image: true, email: true}},
        },
        {
          relation: 'admin',
          scope: {fields: {id: true, name: true, image: true, email: true}},
        },
      ],
    });
    return data;
  }

  async updateById(id: string, weight: Outlier): Promise<void> {
    const data = await this.outlierRepository.updateById(id, weight);
    return data;
  }

  async outlierStatistics(reviewerId?: string) {
    const where = {};
    let userSubscriptionIds: string[] = [];
    if (reviewerId) {
      where['reviewerId'] = reviewerId;
      const users = await this.coachUserSubscriptionsRepository.find({
        where: {coachId: reviewerId},
      });
      userSubscriptionIds = users.map(item => item.userSubscriptionId);
      if (userSubscriptionIds.length)
        where['userSubscriptionIds'] = {inq: userSubscriptionIds};
    }

    const inReviewCount = await this.outlierRepository.count({
      ...where,
      status: OutlierStatusEnum.IN_REVIEW,
    });
    const pendingCount = await this.outlierRepository.count({
      status: OutlierStatusEnum.PENDING,
    });
    const resolvedCount = await this.outlierRepository.count({
      ...where,
      status: OutlierStatusEnum.RESOLVED,
    });
    return {
      in_review: inReviewCount.count,
      resolved: resolvedCount.count,
      pending: pendingCount.count,
    };
  }
}
