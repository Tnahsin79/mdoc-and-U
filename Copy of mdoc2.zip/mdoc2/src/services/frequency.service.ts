import {bind, BindingScope} from '@loopback/context';
import {Filter, repository} from '@loopback/repository';
import {Frequency} from '../models';
import {FrequencyRepository} from '../repositories';

@bind({scope: BindingScope.TRANSIENT})
export class FrequencyService {
  constructor(
    @repository(FrequencyRepository)
    public frequencyRepository: FrequencyRepository,
  ) {}

  async create(payload: Omit<Frequency, 'id'>): Promise<Frequency> {
    return await this.frequencyRepository.create(payload);
  }

  async find(filter: Filter<Frequency> = {}): Promise<Frequency[]> {
    filter.order = ['name ASC'];
    return await this.frequencyRepository.find(filter);
  }
  
  async deleteById( id: string): Promise<void> {
    await this.frequencyRepository.deleteById(id);
  }
}
