// import {
//   repository,
//   AnyObject,
//   CountSchema,
//   Count,
//   Where,
// } from '@loopback/repository';
// import {
//   CoachRepository,
//   DiseaseRepository,
//   ExerciseTypesRepository,
//   EyeExaminationRepository,
//   FootExaminationRepository,
//   HealthConditionRepository,
//   HealthDiaryRepository,
//   HealthProcedureSurgeriesRepository,
//   MedicationPassportRepository,
//   MedicationRepository,
//   OutlierLogsRepository,
//   ProcedureSurgeriesRepository,
//   ProjectsCategoryRepository,
//   ProviderRepository,
//   UserDoctorsRepository,
//   PharmacyRepository,
//   UsersRepository,
//   WaistgoalRepository,
//   CoachProgramsRepository,
//   ProgramsRepository,
//   AdminRepository,
//   PlansRepository,
//   BenefitsRepository,
//   ProgramPlansRepository,
//   PlansBenefitRepository,
//   UserSubscriptionsRepository,
//   PaymentsRepository,
//   CoachTypeSpecialityRepository,
//   SpecialityRepository,
//   CoachSpecialityRepository,
//   ChangeStagesRepository,
//   AdminRoleRepository,
//   RoleRepository,
//   RolePrivilegeRepository,
//   PrivilegeRepository,
//   VoucherRepository,
// } from '../repositories';
// import moment from 'moment';
// import * as _ from 'lodash';
// import {DbDataSource} from '../datasources';
// import {inject, Getter} from '@loopback/core';
// import {isEmpty} from 'lodash';
// import {CoachTypeRepository} from '../repositories/coach-type.repository';
// import {UserDiseaseRepository} from '../repositories/user-disease.repository';
// import {CoachUserSubscriptionsRepository} from '../repositories/coach-user-subscriptions.repository';

// export class LegacySyncHandlerService {
//   static dbSoureType = new DbDataSource();

//   static async coachRepositoryGetter() {
//     return new CoachRepository(
//       LegacySyncHandlerService.dbSoureType,
//       this.userRepositoryGetter,
//       this.coachTypeRepositoryGetter,
//       this.coachProgramsRepositoryGetter,
//       this.coachSpecialityRepositoryGetter,
//       this.coachUserSubscriptionsRepositoryGetter,
//     );
//   }

//   static async coachProgramsRepositoryGetter() {
//     return new CoachProgramsRepository(
//       LegacySyncHandlerService.dbSoureType,
//       this.programsRepositoryGetter,
//       this.coachRepositoryGetter,
//     );
//   }

//   static async changeStagesRepositoryGetter() {
//     return new ChangeStagesRepository(
//       LegacySyncHandlerService.dbSoureType,
//       this.programsRepositoryGetter,
//       this.adminRepositoryGetter,
//     );
//   }

//   static async programsRepositoryGetter() {
//     return new ProgramsRepository(
//       LegacySyncHandlerService.dbSoureType,
//       this.programPlansRepositoryGetter,
//       this.benefitsRepositoryGetter,
//       this.adminRepositoryGetter,
//       this.coachProgramsRepositoryGetter,
//       this.userSubscriptionsRepositoryGetter,
//       this.changeStagesRepositoryGetter,
//     );
//   }

//   static async programPlansRepositoryGetter() {
//     return new ProgramPlansRepository(
//       LegacySyncHandlerService.dbSoureType,
//       this.programsRepositoryGetter,
//       this.plansBenefitRepositoryGetter,
//     );
//   }

//   static async roleRepositoryGetter() {
//     return new RoleRepository(
//       LegacySyncHandlerService.dbSoureType,
//       this.adminRoleRepositoryGetter,
//       this.rolePrivilegeRepositoryGetter,
//     );
//   }

//   static async privilegeRepositoryGetter() {
//     return new PrivilegeRepository(LegacySyncHandlerService.dbSoureType);
//   }

//   static async rolePrivilegeRepositoryGetter() {
//     return new RolePrivilegeRepository(
//       LegacySyncHandlerService.dbSoureType,
//       this.roleRepositoryGetter,
//       this.privilegeRepositoryGetter,
//     );
//   }

//   static async adminRoleRepositoryGetter() {
//     return new AdminRoleRepository(
//       LegacySyncHandlerService.dbSoureType,
//       this.adminRepositoryGetter,
//       this.roleRepositoryGetter,
//     );
//   }

//   static async adminRepositoryGetter() {
//     return new AdminRepository(
//       LegacySyncHandlerService.dbSoureType,
//       this.adminRoleRepositoryGetter,
//     );
//   }

//   static async benefitsRepositoryGetter() {
//     return new BenefitsRepository(
//       LegacySyncHandlerService.dbSoureType,
//       this.programsRepositoryGetter,
//     );
//   }

//   static async coachUserSubscriptionsRepositoryGetter() {
//     return new CoachUserSubscriptionsRepository(
//       LegacySyncHandlerService.dbSoureType,
//       this.userSubscriptionsRepositoryGetter,
//       this.coachRepositoryGetter,
//     );
//   }

//   static async userSubscriptionsRepositoryGetter() {
//     return new UserSubscriptionsRepository(
//       LegacySyncHandlerService.dbSoureType,
//       this.programsRepositoryGetter,
//       this.programPlansRepositoryGetter,
//       this.userRepositoryGetter,
//       this.paymentsRepositoryGetter,
//       this.coachUserSubscriptionsRepositoryGetter,
//       this.voucherRepositoryGetter,
//     );
//   }

//   static async voucherRepositoryGetter() {
//     return new VoucherRepository(
//       LegacySyncHandlerService.dbSoureType,
//       this.programPlansRepositoryGetter,
//       this.programsRepositoryGetter,
//       this.adminRepositoryGetter,
//     );
//   }

//   static async paymentsRepositoryGetter() {
//     return new PaymentsRepository(
//       LegacySyncHandlerService.dbSoureType,
//       this.userRepositoryGetter,
//       this.programsRepositoryGetter,
//       this.programPlansRepositoryGetter
//     );
//   }

//   static async plansBenefitRepositoryGetter() {
//     return new PlansBenefitRepository(
//       LegacySyncHandlerService.dbSoureType,
//       this.benefitsRepositoryGetter,
//     );
//   }

//   static async plansRepositoryGetter() {
//     return new PlansRepository(LegacySyncHandlerService.dbSoureType);
//   }

//   static async diseaseRepositoryGetter() {
//     return new DiseaseRepository(
//       LegacySyncHandlerService.dbSoureType,
//       this.userDiseaseRepositoryGetter,
//     );
//   }

//   static async userDiseaseRepositoryGetter() {
//     return new UserDiseaseRepository(
//       LegacySyncHandlerService.dbSoureType,
//       this.userRepositoryGetter,
//       this.diseaseRepositoryGetter,
//     );
//   }

//   static async userRepositoryGetter() {
//     return new UsersRepository(
//       LegacySyncHandlerService.dbSoureType,
//       this.userSubscriptionsRepositoryGetter,
//       this.userDiseaseRepositoryGetter,
//     );
//   }

//   static async coachTypeRepositoryGetter() {
//     return new CoachTypeRepository(
//       LegacySyncHandlerService.dbSoureType,
//       this.coachTypeSpecialityRepositoryGetter,
//     );
//   }

//   static async specialityRepositoryGetter() {
//     return new SpecialityRepository(
//       LegacySyncHandlerService.dbSoureType,
//       this.coachTypeSpecialityRepositoryGetter,
//       this.coachSpecialityRepositoryGetter,
//     );
//   }

//   static async coachTypeSpecialityRepositoryGetter() {
//     return new CoachTypeSpecialityRepository(
//       LegacySyncHandlerService.dbSoureType,
//       this.coachTypeRepositoryGetter,
//       this.specialityRepositoryGetter,
//     );
//   }

//   static async coachSpecialityRepositoryGetter() {
//     return new CoachSpecialityRepository(
//       LegacySyncHandlerService.dbSoureType,
//       this.coachRepositoryGetter,
//       this.specialityRepositoryGetter,
//     );
//   }

//   static async findAndInsertRecord(memberId: number, payload: any) {
//     const userRepo = new UsersRepository(
//       LegacySyncHandlerService.dbSoureType,
//       this.userSubscriptionsRepositoryGetter,
//       this.userDiseaseRepositoryGetter,
//     );
//     const result = await userRepo.findOne({
//       where: {providerId: memberId},
//     });

//     if (result && result.id) {
//       payload.userId = result.id;
//       const healthDiaryRepository = new HealthDiaryRepository(
//         LegacySyncHandlerService.dbSoureType,
//       );
//       await healthDiaryRepository.create(payload);
//     } else {
//       console.log('CompleteHealth Legacy ID not found', memberId);
//     }
//   }

//   static async healthDairyWeightMigration({
//     weight,
//     memberId,
//     date,
//   }: {
//     weight: string;
//     memberId: number;
//     date: Date;
//   }): Promise<any> {
//     let payload: AnyObject = {
//       providerId: memberId,
//       type: 'weight',
//       weight: {
//         value: Number(weight),
//         unit: 'Kilogram',
//         goal: '0',
//         date: moment(date).toDate(),
//       },
//       isHealthDiaryCompleted: true,
//       created: moment(new Date()).toDate(),
//     };

//     LegacySyncHandlerService.findAndInsertRecord(memberId, payload);
//   }

//   static async healthDairyBloodPressureMigration(data: any): Promise<any> {
//     const bloodPressureValue = data.blood.split('/');

//     let payload: AnyObject = {
//       providerId: data.providerid,
//       type: 'bloodPressure',
//       bloodPressure: {
//         systolic: bloodPressureValue[0],
//         diastolic: bloodPressureValue[1],
//         date: moment(data.time_stamp).toDate(),
//       },
//       isHealthDiaryCompleted: true,
//       created: moment(data.created_date).toDate(),
//     };

//     LegacySyncHandlerService.findAndInsertRecord(data.providerid, payload);
//   }

//   static async healthDairyBMIMigration(data: any): Promise<any> {
//     let payload: AnyObject = {
//       providerId: data.providerid,
//       type: 'bmi',
//       bmi: {
//         value: data?.bmi || '',
//         message: '',
//         goal: '0',
//         date: moment(data.date).toDate(),
//       },
//       isHealthDiaryCompleted: true,
//       created: moment(data.created_date).toDate(),
//     };
//     LegacySyncHandlerService.findAndInsertRecord(data.providerid, payload);
//   }

//   static async healthDairyCholesterolMigration(data: any): Promise<any> {
//     let payload: AnyObject = {
//       providerId: data.providerid,
//       type: 'cholesterol',
//       cholesterol: {
//         cholesterol: data?.min_chole || '',
//         triglycerides: data?.min_trigl || '',
//         hdl: data?.min_hdl || '',
//         ldl: data?.min_ldl || '',
//         date: moment(data.chol_date).toDate(),
//       },
//       isHealthDiaryCompleted: true,
//       created: moment(data.created_date).toDate(),
//     };
//     LegacySyncHandlerService.findAndInsertRecord(data.providerid, payload);
//   }

//   static async healthDairyExerciseMigration(data: any): Promise<any> {
//     let payload: AnyObject = {
//       providerId: data.providerId,
//       type: 'exercise',
//       exercise: {
//         duration: data?.exercise_duration || '',
//         intensity: data?.exercise_intens || '',
//         exerciseName: data.exercise_name,
//         date: moment(data.date_of_exercise).toDate(),
//         created: moment(data.date_of_exercise).toDate(),
//       },
//       isHealthDiaryCompleted: true,
//       created: moment(data.created_date).toDate(),
//     };
//     LegacySyncHandlerService.findAndInsertRecord(data.providerid, payload);
//   }

//   static async healthDairyEyeMigration(data: any): Promise<any> {
//     let payload: AnyObject = {
//       providerId: data.providerId,
//       name: data?.providername || '',
//       address: data?.location,
//       isEyeExaminationComplete: true,
//       testDate: moment(data.lastexamdate).toDate(),
//       created: moment(data.created_date).toDate(),
//     };

//     const userRepo = new UsersRepository(
//       LegacySyncHandlerService.dbSoureType,
//       this.userSubscriptionsRepositoryGetter,
//       this.userDiseaseRepositoryGetter,
//     );
//     const result = await userRepo.findOne({
//       where: {providerId: data.providerId},
//     });

//     if (result && result.id) {
//       payload.userId = result.id;
//       const eyeExaminationRepository = new EyeExaminationRepository(
//         LegacySyncHandlerService.dbSoureType,
        
//       );
//       await eyeExaminationRepository.create(payload);
//     } else {
//       console.log('CompleteHealth Legacy ID not found', data.providerId);
//     }
//   }

//   static async healthDairyFootMigration(data: any): Promise<any> {
//     let payload: AnyObject = {
//       providerId: data.providerId,
//       name: data?.providername || '',
//       address: data?.location,
//       isFootExaminationComplete: true,
//       testDate: moment(data.lastexamdate).toDate(),
//       created: moment(data.created_date).toDate(),
//     };

//     const userRepo = new UsersRepository(
//       LegacySyncHandlerService.dbSoureType,
//       this.userSubscriptionsRepositoryGetter,
//       this.userDiseaseRepositoryGetter,
//     );
//     const result = await userRepo.findOne({
//       where: {providerId: data.providerId},
//     });

//     if (result && result.id) {
//       payload.userId = result.id;
//       const footExaminationRepository = new FootExaminationRepository(
//         LegacySyncHandlerService.dbSoureType,
//       );
//       await footExaminationRepository.create(payload);
//     } else {
//       console.log('CompleteHealth Legacy ID not found', data.providerId);
//     }
//   }

//   static async healthDairyWaistMigration(data: any): Promise<any> {
//     let payload: AnyObject = {
//       providerId: data.providerid,
//       type: 'waist',
//       waist: {
//         value: data?.waist || '',
//         unit: 'cm',
//         goal: '0',
//         date: moment(data.waist_date).toDate(),
//       },
//       isHealthDiaryCompleted: true,
//       created: moment(data.created_date).toDate(),
//     };
//     LegacySyncHandlerService.findAndInsertRecord(data.providerid, payload);
//   }

//   static async healthDairyHBA1cMigration(data: any): Promise<any> {
//     let payload: AnyObject = {
//       providerId: data.providerid,
//       type: 'hbaicLevel',
//       hbaicLevel: data.value,
//       isHealthDiaryCompleted: true,
//       created: moment(data.created_date).toDate(),
//     };
//     LegacySyncHandlerService.findAndInsertRecord(data.providerid, payload);
//   }

//   static async healthDairyUpdateWeightGoalMigration(data: any): Promise<any> {
//     const waistgoalRepository = new WaistgoalRepository(
//       LegacySyncHandlerService.dbSoureType,
//     );

//     const userRepo = new UsersRepository(
//       LegacySyncHandlerService.dbSoureType,
//       this.userSubscriptionsRepositoryGetter,
//       this.userDiseaseRepositoryGetter,
//     );
//     const userResult = await userRepo.findOne({
//       where: {providerId: data.providerid},
//     });

//     if (userResult && userResult.id) {
//       let result: any = await waistgoalRepository.findOne({
//         where: {userId: userResult.id},
//       });

//       if (result) {
//         result.weightGoal = data?.goal;

//         await waistgoalRepository
//           .updateById(result.id, result)
//           .then(res => {
//             console.log(res, '--------------------');
//           })
//           .catch(err => {
//             console.log(err, '=======================error');
//           });
//       } else {
//         let result: any = {};
//         result.weightGoal = data?.goal;
//         result.waistGoal = 0;
//         result.userId = userResult.id;
//         result.created = new Date();
//         await waistgoalRepository.create(result);
//       }
//     } else {
//       console.log('CompleteHealth Legacy ID not found', data.providerid);
//     }
//   }

//   static async healthDairyGlucoseMigration(data: any): Promise<any> {
//     if (
//       (data && data.mealtype === 'Breakfast') ||
//       data.mealtype === 'Lunch' ||
//       data.mealtype === 'Dinner' ||
//       data.mealtype === 'Snaks' ||
//       data.mealtype === 'Fasting Blood Glucose' ||
//       data.mealtype === 'Random Blood Sugar'
//     ) {
//       let payload: AnyObject = {
//         providerId: data.providerid,
//         type: 'glucose',
//         isHealthDiaryCompleted: true,
//         glucose: {
//           unit: data?.selected_unit,
//           date: moment(data.date).toDate(),
//           breakfast: {
//             before: '0',
//             after: '0',
//           },
//           lunch: {
//             before: '0',
//             after: '0',
//           },
//           dinner: {
//             before: '0',
//             after: '0',
//           },
//           snacks: {
//             before: '0',
//             after: '0',
//           },
//           fastingBloodGlucose: {
//             before: '0',
//             after: '0',
//           },
//           randomBloodSugar: {
//             before: '0',
//             after: '0',
//           },
//         },
//       };
//       if (data.mealtype === 'Breakfast') {
//         payload.glucose.breakfast = {
//           before: data?.before_meal || '0',
//           after: data?.after_meal || '0',
//         };
//       } else if (data.mealtype === 'Lunch') {
//         payload.glucose.lunch = {
//           before: data?.before_meal || '0',
//           after: data?.after_meal || '0',
//         };
//       } else if (data.mealtype === 'Dinner') {
//         payload.glucose.dinner = {
//           before: data?.before_meal || '0',
//           after: data?.after_meal || '0',
//         };
//       } else if (data.mealtype === 'Snaks') {
//         payload.glucose.snacks = {
//           before: data?.before_meal || '0',
//           after: data?.after_meal || '0',
//         };
//       } else if (data.mealtype === 'Fasting Blood Glucose') {
//         payload.glucose.fastingBloodGlucose = {
//           before: data?.fasting_blood_glucose || '0',
//           after: '0',
//         };
//       } else if (data.mealtype === 'Random Blood Sugar') {
//         payload.glucose.randomBloodSugar = {
//           before: '0',
//           after: data?.random_blood_sugar,
//         };
//       }

//       LegacySyncHandlerService.findAndInsertRecord(data.providerid, payload);
//     }
//   }

//   static async healthDairyPSAMigration(data: any): Promise<any> {
//     let payload: AnyObject = {
//       providerId: data.providerid,
//       type: 'psa',
//       psa: {
//         totalPSA: data?.free_psa || '',
//         freePSA: data?.test_result || '',
//         date: moment(data.date_lab).toDate(),
//       },
//       isHealthDiaryCompleted: true,
//       created: moment(data.created_date).toDate(),
//     };
//     LegacySyncHandlerService.findAndInsertRecord(data.providerid, payload);
//   }

//   static async userMigration(data: AnyObject): Promise<any> {
//     const baseUrl = 'https://www.mymdoc.com/data/images/';

//     let payload: AnyObject = {
//       providerId: data.providerId,
//       name: data?.firstName + ' ' + data?.lastName || '',
//       firstName: data?.firstName || '',
//       lastName: data?.lastName || '',
//       image: baseUrl + data.imageUrl,
//       phone: '+' + data?.tel || '',
//       email: data?.emailAddress || '',
//       md5password: data.password || '',
//       dob: data?.dob && moment(data.dob).toDate(),
//       gender: data?.gender || '',
//       isProfileComplete: true,
//       contactInfo: {
//         homePhone: data?.cellPhone || '',
//         workPhone: data?.workPhone || '',
//         homePhoneCode: '',
//         workPhoneCode: '',
//       },
//       locationInfo: {
//         country: data?.country || '',
//         state: data?.suburb || '',
//         city: data?.city || '',
//         address: data?.address1 || '',
//         zipCode: data?.zipCode || '',
//       },
//       emergencyInfo: {
//         name: data?.EmergencyContactName || '',
//         phone: data?.EmergencyContactPhone || '',
//         email: data?.EmergencyContactEmail || '',
//         relationship: data?.EmergencyContactRelationship || '',
//       },
//       height: data?.height || '',
//       created: moment(data.dateCreated).toDate(),
//     };

//     // const adminRepositoryGetter =async () => {
//     //   return new AdminRepository(
//     //     LegacySyncHandlerService.dbSoureType,
//     //   )
//     // };

//     // const benefitsRepositoryGetter =async () => {
//     //   return new BenefitsRepository(
//     //     LegacySyncHandlerService.dbSoureType,
//     //     programsRepositoryGetter
//     //   )
//     // };

//     // const plansBenefitRepositoryGetter =async () => {
//     //   return new PlansBenefitRepository(
//     //     LegacySyncHandlerService.dbSoureType,
//     //   )
//     // };

//     // const plansRepositoryGetter =async () => {
//     //   return new PlansRepository(
//     //     LegacySyncHandlerService.dbSoureType,
//     //   )
//     // };

//     // const userRepositoryGetter = async () => {
//     //   return new UsersRepository(
//     //     LegacySyncHandlerService.dbSoureType,
//     //     userSubscriptionsRepositoryGetter
//     //   );
//     // };

//     // const coachTypeRepositoryGetter =async () => {
//     //   return new CoachTypeRepository(
//     //     LegacySyncHandlerService.dbSoureType,
//     //   )
//     // }

//     // const coachRepositoryGetter = async () => {
//     //   return new CoachRepository(
//     //     LegacySyncHandlerService.dbSoureType,
//     //     userRepositoryGetter,
//     //     coachTypeRepositoryGetter,
//     //     coachProgramsRepositoryGetter
//     //   )
//     // };
//     // const coachProgramsRepositoryGetter =async () => {
//     //   return new CoachProgramsRepository(
//     //     LegacySyncHandlerService.dbSoureType,
//     //     programsRepositoryGetter,
//     //     coachRepositoryGetter
//     //   )
//     // }

//     // const programPlansRepositoryGetter =async () => {
//     //   return new ProgramPlansRepository(
//     //     LegacySyncHandlerService.dbSoureType,
//     //     programsRepositoryGetter,
//     //     plansBenefitRepositoryGetter
//     //   )
//     // };

//     // const programsRepositoryGetter =async () => {
//     //   return new ProgramsRepository(
//     //     LegacySyncHandlerService.dbSoureType,
//     //     programPlansRepositoryGetter,
//     //     benefitsRepositoryGetter,
//     //     adminRepositoryGetter,
//     //     coachProgramsRepositoryGetter
//     //   )
//     // };

//     // const paymentsRepositoryGetter =async () => {
//     //   return new PaymentsRepository(
//     //     LegacySyncHandlerService.dbSoureType,
//     //     userRepositoryGetter
//     //   )
//     // };

//     // const userSubscriptionsRepositoryGetter =async () => {
//     //   return new UserSubscriptionsRepository(
//     //     LegacySyncHandlerService.dbSoureType,
//     //     programsRepositoryGetter,
//     //     plansRepositoryGetter,
//     //     userRepositoryGetter,
//     //     paymentsRepositoryGetter,
//     //   )
//     // };

//     const usersRepository = new UsersRepository(
//       LegacySyncHandlerService.dbSoureType,
//       this.userSubscriptionsRepositoryGetter,
//       this.userDiseaseRepositoryGetter,
//     );

//     const exist = await usersRepository.findOne({
//       where: {
//         or: [
//           {phone: (payload && payload.phone) || 'null1'},
//           {email: (payload && payload.email) || 'null2'},
//         ],
//       },
//     });
//     if (exist && exist.id) {
//       console.log('User already exist in DB');
//     } else {
//       await usersRepository.create(payload);
//     }
//   }

//   static async assignCoachMemberMigration(data: AnyObject): Promise<any> {
//     // const userRepositoryGetter = async () => {
//     //   return new UsersRepository(
//     //     LegacySyncHandlerService.dbSoureType,
//     //     userSubscriptionsRepositoryGetter
//     //   );
//     // };

//     // const coachTypeRepositoryGetter =async () => {
//     //   return new CoachTypeRepository(
//     //     LegacySyncHandlerService.dbSoureType,
//     //   )
//     // }

//     // const coachRepositoryGetter =async () => {
//     //   return new CoachRepository(
//     //     LegacySyncHandlerService.dbSoureType,
//     //     userRepositoryGetter,
//     //     coachTypeRepositoryGetter,
//     //     coachProgramsRepositoryGetter
//     //   )
//     // };
//     // const coachProgramsRepositoryGetter =async () => {
//     //   return new CoachProgramsRepository(
//     //     LegacySyncHandlerService.dbSoureType,
//     //     programsRepositoryGetter,
//     //     coachRepositoryGetter
//     //   )
//     // }

//     // const programPlansRepositoryGetter =async () => {
//     //   return new ProgramPlansRepository(
//     //     LegacySyncHandlerService.dbSoureType,
//     //     programsRepositoryGetter,
//     //     plansBenefitRepositoryGetter
//     //   )
//     // };

//     // const paymentsRepositoryGetter =async () => {
//     //   return new PaymentsRepository(
//     //     LegacySyncHandlerService.dbSoureType,
//     //     userRepositoryGetter
//     //   )
//     // };

//     // const plansRepositoryGetter =async () => {
//     //   return new PlansRepository(
//     //     LegacySyncHandlerService.dbSoureType,
//     //   )
//     // };
//     // const userSubscriptionsRepositoryGetter =async () => {
//     //   return new UserSubscriptionsRepository(
//     //     LegacySyncHandlerService.dbSoureType,
//     //     programsRepositoryGetter,
//     //     plansRepositoryGetter,
//     //     userRepositoryGetter,
//     //     paymentsRepositoryGetter,
//     //   )
//     // };

//     // const adminRepositoryGetter =async () => {
//     //   return new AdminRepository(
//     //     LegacySyncHandlerService.dbSoureType,
//     //   )
//     // };

//     // const benefitsRepositoryGetter =async () => {
//     //   return new BenefitsRepository(
//     //     LegacySyncHandlerService.dbSoureType,
//     //     programsRepositoryGetter
//     //   )
//     // };

//     // const plansBenefitRepositoryGetter =async () => {
//     //   return new PlansBenefitRepository(
//     //     LegacySyncHandlerService.dbSoureType,
//     //   )
//     // };

//     // const programsRepositoryGetter =async () => {
//     //   return new ProgramsRepository(
//     //     LegacySyncHandlerService.dbSoureType,
//     //     programPlansRepositoryGetter,
//     //     benefitsRepositoryGetter,
//     //     adminRepositoryGetter,
//     //     coachProgramsRepositoryGetter
//     //   )
//     // };

//     const coachRepository = new CoachRepository(
//       LegacySyncHandlerService.dbSoureType,
//       this.userRepositoryGetter,
//       this.coachTypeRepositoryGetter,
//       this.coachProgramsRepositoryGetter,
//       this.coachSpecialityRepositoryGetter,
//       this.coachUserSubscriptionsRepositoryGetter,
//     );

//     const usersRepository = new UsersRepository(
//       LegacySyncHandlerService.dbSoureType,
//       this.userSubscriptionsRepositoryGetter,
//       this.userDiseaseRepositoryGetter,
//     );

//     let coach = await coachRepository.findOne({
//       where: {
//         coachId: data.coachId,
//       },
//     });
//     if (coach && coach.id) {
//       let user = await usersRepository.findOne({
//         where: {
//           providerId: data.providerId,
//         },
//       });

//       if (user && user.id) {
//         let payload: AnyObject = {
//           assignCoachId: coach.id,
//         };
//         await usersRepository.updateById(user.id, payload);
//       }
//     }
//   }

//   static async userPhamacyRecordsMigration(data: AnyObject): Promise<any> {
//     let payload: AnyObject = {
//       name: data?.name || '',
//       address: data?.address || '',
//       providerId: data?.providerId || '',
//       isPharmacyComplete: true,
//       created: moment(data.created_date, 'YYYY-MM-DD H:mm:ss').toISOString(),
//     };

//     const usersRepository = new UsersRepository(
//       LegacySyncHandlerService.dbSoureType,
//       this.userSubscriptionsRepositoryGetter,
//       this.userDiseaseRepositoryGetter,
//     );

//     const userPhamacyRecordsRepository = new PharmacyRepository(
//       LegacySyncHandlerService.dbSoureType,
//     );

//     const result = await usersRepository.findOne({
//       where: {providerId: data.providerId},
//     });

//     if (result) {
//       payload.createdBy = result?.id;
//       await userPhamacyRecordsRepository.create(payload);
//     } else {
//       console.log('User not found with ID', data.providerId);
//     }
//   }

//   static async userDoctorsMigration(data: AnyObject): Promise<any> {
//     let payload: AnyObject = {
//       name: data?.doctorname || '',
//       hospitalName: data?.hospitalname || '',
//       address: data?.address || '',
//       providerId: data?.providerId || '',
//       isProviderComplete: true,
//       created: moment(data.created_date, 'YYYY-MM-DD H:mm:ss').toISOString(),
//     };

//     const usersRepository = new UsersRepository(
//       LegacySyncHandlerService.dbSoureType,
//       this.userSubscriptionsRepositoryGetter,
//       this.userDiseaseRepositoryGetter,
//     );

//     const providerRepository = new ProviderRepository(
//       LegacySyncHandlerService.dbSoureType,
//     );
//     const result = await usersRepository.findOne({
//       where: {providerId: data.providerId},
//     });

//     if (result) {
//       payload.userId = result?.id;
//       await providerRepository.create(payload);
//     } else {
//       console.log('User not found with ID', data.providerId);
//     }
//   }

//   static async userOutlierLogsMigration(data: AnyObject): Promise<any> {
//     let payload: AnyObject = {
//       coachProviderId: data?.notified_coach_provider_id || '',
//       memberProviderId: data?.outlier_member_provider_id || '',
//       outlierType: data?.outlier_type || '',
//       outlierValue: data?.outlier_value || '',
//       outlierNotificationDatetime: moment(
//         data.outlier_notification_datetime,
//         'DD-MM-YYYY H:mm:ss',
//       ).toISOString(),
//     };

//     const usersRepository = new UsersRepository(
//       LegacySyncHandlerService.dbSoureType,
//       this.userSubscriptionsRepositoryGetter,
//       this.userDiseaseRepositoryGetter,
//     );

//     // const coachTypeRepositoryGetter =async () => {
//     //   return new CoachTypeRepository(
//     //     LegacySyncHandlerService.dbSoureType,
//     //   )
//     // };

//     // const adminRepositoryGetter =async () => {
//     //   return new AdminRepository(
//     //     LegacySyncHandlerService.dbSoureType,
//     //   )
//     // };

//     // const benefitsRepositoryGetter =async () => {
//     //   return new BenefitsRepository(
//     //     LegacySyncHandlerService.dbSoureType,
//     //     programsRepositoryGetter
//     //   )
//     // };

//     // const plansBenefitRepositoryGetter =async () => {
//     //   return new PlansBenefitRepository(
//     //     LegacySyncHandlerService.dbSoureType,
//     //   )
//     // };

//     // const plansRepositoryGetter =async () => {
//     //   return new ProgramPlansRepository(
//     //     LegacySyncHandlerService.dbSoureType,
//     //     programsRepositoryGetter,
//     //     plansBenefitRepositoryGetter
//     //   )
//     // };

//     // const programsRepositoryGetter =async () => {
//     //   return new ProgramsRepository(
//     //     LegacySyncHandlerService.dbSoureType,
//     //     plansRepositoryGetter,
//     //     benefitsRepositoryGetter,
//     //     adminRepositoryGetter,
//     //     coachProgramsRepositoryGetter
//     //   )
//     // };

//     // const coachRepositoryGetter =async () => {
//     //   return new CoachRepository(
//     //     LegacySyncHandlerService.dbSoureType,
//     //     userRepositoryGetter,
//     //     coachTypeRepositoryGetter,
//     //     coachProgramsRepositoryGetter
//     //   )
//     // };
//     // const coachProgramsRepositoryGetter =async () => {
//     //   return new CoachProgramsRepository(
//     //     LegacySyncHandlerService.dbSoureType,
//     //     programsRepositoryGetter,
//     //     coachRepositoryGetter
//     //   )
//     // }

//     const coachRepository = new CoachRepository(
//       LegacySyncHandlerService.dbSoureType,
//       this.userRepositoryGetter,
//       this.coachTypeRepositoryGetter,
//       this.coachProgramsRepositoryGetter,
//       this.coachSpecialityRepositoryGetter,
//       this.coachUserSubscriptionsRepositoryGetter,
//     );

//     const outlierLogsRepository = new OutlierLogsRepository(
//       LegacySyncHandlerService.dbSoureType,
//     );

//     const result = await usersRepository.findOne({
//       where: {providerId: data.outlier_member_provider_id},
//     });
//     const coachresult = await coachRepository.findOne({
//       where: {coachId: data.notified_coach_provider_id},
//     });
//     if (coachresult && coachresult.id && result?.id) {
//       payload.coachId = coachresult.id;
//       payload.userId = result?.id;
//       await outlierLogsRepository.create(payload);
//     } else {
//       console.log('User not found with ID', data.providerId);
//     }
//   }

//   static async HealthConditionMigration(data: AnyObject): Promise<any> {
//     let conditions: AnyObject = {};

//     const diseaseRepository = new DiseaseRepository(
//       LegacySyncHandlerService.dbSoureType,
//       this.userDiseaseRepositoryGetter,
//     );

//     let conditionsData = await diseaseRepository.findOne({
//       where: {
//         name: data.conditions,
//       },
//     });
//     if (!isEmpty(conditions)) {
//       conditions = Object.assign({}, conditionsData);
//     } else {
//       let mediPayload = {
//         userId: '626baa41f491cb44c44952ec', //Inserted by ID
//         name: data.conditions,
//       };
//       let healthData = await diseaseRepository.create(mediPayload);
//       conditions = Object.assign({}, healthData);
//     }

//     if (!isEmpty(conditions)) {
//       const usersRepository = new UsersRepository(
//         LegacySyncHandlerService.dbSoureType,
//         this.userSubscriptionsRepositoryGetter,
//         this.userDiseaseRepositoryGetter,
//       );

//       let user = await usersRepository.findOne({
//         where: {providerId: data.providerId},
//       });

//       if (!isEmpty(user)) {
//         const healthConditionRepository = new HealthConditionRepository(
//           LegacySyncHandlerService.dbSoureType,
//           {} as any,
//           {} as any,
//         );

//         let currentDate = moment()
//           .startOf('day')
//           .unix();
//         let mediDate = moment(data.reporteddate, 'YYYY-MM-DD')
//           .startOf('day')
//           .unix();
//         let payload: AnyObject = {
//           userId: user?.id,
//           diseaseId: conditions?.id,
//           type: mediDate > currentDate ? 'current' : 'past',
//           isHealthConditionComplete: true,
//           diseaseDate: moment(data.reporteddate).toDate(),
//           source: data.source,
//           created: moment(data.created_date).toDate(),
//         };
//         await healthConditionRepository.create(payload);
//       } else {
//         console.log('User not found with ID', data.providerId);
//       }
//     }
//   }

//   static async MedicationPassports(data: AnyObject): Promise<any> {
//     const medicationRepository = new MedicationRepository(
//       LegacySyncHandlerService.dbSoureType,
//     );

//     const usersRepository = new UsersRepository(
//       LegacySyncHandlerService.dbSoureType,
//       this.userSubscriptionsRepositoryGetter,
//       this.userDiseaseRepositoryGetter,
//     );

//     const medicationPassportRepository = new MedicationPassportRepository(
//       LegacySyncHandlerService.dbSoureType,
//       {} as any,
//       {} as any,
//     );

//     let medication: AnyObject = {};
//     let medicationData = await medicationRepository.findOne({
//       where: {
//         name: data.medication,
//       },
//     });
//     if (!isEmpty(medication)) {
//       medication = Object.assign({}, medicationData);
//     } else {
//       let mediPayload = {
//         userId: '626baa41f491cb44c44952ec',
//         name: data.medication,
//       };
//       let mediData = await medicationRepository.create(mediPayload);
//       medication = Object.assign({}, mediData);
//     }
//     if (!isEmpty(medication)) {
//       let user = await usersRepository.findOne({
//         where: {providerId: data.providerId},
//       });
//       if (!isEmpty(user)) {
//         let currentDate = moment()
//           .startOf('day')
//           .unix();
//         let mediDate = moment(data.reporteddate, 'YYYY-MM-DD')
//           .startOf('day')
//           .unix();
//         let payload: AnyObject = {
//           userId: user?.id,
//           medicationId: medication?.id,
//           type: mediDate > currentDate ? 'current' : 'past',
//           frequency: data.frequency,
//           isMedicationPassportComplete: true,
//           startDate: moment(data.reporteddate).toDate(),
//           source: data.source,
//           created: moment(data.created_date).toDate(),
//         };
//         await medicationPassportRepository.create(payload);
//       }
//     }
//   }

//   static async healthProcedureSurgeryMigration(data: AnyObject): Promise<any> {
//     const procedureSurgeriesRepository = new ProcedureSurgeriesRepository(
//       LegacySyncHandlerService.dbSoureType,
//     );

//     let procedure = await procedureSurgeriesRepository.findOne({
//       where: {procedureId: data.procedures},
//     });

//     if (!procedure) {
//       procedure = await procedureSurgeriesRepository.create({
//         name: data.procedures,
//         userId: '626bc76b8e563e1708b62939',
//         procedureId: data.Id,
//         created: moment().toISOString(),
//       });
//     }

//     const usersRepository = new UsersRepository(
//       LegacySyncHandlerService.dbSoureType,
//       this.userSubscriptionsRepositoryGetter,
//       this.userDiseaseRepositoryGetter,
//     );

//     let user = await usersRepository.findOne({
//       where: {providerId: data.providerId},
//     });
//     if (user && user.id) {
//       const healthProcedureSurgeriesRepository = new HealthProcedureSurgeriesRepository(
//         LegacySyncHandlerService.dbSoureType,
//         {} as any,
//         {} as any,
//       );

//       let payload: AnyObject = {
//         userId: user.id,
//         procedureId: procedure.id,
//         treatmentDate: moment(data.created_date).toDate(),
//         isHealthProcedureComplete: true,
//         created: moment().toISOString(),
//       };

//       await healthProcedureSurgeriesRepository
//         .create(payload)
//         .then(res => {
//           console.log(res.id);
//         })
//         .catch(err => {
//           console.log(err);
//         });
//     } else {
//       console.log('User not found with ID', data.providerId);
//     }
//   }
// }
