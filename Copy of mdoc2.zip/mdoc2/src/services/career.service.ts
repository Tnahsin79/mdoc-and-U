import { Filter, repository } from "@loopback/repository";
import { CareerRepository } from "../repositories";
import { BindingScope, bind, inject } from "@loopback/context";
import { ControllerServiceBindings } from "../keys";
import { ControllerService } from "./controller.service";
import { Career, CareerWithRelations } from "../models";
import { UserProfile, securityId } from "@loopback/security";
import { PaginatedResponse } from "../type-schema";
import Utils from "../utils";
import { HttpErrors } from "@loopback/rest";
import { JobStatusEnum } from "../utils/enums";

@bind({ scope: BindingScope.CONTEXT })
export class CareerService {
  constructor(
    @repository(CareerRepository)
    public careerRepository: CareerRepository,
    @inject(ControllerServiceBindings.CONTROLLER_SERVICE)
    public controllerService: ControllerService
  ) {}

  async create(payload: Career, currentUser: UserProfile): Promise<Career> {
    return this.careerRepository.create({
      ...payload,
      creatorId: currentUser[securityId],
      created_at: new Date().toString(),
      modified_at: new Date().toString(),
    });
  }

  async find(
    filter: Filter<Career>,
    page: number,
    search: string,
  ): Promise<PaginatedResponse<CareerWithRelations>> {
    const limit = Utils.getLimit(filter?.limit);
    const pageNum = page ? page : 1;
    const skip = (pageNum - 1) * limit;
    const where = filter?.where || {};

    if (search) {
      where["title"] = {regexp: new RegExp('.*' + search + '.*', 'i')}
    }

    const content = await this.careerRepository.find({
      where: { ...where },
      limit,
      skip,
      include: [{ relation: "creator" }],
    });
    
    const count = await this.careerRepository.count(filter?.where);
    const totalPages = Math.ceil(count.count / limit);
    return {
      data: content,
      count: count.count,
      totalPages,
      currentPage: page,
      status: "success",
    };
  }

  async findById(id: string, filter?: Filter<Career>) {
    const data = this.careerRepository.findById(id, {
      where: filter?.where,
      include: [{ relation: "creator" }],
    });
    return data;
  }

  async updateById(id: string, job: Partial<Career>): Promise<void> {
    const findCareer = await this.findById(id);
    if (!findCareer) {
      throw new HttpErrors[404]("Career does not exist");
    }

    await this.careerRepository.updateById(id, job);
  }

  async statistics(): Promise<object> {
    const careers = await this.careerRepository.find();
    const allJobs = careers.length;
    const ongoingJobs = careers.filter(
      (carrer: Career) => carrer.status === JobStatusEnum.ONGOING
    ).length;
  
    const draftJobs = careers.filter(
      (carrer: Career) => carrer.status === JobStatusEnum.DRAFT
    ).length;

    const closedJobs = careers.filter(
      (carrer: Career) => carrer.status === JobStatusEnum.CLOSED
    ).length;

    return {
      allJobs,
      ongoingJobs,
      draftJobs,
      closedJobs,
    };
  }
}
