import {bind, BindingScope} from '@loopback/context';
import {Filter, repository} from '@loopback/repository';
import {Speciality} from '../models';
import {SpecialityRepository} from '../repositories';
import {PaginatedResponse} from '../type-schema';

@bind({scope: BindingScope.TRANSIENT})
export class SpecialityService {
  constructor(
    @repository(SpecialityRepository)
    public specialityRepository: SpecialityRepository,
  ) {}

  async create(speciality: Omit<Speciality, 'id'>): Promise<Speciality> {
    return this.specialityRepository.create(speciality);
  }

  async find(
    filter?: any,
    page?: number,
  ): Promise<PaginatedResponse<Speciality>> {
    let where;
    let searchString = filter?.searchString;
    if (searchString.includes('+')) {
      searchString = searchString.replace('+', '');
      where = {
        name: {
          like: searchString,
          options: 'i',
        },
      };
    }
    const pageSize =
      filter?.limit && Number(filter?.limit) === 0
        ? undefined
        : filter?.limit ?? 20;
    const pageNum = page ?? 1;
    const skip = (pageNum - 1) * (pageSize || 0);
    const count = await this.specialityRepository.count(where);
    const data = await this.specialityRepository.find({
      where,
      order: filter?.order,
      limit: pageSize,
      skip: skip,
      fields: {
        id: true,
        name: true,
        description: true,
        created_at: true,
      },
    });
    const totalPages = Math.ceil(count.count / pageSize);
    return {
      status: 'success',
      data,
      count: count.count,
      totalPages,
      currentPage: pageNum,
    };
  }
}
