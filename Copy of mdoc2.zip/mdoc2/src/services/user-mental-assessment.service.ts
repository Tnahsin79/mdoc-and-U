import {
  ActivityTimelineRepository,
  UserMentalAssessmentRepository,
  UserMentalAssessmentRecordRepository,
} from '../repositories';
import Utils from '../utils';
import moment from 'moment';
import {OutlierServiceBindings} from '../keys';
import {OutlierService} from './outlier.service';
import {Filter, repository} from '@loopback/repository';
import {BindingScope, bind, inject} from '@loopback/core';
import {PaginatedResponse, activityTypeObj} from '../type-schema';
import {QuestionRepository} from '../repositories/question.repository';
import {UserMentalAssessment, UserMentalAssessmentRecord} from '../models';
import {HealthMetricsTypeEnum, MentalAssessmentGroupEnum} from '../utils/enums';

@bind({scope: BindingScope.CONTEXT})
export class UserMentalAssessmentService {
  constructor(
    @inject(OutlierServiceBindings.OUTLIER_SERVICE)
    public outlierService: OutlierService,
    @repository(UserMentalAssessmentRepository)
    public userMentalAssessmentRepository: UserMentalAssessmentRepository,
    @repository(QuestionRepository)
    public questionRepository: QuestionRepository,
    @repository(ActivityTimelineRepository)
    public activityTimelineRepository: ActivityTimelineRepository,
    @repository(UserMentalAssessmentRecordRepository)
    public userMentalAssessmentRecordRepository: UserMentalAssessmentRecordRepository,
  ) {}

  async create(
    payload: Omit<UserMentalAssessment, 'id'>,
  ): Promise<UserMentalAssessment> {
    const creatingUserMentalAssessmentRecord = await this.userMentalAssessmentRecordRepository.create(
      {
        userId: payload.userId,
        created_at: payload.created_at,
        modified_at: payload.modified_at,
      },
    );
    const data = await this.userMentalAssessmentRepository.create({
      ...payload,
      userMentalAssessmentRecordId: creatingUserMentalAssessmentRecord.id,
    });
    let score = 0;
    const {defaultOptions} = await this.questionRepository.findById(
      data.questionId,
    );
    defaultOptions.forEach(data => {
      if (parseInt(data.id) === payload.selectedOptionId) score += data.score;
    });
    if (score > 2)
      await this.outlierService.create({
        userId: payload.userId,
        metricId: creatingUserMentalAssessmentRecord.id,
        metricType: HealthMetricsTypeEnum.Mental_Assessment,
        metricValue: `${score}`,
      });
    await this.activityTimelineRepository.create({
      activityType: activityTypeObj.USER_MENTAL_ASSESSMENT,
      userId: data.userId,
      metadata: creatingUserMentalAssessmentRecord.id,
    });
    return data;
  }

  async createBulk(
    userId: string,
    payload: Omit<UserMentalAssessment, 'id'>[],
  ): Promise<void> {
    const userMentalAssessmentRecord = await this.userMentalAssessmentRecordRepository.create(
      {
        userId,
        created_at: payload[0].created_at,
        modified_at: payload[0].modified_at,
        group: payload[0].group,
      },
    );
    payload = payload.map(item => {
      item.userMentalAssessmentRecordId = userMentalAssessmentRecord.id;
      return item;
    });
    const data = await this.userMentalAssessmentRepository.createAll(payload);
    await this.activityTimelineRepository.create({
      activityType: activityTypeObj.USER_MENTAL_ASSESSMENT,
      metadata: userMentalAssessmentRecord.id,
      userId,
    });
    const questions = await this.questionRepository.find({
      where: {id: {inq: data.map(item => item.questionId)}},
    });
    const questionsObject = questions.reduce((t, a) => {
      if (!t[a.id]) t[a.id] = a;
      return t;
    }, {});
    let score = 0;
    data.forEach(
      item =>
        (score += questionsObject[item.questionId]?.defaultOptions?.find(
          (option: any) => parseInt(option.id) === item.selectedOptionId,
        )?.score),
    );

    if (score > 2)
      await this.outlierService.create({
        userId,
        metricId: userMentalAssessmentRecord.id,
        metricType: HealthMetricsTypeEnum.Mental_Assessment,
        metricValue: `${score}`,
      });
  }

  async findAll(
    filter: Filter<UserMentalAssessment>,
    page: number,
  ): Promise<PaginatedResponse<UserMentalAssessment>> {
    const limit = filter?.limit ? filter?.limit : 25;
    const pageNum = page ? page : 1;
    const skip = (pageNum - 1) * limit;
    const content = await this.userMentalAssessmentRepository.find({
      where: filter?.where,
      include: [
        {
          relation: 'user',
          scope: {
            fields: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              phone: true,
            },
          },
        },
      ],
      limit,
      skip,
    });
    const count = await this.userMentalAssessmentRepository.count(
      filter?.where,
    );
    const totalPages = Math.ceil(count.count / limit);
    return {
      data: content,
      count: count.count,
      totalPages,
      currentPage: page,
      status: 'success',
    };
  }

  async findById(id: string, filter: Filter<UserMentalAssessment>) {
    const data = this.userMentalAssessmentRepository.findById(id, {
      where: filter?.where,
      include: [
        {
          relation: 'user',
          scope: {
            fields: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              phone: true,
            },
          },
        },
      ],
    });
    return data;
  }

  async updateById(
    id: string,
    userMentalAssessment: UserMentalAssessment,
  ): Promise<void> {
    const data = await this.userMentalAssessmentRepository.updateById(
      id,
      userMentalAssessment,
    );
    return data;
  }

  async deleteById(id: string): Promise<void> {
    return await this.userMentalAssessmentRepository.deleteById(id);
  }

  async findAllUserMentalAssessmentRecord(
    filter: Filter<UserMentalAssessmentRecord>,
    page: number,
  ): Promise<PaginatedResponse<UserMentalAssessmentRecord>> {
    const limit = Utils.getLimit(filter?.limit);
    const pageNum = page ? page : 1;
    const skip = (pageNum - 1) * limit;
    const content = await this.userMentalAssessmentRecordRepository.find({
      where: filter?.where,
      include: [
        {
          relation: 'userMentalAssessments',
          scope: {
            include: [
              {relation: 'question', scope: {include: [{relation: 'options'}]}},
            ],
          },
        },
      ],
      limit,
      skip,
      order: ['created_at DESC'],
    });

    const count = await this.userMentalAssessmentRecordRepository.count(
      filter?.where,
    );
    const totalPages = Math.ceil(count.count / limit);
    return {
      data: content,
      count: count.count,
      totalPages,
      currentPage: page,
      status: 'success',
    };
  }

  async userMentalAssessmentRecordById(
    id: string,
    filter: Filter<UserMentalAssessmentRecord>,
  ): Promise<UserMentalAssessmentRecord> {
    const data = await this.userMentalAssessmentRecordRepository.findById(id, {
      where: filter?.where,
      include: [
        {
          relation: 'userMentalAssessments',
          scope: {
            include: [
              {relation: 'question', scope: {include: [{relation: 'options'}]}},
            ],
          },
        },
      ],
    });
    return data;
  }

  async checkIfMentalHealthAssessmentRecordExists(userId: string) {
    const startofToday = new Date();
    startofToday.setHours(0, 0, 0, 0);
    const _startofToday = moment(startofToday)
      .utc()
      .toDate();

    const endOfToday = new Date();
    endOfToday.setHours(23, 59, 59, 999);
    const _endOfToday = moment(endOfToday)
      .utc()
      .toDate();

    const where = {};
    where['userId'] = userId;
    where['created_at'] = {between: [_startofToday, _endOfToday]};

    const record = await this.userMentalAssessmentRecordRepository.find({
      where,
      include: [
        {
          relation: 'userMentalAssessments',
          scope: {
            include: [
              {relation: 'question', scope: {fields: {group: true, id: true}}},
            ],
          },
        },
      ],
    });

    const gadQuestions = record.filter(
      item =>
        item.userMentalAssessments[0].question.group ===
        MentalAssessmentGroupEnum.GAD,
    );
    const phqQuestions = record.filter(
      item =>
        item.userMentalAssessments[0].question.group ===
        MentalAssessmentGroupEnum.PHQ,
    );

    return {
      gadExists: gadQuestions.length > 0,
      phqExists: phqQuestions.length > 0,
    };
  }
}
