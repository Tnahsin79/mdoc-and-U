import {repository} from '@loopback/repository';
import {SymptomsRepository} from '../repositories';
import {BindingScope, bind} from '@loopback/context';
import Utils from '../utils';

@bind({scope: BindingScope.CONTEXT})
export class SymptomsService {
  constructor(
    @repository(SymptomsRepository)
    public symptomsRepository: SymptomsRepository,
  ) {}

  async find(filter, page) {
    if (page && filter) {
      const pageSize = Utils.getLimit(filter?.limit);
      const pageNum = page ? page : 1;
      const skip = (pageNum - 1) * pageSize;
      let whereClause;
      let searchString = filter?.searchString;

      const orClause = {
        or: [{name: new RegExp('.*' + searchString + '.*', 'i')}],
      };

      whereClause = searchString ? orClause : {};
      const count = await this.symptomsRepository.count(whereClause);
      const totalPages = Math.ceil(count.count / pageSize);
      const symptoms = await this.symptomsRepository.find({
        where: whereClause,
        fields: {
          id: true,
          name: true,
          created: true,
        },
        limit: pageSize,
        skip: skip,
        order: ['name ASC'],
      });

      return {
        status: 'Success',
        data: symptoms,
        pageSize,
        count: count.count,
        totalPages,
        currentPage: pageNum,
      };
    } else {
      return this.symptomsRepository.find({
        order: ['name ASC'],
      });
    }
  }
}
