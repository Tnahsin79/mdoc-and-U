import {
  FCMServiceBindings,
  EmailServiceBindings,
  BlogPostServiceBindings,
  ControllerServiceBindings,
} from '../keys';
import {
  EventTypeEnum,
  NotificationTypeEnum,
  NotificationPriorityEnum,
  CreatorTypeEnum,
} from '../type-schema';
import {
  CoachRepository,
  UsersRepository,
  NotificationRepository,
  CalenderEventRepository,
} from '../repositories';
import moment from 'moment';
import multer from 'multer';
import * as path from 'path';
import Utils from '../utils';
import {CalenderEvent} from '../models';
import {FCMService} from './fcm.service';
import {EmailService} from './email.service';
import {Request, Response} from '@loopback/rest';
import {BlogPostService} from './blog-post.service';
import {ControllerService} from './controller.service';
import {Filter, repository} from '@loopback/repository';
import {UserProfile, securityId} from '@loopback/security';
import {BindingScope, bind, inject} from '@loopback/context';

@bind({scope: BindingScope.CONTEXT})
export class CalenderEventService {
  configOption = Utils.getSiteOptions();

  constructor(
    @repository(CalenderEventRepository)
    public calenderEventRepository: CalenderEventRepository,

    @repository(UsersRepository)
    public userRepository: UsersRepository,

    @repository(CoachRepository)
    public coachRepository: CoachRepository,

    @repository(NotificationRepository)
    public notificationRepository: NotificationRepository,

    @inject(EmailServiceBindings.MAIL_SERVICE)
    public emailService: EmailService,

    @inject(ControllerServiceBindings.CONTROLLER_SERVICE)
    public controllerService: ControllerService,

    @inject(BlogPostServiceBindings.BLOG_POST_SERVICE)
    public blogPostService: BlogPostService,

    @inject(FCMServiceBindings.FCM_SERVICE) public fcmService: FCMService,
  ) {}

  async create(calenderEvent: Omit<CalenderEvent, 'id, status'>) {
    if (!calenderEvent.creatorType) {
      calenderEvent.creatorType =
        calenderEvent.appointmentMemberId === calenderEvent.creatorId
          ? CreatorTypeEnum.user
          : CreatorTypeEnum.coach;
    }
    const event = await this.calenderEventRepository.create(calenderEvent);
    if (
      calenderEvent.appointmentCoachId &&
      calenderEvent.appointmentMemberId &&
      calenderEvent.eventType === 'coach_appointment'
    ) {
      const coach = await this.coachRepository.findById(
        calenderEvent.appointmentCoachId,
      );
      const user = await this.userRepository.findById(
        calenderEvent.appointmentMemberId,
      );
      let mailPayload = {};

      switch (calenderEvent.creatorType) {
        case CreatorTypeEnum.user:
          mailPayload = {
            from: 'Admin@mymdoc.com',
            to: coach.email,
            slug: 'calendar_invite_to_coach',
            message: {
              coachName: coach.firstName,
              date: moment(calenderEvent.eventStartDate).format('DD-MM-YYYY'),
              time: `${moment(calenderEvent.eventStartDate)
                .add(1, 'hours')
                .format('HH:mm A')} to ${moment(calenderEvent.eventEndDate)
                .add(1, 'hours')
                .format('HH:mm A')}`,
              userName: user.firstName
                ? `${user.firstName} ${user?.lastName}`
                : user?.name,
              userContact: user?.email ? user.email : user?.phone,
            },
          };
          await this.emailService.sendMail(mailPayload);
          const notificationPayload = {
            resourceId: event.id,
            notificationObject: event,
            coachId: event.appointmentCoachId,
            notificationType: NotificationTypeEnum.COACH_APPOINTMENT,
            priority: NotificationPriorityEnum.HIGH,
            title: 'Coach Appointment',
            body:
              ' Your member has scheduled an appointment with you. Check your calendar for further information! ',
          };
          await this.notificationRepository.create(notificationPayload);
          break;
        case CreatorTypeEnum.coach:
          if (user?.email) {
            mailPayload = {
              from: 'hello@mymdoc.com',
              to: user.email,
              slug: 'calendar_invite_to_user',
              message: {
                memberName: user.name
                  ? user.name
                  : `${user?.firstName} ${user.lastName}`,
                date: moment(calenderEvent.eventStartDate).format('DD-MM-YYYY'),
                time: `${moment(calenderEvent.eventStartDate)
                  .add(1, 'hours')
                  .format('HH:mm A')} to ${moment(calenderEvent.eventEndDate)
                  .add(1, 'hours')
                  .format('HH:mm A')}`,
                coachName: coach.name
                  ? coach.name
                  : `${coach?.firstName} ${coach?.lastName}`,
                coachContact: coach?.email ? coach.email : user?.phone,
              },
            };

            await this.emailService.sendMail(mailPayload);
          } else {
            const message = `Hi ${
              user?.name ? user?.name : user?.firstName
            }, \nThis is to inform you that your health coach has booked an appointment for you on CompleteHealthTM. \n\nAppointment Details:\n\nDate: ${moment(
              calenderEvent.eventStartDate,
            ).format('DD-MM-YYYY')}\nTime: ${moment(
              calenderEvent.eventStartDate,
            )
              .add(1, 'hours')
              .format('HH:mm')}\nCoach: ${
              coach?.name ? coach.name : coach?.firstName
            }\nContact Information: ${
              coach?.email ? coach?.email : coach.phone
            }\n\nPlease make sure to mark your calendar and be available at the scheduled time. Your coach is looking forward to assisting you with your health goals.\n\nIf you have any questions or need to reschedule, please don't hesitate to reach out to your coach via your mobile/web application `;
            await this.controllerService.sendOtpService(user?.phone, message);
          }
          if (user?.fcmToken && user?.isPushNotification === true) {
            const notificationPayload = {
              resourceId: event.id,
              notificationObject: event,
              userId: event.appointmentMemberId,
              notificationType: NotificationTypeEnum.COACH_APPOINTMENT,
              priority: NotificationPriorityEnum.HIGH,
              title: 'Coach Appointment',
              body:
                ' Exciting news! Your health coach has scheduled an appointment with you. Check your calendar and get ready for progress towards your health goals! ',
            };
            await this.notificationRepository.create(notificationPayload);
            const message = {
              registration_ids: user?.fcmToken,
              data: {type: NotificationTypeEnum.COACH_APPOINTMENT},
              notification: {
                title: notificationPayload.title,
                body: notificationPayload.body,
                priority: 'high',
                sound: 'default',
                vibrate: true,
              },
            };
            await await this.fcmService.sendNotification({message});
          }
          break;
      }
    }
    return event;
  }

  async find(filter?: Filter<CalenderEvent>) {
    const where = filter?.where || {};
    if (!filter.where['eventType']) {
      where['or'] = [
        {eventType: EventTypeEnum.AntenatalAppointment},
        {eventType: EventTypeEnum.CoachAppointment},
        {eventType: EventTypeEnum.FacilityAppointment},
        {eventType: EventTypeEnum.GeneralEvent},
        {eventType: EventTypeEnum.PersonalReminder},
      ];
    }

    return await this.calenderEventRepository.find({
      where,
      include: [
        {
          relation: 'coach',
          scope: {
            fields: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              phone: true,
              image: true,
            },
          },
        },
        {
          relation: 'member',
          scope: {
            fields: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              phone: true,
              image: true,
              locationInfo: true,
              city: true,
              country: true,
            },
          },
        },
      ],
      order: ['created_at DESC'],
    });
  }

  async findById(
    id: string,
    filter: Filter<CalenderEvent>,
  ): Promise<CalenderEvent> {
    const where = filter?.where;
    return await this.calenderEventRepository.findById(id, {
      where,
      include: [
        {
          relation: 'coach',
          scope: {
            fields: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              phone: true,
              image: true,
            },
          },
        },
        {
          relation: 'member',
          scope: {
            fields: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              phone: true,
              image: true,
              locationInfo: true,
              city: true,
              country: true,
            },
          },
        },
      ],
    });
  }

  async updateById(id: string, calenderEvent: CalenderEvent): Promise<void> {
    return await this.calenderEventRepository.updateById(id, calenderEvent);
  }

  async deleteById(id: string): Promise<void> {
    return await this.calenderEventRepository.deleteById(id);
  }

  async createWebinar(
    request: Request,
    response: Response,
    currentUser: UserProfile,
  ) {
    const maxFileSize =
      this.configOption.maxFileSize.oneMB *
      this.configOption.maxFileSize.quantity;
    const upload = multer({
      storage: multer.memoryStorage(),
      fileFilter: function(req: any, file: any, cb: any) {
        let ext = path.extname(file.originalname);
        cb(null, true);
      },
      limits: {fileSize: maxFileSize},
    });
    return new Promise<object>(async (resolve, reject) => {
      upload.any()(request, response, (err: unknown) => {
        if (err) reject(err);
        else {
          if (!request.files) {
            reject(new Error('No file uploaded'));
          } else {
            let imageFile =
              request.files[0].fieldname === 'image'
                ? request.files[0]
                : request.files[1];
            this.blogPostService
              .checkSlug(request)
              .then(async (slugValue: string) => {
                this.controllerService
                  .uploadImageHelper([imageFile], 'complete_health_webinars')
                  .then(async image => {
                    const {
                      title,
                      notes,
                      eventDate,
                      isPublished,
                      isPublicEvent,
                      registrationLink,
                      recordedSessionLink,
                    } = request.body;

                    const webinar = await this.calenderEventRepository.create({
                      title,
                      notes,
                      isPublished,
                      isPublicEvent,
                      slug: slugValue,
                      registrationLink,
                      recordedSessionLink,
                      eventStartDate: eventDate,
                      eventType: EventTypeEnum.Webinar,
                      creatorAdminId: currentUser[securityId],
                      displayImage: (image as unknown) as string,
                      creatorId: currentUser[securityId].toString(),
                    });
                    resolve(webinar);
                  });
              })
              .catch(err => {
                console.log(err);
                return response.json({message: err});
              });
          }
        }
      });
    });
  }

  async findBySearch(
    page?: number,
    search?: string,
    filter?: Filter<CalenderEvent>,
  ) {
    const where = filter?.where || {};
    const limit = Utils.getLimit(filter?.limit);
    const pageNum = page ?? 1;
    const skip = (pageNum - 1) * limit;

    where['eventType'] = EventTypeEnum.Webinar;

    if (search) {
      where['or'] = [
        {title: {regexp: new RegExp('.*' + search + '.*', 'i')}},
        {slug: {regexp: new RegExp('.*' + search + '.*', 'i')}},
        {notes: {regexp: new RegExp('.*' + search + '.*', 'i')}},
      ];
    }

    const content = await this.calenderEventRepository.find({
      where,
      fields: {
        id: true,
        slug: true,
        title: true,
        notes: true,
        created_at: true,
        isPublished: true,
        modified_at: true,
        displayImage: true,
        eventStartDate: true,
        creatorAdminId: true,
        registrationLink: true,
        recordedSessionLink: true,
      },
      include: [
        {
          relation: 'creatorAdmin',
          scope: {
            fields: {
              id: true,
              name: true,
              image: true,
            },
          },
        },
      ],
      order: ['created_at DESC'],
      skip,
      limit,
    });

    const count = await this.calenderEventRepository.count(where);
    const totalPages = Math.ceil(count.count / limit);

    return {
      data: content,
      count: count.count,
      totalPages,
      currentPage: page,
      status: 'success',
    };
  }

  async findWebinarById(id: string, filter: Filter<CalenderEvent>) {
    return await this.calenderEventRepository.findOne({
      where: {
        ...filter?.where,
        or: [{id}, {slug: id}],
        eventType: EventTypeEnum.Webinar,
      },
      include: [
        {
          relation: 'creatorAdmin',
          scope: {
            fields: {
              id: true,
              name: true,
              image: true,
              email: true,
              phoneNumber: true,
            },
          },
        },
      ],
    });
  }

  async webinarStatistics(): Promise<{
    draftWebinars: number;
    totalWebinars: number;
    publishedWebinars: number;
  }> {
    const publishedWebinars = await this.calenderEventRepository.count({
      eventType: EventTypeEnum.Webinar,
      isPublished: true,
    });
    const draftWebinars = await this.calenderEventRepository.count({
      eventType: EventTypeEnum.Webinar,
      isPublished: false,
    });
    const totalWebinars = await this.calenderEventRepository.count({
      eventType: EventTypeEnum.Webinar,
    });
    return {
      draftWebinars: draftWebinars.count,
      totalWebinars: totalWebinars.count,
      publishedWebinars: publishedWebinars.count,
    };
  }
}
