import {bind, BindingScope} from '@loopback/context';
import {Filter, repository} from '@loopback/repository';
import {
  Benefits,
  CoachPrograms,
  PlansBenefit,
  ProgramPlans,
  Programs,
  ProgramsWithRelations,
} from '../models';
import {
  BenefitsRepository,
  ChangeStagesRepository,
  CoachProgramsRepository,
  PlansBenefitRepository,
  ProgramPlansRepository,
  ProgramsRepository,
} from '../repositories';
import {HttpErrors} from '@loopback/rest';

@bind({scope: BindingScope.TRANSIENT})
export class ProgramsService {
  constructor(
    @repository(ProgramsRepository)
    public programsRepository: ProgramsRepository,
    @repository(ProgramPlansRepository)
    public programPlansRepository: ProgramPlansRepository,
    @repository(BenefitsRepository)
    public benefitsRepository: BenefitsRepository,
    @repository(PlansBenefitRepository)
    public plansBenefitRepository: PlansBenefitRepository,
    @repository(CoachProgramsRepository)
    public coachProgramsRepository: CoachProgramsRepository,
    @repository(ChangeStagesRepository)
    public changeStagesRepository: ChangeStagesRepository,
  ) {}

  async create(payload: Omit<Programs, 'id'>): Promise<Programs> {
    return await this.programsRepository.create(payload);
  }

  async updateById(id: string, payload: Partial<Programs>): Promise<void> {
    return await this.programsRepository.updateById(id, payload);
  }

  async getProgramById(id: string): Promise<ProgramsWithRelations> {
    return await this.programsRepository.findById(id, {
      include: [
        {relation: 'changeStages'},
        {
          relation: 'admin',
          scope: {
            fields: {
              id: true,
              name: true,
              email: true,
              phoneNumber: true,
            },
          },
        },
        {
          relation: 'approver',
          scope: {
            fields: {
              id: true,
              name: true,
            },
          },
        },
        {
          relation: 'coachPrograms',
          scope: {
            include: [{relation: 'coach'}],
          },
        },
        {relation: 'benefits'},
        {
          relation: 'plans',
          scope: {
            fields: {
              id: true,
              title: true,
              basePrice: true,
              discountData: true,
              programId: true,
              duration: true,
            },
            where: {
              isDeleted: false,
            },
            include: [
              {
                relation: 'plansBenefit',
                scope: {
                  include: [{relation: 'benefit'}],
                },
              },
            ],
            order: ['order ASC'],
          },
        },
      ],
    });
  }

  async find(filter: Filter<Programs> = {}): Promise<ProgramsWithRelations[]> {
    const programs = await this.programsRepository.find({
      where: filter?.where,
      order: ['created DESC'],
      fields: {
        id: true,
        title: true,
        tags: true,
        approvalStatus: true,
        description: true,
        specificGender: true,
        createdBy: true,
        approvedBy: true,
        approvalDate: true,
        coachPrograms: true,
      },
      include: [
        {relation: 'changeStages'},
        {
          relation: 'admin',
          scope: {
            fields: {
              id: true,
              name: true,
              email: true,
              phoneNumber: true,
            },
          },
        },
        {
          relation: 'approver',
          scope: {
            fields: {
              id: true,
              name: true,
            },
          },
        },
        {
          relation: 'coachPrograms',
        },
        {
          relation: 'plans',
          scope: {
            fields: {
              id: true,
              title: true,
              basePrice: true,
              discountData: true,
              programId: true,
              duration: true,
            },
            where: {
              isDeleted: false,
            },
            include: [
              {
                relation: 'plansBenefit',
                scope: {
                  include: [
                    {
                      relation: 'benefit',
                    },
                  ],
                },
              },
            ],
            order: ['order ASC'],
          },
        },
        {
          relation: 'benefits',
          scope: {
            fields: {
              id: true,
              title: true,
              programId: true,
            },
            order: ['order ASC'],
          },
        },
      ],
    });
    return programs;
  }

  async createNewProgram({
    planList,
    programTitle,
    description = '',
    benefitList,
    planTypes,
    adminId,
    specificGender,
    tags,
  }): Promise<{
    planBenefits: PlansBenefit[];
    plans: ProgramPlans[];
    program: Programs;
    benefits: Benefits[];
  }> {
    const program = await this.programsRepository.create({
      title: programTitle,
      createdBy: adminId,
      validSubscriptionTypes: planTypes,
      description,
      specificGender,
      tags,
    });
    await this.changeStagesRepository.create({programId: program?.id});

    const list = planList.map(item => ({
      title: item.title,
      programId: program?.id,
      discountData: item.discountData,
      monthlyPrice: item.monthlyPrice,
      yearlyPrice: item.yearlyPrice,
      quarterlyPrice: item.quarterlyPrice,
      biAnnualPrice: item.biAnnualPrice,
      threeMonthPrice: item.threeMonthPrice,
      basePrice: item.basePrice,
      order: item.order,
      duration: item.duration,
    }));
    const plans = await this.programPlansRepository.createAll(list);

    const blist = benefitList.map(item => ({
      title: item.title,
      order: item.order,
      type: item.type,
      programId: program?.id,
    }));
    const benefits = await this.benefitsRepository.createAll(blist);

    const planBenefitMapppings = ([] as any[]).concat(
      ...planList.map(plan =>
        plan.benefits.map(benefit => ({
          planId: plans?.find(item => item.order === plan.order)?.id,
          benefitId: benefits?.find(item => item.order === benefit.order)?.id,
          type: benefit.type,
          value: benefit.value,
        })),
      ),
    );

    const planBenefits = await this.plansBenefitRepository.createAll(
      planBenefitMapppings,
    );

    return {
      planBenefits,
      plans,
      program,
      benefits,
    };
  }

  async getProgramForUpdate(programId: string) {
    const program = await this.programsRepository.findById(programId);
    if (!program) {
      throw new HttpErrors[404]('Program not found.');
    }
    const plans = await this.programPlansRepository.find({
      where: {
        programId,
        isDeleted: false,
      },
      include: [
        {relation: 'plansBenefit', scope: {include: [{relation: 'benefit'}]}},
      ],
    });

    const benefits = await this.benefitsRepository.find({
      where: {
        programId,
      },
    });

    return {
      plans,
      program,
      benefits,
    };
  }

  async updateBenefit(benefit: Benefits) {
    const existing = await this.benefitsRepository.findById(benefit.id);
    if (!existing) {
      throw new HttpErrors[404]('Benefit not found.');
    }
    if (existing.type !== benefit.type) {
      // Delete the saved values
      await this.plansBenefitRepository.updateAll(
        {value: benefit.type === 'checkmark' ? 'false' : ''},
        {
          benefitId: benefit.id,
        },
      );
    }
    await this.benefitsRepository.updateById(benefit.id, benefit);
  }

  async addBenefit(payload: Omit<Benefits, 'id'>) {
    const benefit = await this.benefitsRepository.create(payload);
    // Add the benefit to all the plans
    const plans = await this.programPlansRepository.find({
      where: {
        programId: payload.programId,
      },
    });

    const planBenefitMapppings = plans?.map(item => ({
      planId: item.id,
      benefitId: benefit?.id,
      value: benefit?.type === 'checkmark' ? 'false' : '',
      type: benefit?.type,
    }));
    const plansBenefits = await this.plansBenefitRepository.createAll(
      planBenefitMapppings,
    );
    return {benefit, plansBenefits};
  }

  async deleteBenefit(id: string) {
    await this.benefitsRepository.deleteById(id);
    await this.plansBenefitRepository.deleteAll({
      benefitId: id,
    });
  }

  async updatePlansBenefitValue(id: string, payload) {
    await this.plansBenefitRepository.updateById(id, payload);
  }

  async addPlan(payload: Omit<ProgramPlans, 'id'>) {
    const plan = await this.programPlansRepository.create(payload);
    const benefits = await this.benefitsRepository.find({
      where: {
        programId: payload.programId,
      },
    });
    const planBenefitMapppings = benefits.map(benefit => ({
      planId: plan?.id,
      benefitId: benefit?.id,
      value: benefit.type === 'checkmark' ? 'false' : '',
      type: benefit.type,
    }));
    await this.plansBenefitRepository.createAll(planBenefitMapppings);
    const response = await this.programPlansRepository.findById(plan?.id, {
      include: [
        {relation: 'plansBenefit', scope: {include: [{relation: 'benefit'}]}},
      ],
    });

    return response;
  }

  async updatePlanById(
    id: string,
    payload: Partial<ProgramPlans>,
  ): Promise<void> {
    return await this.programPlansRepository.updateById(id, payload);
  }

  async deletePlan(id: string) {
    // soft delete for documentation and history purposes
    await this.programPlansRepository.updateById(id, {isDeleted: true});
    await this.plansBenefitRepository.deleteAll({
      planId: id,
    });
  }

  async updatePlansBulk(plans) {
    plans.forEach(async element => {
      await this.programPlansRepository.updateById(element.id, {
        order: element.order,
      });
    });
  }

  async updateBenefitsBulk(benefits) {
    benefits.forEach(async element => {
      await this.benefitsRepository.updateById(element.id, {
        order: element.order,
      });
    });
  }

  async assignCoachesToProgram(payload) {
    await this.coachProgramsRepository.createAll(payload);
  }

  async getCoaches(id: string) {
    return await this.coachProgramsRepository.find({
      where: {
        programId: id,
      },
      include: [
        {
          relation: 'coach',
          scope: {
            fields: {
              id: true,
              name: true,
              firstName: true,
              lastName: true,
              image: true,
              address: true,
              coachTypeId: true,
              specialities: true,
            },
            include: [
              {relation: 'coachType'},
              {relation: 'coachSpecialities'},
              {
                relation: 'assignedMembers',
                scope: {
                  include: [
                    {
                      relation: 'subscription',
                      scope: {
                        include: [
                          {
                            relation: 'user',
                            scope: {
                              fields: {id: true, name: true, image: true},
                            },
                          },
                        ],
                      },
                    },
                  ],
                },
              },
            ],
          },
        },
      ],
    });
  }

  async getCoachProgramsCollection(
    filter?: Filter<CoachPrograms>,
    includeRelations?: boolean,
  ) {
    const result = await this.coachProgramsRepository.find({
      where: filter?.where,
      include: includeRelations
        ? [
            {
              relation: 'coach',
              scope: {
                fields: {
                  id: true,
                  name: true,
                  image: true,
                  address: true,
                },
                include: [
                  {
                    relation: 'assignedMembers',
                    scope: {
                      include: [
                        {
                          relation: 'subscription',
                          scope: {
                            include: [
                              {
                                relation: 'user',
                                scope: {
                                  fields: {id: true, name: true, image: true},
                                },
                              },
                            ],
                          },
                        },
                      ],
                    },
                  },
                ],
              },
            },
          ]
        : [],
    });
    return result;
  }

  async removeCoachFromProgram({
    programId,
    coachId,
  }: {
    programId: string;
    coachId: string;
  }) {
    await this.coachProgramsRepository.deleteAll({
      programId,
      coachId,
    });
  }

  async updateCoachStatusInProgram({
    coachProgramId,
    status,
  }: {
    coachProgramId: string;
    status: 'active' | 'inactive';
  }) {
    try {
      await this.coachProgramsRepository.updateById(coachProgramId, {
        status,
      });
    } catch (error) {
      throw new HttpErrors[400]('An error occurred. Please check payload.');
    }
  }

  async updateStagesOfChange(programId, updates) {
    const stage = await this.changeStagesRepository.findOne({
      where: {programId},
    });
    if (stage) {
      return await this.changeStagesRepository.updateById(stage.id, {
        ...updates,
        programId,
      });
    } else {
      return await this.changeStagesRepository.create({...updates, programId});
    }
  }
}
