import moment from 'moment';
import {bind, BindingScope} from '@loopback/context';
import {DATE, repository} from '@loopback/repository';
import {BulkCommunicationLog, PaginatedResponse} from '../type-schema';
import {CommunicationLog, CommunicationLogWithRelations} from '../models';
import {CommunicationLogRepository, UsersRepository} from '../repositories';

@bind({scope: BindingScope.TRANSIENT})
export class CommunicationLogService {
  constructor(
    @repository(CommunicationLogRepository)
    public communicationLogRepository: CommunicationLogRepository,
    @repository(UsersRepository)
    public usersRepository: UsersRepository,
  ) {}

  async create(
    payload: Omit<CommunicationLog, 'id'>,
  ): Promise<CommunicationLogWithRelations> {
    return await this.communicationLogRepository.create(payload);
  }

  async bulkCreate(
    bulkCommunicationLog: BulkCommunicationLog,
  ): Promise<CommunicationLog[]> {
    const {emails, phoneNumbers, entryDate, ...rest} = bulkCommunicationLog;

    const users = await this.usersRepository.find({
      where: {
        or: [
          {
            email: {
              inq: emails,
            },
          },
          {
            phone: {
              inq: phoneNumbers,
            },
          },
        ],
      },
    });

    // create communication log for each user
    const communicationLogs = users.map(user => {
      return {
        userId: user.id,
        entryDate: moment(entryDate).toISOString(),
        ...rest,
      };
    });

    const bulkCreate = await this.communicationLogRepository.createAll(
      communicationLogs,
    );
    return bulkCreate;
  }

  async updateById(
    id: string,
    payload: Partial<CommunicationLog>,
  ): Promise<void> {
    return await this.communicationLogRepository.updateById(id, payload);
  }

  async deleteById(id: string): Promise<void> {
    return await this.communicationLogRepository.deleteById(id);
  }

  async getByUserId(id: string): Promise<CommunicationLogWithRelations[]> {
    return await this.communicationLogRepository.find({
      where: {
        userId: id,
      },
      order: ['created DESC'],
      include: [
        {
          relation: 'coach',
          scope: {
            fields: {
              id: true,
              name: true,
              image: true,
              email: true,
              phone: true,
              address: true,
            },
          },
        },
      ],
    });
  }

  async getByCoachId(
    id: string,
    limit: number,
    page?: number,
  ): Promise<PaginatedResponse<CommunicationLogWithRelations>> {
    const pageNum = page ? page : 1;
    const skip = (pageNum - 1) * limit;
    const content = await this.communicationLogRepository.find({
      where: {
        coachId: id,
      },
      order: ['created DESC'],
      include: [
        {
          relation: 'user',
          scope: {
            fields: {
              id: true,
              name: true,
              image: true,
              email: true,
              phone: true,
              locationInfo: true,
            },
          },
        },
      ],
      limit,
      skip,
    });

    const count = await this.communicationLogRepository.count({coachId: id});
    const totalPages = Math.ceil(count.count / limit);

    return {
      data: content,
      count: count.count,
      totalPages,
      currentPage: page,
      status: 'success',
    };
  }

  async getByUserIdAndCoachId(
    userId: string,
    coachId: string,
  ): Promise<CommunicationLogWithRelations[]> {
    return await this.communicationLogRepository.find({
      where: {
        userId,
        coachId,
      },
      order: ['created DESC'],
      include: [{relation: 'user'}, {relation: 'coach'}],
    });
  }
}
