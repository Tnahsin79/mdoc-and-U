import {PaginatedResponse} from '../type-schema';
import {ForumUserRepository} from '../repositories';
import {BindingScope, bind} from '@loopback/context';
import {Filter, repository} from '@loopback/repository';
import {ForumUser, ForumUserWithRelations} from '../models';

@bind({scope: BindingScope.CONTEXT})
export class ForumUserService {
  constructor(
    @repository(ForumUserRepository)
    public forumUserRepository: ForumUserRepository,
  ) {}

  async create(payload: Omit<ForumUser, 'id'>[]): Promise<ForumUserWithRelations[]> {
    await this.forumUserRepository.createAll(payload);
    return await this.forumUserRepository.find({
      where: {
        id: {inq: payload.map(i => i.userId)}
      },
      include: [
        {
          relation: 'forum',
          scope: {
            fields: {
              id: true,
              coachId: true,
              topic: true,
              cohorts: true,
              approvalStatus: true,
            },
          },
        },
        {
          relation: 'user',
          scope: {
            fields: {
              id: true,
              image: true,
              firstName: true,
              lastName: true,
              email: true,
              phone: true,
            },
          },
        },
      ],
    })
  }

  async findAll(
    filter: Filter<ForumUser>,
    page: number,
  ): Promise<PaginatedResponse<ForumUserWithRelations>> {
    const limit = filter?.limit ? filter?.limit : 25;
    const pageNum = page ? page : 1;
    const skip = (pageNum - 1) * limit;
    const content = await this.forumUserRepository.find({
      where: filter?.where,
      include: [
        {
          relation: 'forum',
          scope: {
            fields: {
              id: true,
              topic: true,
              coachId: true,
              cohorts: true,
              approvalStatus: true,
            },
          },
        },
        {
          relation: 'user',
          scope: {
            fields: {
              id: true,
              image: true,
              firstName: true,
              lastName: true,
              email: true,
              phone: true,
            },
          },
        },
      ],
      limit,
      skip,
    });
    const count = await this.forumUserRepository.count();
    const totalPages = Math.ceil(count.count / limit);
    return {
      data: content,
      count: count.count,
      totalPages,
      currentPage: page,
      status: 'success',
    };
  }

  async findById(id: string, filter: Filter<ForumUser>) {
    const data = this.forumUserRepository.findById(id, {
      where: filter?.where,
      include: [
        {
          relation: 'forum',
          scope: {
            fields: {
              id: true,
              topic: true,
              coachId: true,
              cohorts: true,
              approvalStatus: true,
            },
          },
        },
        {
          relation: 'user',
          scope: {
            fields: {
              id: true,
              image: true,
              firstName: true,
              lastName: true,
              email: true,
              phone: true,
            },
          },
        },
      ],
    });
    return data;
  }

  async updateById(id: string, forumUser: ForumUser): Promise<void> {
    const data = await this.forumUserRepository.updateById(id, forumUser);
    return data;
  }

  async deleteById(id: string): Promise<void> {
    return await this.forumUserRepository.deleteById(id);
  }
}
