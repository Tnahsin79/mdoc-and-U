import {
  BmiRepository,
  UsersRepository,
  HeightRepository,
  ActivityTimelineRepository,
} from '../repositories';
import {BmiService} from './bmi.service';
import {HttpErrors} from '@loopback/rest';
import {
  userPreferredHeight,
  footOrCentimeterToMeter,
} from '../utils/health-metrics-functions';
import {BmiServiceBindings} from '../keys';
import {Height, HeightWithRelations} from '../models';
import {Filter, repository} from '@loopback/repository';
import {BindingScope, bind, inject} from '@loopback/context';
import {PaginatedResponse, activityTypeObj} from '../type-schema';

@bind({scope: BindingScope.CONTEXT})
export class HeightService {
  constructor(
    @inject(BmiServiceBindings.BMI_SERVICE)
    public bmiService: BmiService,
    @repository(UsersRepository)
    public userRepository: UsersRepository,
    @repository(HeightRepository)
    public heightRepository: HeightRepository,
    @repository(BmiRepository)
    public bmiRepository: BmiRepository,
    @repository(ActivityTimelineRepository)
    public activityTimelineRepository: ActivityTimelineRepository,
  ) {}

  async create(payload: Omit<Height, 'id'>): Promise<Height> {
    let defaultValue = payload.value;
    if (payload.unit === 'CM' || payload.unit === 'FT/IN') {
      defaultValue = footOrCentimeterToMeter(payload.value, payload?.unit);
    }
    if (defaultValue < 1 || defaultValue > 2.5)
      throw new HttpErrors[409]('Please provide a valid value');
    const data = await this.heightRepository.create({
      ...payload,
      defaultValue,
      defaultUnit: 'M',
    });

    await this.activityTimelineRepository.create({
      activityType: activityTypeObj.HEIGHT,
      userId: data.userId,
      metadata: data.id,
    });
    await this.bmiService.create({
      userId: payload?.userId,
      channel: data.channel,
      coachId: data?.coachId,
      created_at: payload.created_at,
      modified_at: payload.modified_at,
    });
    return data;
  }

  async findAll(
    filter: Filter<Height>,
    page: number,
  ): Promise<PaginatedResponse<HeightWithRelations>> {
    const limit = filter?.limit ? filter?.limit : 25;
    const pageNum = page ? page : 1;
    const skip = (pageNum - 1) * limit;
    const content = await this.heightRepository.find({
      where: filter?.where,
      include: [
        {
          relation: 'coach',
          scope: {
            fields: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              phone: true,
            },
          },
        },
        {
          relation: 'user',
          scope: {
            fields: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              phone: true,
              heightUnit: true,
            },
          },
        },
      ],
      order: ['created_at DESC'],
      skip,
      limit,
    });
    const count = await this.heightRepository.count(filter?.where);
    const totalPages = Math.ceil(count.count / limit);

    content.map(height => {
      const response = userPreferredHeight(
        height.value,
        height.unit,
        height.user.heightUnit,
        height,
      );
      height.value = response.requiredHeight;
      height.unit = response.requiredUnit;
    });

    return {
      data: content,
      count: count.count,
      totalPages,
      currentPage: page,
      status: 'success',
    };
  }

  async findById(id: string, filter: Filter<Height>) {
    const data = this.heightRepository.findById(id, {
      where: filter?.where,
      include: [
        {
          relation: 'coach',
          scope: {
            fields: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              phone: true,
            },
          },
        },
        {
          relation: 'user',
          scope: {
            fields: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              phone: true,
            },
          },
        },
      ],
    });
    return data;
  }

  async updateById(id: string, height: Height): Promise<void> {
    if (height.value) {
      height.defaultValue = height.value;
      if (height.unit === 'CM' || height.unit === 'FT/IN')
        height.defaultValue = footOrCentimeterToMeter(
          height.value,
          height?.unit,
        );
    }
    return await this.heightRepository.updateById(id, height);
  }

  async deleteById(id: string): Promise<void> {
    const data = await this.heightRepository.deleteById(id);
    await this.bmiRepository.deleteAll({heightId: id});
    return data;
  }
}
