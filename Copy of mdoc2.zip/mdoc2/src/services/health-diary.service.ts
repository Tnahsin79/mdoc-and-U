import {
  BmiRepository,
  PsaRepository,
  HbaicRepository,
  UsersRepository,
  WeightRepository,
  HeightRepository,
  ExerciseRepository,
  PharmacyRepository,
  TreatmentRepository,
  CholestrolRepository,
  BloodSugarRepository,
  TemperatureRepository,
  BloodPressureRepository,
  EyeExaminationRepository,
  PregnancyCycleRepository,
  LabsProceduresRepository,
  FootExaminationRepository,
  HealthConditionRepository,
  MedicationPassportRepository,
  ProcedureSurgeriesRepository,
  WaistCircumferenceRepository,
  HealthProcedureSurgeriesRepository,
} from '../repositories';
import {
  userPreferredWaist,
  userPreferredHeight,
  userPreferredWeight,
  userPreferredTemperature,
  userPreferredBloodGlucose,
} from '../utils/health-metrics-functions';
import {repository} from '@loopback/repository';
import {bind, BindingScope} from '@loopback/context';

@bind({scope: BindingScope.TRANSIENT})
export class HealthDiaryService {
  constructor(
    @repository(HealthConditionRepository)
    public healthConditionRepository: HealthConditionRepository,
    @repository(TreatmentRepository)
    public treatmentRepository: TreatmentRepository,
    @repository(MedicationPassportRepository)
    public medicationRepository: MedicationPassportRepository,
    @repository(FootExaminationRepository)
    public footExaminationRepository: FootExaminationRepository,
    @repository(PharmacyRepository)
    public pharmacyRepository: PharmacyRepository,
    @repository(EyeExaminationRepository)
    public eyeExaminationRepository: EyeExaminationRepository,
    @repository(HealthProcedureSurgeriesRepository)
    public healthProcedureSurgeriesRepository: HealthProcedureSurgeriesRepository,
    @repository(ProcedureSurgeriesRepository)
    public procedureSurgeriesRepository: ProcedureSurgeriesRepository,
    @repository(LabsProceduresRepository)
    public labsProceduresRepository: LabsProceduresRepository,
    @repository(UsersRepository) public usersRepository: UsersRepository,
    @repository(WeightRepository) public weightRepository: WeightRepository,
    @repository(TemperatureRepository)
    public temperatureRepository: TemperatureRepository,
    @repository(HeightRepository) public heightRepository: HeightRepository,
    @repository(WaistCircumferenceRepository)
    public waistCircumferenceRepository: WaistCircumferenceRepository,
    @repository(BloodPressureRepository)
    public bloodPressureRepository: BloodPressureRepository,
    @repository(ExerciseRepository)
    public exerciseRepository: ExerciseRepository,
    @repository(PsaRepository) public psaRepository: PsaRepository,
    @repository(CholestrolRepository)
    public cholestrolRepository: CholestrolRepository,
    @repository(BloodSugarRepository)
    public bloodSugarRepository: BloodSugarRepository,
    @repository(HbaicRepository) public hbaicRepository: HbaicRepository,
    @repository(PregnancyCycleRepository)
    public pregnancyCycleRepository: PregnancyCycleRepository,
    @repository(BmiRepository)
    public bmiRepository: BmiRepository,
  ) {}

  async getUserHealthDiaryByUserId(userId: string) {
    const waist = await this.waistCircumferenceRepository.findOne({
      where: {
        userId,
      },
      include: [
        {
          relation: 'user',
          scope: {
            fields: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              phone: true,
              waistUnit: true,
            },
          },
        },
      ],
      order: ['created_at DESC'],
    });
    if (waist?.user?.waistUnit) {
      const responseWaist = userPreferredWaist(
        waist.currentWaist,
        waist.waistGoal,
        waist.unit,
        waist.user.waistUnit,
      );
      waist.currentWaist = responseWaist.requiredWaist;
      waist.unit = responseWaist.requiredUnit;
    }

    const weight = await this.weightRepository.findOne({
      where: {
        userId,
      },
      include: [
        {
          relation: 'user',
          scope: {
            fields: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              phone: true,
              weightUnit: true,
            },
          },
        },
      ],
      order: ['created_at DESC'],
    });
    if (weight?.user?.weightUnit) {
      const responseWeight = userPreferredWeight(
        weight.value,
        weight.goal,
        weight.unit,
        weight.user.weightUnit,
      );
      weight.value = responseWeight.requiredWeight;
      weight.unit = responseWeight.requiredUnit;
    }

    const prostrate = await this.psaRepository.findOne({
      where: {
        userId,
      },
      order: ['created_at DESC'],
    });

    const exercise = await this.exerciseRepository.findOne({
      where: {
        userId,
      },
      order: ['created_at DESC'],
    });

    const bloodPressure = await this.bloodPressureRepository.findOne({
      where: {
        userId,
      },
      order: ['created_at DESC'],
    });

    const bloodSugar = await this.hbaicRepository.findOne({
      where: {
        userId,
      },
      order: ['created_at DESC'],
    });

    const glucose = await this.bloodSugarRepository.findOne({
      where: {
        userId,
      },
      include: [
        {
          relation: 'user',
          scope: {
            fields: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              phone: true,
              bGlucoseUnit: true,
            },
          },
        },
      ],
      order: ['created_at DESC'],
    });
    if (glucose?.user?.bGlucoseUnit) {
      const beforeMealResponse = userPreferredBloodGlucose(
        glucose.beforeMeal,
        glucose.unit,
        glucose.user.bGlucoseUnit,
      );
      glucose.beforeMeal = beforeMealResponse.requiredValue;
      glucose.unit = beforeMealResponse.requiredUnit;
      const afterMealResponse = userPreferredBloodGlucose(
        glucose.afterMeal,
        glucose.unit,
        glucose.user.bGlucoseUnit,
      );
      glucose.afterMeal = afterMealResponse.requiredValue;
      glucose.unit = afterMealResponse.requiredUnit;
    }

    const cholesterol = await this.cholestrolRepository.findOne({
      where: {
        userId,
      },
      order: ['created_at DESC'],
    });

    const footExamination = await this.footExaminationRepository.findOne({
      where: {userId},
      order: ['created DESC'],
    });

    const eyeExamination = await this.eyeExaminationRepository.findOne({
      where: {userId},
      order: ['created DESC'],
    });

    const medication = await this.medicationRepository.findOne({
      where: {userId},
      order: ['modified DESC'],
      include: [{relation: 'medicine'}],
    });

    const temperature = await this.temperatureRepository.findOne({
      where: {
        userId,
      },
      include: [
        {
          relation: 'user',
          scope: {
            fields: {
              id: true,
              temperatureUnit: true,
            },
          },
        },
      ],
      order: ['created_at DESC'],
    });
    if (temperature?.user?.temperatureUnit) {
      const response = userPreferredTemperature(
        temperature.value,
        temperature.unit,
        temperature.user.temperatureUnit,
      );
      temperature.value = response.requiredTemperature;
      temperature.unit = response.requiredUnit;
    }

    const height = await this.heightRepository.findOne({
      where: {
        userId,
      },
      include: [
        {
          relation: 'user',
          scope: {
            fields: {
              id: true,
              heightUnit: true,
            },
          },
        },
      ],
      order: ['created_at DESC'],
    });
    if (height?.user?.heightUnit) {
      const responseHeight = userPreferredHeight(
        height.value,
        height.unit,
        height.user.heightUnit,
        height,
      );
      height.value = responseHeight.requiredHeight;
      height.unit = responseHeight.requiredUnit;
    }

    const bmi = await this.bmiRepository.findOne({
      where: {
        userId,
      },
      order: ['created_at DESC'],
    });

    let pregnancy = await this.pregnancyCycleRepository.findOne({
      where: {userId, isActive: true},
      order: ['created_at DESC'],
    });

    if (!pregnancy) {
      pregnancy = await this.pregnancyCycleRepository.findOne({
        where: {userId},
        order: ['created_at DESC'],
      });
    }

    return {
      bmi,
      waist,
      weight,
      height,
      glucose,
      exercise,
      pregnancy,
      prostrate,
      bloodSugar,
      medication,
      cholesterol,
      temperature,
      bloodPressure,
      eyeExamination,
      footExamination,
    };
  }
}
