import {inject} from '@loopback/context';
import {HttpErrors} from '@loopback/rest';
import {promisify} from 'util';
import {TokenService} from '@loopback/authentication';
import {UserProfile, securityId} from '@loopback/security';
import {TokenServiceBindings} from '../keys';
import {AnyObject} from '@loopback/repository';

const jwt = require('jsonwebtoken');
const signAsync = promisify(jwt.sign);
const verifyAsync = promisify(jwt.verify);

export class JWTService implements TokenService {
  constructor(
    @inject(TokenServiceBindings.TOKEN_SECRET)
    private jwtSecret: string,
    @inject(TokenServiceBindings.TOKEN_EXPIRES_IN)
    private jwtExpiresIn: string,
    // Move to env on prod before changing this
    private REFRESH_SECRET = '2867GGG34A7716A2F84459EAC9483',
  ) {}

  async verifyToken(token: string): Promise<UserProfile> {
    if (!token) {
      throw new HttpErrors.Unauthorized(
        `Error verifying token: 'token' is null`,
      );
    }
    try {
      let userProfile: UserProfile;
      // decode user profile from token
      const decryptedToken = await verifyAsync(token, this.jwtSecret);
      // don't copy over  token field 'iat' and 'exp', nor 'email' to user profile
      userProfile = Object.assign(
        {[securityId]: '', name: '', email: ''},
        {
          [securityId]: decryptedToken.id,
          name: decryptedToken.lname,
          email: decryptedToken.email,
        },
      );
      return userProfile;
    } catch (error) {
      throw new HttpErrors.Unauthorized(
        `Error verifying token: ${error.message}`,
      );
    }
  }

  async generateToken(userProfile: UserProfile): Promise<string> {
    if (!userProfile) {
      throw new HttpErrors.Unauthorized(
        'Error generating token: userProfile is null',
      );
    }

    // Generate a JSON Web Token
    const userInfoForToken = {
      id: userProfile[securityId],
      name: userProfile.lname || userProfile.name,
      email: userProfile.email,
    };
    let token: string;
    try {
      token = await signAsync(userInfoForToken, this.jwtSecret, {
        expiresIn: 600, // 10 minutes
      });
    } catch (err) {
      throw new HttpErrors.Unauthorized(`Error encoding token : ${err}`);
    }

    return token;
  }

  async generateRefreshToken(
    userProfile: UserProfile,
  ): Promise<{accessToken: string; refreshToken: string}> {
    if (!userProfile) {
      throw new HttpErrors.Unauthorized(
        'Error generating token: userProfile is null',
      );
    }
    const expiresInSixMonths = 15780000;
    const userInfoForToken = {
      id: userProfile[securityId],
      email: userProfile.email,
    };
    let refreshToken: string;
    let accessToken: string;
    try {
      refreshToken = await signAsync(userInfoForToken, this.REFRESH_SECRET, {
        expiresIn: expiresInSixMonths,
      });
      accessToken = await this.generateToken(userProfile);
    } catch (err) {
      throw new HttpErrors.Unauthorized(`Error encoding token : ${err}`);
    }
    return {refreshToken, accessToken};
  }



  async verifyRefreshToken(token: string): Promise<Omit<UserProfile, 'name'>> {
    if (!token) {
      throw new HttpErrors.Unauthorized(
        `Error verifying token: 'token' is null`,
      );
    }
    let userProfile;

    try {
      userProfile = await verifyAsync(token, this.REFRESH_SECRET);
    } catch (error) {
      throw new HttpErrors.Unauthorized(
        `Error verifying token: ${error.message}`,
      );
    }
    return userProfile;
  }
  

  async generateResetToken(userProfile: AnyObject): Promise<string> {
    if (!userProfile) {
      throw new HttpErrors.Unauthorized(
        'Error generating reset token : userProfile is null',
      );
    }

    let token: string,
      resetExpireIn = 600; // 10 minutes
    try {
      token = await signAsync(userProfile, this.jwtSecret, {
        expiresIn: Number(resetExpireIn),
      });
    } catch (err) {
      throw new HttpErrors.Unauthorized(`Error encoding token : ${err}`);
    }

    return token;
  }
}
