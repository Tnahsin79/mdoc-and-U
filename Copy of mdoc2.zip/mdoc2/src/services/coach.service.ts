import _ from 'lodash';
import {
  CoachRepository,
  LoginHistoryRepository,
  CoachProgramsRepository,
  CoachSpecialityRepository,
} from '../repositories';
import moment from 'moment';
import {inject} from '@loopback/core';
import {JWTService} from './jwt-service';
import {HttpErrors} from '@loopback/rest';
import {SourceTypeEnum} from '../type-schema';
import {bind, BindingScope} from '@loopback/context';
import {securityId, UserProfile} from '@loopback/security';
import {PasswordHasher} from '../services/hash.password.bcryptjs';
import {UserTypeEnum, LoginHistoryTypeEnum} from '../utils/enums';
import {AnyObject, Filter, repository} from '@loopback/repository';
import {PasswordHasherBindings, TokenServiceBindings} from '../keys';
import {Coach, CoachSpeciality, CoachSpecialityRelations} from '../models';

@bind({scope: BindingScope.TRANSIENT})
export class CoachService {
  constructor(
    @repository(CoachRepository)
    public coachRepository: CoachRepository,
    @repository(CoachSpecialityRepository)
    public coachSpecialityRepository: CoachSpecialityRepository,
    @repository(CoachProgramsRepository)
    public coachProgramsRepository: CoachProgramsRepository,
    @inject(TokenServiceBindings.TOKEN_SERVICE)
    public tokenService: JWTService,
    @inject(PasswordHasherBindings.PASSWORD_HASHER)
    public passwordHasher: PasswordHasher,
    @repository(LoginHistoryRepository)
    public loginHistoryRepository: LoginHistoryRepository,
  ) {}

  async getAllCoaches(limit = 20, page = 1, search = ''): Promise<AnyObject> {
    const skip = (page - 1) * limit;

    const where = {
      or: [
        {
          name: {
            like: search,
            options: 'i',
          },
        },
        {
          firstName: {
            like: search,
            options: 'i',
          },
        },
        {
          lastName: {
            like: search,
            options: 'i',
          },
        },
      ],
    };

    const result = await this.coachRepository.find({
      where,
      fields: {
        password: false,
        md5password: false,
      },
      include: [{relation: 'coachType'}],
      order: ['firstName ASC', 'lastName ASC'],
      skip,
      limit: limit === 0 ? undefined : limit,
    });
    const {count = 0} = await this.coachRepository.count(where);
    const totalPages = Math.ceil(count / limit);
    return {
      data: result,
      currentPage: page,
      limit,
      count: count || 0,
      totalPages,
    };
  }
  async resetCoachPassword(data: {
    token: string;
    password: string;
    email: string;
  }): Promise<any> {
    const coach = await this.coachRepository.findOne({
      where: {
        email: {regexp: `/^${data.email}/i`},
      },
    });
    if (coach?.id) {
      if (coach.resetToken === data.token) {
        const hashedPassword = await this.passwordHasher.hashPassword(
          data.password,
        );
        coach.password = hashedPassword;
        delete coach.md5password;

        try {
          await this.coachRepository.save(coach);
          coach.resetToken = null;
          await this.coachRepository.save(coach);
          return {
            status: 200,
            data: {
              message: 'Password reset successful!',
            },
          };
        } catch (error) {
          throw new HttpErrors.UnprocessableEntity(
            `Error in updating coach password`,
          );
        }
      } else {
        throw new HttpErrors.UnprocessableEntity('Reset tokens do not match');
      }
    } else {
      throw new HttpErrors.NotFound(`error while updating`);
    }
  }

  async changePassword(userId, password) {
    const responseData: AnyObject = {
      status: 'Success',
    };

    const coach = await this.coachRepository.findById(userId);

    if (!coach) {
      throw new HttpErrors.NotFound(`Coach not found`);
    }

    coach.password = await this.passwordHasher.hashPassword(password);
    await this.coachRepository.updateById(userId, coach);
    return responseData;
  }

  async getCoaches(filter, page): Promise<AnyObject> {
    const pageSize = filter?.limit === 0 ? undefined : filter?.limit || 20;
    const pageNum = page ? page : 1;
    const skip = (pageNum - 1) * pageSize;
    let searchString = filter?.searchString;
    if (searchString?.includes('+')) {
      searchString = searchString.replace('+', '');
    }

    let whereClause;
    const orClause = {
      or: [
        {name: new RegExp('.*' + searchString + '.*', 'i')},
        {email: new RegExp('.*' + searchString + '.*', 'i')},
        {phone: new RegExp('.*' + searchString + '.*', 'i')},
      ],
    };

    if (searchString) {
      whereClause = orClause;
    } else {
      whereClause = {};
    }
    const coaches = await this.coachRepository.find({
      where: whereClause,
      fields: {
        id: true,
        name: true,
        image: true,
        assignUserId: true,
        isActive: true,
        email: true,
        phone: true,
        specialities: true,
      },
      order: filter?.order,
      include: [
        {
          relation: 'coachType',
          scope: {
            fields: {name: true},
          },
        },
        {
          relation: 'users',
          scope: {
            fields: {assignCoachId: true},
          },
        },
      ],
      limit: pageSize,
      skip: skip,
    });

    const respdata: Array<Coach> = [];

    if (coaches?.length > 0) {
      _.forEach(coaches, (val: any) => {
        const {users, coachType, ...others} = val;
        const obj = Object.assign({}, others);
        obj.role = coachType?.name || '';
        obj.members = users?.length || 0;
        respdata.push(obj);
      });
    }

    const count = await this.coachRepository.count(whereClause);

    const totalPages = Math.ceil(count.count / pageSize);

    return {
      data: respdata,
      count: count.count,
      totalPages: totalPages,
      currentPage: pageNum,
      status: 'Success',
    };
  }

  async getCoachesBySpecialty(specialityId: string): Promise<any> {
    return await this.coachSpecialityRepository.find({
      where: {
        specialityId,
      },
      include: [{relation: 'coach'}],
    });
  }

  async refreshCoachToken(
    token: string,
  ): Promise<{
    refreshToken: string;
    accessToken: string;
  }> {
    const user = await this.tokenService.verifyRefreshToken(token);
    const coach = await this.coachRepository.findById(user?.id);
    if (!coach || !coach.refreshToken) {
      throw new HttpErrors.NotFound(`User not found`);
    }
    const data = this.tokenService.verifyRefreshToken(coach.refreshToken);
    if (!data) {
      throw new HttpErrors.Forbidden('Invalid token');
    }
    const userProfile = {
      email: coach?.email,
      [securityId]: coach?.id,
      name: coach?.lastName,
    };
    return await this.tokenService.generateRefreshToken(userProfile);
  }

  async findAllCoachesBySpecialityId(
    specialityId: string,
    filter?: Filter<CoachSpeciality>,
  ): Promise<CoachSpecialityRelations[]> {
    const response = await this.coachSpecialityRepository.find({
      where: {
        specialityId,
      },
      include: [
        {
          relation: 'coach',
          scope: {
            fields: {
              id: true,
              name: true,
              image: true,
              assignUserId: true,
              isActive: true,
              email: true,
              phone: true,
            },
          },
        },
        {
          relation: 'speciality',
          scope: {
            fields: {
              id: true,
              name: true,
              created_at: true,
            },
          },
        },
      ],
    });
    return response;
  }

  async getCoachPrograms(coachId: string) {
    return this.coachProgramsRepository.find({
      where: {
        coachId,
      },
      include: [
        {
          relation: 'program',
        },
      ],
    });
  }

  async logout(
    currentUser: UserProfile,
    credentials: {source: SourceTypeEnum; browserAgent?: string},
  ) {
    const logOut = await this.coachRepository.updateById(
      currentUser[securityId],
      {refreshToken: null},
    );
    await this.loginHistoryRepository.create({
      source: credentials.source,
      userType: UserTypeEnum.COACH,
      coachId: currentUser[securityId],
      loginDateTime: moment().toISOString(),
      browserAgent: credentials.browserAgent,
      record_type: LoginHistoryTypeEnum.LOGOUT,
    });
    return logOut;
  }
}
