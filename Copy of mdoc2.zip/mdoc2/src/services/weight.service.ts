import {
  BmiRepository,
  UsersRepository,
  WeightRepository,
  ActivityTimelineRepository,
} from '../repositories';
import {BmiService} from './bmi.service';
import {HttpErrors} from '@loopback/rest';
import {
  returnValues,
  poundsToKilograms,
  userPreferredWeight,
} from '../utils/health-metrics-functions';
import {OutlierService} from './outlier.service';
import {HealthMetricsTypeEnum} from '../utils/enums';
import {Weight, WeightWithRelations} from '../models';
import {Filter, repository} from '@loopback/repository';
import {BindingScope, bind, inject} from '@loopback/context';
import {PaginatedResponse, activityTypeObj} from '../type-schema';
import {BmiServiceBindings, OutlierServiceBindings} from '../keys';

@bind({scope: BindingScope.CONTEXT})
export class WeightService {
  constructor(
    @inject(OutlierServiceBindings.OUTLIER_SERVICE)
    public outlierService: OutlierService,
    @inject(BmiServiceBindings.BMI_SERVICE)
    public bmiService: BmiService,
    @repository(WeightRepository)
    public weightRepository: WeightRepository,
    @repository(BmiRepository)
    public bmiRepository: BmiRepository,
    @repository(ActivityTimelineRepository)
    public activityTimelineRepository: ActivityTimelineRepository,
    @repository(UsersRepository)
    public usersRepository: UsersRepository,
  ) {}

  async create(payload: Omit<Weight, 'id'>): Promise<Weight> {
    let defaultValue = payload.value;
    if (payload.unit != 'KG') {
      defaultValue = poundsToKilograms(payload.value);
    }
    if (defaultValue > 635 || defaultValue < 20)
      throw new HttpErrors[409]('Please provide a valid value');
    const data = await this.weightRepository.create({
      ...payload,
      defaultValue,
      defaultUnit: 'KG',
    });

    await this.activityTimelineRepository.create({
      activityType: activityTypeObj.WEIGHT,
      userId: data.userId,
      metadata: data.id,
      created_at: payload.created_at,
      modified_at: payload.modified_at,
    });
    await this.bmiService.create({
      userId: payload?.userId,
      channel: data.channel,
      coachId: data?.coachId,
    });
    try {
      const minMaxValue = returnValues('weight', payload.unit);
      if (
        data.value <= minMaxValue.minCritical ||
        data.value >= minMaxValue.maxCritical
      ) {
        const outlier = {
          userId: payload.userId,
          metricType: HealthMetricsTypeEnum.Weight,
          metricId: data.id,
          metricValue: `${data.value}${data.unit}`,
        };
        await this.outlierService.create(outlier);
      }
    } catch (error) {}
    return data;
  }

  async findAll(
    filter: Filter<Weight>,
    page: number,
  ): Promise<PaginatedResponse<WeightWithRelations>> {
    const limit = filter?.limit ? filter?.limit : 25;
    const pageNum = page ? page : 1;
    const skip = (pageNum - 1) * limit;
    const content = await this.weightRepository.find({
      where: filter?.where,
      include: [
        {
          relation: 'coach',
          scope: {
            fields: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              phone: true,
            },
          },
        },
        {
          relation: 'user',
          scope: {
            fields: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              phone: true,
              weightUnit: true,
            },
          },
        },
      ],
      order: ['created_at DESC'],
      skip,
      limit,
    });
    const count = await this.weightRepository.count(filter?.where);
    const totalPages = Math.ceil(count.count / limit);

    content.map(weight => {
      const response = userPreferredWeight(
        weight.value,
        weight.goal,
        weight.unit,
        weight.user.weightUnit,
      );
      weight.value = response.requiredWeight;
      weight.unit = response.requiredUnit;
      weight.goal = response.requiredGoal;
    });

    return {
      data: content,
      count: count.count,
      totalPages,
      currentPage: page,
      status: 'success',
    };
  }

  async findById(id: string, filter: Filter<Weight>) {
    const data = this.weightRepository.findById(id, {
      where: filter?.where,
      include: [
        {
          relation: 'coach',
          scope: {
            fields: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              phone: true,
            },
          },
        },
        {
          relation: 'user',
          scope: {
            fields: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              phone: true,
            },
          },
        },
      ],
    });
    return data;
  }

  async updateById(id: string, weight: Weight): Promise<void> {
    if (weight.value) {
      weight.defaultValue = weight.value;
      if (weight.unit != 'KG')
        weight.defaultValue = poundsToKilograms(weight.value);
    }
    const data = await this.weightRepository.updateById(id, weight);
    return data;
  }

  async deleteById(id: string): Promise<void> {
    const data = await this.weightRepository.deleteById(id);
    await this.bmiRepository.deleteAll({weightId: id});
    return data;
  }
}
