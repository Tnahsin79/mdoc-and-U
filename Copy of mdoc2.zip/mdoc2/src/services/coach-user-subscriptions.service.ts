import {
  CoachProgramsRepository,
  UserSubscriptionsRepository,
} from '../repositories';
import moment from 'moment';
import Utils from '../utils';
import {HttpErrors} from '@loopback/rest';
import {ActiveInactiveEnum, PaginatedResponse} from '../type-schema';
import {CoachUserSubscriptions} from '../models';
import {BindingScope, bind} from '@loopback/context';
import {Filter, repository} from '@loopback/repository';
import {CoachUserSubscriptionsRepository} from '../repositories/coach-user-subscriptions.repository';

@bind({scope: BindingScope.CONTEXT})
export class CoachUserSubscriptionsService {
  constructor(
    @repository(CoachUserSubscriptionsRepository)
    public coachUserSubscriptionsRepository: CoachUserSubscriptionsRepository,
    @repository(CoachProgramsRepository)
    public coachProgramsRepository: CoachProgramsRepository,
    @repository(UserSubscriptionsRepository)
    public userSubscriptionsRepository: UserSubscriptionsRepository,
  ) {}

  async create(
    payload: Omit<CoachUserSubscriptions, 'id'>,
  ): Promise<CoachUserSubscriptions> {
    return await this.coachUserSubscriptionsRepository.create(payload);
  }

  async createBulk(body: {
    programId: string;
    coachId: string;
    userSubscriptionIds: string[];
    fromCoachId?: string;
  }): Promise<CoachUserSubscriptions[]> {
    const {coachId, programId, userSubscriptionIds, fromCoachId} = body;
    const payload = userSubscriptionIds.map(item => ({
      userSubscriptionId: item,
      coachId,
    }));
    await this.coachUserSubscriptionsRepository.deleteAll({
      userSubscriptionId: {inq: userSubscriptionIds},
    });
    const response = await this.coachUserSubscriptionsRepository.createAll(
      payload,
    );
    const coachProgram = await this.coachProgramsRepository.findOne({
      where: {coachId, programId},
    });

    // Update the total member count of coach
    if (coachProgram) {
      const total =
        (coachProgram.totalMembers || 0) + userSubscriptionIds.length;
      await this.coachProgramsRepository.updateById(coachProgram.id, {
        totalMembers: total,
      });
    }

    // This is used when reassigning the members already assigned to a coach
    if (fromCoachId) {
      const fromCoach = await this.coachProgramsRepository.findOne({
        where: {coachId: fromCoachId, programId},
      });
      const total = (fromCoach.totalMembers || 0) - userSubscriptionIds.length;
      await this.coachProgramsRepository.updateById(fromCoach?.id, {
        totalMembers: total,
      });
    }

    return response;
  }

  async findAll({
    filter,
    programId,
    includeRelationships = true,
    startDate,
    endDate,
    page,
  }: {
    filter: Filter<CoachUserSubscriptions>;
    page: number;
    programId?: string;
    includeRelationships: boolean;
    startDate?: string;
    endDate?: string;
  }): Promise<PaginatedResponse<CoachUserSubscriptions>> {
    const limit = Utils.getLimit(filter?.limit);
    const pageNum = page ? page : 1;
    const skip = (pageNum - 1) * limit;
    const where = filter?.where || {};
    where['status'] = {neq: ActiveInactiveEnum.INACTIVE}
    if (programId) {
      const userSubscriptions = await this.userSubscriptionsRepository.find({
        where: {programId},
      });
      where['userSubscriptionId'] = {
        inq: userSubscriptions?.map(item => item.id),
      };
    }
    if (startDate && endDate) {
      const _startDate = moment(startDate)
        .utc()
        .toDate();
      const _endDate = moment(endDate)
        .utc()
        .toDate();
      where['created'] = {between: [_startDate, _endDate]};
    }

    if (startDate && !endDate) {
      const _startDate = moment(startDate)
        .utc()
        .toDate();
      where['created'] = {gte: _startDate};
    }

    if (endDate && !startDate) {
      const _endDate = moment(endDate)
        .utc()
        .toDate();
      where['created'] = {lte: _endDate};
    }
    const content = await this.coachUserSubscriptionsRepository.find({
      where,
      include: !includeRelationships
        ? []
        : [
            {
              relation: 'coach',
              scope: {
                fields: {
                  id: true,
                  firstName: true,
                  lastName: true,
                  email: true,
                  phone: true,
                },
              },
            },
            {
              relation: 'subscription',
              scope: {
                include: [
                  {
                    relation: 'user',
                    scope: {
                      fields: {
                        id: true,
                        firstName: true,
                        lastName: true,
                        name: true,
                        image: true,
                        email: true,
                        phone: true,
                        created: true,
                        dob: true,
                        gender: true,
                      },
                    },
                  },
                ],
              },
            },
          ],
      limit,
      skip,
    });
    const count = await this.coachUserSubscriptionsRepository.count(where);
    const totalPages = Math.ceil(count.count / limit);
    return {
      data: content,
      count: count.count,
      totalPages,
      currentPage: page,
      status: 'success',
    };
  }

  async findById(id: string, filter: Filter<CoachUserSubscriptions>) {
    const where = filter?.where || {};
    const data = this.coachUserSubscriptionsRepository.findById(id, {
      where: {...where, status: ActiveInactiveEnum.ACTIVE},
      include: [
        {
          relation: 'coach',
          scope: {
            fields: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              phone: true,
            },
          },
        },
        {
          relation: 'subscription',
          scope: {
            include: [{relation: 'user'}],
          },
        },
      ],
    });
    if (!data) {
      throw new HttpErrors[404]('The data does not exist.');
    }
    return data;
  }

  async updateById(
    id: string,
    payload: Partial<CoachUserSubscriptions>,
  ): Promise<void> {
    await this.coachUserSubscriptionsRepository.updateById(id, payload);
  }

  async unassign(id: string): Promise<void> {
    const data = await this.coachUserSubscriptionsRepository.findById(id, {
      include: [{relation: 'subscription'}],
    });
    if (!data) {
      throw new HttpErrors[404]('The data does not exist.');
    }
    const coachProgram = await this.coachProgramsRepository.findOne({
      where: {coachId: data?.coachId, programId: data?.subscription?.programId},
    });
    if (coachProgram) {
      // Handle case for already existing records as at time of implementation
      const total =
        (coachProgram?.totalMembers || 0) === 0
          ? 1
          : coachProgram?.totalMembers;
      await this.coachProgramsRepository.updateById(coachProgram.id, {
        totalMembers: total - 1,
      });
    }
    return await this.coachUserSubscriptionsRepository.deleteById(id);
  }

  async reassignAllMembers(payload: {
    fromCoachId: string;
    toCoachId: string;
    programId: string;
  }): Promise<void> {
    const {fromCoachId, toCoachId, programId} = payload;
    const membersToReAssign = await this.coachUserSubscriptionsRepository.find({
      where: {
        coachId: fromCoachId,
      },
    });
    if (!membersToReAssign?.length) {
      throw new HttpErrors[409]('The selected coach has no assigned member.');
    }

    // Update all records belonging to the coach you are removing his/her members
    // Set their active coach to the coach you want to reassign them to.

    await this.coachUserSubscriptionsRepository.updateAll(
      {coachId: toCoachId},
      {coachId: fromCoachId},
    );

    // Update the total count of members assigned to the new coach
    const newCoachProgram = await this.coachProgramsRepository.findOne({
      where: {coachId: toCoachId, programId},
    });
    if (newCoachProgram) {
      const total =
        (newCoachProgram.totalMembers || 0) + membersToReAssign.length;
      await this.coachProgramsRepository.updateById(newCoachProgram.id, {
        totalMembers: total,
      });
    }

    // Update the total assigned member count of the old coach to zero.
    const oldCoachProgram = await this.coachProgramsRepository.findOne({
      where: {coachId: fromCoachId, programId},
    });
    if (oldCoachProgram) {
      await this.coachProgramsRepository.updateById(oldCoachProgram.id, {
        totalMembers: 0,
      });
    }
  }
}
