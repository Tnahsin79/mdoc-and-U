import {PaginatedResponse} from '../type-schema';
import {BindingScope, bind} from '@loopback/context';
import {PregnancyLogRepository} from '../repositories';
import {Filter, repository} from '@loopback/repository';
import {PregnancyLog, PregnancyLogWithRelations} from '../models';

@bind({scope: BindingScope.CONTEXT})
export class PregnancyLogService {
  constructor(
    @repository(PregnancyLogRepository)
    public pregnancyLogRepository: PregnancyLogRepository,
  ) {}

  async create(payload: Omit<PregnancyLog, 'id'>): Promise<PregnancyLog> {
    return await this.pregnancyLogRepository.create(payload);
  }

  async findAll(
    filter: Filter<PregnancyLog>,
    page: number,
  ): Promise<PaginatedResponse<PregnancyLogWithRelations>> {
    const limit = filter?.limit ? filter?.limit : 25;
    const pageNum = page ? page : 1;
    const skip = (pageNum - 1) * limit;
    const content = await this.pregnancyLogRepository.find({
      where: filter?.where,
      include: [
        {
          relation: 'pregnancyCycle',
          scope: {
            include: [
              {
                relation: 'user',
                scope: {
                  fields: {
                    id: true,
                    firstName: true,
                    lastName: true,
                    email: true,
                    phoneNo: true,
                  },
                },
              },
            ],
          },
        },
      ],
      limit,
      skip,
    });
    const count = await this.pregnancyLogRepository.count();
    const totalPages = Math.ceil(count.count / limit);
    return {
      data: content,
      count: count.count,
      totalPages,
      currentPage: page,
      status: 'success',
    };
  }

  async findById(id: string, filter: Filter<PregnancyLog>) {
    const data = this.pregnancyLogRepository.findById(id, {
      where: filter?.where,
      include: [
        {
          relation: 'pregnancyCycle',
          scope: {
            include: [
              {
                relation: 'user',
                scope: {
                  fields: {
                    id: true,
                    firstName: true,
                    lastName: true,
                    email: true,
                    phoneNo: true,
                  },
                },
              },
            ],
          },
        },
      ],
    });
    return data;
  }

  async updateById(id: string, pregnancyLog: PregnancyLog): Promise<void> {
    const data = await this.pregnancyLogRepository.updateById(id, pregnancyLog);
    return data;
  }

  async deleteById(id: string): Promise<void> {
    return await this.pregnancyLogRepository.deleteById(id);
  }
}
