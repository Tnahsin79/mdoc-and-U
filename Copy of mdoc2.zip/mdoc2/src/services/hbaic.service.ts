import {HttpErrors} from '@loopback/rest';
import {OutlierServiceBindings} from '../keys';
import {OutlierService} from './outlier.service';
import {Hbaic, HbaicWithRelations} from '../models';
import {HealthMetricsTypeEnum} from '../utils/enums';
import {Filter, repository} from '@loopback/repository';
import {BindingScope, bind, inject} from '@loopback/context';
import {returnValues} from '../utils/health-metrics-functions';
import {PaginatedResponse, activityTypeObj} from '../type-schema';
import {ActivityTimelineRepository, HbaicRepository} from '../repositories';

@bind({scope: BindingScope.CONTEXT})
export class HbaicService {
  constructor(
    @inject(OutlierServiceBindings.OUTLIER_SERVICE)
    public outlierService: OutlierService,
    @repository(HbaicRepository)
    public hbaicRepository: HbaicRepository,
    @repository(ActivityTimelineRepository)
    public activityTimelineRepository: ActivityTimelineRepository,
  ) {}

  async create(payload: Omit<Hbaic, 'id'>): Promise<Hbaic> {
    if (payload.value < 4 || payload.value > 15) {
      throw new HttpErrors[409]('Please provide a valid value');
    }
    const data = await this.hbaicRepository.create(payload);
    await this.activityTimelineRepository.create({
      activityType: activityTypeObj.HBAIC,
      userId: data.userId,
      metadata: data.id,
    });

    try {
      const minMaxValue = returnValues(HealthMetricsTypeEnum.Hbaic);
      if (
        data.value <= minMaxValue.minCritical ||
        data.value >= minMaxValue.maxCritical
      ) {
        const outlier = {
          userId: payload.userId,
          metricType: HealthMetricsTypeEnum.Hbaic,
          metricId: data.id,
          metricValue: `${data.value}`,
        };
        await this.outlierService.create(outlier);
      }
    } catch (error) {}
    return data;
  }

  async findAll(
    filter: Filter<Hbaic>,
    page: number,
  ): Promise<PaginatedResponse<HbaicWithRelations>> {
    const limit = filter?.limit ? filter?.limit : 25;
    const pageNum = page ? page : 1;
    const skip = (pageNum - 1) * limit;
    const content = await this.hbaicRepository.find({
      where: filter?.where,
      include: [
        {
          relation: 'coach',
          scope: {
            fields: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              phone: true,
            },
          },
        },
        {
          relation: 'user',
          scope: {
            fields: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              phone: true,
            },
          },
        },
      ],
      limit,
      skip,
      order: ['created_at DESC'],
    });
    const count = await this.hbaicRepository.count(filter?.where);
    const totalPages = Math.ceil(count.count / limit);
    return {
      data: content,
      count: count.count,
      totalPages,
      currentPage: page,
      status: 'success',
    };
  }

  async findById(id: string, filter: Filter<Hbaic>) {
    const data = this.hbaicRepository.findById(id, {
      where: filter?.where,
      include: [
        {
          relation: 'coach',
          scope: {
            fields: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              phone: true,
            },
          },
        },
        {
          relation: 'user',
          scope: {
            fields: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              phone: true,
            },
          },
        },
      ],
    });
    return data;
  }

  async updateById(id: string, hbaic: Hbaic): Promise<void> {
    const data = await this.hbaicRepository.updateById(id, hbaic);
    return data;
  }

  async deleteById(id: string): Promise<void> {
    return await this.hbaicRepository.deleteById(id);
  }
}
