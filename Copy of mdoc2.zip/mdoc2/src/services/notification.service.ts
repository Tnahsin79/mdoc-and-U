import {Notification} from '../models';
import {NotificationTypeEnum, PaginatedResponse} from '../type-schema';
import {BindingScope, bind} from '@loopback/context';
import {NotificationRepository} from '../repositories';
import {Filter, repository} from '@loopback/repository';

@bind({scope: BindingScope.CONTEXT})
export class NotificationService {
  constructor(
    @repository(NotificationRepository)
    public notificationRepository: NotificationRepository,
  ) {}

  async create(notification: Omit<Notification, 'id'>) {
    return this.notificationRepository.create(notification);
  }

  async findAll(
    filter: Filter<Notification>,
    page: number,
  ): Promise<PaginatedResponse<Notification>> {
    const limit = filter?.limit ? filter?.limit : 25;
    const pageNum = page ? page : 1;
    const skip = (pageNum - 1) * limit;

    const where = {...filter?.where};
    where['notificationType'] = {neq: NotificationTypeEnum.CHAT};

    const content = await this.notificationRepository.find({
      where,
      order: ['created DESC'],
      skip,
      limit,
    });

    const count = await this.notificationRepository.count(filter?.where);
    const totalPages = Math.ceil(count.count / limit);

    return {
      data: content,
      count: count.count,
      totalPages,
      currentPage: page,
      status: 'success',
    };
  }
}
