import {repository} from '@loopback/repository';
import {BindingScope, bind} from '@loopback/context';
import {
  AdminRoleRepository,
  RolePrivilegeRepository,
  RoleRepository,
} from '../repositories';
import {Role} from '../models';
import { HttpErrors } from '@loopback/rest';

@bind({scope: BindingScope.CONTEXT})
export class RoleService {
  constructor(
    @repository(RoleRepository)
    public roleRepository: RoleRepository,
    @repository(RolePrivilegeRepository)
    public rolePrivilegeRepository: RolePrivilegeRepository,
    @repository(AdminRoleRepository)
    public adminRoleRepository: AdminRoleRepository,
  ) {}

  async create(data: any): Promise<any> {
    const roleObj = await this.roleRepository.create({
      title: data.title,
      description: data.description,
    });

    if (roleObj && roleObj.id && data.privileges && data.privileges.length) {
      const rolePrivileges = data.privileges.map((privilegeId: string) => {
        return {
          roleId: roleObj.id,
          privilegeId: privilegeId,
        };
      });

      await this.rolePrivilegeRepository.createAll(rolePrivileges);
    }
    return roleObj;
  }

  async assignRolesToAdmin(adminId: string, roleIds: string[]): Promise<any> {
    const adminRoles = roleIds.map((roleId: string) => {
      return {
        roleId: roleId,
        adminId: adminId,
      };
    });

    await this.adminRoleRepository.createAll(adminRoles);
    return true;
  }

  async updateById(id: string, payload: {role: Role; privileges: string[]}) {
    await this.roleRepository.updateById(id, payload.role);
    await this.rolePrivilegeRepository.deleteAll({roleId: id});
    const privileges = payload.privileges.map(item => ({
      roleId: id,
      privilegeId: item,
    }));
    await this.rolePrivilegeRepository.createAll(privileges);
  }

  async findAll(filter) {
    return await this.roleRepository.find({
      where: filter?.where,
      include: [
        {
          relation: 'rolePrivileges',
          scope: {
            include: [{relation: 'privilege'}],
          },
        },
        {
          relation: 'admins',
          scope: {
            fields: {
              id: true,
              name: true,
              image: true,
              email: true,
            },
          },
        },
      ],
    });
  }

  async findById(id: string) {
    const role = await this.roleRepository.findById(id, {
      include: [
        {
          relation: 'rolePrivileges',
          scope: {
            include: [{relation: 'privilege'}],
          },
        },
        {
          relation: 'admins',
          scope: {
            fields: {
              id: true,
              name: true,
              image: true,
              email: true,
            },
          },
        },
      ],
    });
    if (!role) {
      throw new HttpErrors[404]('This role does not exist')
    }
    return role;
  }
}
