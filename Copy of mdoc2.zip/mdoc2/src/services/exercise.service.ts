import {PaginatedResponse} from '../type-schema';
import {ExerciseRepository} from '../repositories';
import {BindingScope, bind} from '@loopback/context';
import {Filter, repository} from '@loopback/repository';
import {Exercise, ExerciseWithRelations} from '../models';

@bind({scope: BindingScope.CONTEXT})
export class ExerciseService {
  constructor(
    @repository(ExerciseRepository)
    public exerciseRepository: ExerciseRepository,
  ) {}

  async create(payload: Omit<Exercise, 'id'>): Promise<Exercise> {
    return await this.exerciseRepository.create(payload);
  }

  async findAll(
    filter: Filter<Exercise>,
    page: number,
  ): Promise<PaginatedResponse<ExerciseWithRelations>> {
    const limit = filter?.limit ? filter?.limit : 25;
    const pageNum = page ? page : 1;
    const skip = (pageNum - 1) * limit;
    const content = await this.exerciseRepository.find({
      where: filter?.where,
      include: [
        {
          relation: 'coach',
          scope: {
            fields: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              phone: true,
            },
          },
        },
        {
          relation: 'user',
          scope: {
            fields: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              phone: true,
            },
          },
        },
      ],
      order: ['created_at DESC'],
      skip,
      limit,
    });
    const count = await this.exerciseRepository.count(filter?.where);
    const totalPages = Math.ceil(count.count / limit);
    return {
      data: content,
      count: count.count,
      totalPages,
      currentPage: page,
      status: 'success',
    };
  }

  async findById(id: string, filter: Filter<Exercise>) {
    const data = this.exerciseRepository.findById(id, {
      where: filter?.where,
      include: [
        {
          relation: 'coach',
          scope: {
            fields: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              phone: true,
            },
          },
        },
        {
          relation: 'user',
          scope: {
            fields: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              phone: true,
            },
          },
        },
      ],
    });
    return data;
  }

  async updateById(id: string, exercise: Exercise): Promise<void> {
    const data = await this.exerciseRepository.updateById(id, exercise);
    return data;
  }

  async deleteById(id: string): Promise<void> {
    return await this.exerciseRepository.deleteById(id);
  }
}
