import {Filter, repository} from '@loopback/repository';
import {
  ChatRepository,
  ChatRoomRepository,
  CoachRepository,
  UsersRepository,
} from '../repositories';
import {BindingScope, bind} from '@loopback/context';
import {ChatRoomUserRepository} from '../repositories/chat-room-user.repository';
import {ChatRoom, ChatRoomWithRelations, ChatWithRelations} from '../models';
import {UserLiteObject} from '../utils/enums';
import Utils from '../utils';
import {HttpErrors} from '@loopback/rest';

@bind({scope: BindingScope.CONTEXT})
export class ChatRoomService {
  constructor(
    @repository(ChatRoomRepository)
    public chatRoomRepository: ChatRoomRepository,
    @repository(ChatRoomUserRepository)
    public chatRoomUserRepository: ChatRoomUserRepository,
    @repository(ChatRepository)
    public chatRepository: ChatRepository,
    @repository(CoachRepository)
    public coachRepository: CoachRepository,
    @repository(UsersRepository)
    public usersRepository: UsersRepository,
  ) {}

  async find(filter) {
    return this.chatRoomRepository.find(filter);
  }

  async create(payload: Omit<ChatRoom, 'id'>) {
    if (payload.type === 'group') {
      return await this.chatRoomRepository.create(payload);
    } else {
      if (!payload.receiverCoachId)
        throw new HttpErrors[409](
          'Coach not found, please refresh and try again',
        );
      const creatorType = payload.creatorType;
      let where: any = {};
      if (creatorType === 'coach') {
        where = {
          or: [
            {
              and: [
                {creatorId: payload.creatorId},
                {
                  receiverIds: {
                    inq: [payload.receiverIds],
                  },
                },
                {type: 'direct'},
              ],
            },
            {
              and: [
                {creatorId: {inq: payload.receiverIds}},
                {receiverCoachId: payload.creatorId},
                {type: 'direct'},
              ],
            },
          ],
        };
      } else {
        where = {
          or: [
            {
              and: [
                {creatorId: payload.creatorId},
                {receiverCoachId: payload.receiverCoachId},
                {type: 'direct'},
              ],
            },
            {
              and: [
                {creatorId: payload.receiverCoachId},
                {receiverIds: {inq: [[payload.creatorId]]}},
                {type: 'direct'},
              ],
            },
          ],
        };
      }
      const existing = await this.chatRoomRepository.findOne({
        where,
      });
      if (existing) {
        return existing;
      }
      let user: any = {};
      if (payload.type === 'direct') {
        user = await this.usersRepository.findOne({
          where: {id: payload.receiverIds[0]},
        });
      }
      const obj = {
        ...payload,
        receiverMemberId:
          payload.type === 'direct' ? payload.receiverIds[0] : undefined,
        userFullName:
          payload.type === 'direct'
            ? `${user?.firstName || 'xx'} ${user?.lastName || 'xx'}`
            : undefined, // xx is used for tracking and debugging purposes
        receiverCoachId:
          payload.creatorType === 'coach'
            ? payload.creatorId
            : payload.receiverCoachId,
      };
      const room = await this.chatRoomRepository.create(obj);
      return {...room, isNewRoom: true};
    }
  }

  async getSingleChatroom({
    coachId,
    userId,
  }: {
    coachId: string;
    userId: string;
  }) {
    if (!coachId || !userId) {
      throw new HttpErrors[409]('Please provide a valid user and coach');
    }
    const chatRoom = await this.chatRoomRepository.findOne({
      where: {
        receiverCoachId: coachId,
        receiverMemberId: userId,
      },
      include: [
        {relation: 'receiverCoach', scope: {fields: UserLiteObject}},
        {relation: 'receiverMember', scope: {fields: UserLiteObject}},
      ],
    });
    if (!chatRoom) {
      const user = await this.usersRepository.findOne({where: {id: userId}});
      if (!user) {
        throw new HttpErrors[409]('User does not exist')
      }
      const newRoom = await this.chatRoomRepository.create({
        type: 'direct',
        creatorId: coachId,
        receiverCoachId: coachId,
        receiverMemberId: userId,
        receiverIds: [userId],
        userFullName: `${user.firstName} ${user.lastName}`,
        imageUrl: user.image,
        creatorType: 'coach'
      });
      const room = await this.chatRoomRepository.findOne({
        where: {
          id: newRoom.id
        },
        include: [
          {relation: 'receiverCoach', scope: {fields: UserLiteObject}},
          {relation: 'receiverMember', scope: {fields: UserLiteObject}},
        ],
      });
      return room;
    }
    return chatRoom;
  }

  async getChatUserList(id: string) {
    const chatRooms = await this.chatRoomRepository.find({
      where: {
        or: [{creatorId: id}, {receiverMemberId: id}, {receiverIds: {inq: [[id]]}}],
      },
      order: ['lastMessageTime DESC'],
      include: [{relation: 'receiverCoach', scope: {fields: UserLiteObject}}]
    });

    const chatList: ChatWithRelations[] = [];
    const res = chatRooms?.map(async room => {
      const chat = await this.chatRepository.findOne({
        where: {
          chatRoomId: room.id,
        },
        order: ['created_at DESC'],
      });
      chatList.push(chat);
      return {
        ...room,
        chats: [chat]
      };
    });
    const response = await Promise.all(res);

    return response.filter(x => x);
  }

  async getCoachChatList(
    coachId: string,
    type: 'direct' | 'group',
    filter?: Filter<ChatRoom>,
    page?: number,
    search?: string,
  ) {
    let where: any = {
      or: [{creatorId: coachId}, {receiverCoachId: coachId}],
    };
    const limit = Utils.getLimit(filter?.limit);
    const pageNum = page ? page : 1;
    const skip = (pageNum - 1) * limit;

    let searchString = search;
    if (searchString?.includes('+')) {
      searchString = searchString.replace('+', '');
    }

    if (search) {
      where = {
        and: [
          {
            or: [{creatorId: coachId}, {receiverCoachId: coachId}],
          },
          {
            or: [
              {userFullName: new RegExp('.*' + searchString + '.*', 'i')},
              {groupName: new RegExp('.*' + searchString + '.*', 'i')},
            ],
          },
        ],
      };
    }

    const chatRooms = await this.chatRoomRepository.find({
      where,
      limit,
      skip,
      include: [
        {
          relation: 'receiverMember',
          scope: {
            fields: {
              id: true,
              firstName: true,
              lastName: true,
              image: true,
              isOnline: true,
              name: true,
              lastSeen: true,
            },
          },
        },
      ],
      order: ['lastMessageTime DESC'],
    });

    // Retrieve the latest chat for each chat room
    for (const room of chatRooms) {
      const latestChat = await this.chatRepository.findOne({
        where: {chatRoomId: room.id},
        order: ['created_at DESC'],
      });
      room.chats = [latestChat]; // Set the latest chat for the chat room
    }

    const count = await this.chatRoomRepository.count(where);
    const totalPages = Math.ceil(count.count / limit);

    return {
      data: chatRooms,
      count: count.count,
      totalPages,
      currentPage: page,
      status: 'success',
    };
  }

  async getSummary(id: string, userId: string) {
    const chatRoom = await this.chatRoomRepository.findById(id);
    if (chatRoom) {
      const uids = [...chatRoom.receiverIds, chatRoom?.creatorId].filter(
        item => item.toString() !== userId,
      );

      const chats = await this.chatRepository.find({
        where: {chatRoomId: id, resourceUrl: {neq: ''}},
      });
      const users = await this.usersRepository.find({
        where: {
          id: {inq: uids},
        },
        fields: {
          id: true,
          image: true,
          name: true,
          firstName: true,
          lastName: true,
          email: true,
          phone: true,
        },
        include: [
          {
            relation: 'subscriptions',
            scope: {include: [{relation: 'program'}]},
          },
        ],
      });
      const resources = chats?.map(item => item.resourceUrl);
      const coach = await this.coachRepository.findOne({
        where: {
          or: [
            {id: chatRoom?.creatorId},
            {id: chatRoom?.receiverCoachId || null},
          ],
        },
        fields: {
          id: true,
          image: true,
          name: true,
          firstName: true,
          lastName: true,
        },
      });
      return {
        chatRoom,
        users,
        resources,
        coach,
      };
    }
  }

  returnRelations() {
    return [
      {
        relation: 'coach',
        scope: {
          fields: {
            id: true,
            firstName: true,
            lastName: true,
            name: true,
            image: true,
          },
        },
      },
      {
        relation: 'user',
        scope: {
          fields: {
            id: true,
            name: true,
            firstName: true,
            lastName: true,
            image: true,
          },
        },
      },
    ];
  }
}
