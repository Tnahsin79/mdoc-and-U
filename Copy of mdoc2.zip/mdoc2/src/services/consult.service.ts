import {
  EmailServiceBindings,
  TokenServiceBindings,
  ControllerServiceBindings,
} from '../keys';
import {
  CoachRepository,
  UsersRepository,
  ConsultRepository,
  PartnerRepository,
} from '../repositories';
import dotenv from 'dotenv';
import moment from 'moment';
import Utils from '../utils';
import {JWTService} from './jwt-service';
import {HttpErrors} from '@loopback/rest';
import {EmailService} from './email.service';
import {securityId} from '@loopback/security';
import {PaginatedResponse} from '../type-schema';
import {ControllerService} from './controller.service';
import {Consult, ConsultWithRelations} from '../models';
import {Filter, repository} from '@loopback/repository';
import {BindingScope, bind, inject} from '@loopback/context';
import {ConsultStatusEnum, UserLiteObject} from '../utils/enums';

dotenv.config();
@bind({scope: BindingScope.CONTEXT})
export class ConsultService {
  constructor(
    @inject(EmailServiceBindings.MAIL_SERVICE)
    public emailService: EmailService,
    @repository(UsersRepository)
    public userRepository: UsersRepository,
    @repository(ConsultRepository)
    public consultRepository: ConsultRepository,
    @repository(PartnerRepository)
    public partnerRepository: PartnerRepository,
    @repository(CoachRepository)
    public coachRepository: CoachRepository,
    @inject(ControllerServiceBindings.CONTROLLER_SERVICE)
    public controllerService: ControllerService,
    @inject(TokenServiceBindings.TOKEN_SERVICE)
    public jwtService: JWTService,
  ) {}

  async verifyConsultCode({
    partnerId,
    consultId,
    passcode,
  }: {
    partnerId: string;
    consultId: string;
    passcode: string;
  }) {
    const consult = await this.consultRepository.findOne({
      where: {
        id: consultId,
        passcode,
      },
    });
    if (!consult) {
      throw new HttpErrors[409]('Consult does not exist');
    }
    const partner = await this.partnerRepository.findById(partnerId, {
      include: [{relation: 'coachAccount', scope: {fields: UserLiteObject}}],
    });
    if (!partner) {
      throw new HttpErrors[409]('Partner does not exist');
    }
    if (consult.partnerId?.toString() !== partner?.id?.toString()) {
      throw new HttpErrors[409]("You don't have access to this consult");
    }
    if (consult.passcode !== passcode) {
      throw new HttpErrors[409]("You don't have access to this consult");
    }
    const coach = await this.coachRepository.findOne({
      where: {partnerId: partner?.id},
    });

    // authenticate partner coach account

    const userProfile = {
      [securityId]: coach?.id ?? '',
      name: coach?.name ?? '',
      email: coach?.email ?? '',
    };
    const token = await this.jwtService.generateToken(userProfile);
    const {refreshToken} = await this.jwtService.generateRefreshToken(
      userProfile,
    );
    const obj = {
      isOnline: true,
      refreshToken,
    };
    await this.coachRepository.updateById(coach?.id, obj);

    const response = await this.findById(consultId);

    return {consult: response, coach, accessToken: token, refreshToken};
  }

  async create(payload: Omit<Consult, 'id'>): Promise<Consult> {
    const partner = await this.partnerRepository.findById(payload.partnerId);
    if (!partner) {
      throw new HttpErrors[409]('Partner not found');
    }
    const user = await this.userRepository.findById(payload.userId);
    if (!user) {
      throw new HttpErrors[409]('Member not found');
    }

    const coach = await this.coachRepository.findById(payload.coachId);

    const consult = await this.consultRepository.create(payload);

    // Send email here

    if (user?.email) {
      await this.emailService.sendMail({
        to: user?.email,
        slug: 'new_consult_member',
        message: {
          name: `${user.firstName}`,
          partner: partner?.name,
          consultId: consult.id,
          date: moment(consult.preferredDate).format('Do MMM, YYYY HH:mm a'),
        },
      });
    } else {
      const body = `A consult session has been booked for you with ${partner?.name}.`;
      await this.controllerService.sendOtpService(user?.phone, body);
    }

    if (partner?.email) {
      await this.emailService.sendMail({
        to: partner.email,
        slug: 'new_consult_partner',
        message: {
          patientName: `${user.firstName} ${user.lastName}`,
          partner: partner?.name,
          consultId: consult.id,
          consultDate: moment(consult.preferredDate).format(
            'Do MMM, YYYY HH:mm a',
          ),
          code: consult.passcode,
          link: `${process.env.COACH_FRONTEND_URL}/member-consult/${consult.id}?partnerId=${partner.id}`,
          patientPhone: user.phone,
          patientEmail: user.email,
          patientAge: moment(user.dob).fromNow(),
          patientGender: user.gender || 'not-specified',
          consultReason: consult.consultReason,
          reasonType: consult.reasonType,
          coachName: `${coach?.firstName} ${coach?.lastName}`,
          coachEmail: coach?.email,
          coachPhone: coach?.phone,
          coachOrg: 'mDoc Healthcare',
          note: consult?.additionalNotes,
        },
      });
    }

    return consult;
  }

  async getStatistics(coachId: string) {
    const consults = await this.consultRepository.find({
      where: {coachId},
    });
    const booked =
      consults.filter(item => item.status === ConsultStatusEnum.BOOKED)
        ?.length || 0;
    const accepted =
      consults.filter(item => item.status === ConsultStatusEnum.ACCEPTED)
        ?.length || 0;
    const completed =
      consults.filter(item => item.status === ConsultStatusEnum.COMPLETED)
        ?.length || 0;

    return {
      totalConsults: consults?.length || 0,
      totalBooked: booked,
      totalAccepted: accepted,
      totalCompleted: completed,
    };
  }

  async findAll(
    filter: Filter<Consult>,
    page: number,
    search?: string,
  ): Promise<PaginatedResponse<ConsultWithRelations>> {
    const where = filter?.where || {};
    const limit = Utils.getLimit(filter?.limit);
    const pageNum = page ? page : 1;
    const skip = (pageNum - 1) * limit;

    let searchString = search;
    if (searchString?.includes('+')) {
      searchString = searchString.replace('+', '');
    }

    if (search) {
      where['userFullName'] = new RegExp('.*' + searchString + '.*', 'i');
    }
    const content = await this.consultRepository.find({
      where,
      include: [
        {
          relation: 'coach',
          scope: {
            fields: UserLiteObject,
          },
        },
        {
          relation: 'user',
          scope: {
            fields: UserLiteObject,
          },
        },
        {relation: 'partner'},
        {relation: 'height'},
        {relation: 'weight'},
        {relation: 'bloodPressure'},
        {relation: 'bloodSugar'},
        {relation: 'hbaic'},
        {relation: 'note'},
        {relation: 'temperature'},
        {relation: 'exercise'},
        {relation: 'eyeExamination'},
        {relation: 'cholestrol'},
        {
          relation: 'medication',
          scope: {
            include: [
              {
                relation: 'medicine',
                scope: {
                  fields: {
                    id: true,
                    name: true,
                  },
                },
              },
            ],
          },
        },
      ],
      limit,
      skip,
      order: ['created_at DESC'],
    });
    const count = await this.consultRepository.count(where);
    const totalPages = Math.ceil(count.count / limit);

    return {
      data: content,
      count: count.count,
      totalPages,
      currentPage: page,
      status: 'success',
    };
  }

  async findById(id: string, filter?: Filter<Consult>) {
    const data = this.consultRepository.findById(id, {
      where: filter?.where,
      include: [
        {
          relation: 'coach',
          scope: {
            fields: UserLiteObject,
          },
        },
        {
          relation: 'user',
          scope: {
            fields: UserLiteObject,
          },
        },
        {relation: 'partner'},
        {relation: 'height'},
        {relation: 'weight'},
        {relation: 'bloodPressure'},
        {relation: 'bloodSugar'},
        {relation: 'hbaic'},
        {relation: 'note'},
        {relation: 'temperature'},
        {relation: 'exercise'},
        {relation: 'eyeExamination'},
        {relation: 'cholestrol'},
        {
          relation: 'medication',
          scope: {
            include: [
              {
                relation: 'medicine',
                scope: {
                  fields: {
                    id: true,
                    name: true,
                  },
                },
              },
            ],
          },
        },
      ],
    });
    return data;
  }

  async updateById(id: string, updates: Consult): Promise<void> {
    const consult = await this.consultRepository.findById(id, {
      include: [
        {relation: 'user', scope: {fields: UserLiteObject}},
        {relation: 'coach', scope: {fields: UserLiteObject}},
        {relation: 'partner'},
      ],
    });
    if (!consult) {
      throw new HttpErrors[404]('Consult does not exist');
    }
    const res = await this.consultRepository.updateById(id, updates);
    const status = consult?.status;
    const coach = consult?.coach;
    const user = consult?.user;
    const partner = consult?.partner;
    if (
      updates?.status === ConsultStatusEnum.ACCEPTED &&
      status === ConsultStatusEnum.BOOKED
    ) {
      // Send acceptance mail here to user and coach
      if (coach?.email) {
        await this.emailService.sendMail({
          to: coach?.email,
          slug: 'accepted_consult_coach',
          message: {
            name: `${coach?.firstName}`,
            link: updates?.meetingResource,
            platform: updates?.meetingPlatform,
            partner: partner?.name,
            patientName: `${user.firstName} ${user.lastName}`,
            date: moment(updates.consultDate).format('Do MMM, YYYY HH:mm a'),
          },
        });
      }
      if (user?.email) {
        await this.emailService.sendMail({
          to: user?.email,
          slug: 'accepted_consult_user',
          message: {
            name: `${user?.firstName}`,
            link: '',
            platform: updates?.meetingPlatform,
            partner: partner?.name,
            date: moment(updates.consultDate).format('Do MMM, YYYY HH:mm a'),
          },
        });
      } else {
        const body = `Your consult with ${partner?.name} on ${moment(
          updates.consultDate,
        ).format('Do MMM, YYYY HH:mm a')} has been confirmed.`;
        await this.controllerService.sendOtpService(user?.phone, body);
      }
    }
    return res;
  }

  async deleteById(id: string): Promise<void> {
    const data = await this.consultRepository.deleteById(id);
    return data;
  }
}
