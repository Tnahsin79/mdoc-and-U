import {
  EmailServiceBindings,
  TokenServiceBindings,
  HeightServiceBindings,
  WeightServiceBindings,
  PasswordHasherBindings,
  ControllerServiceBindings,
} from '../keys';
import md5 from 'md5';
import {
  Credentials,
  SourceTypeEnum,
  VerificationTypeEnum,
} from '../type-schema';
import {
  UsersRepository,
  CoachRepository,
  PaymentsRepository,
  PharmacyRepository,
  ProviderRepository,
  LoginHistoryRepository,
  EyeExaminationRepository,
  LabsProceduresRepository,
  HealthConditionRepository,
  FootExaminationRepository,
  MedicationPassportRepository,
  HealthProcedureSurgeriesRepository,
} from '../repositories';
import moment from 'moment';
import * as _ from 'lodash';
import multer from 'multer';
import * as path from 'path';
import Utils from '../utils';
import {JWTService} from './jwt-service';
import {inject} from '@loopback/context';
import {Height, Weight} from '../models';
import {Users} from '../models/users.model';
import * as common from '../services/common';
import {validatePassword} from './validator';
import {HeightService} from './height.service';
import {WeightService} from './weight.service';
import {UserService} from '@loopback/authentication';
import {EmailService} from '../services/email.service';
import {PasswordHasher} from './hash.password.bcryptjs';
import {repository, AnyObject} from '@loopback/repository';
import {UserProfile, securityId} from '@loopback/security';
import {HttpErrors, Request, Response} from '@loopback/rest';
import {ControllerService} from '../services/controller.service';
import {LoginHistoryTypeEnum, UserTypeEnum} from '../utils/enums';

export class UsersService implements UserService<Users, Credentials> {
  configOption = Utils.getSiteOptions();

  constructor(
    @repository(UsersRepository) public usersRepository: UsersRepository,
    @repository(PaymentsRepository)
    public paymentRepository: PaymentsRepository,
    @repository(CoachRepository) public coachRepository: CoachRepository,
    @inject(PasswordHasherBindings.PASSWORD_HASHER)
    public passwordHasher: PasswordHasher,
    @inject(ControllerServiceBindings.CONTROLLER_SERVICE)
    public controllerService: ControllerService,
    @inject(EmailServiceBindings.MAIL_SERVICE)
    public emailservice: EmailService,
    @inject(HeightServiceBindings.HEIGHT_SERVICE)
    public heightService: HeightService,
    @inject(WeightServiceBindings.WEIGHT_SERVICE)
    public weightService: WeightService,
    @inject(TokenServiceBindings.TOKEN_SERVICE) public jwtService: JWTService,
    @repository(LoginHistoryRepository)
    public loginHistoryRepository: LoginHistoryRepository,

    @repository(EyeExaminationRepository)
    public eyeExaminationRepository: EyeExaminationRepository,

    @repository(FootExaminationRepository)
    public footExaminationRepository: FootExaminationRepository,

    @repository(HealthConditionRepository)
    public healthConditionRepository: HealthConditionRepository,

    @repository(MedicationPassportRepository)
    public medicationPassportRepository: MedicationPassportRepository,

    @repository(PharmacyRepository)
    public pharmacyRepository: PharmacyRepository,

    @repository(HealthProcedureSurgeriesRepository)
    public procedureSurgeriesRepository: HealthProcedureSurgeriesRepository,

    @repository(LabsProceduresRepository)
    public labsProceduresRepository: LabsProceduresRepository,

    @repository(ProviderRepository)
    public providerRepository: ProviderRepository,
  ) {}

  async userLogin(credentials: Credentials) {
    const {email, password} = credentials;
    const user = await this.verifyCredentials({email, password}, true);

    if (user) {
      await this.loginHistoryRepository.create({
        userId: user.id,
        loginDateTime: moment().toISOString(),
        source: credentials.source,
        userType: UserTypeEnum.USER,
        browserAgent: credentials.browserAgent,
        record_type: LoginHistoryTypeEnum.LOGIN,
      });
      const response: any = {user};
      if (user.verificationStatus === 'unverified') {
        const result = await this.sendUserOTP(user.phone, user.email);
        response.otpStatus = result.status;
        return response;
      }
      const userProfile = {
        [securityId]: user.id ?? '',
        name: user.name ?? '',
        email: user.email ?? '',
      };

      const {
        refreshToken,
        accessToken,
      } = await this.jwtService.generateRefreshToken(userProfile);
      await this.usersRepository.updateById(user.id, {
        isOnline: true,
        refreshToken,
      });
      return {user, refreshToken, accessToken};
    } else {
      throw new HttpErrors[409]('Invalid login credentials.');
    }
  }

  async create(user) {
    // check if email is blacklisted
    if (user?.email && Utils.isEmailBlacklisted(user?.email)) {
      throw new HttpErrors[409]('Action not allowed. Please contact support.');
    }
    if (user?.password) {
      user.password = await this.passwordHasher.hashPassword(user.password);
      user.md5password = md5(user.password);
    }
    const phone = Utils.stripNigerianPhoneOfLeadingZero(user?.phone);
    const emailLowercase =  user?.email?.toLowerCase();
    const where = {};
    if (user?.phone && user?.email) {
      where['or'] = [{phone}, {email: emailLowercase}];
    } else if (user?.phone) {
      where['phone'] = phone;
    } else if (user?.email) {
      where['email'] = emailLowercase;
    }
    console.log(where);
    const userDetail = await this.usersRepository.findOne({
      where,
    });

    if (userDetail?.id) {
      throw new HttpErrors[409]('Email or phone number already exists.');
    } else {
      try {
        // generate a referral code for the user
        user.referralCode = (await this.generateReferralCode(user)).toString();
        const newUser = await this.usersRepository.create({
          ...user,
          ...(user?.email && {email: emailLowercase}),
          phone,
        });
        const result = await this.sendUserOTP(newUser?.phone, newUser?.email);
        return {
          otpStatus: result,
          user: {
            id: newUser?.id,
            email: newUser?.email,
            phone: newUser?.phone,
          },
        };
      } catch (error) {
        console.error({error: error?.response?.body});
        throw new HttpErrors[500](error?.message || '');
      }
    }
  }

  async socialLogin(data) {
    if (
      !(
        data &&
        (data.facebookId || data.twitterId || data.googleId || data.appleId)
      )
    ) {
      throw new HttpErrors.UnprocessableEntity('Social Id is required!');
    }

    if (!data.name || !data.email) {
      throw new HttpErrors[409]('Email Address and Name is required!');
    }

    let query: AnyObject = {};
    const socailKey = {facebookId: '', twitterId: '', googleId: ''};
    if (data.facebookId) {
      socailKey['facebookId'] = data.facebookId;
      query = {
        'social.facebookId': data.facebookId,
      };
    } else if (data.twitterId) {
      socailKey['twitterId'] = data.twitterId;
      query = {
        'social.twitterId': data.twitterId,
      };
    } else if (data.googleId) {
      socailKey['googleId'] = data.googleId;
      query = {
        'social.googleId': data.googleId,
      };
    } else if (data.appleId) {
      socailKey['appleId'] = data.appleId;
      query = {
        'social.appleId': data.appleId,
      };
    }

    let userDetail = await this.usersRepository.findOne({
      where: query,
      fields: {password: false, md5password: false, social: false},
      include: [
        {
          relation: 'subscriptions',
          scope: {
            include: [
              {relation: 'plan'},
              {relation: 'program'},
              {relation: 'payment'},
            ],
          },
        },
      ],
    });

    if (userDetail === null) {
      // check if the email account already exist
      const emailAccountExist = await this.usersRepository.findOne({
        where: {email: data.email},
        fields: {password: false, md5password: false, social: false},
      });

      if (emailAccountExist) {
        throw new HttpErrors.NotAcceptable('Email account already exist');
      }

      // split the username for the first and lastname property
      data.firstName = data.name.split(' ')[0] ?? '';
      data.lastName = data.name.split(' ')[1] ?? '';
      // create the account as social login
      await this.usersRepository.create({
        name: data.name,
        firstName: data.firstName,
        lastName: data.lastName,
        email: data.email,
        gender: data.gender,
        dob: data.dob,
        verificationStatus: 'verified',
        password: null,
        md5password: null,
        social: socailKey,
        referralCode: (await this.generateReferralCode(data)).toString(),
      });

      userDetail = await this.usersRepository.findOne({
        where: query,
        fields: {password: false, md5password: false, social: false},
        include: [
          {
            relation: 'subscriptions',
            scope: {
              include: [
                {relation: 'plan'},
                {relation: 'program'},
                {relation: 'payment'},
              ],
            },
          },
        ],
      });
    }

    if (userDetail?.id) {
      const userProfile = {
        [securityId]: userDetail.id ?? '',
        name: userDetail.name ?? '',
        email: userDetail.email ?? '',
      };

      const {
        refreshToken,
        accessToken,
      } = await this.jwtService.generateRefreshToken(userProfile);
      await this.usersRepository.updateById(userDetail.id, {
        isOnline: true,
        refreshToken,
      });
      return {user: userDetail, accessToken, refreshToken};
    } else {
      throw new HttpErrors.NotFound('User not registered!');
    }
  }

  async verifyOtp(data: {
    email: string;
    phone: string;
    otp: string;
    verificationType: VerificationTypeEnum;
  }) {
    const email = data?.email?.toLowerCase();
    const phone = data?.phone;
    const userOTP = data?.otp;
    const verificationType = data?.verificationType;
    const isActivation = verificationType === VerificationTypeEnum.activation;
    let tokens = {accessToken: '', refreshToken: ''};

    if ((email || phone) && userOTP) {
      const user = await this.usersRepository.findOne({
        where: {
          or: [{email}, {phone}],
          otp: userOTP,
        },
        include: [
          {
            relation: 'subscriptions',
            scope: {
              include: [
                {relation: 'plan'},
                {relation: 'program'},
                {relation: 'payment'},
              ],
            },
          },
        ],
      });

      if (!user) {
        throw new HttpErrors[409]('Invalid code');
      }

      if (user.otp !== userOTP) {
        throw new HttpErrors[409]('Invalid code.');
      }

      if (moment().diff(moment(user.otpExpiry), 'M') > 10) {
        throw new HttpErrors[409]('Code expired.');
      }

      const updates: any = {
        otp: null,
      };

      if (isActivation) {
        const userProfile = {
          [securityId]: user.id ?? '',
          name: user.name ?? '',
          email: user.email ?? '',
        };

        tokens = await this.jwtService.generateRefreshToken(userProfile);
        updates.verificationStatus = 'verified';
        updates.refreshToken = tokens.refreshToken;
        updates.verifiedAt = new Date().toString();
      }

      const message = `Congratulations on joining mDoc CompleteHealth™, ${user.firstName ||
        user.name}!.

You have taken the first step toward a healthier you.

Your journey has officially begun, and mDoc is here to support you every step of the way.
Welcome aboard!`;
      await this.usersRepository.updateById(user.id, updates);
      if (data.verificationType === 'activation') {
        if (data.email) {
          await this.emailservice.sendMail({
            to: data?.email,
            slug: 'member_sign_up',
            message: {
              name: user.firstName || user.name,
            },
          });
        } else if (data.phone) {
          await this.controllerService.sendOtpService(data.phone, message);
        }
      }
      return {
        status: 'success',
        user: isActivation
          ? user
          : {
              id: user?.id,
              firstName: user?.firstName,
              lastName: user?.lastName,
            },
        ...tokens,
      };
    } else {
      throw new HttpErrors.UnprocessableEntity(
        'Request parameters are missing.',
      );
    }
  }

  async changePassword(data: {password: string; id: string}) {
    try {
      const {password, id} = data;
      validatePassword(password);
      const hashedPassword = await this.passwordHasher.hashPassword(password);
      await this.usersRepository.updateById(id, {password: hashedPassword});
      return {
        status: 'success',
      };
    } catch (error) {
      throw new HttpErrors.BadRequest(error);
    }
  }

  async updatePassword(id, {oldPassword, newPassword}) {
    const existing = await this.usersRepository.findById(id);
    const email = existing.email;
    const user = await this.verifyCredentials(
      {email, password: oldPassword},
      false,
    );
    if (user) {
      const _password = await this.passwordHasher.hashPassword(newPassword);
      const md5password = md5(newPassword);
      await this.usersRepository.updateById(id, {
        md5password,
        password: _password,
      });
      return {status: 'success'};
    } else {
      return {status: 'failed'};
    }
  }

  async updateById(id: string, updates: Omit<Users, 'id, email, phone'>) {
    const existingUser = await this.usersRepository.findById(id);
    if (!existingUser) {
      throw new HttpErrors[404]('User does not exist.');
    }
    await this.usersRepository.updateById(id, updates);
    if (updates['height']) {
      const payload = ({
        userId: id,
        value: updates['height'],
        unit: updates['heightUnit'],
        created_at: new Date().toString(),
        modified_at: new Date().toString(),
      } as unknown) as Omit<Height, 'id'>;
      await this.heightService.create(payload);
    }
    if (updates['weight']) {
      const payload = ({
        userId: id,
        value: updates['weight'],
        unit: updates['weightUnit'],
        goal: updates['weightGoal'],
        created_at: new Date().toString(),
        modified_at: new Date().toString(),
      } as unknown) as Omit<Weight, 'id'>;
      await this.weightService.create(payload);
    }
    const user = await this.usersRepository.findById(id, {
      include: [
        {
          relation: 'subscriptions',
          scope: {
            include: [
              {relation: 'plan'},
              {relation: 'program'},
              {relation: 'payment'},
            ],
          },
        },
      ],
    });
    return user;
  }

  async refreshUserToken(
    token: string,
    source: SourceTypeEnum,
  ): Promise<{
    refreshToken: string;
    accessToken: string;
  }> {
    const existingUser = await this.jwtService.verifyRefreshToken(token);
    const user = await this.usersRepository.findById(existingUser?.id);
    if (!user || !user.refreshToken) {
      throw new HttpErrors.NotFound(`User not found`);
    }
    const data = this.jwtService.verifyRefreshToken(user.refreshToken);
    if (!data) {
      throw new HttpErrors.Forbidden('Invalid token');
    }
    const userProfile = {
      email: user?.email,
      [securityId]: user?.id,
      name: user?.lastName,
    };
    const newTokens = await this.jwtService.generateRefreshToken(userProfile);
    await this.loginHistoryRepository.create({
      userId: user.id,
      loginDateTime: moment().toISOString(),
      source: source,
      record_type: LoginHistoryTypeEnum.REFRESH,
    });
    return newTokens;
  }

  async sendUserOTP(mobile?: string, email?: string) {
    const userOtp = common.generateOTP();
    const emailLowercase =  email?.toLowerCase();
    const where = {};
    if (mobile && email) {
      where['or'] = [
        { email: emailLowercase },
        { phone: mobile },
        { phone: `${mobile.slice(1)}`}
      ];
    } else if (email) {
      where['email'] = emailLowercase;
    } else if (mobile) {
      where['or'] = [{phone: mobile}, {phone: `${mobile.slice(1)}`}];
    }

    if (mobile || email) {
      try {
        const user: AnyObject = await this.usersRepository.findOne({where});
        if (!user) {
          return {
            status: 'failed',
            message: 'Invalid credentials provided',
          };
        }

        const otpExpiry = moment()
          .add(10, 'minutes')
          .toISOString();
        await this.usersRepository.updateById(user.id, {
          otp: userOtp,
          otpExpiry,
        });

        if (user.phone) {
          const body = `Your mDoc CompleteHealth one time pin (OTP) is ${userOtp}. It expires in 10 minutes. Don't share this pin with anyone.`;
          await this.controllerService.sendOtpService(user.phone, body);
        }

        if (user.email) {
          const mailOptions: AnyObject = {
            to: user.email,
            slug: 'registration-otp',
            message: {
              otp: userOtp,
            },
          };

          await this.emailservice.sendMail(mailOptions);
        }
        return {
          status: 'success',
        };
      } catch (error) {
        console.error({error});
        return {
          status: 'failed',
        };
      }
    }
    throw new HttpErrors.UnprocessableEntity('Request parameters are missing.');
  }

  async verifyCredentials(
    credentials: Omit<Credentials, 'source'>,
    includeSubscription = false,
  ): Promise<Users> {
    const invalidCredentialsError = 'Invalid email or password.';

    const user = await this.usersRepository.findOne({
      where: {
        or: [
          {phone: `${credentials.email.slice(1)}`}, // to strip the '+' sign
          {phone: credentials.email},
          {email: credentials.email.toLowerCase()},
        ],
      },
      include: includeSubscription
        ? [
            {
              relation: 'subscriptions',
              scope: {
                include: [
                  {relation: 'plan'},
                  {relation: 'program'},
                  {relation: 'payment'},
                  {
                    relation: 'coach',
                    scope: {
                      include: [
                        {
                          relation: 'coach',
                          scope: {fields: {id: true, name: true, image: true}},
                        },
                      ],
                    },
                  },
                ],
              },
            },
          ]
        : [],
    });
    if (!user) {
      throw new HttpErrors[409](invalidCredentialsError);
    }
    const passwordMatched = await this.passwordHasher.comparePassword(
      credentials.password,
      user.password || '',
    );

    if (!passwordMatched && md5(credentials.password) !== user.md5password) {
      throw new HttpErrors.Unauthorized('Password Incorrect');
    }
    return user;
  }

  convertToUserProfile(user: Users): UserProfile {
    return {
      [securityId]: user.id || '',
      lname: user.name || '',
      email: user.email || '',
    };
  }

  async generateReferralCode(user: Users): Promise<string> {
    const randomNumber = Math.floor(Math.random() * 100000 + 1);
    const referralCode = `${user.firstName.toLowerCase()}_${
      user.lastName
    }_${randomNumber}`.toLowerCase();
    const isAvailable = await this.usersRepository.findOne({
      where: {
        referralCode,
      },
    });
    if (isAvailable) {
      const regenerate = await this.generateReferralCode(user);
      return regenerate;
    }
    return referralCode;
  }

  async fetchUserRecentHealthPassport(userId: string) {
    const eyeExamination = await this.eyeExaminationRepository.findOne({
      where: {userId},
      order: ['testDate DESC'],
    });

    const footExamination = await this.footExaminationRepository.findOne({
      where: {userId},
      order: ['testDate DESC'],
    });

    const provider = await this.providerRepository.findOne({
      where: {userId},
      order: ['created DESC'],
    });

    const healthCondition = await this.healthConditionRepository.findOne({
      where: {userId},
      include: [{relation: 'disease'}],
      order: ['diseaseDate DESC'],
    });

    const pharmacy = await this.pharmacyRepository.findOne({
      where: {userId},
      order: ['created DESC'],
    });

    const lab = await this.labsProceduresRepository.findOne({
      where: {userId},
      order: ['date DESC'],
    });

    const medication = await this.medicationPassportRepository.findOne({
      where: {userId},
      include: [{relation: 'medicine'}],
      order: ['startDate DESC'],
    });

    const procedure = await this.procedureSurgeriesRepository.findOne({
      where: {userId},
      include: [{relation: 'procedure'}],
      order: ['treatmentDate DESC'],
    });

    return {
      eyeExamination,
      footExamination,
      pharmacy,
      procedure,
      provider,
      healthCondition,
      lab,
      medication,
    };
  }

  async generalImageUpload(request: Request, response: Response) {
    const maxFileSize =
      this.configOption.maxFileSize.oneMB *
      this.configOption.maxFileSize.quantity;
    const upload = multer({
      storage: multer.memoryStorage(),
      fileFilter: function(req: any, file: any, cb: any) {
        let ext = path.extname(file.originalname);
        cb(null, true);
      },
      limits: {fileSize: maxFileSize},
    });

    return new Promise<string>(async (resolve, reject) => {
      upload.any()(request, response, (err: unknown) => {
        if (err) reject(err);
        else {
          if (!request.files) {
            reject(new Error('No file uploaded'));
          } else {
            let imageFile =
              request.files[0].fieldname === 'image'
                ? request.files[0]
                : request.files[1];
            common
              .configureBucketName(request)
              .then(async (bucketName: string) => {
                this.controllerService
                  .uploadImageHelper([imageFile], bucketName)
                  .then(async (image: string) => {
                    resolve(image);
                  });
              });
          }
        }
      });
    }).catch(err => {
      console.log(err);
      return response.json({message: err});
    });
  }

  async fetchKemPayload(userId: string) {}
}
