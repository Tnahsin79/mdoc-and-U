import multer from 'multer';
import * as _ from 'lodash';
import moment from 'moment';
import * as path from 'path';
import Utils from '../utils';
import {Users} from '../models';
import {UsersService} from './user-service';
import {SourceTypeEnum} from '../type-schema';
import {AnyObject} from '@loopback/repository';
import {Request, Response} from '@loopback/rest';
import {securityId, UserProfile} from '@loopback/security';
import {HeightEnum} from '../utils/health-metrics-functions';
import {LoginHistoryTypeEnum, UserTypeEnum} from '../utils/enums';

export class UserServiceExtention extends UsersService {
  configOption = Utils.getSiteOptions();
  async fetchUserByFilter(
    filter: AnyObject,
    page: number,
    startDate?: string,
    endDate?: string,
  ): Promise<AnyObject> {
    const responseData: Array<AnyObject> = [];
    const pageSize = filter?.limit === 0 ? undefined : filter?.limit || 20;
    const pageNum = page ? page : 1;
    const skip = (pageNum - 1) * pageSize;
    const assignCoachId = filter?.assignCoachId;
    let whereClause;
    let searchString = filter?.searchString;
    if (searchString.includes('+')) {
      searchString = searchString.replace('+', '');
    }
    const orClause = {
      or: [
        {name: new RegExp('.*' + searchString + '.*', 'i')},
        {email: new RegExp('.*' + searchString + '.*', 'i')},
        {phone: new RegExp('.*' + searchString + '.*', 'i')},
      ],
    };

    if (startDate && endDate) {
      const _startDate = moment(startDate)
        .utc()
        .toDate();
      const _endDate = moment(endDate)
        .utc()
        .toDate();
      whereClause['created'] = {between: [_startDate, _endDate]};
    }

    if (startDate && !endDate) {
      const _startDate = moment(startDate)
        .utc()
        .toDate();
      whereClause['created'] = {gte: _startDate};
    }

    if (endDate && !startDate) {
      const _endDate = moment(endDate)
        .utc()
        .toDate();
      whereClause['created'] = {lte: _endDate};
    }

    if (assignCoachId) {
      whereClause = {and: [{assignCoachId}, orClause]};
    } else if (searchString) {
      whereClause = orClause;
    } else {
      whereClause = {};
    }
    const count = await this.usersRepository.count(whereClause);
    const totalPages = Math.ceil(count.count / pageSize);

    const users = await this.usersRepository.find({
      where: whereClause,
      fields: {
        id: true,
        firstName: true,
        lastName: true,
        name: true,
        email: true,
        phone: true,
        image: true,
        locationInfo: true,
        created: true,
        dob: true,
        gender: true,
      },
      order: ['created DESC'],
      skip: skip,
      limit: pageSize,
    });
    // const ids: Array<string> = _.map(users, v => v.id);
    // const coachesId: Array<string> = _.map(users, v => v.assignCoachId);

    // const payments = await this.paymentRepository.find({
    //   where: {
    //     userId: {inq: ids},
    //   },
    // });

    // const coachData = await this.coachRepository.find({
    //   where: {
    //     id: {inq: coachesId},
    //   },
    //   fields: {
    //     id: true,
    //     name: true,
    //     coachTypeId: true,
    //   },
    // });

    // const payment = payments?.length && _.groupBy(payments, v => v.userId);
    // const coach = coachData?.length && _.groupBy(coachData, v => v.id);

    // _.forEach(users, function(val: AnyObject) {
    //   const obj = Object.assign({}, val);
    //   obj.payment = (payment?.[val.id]?.length && payment[val.id][0]) || {};
    //   obj.coach =
    //     (coach?.[val.assignCoachId]?.length && coach[val.assignCoachId][0]) ||
    //     {};
    //   responseData.push(obj);
    // });

    return {
      status: 'Success',
      data: users,
      pageSize,
      totalCount: count.count,
      totalPages: totalPages,
      currentPage: pageNum,
    };
  }

  async getUsersByCoachId(coachId: string): Promise<Users[]> {
    const result = await this.usersRepository.find({
      where: {
        assignCoachId: coachId,
      },
      fields: {
        password: false,
        fcmToken: false,
      },
    });
    return result;
  }

  async generateReferralCode(user: Users): Promise<string> {
    const randomNumber = Math.floor(Math.random() * 100000 + 1);
    const referralCode = `${user.firstName.toLowerCase()}_${
      user.lastName
    }_${randomNumber}`.toLowerCase();
    const isAvailable = await this.usersRepository.findOne({
      where: {
        referralCode,
      },
    });
    if (isAvailable) {
      const regenerate = await this.generateReferralCode(user);
      return regenerate;
    }
    return referralCode;
  }

  async santizeDate(value: string): Promise<string> {
    const date = new Date(value);
    return new Date(
      date.getTime() - date.getTimezoneOffset() * 60000,
    ).toISOString();
    // return date.toISOString(); // for healthDiary migration
  }

  async fixCommunicationLogDate(
    time: string,
    entrydate: string,
  ): Promise<string> {
    if (time.slice(0, 7) === '0 days ') {
      const adjustedTime = time.slice(7);
      const adjustedDate = entrydate.slice(0, 11);
      const newDate = `${adjustedDate} ${adjustedTime}`;
      const date = new Date(newDate);
      return new Date(
        date.getTime() - date.getTimezoneOffset() * 60000,
      ).toISOString();
    }
    if (time.length === 8) {
      const adjustedDate = entrydate.slice(0, 11);
      const newDate = `${adjustedDate} ${time}`;
      const date = new Date(newDate);
      return new Date(
        date.getTime() - date.getTimezoneOffset() * 60000,
      ).toISOString();
    }
    return this.santizeDate(time);
  }

  convertHeight(height, unit) {
    if (unit === 'cm' || unit === 'CM') {
      return {height, unit: HeightEnum.CM};
    }
    if (unit === 'inches') {
      const feet = Math.floor(height / 12);
      const remainingInches = (height % 12) / 12;
      return {
        height: `${(feet + remainingInches).toFixed(5)}`,
        unit: HeightEnum['FT/IN'],
      };
    }
    if (unit === 'meters') {
      return {height: height * 100, unit: HeightEnum.CM};
    }
    if (unit === 'FT/IN' || unit === 'ft/in') {
      return {height, unit: HeightEnum['FT/IN']};
    }
    return {height: null, unit: null};
  }

  formatGlucoseData(
    data,
    mealType = '',
  ): {
    mealType: string;
    beforeMeal: string;
    afterMeal: string;
  } {
    const {
      breakfast = {},
      lunch = {},
      dinner = {},
      snacks = {},
      randomBloodSugar = {},
      random = {},
      fastingBloodGlucose = {},
      fasting = {},
      bloodSugarValue = {},
    } = data;
    if (
      Number(bloodSugarValue.afterMeal) ||
      Number(bloodSugarValue.beforeMeal)
    ) {
      return {
        mealType: mealType || 'random',
        beforeMeal: bloodSugarValue.beforeMeal,
        afterMeal: bloodSugarValue.afterMeal,
      };
    }
    if (Number(breakfast.after) || Number(breakfast.before)) {
      return {
        mealType: 'breakfast',
        beforeMeal: breakfast.before,
        afterMeal: breakfast.after,
      };
    }
    if (Number(lunch.after) || Number(lunch.before)) {
      return {
        mealType: 'lunch',
        beforeMeal: lunch.before,
        afterMeal: lunch.after,
      };
    }
    if (Number(dinner.after) || Number(dinner.before)) {
      return {
        mealType: 'dinner',
        beforeMeal: dinner.before,
        afterMeal: dinner.after,
      };
    }
    if (Number(snacks.after) || Number(snacks.before)) {
      return {
        mealType: 'snack',
        beforeMeal: snacks.before,
        afterMeal: snacks.after,
      };
    }
    if (
      Number(random?.after) ||
      Number(random?.before) ||
      Number(randomBloodSugar?.after) ||
      Number(randomBloodSugar?.before)
    ) {
      return {
        mealType: 'random',
        beforeMeal: Number(random.before)
          ? random.before
          : randomBloodSugar.before,
        afterMeal: Number(random.after) ? random.after : randomBloodSugar.after,
      };
    }
    if (
      Number(fasting?.after) ||
      Number(fasting?.before) ||
      Number(fastingBloodGlucose?.after) ||
      Number(fastingBloodGlucose?.before)
    ) {
      return {
        mealType: 'fasting',
        beforeMeal: Number(fasting.before)
          ? fasting.before
          : fastingBloodGlucose.before,
        afterMeal: Number(fasting.after)
          ? fasting.after
          : fastingBloodGlucose.after,
      };
    }
    return {
      mealType: '',
      beforeMeal: '',
      afterMeal: '',
    };
  }

  async uploadProfilePicture(
    req: Request,
    res: Response,
    currentUser: UserProfile,
  ) {
    const maxFileSize =
      this.configOption.maxFileSize.oneMB *
      this.configOption.maxFileSize.quantity;

    const upload = multer({
      // storage: storage,
      storage: multer.memoryStorage(),
      fileFilter: function(req: any, file: any, cb: any) {
        let ext = path.extname(file.originalname);
        // if (_.indexOf(allowedFileType, ext) === -1) {
        //   return cb(new HttpErrors.UnprocessableEntity('File not Allowed!'), false)
        // }
        cb(null, true);
      },
      limits: {fileSize: maxFileSize},
    });
    return new Promise<object>(async (resolve, reject) => {
      upload.any()(req, res, (err: unknown) => {
        if (err) reject(err);
        else {
          this.controllerService
            .uploadImageHelper(req.files, 'mdoc_userprofile')
            .then(res => {
              if (res) {
                this.usersRepository.updateById(currentUser[securityId], {
                  image: ((res as unknown) as string) || '',
                });
                resolve({
                  files: res,
                  fields: (req as any).fields,
                });
              }
            })
            .catch(err => {
              console.log(err);
              return err;
            });
        }
      });
    });
  }

  async logout(
    currentUser: UserProfile,
    credentials: {source: SourceTypeEnum; browserAgent?: string},
  ) {
    const logOut = await this.usersRepository.updateById(
      currentUser[securityId],
      {refreshToken: null},
    );
    await this.loginHistoryRepository.create({
      source: credentials.source,
      userType: UserTypeEnum.USER,
      userId: currentUser[securityId],
      browserAgent: credentials.browserAgent,
      loginDateTime: moment().toISOString(),
      record_type: LoginHistoryTypeEnum.LOGOUT,
    });
    return logOut;
  }
}
