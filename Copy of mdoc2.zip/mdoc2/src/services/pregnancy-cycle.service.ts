import {PaginatedResponse} from '../type-schema';
import {BindingScope, bind} from '@loopback/context';
import {Filter, repository} from '@loopback/repository';
import {PregnancyCycleRepository} from '../repositories';
import {PregnancyCycle, PregnancyCycleWithRelations} from '../models';

@bind({scope: BindingScope.CONTEXT})
export class PregnancyCycleService {
  constructor(
    @repository(PregnancyCycleRepository)
    public pregnancyCycleRepository: PregnancyCycleRepository,
  ) {}

  async create(payload: Omit<PregnancyCycle, 'id'>): Promise<PregnancyCycle> {
    return await this.pregnancyCycleRepository.create(payload);
  }

  async findAll(
    filter: Filter<PregnancyCycle>,
    page: number,
  ): Promise<PaginatedResponse<PregnancyCycleWithRelations>> {
    const limit = filter?.limit ? filter?.limit : 25;
    const pageNum = page ? page : 1;
    const skip = (pageNum - 1) * limit;
    const content = await this.pregnancyCycleRepository.find({
      where: filter?.where,
      include: [
        {
          relation: 'user',
          scope: {
            fields: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              phoneNo: true,
            },
          },
        },
        {
          relation: 'pregnancyLogs',
        },
      ],
      order: ['created_at DESC'],
      skip,
      limit,
    });
    const count = await this.pregnancyCycleRepository.count();
    const totalPages = Math.ceil(count.count / limit);
    return {
      data: content,
      count: count.count,
      totalPages,
      currentPage: page,
      status: 'success',
    };
  }

  async findById(id: string, filter: Filter<PregnancyCycle>) {
    const data = this.pregnancyCycleRepository.findById(id, {
      where: filter?.where,
      include: [
        {
          relation: 'user',
          scope: {
            fields: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              phoneNo: true,
            },
          },
        },
        {
          relation: 'pregnancyLogs',
        },
      ],
    });
    return data;
  }

  async updateById(id: string, pregnancyCycle: PregnancyCycle): Promise<void> {
    const data = await this.pregnancyCycleRepository.updateById(
      id,
      pregnancyCycle,
    );
    return data;
  }

  async deleteById(id: string): Promise<void> {
    return await this.pregnancyCycleRepository.deleteById(id);
  }
}
