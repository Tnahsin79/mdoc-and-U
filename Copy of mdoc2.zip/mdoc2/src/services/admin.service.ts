import {
  AdminRepository,
  AdminRoleRepository,
  LoginHistoryRepository,
} from '../repositories';
import moment from 'moment';
import {JWTService} from './jwt-service';
import {HttpErrors} from '@loopback/rest';
import {EmailService} from './email.service';
import {SourceTypeEnum} from '../type-schema';
import {repository} from '@loopback/repository';
import {BindingScope, inject, bind} from '@loopback/core';
import {securityId, UserProfile} from '@loopback/security';
import {UserTypeEnum, LoginHistoryTypeEnum} from '../utils/enums';
import {EmailServiceBindings, TokenServiceBindings} from '../keys';

@bind({scope: BindingScope.TRANSIENT})
export class AdminService {
  constructor(
    @repository(AdminRepository)
    public adminRepository: AdminRepository,
    @inject(EmailServiceBindings.MAIL_SERVICE)
    public emailService: EmailService,
    @inject(TokenServiceBindings.TOKEN_SERVICE)
    public tokenService: JWTService,
    @repository(AdminRoleRepository)
    public adminRoleRepository: AdminRoleRepository,
    @repository(LoginHistoryRepository)
    public loginHistoryRepository: LoginHistoryRepository,
  ) {}

  async refreshAdminToken(
    token: string,
  ): Promise<{
    refreshToken: string;
    accessToken: string;
  }> {
    const user = await this.tokenService.verifyRefreshToken(token);
    const admin = await this.adminRepository.findById(user?.id);
    if (!admin || !admin.refreshToken) {
      throw new HttpErrors.NotFound(`User not found`);
    }
    const data = this.tokenService.verifyRefreshToken(admin.refreshToken);
    if (!data) {
      throw new HttpErrors.Forbidden('Invalid token');
    }
    const userProfile = {
      email: admin?.email,
      [securityId]: admin?.id,
      name: admin?.name,
    };
    return await this.tokenService.generateRefreshToken(userProfile);
  }

  async findAll(filter?: any) {
    const {count} = await this.adminRepository.count();
    const admins = await this.adminRepository.find({
      where: filter?.where,
      fields: {password: false},
      include: [
        {
          relation: 'roles',
          scope: {
            include: [{relation: 'role'}],
          },
        },
      ],
      order: ['name ASC'],
    });
    return {admins, count};
  }

  async assignRoles(adminId: string, roleIds: string[]) {
    await this.adminRoleRepository.deleteAll({adminId});
    const payload = roleIds.map(item => ({
      adminId,
      roleId: item,
      updatedAt: new Date(),
    }));
    await this.adminRoleRepository.createAll(payload);
  }

  generateOTP(): string {
    const digits = '0123456789';
    let OTP = '';
    for (let i = 0; i < 6; i++) {
      OTP += digits[Math.floor(Math.random() * 10)];
    }
    return OTP;
  }

  async sendEmail(to: string, OTP: string): Promise<object> {
    const data = {
      to,
      slug: 'forgot-password-otp',
      message: {
        frontendUrl: process.env.ADMIN_FRONTEND_URL,
        token: OTP,
      },
    };
    return await this.emailService.sendMail(data);
  }

  async logout(
    currentUser: UserProfile,
    credentials: {source: SourceTypeEnum; browserAgent?: string},
  ) {
    const logOut = await this.adminRepository.updateById(
      currentUser[securityId],
      {refreshToken: null},
    );
    await this.loginHistoryRepository.create({
      source: credentials.source,
      userType: UserTypeEnum.ADMIN,
      adminId: currentUser[securityId],
      loginDateTime: moment().toISOString(),
      browserAgent: credentials.browserAgent,
      record_type: LoginHistoryTypeEnum.LOGOUT,
    });
    return logOut;
  }
}
