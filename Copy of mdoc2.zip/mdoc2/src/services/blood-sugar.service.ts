import {
  BloodSugarRepository,
  ActivityTimelineRepository,
} from '../repositories';
import {HttpErrors} from '@loopback/rest';
import {
  returnValues,
  convertBloodGlucose,
  userPreferredBloodGlucose,
} from '../utils/health-metrics-functions';
import {OutlierServiceBindings} from '../keys';
import {OutlierService} from './outlier.service';
import {HealthMetricsTypeEnum} from '../utils/enums';
import {Filter, repository} from '@loopback/repository';
import {BindingScope, bind, inject} from '@loopback/context';
import {BloodSugar, BloodSugarWithRelations} from '../models';
import {PaginatedResponse, activityTypeObj} from '../type-schema';

@bind({scope: BindingScope.CONTEXT})
export class BloodSugarService {
  constructor(
    @inject(OutlierServiceBindings.OUTLIER_SERVICE)
    public outlierService: OutlierService,
    @repository(BloodSugarRepository)
    public bloodSugarRepository: BloodSugarRepository,
    @repository(ActivityTimelineRepository)
    public activityTimelineRepository: ActivityTimelineRepository,
  ) {}

  async create(payload: Omit<BloodSugar, 'id'>): Promise<BloodSugar> {
    let defaultAfterMeal = Number(payload.afterMeal);
    let defaultBeforeMeal = Number(payload.beforeMeal);
    if (payload.unit != 'mmol/L') {
      defaultAfterMeal = convertBloodGlucose(Number(payload.afterMeal));
      defaultBeforeMeal = convertBloodGlucose(Number(payload.beforeMeal));
    }
    if (
      payload.mealType !== 'fasting' &&
      payload.mealType !== 'random' &&
      (Number(defaultBeforeMeal) < 2.8 || Number(defaultBeforeMeal) > 19.4)
    ) {
      throw new HttpErrors[409]('Please provide a valid value');
    }
    if (
      payload.mealType !== 'fasting' &&
      payload.mealType !== 'random' &&
      (Number(defaultAfterMeal) < 2.8 || Number(defaultAfterMeal) > 19.4)
    ) {
      throw new HttpErrors[409]('Please provide a valid value');
    }

    if (
      payload.mealType === 'fasting' &&
      (Number(defaultBeforeMeal) < 2.8 || Number(defaultBeforeMeal) > 19.4)
    ) {
      throw new HttpErrors[409]('Please provide a valid value');
    }

    if (
      payload.mealType === 'random' &&
      (Number(defaultAfterMeal) < 2.8 || Number(defaultAfterMeal) > 19.4)
    ) {
      throw new HttpErrors[409]('Please provide a valid value');
    }
    const data = await this.bloodSugarRepository.create({
      ...payload,
      defaultAfterMeal,
      defaultBeforeMeal,
      defaultUnit: 'mmol/L',
    });
    await this.activityTimelineRepository.create({
      activityType: activityTypeObj.BLOOD_SUGAR,
      userId: data.userId,
      metadata: data.id,
    });
    try {
      const minMaxValue = returnValues(
        HealthMetricsTypeEnum.Blood_Glucose,
        data.unit,
      );
      const key = data.beforeMeal ? 'beforeMeal' : 'afterMeal';
      if (
        parseInt(data[key]) <= minMaxValue.random.minCritical ||
        parseInt(data[key]) >= minMaxValue.random.maxCritical ||
        (data.mealType === 'fasting' &&
          (parseInt(data.afterMeal) <= minMaxValue.fasting.minCritical ||
            parseInt(data.afterMeal) >= minMaxValue.fasting.maxCritical))
      ) {
        const outlier = {
          userId: payload.userId,
          metricType: HealthMetricsTypeEnum.Blood_Glucose,
          metricId: data.id,
          metricValue: `mealType: ${data.mealType}, beforeMeal: ${data.beforeMeal}${data.unit}, afterMeal: ${data.afterMeal}${data.unit}`,
        };
        await this.outlierService.create(outlier);
      }
    } catch (error) {}
    return data;
  }

  async findAll(
    filter: Filter<BloodSugar>,
    page: number,
  ): Promise<PaginatedResponse<BloodSugarWithRelations>> {
    const limit = filter?.limit ? filter?.limit : 25;
    const pageNum = page ? page : 1;
    const skip = (pageNum - 1) * limit;
    const content = await this.bloodSugarRepository.find({
      where: filter?.where,
      include: [
        {
          relation: 'coach',
          scope: {
            fields: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              phone: true,
            },
          },
        },
        {
          relation: 'user',
          scope: {
            fields: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              phone: true,
              bGlucoseUnit: true,
            },
          },
        },
      ],
      order: ['created_at DESC'],
      skip,
      limit,
    });
    const count = await this.bloodSugarRepository.count(filter?.where);
    const totalPages = Math.ceil(count.count / limit);

    content.map(bloodGlucose => {
      const beforeMealResponse = userPreferredBloodGlucose(
        bloodGlucose.beforeMeal,
        bloodGlucose.unit,
        bloodGlucose.user.bGlucoseUnit,
      );
      bloodGlucose.beforeMeal = beforeMealResponse.requiredValue;
      bloodGlucose.unit = beforeMealResponse.requiredUnit;
      const afterMealResponse = userPreferredBloodGlucose(
        bloodGlucose.afterMeal,
        bloodGlucose.unit,
        bloodGlucose.user.bGlucoseUnit,
      );
      bloodGlucose.afterMeal = afterMealResponse.requiredValue;
      bloodGlucose.unit = afterMealResponse.requiredUnit;
    });

    return {
      data: content,
      count: count.count,
      totalPages,
      currentPage: page,
      status: 'success',
    };
  }

  async findById(id: string, filter: Filter<BloodSugar>) {
    const data = this.bloodSugarRepository.findById(id, {
      where: filter?.where,
      include: [
        {
          relation: 'coach',
          scope: {
            fields: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              phone: true,
            },
          },
        },
        {
          relation: 'user',
          scope: {
            fields: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              phone: true,
            },
          },
        },
      ],
    });
    return data;
  }

  async updateById(id: string, bloodSugar: BloodSugar): Promise<void> {
    if (bloodSugar.afterMeal || bloodSugar.beforeMeal) {
      bloodSugar.defaultAfterMeal = Number(bloodSugar.afterMeal);
      bloodSugar.defaultBeforeMeal = Number(bloodSugar.beforeMeal);
      if (bloodSugar.unit != 'mmol/L')
        bloodSugar.defaultAfterMeal = convertBloodGlucose(
          Number(bloodSugar?.afterMeal),
        );
      bloodSugar.defaultBeforeMeal = convertBloodGlucose(
        Number(bloodSugar?.beforeMeal),
      );
    }
    return await this.bloodSugarRepository.updateById(id, bloodSugar);
  }

  async deleteById(id: string): Promise<void> {
    return await this.bloodSugarRepository.deleteById(id);
  }
}
