import { bind, BindingScope, inject } from '@loopback/core';
import { repository, AnyObject } from '@loopback/repository';
import { BloodPressureRepository, BloodSugarRepository, BmiRepository, CholestrolRepository, CoachRepository, CommunicationLogRepository, DiseaseRepository, ExerciseRepository, ExerciseTypesRepository, EyeExaminationRepository, FootExaminationRepository, HbaicRepository, HealthConditionRepository, HealthProcedureSurgeriesRepository, MedicationPassportRepository, MedicationRepository, NoteRepository, PharmacyRepository, ProcedureListRepository, ProviderRepository, PsaRepository, UsersRepository, WaistCircumferenceRepository, WeightGoalRepository, WeightRepository, ActionPlanRepository, LifestyleDiaryRepository, HeightRepository, HealthDiaryRepository } from '../repositories';
import * as _ from 'lodash';
import {
  UserServiceExtensionBindings,
  PasswordHasherBindings,
} from '../keys';
import { PasswordHasher } from './hash.password.bcryptjs';
import {UserServiceExtention} from '../services/usersServiceExtended';
import { footOrCentimeterToMeter, HeightEnum, poundsToKilograms } from '../utils/health-metrics-functions';

const baseUrl = 'https://www.mymdoc.com/data/images/'

@bind({ scope: BindingScope.TRANSIENT })
export class MigrationServiceV2 {
  constructor(
    @inject(UserServiceExtensionBindings.USER_SERVICE_EXT)
    public userServiceExt: UserServiceExtention,
    @inject(PasswordHasherBindings.PASSWORD_HASHER)
    public passwordHasher: PasswordHasher,
    @repository(UsersRepository) public usersRepository: UsersRepository,
    @repository(WeightRepository) public weightRepository: WeightRepository,
    @repository(ActionPlanRepository) public actionPlanRepository: ActionPlanRepository,
    @repository(LifestyleDiaryRepository) public lifestyleDiaryRepository: LifestyleDiaryRepository,
    @repository(WaistCircumferenceRepository) public waistCircumferenceRepository: WaistCircumferenceRepository,
    @repository(PsaRepository) public psaRepository: PsaRepository,
    @repository(ProviderRepository) public providerRepository: ProviderRepository,
    @repository(PharmacyRepository) public pharmacyRepository: PharmacyRepository,
    @repository(NoteRepository) public noteRepository: NoteRepository,
    @repository(MedicationRepository) public medicationRepository: MedicationRepository,
    @repository(MedicationPassportRepository) public medicationPassportRepository: MedicationPassportRepository,
    @repository(BloodPressureRepository) public bloodPressureRepository: BloodPressureRepository,
    @repository(BloodSugarRepository) public bloodSugarRepository: BloodSugarRepository,
    @repository(CholestrolRepository) public cholesterolRepository: CholestrolRepository,
    @repository(ExerciseTypesRepository) public exerciseTypesRepository: ExerciseTypesRepository,
    @repository(ExerciseRepository) public exerciseRepository: ExerciseRepository,
    @repository(ProcedureListRepository) public procedureListRepository: ProcedureListRepository,
    @repository(BmiRepository) public bmiRepository: BmiRepository,
    @repository(EyeExaminationRepository) public eyeExaminationRepository: EyeExaminationRepository,
    @repository(FootExaminationRepository) public footExaminationRepository: FootExaminationRepository,
    @repository(HbaicRepository) public hbaicRepository: HbaicRepository,
    @repository(HealthProcedureSurgeriesRepository) public healthProcedureSurgeriesRepository: HealthProcedureSurgeriesRepository,
    @repository(DiseaseRepository) public diseaseRepository: DiseaseRepository,
    @repository(HealthConditionRepository) public healthConditionRepository: HealthConditionRepository,
    @repository(WeightGoalRepository) public weightGoalRepository: WeightGoalRepository,
    @repository(CommunicationLogRepository) public communicationLogRepository: CommunicationLogRepository,
    @repository(CoachRepository) public coachRepository: CoachRepository,
    @repository(HeightRepository) public heightRepository: HeightRepository,
    @repository(HealthDiaryRepository) public healthDiaryRepository: HealthDiaryRepository,
  ) { }

  async fetchCoachIdByProviderId(coachId: number | null): Promise<string> {
    let newCoachId = Number(coachId);
  
    if ([164805, 541881].includes(newCoachId)) {
      newCoachId = 504
    }

    const coachExist = await this.coachRepository.findOne({
      where: { 
        coachId: newCoachId
      }
    });

    if (coachExist?.id) {
      return coachExist.id
    }

    return ''
  }

  async userMigration(user: AnyObject): Promise<AnyObject> {
    const payload: AnyObject = {
      providerId: user.providerId,
      name: user?.name || "",
      firstName: user?.firstName || "",
      lastName: user?.lastName || "",
      image: baseUrl + user.image,
      phone: user?.phone,
      email: user?.email || "",
      md5password: user.md5password || "",
      gender: user?.gender || "",
      isProfileComplete: true,
      contactInfo: {
        homePhone: user?.cellPhone || "",
        workPhone: user?.workPhone || "",
        homePhoneCode: "",
        workPhoneCode: ""
      },
      locationInfo: {
        country: user?.country || "",
        state: user?.state || "",
        city: user?.city || "",
        address: user?.address || "",
        zipCode: user?.zipcode || ""
      },
      emergencyInfo: {
        name: user?.EmergencyContactName || "",
        phone: user?.EmergencyContactPhone || "",
        email: user?.EmergencyContactEmail || "",
        relationship: user?.EmergencyContactRelationship || ""
      },
      height: null,
      status: user?.status || "",
      isDeleted: user?.isDeleted ===   '0' ? false : true,
      referralCode: user?.referralCode || "",
      verificationStatus: "verified",
      created: await this.userServiceExt.santizeDate(user.created),
    }

    if (user?.dob) {
      payload.dob = await this.userServiceExt.santizeDate(user.dob);
    }

    const accountExist = await this.usersRepository.findOne({
      where: {
        and: [
          { email: user.email ?? undefined },
          { phone: user.phone ?? undefined },
        ]
      } 
    });
    if (accountExist?.id) {
      await this.usersRepository.updateById(accountExist.id, { 
        providerId: payload.providerId,
        referralCode: payload.referralCode
      })
      if (user?.height) {
        await this.userHeightMissingMigration({
          providerId: payload.providerId,
          height: user.height
        })
      }
      return {
        status: 'accountExist',
        providerId: payload?.providerId
      };
    }
    
    const providerIdExist = await this.usersRepository.findOne({ where: { providerId: payload.providerId } })

    if (!providerIdExist?.id) {
      await this.usersRepository.create(payload)
      if (user?.height) {
        await this.userHeightMissingMigration({
          providerId: payload.providerId,
          height: user.height
        })
      }
      return {
        status: 'create',
        providerId: payload?.providerId
      };
    }

    if (user?.height) {
      await this.userHeightMissingMigration({
        providerId: payload.providerId,
        height: user.height
      })
    }
    return {
      status: 'providerIdExist',
      providerId: payload?.providerId
    };
  }

  async userHeightMigration() {
    const stats = {
      hasHeight: [],
      noHeight: [],
      fails: []
    }

    const accounts = await this.usersRepository.find({
      where: {
        height: { neq: null }
      },
      order: ['id ASC'],
    });

    // eslint-disable-next-line @typescript-eslint/no-misused-promises
    accounts.forEach(async (account) => {
      let heightUnit = `` + account.heightUnit;
      console.log(account.height, account.heightUnit, heightUnit)
      if (!heightUnit || heightUnit === undefined || heightUnit === 'undefined' || heightUnit === null || heightUnit === 'null') {
        if (account.height >= 1 && account.height <= 2.5) {
          heightUnit = "meters"
        } else if (account.height >= 4 && account.height <=  8) {
          heightUnit = "ft/in"
        } else if (account.height >= 59 && account.height <=  80) {
          heightUnit = "inches"
        } else if (account.height > 100 && account.height <=  500) {
          heightUnit = "CM"
        } else {
          await this.usersRepository.updateById(account.id, { height: null });
          console.log('terminate', account.id)
          return;
        }
      }
      console.log(account.height, heightUnit)
      if (account.height && heightUnit) {
        const { height, unit } = this.userServiceExt.convertHeight(account.height, heightUnit);
        console.log(height, unit)
        if (height && unit) {
          const heightExist = await this.heightRepository.findOne({
            where: { 
              userId: account.id, 
              value: height,
              unit
            }
          });
          console.log(heightExist);
          console.log("++++++++++++++++++++++++++++++++++++++++++++")

          if (!heightExist) {
            const defaultValue = footOrCentimeterToMeter(height, unit);
            await this.heightRepository.create({
              defaultValue,
              unit,
              userId: account.id,
              value: height,
              channel: "web",
              defaultUnit: 'M',
            });
          }
          await this.usersRepository.updateById(account.id, { height: null });
          console.log('updated', account.id)
          stats.hasHeight.push(account.id)
        } else {
          console.log('no height & unit', account.id)
          stats.fails.push(account.id)
        }
      } else {
        await this.usersRepository.updateById(account.id, { height: null });
        console.log('no height', account.id)
        stats.noHeight.push(account.id)
      }
    });

    return {
      stats,
      statsCount: {
        noHeightCount: stats.noHeight.length, 
        heightCount: stats.hasHeight.length, 
        fails: stats.fails.length
      },
      count: accounts.length
    }
  }
  async userHeightMissingMigration(payload) {
    const {
      providerId,
      height // value is in meters
    } = payload;

    const heightInCM = height * 100; // convert meters to CM

    const account = await this.usersRepository.findOne({
      where: {
        providerId
      },
    });

    if (!account) {
      return {
        status: 'USER_NOT_EXIST',
        providerId
      };
    }

    const userHeightExist = await this.heightRepository.findOne({
      where: {
        userId: account.id,
        value: heightInCM,
        unit: HeightEnum.CM
      }
    });

    if (!userHeightExist) {
      // create the height for the user
      await this.heightRepository.create({
        defaultValue: height, // height in meters 
        unit: HeightEnum.CM,
        userId: account.id,
        value: heightInCM, // height in cm
        channel: "web",
        defaultUnit: 'M',
      });

      return {
        status: 'CREATE',
        providerId: account.id
      };
    }

    return {
      status: 'METRIC_EXIST',
      providerId: account.id,
    };
  }

  async usersWeightMigration(weight: AnyObject): Promise<AnyObject> {
    const payload: AnyObject = {
      userId: weight?.userId,
      coachId: weight?.coachId && parseInt(weight?.coachId) !== parseInt(weight.userId) ? weight?.coachId : '',
      value: weight?.value,
      defaultValue: weight?.value,
      goal: weight?.goal,
      logDate: weight?.logDate && await this.userServiceExt.santizeDate(weight.logDate),
      unit: weight?.unit,
      channel: weight?.channel,
      'created_at': weight?.created_at && await this.userServiceExt.santizeDate(weight.created_at),
      'modified_at': weight?.created_at && await this.userServiceExt.santizeDate(weight.created_at),
    }

    // get the userId if exist
    const userExist = await this.usersRepository.findOne({
      where: {
        or: [
          { providerId: weight.userId },
          { id: weight.userId }
        ]
      } 
    });

    if (userExist?.id) {
      payload.userId = userExist.id
      payload.coachId = payload.coachId && await this.fetchCoachIdByProviderId(payload.coachId)
      // check if current weight exist on DB
      const checkWeightLog = await this.weightRepository.findOne({ 
        where: {
          and: [
            { userId: userExist?.id },
            { value: payload?.value },
            { logDate: payload.logDate },
            { unit: payload.unit },
            { 'created_at': payload.created_at },
          ]
        }
      });

      if (!checkWeightLog?.id) { // create weight if doesn't exist
        await this.weightRepository.create(payload)
        return {
          status: 'CREATE',
          providerId: payload?.userId
        };
      }

      return {
        status: 'METRIC_EXIST',
        providerId: checkWeightLog?.id
      };
    }

    return {
      status: 'USER_NOT_EXIST',
      providerId: payload?.userId
    };
  }

  async userWaistCircumferenceMigration(waist: AnyObject): Promise<AnyObject> {
    const payload: AnyObject = {
      userId: waist?.userId,
      coachId: waist?.coachId && parseInt(waist?.coachId) !== parseInt(waist.userId) ? waist?.coachId : '',
      currentWaist: waist?.currentWaist,
      defaultValue: waist?.currentWaist,
      logDate: waist?.logDate && await this.userServiceExt.santizeDate(waist.logDate),
      waistGoal: waist?.waistGoal || 0,
      unit: waist?.unit || "CM",
      channel: waist?.channel || "web",
      'created_at': waist?.created_at && await this.userServiceExt.santizeDate(waist.created_at),
      'modified_at': waist?.modified_at && await this.userServiceExt.santizeDate(waist.modified_at),
    }

    // get the userId if exist
    const userExist = await this.usersRepository.findOne({
      where: {
        or: [
          { providerId: payload.userId },
          { id: payload.userId }
        ]
      } 
    });

    if (userExist?.id) {
      payload.userId = userExist.id
      payload.coachId = payload.coachId && await this.fetchCoachIdByProviderId(payload.coachId)
      // check if current user waist circumference exist on DB
      const checkWaistCircumferenceLog = await this.waistCircumferenceRepository.findOne({ 
        where: {
          and: [
            { userId: userExist?.id },
            { currentWaist: payload?.currentWaist },
            { logDate: payload.logDate },
            { unit: payload.unit },
            { 'created_at': payload.created_at },
          ]
        }
      });

      if (!checkWaistCircumferenceLog?.id) { // create waist circumference if doesn't exist
        await this.waistCircumferenceRepository.create(payload)
        return {
          status: 'CREATE',
          providerId: payload?.userId
        };
      }

      return {
        status: 'METRIC_EXIST',
        providerId: checkWaistCircumferenceLog?.id
      };
    }

    return {
      status: 'USER_NOT_EXIST',
      providerId: payload?.userId
    };
  }

  async userPSAMigration(psa: AnyObject): Promise<AnyObject> {
    const payload: AnyObject = {
      userId: psa?.userId,
      coachId: psa?.coachId && parseInt(psa?.coachId) !== parseInt(psa.userId) ? psa?.coachId : '',
      logDate: psa?.logDate && await this.userServiceExt.santizeDate(psa.logDate),
      totalPsa: psa?.totalPsa && `${psa.totalPsa} ng/mL`,
      freePsa: psa?.freePsa ? `${psa.freePsa} ng/mL` : '0 ng/mL',
      fileName: psa?.fileName || '',
      'created_at': psa?.created && await this.userServiceExt.santizeDate(psa.created),
      'modified_at': psa?.modified && await this.userServiceExt.santizeDate(psa.modified),
    }
    
    // get the userId if exist
    const userExist = await this.usersRepository.findOne({
      where: {
        or: [
          { providerId: psa.userId },
          { id: psa.userId }
        ]
      } 
    });

    if (userExist?.id) {
      payload.userId = userExist.id
      payload.coachId = payload.coachId && await this.fetchCoachIdByProviderId(payload.coachId)
      // check if current user waist circumference exist on DB
      const checkPSALog = await this.psaRepository.findOne({ 
        where: {
          and: [
            { userId: userExist?.id },
            { logDate: payload.logDate },
            { totalPsa: payload?.totalPsa },
            { fileName: payload.fileName },
            { 'created_at': payload.created_at },
          ]
        }
      });

      if (!checkPSALog?.id) { // create weight if doesn't exist
        await this.psaRepository.create(payload)
        return {
          status: 'CREATE',
          providerId: payload?.userId
        };
      }

      checkPSALog.coachId = payload.coachId
      checkPSALog.created_at = payload.created_at
      checkPSALog.modified_at = payload.modified_at
      await this.psaRepository.updateById(checkPSALog.id, checkPSALog);
      return {
        status: 'METRIC_EXIST',
        providerId: checkPSALog?.id
      };
    }
    
    return {
      status: 'USER_NOT_EXIST',
      providerId: payload?.userId
    };
  }

  async userProviderMigration(provider: AnyObject): Promise<AnyObject> {
    const payload: AnyObject = {
      userId: provider?.userId,
      coachId: provider?.coachId && parseInt(provider?.coachId) !== parseInt(provider.userId) ? provider?.coachId : '',
      name: provider?.name || '',
      hospitalName: provider?.hospitalName || '',
      address: provider?.address || '',
      isProviderComplete: provider?.isProviderComplete && provider.isProviderComplete === 'True' ? true : false,
      created: provider?.created && await this.userServiceExt.santizeDate(provider.created),
      modified: provider?.modified && await this.userServiceExt.santizeDate(provider.modified),
    }
    
    // get the userId if exist
    const userExist = await this.usersRepository.findOne({ where: { providerId: provider.userId } });

    if (userExist?.id) {
      payload.userId = userExist.id
      payload.coachId = payload.coachId && await this.fetchCoachIdByProviderId(payload.coachId)
      // check if current user waist circumference exist on DB
      const checkUserProviderLog = await this.providerRepository.findOne({ 
        where: {
          and: [
            { userId: userExist?.id },
            { name: payload.name },
            { hospitalName: payload?.hospitalName },
            { address: payload?.address },
            { created: payload.created },
          ]
        }
      });

      if (!checkUserProviderLog?.id) {
        await this.providerRepository.create(payload)
        return {
          status: 'CREATE',
          providerId: payload?.userId
        };
      }

      return {
        status: 'METRIC_EXIST',
        providerId: checkUserProviderLog?.id
      };
    }

    return {
      status: 'USER_NOT_EXIST',
      providerId: payload?.userId
    };
  }

  async userPharmacyMigration(pharmacy: AnyObject): Promise<AnyObject> {
    const payload: AnyObject = {
      userId: pharmacy?.userId,
      coachId: pharmacy?.coachId && parseInt(pharmacy?.coachId) !== parseInt(pharmacy.userId) ? pharmacy?.coachId : '',
      name: pharmacy?.name || '',
      address: pharmacy?.address || '',
      isPharmacyComplete: true,
      created: pharmacy?.created && await this.userServiceExt.santizeDate(pharmacy.created),
      modified: pharmacy?.modified && await this.userServiceExt.santizeDate(pharmacy.modified),
    }
    
    // get the userId if exist
    const userExist = await this.usersRepository.findOne({ where: { providerId: pharmacy.userId } });

    if (userExist?.id) {
      payload.userId = userExist.id
      payload.coachId = payload.coachId && await this.fetchCoachIdByProviderId(payload.coachId)
      // check if current user waist circumference exist on DB
      const checkUserPharamcyLog = await this.pharmacyRepository.findOne({ 
        where: {
          and: [
            { userId: userExist?.id },
            { name: payload.name },
            { address: payload?.address },
            { created: payload.created },
          ]
        }
      });

      if (!checkUserPharamcyLog?.id) {
        await this.pharmacyRepository.create(payload)
        return {
          status: 'CREATE',
          providerId: payload?.userId
        };
      }

      return {
        status: 'METRIC_EXIST',
        providerId: checkUserPharamcyLog?.id
      };
    }

    return {
      status: 'USER_NOT_EXIST',
      providerId: payload?.userId
    };
  }

  async usersNotesMigration(note: AnyObject): Promise<AnyObject> {
    const payload: AnyObject = {
      userId: note?.userId,
      coachId: note?.coachId && parseInt(note?.coachId) !== parseInt(note.userId) ? note?.coachId : '',
      summary: note?.summary || '',
      title: note?.title || '',
      signsAndSymptoms: note?.signsandSymptoms || '',
      allergies: note?.allergies || '',
      medications: note?.medications || '',
      pastMedicalHistory: note?.pastMedicationHistory || true,
      lastMeal: note?.lastMeal || '',
      emergencyEvents: note?.emergencyEvents || '',
      levelOfConsciousness: note?.levelOfConsciousness || '',
      breathing: note?.breathing || '',
      circulation: note?.circulation || '',
      skin: note?.skin || '',
      headToToe: note?.headToToe || '',
      created: note?.created ? await this.userServiceExt.santizeDate(note.created) : new Date(),
      modified: note?.modified ? await this.userServiceExt.santizeDate(note.modified) : new Date(),
    }

    console.log(payload)
    
    // get the userId if exist
    const userExist = await this.usersRepository.findOne({ where: { providerId: note.userId } });

    if (userExist?.id) {
      payload.userId = userExist.id
      payload.coachId = payload.coachId && await this.fetchCoachIdByProviderId(payload.coachId)
      // check if current user waist circumference exist on DB
      const checkUserNotesLog = await this.noteRepository.findOne({ 
        where: {
          and: [
            { userId: userExist?.id },
            { summary: payload.summary },
            { title: payload?.title },
            { created: payload.created },
          ]
        }
      });

      console.log(checkUserNotesLog)

      if (!checkUserNotesLog?.id) {
        await this.noteRepository.create(payload)
        return {
          status: 'CREATE',
          providerId: payload?.userId
        };
      }

      return {
        status: 'METRIC_EXIST',
        providerId: checkUserNotesLog?.id
      };
    }

    return {
      status: 'USER_NOT_EXIST',
      providerId: payload?.userId
    };
  }

  async medicationsMigration(medication: AnyObject): Promise<AnyObject> {
    const payload: AnyObject = {
      userId: '626baa41f491cb44c44952ec',
      name: medication?.name ?? null,
      created: medication?.created_at ? await this.userServiceExt.santizeDate(medication.created_at) : new Date(),
      modified: medication?.updated_at ? await this.userServiceExt.santizeDate(medication.updated_at) : new Date(),
    }

    // check if current user waist circumference exist on DB
    const checkMedicationLog = await this.medicationRepository.findOne({
      where: { name: payload.name }
    });

    if (!checkMedicationLog?.id) {
      await this.medicationRepository.create(payload)
      return {
        status: 'CREATE',
        providerId: payload?.userId
      };
    }

    return {
      status: 'METRIC_EXIST',
      providerId: checkMedicationLog?.id
    };
  }

  async userMedicationPassportMigration(medicationPassport: AnyObject): Promise<AnyObject> {
    const payload: AnyObject = {
      userId: medicationPassport?.userId,
      coachId: medicationPassport?.coachId && parseInt(medicationPassport?.coachId) !== parseInt(medicationPassport.userId) ? medicationPassport?.coachId : '',
      medicationId: medicationPassport?.medicationId || '',
      type: medicationPassport?.type || '',
      frequency: medicationPassport?.frequency || '',
      isMedicationPassportComplete: true,
      startDate: medicationPassport?.startDate ? await this.userServiceExt.santizeDate(medicationPassport.startDate) : new Date(),
      source: medicationPassport?.source || '-',
      dosagesUnit: medicationPassport?.dosagesUnit || '',
      isPastMedication: medicationPassport?.isPastMedication && medicationPassport.isPastMedication === 'True' ? true : false,
      dosage: medicationPassport?.dosage || '',
      created: medicationPassport?.created ? await this.userServiceExt.santizeDate(medicationPassport.created) : new Date(),
      modified: medicationPassport?.modified ? await this.userServiceExt.santizeDate(medicationPassport.modified) : new Date(),
    }
    
    // get the userId if exist
    const userExist = await this.usersRepository.findOne({ where: { providerId: medicationPassport.userId } });

    if (userExist?.id) {
      payload.userId = userExist.id
      payload.coachId = payload.coachId && await this.fetchCoachIdByProviderId(payload.coachId)

      const medicationId = await this.medicationRepository.findOne({
        where: { name: payload.medicationId }
      });
  
      if (medicationId?.id) {
        payload.medicationId = medicationId?.id

        // check if current user waist circumference exist on DB
        const checkUserMedicationPassportLog = await this.medicationPassportRepository.findOne({ 
          where: {
            and: [
              { userId: userExist?.id },
              { medicationId: medicationId?.id },
              { frequency: payload?.frequency },
              { startDate: payload?.startDate },
              { created: payload?.created },
            ]
          }
        });
  
        if (!checkUserMedicationPassportLog?.id) { // create weight if doesn't exist
          await this.medicationPassportRepository.create(payload)
          return {
            status: 'CREATE',
            providerId: payload?.userId
          };
        }

        checkUserMedicationPassportLog.coachId = payload.coachId
        checkUserMedicationPassportLog.created = payload.created
        checkUserMedicationPassportLog.modified = payload.modified
        await this.medicationPassportRepository.updateById(checkUserMedicationPassportLog.id, checkUserMedicationPassportLog);
        return {
          status: 'METRIC_EXIST',
          providerId: checkUserMedicationPassportLog?.id
        };
      }

    }

    return {
      status: 'USER_NOT_EXIST',
      providerId: payload?.userId
    };
  }

  async usersBloodPressureMigration(bloodPressure: AnyObject): Promise<AnyObject> {
    const payload: AnyObject = {
      userId: bloodPressure?.userId,
      coachId: bloodPressure?.coachId && parseInt(bloodPressure?.coachId) !== parseInt(bloodPressure.userId) ? bloodPressure?.coachId : '',
      systolic: bloodPressure?.systolic,
      diastolic: bloodPressure?.diastolic,
      logDate: bloodPressure?.logDate && await this.userServiceExt.santizeDate(bloodPressure.logDate),
      comment: bloodPressure?.comments || '',
      channel: bloodPressure?.channel,
      'created_at': bloodPressure?.created_at && await this.userServiceExt.santizeDate(bloodPressure.created_at),
      'modified_at': bloodPressure?.modified_at && await this.userServiceExt.santizeDate(bloodPressure.modified_at),
    }

    // get the userId if exist
    const userExist = await this.usersRepository.findOne({
      where: {
        or: [
          { providerId: bloodPressure.userId },
          { id: bloodPressure.userId }
        ]
      } 
    });

    if (userExist?.id) {
      payload.userId = userExist.id
      payload.coachId = payload.coachId && await this.fetchCoachIdByProviderId(payload.coachId)
      // check if current weight exist on DB
      const checkBloodPressureLog = await this.bloodPressureRepository.findOne({ 
        where: {
          and: [
            { userId: userExist?.id },
            { systolic: payload?.systolic },
            { diastolic: payload.diastolic },
            { logDate: payload.logDate },
            { 'created_at': payload.created_at },
          ]
        }
      });

      if (!checkBloodPressureLog?.id) { // create blood pressure if doesn't exist
        await this.bloodPressureRepository.create(payload)
        return {
          status: 'CREATE',
          providerId: payload?.userId
        };
      }

      return {
        status: 'METRIC_EXIST',
        providerId: checkBloodPressureLog?.id
      };
    }

    return {
      status: 'USER_NOT_EXIST',
      providerId: payload?.userId
    };
  }

  async usersBloodSugarMigration(bloodSugar: AnyObject): Promise<AnyObject> {
    const payload: AnyObject = {
      userId: bloodSugar?.userId,
      coachId: bloodSugar?.coachId && parseInt(bloodSugar?.coachId) !== parseInt(bloodSugar.userId) ? bloodSugar?.coachId : '',
      mealType: bloodSugar?.mealType,
      mealDetail: bloodSugar?.mealDetail,
      beforeMeal: bloodSugar?.beforeMeal || '0',
      defaultBeforeMeal: bloodSugar?.beforeMeal || '0',
      afterMeal: bloodSugar?.afterMeal || '0',
      defaultAfterMeal: bloodSugar?.afterMeal || '0',
      unit: bloodSugar?.unit || 'mg/dL',
      logDate: bloodSugar?.logDate && await this.userServiceExt.santizeDate(bloodSugar.logDate),
      channel: bloodSugar?.channel,
      'created_at': bloodSugar?.created_at && await this.userServiceExt.santizeDate(bloodSugar.created_at),
      'modified_at': bloodSugar?.modified_at && await this.userServiceExt.santizeDate(bloodSugar.modified_at),
    }

    // get the userId if exist
    const userExist = await this.usersRepository.findOne({ 
      where: {
        or: [
          { providerId: bloodSugar.userId } ,
          { id: bloodSugar.userId }
        ]
      }
    });

    if (userExist?.id) {
      payload.userId = userExist.id
      payload.coachId = payload.coachId && await this.fetchCoachIdByProviderId(payload.coachId)
      // check if current weight exist on DB
      const checkBloodSugarLog = await this.bloodSugarRepository.findOne({ 
        where: {
          and: [
            { userId: userExist?.id },
            { mealType: payload?.mealType },
            { beforeMeal: payload?.beforeMeal },
            { afterMeal: payload?.afterMeal },
            { logDate: payload.logDate },
            { 'created_at': payload.created_at },
          ]
        }
      });

      if (!checkBloodSugarLog?.id) { // create blood sugar if doesn't exist
        await this.bloodSugarRepository.create(payload)
        return {
          status: 'CREATE',
          providerId: payload?.userId
        };
      }

      checkBloodSugarLog.coachId = payload.coachId
      checkBloodSugarLog.created_at = payload.created_at
      checkBloodSugarLog.modified_at = payload.modified_at
      await this.bloodSugarRepository.updateById(checkBloodSugarLog.id, checkBloodSugarLog);
      return {
        status: 'METRIC_EXIST',
        providerId: checkBloodSugarLog?.id
      };
    }

    return {
      status: 'USER_NOT_EXIST',
      providerId: payload?.userId
    };
  }

  async usersCholesterolMigration(cholesterol: AnyObject): Promise<AnyObject> {
    const payload: AnyObject = {
      userId: cholesterol?.userId,
      coachId: cholesterol?.coachId && parseInt(cholesterol?.coachId) !== parseInt(cholesterol.userId) ? cholesterol?.coachId : '',
      triglycerides: cholesterol?.triglycerides,
      hdl: cholesterol?.hdl,
      ldl: cholesterol?.ldl,
      cholesterol: cholesterol?.cholestrol,
      unit: cholesterol?.unit,
      logDate: cholesterol?.logDate && await this.userServiceExt.santizeDate(cholesterol.logDate),
      'created_at': cholesterol?.created && await this.userServiceExt.santizeDate(cholesterol.created),
      'modified_at': cholesterol?.modified && await this.userServiceExt.santizeDate(cholesterol.modified),
    }

    // get the userId if exist
    const userExist = await this.usersRepository.findOne({
      where: {
        or: [
          { providerId: cholesterol.userId },
          { id: cholesterol.userId }
        ]
      } 
    });

    if (userExist?.id) {
      payload.userId = userExist.id
      payload.coachId = payload.coachId && await this.fetchCoachIdByProviderId(payload.coachId)
      // check if current weight exist on DB
      const checkCholesterolLog = await this.cholesterolRepository.findOne({ 
        where: {
          and: [
            { userId: userExist?.id },
            { triglycerides: payload?.triglycerides },
            { hdl: payload?.hdl },
            { ldl: payload?.ldl },
            { cholesterol: payload?.cholesterol },
            { logDate: payload.logDate },
            { 'created_at': payload.created_at },
          ]
        }
      });

      if (!checkCholesterolLog?.id) {
        await this.cholesterolRepository.create(payload)
        return {
          status: 'CREATE',
          providerId: payload?.userId
        };
      }

      return {
        status: 'METRIC_EXIST',
        providerId: checkCholesterolLog?.id
      };
    }

    return {
      status: 'USER_NOT_EXIST',
      providerId: payload?.userId
    };
  }

  async usersExerciseTypeMigration(exerciseType: AnyObject): Promise<AnyObject> {
    const payload: AnyObject = {
      name: exerciseType?.name,
      legacyId: exerciseType?.id,
      created: exerciseType?.created_at ? await this.userServiceExt.santizeDate(exerciseType.created_at) : await this.userServiceExt.santizeDate(exerciseType.modified_at),
      modified: exerciseType?.modified_at && await this.userServiceExt.santizeDate(exerciseType.modified_at),
    }

    const checkExerciseTypeLog = await this.exerciseTypesRepository.findOne({ 
      where: { 
        and: [
          { name: payload?.name },
          { legacyId: payload?.legacyId }
        ]
       }
    });

    if (!checkExerciseTypeLog?.id) {
      await this.exerciseTypesRepository.create(payload)
      return {
        status: 'CREATE',
        providerId: payload?.userId
      };
    }

    return {
      status: 'METRIC_EXIST',
      providerId: checkExerciseTypeLog?.id
    };
  }

  async usersExerciseMigration(exercise: AnyObject): Promise<AnyObject> {
    const payload: AnyObject = {
      userId: exercise?.userId,
      coachId: exercise?.coachId && parseInt(exercise?.coachId) !== parseInt(exercise.userId) ? exercise?.coachId : '',
      duration: exercise?.duration || '',
      intensity: exercise?.intensity ? (exercise.intensity === 'Mod' ? 'Medium' : exercise?.intensity) : '',
      exerciseTypeId: exercise?.exercise_activity_id ? Number(exercise?.exercise_activity_id) : exercise?.exercise_activity_id,
      startTime: exercise?.startTime ? await this.userServiceExt.santizeDate(exercise.startTime) : new Date(),
      logDate: exercise?.logDate && await this.userServiceExt.santizeDate(exercise.logDate),
      channel: exercise?.channel || 'web',
      'created_at': exercise?.created_at && await this.userServiceExt.santizeDate(exercise.created_at),
      'modified_at': exercise?.modified_at && await this.userServiceExt.santizeDate(exercise.modified_at),
    }
    
    // get the userId if exist
    const userExist = await this.usersRepository.findOne({
      where: {
        or: [
          { providerId: exercise.userId },
          { id: exercise.userId }
        ]
      } 
    });

    if (userExist?.id) {
      payload.userId = userExist.id
      payload.coachId = payload.coachId && await this.fetchCoachIdByProviderId(payload.coachId)

      const exerciseTypeId = await this.exerciseTypesRepository.findOne({
        where: { legacyId: payload.exerciseTypeId }
      });
  
        payload.exerciseTypeId = exerciseTypeId?.id || ""

        // check if current user waist circumference exist on DB
        const checkUserExerciseLog = await this.exerciseRepository.findOne({ 
          where: {
            and: [
              { userId: userExist?.id },
              // { exerciseTypeId: payload?.exerciseTypeId },
              { duration: payload?.duration },
              { intensity: payload?.intensity },
              { logDate: payload?.logDate },
              { 'created_at': payload?.created_at },
            ]
          }
        });
  
        if (!checkUserExerciseLog?.id) { // create weight if doesn't exist
          await this.exerciseRepository.create(payload)
          return {
            status: 'CREATE',
            providerId: payload?.userId
          };
        }

        checkUserExerciseLog.coachId = payload.coachId
        checkUserExerciseLog.created_at = payload.created_at
        checkUserExerciseLog.modified_at = payload.modified_at
        await this.exerciseRepository.updateById(checkUserExerciseLog.id, checkUserExerciseLog);
        return {
          status: 'METRIC_EXIST',
          providerId: checkUserExerciseLog?.id
        };
    }

    return {
      status: 'USER_NOT_EXIST',
      providerId: payload?.userId
    };
  }

  async proceduresListMigration(procedure: AnyObject): Promise<AnyObject> {
    const payload: AnyObject = {
      name: procedure?.name,
      procedureId: procedure?.procedureId,
      'created_at': procedure?.created ? await this.userServiceExt.santizeDate(procedure.created) : new Date(),
      'modified_at': procedure?.modified ? await this.userServiceExt.santizeDate(procedure.modified) : new Date(),
    }

    const checkProceduresListLog = await this.procedureListRepository.findOne({ 
      where: { 
        and: [
          { name: payload?.name },
          { procedureId: payload?.procedureId }
        ]
       }
    });

    if (!checkProceduresListLog?.id) {
      await this.procedureListRepository.create(payload)
      return {
        status: 'CREATE',
        providerId: payload?.userId
      };
    }

    return {
      status: 'METRIC_EXIST',
      providerId: checkProceduresListLog?.id
    };
  }

  async usersBMIMigration(bmi: AnyObject): Promise<AnyObject> {
    const payload: AnyObject = {
      userId: bmi?.userId,
      coachId: bmi?.coachId && parseInt(bmi?.coachId) !== parseInt(bmi.userId) ? bmi?.coachId : '',
      bmi: bmi?.bmi,
      channel: bmi?.channel,
      logDate: bmi?.logDate && await this.userServiceExt.santizeDate(bmi.logDate),
      'created_at': bmi?.created && await this.userServiceExt.santizeDate(bmi.created),
      'modified_at': bmi?.created && await this.userServiceExt.santizeDate(bmi.created),
    }

    // get the userId if exist
    const userExist = await this.usersRepository.findOne({ 
      where: { 
        or: [
          { providerId: bmi.userId },
          { id: bmi.userId }
        ]
      } 
    });

    if (userExist?.id) {
      payload.userId = userExist.id
      payload.coachId = payload.coachId && await this.fetchCoachIdByProviderId(payload.coachId)
      // check if current weight exist on DB
      const checkBmiLog = await this.bmiRepository.findOne({ 
        where: {
          and: [
            { userId: userExist?.id },
            { bmi: payload?.bmi },
            { logDate: payload.logDate },
            { 'created_at': payload.created_at },
          ]
        }
      });

      if (!checkBmiLog?.id) {
        await this.bmiRepository.create(payload)
        return {
          status: 'CREATE',
          providerId: payload?.userId
        };
      }

      return {
        status: 'METRIC_EXIST',
        providerId: checkBmiLog?.id
      };
    }

    return {
      status: 'USER_NOT_EXIST',
      providerId: payload?.userId
    };
  }

  async usersEyeExaminationMigration(eyeExamination: AnyObject): Promise<AnyObject> {
    const payload: AnyObject = {
      userId: eyeExamination?.userId,
      coachId: eyeExamination?.coachId && parseInt(eyeExamination?.coachId) !== parseInt(eyeExamination.userId) ? eyeExamination?.coachId : '',
      testDate: eyeExamination?.testDate && await this.userServiceExt.santizeDate(eyeExamination.testDate),
      name: eyeExamination?.name,
      address: eyeExamination?.address,
      isEyeExaminationComplete: true,
      created: eyeExamination?.created && await this.userServiceExt.santizeDate(eyeExamination.created),
      modified: eyeExamination?.modified && await this.userServiceExt.santizeDate(eyeExamination.modified),
    }

    // get the userId if exist
    const userExist = await this.usersRepository.findOne({ where: { providerId: eyeExamination.userId } });

    if (userExist?.id) {
      payload.userId = userExist.id
      payload.coachId = payload.coachId && await this.fetchCoachIdByProviderId(payload.coachId)
      // check if current weight exist on DB
      const checkEyeExaminationLog = await this.eyeExaminationRepository.findOne({ 
        where: {
          and: [
            { userId: userExist?.id },
            { testDate: payload?.testDate },
            { name: payload.name },
            { address: payload.address },
            { created: payload.created },
          ]
        }
      });

      if (!checkEyeExaminationLog?.id) {
        await this.eyeExaminationRepository.create(payload)
        return {
          status: 'CREATE',
          providerId: payload?.userId
        };
      }

      return {
        status: 'METRIC_EXIST',
        providerId: checkEyeExaminationLog?.id
      };
    }

    return {
      status: 'USER_NOT_EXIST',
      providerId: payload?.userId
    };
  }

  async usersFootExaminationMigration(footExamination: AnyObject): Promise<AnyObject> {
    const payload: AnyObject = {
      userId: footExamination?.userId,
      coachId: footExamination?.coachId && parseInt(footExamination?.coachId) !== parseInt(footExamination.userId) ? footExamination?.coachId : '',
      testDate: footExamination?.testDate && await this.userServiceExt.santizeDate(footExamination.testDate),
      name: footExamination?.name,
      address: footExamination?.address,
      isFootExaminationComplete: true,
      created: footExamination?.created && await this.userServiceExt.santizeDate(footExamination.created),
      modified: footExamination?.modified && await this.userServiceExt.santizeDate(footExamination.modified),
    }

    // get the userId if exist
    const userExist = await this.usersRepository.findOne({ where: { providerId: footExamination.userId } });

    if (userExist?.id) {
      payload.userId = userExist.id
      payload.coachId = payload.coachId && await this.fetchCoachIdByProviderId(payload.coachId)
      // check if current weight exist on DB
      const checkFootExaminationLog = await this.footExaminationRepository.findOne({ 
        where: {
          and: [
            { userId: userExist?.id },
            { testDate: payload?.testDate },
            { name: payload.name },
            { address: payload.address },
            { created: payload.created },
          ]
        }
      });

      if (!checkFootExaminationLog?.id) {
        await this.footExaminationRepository.create(payload)
        return {
          status: 'CREATE',
          providerId: payload?.userId
        };
      }

      return {
        status: 'METRIC_EXIST',
        providerId: checkFootExaminationLog?.id
      };
    }

    return {
      status: 'USER_NOT_EXIST',
      providerId: payload?.userId
    };
  }

  async usersHba1cMigration(hba1c: AnyObject): Promise<AnyObject> {
    const payload: AnyObject = {
      userId: hba1c?.userId,
      coachId: hba1c?.coachId && parseInt(hba1c?.coachId) !== parseInt(hba1c.userId) ? hba1c?.coachId : '',
      logDate: hba1c?.logDate && await this.userServiceExt.santizeDate(hba1c.logDate),
      value: hba1c?.value,
      'created_at': hba1c?.created_at && await this.userServiceExt.santizeDate(hba1c.created_at),
      'modified_at': hba1c?.modified_at && await this.userServiceExt.santizeDate(hba1c.modified_at),
    }

    // get the userId if exist
    const userExist = await this.usersRepository.findOne({
      where: {
        or: [
          { providerId: hba1c.userId },
          { id: hba1c.userId }
        ]
      } 
    });

    if (userExist?.id) {
      payload.userId = userExist.id
      payload.coachId = payload.coachId && await this.fetchCoachIdByProviderId(payload.coachId)
      // check if current weight exist on DB
      const checkHba1cLog = await this.hbaicRepository.findOne({ 
        where: {
          and: [
            { userId: userExist?.id },
            { value: payload?.testDate },
            { logDate: payload.logDate },
            { 'created_at': payload.created_at },
          ]
        }
      });

      if (!checkHba1cLog?.id) {
        await this.hbaicRepository.create(payload)
        return {
          status: 'CREATE',
          providerId: payload?.userId
        };
      }

      return {
        status: 'METRIC_EXIST',
        providerId: checkHba1cLog?.id
      };
    }

    return {
      status: 'USER_NOT_EXIST',
      providerId: payload?.userId
    };
  }

  async usersHealthProceduresSurgeriesMigration(healthProcedure: AnyObject): Promise<AnyObject> {
    const payload: AnyObject = {
      userId: healthProcedure?.userId,
      coachId: healthProcedure?.coachId && parseInt(healthProcedure?.coachId) !== parseInt(healthProcedure.userId) ? healthProcedure?.coachId : '',
      treatmentDate: healthProcedure?.treatmentDate && await this.userServiceExt.santizeDate(healthProcedure.treatmentDate),
      procedureId: healthProcedure?.procedureId && Number(healthProcedure?.procedureId),
      isHealthProcedureComplete: true,
      created: healthProcedure?.created && await this.userServiceExt.santizeDate(healthProcedure.created),
      modified: healthProcedure?.modified && await this.userServiceExt.santizeDate(healthProcedure.modified),
    }
    
    // get the userId if exist
    const userExist = await this.usersRepository.findOne({ where: { providerId: healthProcedure.userId } });

    if (userExist?.id) {
      payload.userId = userExist.id
      payload.coachId = payload.coachId && await this.fetchCoachIdByProviderId(payload.coachId)

      const procedureId = await this.procedureListRepository.findOne({
        where: { procedureId: payload.procedureId }
      });
  
      if (procedureId?.id) {
        payload.procedureId = procedureId?.id

        // check if current user waist circumference exist on DB
        const checkUserHealthProcedureSurgeriesLog = await this.healthProcedureSurgeriesRepository.findOne({ 
          where: {
            and: [
              { userId: userExist?.id },
              { procedureId: payload?.procedureId },
              { treatmentDate: payload?.treatmentDate },
              { created: payload?.created },
            ]
          }
        });
  
        if (!checkUserHealthProcedureSurgeriesLog?.id) {
          await this.healthProcedureSurgeriesRepository.create(payload)
          return {
            status: 'CREATE',
            providerId: payload?.userId
          };
        }

        return {
          status: 'METRIC_EXIST',
          providerId: checkUserHealthProcedureSurgeriesLog?.id
        };
      }

    }
    return {
      status: 'USER_NOT_EXIST',
      providerId: payload?.userId
    };
  }

  async diseaseMigration(disease: AnyObject): Promise<AnyObject> {
    const payload: AnyObject = {
      name: disease?.type,
      legacyId: disease?.id,
      created: disease?.created_at ? await this.userServiceExt.santizeDate(disease.created_at) : new Date(),
      modified: disease?.created_at ? await this.userServiceExt.santizeDate(disease.created_at) : new Date(),
    }

    // check if current user waist circumference exist on DB
    const checkDiseaseLog = await this.diseaseRepository.findOne({
      where: { name: payload.name }
    });

    if (!checkDiseaseLog?.id) {
      await this.diseaseRepository.create(payload)
      return {
        status: 'CREATE',
        providerId: checkDiseaseLog?.id
      };
    }

    return {
      status: 'METRIC_EXIST',
      providerId: checkDiseaseLog?.id
    };
  }

  async usersHealthConditionMigration(healthCondition: AnyObject): Promise<AnyObject> {
    const payload: AnyObject = {
      userId: healthCondition?.userId,
      coachId: healthCondition?.coachId && parseInt(healthCondition?.coachId) !== parseInt(healthCondition.userId) ? healthCondition?.coachId : '',
      diseaseId: healthCondition?.diseaseId,
      source: healthCondition?.source,
      type: healthCondition?.type ?? 'past',
      isHealthConditionComplete: true,
      created: healthCondition?.created ? await this.userServiceExt.santizeDate(healthCondition.created) : new Date(),
      modified: healthCondition?.modified ? await this.userServiceExt.santizeDate(healthCondition.modified) : new Date(),
    }

    if (healthCondition?.diseaseDate) {
      payload.diseaseDate = await this.userServiceExt.santizeDate(healthCondition.diseaseDate)
    }
    
    // get the userId if exist
    const userExist = await this.usersRepository.findOne({ where: { providerId: healthCondition.userId } });

    if (userExist?.id) {
      payload.userId = userExist.id
      payload.coachId = payload.coachId && await this.fetchCoachIdByProviderId(payload.coachId)

      const diseaseId = await this.diseaseRepository.findOne({
        where: { name: payload.diseaseId }
      });
  
      if (diseaseId?.id) {
        payload.diseaseId = diseaseId?.id

        // check if current user waist circumference exist on DB
        const checkUserHealthConditionLog = await this.healthConditionRepository.findOne({ 
          where: {
            and: [
              { userId: userExist?.id },
              { diseaseId: payload?.diseaseId },
              { source: payload?.source },
              { diseaseDate: payload?.diseaseDate },
              { created: payload?.created },
            ]
          }
        });
  
        if (!checkUserHealthConditionLog?.id) { // create weight if doesn't exist
          await this.healthConditionRepository.create(payload)
          return {
            status: 'CREATE',
            providerId: payload?.userId
          };
        }

        checkUserHealthConditionLog.coachId = payload.coachId;
        checkUserHealthConditionLog.created = payload.created;
        checkUserHealthConditionLog.modified = payload.modified;
        return {
          status: 'METRIC_EXIST',
          providerId: checkUserHealthConditionLog?.id
        };
      }
    }

    return {
      status: 'USER_NOT_EXIST',
      providerId: payload?.userId
    };
  }

  async usersWeightGoalMigration(weightGoal: AnyObject): Promise<AnyObject> {
    const payload: AnyObject = {
      userId: weightGoal?.userId,
      coachId: weightGoal?.coachId && parseInt(weightGoal?.coachId) !== parseInt(weightGoal.userId) ? weightGoal?.coachId : '',
      value: weightGoal?.value,
      channel: weightGoal?.channel,
      unit: weightGoal?.unit,
      logDate: weightGoal?.logDate && await this.userServiceExt.santizeDate(weightGoal.logDate),
      created: weightGoal?.created && await this.userServiceExt.santizeDate(weightGoal.created),
      modified: weightGoal?.created && await this.userServiceExt.santizeDate(weightGoal.created),
    }
    
    // get the userId if exist
    const userExist = await this.usersRepository.findOne({ where: { providerId: weightGoal.userId } });

    if (userExist?.id) {
      payload.userId = userExist.id
      payload.coachId = payload.coachId && await this.fetchCoachIdByProviderId(payload.coachId)
      
      const checkUserWeightGoalLog = await this.weightGoalRepository.findOne({ 
        where: {
          and: [
            { userId: userExist?.id },
            { value: payload.value },
            { logDate: payload?.logDate },
            { unit: payload?.unit },
            { created: payload.created },
          ]
        }
      });

      if (!checkUserWeightGoalLog?.id) {
        await this.weightGoalRepository.create(payload)
        return {
          status: 'CREATE',
          providerId: payload?.userId
        };
      }

      checkUserWeightGoalLog.coachId = payload.coachId;
      checkUserWeightGoalLog.created = payload.created;
      checkUserWeightGoalLog.modified = payload.modified;
      await this.weightGoalRepository.updateById(checkUserWeightGoalLog.id, checkUserWeightGoalLog);
      return {
        status: 'METRIC_EXIST',
        providerId: checkUserWeightGoalLog?.id
      };
    }

    return {
      status: 'USER_NOT_EXIST',
      providerId: payload?.userId
    };
  }

  async usersCommunicationLogMigration(communicationLog: AnyObject): Promise<AnyObject> {
    const payload: AnyObject = {
      userId: communicationLog?.userId,
      coachId: communicationLog?.coachId && parseInt(communicationLog?.coachId) !== parseInt(communicationLog.userId) ? communicationLog?.coachId : '',
      logType: communicationLog?.logType,
      entryDate: communicationLog?.entryDate && await this.userServiceExt.santizeDate(communicationLog.entryDate),
      callType: communicationLog?.callType ?? '',
      conversationType: communicationLog?.conversationType,
      comment: communicationLog?.comment,
      created: communicationLog?.created && await this.userServiceExt.santizeDate(communicationLog.created),
      modified: communicationLog?.modified && await this.userServiceExt.santizeDate(communicationLog.modified),
    }

    if (communicationLog?.time) {
      payload.time = await this.userServiceExt.fixCommunicationLogDate(communicationLog.time, communicationLog.entryDate)
    }

    if (communicationLog?.endTime) {
      payload.endTime = await this.userServiceExt.fixCommunicationLogDate(communicationLog.endTime, communicationLog.entryDate)
    }

    if (communicationLog?.logTime) {
      payload.logTime = await this.userServiceExt.fixCommunicationLogDate(communicationLog.logTime, communicationLog.entryDate)
    }

    // get the userId if exist
    const userExist = await this.usersRepository.findOne({ where: { providerId: communicationLog.userId } });

    if (userExist?.id) {
      payload.userId = userExist.id
      payload.coachId = payload.coachId && await this.fetchCoachIdByProviderId(payload.coachId)

      const checkUserCommunicationLogLog = await this.communicationLogRepository.findOne({ 
        where: {
          and: [
            { userId: userExist?.id },
            { logType: payload.logType },
            { entryDate: payload?.entryDate },
            { created: payload.created },
          ]
        }
      });

      if (!checkUserCommunicationLogLog?.id) {
        await this.communicationLogRepository.create(payload)
        return {
          status: 'CREATE',
          providerId: payload?.userId
        };
      }

      checkUserCommunicationLogLog.coachId = payload.coachId;
      checkUserCommunicationLogLog.created = payload.created;
      checkUserCommunicationLogLog.modified = payload.modified;
      await this.communicationLogRepository.updateById(checkUserCommunicationLogLog.id, checkUserCommunicationLogLog);
      return {
        status: 'METRIC_EXIST',
        providerId: checkUserCommunicationLogLog?.id
      };
    }

    return {
      status: 'USER_NOT_EXIST',
      providerId: payload?.userId
    };
  }

  async usersCommunicationDeleteMigration(communicationLogList): Promise<AnyObject> {
    const ids = communicationLogList.map(list => list._id);
    
    // Assuming this.usersRepository.delete is an asynchronous operation
    const deletePromises = ids.map(async (id) => {
      try {
        // Replace the following line with your actual delete operation
        await this.communicationLogRepository.deleteById(id);
        return { id, success: true };
      } catch (error) {
        // Handle errors or log them if necessary
        console.error(`Error deleting record with id ${id}:`, error);
        return { id, success: false };
      }
    });

    // Wait for all delete operations to complete
    const deletedRecords = await Promise.all(deletePromises);

    return {
      success: deletedRecords.every(record => record.success),
      deletedRecords,
    };
  }

  async coachesMigration(coach: AnyObject): Promise<AnyObject> {
    const payload: AnyObject = {
      coachId: parseInt(coach.providerId),
      name: coach?.name || "",
      firstName: coach?.firstName || "",
      lastName: coach?.lastName || "",
      gender: coach?.gender || "",
      address: {
        country: coach?.country || "",
        state: coach?.state || "",
        city: coach?.city || "",
        address: coach?.address || "",
        zipCode: coach?.zipcode || ""
      },
      phone: coach?.phone || "",
      email: coach?.email || "",
      md5password: coach.md5password || "",
      password: await this.passwordHasher.hashPassword('123456'),
      created: await this.userServiceExt.santizeDate(coach.created),
      image: baseUrl + coach?.image || "",
      isActive: coach.status ? true : false,
      referralCode: coach?.referralCode || "",
    }

    if (coach?.dob) {
      payload.dob = await this.userServiceExt.santizeDate(coach.dob);
    }

    const accountExist = await this.coachRepository.findOne({ 
      where: {
        or: [
          { email: coach?.email || 'null' },
          { phone: coach?.phone || 'null' },
        ]
      }
    });

    if (accountExist?.id) {
      await this.coachRepository.updateById(accountExist.id, { 
        coachId: payload.coachId,
        md5password: payload.md5password,
        referralCode: payload.referralCode
      })
      return {
        status: 'accountExist',
        providerId: payload?.coachId
      };
    }

    const providerIdExist = await this.coachRepository.findOne({ where: { coachId: payload.coachId } })

    if (!providerIdExist?.id) {
      await this.coachRepository.create(payload)
      return {
        status: 'create',
        providerId: payload?.coachId
      };
    }

    await this.coachRepository.updateById(providerIdExist.id, {
      md5password: payload.md5password,
      referralCode: payload.referralCode
    })

    return {
      status: 'providerIdExist',
      providerId: payload?.coachId
    };
  }

  async usersActionPlanMigration(action: AnyObject): Promise<AnyObject> {
    const payload: AnyObject = {
      userId: action?.userId,
      coachId: action?.coachId && parseInt(action?.coachId) !== parseInt(action.userId) ? action?.coachId : '',
      body: action?.body,
      attachment: action?.attachment,
      isDownloaded: action?.isDowndloaded,
      created: action?.created && await this.userServiceExt.santizeDate(action.created),
      modified: action?.modified && await this.userServiceExt.santizeDate(action.modified),
    }

    // get the userId if exist
    const userExist = await this.usersRepository.findOne({ where: { providerId: action.userId } });

    if (userExist?.id) {
      payload.userId = userExist.id
      payload.coachId = payload.coachId && await this.fetchCoachIdByProviderId(payload.coachId)

      const checkActionPlanLog = await this.actionPlanRepository.findOne({ 
        where: {
          and: [
            { userId: userExist?.id },
            { body: payload.body },
            { created: payload.created },
          ]
        }
      });

      if (!checkActionPlanLog?.id) {
        await this.actionPlanRepository.create(payload)
        return {
          status: 'CREATE',
          providerId: payload?.userId
        };
      }

      checkActionPlanLog.coachId = payload.coachId;
      checkActionPlanLog.created = payload.created;
      checkActionPlanLog.modified = payload.modified;
      await this.actionPlanRepository.updateById(checkActionPlanLog.id, checkActionPlanLog);
      return {
        status: 'METRIC_EXIST',
        providerId: checkActionPlanLog?.id
      };
    }

    return {
      status: 'USER_NOT_EXIST',
      providerId: payload?.userId
    };
  }

  async usersLifestyleDiaryMigration(lifestyle: AnyObject): Promise<AnyObject> {
    const payload: AnyObject = {
      userId: lifestyle?.userId,
      sleepTime: lifestyle?.sleepTime,
      exercise: lifestyle?.exercise,
      fluShots: lifestyle?.fluShots,
      smokeTobacco: lifestyle?.smokeTobacco,
      drinkAlcohol: lifestyle?.drinkAlcohol,
      recreatDrugs: lifestyle?.recreatDrugs,
      toxicChemical: lifestyle?.toxicChemical,
      everDisabled: lifestyle?.everDisabled,
      created: lifestyle?.created && await this.userServiceExt.santizeDate(lifestyle.created),
      modified: lifestyle?.modified && await this.userServiceExt.santizeDate(lifestyle.modified),
    }

    // get the userId if exist
    const userExist = await this.usersRepository.findOne({ where: { providerId: lifestyle.userId } });

    if (userExist?.id) {
      payload.userId = userExist.id;

      const checkLifestyleDiaryLog = await this.lifestyleDiaryRepository.findOne({ 
        where: {
          and: [
            { userId: userExist?.id },
            { sleepTime: payload.sleepTime },
            { exercise: payload.exercise },
            { fluShots: payload.fluShots },
            { smokeTobacco: payload.smokeTobacco },
            { drinkAlcohol: payload.drinkAlcohol },
            { recreatDrugs: payload.recreatDrugs },
            { toxicChemical: payload.toxicChemical },
            { everDisabled: payload.everDisabled },
            { created: payload.created },
          ]
        }
      });

      if (!checkLifestyleDiaryLog?.id) {
        await this.lifestyleDiaryRepository.create(payload)
        return {
          status: 'CREATE',
          providerId: payload?.userId
        };
      }

      checkLifestyleDiaryLog.created = payload.created;
      checkLifestyleDiaryLog.modified = payload.modified;
      await this.lifestyleDiaryRepository.updateById(checkLifestyleDiaryLog.id, checkLifestyleDiaryLog);
      return {
        status: 'METRIC_EXIST',
        providerId: checkLifestyleDiaryLog?.id
      };
    }

    return {
      status: 'USER_NOT_EXIST',
      providerId: payload?.userId
    };
  }

  async userFirstNameLastNameUpdate() {
    try {
      const accounts = await this.usersRepository.find({
        where: {},
        order: ['id ASC'],
      });
  
      const selectedResponse = [];
      const noNameResponse = [];
  
      for (const account of accounts) {
        if (!account?.firstName && !account?.lastName) {
          if (account?.name && account.name.includes(' ')) {
            const result = account.name.split(' ');
            const firstName = result.shift();
            const lastName = result.join(' ');
            if (firstName && lastName) {
              console.log([account.id, account.name, firstName, lastName]);
              await this.usersRepository.updateById(account.id, {
                ...account,
                firstName,
                lastName
              })
              selectedResponse.push(account);
            } else {
              console.log(account.id);
            }
          } else {
            noNameResponse.push(account);
          }
        }
      }
  
      return { selectedResponse, noNameResponse };
    } catch (error) {
      console.error("Error fetching user accounts:", error);
      throw error;
    }
  }

  async sanitizeNigeriaPhonenumbers() {
    try {
      const searchString1 = '\\+2340'; // Escape the plus sign for regex
      const searchString2 = '2340';    // Second search string

      const whereClause = {
        or: [
          { phone: { regexp: new RegExp('^' + searchString1) } },
          { phone: { regexp: new RegExp('^' + searchString2) } }
        ]
      };

      const accounts = await this.usersRepository.find({
        where: whereClause,
        order: ['id ASC']
      });
  
      for (const account of accounts) {
        let newPhoneNumber = account.phone;
        if (account.phone.startsWith('+2340')) {
          newPhoneNumber = `+234${account.phone.substring(5)}`
        }
        if (account.phone.startsWith('2340')) {
          newPhoneNumber = `234${account.phone.substring(4)}`
        }
        await this.usersRepository.updateById(account.id, {
          ...account,
          phone: newPhoneNumber,
        });
      }
  
      return { filteredAccounts: accounts };
    } catch (error) {
      console.error("Error sanitizing phone numbers:", error);
      throw error;
    }
  }

  async updateErasedPhoneNumber(usersList) {
    try {
      // list of providerIds
      const errorAcct = [
        // 843805,
        // 1866575,
        // 541450,
      ];

      let count = 0;

      for (const error of errorAcct) {
        const account = usersList.find(user => user.providerId == error);
        if (account) {
          const accountExist = await this.usersRepository.findOne({
            where: {
              providerId: error
            }
          });
          if (accountExist?.id) {
            await this.usersRepository.updateById(accountExist.id, { 
              phone: account.phone
            });
            count++
          }
        }
      }
      return { revertedAccountCount: count };
    } catch (error) {
      console.error("Error sanitizing phone numbers:", error);
      throw error;
    }
  }

  async sanitizeUserEmailAccount() {
    try {
      const whereClause = {
        ...{ email: { regexp: new RegExp('[A-Z]') } }
      };

      const accounts = await this.usersRepository.find({
        where: whereClause,
        order: ['id ASC']
      });
  
      for (const account of accounts) {
        await this.usersRepository.updateById(account.id, {
          ...account,
          email: account.email.toLowerCase(),
        });
      }
  
      return { filteredAccounts: accounts };
    } catch (error) {
      console.error("Error sanitizing phone numbers:", error);
      throw error;
    }
  }

  async deleteUserEmailAccount() {
    try {
      const searchString1 = '@javnoi.com';

      const whereClause = {
        email: { regexp: new RegExp(searchString1 + '$', 'i') }
      };

      const accounts = await this.usersRepository.find({
        where: whereClause,
        order: ['id ASC']
      });
  
      for (const account of accounts) {
        await this.usersRepository.deleteById(account.id);
      }
  
      return { filteredAccounts: accounts };
    } catch (error) {
      console.error("Error sanitizing phone numbers:", error);
      throw error;
    }
  }

  async healthDiaryMigration() {
    try {
      const healthDiaryAccounts = await this.healthDiaryRepository.find({
        where: {
          // type: 'bloodPressureN',
        },
        order: ['id ASC'],
      });

      const response = {
        CREATE: [],
        METRIC_EXIST: [],
        USER_NOT_EXIST: []
      };

      // This is fully functional but commented for now 
      // so the application can start correctly
      // If needed, just uncommented the `for` statement and that's it
      // for (const account of healthDiaryAccounts) {
      //   const { type, created, modified } = account;
      //   if (type === 'waist' && account.waist) {
      //     const waist = account.waist;
      //     const data = {
      //       userId: account?.providerId || account?.userId,
      //       coachId: '',
      //       currentWaist: waist?.value,
      //       defaultValue: waist?.value,
      //       logDate: waist?.date || account.created,
      //       waistGoal: waist?.goal || 0,
      //       unit: waist?.unit?.toLowerCase() || "cm",
      //       channel: account?.channel || 'web',
      //       'created_at': created,
      //       'modified_at': modified,
      //     };
      //     console.log('Waist Data: ', data);
      //     const { status, providerId } = await this.userWaistCircumferenceMigration(data);
      //     if (['CREATE', 'METRIC_EXIST', 'USER_NOT_EXIST'].includes(status)) {
      //       await this.healthDiaryRepository.deleteById(account.id);
      //     }
      //     response[status].push({
      //       id: account.id,
      //       userId: account.userId,
      //       type,
      //       providerId
      //     });
      //   }
      //   if (type === 'bmi' && account.bmi) {
      //     const bmi = account.bmi;
      //     const data = {
      //       userId: account?.providerId || account?.userId,
      //       coachId: '',
      //       bmi: bmi?.value,
      //       channel: 'web',
      //       logDate: bmi?.date || created,
      //       created,
      //       modified,
      //     };
      //     console.log('BMI Data: ', data);
      //     const { status, providerId } = await this.usersBMIMigration(data);
      //     if (['CREATE', 'METRIC_EXIST', 'USER_NOT_EXIST'].includes(status)) {
      //       await this.healthDiaryRepository.deleteById(account.id);
      //     }
      //     response[status].push({
      //       id: account.id,
      //       type,
      //       userId: account.userId,
      //       providerId
      //     });
      //   }
      //   if (type === 'psa' && account.psa) {
      //     const psa = account.psa;
      //     const data = {
      //       userId: account?.providerId || account?.userId,
      //       coachId: '',
      //       logDate: psa?.date || account.created,
      //       totalPsa: psa?.totalPSA ? `${psa?.totalPSA}` : '0',
      //       freePsa: psa?.freePSA ? `${psa.freePSA}` : '0',
      //       fileName: psa?.fileName || '',
      //       'created_at': created,
      //       'modified_at': modified,
      //     }
      //     console.log('PSA Data: ', data);
      //     const { status, providerId } = await this.userPSAMigration(data);
      //     if (['CREATE', 'METRIC_EXIST', 'USER_NOT_EXIST'].includes(status)) {
      //       await this.healthDiaryRepository.deleteById(account.id);
      //     }
      //     response[status].push({
      //       id: account.id,
      //       type,
      //       userId: account.userId,
      //       providerId
      //     });
      //   }
      //   if (type === 'weight' && account.weight) {
      //     const weight = account.weight;
      //     const data = {
      //       userId: account?.providerId || account?.userId,
      //       coachId: '',
      //       value: weight?.value,
      //       unit: weight?.unit,
      //       defaultValue: weight?.unit !== "KG" && poundsToKilograms(weight.value) || weight.value,
      //       defaultUnit: 'KG',
      //       goal: weight?.goal || '0',
      //       logDate: weight?.date || account.created,
      //       channel: 'web',
      //       'created_at': created,
      //       'modified_at': modified,
      //     }
      //     console.log('Weight Data: ', data);
      //     const { status, providerId } = await this.usersWeightMigration(data);
      //     if (['CREATE', 'METRIC_EXIST', 'USER_NOT_EXIST'].includes(status)) {
      //       await this.healthDiaryRepository.deleteById(account.id);
      //     }
      //     response[status].push({
      //       id: account.id,
      //       type,
      //       userId: account.userId,
      //       providerId
      //     });
      //   }
      //   if (type === 'bloodPressure' && account.bloodPressure) {
      //     const bloodPressure = account.bloodPressure;
      //     const data = {
      //       userId: account?.providerId || account?.userId,
      //       coachId: '',
      //       systolic: bloodPressure?.systolic,
      //       diastolic: bloodPressure?.diastolic,
      //       logDate: bloodPressure?.date || created,
      //       comment: bloodPressure?.comments || '',
      //       channel: 'web',
      //       'created_at': created,
      //       'modified_at': modified,
      //     }
      //     console.log('Blood Pressure Data: ', data);
      //     const { status, providerId } = await this.usersBloodPressureMigration(data);
      //     if (['CREATE', 'METRIC_EXIST', 'USER_NOT_EXIST'].includes(status)) {
      //       await this.healthDiaryRepository.deleteById(account.id);
      //     }
      //     response[status].push({
      //       id: account.id,
      //       type,
      //       userId: account.userId,
      //       providerId
      //     });
      //   }
      //   if (type === 'cholesterol' && account.cholesterol) {
      //     const cholesterol = account.cholesterol;
      //     if (cholesterol?.triglycerides && cholesterol?.hdl && cholesterol?.ldl) {
      //       const data = {
      //         userId: account?.providerId || account?.userId,
      //         coachId: '',
      //         triglycerides: cholesterol?.triglycerides,
      //         hdl: cholesterol?.hdl,
      //         ldl: cholesterol?.ldl,
      //         cholestrol: cholesterol?.cholesterol,
      //         logDate: cholesterol?.date || created,
      //         created,
      //         modified,
      //       }
      //       console.log('Cholesterol Data: ', data);
      //       const { status, providerId } = await this.usersCholesterolMigration(data);
      //       if (['CREATE', 'METRIC_EXIST', 'USER_NOT_EXIST'].includes(status)) {
      //         await this.healthDiaryRepository.deleteById(account.id);
      //       }
      //       response[status].push({
      //         id: account.id,
      //         type,
      //         userId: account.userId,
      //         providerId
      //       });
      //     }
      //   }
      //   if (type === 'hbaicLevel' && account.hbaicLevel) {
      //     const hba1c = account.hbaicLevel;
      //     const data = {
      //       userId: account?.providerId || account?.userId,
      //       coachId: '',
      //       logDate: account.date || created,
      //       value: hba1c,
      //       'created_at': created,
      //       'modified_at': modified,
      //     }
      //     console.log('HBAIC Data: ', data);
      //     const { status, providerId } = await this.usersHba1cMigration(data);
      //     if (['CREATE', 'METRIC_EXIST', 'USER_NOT_EXIST'].includes(status)) {
      //       await this.healthDiaryRepository.deleteById(account.id);
      //     }
      //     response[status].push({
      //       id: account.id,
      //       type,
      //       userId: account.userId,
      //       providerId
      //     });
      //   }
      //   if (type === 'exercise' && account.exercise) {
      //     const exercise = account.exercise;
      //     if (exercise?.intensity !== 'No Exercise') {
      //       const exerciseType = await this.exerciseTypesRepository.findOne({
      //         where: { name: exercise?.exerciseName }
      //       });
      //       const data = {
      //         userId: account?.providerId || account?.userId,
      //         coachId: '',
      //         duration: exercise?.duration || '0',
      //         intensity: exercise?.intensity,
      //         'exercise_activity_id': exerciseType?.legacyId ? Number(exerciseType?.legacyId) : '',
      //         startTime: exercise?.date || created,
      //         logDate: exercise?.date || created,
      //         channel: 'web',
      //         'created_at': created,
      //         'modified_at': modified,
      //       }
      //       console.log('Exercise Data: ', data);
      //       const { status, providerId } = await this.usersExerciseMigration(data);
      //       if (['CREATE', 'METRIC_EXIST', 'USER_NOT_EXIST'].includes(status)) {
      //         await this.healthDiaryRepository.deleteById(account.id);
      //       }
      //       response[status].push({
      //         id: account.id,
      //         type,
      //         userId: account.userId,
      //         providerId
      //       });
      //     }
      //   }
      //   if (type === 'glucose' && account.glucose) {
      //     const glucose = account.glucose;
      //     const { beforeMeal = '', afterMeal = '', mealType = '' } = this.userServiceExt.formatGlucoseData(glucose, glucose?.mealType);
      //     if ((beforeMeal || afterMeal) && mealType) {
      //       const data = {
      //         userId: account?.providerId || account?.userId,
      //         coachId: '',
      //         mealType: mealType,
      //         mealDetail: account?.mealDetail,
      //         beforeMeal: beforeMeal || '0',
      //         defaultBeforeMeal: beforeMeal || '0',
      //         afterMeal: afterMeal || '0',
      //         defaultAfterMeal: afterMeal || '0',
      //         unit: glucose?.unit || 'mg/dL',
      //         logDate: glucose?.date || created,
      //         channel: 'web',
      //         'created_at': created,
      //         'modified_at': modified,
      //       };
      //       console.log('Glucose Data: ', data);
      //       const { status, providerId } = await this.usersBloodSugarMigration(data);
      //       await this.healthDiaryRepository.deleteById(account.id);
      //       response[status].push({
      //         id: account.id,
      //         userId: account.userId,
      //         providerId
      //       });
      //     }
      //   }
      // }
  
      return response;
    } catch (error) {
      console.error("Error fetching health diary accounts:", error);
      throw error;
    }
  }
}
