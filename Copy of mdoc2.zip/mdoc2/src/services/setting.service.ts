import {SettingRepository} from '../repositories';
import {repository} from '@loopback/repository';
import {BindingScope, bind} from '@loopback/context';
import { Setting } from '../models';

@bind({scope: BindingScope.CONTEXT})
export class SettingService {
  constructor(
    @repository(SettingRepository)
    public settingRepository: SettingRepository,
  ) {}

    async createSetting(setting: Setting) {
        return this.settingRepository.create(setting);
    }

    async find() {
        return this.settingRepository.find();
    }

    async updateSetting(id: string, setting: Partial<Setting>) {
        return this.settingRepository.updateById(id, setting)
    }

    async findSettingById(id: string) {
        return this.settingRepository.findById(id);
    }
}
