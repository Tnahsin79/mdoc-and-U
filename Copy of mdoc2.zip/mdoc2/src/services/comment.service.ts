import {
  CommentRepository,
  BlogPostRepository,
  CommentReplyRepository,
  NotificationRepository,
} from '../repositories';
import Utils from '../utils';
import {Comment} from '../models';
import {FCMService} from './fcm.service';
import {HttpErrors} from '@loopback/rest';
import {FCMServiceBindings} from '../keys';
import {LikeAndDislike} from '../utils/type';
import {BindingScope, bind, inject} from '@loopback/context';
import {Filter, repository, Where} from '@loopback/repository';

@bind({scope: BindingScope.CONTEXT})
export class CommentService {
  constructor(
    @repository(CommentRepository) public commentRepository: CommentRepository,
    @repository(NotificationRepository)
    public notificationRepository: NotificationRepository,
    @repository(BlogPostRepository)
    public blogPostRepository: BlogPostRepository,
    @repository(CommentReplyRepository)
    public commentReplyRepository: CommentReplyRepository,
    @inject(FCMServiceBindings.FCM_SERVICE) public fcmServices: FCMService,
  ) {}

  async create(comment: Omit<Comment, 'id'>) {
    const commentDetail = await this.commentRepository.create(comment);
    if (comment.replyToCommentId) {
      await this.commentReplyRepository.create({
        userId: commentDetail.userId,
        replyCommentId: commentDetail.id,
        parentCommentId: commentDetail.replyToCommentId,
        created_at: new Date().toString(),
        modified_at: new Date().toString(),
      });
      const repliedComment = await this.commentRepository.findById(
        comment.replyToCommentId,
      );
      if (repliedComment) {
        const totalReplies = (repliedComment.totalReplies || 0) + 1;
        await this.commentRepository.updateById(repliedComment.id, {
          totalReplies,
        });
      }
    }
    const result = await this.commentRepository.findOne({
      where: {
        id: commentDetail.id,
      },
      include: [
        {
          relation: 'user',
          scope: {
            fields: {
              id: true,
              name: true,
              image: true,
              city: true,
              country: true,
              phone: true,
            },
          },
        },
        {
          relation: 'coach',
          scope: {
            fields: {
              id: true,
              name: true,
              image: true,
            },
          },
        },
      ],
    });
    if (result && result.blogPostId) {
      const postData = await this.blogPostRepository.findOne({
        where: {id: result.blogPostId},
        include: [
          {
            relation: 'user',
            scope: {
              fields: {
                id: true,
                name: true,
                image: true,
                city: true,
                country: true,
                phone: true,
                fcmToken: true,
                isPushNotification: true,
              },
            },
          },
        ],
      });
      if (postData && postData.creatorId) {
        const notification = {
          title: 'New Comment',
          message:
            (result &&
              result.user &&
              result.user.name + ' commented on your post') ||
            'unknown commented on your post',
          userId: postData.creatorId,
          notiObject: {postId: postData.id},
          type: 'postDetail',
        };
        await this.notificationRepository.create(notification);
        if (
          postData &&
          postData.creatorId &&
          postData.creator.fcmToken &&
          postData.creator.isPushNotification
        ) {
          var message = {
            to: postData.creator && postData.creator.fcmToken,
            data: {
              name: (postData.creator && postData.creator.name) || '',
              userId: postData.creatorId,
              postId: postData.id,
              type: 'postDetail',
            },
            notification: {
              title: 'New Comment',
              body:
                (result &&
                  result.user &&
                  result.user.name + ' commented on your post') ||
                'unknown commented on your post',
              priority: 'high',
              sound: 'default',
              vibrate: true,
            },
          };
          await this.fcmServices.sendNotification({message: message});
        }
      }
    }
    return result;
  }

  async count(where?: Where<Comment>) {
    return await this.commentRepository.count(where);
  }

  async updateById(id: string, comment: Comment): Promise<void> {
    return await this.commentRepository.updateById(id, comment);
  }

  async deleteById(id: string): Promise<void> {
    return await this.commentRepository.deleteById(id);
  }

  async createComment(comment: Omit<Comment, 'id'>) {
    try {
      const seen: string[] = [];
      if (comment.userId) seen.push(comment.userId);
      if (comment.coachId) seen.push(comment.coachId);
      const newComment = await this.commentRepository.create({...comment, seen});
      return {
        status: 'success',
        newComment,
      };
    } catch (error) {
      return {
        status: 'failed',
        error,
      };
    }
  }


  async updateCommentReaders({
    commentId,
    userId,
  }: {
    commentId: string;
    userId: string;
  }): Promise<Comment> {
    const comment = await this.commentRepository.findById(commentId, {
      include: [{relation: 'forum'}]
    });
    if (comment) {
      const seen = [...(comment.seen || []), userId];
      await this.commentRepository.updateById(commentId, {seen});
      comment.seen = seen;
      return comment;
    }
  }

  async find(
    id: string,
    filter: Filter<Comment>,
    page: number,
    reverse: boolean,
  ) {
    const limit = Utils.getLimit(filter?.limit);
    const pageNum = page ? page : 1;
    const skip = (pageNum - 1) * limit;
    const where = {
      or: [{postId: id}, {forumId: id}],
      replyToCommentId: '',
    };
    const count = await this.commentRepository.count(where);
    const skipCount = Math.max(0, count.count - limit * pageNum);
    const endLimit = Math.min(limit, count.count - limit * (pageNum - 1));
    const content = await this.commentRepository.find({
      where,
      include: [
        {
          relation: 'blogPost',
          scope: {
            fields: {
              id: true,
              text: true,
              imageUrl: true,
              creatorId: true,
            },
            include: [
              {
                relation: 'creator',
                scope: {
                  fields: {
                    id: true,
                    name: true,
                    image: true,
                  },
                },
              },
            ],
          },
        },
        {
          relation: 'user',
          scope: {
            fields: {
              id: true,
              name: true,
              image: true,
            },
          },
        },
        {
          relation: 'replies',
          scope: {
            fields: {
              id: true,
              replyCommentId: true,
            },
            include: [
              {
                relation: 'replyComment',
                scope: {
                  include: [
                    {
                      relation: 'user',
                      scope: {fields: {id: true, name: true, image: true}},
                    },
                  ],
                },
              },
            ],
          },
        },
      ],
      limit: reverse ? endLimit : limit,
      skip: reverse ? skipCount : skip,
      order: reverse ? undefined : ['created_at DESC', 'created DESC'],
    });
    const totalPages = Math.ceil(count.count / limit);
    return {
      data: content,
      count: count.count,
      totalPages,
      currentPage: page,
      status: 'success',
    };
  }

  async getCommentReplies(id: string) {
    return await this.commentRepository.find({
      where: {
        replyToCommentId: id,
      },
      include: [
        {
          relation: 'coach',
          scope: {
            fields: {
              id: true,
              name: true,
              image: true,
            },
          },
        },
        {
          relation: 'user',
          scope: {
            fields: {
              id: true,
              name: true,
              image: true,
            },
          },
        },
        {
          relation: 'replies',
          scope: {
            fields: {
              id: true,
              replyCommentId: true,
            },
            include: [
              {
                relation: 'replyComment',
                scope: {
                  include: [
                    {
                      relation: 'user',
                      scope: {fields: {id: true, name: true, image: true}},
                    },
                  ],
                },
              },
            ],
          },
        },
      ],
    });
  }

  async findById(id: string) {
    const response = await this.commentRepository.findById(id, {
      fields: {
        id: true,
        comment: true,
        created_at: true,
        modified_at: true,
        blogPostId: true,
        userId: true,
      },
      include: [
        {
          relation: 'post',
          scope: {
            fields: {
              id: true,
              text: true,
              image: true,
              userId: true,
            },
            include: [
              {
                relation: 'user',
                scope: {
                  fields: {
                    id: true,
                    name: true,
                    image: true,
                  },
                },
              },
            ],
          },
        },
        {
          relation: 'user',
          scope: {
            fields: {
              id: true,
              name: true,
              image: true,
            },
          },
        },
        {
          relation: 'replies',
          scope: {
            fields: {
              id: true,
              replyCommentId: true,
            },
            include: [
              {
                relation: 'replyComment',
                scope: {
                  include: [
                    {
                      relation: 'user',
                      scope: {fields: {id: true, name: true, image: true}},
                    },
                  ],
                },
              },
            ],
          },
        },
      ],
    });
    return response;
  }

  async addLike(like: LikeAndDislike) {
    const comment = await this.commentRepository.findById(like.commentId);
    if (!comment) {
      throw new HttpErrors.NotFound('Comment not found');
    }
    if (comment.likes.includes(like.userId)) {
      throw new HttpErrors.BadRequest('You can not like a comment twice');
    } else {
      try {
        comment.likes.push(like.userId);
        return await this.commentRepository.update(comment);
      } catch (error) {
        throw new HttpErrors.BadRequest(error.message);
      }
    }
  }

  async addDisLike(dislike: LikeAndDislike) {
    const comment = await this.commentRepository.findById(dislike.commentId);
    if (!comment) {
      throw new HttpErrors.NotFound('Comment not found');
    }
    if (comment.dislikes.includes(dislike.userId)) {
      throw new HttpErrors.BadRequest('You can not dislike a comment twice');
    } else {
      try {
        comment.dislikes.push(dislike.userId);
        return await this.commentRepository.update(comment);
      } catch (error) {
        throw new HttpErrors.BadRequest(error.message);
      }
    }
  }
}
