import { bind, BindingScope, inject } from '@loopback/core';
import { repository, AnyObject } from '@loopback/repository';
import { CoachRepository, ExerciseTypesRepository, EyeExaminationRepository, FootExaminationRepository, HealthDiaryRepository, OutlierLogsRepository, ProjectsCategoryRepository, UserDoctorsRepository, UserPhamacyRecordsRepository, UsersRepository } from '../repositories';
import moment from 'moment';
import * as _ from 'lodash';
import csv from 'csvtojson';
var fs = require('fs');
@bind({ scope: BindingScope.TRANSIENT })
export class HealthDairyMigrationService {
  constructor(
    @repository(UsersRepository) public usersRepository: UsersRepository,
    @repository(HealthDiaryRepository) public healthDiaryRepository: HealthDiaryRepository,
    @repository(EyeExaminationRepository) public eyeExaminationRepository: EyeExaminationRepository,
    @repository(FootExaminationRepository) public footExaminationRepository: FootExaminationRepository
  ) { }

  async healthDairyBloodPressureMigration(): Promise<any> {

    const filePath = './public/blood_pressure_history.csv'

    let results = await csv().fromFile(filePath);
    if (results && results.length) {
      for (let [index, data] of results.entries()) {

        let payload: AnyObject = {
          providerId: data.providerid,
          type: "bloodPressure",
          bloodPressure: {
            systolic: data?.systolic || "",
            diastolic: data?.diastolic || "",
            date: moment(data.date, 'DD-MM-YYYY').toISOString()
          },
          isHealthDiaryCompleted: true,
          created: moment(data.created_date, 'DD-MM-YYYY').toISOString(),
        }

        const result = await this.usersRepository.findOne({ where: { providerId: data.providerid } })
        if (result && result.id) {
          payload.userId = result?.id || ""
          await this.healthDiaryRepository.create(payload)
          if (results.length === index + 1) {
            // fs.unlinkSync(filePath)
            this.healthDairyBMIMigration()
          }
        }
      }
    } else {
      this.healthDairyBMIMigration()
    }
  }

  async healthDairyBMIMigration(): Promise<any> {

    const filePath = './public/bmi_history.csv'

    let results = await csv().fromFile(filePath);
    if (results && results.length) {
      for (let [index, data] of results.entries()) {
        let payload: AnyObject = {
          providerId: data.providerid,
          type: "bmi",
          bmi: {
            value: data?.bmi || "",
            message: "",
            goal: "0",
            date: moment(data.date, 'YYYY-MM-DD').toISOString()
          },
          isHealthDiaryCompleted: true,
          created: moment(data.created_date, 'YYYY-MM-DD').toISOString(),
        }

        const result = await this.usersRepository.findOne({ where: { providerId: data.providerid } })
        if (result && result.id) {
          payload.userId = result?.id || ""
          await this.healthDiaryRepository.create(payload)
          if (results.length === index + 1) {
            // fs.unlinkSync(filePath)
            this.healthDairyCholesterolMigration()
          }
        }
      }
    } else {
      this.healthDairyCholesterolMigration()
    }
  }

  async healthDairyCholesterolMigration(): Promise<any> {
    const filePath = './public/cholesterol_tracker.csv'

    let results = await csv().fromFile(filePath);
    if (results && results.length) {
      for (let [index, data] of results.entries()) {

        let payload: AnyObject = {
          providerId: data.providerid,
          type: "cholesterol",
          cholesterol: {
            cholesterol: data?.min_chole || "",
            triglycerides: data?.min_trigl || "",
            hdl: data?.min_hdl || "",
            ldl: data?.min_ldl || "",
            date: moment(data.chol_date, 'YYYY-MM-DD').toISOString()
          },
          isHealthDiaryCompleted: true,
          created: moment(data.created_date, 'YYYY-MM-DD').toISOString(),
        }
        const result = await this.usersRepository.findOne({ where: { providerId: data.providerid } })
        if (result && result.id) {
          payload.userId = result?.id || ""
          await this.healthDiaryRepository.create(payload)
          if (results.length === index + 1) {
            // fs.unlinkSync(filePath)
            this.healthDairyExerciseMigration()
          }
        }
      }
    } else {
      this.healthDairyExerciseMigration()
    }
  }

  async healthDairyExerciseMigration(): Promise<any> {
    const filePath = './public/exercise_history.csv'

    let results = await csv().fromFile(filePath);
    if (results && results.length) {
      for (let [index, data] of results.entries()) {
        let payload: AnyObject = {
          providerId: data.providerId,
          type: "exercise",
          exercise: {
            duration: data?.exercise_duration || "",
            intensity: data?.exercise_intens || "",
            exerciseName: "",
            date: moment(data.date_of_exercise, 'YYYY-MM-DD').toISOString(),
            created: moment(data.date_of_exercise, 'YYYY-MM-DD').toISOString()
          },
          isHealthDiaryCompleted: true,
          created: moment(data.created_date, 'YYYY-MM-DD').toISOString(),
        }

        const result = await this.usersRepository.findOne({ where: { providerId: data.providerId } })
        if (result && result.id) {
          payload.userId = result?.id || ""
          await this.healthDiaryRepository.create(payload)
          if (results.length === index + 1) {
            // fs.unlinkSync(filePath)
            this.healthDairyEyeMigration()
          }
        }
      }
    } else {
      this.healthDairyEyeMigration()
    }
  }

  async healthDairyEyeMigration(): Promise<any> {
    const filePath = './public/eye_exam_record.csv'

    let results = await csv().fromFile(filePath);
    if (results && results.length) {
      for (let [index, data] of results.entries()) {
        let payload: AnyObject = {
          providerId: data.providerId,
          name: data?.providername || "",
          address: data?.location,
          isEyeExaminationComplete: true,
          testDate: moment(data.lastexamdate, 'YYYY-MM-DD').toISOString(),
          created: moment(data.created_date, 'YYYY-MM-DD').toISOString(),
        }
        const result = await this.usersRepository.findOne({ where: { providerId: data.providerId } })
        if (result && result.id) {
          payload.userId = result?.id || ""
          await this.eyeExaminationRepository.create(payload)
          if (results.length === index + 1) {
            // fs.unlinkSync(filePath)
            this.healthDairyFootMigration()
          }
        }
      }
    } else {
      this.healthDairyFootMigration()
    }
  }

  async healthDairyFootMigration(): Promise<any> {

    const filePath = './public/foot_exam_record.csv'
    let results = await csv().fromFile(filePath);
    if (results && results.length) {
      for (let [index, data] of results.entries()) {
        let payload: AnyObject = {
          providerId: data.providerId,
          name: data?.providername || "",
          address: data?.location,
          isFootExaminationComplete: true,
          testDate: moment(data.lastexamdate, 'YYYY-MM-DD').toISOString(),
          created: moment(data.created_date, 'YYYY-MM-DD').toISOString(),
        }

        const result = await this.usersRepository.findOne({ where: { providerId: data.providerId } })
        if (result && result.id) {
          payload.userId = result?.id || ""
          await this.footExaminationRepository.create(payload)
          if (results.length === index + 1) {
            // fs.unlinkSync(filePath)
            this.healthDairyPSAMigration()
          }
        }
      }
    } else {
      this.healthDairyPSAMigration()
    }
  }

  async healthDairyWaistMigration(): Promise<any> {
    const filePath = './public/waist_circumfrence.csv'
    let results = await csv().fromFile(filePath);

    if (results && results.length) {
      for (let [index, data] of results.entries()) {

        let payload: AnyObject = {
          providerId: data.providerid,
          type: "waist",
          waist: {
            value: data?.waist || "",
            unit: "cm",
            goal: "0",
            date: moment(data.waist_date, 'YYYY-MM-DD').toISOString()
          },
          isHealthDiaryCompleted: true,
          created: moment(data.created_date, 'YYYY-MM-DD').toISOString(),
        }

        const result = await this.usersRepository.findOne({ where: { providerId: data.providerid } })
        if (result && result.id) {
          payload.userId = result?.id || ""
          await this.healthDiaryRepository.create(payload)
          if (results.length === index + 1) {
            // fs.unlinkSync(filePath)
            this.healthDairyBloodPressureMigration()
          }
        }
      }
    } else {
      this.healthDairyBloodPressureMigration()
    }
  }

  async healthDairyWeightMigration(): Promise<any> {

    const filePath = './public/weight_diary.csv'
    let data = await csv().fromFile(filePath);

    if (data && data.length) {

      for (let [index, value] of data.entries()) {

        let payload: AnyObject = {
          providerId: value.providerid,
          type: "weight",
          weight: {
            value: value?.weight || "",
            unit: "Kilogram",
            goal: "0",
            date: moment(value.date, 'YYYY-MM-DD').toISOString()
          },
          isHealthDiaryCompleted: true,
          created: moment(value.created_date, 'YYYY-MM-DD').toISOString(),
        }

        const result = await this.usersRepository.findOne({ where: { providerId: value.providerid } })
        if (result && result.id) {
          payload.userId = result?.id || ""
          await this.healthDiaryRepository.create(payload)
          if (data.length === index + 1) {
            // fs.unlinkSync(filePath)
            this.healthDairyUpdateWeightGoalMigration()
          }
        }
      }
    } else {
      this.healthDairyUpdateWeightGoalMigration()
    }
  }

  async healthDairyUpdateWeightGoalMigration(): Promise<any> {
    let obj: AnyObject = {}
    const filePath = './public/weight_goal.csv'
    let data = await csv().fromFile(filePath);
    if (data && data.length) {
      for (let [index, value] of data.entries()) {
        let result: any = await this.healthDiaryRepository.findOne({ where: { providerId: value.providerid, type: 'weight' } })
        if (result && result.id) {
          obj = Object.assign({}, result)
          result.weight.goal = value?.goal || "0"

          await this.healthDiaryRepository.updateById(result.id, result).then(res => {

          }).catch(err => {
            console.log(err, '=======================error');

          })
          if (data.length === index + 1) {
            // fs.unlinkSync(filePath)
            this.healthDairyGlucoseMigration()
          }
        }
      }
    } else {
      this.healthDairyGlucoseMigration()
    }
  }

  async healthDairyGlucoseMigration(): Promise<any> {
    const filePath = './public/sugar_tracker.csv'
    let result = await csv().fromFile(filePath);
    if (result && result.length) {
      for (let [index, data] of result.entries()) {
        if (data && data.mealtype === "Breakfast" || data.mealtype === "Lunch" || data.mealtype === "Dinner" || data.mealtype === "Snaks") {
          let existResult: any = await this.healthDiaryRepository.findOne({
            where: { providerId: data.providerid, type: 'glucose' }
          })
          if (existResult && existResult.id) {

            existResult.glucose.date = moment(data.date, 'YYYY-MM-DD').toISOString()
            if (data.mealtype === "Breakfast") {
              existResult.glucose.breakfast = {
                "before": data?.before_meal || "0",
                "after": data?.after_meal || "0"
              }
            }
            else if (data.mealtype === "Lunch") {
              existResult.glucose.lunch = {
                "before": data?.before_meal || "0",
                "after": data?.after_meal || "0"
              }
            }
            else if (data.mealtype === "Dinner") {
              existResult.glucose.dinner = {
                "before": data?.before_meal || "0",
                "after": data?.after_meal || "0"
              }
            }
            else if (data.mealtype === "Snaks") {
              existResult.glucose.snacks = {
                "before": data?.before_meal || "0",
                "after": data?.after_meal || "0"
              }
            }
            await this.healthDiaryRepository.updateById(existResult.id, existResult)


            if (result.length === index + 1) {
              // fs.unlinkSync(filePath)
              this.healthDairyWaistMigration()
            }
          }
          else {
            let payload: AnyObject = {
              providerId: data.providerid,
              type: "glucose",
              isHealthDiaryCompleted: true,
              glucose: {
                unit: data?.selected_unit,
                date: moment(data.date, 'YYYY-MM-DD').toISOString(),
                breakfast: {
                  "before": "0",
                  "after": "0",
                },
                lunch: {
                  "before": "0",
                  "after": "0"
                },
                dinner: {
                  "before": "0",
                  "after": "0"
                },
                snacks: {
                  "before": "0",
                  "after": "0"
                }
              }
            }
            if (data.mealtype === "Breakfast") {
              payload.glucose.breakfast = {
                "before": data?.before_meal || "0",
                "after": data?.after_meal || "0"
              }
            }
            else if (data.mealtype === "Lunch") {
              payload.glucose.lunch = {
                "before": data?.before_meal || "0",
                "after": data?.after_meal || "0"
              }
            }
            else if (data.mealtype === "Dinner") {
              payload.glucose.dinner = {
                "before": data?.before_meal || "0",
                "after": data?.after_meal || "0"
              }
            }
            else if (data.mealtype === "Snaks") {
              payload.glucose.snacks = {
                "before": data?.before_meal || "0",
                "after": data?.after_meal || "0"
              }
            }
            const user = await this.usersRepository.findOne({ where: { providerId: data.providerid } })
            if (user && user.id) {
              payload.userId = user.id
              await this.healthDiaryRepository.create(payload)
              if (result.length === index + 1) {
                // fs.unlinkSync(filePath)
                // this.healthDairyWaistMigration()
              }
            }
          }
        } else {
          if (result.length === index + 1) {
            this.healthDairyWaistMigration()
          }
        }
      }
    } else {
      this.healthDairyWaistMigration()
    }
  }

  async healthDairyPSAMigration(): Promise<any> {
    const filePath = './public/psa_records.csv'
    let results = await csv().fromFile(filePath);
    if (results && results.length) {
      for (let [index, data] of results.entries()) {

        let payload: AnyObject = {
          providerId: data.providerid,
          type: "psa",
          psa: {
            totalPSA: data?.free_psa || "",
            freePSA: data?.test_result || "",
            date: moment(data.date_lab, 'DD-MM-YYYY').toISOString()
          },
          isHealthDiaryCompleted: true,
          created: moment(data.created_date, 'DD-MM-YYYY').toISOString(),
        }
        const result = await this.usersRepository.findOne({ where: { providerId: data.providerid } })
        if (result && result.id) {
          payload.userId = result?.id || ""
          await this.healthDiaryRepository.create(payload)
          if (results.length === index + 1) {
            // fs.unlinkSync(filePath)
            this.healthDairyWaistMigration()
          }
        }
      }
    } else {
      this.healthDairyWaistMigration()
    }
  }
}
