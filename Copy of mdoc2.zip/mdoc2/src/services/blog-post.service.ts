import _ from 'lodash';
import {
  LikeRepository,
  UsersRepository,
  CommentRepository,
  InterestRepository,
  BlogPostRepository,
} from '../repositories';
import moment from 'moment';
import multer from 'multer';
import Utils from '../utils';
import * as path from 'path';
import {BlogPost} from '../models';
import {OrderEnum} from '../utils/enums';
import {Request, Response} from '@loopback/rest';
import {PaginatedResponse} from '../type-schema';
import {ControllerServiceBindings} from '../keys';
import {ControllerService} from './controller.service';
import {Filter, repository} from '@loopback/repository';
import {UserProfile, securityId} from '@loopback/security';
import {BindingScope, bind, inject} from '@loopback/context';

@bind({scope: BindingScope.CONTEXT})
export class BlogPostService {
  configOption = Utils.getSiteOptions();

  constructor(
    @repository(BlogPostRepository)
    public blogPostRepository: BlogPostRepository,
    @inject(ControllerServiceBindings.CONTROLLER_SERVICE)
    public controllerService: ControllerService,
    @repository(LikeRepository) public likeRepository: LikeRepository,
    @repository(CommentRepository) public commentRepository: CommentRepository,
    @repository(InterestRepository)
    public interestRepository: InterestRepository,
    @repository(UsersRepository) public usersRepository: UsersRepository,
  ) {}

  async checkSlug(request: any) {
    if (request.body?.slug) {
      const getSlug = this.createSlug(request.body.slug, false);
      const slugExist = await this.findBySlug(getSlug);
      if (slugExist) {
        return new Promise((resolve, reject) => reject('Slug already exists'));
      }
      return new Promise((resolve, reject) => {
        resolve(getSlug);
      });
    } else {
      const slug = this.createSlug(request.body.title, true);
      return new Promise((resolve, reject) => {
        resolve(slug);
      });
    }
  }

  async create(request: Request, response: Response, currentUser: UserProfile) {
    const maxFileSize =
      this.configOption.maxFileSize.oneMB *
      this.configOption.maxFileSize.quantity;

    const upload = multer({
      storage: multer.memoryStorage(),
      fileFilter: function(req: any, file: any, cb: any) {
        let ext = path.extname(file.originalname);
        cb(null, true);
      },
      limits: {fileSize: maxFileSize},
    });
    return new Promise<object>(async (resolve, reject) => {
      upload.any()(request, response, (err: unknown) => {
        if (err) reject(err);
        else {
          this.checkSlug(request)
            .then(async (slugValue: string) => {
              this.controllerService
                .uploadImageHelper(request.files, 'complete_health_blog_post')
                .then(async res => {
                  if (res) {
                    const {
                      title,
                      status,
                      order,
                      description,
                      content,
                      displayDate = new Date(),
                    } = request.body;
                    const blogPost = await this.blogPostRepository.create({
                      title,
                      status,
                      imageUrl: (res as unknown) as string,
                      creatorId: currentUser[securityId],
                      description,
                      content,
                      displayDate,
                      slug: slugValue,
                      order,
                      created_at: new Date().toString(),
                      modified_at: new Date().toString(),
                    });
                    resolve(blogPost);
                  }
                });
            })
            .catch(err => {
              console.log(err);
              return response.json({message: err});
            });
        }
      });
    });
  }

  createSlug(title: string, addDate?: boolean) {
    const sanitizedTitle = title
      .toLowerCase()
      .replace(/[^a-z0-9\s-]/g, '')
      .trim()
      .replace(/\s+/g, '-');
    const slug = addDate
      ? `${sanitizedTitle}-${moment(new Date()).format(
          'YYYY-MM-DD-HH-MM-SS-SSS',
        )}`
      : `${sanitizedTitle}`;
    return slug;
  }

  async find(
    order: OrderEnum = OrderEnum.DESC,
    search?: string,
    filter?: Filter<BlogPost>,
    page?: number,
    startDate?: string,
    endDate?: string,
  ): Promise<PaginatedResponse<BlogPost>> {
    const where = filter?.where || {};
    const limit = Utils.getLimit(filter?.limit);
    const pageNum = page ? page : 1;
    const skip = (pageNum - 1) * limit;
    if (startDate && endDate) {
      const _startDate = moment(startDate)
        .utc()
        .toDate();
      const _endDate = moment(endDate)
        .utc()
        .toDate();
      where['created_at'] = {between: [_startDate, _endDate]};
    }

    if (startDate && !endDate) {
      const _startDate = moment(startDate)
        .utc()
        .toDate();
      where['created_at'] = {gte: _startDate};
    }

    if (endDate && !startDate) {
      const _endDate = moment(endDate)
        .utc()
        .toDate();
      where['created_at'] = {lte: _endDate};
    }

    if (search) {
      where['or'] = [
        {title: {regexp: new RegExp('.*' + search + '.*', 'i')}},
        {description: {regexp: new RegExp('.*' + search + '.*', 'i')}},
        {content: {regexp: new RegExp('.*' + search + '.*', 'i')}},
      ];
    }

    const content = await this.blogPostRepository.find({
      where,
      fields: {
        id: true,
        title: true,
        description: true,
        imageUrl: true,
        status: true,
        creatorId: true,
        displayDate: true,
        slug: true,
        created_at: true,
        modified_at: true,
      },
      include: [
        {
          relation: 'creator',
          scope: {
            fields: {
              id: true,
              name: true,
              image: true,
              email: true,
              phoneNumber: true,
            },
          },
        },
      ],
      order: [`created_at ${order}`],
      skip,
      limit,
    });
    const count = await this.blogPostRepository.count(filter?.where);
    const totalPages = Math.ceil(count.count / limit);

    return {
      data: content,
      count: count.count,
      totalPages,
      currentPage: page,
      status: 'success',
    };
  }

  async findById(id: string, filter?: Filter<BlogPost>): Promise<BlogPost> {
    const postDetails = await this.blogPostRepository.findById(id, {
      where: {...filter?.where},
      include: [
        {
          relation: 'creator',
          scope: {
            fields: {
              id: true,
              name: true,
              image: true,
              email: true,
              phoneNumber: true,
            },
          },
        },
        {
          relation: 'likes',
          scope: {
            fields: {
              id: true,
            },
          },
        },
        {
          relation: 'comments',
          scope: {
            fields: {
              id: true,
            },
          },
        },
      ],
    });
    if (postDetails) {
      const read = (postDetails?.read || 0) + 1;
      postDetails.read = read;
      await this.blogPostRepository.updateById(postDetails.id, {
        read
      });
    }
    return postDetails;
  }

  async updateById(id: string, post: BlogPost): Promise<any> {
    const updateBlogPost = await this.blogPostRepository.updateById(id, post);
    return updateBlogPost;
  }

  async bulkUpdate(payload: Array<{id: string; order: number}>): Promise<void> {
    for (const item of payload) {
      await this.blogPostRepository.updateById(item.id, {order: item.order});
    }
  }

  async deleteById(id: string): Promise<void> {
    const deleteBlogPost = await this.blogPostRepository.deleteById(id);
    return deleteBlogPost;
  }

  async findBySlug(slug: string) {
    const postDetails = await this.blogPostRepository.findOne({
      where: {or: [{slug}, {id: slug}]},
      include: [
        {
          relation: 'creator',
          scope: {
            fields: {
              id: true,
              name: true,
              email: true,
              phoneNumber: true,
            },
          },
        },
        {
          relation: 'likes',
          scope: {
            fields: {
              id: true,
            },
          },
        },
        {
          relation: 'comments',
          scope: {
            fields: {
              id: true,
            },
          },
        },
      ],
    });

    if (postDetails) {
      const read = (postDetails?.read || 0) + 1;
      postDetails.read = read;
      await this.blogPostRepository.updateById(postDetails.id, {
        read
      });
    }

    return postDetails;
  }
}
