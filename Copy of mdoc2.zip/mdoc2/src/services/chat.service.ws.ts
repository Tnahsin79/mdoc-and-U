import {
  ChatRepository,
  ChatRoomRepository,
  CoachRepository,
  NotificationRepository,
  UsersRepository,
} from '../repositories';
import {repository} from '@loopback/repository';
import {BindingScope, bind, inject} from '@loopback/context';
import {Chat, ChatWithRelations} from '../models';
import {FCMServiceBindings, NotificationServiceBindings} from '../keys';
import {FCMService} from './fcm.service';
import cron from 'node-cron';
import {NotificationService} from './notification.service';
import {NotificationTypeEnum, SenderTypeEnum} from '../type-schema';
import moment from 'moment';
import Utils from '../utils';

@bind({scope: BindingScope.CONTEXT})
export class ChatServiceWs {
  constructor(
    @repository(UsersRepository) public userRepository: UsersRepository,
    @repository(ChatRepository) public chatRepository: ChatRepository,
    @repository(ChatRoomRepository)
    public chatRoomRepository: ChatRoomRepository,
    @repository(NotificationRepository)
    public notificationRepository: NotificationRepository,
    @repository(CoachRepository)
    public coachRepository: CoachRepository,
    @inject(FCMServiceBindings.FCM_SERVICE) public fcmService: FCMService,
  ) {}

  async updateChatReaders({
    chatId,
    userId,
  }: {
    chatId: string;
    userId: string;
  }): Promise<Chat> {
    const chat = await this.chatRepository.findById(chatId, {
      include: [{relation: 'chatRoom'}],
    });
    if (chat) {
      const seen = [...(chat.seen || []), userId];
      await this.chatRepository.updateById(chatId, {seen});
      chat.seen = seen;
      return chat;
    }
  }

  async createNewChat(chat: Omit<Chat, 'id'>): Promise<ChatWithRelations> {
    const newChat = await this.chatRepository.create({
      ...chat,
      seen: [chat.senderId],
    });
    await this.chatRoomRepository.updateById(newChat.chatRoomId, {lastMessageTime: newChat?.created_at})
    const chatRoom = await this.chatRoomRepository.findById(chat.chatRoomId, {
      include: [
        {
          relation: 'receiverCoach',
          scope: {fields: {id: true, name: true, fcmToken: true, image: true}},
        },
      ],
    });
    const result = await this.chatRepository.findById(newChat?.id, {
      include: [
        {
          relation: 'chatRoom',
          scope: {
            include: [
              {
                relation: 'receiverMember',
                scope: {
                  fields: {
                    id: true,
                    firstName: true,
                    lastName: true,
                    image: true,
                  },
                },
              },
              {
                relation: 'receiverCoach',
                scope: {
                  fields: {
                    id: true,
                    firstName: true,
                    lastName: true,
                    image: true,
                  },
                },
              },
            ],
          },
        },
      ],
    });

    const body = newChat.message
      ? Utils.stripHtmlTags(newChat.message)
      : `${newChat?.senderName || 'A user'} sent an attachment.`;
    const title = newChat?.senderName || 'New message';
    const image = newChat?.senderImage;

    const notificationPayload = chatRoom?.receiverIds?.map(item => ({
      userId: item,
      notificationType: NotificationTypeEnum.CHAT,
      resourceId: result?.id,
      title,
      body,
      image,
      notificationObject: result,
    }));
    await this.notificationRepository.createAll(notificationPayload);

    if (newChat?.senderTypeEnum === SenderTypeEnum.COACH) {
      const receivers = await this.userRepository.find({
        where: {id: {inq: chatRoom?.receiverIds || []}},
      });
      const tokens = receivers
        ?.filter(item => !!item.fcmToken)
        .map(user => user?.fcmToken);

      const message = {
        registration_ids: tokens,
        data: {
          type: NotificationTypeEnum.CHAT,
          chat: result,
        },
        notification: {
          title,
          body,
          priority: 'high',
          sound: 'default',
          vibrate: true,
        },
      };
      await this.fcmService.sendNotification({message});
    }
    else {
      const coachToken = chatRoom?.receiverCoach?.fcmToken;
      if (coachToken) {
        const message = {
          registration_ids: [coachToken],
          data: {
            type: NotificationTypeEnum.CHAT,
            chat: result,
          },
          notification: {
            title,
            body,
            priority: 'high',
            sound: 'default',
            vibrate: true,
          },
        };
        await this.fcmService.sendNotification({message});
      }
    }
    return result;
  }

  async createBroadcastMessage(msg, callback) {
    if (msg && typeof msg === 'string') {
      const msgObj: {
        coachId: string;
        timer?: Date;
        users: {id: string; name: string}[];
        message: string;
        senderName: string;
        senderImage: string;
        resourceUrl?: string;
      } = JSON.parse(msg);
      const users = msgObj?.users;
      const timer = msgObj.timer;

      const handleCreate = async (userId, userFullName) => {
        const payload = {
          message: msgObj.message,
          resourceUrl: msgObj.resourceUrl,
          senderCoachId: msgObj.coachId,
          senderId: msgObj.coachId,
          senderTypeEnum: 'coach',
          chatRoomId: '',
          senderName: msgObj.senderName,
          senderImage: msgObj.senderImage,
        };
        const room = await this.chatRoomRepository.findOne({
          where: {
            or: [
              {receiverCoachId: msgObj.coachId, receiverIds: {inq: [[userId]]}},
              {creatorId: msgObj.coachId, receiverIds: {inq: [[userId]]}},
            ],
          },
        });
        if (room) {
          payload.chatRoomId = room.id;
        } else {
          const newRoom = await this.chatRoomRepository.create({
            creatorId: msgObj.coachId,
            receiverIds: [userId],
            type: 'direct',
            receiverMemberId: userId,
            userFullName,
          });
          payload.chatRoomId = newRoom?.id;
        }
        // @ts-ignore
        const chat = await this.createNewChat(payload);
        await this.chatRoomRepository.updateById(payload.chatRoomId, {lastMessageTime: chat?.created_at})
        callback?.(chat, userId);
      };

      if (users.length > 0) {
        if (timer) {
          try {
            const newDate = new Date(timer);
            const day = newDate.getDate();
            const month = newDate.getMonth() + 1;

            const hour = newDate.getHours();
            const minute = newDate.getMinutes();

            cron.schedule(`${minute} ${hour} ${day} ${month} *`, () => {
              users.forEach(async user => {
                handleCreate(user.id, user.name);
              });
            });
          } catch (error) {
            console.log(error);
            return error;
          }
        } else {
          users.forEach(user => {
            handleCreate(user.id, user.name);
          });
        }
      }
    }
  }

  async goOnlineCoach(
    id: string,
    socketId: string,
    callback: (roomIds: string[]) => void,
  ) {
    if (id) {
      await this.coachRepository.updateById(id, {
        isOnline: true,
        lastSeen: moment().toISOString(),
        socketId,
      });
      const rooms = await this.chatRoomRepository.find({
        where: {
          or: [{creatorId: id}, {receiverCoachId: id}],
        },
      });
      const roomIds = rooms.map(item => item.id?.toString());
      callback([...(roomIds || []), id]);
    }
  }

  async goOffline(socketId: string, callback?: (id: string) => void) {
    const coach = await this.coachRepository.findOne({where: {socketId}});
    if (coach) {
      await this.coachRepository.updateById(coach.id, {
        lastSeen: moment().toISOString(),
        isOnline: false,
      });
      callback?.(coach.id);
    }

    const user = await this.userRepository.findOne({where: {socketId}});
    if (user) {
      await this.userRepository.updateById(user.id, {
        lastSeen: moment().toISOString(),
        isOnline: false,
      });
      callback?.(user.id);
    }
  }

  async goOnlineMember(
    id: string,
    socketId: string,
    callback: (ids?: string[]) => void,
  ) {
    if (id) {
      await this.userRepository.updateById(id, {
        isOnline: true,
        lastSeen: moment().toISOString(),
        socketId,
      });
      const rooms = await this.chatRoomRepository.find({
        where: {
          // @ts-ignore
          or: [
            {creatorId: id},
            {receiverMemberId: id},
            {receiverIds: {inq: [[id]]}},
          ],
        },
      });
      const roomIds = rooms.map(item => item.id?.toString());
      callback([...(roomIds || []), id]);
      callback?.();
    }
  }
}
