import {
  BloodPressureRepository,
  ActivityTimelineRepository,
} from '../repositories';
import {HttpErrors} from '@loopback/rest';
import {OutlierServiceBindings} from '../keys';
import {OutlierService} from './outlier.service';
import {HealthMetricsTypeEnum} from '../utils/enums';
import {Filter, repository} from '@loopback/repository';
import {BindingScope, bind, inject} from '@loopback/context';
import {returnValues} from '../utils/health-metrics-functions';
import {PaginatedResponse, activityTypeObj} from '../type-schema';
import {BloodPressure, BloodPressureWithRelations} from '../models';

@bind({scope: BindingScope.CONTEXT})
export class BloodPressureService {
  constructor(
    @inject(OutlierServiceBindings.OUTLIER_SERVICE)
    public outlierService: OutlierService,
    @repository(BloodPressureRepository)
    public bloodPressureRepository: BloodPressureRepository,
    @repository(ActivityTimelineRepository)
    public activityTimelineRepository: ActivityTimelineRepository,
  ) {}

  async create(payload: Omit<BloodPressure, 'id'>): Promise<BloodPressure> {
    if (
      parseInt(payload.systolic) < 70 ||
      parseInt(payload.systolic) > 210 ||
      parseInt(payload.diastolic) < 40 || parseInt(payload.diastolic) > 130
    ) {
      throw new HttpErrors[409]('Please provide a valid value');
    }
    const data = await this.bloodPressureRepository.create(payload);
    await this.activityTimelineRepository.create({
      activityType: activityTypeObj.BLOOD_PRESSURE,
      userId: data.userId,
      metadata: data.id,
    });
    try {
      const minMaxValue = returnValues(HealthMetricsTypeEnum.Blood_Pressure);
      if (
        parseInt(payload.systolic) < minMaxValue.systolic.minCritical ||
        parseInt(payload.systolic) >= minMaxValue.systolic.maxCritical ||
        parseInt(payload.diastolic) < minMaxValue.diastolic.minCritical ||
        parseInt(payload.diastolic) >= minMaxValue.diastolic.maxCritical
      ) {
        const outlier = {
          userId: payload.userId,
          metricType: HealthMetricsTypeEnum.Blood_Pressure,
          metricId: data.id,
          metricValue: `systolic: ${data.systolic}${data.unit}, diastolic: ${data.diastolic}${data.unit}`,
        };
        await this.outlierService.create(outlier);
      }
    } catch (error) {}
    return data;
  }

  async findAll(
    filter: Filter<BloodPressure>,
    page: number,
  ): Promise<PaginatedResponse<BloodPressureWithRelations>> {
    const limit = filter?.limit ? filter?.limit : 25;
    const pageNum = page ? page : 1;
    const skip = (pageNum - 1) * limit;
    const content = await this.bloodPressureRepository.find({
      where: filter?.where,
      include: [
        {
          relation: 'coach',
          scope: {
            fields: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              phone: true,
            },
          },
        },
        {
          relation: 'user',
          scope: {
            fields: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              phone: true,
            },
          },
        },
      ],
      order: ['created_at DESC'],
      skip,
      limit,
    });
    const count = await this.bloodPressureRepository.count(filter?.where);
    const totalPages = Math.ceil(count.count / limit);
    return {
      data: content,
      count: count.count,
      totalPages,
      currentPage: page,
      status: 'success',
    };
  }

  async findById(id: string, filter: Filter<BloodPressure>) {
    const data = this.bloodPressureRepository.findById(id, {
      include: [
        {
          relation: 'coach',
          scope: {
            fields: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              phone: true,
            },
          },
        },
        {
          relation: 'user',
          scope: {
            fields: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              phone: true,
            },
          },
        },
      ],
    });
    return data;
  }

  async updateById(id: string, bloodPressure: BloodPressure): Promise<void> {
    const data = await this.bloodPressureRepository.updateById(
      id,
      bloodPressure,
    );
    return data;
  }

  async deleteById(id: string): Promise<void> {
    return await this.bloodPressureRepository.deleteById(id);
  }
}
