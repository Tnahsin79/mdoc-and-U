import {Voucher} from '../models';
import {HttpErrors} from '@loopback/rest';
import {PaymentsRepository, VoucherRepository} from '../repositories';
import {BindingScope, bind} from '@loopback/context';
import {Filter, Where, repository} from '@loopback/repository';
import {VoucherTypeEnum} from '../utils/enums';
import moment from 'moment';

@bind({scope: BindingScope.CONTEXT})
export class VoucherService {
  constructor(
    @repository(VoucherRepository)
    public voucherRepository: VoucherRepository,
    @repository(PaymentsRepository)
    public paymentsRepository: PaymentsRepository,
  ) {}

  async create(payload: Omit<Voucher, 'id'>): Promise<Voucher> {
    const check = await this.voucherRepository.findOne({
      where: {
        code: payload.code,
        programId: payload.programId,
        planId: payload.planId,
      },
    });
    if (check)
      throw new HttpErrors.Conflict('Voucher with this code already exists');
    return await this.voucherRepository.create(payload);
  }

  async voucherCount(where?: Where<Voucher>) {
    return await this.voucherRepository.count(where);
  }

  async findByCode(
    userId: string,
    code: string,
    programId: string,
    planId?: string,
  ) {
    const voucher = await this.voucherRepository.findOne({
      where: {
        code,
        planId: planId ?? null,
        programId: programId ?? null,
        approvalStatus: 'approved',
        status: 'active',
      },
      include: [{relation: 'plan'}, {relation: 'program'}],
    });
    if (!voucher) {
      throw new HttpErrors[409]('Voucher does not exist');
    }
    if (
      voucher.voucherType === VoucherTypeEnum.SINGLE &&
      voucher.createdForUserId?.toString() !== userId
    ) {
      throw new HttpErrors[409]('Voucher does not exist.');
    }

    const existingPayment = await this.paymentsRepository.findOne({
      where: {userId, voucherId: voucher?.id, status: 'success'},
    });
    if (existingPayment) {
      throw new HttpErrors[409]('You have already used this voucher.');
    }
    return voucher;
  }

  async findAll(filter?: Filter<Voucher>) {
    return await this.voucherRepository.find({
      where: filter?.where,
      include: [{relation: 'plan'}, {relation: 'program'}],
    });
  }

  async findById(id: string) {
    return await this.voucherRepository.findById(id);
  }

  async updateById(id: string, voucher: Voucher): Promise<void> {
    return await this.voucherRepository.updateById(id, voucher);
  }

  async deleteById(id: string): Promise<void> {
    return await this.voucherRepository.deleteById(id);
  }
}
