const siteOption = require(`../config/config.json`);
import * as _ from 'lodash';
import moment from 'moment';
import {bucketName} from '../utils/enums';

export function getSiteOptions() {
  return siteOption;
}

export function filterEmailContent(content: any, obj: any) {
  obj = obj || {};
  if (content) {
    const keys = content.match(/\[(.+?)\]/g);
    if (keys?.length) {
      keys.forEach(function(k: any) {
        content = content.replace(k, obj[k.slice(1, -1)]);
      });
    }
    return content;
  } else return false;
}
export function calculateStripeFee(amount: number) {
  const sFees = (amount + 0.3) / ((100 - 2.9) / 100);
  return {total: sFees, fee: sFees - amount};
}

export function getDurationInDays(duration: string) {
  switch (duration) {
    case '1 Month':
      return 1 * 30;
    case '3 Months':
      return 3 * 30;
    case '6 Months':
      return 6 * 30;
    case '12 Months':
      return 12 * 30;
    case 'Free':
      return 0;
    default:
      break;
  }
}

// export function calculateExpirationDate(
//   subscriptionDate: string | undefined,
//   duration: string,
//   previousExpiry?: string,
// ): string {
//   const durationInDays = getDurationInDays(duration);
//   const expirationDate = moment(subscriptionDate).toISOString();
//   if (!previousExpiry) {
//     if (durationInDays) {
//       // expirationDate.setDate(expirationDate.getDate() + durationInDays);
//       moment(subscriptionDate).add(durationInDays, "days").toISOString()
//     }
//     return expirationDate;
//   } else {
//     const previousExpiryDate = moment(previousExpiry).toISOString();
//     if (durationInDays) {
//       // expirationDate.setDate(previousExpiryDate.getDate() + durationInDays);
//       moment(previousExpiryDate).add(durationInDays, "days").toISOString()

//     }
//     return expirationDate;
//   }
// }

export function calculateExpirationDate(
  subscriptionDate: string | undefined,
  duration: string,
  previousExpiry?: Date | null,
): Date | null {
  const durationInDays: number | any = getDurationInDays(duration);
  let expirationDate: Date | null = new Date(subscriptionDate as string);
  if (!previousExpiry) {
    if (durationInDays !== 0) {
      expirationDate.setDate(expirationDate.getDate() + durationInDays);
    } else {
      expirationDate = null;
    }
    return expirationDate;
  } else {
    const previousExpiryDate = new Date(previousExpiry);
    if (durationInDays !== 0) {
      expirationDate.setDate(previousExpiryDate.getDate() + durationInDays);
    } else {
      expirationDate = null;
    }
    return expirationDate;
  }
}

export function getSubscriptionProgram(program: string | any) {
  switch (program) {
    case 'propel':
      return 'Propel';
    case 'weight_management':
      return 'Weight Management and Fitness';
    case 'oncology':
      return 'Oncology';
    case 'mens_wellness':
      return "Men's Wellness";
    case 'womens_wellness':
      return "Women's Wellness";
    case 'behavioural_health':
      return 'Behavioural Health';
    case 'pre_diabetes':
      return 'Pre Diabetes';
    case 'hypertension':
      return 'Hypertension';
    default:
      return 'Propel';
  }
}

export function fnCalculateAge(age) {
  let userAge = moment(age).format('YYYY-MM-DD');
  var userDateinput = userAge;
  var birthDate = new Date(userDateinput);
  var difference = Date.now() - birthDate.getTime();
  var ageDate = new Date(difference);
  var calculatedAge = Math.abs(ageDate.getUTCFullYear() - 1970);
  return calculatedAge;
}

export function getPackageType(type: string) {
  switch (type) {
    case '1 Month':
      return 'Monthly';
    case '3 Months':
      return 'Quarterly';
    case '6 Months':
      return '6 Months';
    case '12 Months':
      return 'Yearly';
    default:
      return '';
  }
}
const getPlanPrice = (plan: string) => {
  switch (plan) {
    case 'Weight Management':
      return 5000;
    case 'Gold Plus':
      return 20000;
    case 'Gold':
      return 10000;
    case 'Silver':
      return 2000;
    case 'Bronze':
      return 500;
    default:
      return 0;
  }
};
function percentageValue(partialValue: number, totalValue: number) {
  return (partialValue / 100) * totalValue;
}

export const calculateAmount = (subscriptionName: string, planName: string) => {
  switch (planName) {
    case '1 Month':
      return getPlanPrice(subscriptionName) * 1;
    case '3 Months':
      return (
        getPlanPrice(subscriptionName) * 3 -
        percentageValue(10, getPlanPrice(subscriptionName) * 3)
      );
    case '6 Months':
      if (subscriptionName.toLowerCase() === 'weight management') {
        return (
          getPlanPrice(subscriptionName) * 6 -
          percentageValue(50, getPlanPrice(subscriptionName) * 6)
        );
      } else {
        return (
          getPlanPrice(subscriptionName) * 6 -
          percentageValue(15, getPlanPrice(subscriptionName) * 6)
        );
      }
    case '12 Months':
      return (
        getPlanPrice(subscriptionName) * 12 -
        percentageValue(20, getPlanPrice(subscriptionName) * 12)
      );
    default:
      return 0;
  }
};

export const crypt = (salt, text) => {
  const textToChars = text => text.split('').map(c => c.charCodeAt(0));
  const byteHex = n => ('0' + Number(n).toString(16)).substr(-2);
  const applySaltToChar = code =>
    textToChars(salt).reduce((a, b) => a ^ b, code);

  return text
    .split('')
    .map(textToChars)
    .map(applySaltToChar)
    .map(byteHex)
    .join('');
};

export const decrypt = (salt, encoded) => {
  const textToChars = text => text.split('').map(c => c.charCodeAt(0));
  const applySaltToChar = code =>
    textToChars(salt).reduce((a, b) => a ^ b, code);
  return encoded
    .match(/.{1,2}/g)
    .map(hex => parseInt(hex, 16))
    .map(applySaltToChar)
    .map(charCode => String.fromCharCode(charCode))
    .join('');
};

export const generateOTP = () => {
  const digits = '0123456789';
  let OTP = '';
  for (let i = 0; i < 5; i++) {
    OTP += digits[Math.floor(Math.random() * 10)];
  }
  return OTP;
};

export function configureBucketName(request: any) {
  const resource = request?.body?.resource;
  if (resource) {
    return new Promise((resolve, reject) => resolve(bucketName[resource]));
  } else {
    return new Promise((resolve, reject) => {
      reject('Not a valid resource type');
    });
  }
}
