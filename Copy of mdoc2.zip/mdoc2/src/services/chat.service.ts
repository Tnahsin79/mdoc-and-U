import multer from 'multer';
import * as path from 'path';
import Utils from '../utils';
import {Request, Response} from '@loopback/rest';
import {ControllerServiceBindings} from '../keys';
import {Chat, ChatWithRelations} from '../models';
import {ControllerService} from './controller.service';
import {Filter, repository} from '@loopback/repository';
import {BindingScope, bind, inject} from '@loopback/context';
import {PaginatedResponse, SenderTypeEnum} from '../type-schema';
import {ChatRepository, ChatRoomRepository} from '../repositories';

@bind({scope: BindingScope.CONTEXT})
export class ChatService {
  configOption: any;
  constructor(
    @repository(ChatRepository) public chatRepository: ChatRepository,
    @repository(ChatRoomRepository)
    public chatRoomRepository: ChatRoomRepository,
    @inject(ControllerServiceBindings.CONTROLLER_SERVICE)
    public controllerService: ControllerService,
  ) {}

  async create(chat: Omit<Chat, 'id'>): Promise<Chat> {
    return await this.chatRepository.create(chat);
  }

  async find(
    filter: Filter<Chat>,
    page: number,
    reverse: boolean = false,
    chatRoomUsers: {coachId: string; userId: string},
  ): Promise<PaginatedResponse<ChatWithRelations>> {
    const limit = Utils.getLimit(filter?.limit);
    const pageNum = page ? page : 1;
    const skip = (pageNum - 1) * limit;
    const where = filter?.where || {};

    // This is used when the admin wants to view the chat history between a member and a coach.
    if (chatRoomUsers) {
      const {coachId, userId} = chatRoomUsers;
      const room = await this.chatRoomRepository.findOne({
        where: {
          or: [
            {
              creatorType: 'coach',
              type: 'direct',
              and: [{creatorId: coachId, receiverIds: {inq: [[userId]]}}],
            },
            {
              creatorType: 'member',
              type: 'direct',
              and: [{creatorId: userId, receiverCoachId: coachId}],
            },
          ],
        },
      });
      if (room) {
        where['chatRoomId'] = room.id;
      } else {
        return {
          data: [],
          count: 0,
          totalPages: 0,
          currentPage: page,
          status: 'success',
        };
      }
    }
    const count = await this.chatRepository.count(where);
    const skipCount = Math.max(0, count.count - limit * pageNum);
    const endLimit = Math.min(limit, count.count - limit * (pageNum - 1));
    const content = await this.chatRepository.find({
      where,
      limit: reverse ? endLimit : limit,
      skip: reverse ? skipCount : skip,
      order: reverse ? undefined : ['created_at DESC'],
    });
    const totalPages = Math.ceil(count.count / limit);

    return {
      data: content,
      count: count.count,
      totalPages,
      currentPage: page,
      status: 'success',
    };
  }

  async getUnreadMessages(id: string, type: SenderTypeEnum): Promise<Chat[]> {
    const where =
      type === SenderTypeEnum.COACH
        ? {or: [{creatorId: id}, {receiverCoachId: id}]}
        : {or: [{creatorId: id}, {receiverIds: {inq: [[id]]}}]};
    const chatRooms = await this.chatRoomRepository.find({
      where,
    });
    const roomIds = chatRooms.map(item => item.id);
    const messages = await this.chatRepository.find({
      where: {
        chatRoomId: {inq: roomIds},
      },
      include: [{relation: 'chatRoom'}]
    });
    const unreadMessages = messages.filter(item => !item.seen?.includes(id));
    return unreadMessages;
  }

  async findById(id: string, filter: Filter<Chat>): Promise<Chat> {
    return await this.chatRepository.findById(id, {
      where: filter?.where,
      include: [
        {
          relation: 'user',
          scope: {
            fields: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              phone: true,
              image: true,
            },
          },
        },
        {
          relation: 'coach',
          scope: {
            fields: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              phone: true,
              image: true,
            },
          },
        },
      ],
    });
  }

  async updateById(id: string, chat: Chat): Promise<void> {
    return await this.chatRepository.updateById(id, chat);
  }

  async uploadFile(request: Request, response: Response) {
    const maxFileSize = 1048576 * 50; // 50 megabytes

    const upload = multer({
      storage: multer.memoryStorage(),
      fileFilter: function(req: any, file: any, cb: any) {
        let ext = path.extname(file.originalname);
        cb(null, true);
      },
      limits: {fileSize: maxFileSize},
    });
    return new Promise<object>(async (resolve, reject) => {
      upload.any()(request, response, (err: unknown) => {
        if (err) reject(err);
        else {
          this.controllerService
            .uploadImageHelper(request.files, 'completehealth_chat_resources')
            .then(async res => {
              if (res) {
                resolve({file: res});
              }
            })
            .catch(err => {
              console.log(err);
              return err;
            });
        }
      });
    });
  }
}
