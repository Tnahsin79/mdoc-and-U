import {
  Bla,
  BlaRecord,
  BlaRecordWithRelations,
  UserSubscriptionsWithRelations,
} from '../models';
import {
  BlaRepository,
  BlaRecordRepository,
  CoachProgramsRepository,
  ActivityTimelineRepository,
  UserSubscriptionsRepository,
  CoachUserSubscriptionsRepository,
} from '../repositories';
import Utils from '../utils';
import {BindingScope, bind} from '@loopback/context';
import {Filter, repository} from '@loopback/repository';
import {ActiveInactiveEnum, activityTypeObj, PaginatedResponse} from '../type-schema';

@bind({scope: BindingScope.CONTEXT})
export class BlaService {
  constructor(
    @repository(BlaRepository) public blaRepository: BlaRepository,
    @repository(BlaRecordRepository)
    public blaRecordRepository: BlaRecordRepository,
    @repository(UserSubscriptionsRepository)
    public userSubscriptionsRepository: UserSubscriptionsRepository,
    @repository(CoachUserSubscriptionsRepository)
    public coachUserSubscriptionsRepository: CoachUserSubscriptionsRepository,
    @repository(CoachProgramsRepository)
    public coachProgramsRepository: CoachProgramsRepository,
    @repository(ActivityTimelineRepository)
    public activityTimelineRepository: ActivityTimelineRepository,
  ) {}

  async create(bla: Omit<Bla, 'id'>) {
    const creatingBlaRecord = await this.blaRecordRepository.create({
      userId: bla.userId,
      programId: bla.programId,
    });
    const data = await this.blaRepository.create({
      ...bla,
      blaRecordId: creatingBlaRecord.id,
    });
    await this.activityTimelineRepository.create({
      activityType: activityTypeObj.BLA,
      userId: data.userId,
      metadata: creatingBlaRecord.id,
      created_at: bla.created_at,
      modified_at: bla.modified_at,
    });
    return data;
  }

  async createBulk(
    blaList: Omit<Bla, 'id'>[],
    userSubscriptionId: string,
  ): Promise<UserSubscriptionsWithRelations> {
    const blaRecord = await this.blaRecordRepository.create({
      userId: blaList[0].userId,
      programId: blaList[0].programId,
    });
    blaList = blaList.map(bla => {
      bla.blaRecordId = blaRecord.id;
      return bla;
    });
    await this.blaRepository.createAll(blaList);
    await this.activityTimelineRepository.create({
      activityType: activityTypeObj.BLA,
      userId: blaList[0].userId,
      metadata: blaRecord.id,
      created_at: blaList[0].created_at || new Date().toString(),
      modified_at: blaList[0].modified_at || new Date().toString(),
    });


      // Assign to a coach here

      // If user has not been assigned a coach already, assign a new coach
      const existingCoach = await this.coachUserSubscriptionsRepository.findOne(
        {
          where: {
            userSubscriptionId,
            status: ActiveInactiveEnum.ACTIVE
          },
        },
      );
      if (!existingCoach) {
        const coaches = await this.coachProgramsRepository.find({
          where: {programId: blaList[0].programId, status: 'active'},
        });
        // Get coach with fewest members
        const coachWithFewestMembers = coaches.reduce((acc, curr) => {
          return curr.totalMembers < acc.totalMembers ? curr : acc;
        }, coaches[0]);
        if (coachWithFewestMembers) {
          await this.coachUserSubscriptionsRepository.create({
            coachId: coachWithFewestMembers.coachId,
            userSubscriptionId,
          });

          await this.coachProgramsRepository.updateById(
            coachWithFewestMembers?.id,
            {totalMembers: (coachWithFewestMembers?.totalMembers || 0) + 1},
          );
          // Notify coach here

          // Assign coach end
        }
      }

    // Return for mobile app
    const userSubscription = await this.userSubscriptionsRepository.findById(
      userSubscriptionId,
      {
        include: [
          {
            relation: 'coach',
            scope: {
              include: [
                {
                  relation: 'coach',
                  scope: {
                    fields: {
                      id: true,
                      name: true,
                      image: true,
                    },
                  },
                },
              ],
            },
          },
          {
            relation: 'program',
            scope: {
              fields: {
                id: true,
                title: true,
              },
            },
          },
          {relation: 'plan'},
          {relation: 'payment'},
        ],
      },
    );

    await this.userSubscriptionsRepository.updateById(userSubscriptionId, {
      blaCount: (userSubscription.blaCount || 0) + 1,
    });

    return userSubscription;
  }

  async findAll(filter: Filter<Bla>) {
    return await this.blaRepository.find({
      where: filter?.where,
      include: [
        {
          relation: 'question',
          scope: {
            include: [{relation: 'options'}],
          },
        },
        {relation: 'option'},
        {relation: 'program'},
        {
          relation: 'user',
          scope: {
            fields: {
              id: true,
              name: true,
              image: true,
            },
          },
        },
      ],
    });
  }

  async findAllBlaRecord(
    filter: Filter<BlaRecord>,
    page: number,
  ): Promise<PaginatedResponse<BlaRecordWithRelations>> {
    const limit = Utils.getLimit(filter?.limit);
    const pageNum = page ? page : 1;
    const skip = (pageNum - 1) * limit;
    const content = await this.blaRecordRepository.find({
      where: filter?.where,
      include: [
        {
          relation: 'blas',
        },
      ],
      limit,
      skip,
    });

    const count = await this.blaRecordRepository.count(filter?.where);
    const totalPages = Math.ceil(count.count / limit);
    return {
      data: content,
      count: count.count,
      totalPages,
      currentPage: page,
      status: 'success',
    };
  }

  async blaRecordById(
    id: string,
    filter: Filter<BlaRecord>,
  ): Promise<BlaRecordWithRelations> {
    const data = await this.blaRecordRepository.findById(id, {
      where: filter?.where,
      include: [
        {
          relation: 'blas',
        },
      ],
    });
    return data;
  }
}
