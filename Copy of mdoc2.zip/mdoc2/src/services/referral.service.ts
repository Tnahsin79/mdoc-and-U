import {
  UserLiteObject,
  ReferralTypeEnum,
  AcceptanceStatusEnum,
} from '../utils/enums';
import {
  AdminRepository,
  CoachRepository,
  UsersRepository,
  ReferralRepository,
} from '../repositories';
import moment from 'moment';
import Utils from '../utils';
import {Referral} from '../models';
import {HttpErrors} from '@loopback/rest';
import {EmailService} from './email.service';
import {PaginatedResponse} from '../type-schema';
import {ControllerService} from './controller.service';
import {Filter, repository} from '@loopback/repository';
import {BindingScope, bind, inject} from '@loopback/context';
import {ControllerServiceBindings, EmailServiceBindings} from '../keys';

@bind({scope: BindingScope.CONTEXT})
export class ReferralService {
  constructor(
    @repository(ReferralRepository)
    public referralRepository: ReferralRepository,
    @repository(AdminRepository)
    public adminRepository: AdminRepository,
    @repository(CoachRepository)
    public coachRepository: CoachRepository,
    @repository(UsersRepository)
    public usersRepository: UsersRepository,
    @inject(EmailServiceBindings.MAIL_SERVICE)
    public emailService: EmailService,
    @inject(ControllerServiceBindings.CONTROLLER_SERVICE)
    public controllerService: ControllerService,
  ) {}

  async create(params: Omit<Referral, 'id'>): Promise<Referral> {
    // TODO: Create a feedback form for a new referral
    const referringCoach = params?.senderCoachId
      ? await this.coachRepository.findById(params?.senderCoachId)
      : await this.adminRepository.findById(params?.adminId);
    const user = await this.usersRepository.findById(params.userId);

    if (!user) {
      throw new HttpErrors[409]('The selected user does not exist');
    }
    const userName =
      user.firstName && user.lastName
        ? `${user.firstName} ${user.lastName}`
        : user.name;

    if (params.referralType === ReferralTypeEnum.INTERNAL) {
      // get coach object
      const coach = await this.coachRepository.findById(params.receiverCoachId);
      if (!coach) {
        throw new HttpErrors[409]('The selected coach does not exist');
      }
      let newInternalReferral: Referral;

      // Check if the user has already been referred to the coach
      const existingReferral = await this.referralRepository.findOne({
        where: {userId: params.userId, receiverCoachId: params.receiverCoachId},
      });

      if (existingReferral) {
        throw new HttpErrors[409](
          'You have already referred this member to the selected coach.',
        );
      } else {
        newInternalReferral = await this.referralRepository.create({
          ...params,
          userFullName: userName,
        });
      }
      // Send email notification of new referral to coach
      await this.emailService.sendMail({
        to: coach.email,
        slug: 'internal_referral_staff',
        message: {
          coachName: coach.firstName,
          patientName: userName,
          patientAge: moment().diff(moment(user.dob), 'years'),
          patientGender: user.gender || 'not-specified',
          note: newInternalReferral?.note,
          referralReason: newInternalReferral.referralReason,
          reasonType: newInternalReferral.reasonType,
          fromCoachName: `${referringCoach?.name}`,
          fromCoachEmail: referringCoach?.email,
          fromCoachPhone:
            referringCoach['phone'] || referringCoach['phoneNumber'],
          patientPhone: user.phone,
          patientEmail: user.email,
        },
      });

      // Send email notification of referral to member
      if (!params?.adminId) {
        if (user?.email)
          await this.emailService.sendMail({
            to: user?.email,
            slug: 'internal_referral_member',
            message: {
              patientName: userName,
              newCoachName: `${coach?.firstName} ${coach?.lastName}`,
              coachName: `${referringCoach?.name}`,
            },
          });
        else {
          const body = `Hi ${user.firstName}, you have been referred by Coach ${referringCoach?.name} from 
         mDoc healthcare to Coach ${coach?.firstName} considering your recent records.`;
          await this.controllerService.sendOtpService(user?.phone, body);
        }
      }

      return newInternalReferral;
    } else {
      const externalReferral = await this.referralRepository.create(params);

      if (externalReferral?.facilityEmail) {
        await this.emailService.sendMail({
          to: externalReferral.facilityEmail,
          slug: 'internal_referral_staff',
          message: {
            patientName: userName,
            patientAge: moment().diff(moment(user.dob), 'years'),
            patientGender: user.gender || 'not-specified',
            note: externalReferral?.note,
            referralReason: externalReferral.referralReason,
            reasonType: externalReferral.reasonType,
            coachName: `${referringCoach?.name}`,
            coachEmail: referringCoach?.email,
            coachPhone:
              referringCoach['phone'] || referringCoach['phoneNumber'],

            patientPhone: user.phone || 'Not specified',
            patientEmail: user.email || 'Not specified',
            coachOrg: 'mDoc Healthcare',
            patientAddress: `${user?.state || 'Not specified'}`,
          },
        });
      }

      return externalReferral;
    }
  }

  async getCoachStatistics(coachId: string) {
    try {
      const referrals = await this.referralRepository.find({
        where: {receiverCoachId: coachId},
      });
      const outbound = await this.referralRepository.find({
        where: {senderCoachId: coachId},
      });
      const totalPending = referrals.filter(
        item => item.acceptanceStatus === AcceptanceStatusEnum.PENDING,
      );
      const totalAccepted = referrals.filter(
        item => item.acceptanceStatus === AcceptanceStatusEnum.ACCEPTED,
      );
      return {
        totalReferrals: referrals?.length,
        totalOutboundReferrals: outbound?.length,
        totalPendingReferrals: totalPending?.length,
        totalAcceptedRefferals: totalAccepted?.length,
      };
    } catch (error) {
      throw new HttpErrors[400](
        'An error occurred. Please check your payload.',
      );
    }
  }

  async find(
    filter?: Filter<Referral>,
    page?: number,
    search?: string,
  ): Promise<PaginatedResponse<Referral>> {
    const where = filter?.where || {};
    const limit = Utils.getLimit(filter?.limit);
    const pageNum = page ? page : 1;
    const skip = (pageNum - 1) * limit;

    let searchString = search;
    if (searchString?.includes('+')) {
      searchString = searchString.replace('+', '');
    }

    if (search) {
      where['userFullName'] = new RegExp('.*' + searchString + '.*', 'i');
    }

    const referrals = await this.referralRepository.find({
      where,
      include: [
        {
          relation: 'user',
          scope: {
            fields: UserLiteObject,
            include: [{relation: 'subscriptions'}],
          },
        },
        {
          relation: 'senderCoach',
          scope: {
            fields: UserLiteObject,
          },
        },
        {
          relation: 'receiverCoach',
          scope: {
            fields: UserLiteObject,
          },
        },
        {
          relation: 'approvedBy',
          scope: {
            fields: {
              id: true,
              name: true,
              firstName: true,
              lastName: true,
              email: true,
            },
          },
        },
      ],
      limit,
      skip,
    });
    const count = await this.referralRepository.count(where);
    const totalPages = Math.ceil(count.count / limit);
    return {
      data: referrals,
      count: count.count,
      totalPages,
      currentPage: page,
      status: 'success',
    };
  }

  async findById(id: string, filter?: Filter<Referral>): Promise<Referral> {
    const referral = await this.referralRepository.findById(id, {
      include: [
        {
          relation: 'user',
          scope: {
            fields: UserLiteObject,
            include: [{relation: 'subscriptions'}],
          },
        },
        {
          relation: 'senderCoach',
          scope: {
            fields: UserLiteObject,
          },
        },
        {
          relation: 'receiverCoach',
          scope: {
            fields: UserLiteObject,
          },
        },
        {
          relation: 'approvedBy',
          scope: {
            fields: {
              id: true,
              name: true,
              email: true,
            },
          },
        },
      ],
    });
    return referral;
  }

  async updateById(id: string, referral: Referral) {
    const udpatingReferral = await this.referralRepository.updateById(
      id,
      referral,
    );
    return udpatingReferral;
  }

  async deleteById(id: string) {
    const deletingReferral = await this.referralRepository.deleteById(id);
    return deletingReferral;
  }
}
