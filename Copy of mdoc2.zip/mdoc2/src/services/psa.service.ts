import {Psa, PsaWithRelations} from '../models';
import {BindingScope, bind} from '@loopback/context';
import {Filter, repository} from '@loopback/repository';
import {PaginatedResponse, activityTypeObj} from '../type-schema';
import {ActivityTimelineRepository, PsaRepository} from '../repositories';

@bind({scope: BindingScope.CONTEXT})
export class PsaService {
  constructor(
    @repository(PsaRepository)
    public psaRepository: PsaRepository,
    @repository(ActivityTimelineRepository)
    public activityTimelineRepository: ActivityTimelineRepository,
  ) {}

  async create(payload: Omit<Psa, 'id'>): Promise<Psa> {
    const data = await this.psaRepository.create(payload);
    await this.activityTimelineRepository.create({
      activityType: activityTypeObj.PSA,
      userId: data.userId,
      metadata: data.id,
    });
    return data;
  }

  async findAll(
    filter: Filter<Psa>,
    page: number,
  ): Promise<PaginatedResponse<PsaWithRelations>> {
    const limit = filter?.limit ? filter?.limit : 25;
    const pageNum = page ? page : 1;
    const skip = (pageNum - 1) * limit;
    const content = await this.psaRepository.find({
      where: filter?.where,
      include: [
        {
          relation: 'coach',
          scope: {
            fields: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              phone: true,
            },
          },
        },
        {
          relation: 'user',
          scope: {
            fields: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              phone: true,
            },
          },
        },
      ],
      order: ['created_at DESC'],
      skip,
      limit,
    });
    const count = await this.psaRepository.count(filter?.where);
    const totalPages = Math.ceil(count.count / limit);
    return {
      data: content,
      count: count.count,
      totalPages,
      currentPage: page,
      status: 'success',
    };
  }

  async findById(id: string, filter: Filter<Psa>) {
    const data = this.psaRepository.findById(id, {
      where: filter?.where,
      include: [
        {
          relation: 'coach',
          scope: {
            fields: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              phone: true,
            },
          },
        },
        {
          relation: 'user',
          scope: {
            fields: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              phone: true,
            },
          },
        },
      ],
    });
    return data;
  }

  async updateById(id: string, psa: Psa): Promise<void> {
    const data = await this.psaRepository.updateById(id, psa);
    return data;
  }

  async deleteById(id: string): Promise<void> {
    return await this.psaRepository.deleteById(id);
  }
}
