import {
  CholestrolRepository,
  ActivityTimelineRepository,
} from '../repositories';
import {HttpErrors} from '@loopback/rest';
import {OutlierServiceBindings} from '../keys';
import {OutlierService} from './outlier.service';
import {HealthMetricsTypeEnum} from '../utils/enums';
import {Filter, repository} from '@loopback/repository';
import {BindingScope, bind, inject} from '@loopback/context';
import {Cholestrol, CholestrolWithRelations} from '../models';
import {returnValues} from '../utils/health-metrics-functions';
import {PaginatedResponse, activityTypeObj} from '../type-schema';

@bind({scope: BindingScope.CONTEXT})
export class CholestrolService {
  constructor(
    @inject(OutlierServiceBindings.OUTLIER_SERVICE)
    public outlierService: OutlierService,
    @repository(CholestrolRepository)
    public cholestrolRepository: CholestrolRepository,
    @repository(ActivityTimelineRepository)
    public activityTimelineRepository: ActivityTimelineRepository,
  ) {}

  async create(payload: Omit<Cholestrol, 'id'>): Promise<Cholestrol> {
    if (
      parseInt(payload.hdl) < 20 ||
      parseInt(payload.hdl) > 100 ||
      parseInt(payload.ldl) < 40 ||
      parseInt(payload.ldl) > 190 ||
      parseInt(payload.triglycerides) < 10 ||
      parseInt(payload.triglycerides) > 1000 ||
      parseInt(payload.cholesterol) < 100 ||
      parseInt(payload.cholesterol) > 400
    ) {
      throw new HttpErrors[409]('Please provide a valid value');
    }
    const data = await this.cholestrolRepository.create(payload);
    await this.activityTimelineRepository.create({
      activityType: activityTypeObj.CHOLESTROL,
      userId: data.userId,
      metadata: data.id,
    });
    try {
      const minMaxValue = returnValues(HealthMetricsTypeEnum.Cholesterol);
      if (
        parseInt(data.hdl) <= minMaxValue.hdl.minCritical ||
        parseInt(data.hdl) >= minMaxValue.hdl.maxCritical ||
        parseInt(data.ldl) <= minMaxValue.ldl.minCritical ||
        parseInt(data.ldl) >= minMaxValue.ldl.maxCritical ||
        parseInt(data.triglycerides) <= minMaxValue.triglycerides.minCritical ||
        parseInt(data.triglycerides) >= minMaxValue.triglycerides.maxCritical ||
        parseInt(data.cholesterol) <= minMaxValue.cholesterol.minCritical ||
        parseInt(data.cholesterol) >= minMaxValue.cholesterol.maxCritical
      ) {
        const outlier = {
          userId: payload.userId,
          metricType: HealthMetricsTypeEnum.Cholesterol,
          metricId: data.id,
          metricValue: `hdl: ${data.hdl}${data.unit}, ldl: ${data.ldl}${data.unit}, triglycerides: ${data.triglycerides}${data.unit}, cholesterol:${data.cholesterol}${data.unit}`,
        };
        await this.outlierService.create(outlier);
      }
    } catch (error) {
      return error;
    }
    return data;
  }

  async findAll(
    filter: Filter<Cholestrol>,
    page: number,
  ): Promise<PaginatedResponse<CholestrolWithRelations>> {
    const limit = filter?.limit ? filter?.limit : 25;
    const pageNum = page ? page : 1;
    const skip = (pageNum - 1) * limit;
    const content = await this.cholestrolRepository.find({
      where: filter?.where,
      include: [
        {
          relation: 'coach',
          scope: {
            fields: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              phone: true,
            },
          },
        },
        {
          relation: 'user',
          scope: {
            fields: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              phone: true,
            },
          },
        },
      ],
      order: ['created_at DESC'],
      skip,
      limit,
    });
    const count = await this.cholestrolRepository.count(filter?.where);
    const totalPages = Math.ceil(count.count / limit);
    return {
      data: content,
      count: count.count,
      totalPages,
      currentPage: page,
      status: 'success',
    };
  }

  async findById(id: string, filter: Filter<Cholestrol>) {
    const data = this.cholestrolRepository.findById(id, {
      where: filter?.where,
      include: [
        {
          relation: 'coach',
          scope: {
            fields: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              phone: true,
            },
          },
        },
        {
          relation: 'user',
          scope: {
            fields: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              phone: true,
            },
          },
        },
      ],
    });
    return data;
  }

  async updateById(id: string, cholestrol: Cholestrol): Promise<void> {
    const data = await this.cholestrolRepository.updateById(id, cholestrol);
    return data;
  }

  async deleteById(id: string): Promise<void> {
    return await this.cholestrolRepository.deleteById(id);
  }
}
