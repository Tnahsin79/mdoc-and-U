import {HttpErrors} from '@loopback/rest';
import {Option, Question} from '../models';
import {repository} from '@loopback/repository';
import {BindingScope, bind} from '@loopback/context';
import {UserFeedbackAnswerRepository} from '../repositories';
import {OptionRepository} from '../repositories/option.repository';
import {QuestionRepository} from '../repositories/question.repository';

@bind({scope: BindingScope.CONTEXT})
export class QuestionService {
  constructor(
    @repository(QuestionRepository)
    public questionRepository: QuestionRepository,
    @repository(UserFeedbackAnswerRepository)
    public userFeedbackAnswerRepository: UserFeedbackAnswerRepository,
    @repository(OptionRepository)
    public optionRepository: OptionRepository,
  ) {}

  async findAll(filter) {
    return await this.questionRepository.find({
      where: filter?.where,
      include: [
        {relation: 'program'},
        {relation: 'options', scope: {
          where: {isDeleted: {neq: true}}
        }},
        {
          relation: 'createdBy',
          scope: {
            fields: {
              id: true,
              name: true,
              email: true,
              image: true,
            },
          },
        },
      ],
    });
  }

  async create({question, options}) {
    const newQuestion = await this.questionRepository.create(question);
    const payload = options.map(option => ({
      ...option,
      questionId: newQuestion.id,
    }));
    await this.optionRepository.createAll(payload);
    return await this.questionRepository.findById(newQuestion.id, {
      include: [{relation: 'options'}],
    });
  }

  async createOption(option) {
    return this.optionRepository.create(option);
  }

  async createQuestionBulk(questions) {
    questions.forEach(async item => {
      const question = await this.questionRepository.create(item.question);
      const options = item.options.map(option => ({
        ...option,
        questionId: question.id,
      }));
      await this.optionRepository.createAll(options);
    });
  }

  async updateQuestion(id: string, question: Partial<Question>) {
    await this.questionRepository.updateById(id, question);
  }

  async updateOption(id: string, option: Partial<Option>) {
    return await this.optionRepository.updateById(id, option);
  }

  async updateOptionBulk(options: Partial<Option>[]) {
    options.forEach(async item => {
      await this.optionRepository.updateById(item.id, item);
    });
  }

  async updateQuestionBulk(questions: {id: string; order: number}[]) {
    try {
      questions.forEach(async item => {
        await this.questionRepository.updateById(item.id, {order: item.order});
      });
    }
    catch (error) {
      throw new HttpErrors[400]("An error occurred while updating the question orders.")
    }
  }

  async deleteOption(id: string) {
    const checking = await this.userFeedbackAnswerRepository.find({
      where: {
        selectedOptionId: id,
      },
    });
    if (checking.length > 0) {
      throw new HttpErrors.Conflict(
        'Can not delete this option as it is being used',
      );
    }
    return await this.optionRepository.updateById(id, {isDeleted: true});
  }

  async deleteQuestion(id: string) {
    try {
      const checking = await this.userFeedbackAnswerRepository.find({
        where: {questionId: id},
      });
      if (checking.length > 0)
        throw new HttpErrors.Conflict(
          'Can not delete this question as it is being used',
        );
      const question = await this.questionRepository.findById(id);
      const questions = await this.questionRepository.find({
        where: {programId: question?.programId},
      });
      const payload = questions
        .filter(item => item.id.toString() !== id)
        .sort((a, b) => a.order - b.order)
        .map((item, index) => ({id: item.id, order: index + 1}));
      payload.forEach(async item => {
        await this.questionRepository.updateById(item.id, {order: item.order});
      });
      await this.questionRepository.deleteById(id);
      await this.optionRepository.deleteAll({questionId: id});
    } catch (error) {
      throw new HttpErrors[400]('An error occurred');
    }
  }
}
