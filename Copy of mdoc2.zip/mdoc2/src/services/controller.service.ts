import {
  UsersRepository,
  ReviewRepository,
  NotificationRepository,
  SubscriptionsRepository,
} from '../repositories';
import * as _ from 'lodash';
import moment from 'moment';
import {format} from 'util';
import dotenv from 'dotenv';
import request from 'request';
import forge from 'node-forge';
import {ObjectID} from 'mongodb';
import {storage} from '../config';
import {EmailServiceBindings} from '../keys';
import {EmailService} from './email.service';
import {bind, BindingScope, inject} from '@loopback/core';
import {repository, AnyObject} from '@loopback/repository';

dotenv.config();

@bind({scope: BindingScope.TRANSIENT})
export class ControllerService {
  constructor(
    @repository(UsersRepository) public usersRepository: UsersRepository,
    @repository(ReviewRepository) public reviewRepository: ReviewRepository,
    @repository(NotificationRepository)
    public notificationRepository: NotificationRepository,
    @repository(SubscriptionsRepository)
    public subscriptionsRepository: SubscriptionsRepository,
    @inject(EmailServiceBindings.MAIL_SERVICE)
    public emailService: EmailService,
  ) {}

  async refreshAverageRating(data: AnyObject): Promise<any> {
    if (data?.userId) {
      const user = await this.usersRepository.findOne({
        where: {
          id: data.userId,
        },
      });

      if (user?.id) {
        if (!this.reviewRepository.dataSource.connected) {
          await this.reviewRepository.dataSource.connect();
        }
        const reviewCollection = (this.reviewRepository.dataSource
          .connector as any).collection('Review');

        await Promise.all([
          reviewCollection
            .aggregate([
              {
                $match: {
                  userId: new ObjectID(String(data.userId)),
                },
              },
              {
                $group: {
                  _id: '$userId',
                  avgRating: {
                    $avg: '$rating',
                  },
                },
              },
            ])
            .get(),
        ])
          .then(async (res: any) => {
            const rating = res?.[0]?.[0]?.avgRating || 0;
            const userObj = {
              rating: rating,
            };
            await this.usersRepository.updateById(data.userId, userObj);
          })
          .catch((err: any) => {
            console.debug(err);
          });
      }
    }
  }
  async calculateBmi(weight: any, height: any) {
    if (weight > 0 && height > 0) {
      const finalBmi = weight / (((height / 100) * height) / 100);
      const bmi: any = Math.round(finalBmi);
      let bmiObj = {};
      if (bmi < 18.5) {
        return (bmiObj = {
          avgBmi: bmi,
          message:
            bmi +
            ' Your BMI is very low.  The normal range is 18.5-25. Please talk to your mDoc team about how to high your BMI into a healther range.',
          date: moment().toISOString(),
        });
      }
      if (bmi > 18.5 && bmi <= 25) {
        return (bmiObj = {
          avgBmi: bmi,
          message: bmi + ' Your BMI is within the normal range of 18.5-25.',
          date: moment().toISOString(),
        });
      }
      if (bmi > 25 && bmi <= 30) {
        return (bmiObj = {
          avgBmi: bmi,
          message:
            bmi +
            ' Your BMI is slightly higher than normal, since it is above 25.',
          date: moment().toISOString(),
        });
      }
      if (bmi > 30 && bmi <= 40) {
        return (bmiObj = {
          avgBmi: bmi,
          message:
            bmi + '  Your BMI is higher than normal, since it is above 25.',
          date: moment().toISOString(),
        });
      }
      if (bmi > 40) {
        return (bmiObj = {
          avgBmi: bmi,
          message:
            bmi +
            ' Your BMI is very high.  The normal range is 18.5-25. Please talk to your mDoc team about how to lower your BMI into a healther range.',
          date: moment().toISOString(),
        });
      }
    }
  }

  async uploadImageOnGoogleCloud(filename: any) {
    const name = filename?.[0]?.filename;
    const destination = filename?.[0]?.destination;
    const file = 'public/images/' + name;

    // return file
    return storage
      .bucket('mdoc_userprofile')
      .upload(file)
      .then(res => {
        if (res?.[0]) {
          return (
            'https://storage.googleapis.com/mdoc_userprofile/' +
            filename[0].filename
          );
        }
        return (
          'https://storage.googleapis.com/mdoc_userprofile/' +
          filename[0].filename
        );
      })
      .catch(err => {
        console.log(err);
      });
  }
  uploadImageHelper = (file, bucketName: string) => {
    const bucket = storage.bucket(bucketName);
    return new Promise((resolve, reject) => {
      const {originalname, buffer} = file[0];
      const blob = bucket.file(originalname.replace(/ /g, '_'));
      const blobStream = blob.createWriteStream({
        resumable: false,
      });
      blobStream
        .on('finish', () => {
          const publicUrl = format(
            `https://storage.googleapis.com/${bucketName}/${blob.name}`,
          );
          resolve(publicUrl);
        })
        .on('error', err => {
          console.log(err);
          reject(`Unable to upload image, something went wrong`);
        })
        .end(buffer);
    });
  };

  async encrypt(key: any, text: any) {
    const cipher = forge.cipher.createCipher(
      '3DES-ECB',
      forge.util.createBuffer(key),
    );
    cipher.start({iv: ''});
    cipher.update(forge.util.createBuffer(text));
    cipher.finish();
    const encrypted = cipher.output;
    return forge.util.encode64(encrypted.getBytes());
  }

  async sendOtpService(phoneNumber: any, message: string): Promise<any> {
    const nigerian1 = phoneNumber.substring(0, 4);
    const nigerian2 = phoneNumber.substring(0, 3);
    const SMS_API_KEY = process.env.SMS_API_KEY; // TODO: set constants on a separate module
    const data: AnyObject = {
      to: phoneNumber,
      sms: message,
      api_key: SMS_API_KEY,
      from: 'mDoc Health',
      type: 'plain',
      channel: 'generic',
    };
    if (nigerian1 === '+234' || nigerian2 === '234') {
      data.channel = 'dnd';
      data.from = 'N-Alert';
    }

    const option = {
      method: 'POST',
      url: 'https://api.ng.termii.com/api/sms/send',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    };

    return new Promise((resolve, reject) => {
      request(option, function(error: any, response: any) {
        if (error) {
          console.log(error);
          reject(error);
        } else {
          if (response?.body) {
            const data = JSON.parse(response.body);
            resolve(data);
          }
        }
      });
    });
  }

  async subscriptionNotification(): Promise<any> {
    let expDate = moment()
      .add(10, 'days')
      .endOf('day')
      .toISOString();
    const _this = this;
    let query: AnyObject = {and: []};
    query.and.push({
      expireDate: {lte: expDate},
    });
    query.and.push({
      expireDate: {
        gte: moment()
          .startOf('day')
          .toISOString(),
      },
    });

    let subs = await this.subscriptionsRepository.find({
      where: query,
    });
    //return
    if (subs && subs.length) {
      let userIds: Array<any> = _.map(subs, v => v.userId);
      // await this.emailService.sendMail(mailOptions)

      let users = await this.usersRepository.find({
        where: {
          id: {inq: userIds},
        },
      });
      let userGrp = users && users.length && _.groupBy(users, v => v.id);
      _.forEach(subs, async function(val: any) {
        let user: any =
          (userGrp &&
            userGrp[val.userId] &&
            userGrp[val.userId].length &&
            userGrp[val.userId][0]) ||
          {};
        if (user && user.email) {
          var a = moment(val.expireDate, 'YYYY-MM-DD');
          var b = moment().format('YYYY-MM-DD');
          let diffDay = a.diff(b, 'days');

          if (diffDay === 10 || diffDay === 5 || diffDay === 1) {
            const mailOptions: AnyObject = {
              to: user.email,
              slug: 'subscription',
              sub: diffDay + ' DAYS REMINDER',
              message: {
                days: diffDay,
                name: user?.name,
                date: moment(val.expireDate).format('MMM DD YYYY'),
              },
            };
            let planReminder: AnyObject = {
              title: 'Subscription reminder',
              message:
                'You  currently subscription plans will expire on' +
                moment(val.expireDate).format('MMM DD YYYY'),
              userId: val.userId,
              notiObject: {userId: val.userId},
              type: 'subscriptionDetail',
            };
            await _this.notificationRepository.create(planReminder);
            await _this.emailService.sendMail(mailOptions);
          }
        }
      });
    }
  }
}
