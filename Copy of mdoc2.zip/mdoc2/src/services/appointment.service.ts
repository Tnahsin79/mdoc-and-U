import {bind, BindingScope} from '@loopback/context';
import {repository} from '@loopback/repository';
import {Appointment, AppointmentWithRelations} from '../models';
import {AppointmentRepository} from '../repositories';

@bind({scope: BindingScope.TRANSIENT})
export class AppointmentService {
  constructor(
    @repository(AppointmentRepository)
    public AppointmentRepository: AppointmentRepository,
  ) {}

  async getAppointmentsByCoachId(coachId: string): Promise<AppointmentWithRelations[]> {
    return await this.AppointmentRepository.find({
        where: {
            coachId
        },
        include: [{relation: 'coach'}, {relation: 'user'}]
    });
  }
}
