import _ from 'lodash';
import multer from 'multer';
import Utils from '../utils';
import * as path from 'path';
import {Publication} from '../models';
import {Request, Response} from '@loopback/rest';
import {PaginatedResponse} from '../type-schema';
import {BlogPostService} from './blog-post.service';
import {ControllerService} from './controller.service';
import {Filter, repository} from '@loopback/repository';
import {UserProfile, securityId} from '@loopback/security';
import {BindingScope, bind, inject} from '@loopback/context';
import {UsersRepository, PublicationRepository} from '../repositories';
import {BlogPostServiceBindings, ControllerServiceBindings} from '../keys';
import {PublicationStatusEnum} from '../utils/enums';

@bind({scope: BindingScope.CONTEXT})
export class PublicationService {
  configOption = Utils.getSiteOptions();

  constructor(
    @repository(PublicationRepository)
    public publicationRepository: PublicationRepository,
    @inject(ControllerServiceBindings.CONTROLLER_SERVICE)
    public controllerService: ControllerService,
    @repository(UsersRepository) public usersRepository: UsersRepository,
    @inject(BlogPostServiceBindings.BLOG_POST_SERVICE)
    public blogPostService: BlogPostService,
  ) {}

  async create(request: Request, response: Response, currentUser: UserProfile) {
    const maxFileSize =
      this.configOption.maxFileSize.oneMB *
      this.configOption.maxFileSize.quantity;

    const upload = multer({
      storage: multer.memoryStorage(),
      fileFilter: function(req: any, file: any, cb: any) {
        let ext = path.extname(file.originalname);
        cb(null, true);
      },
      limits: {fileSize: maxFileSize},
    });
    return new Promise<object>(async (resolve, reject) => {
      upload.any()(request, response, (err: unknown) => {
        if (err) reject(err);
        else {
          // Check if the files are uploaded
          if (!request.files) {
            reject(new Error('No file uploaded'));
          } else {
            let imageFile =
              request.files[0].fieldname === 'image'
                ? request.files[0]
                : request.files[1];
            // let pdfFile =
            //   request.files[0].fieldname === 'pdf'
            //     ? request.files[0]
            //     : request.files[1];

            // Upload the image file
            this.blogPostService
              .checkSlug(request)
              .then(async (slugValue: string) => {
                this.controllerService
                  .uploadImageHelper(
                    [imageFile],
                    'complete_health_publications',
                  )
                  .then(async image => {
                    // Upload the pdf file
                    // this.controllerService
                    //   .uploadImageHelper(
                    //     [pdfFile],
                    //     'complete_health_publications',
                    //   )
                    //   .then(async pdf => {
                    const {
                      title,
                      description,
                      publicationDate = new Date(),
                      citation,
                      journalName,
                    } = request.body;
                    // Create the publication
                    const publication = await this.publicationRepository.create(
                      {
                        title,
                        description,
                        slug: slugValue,
                        publicationDate,
                        citation,
                        journalName,
                        externalLink: request.body?.externalLink,
                        created_at: new Date().toString(),
                        // pdfUrl: (pdf as unknown) as string,
                        creatorId: currentUser[securityId],
                        modified_at: new Date().toString(),
                        imageUrl: (image as unknown) as string,
                      },
                    );
                    resolve(publication);
                  });
                // });
              })
              .catch(err => {
                console.log(err);
                return response.json({message: err});
              });
          }
        }
      });
    });
  }

  async find(
    search?: string,
    status?: string,
    filter?: Filter<Publication>,
    page?: number,
  ): Promise<PaginatedResponse<Publication>> {
    const where = filter?.where || {};
    const limit = Utils.getLimit(filter?.limit);
    const pageNum = page ? page : 1;
    const skip = (pageNum - 1) * limit;

    if (search) {
      where['or'] = [
        {title: {regexp: new RegExp('.*' + search + '.*', 'i')}},
        {description: {regexp: new RegExp('.*' + search + '.*', 'i')}},
        {slug: {regexp: new RegExp('.*' + search + '.*', 'i')}},
      ];
    }

    if (status) {
      where['status'] = status;
    }

    const content = await this.publicationRepository.find({
      where,
      include: [
        {
          relation: 'creator',
          scope: {
            fields: {
              id: true,
              name: true,
              image: true,
              email: true,
              phoneNumber: true,
            },
          },
        },
      ],
      order: ['created_at DESC'],
      skip,
      limit,
    });
    const count = await this.publicationRepository.count(where);
    const totalPages = Math.ceil(count.count / limit);

    return {
      data: content,
      count: count.count,
      totalPages,
      currentPage: page,
      status: 'success',
    };
  }

  async findById(
    id: string,
    filter?: Filter<Publication>,
  ): Promise<Publication> {
    const postDetails = await this.publicationRepository.findById(id, {
      where: {...filter?.where},
      include: [
        {
          relation: 'creator',
          scope: {
            fields: {
              id: true,
              name: true,
              email: true,
              phoneNumber: true,
            },
          },
        },
      ],
    });

    return postDetails;
  }

  async update(publicationId: string, request: Request, response: Response) {
    const maxFileSize =
      this.configOption.maxFileSize.oneMB *
      this.configOption.maxFileSize.quantity;

    const upload = multer({
      storage: multer.memoryStorage(),
      fileFilter: function(req: any, file: any, cb: any) {
        let ext = path.extname(file.originalname);
        cb(null, true);
      },
      limits: {fileSize: maxFileSize},
    });

    return new Promise<object>(async (resolve, reject) => {
      upload.any()(request, response, async (err: unknown) => {
        if (err) reject(err);
        else {
          try {
            // Get the current publication
            const currentPublication = await this.publicationRepository.findById(
              publicationId,
            );

            // Check if files are uploaded
            let imageFile;
            // let pdfFile;
            request.files = request.files as Express.Multer.File[];

            if (request.files && request.files.length > 0) {
              imageFile =
                request.files.find((file: any) => file.fieldname === 'image') ||
                null;
              // pdfFile =
              //   request.files.find((file: any) => file.fieldname === 'pdf') ||
              //   null;
            }

            let imageUrl = currentPublication.imageUrl;
            // let pdfUrl = currentPublication.pdfUrl;

            if (imageFile) {
              const image = await this.controllerService.uploadImageHelper(
                [imageFile],
                'complete_health_publications',
              );
              ``;
              imageUrl = image as string;
            }

            // if (pdfFile) {
            //   const pdf = await this.controllerService.uploadImageHelper(
            //     [pdfFile],
            //     'complete_health_publications',
            //   );
            //   pdfUrl = pdf as string;
            // }

            const {
              title,
              description,
              publicationDate = new Date(),
              externalLink,
              status,
              citation,
              journalName,
            } = request.body;

            // Update the publication
            const updatedPublication = this.publicationRepository.updateById(
              publicationId,
              {
                title: title || currentPublication.title,
                description: description || currentPublication.description,
                publicationDate,
                // pdfUrl,
                journalName: journalName || currentPublication?.journalName,
                citation: citation || currentPublication?.citation,
                imageUrl,
                status: status || currentPublication.status,
                externalLink: externalLink || currentPublication.externalLink,
                modified_at: new Date().toString(),
              },
            );
            resolve(updatedPublication);
          } catch (error) {
            reject(error);
          }
        }
      });
    });
  }

  async deleteById(id: string): Promise<void> {
    return await this.publicationRepository.deleteById(id);
  }

  async statistics(): Promise<object> {
    const publications = await this.publicationRepository.find();
    const publicationCount = publications.length;
    const publishedCount = publications.filter(
      (publication: Publication) =>
        publication.status === PublicationStatusEnum.PUBLISHED,
    ).length;
    const unpublishedCount = publications.filter(
      (publication: Publication) =>
        publication.status === PublicationStatusEnum.DRAFTS,
    ).length;

    const statistics = {
      publicationCount,
      publishedCount,
      unpublishedCount,
    };

    return statistics;
  }
}
