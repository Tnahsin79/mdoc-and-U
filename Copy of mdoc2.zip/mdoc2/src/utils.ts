import {AnyObject} from '@loopback/repository';
const configOption = require(`./config/config.json`);
import {getModelSchemaRef} from '@loopback/openapi-v3';
// const configOption = require(`../config/config.staging.json`);

export default class Utils {
  static getBaseUrl() {
    return (
      'http' +
      (process.env.IS_SSL ? 's' : '') +
      '://' +
      process.env.HOST +
      (Number(process.env.PORT) === 80 || Number(process.env.PORT) === 443
        ? ''
        : ':' + Number(process.env.PORT))
    );
  }

  static getClientBaseUrl() {
    return (
      'http' +
      (process.env.IS_SSL ? 's' : '') +
      '://' +
      configOption.client.host +
      (configOption.client.port === 80 || configOption.client.port === 443
        ? ''
        : ':' + configOption.client.port)
    );
  }

  static getSiteOptions() {
    return configOption;
  }

  static filterEmailContent(content: any, obj: any) {
    obj = obj || {};
    if (content) {
      let keys = content.match(/\[(.+?)\]/g);
      if (keys && keys.length) {
        keys.forEach(function(k: any) {
          content = content.replace(k, obj[k.slice(1, -1)]);
        });
      }
      return content;
    } else {
      return false;
    }
  }

  static getLimit(limit?: number) {
    return limit === 1234 ? undefined : limit ? limit : 25;
  }

  static paginatedSchema(
    model: any,
    includeRelations: boolean = false,
    extras: AnyObject = {},
  ) {
    return {
      type: 'object',
      properties: {
        currentPage: {type: 'number'},
        totalPages: {type: 'number'},
        count: {type: 'number'},
        status: {type: 'string'},
        data: {
          type: 'array',
          items: getModelSchemaRef(model, {
            includeRelations,
            ...extras,
          }),
        },
      },
    };
  }

  static stripNigerianPhoneOfLeadingZero(phone: string) {
    if (!phone) {
      return;
    }
    const firstFourChars = phone.substring(0, 4);
    if (firstFourChars === '+234') {
      const fromFifthToEnd = phone.substring(4);
      if (fromFifthToEnd.length > 10 && fromFifthToEnd.charAt(0) === '0') {
        return `${firstFourChars}${fromFifthToEnd.substring(1)}`;
      }
      return phone;
    }
    return phone;
  }

  static isEmailBlacklisted(email: string) {
    const blacklist = [
      '@javnoi.com'
    ];
    // Convert the email to lower case for case-insensitive comparison
    const lowerCaseEmail = email.toLowerCase();
    
    // Check if the email ends with any of the extensions in the blacklist
    return blacklist.some(extension => lowerCaseEmail.endsWith(extension.toLowerCase()));
  }

  static generateRandomCode() {
    const digits = '123456789';
    let reference = '';

    for (let i = 0; i < 6; i++) {
      const randomIndex = Math.floor(Math.random() * digits.length);
      reference += digits[randomIndex];
    }
    return reference;
  }

  static stripHtmlTags (input: string): string {
    const htmlTagPattern = /<\/?[^>]+(>|$)/g;
    return input.replace(htmlTagPattern, '');
  };
}
/*
export const siteOptions = configOption;

export function getUrl() {
  return 'http' + (process.env.IS_SSL ? 's' : '') + '://' + configOption.host +
    ((configOption.port === 80 || configOption.port === 443) ? '' : ':' + configOption.port);
}

import * as Utils from '../utils';
*/
