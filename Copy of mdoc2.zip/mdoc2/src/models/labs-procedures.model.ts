import { Entity, model, property, belongsTo } from '@loopback/repository';
import { Users, UsersWithRelations } from './users.model'
import { Lab, LabWithRelations } from './lab.model'

@model({ settings: {} })
export class LabsProcedures extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @belongsTo(() => Users)
  userId: string
  
  @property({
    type: 'string',
    required: true,
  })
  name: string;

  @belongsTo(() => Lab, { name: 'lab' })
  labId?: string

  @property({
    type: 'boolean',
    default: false,
  })
  isLabComplete?: boolean;

  @property({
    type: 'date',
    default: undefined
  })
  date?: string;

  @property({
    type: 'date',
    default: () => new Date()
  })
  created?: string;

  @property({
    type: 'date',
    default: () => new Date()
  })
  modified?: string;


  constructor(data?: Partial<LabsProcedures>) {
    super(data);
  }
}

export interface LabsProceduresRelations {
  user?: UsersWithRelations,
  lab?: LabWithRelations,
}

export type LabsProceduresWithRelations = LabsProcedures & LabsProceduresRelations;
