import { Coach, CoachWithRelations } from './coach.model';
import {Entity, model, property, belongsTo} from '@loopback/repository';
import { UserSubscriptions, UserSubscriptionsWithRelations } from './user-subscriptions.model';
import { ActiveInactiveEnum } from '../type-schema';

@model()
export class CoachUserSubscriptions extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @belongsTo(() => Coach, { name: 'coach' })
  coachId: string;

  @belongsTo(() => UserSubscriptions, { name: 'subscription'})
  userSubscriptionId: string;

  // Will be set to inactive when the same member is assigned to the same coach
  @property({
    type: 'string',
    jsonSchema: {
      enum: Object.values(ActiveInactiveEnum)
    },
    default: ActiveInactiveEnum.ACTIVE,
  })
  status?: ActiveInactiveEnum;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created_at?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified_at?: string;

  constructor(data?: Partial<CoachUserSubscriptions>) {
    super(data);
  }
}

export interface CoachUserSubscriptionsRelations {
  coach?: CoachWithRelations;
  subscription?: UserSubscriptionsWithRelations;
}

export type CoachUserSubscriptionsWithRelations = CoachUserSubscriptions & CoachUserSubscriptionsRelations;
