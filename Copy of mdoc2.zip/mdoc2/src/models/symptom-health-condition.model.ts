import { Entity, belongsTo, model, property } from '@loopback/repository';
import { Users, UsersWithRelations } from './users.model';
import { Symptoms, SymptomsWithRelations } from './symptoms.model';
import { HealthCondition, HealthConditionWithRelations } from './health-condition.model';
import { Medication, MedicationWithRelations } from './medication.model';

@model()
export class SymptomHealthCondition extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @belongsTo(() => Users)
  userId: string;

  @belongsTo(() => Symptoms, {name: 'symptom'})
  symptomId: string;

  @belongsTo(() => HealthCondition, {name: 'healthCondition'})
  healthConditionId: string;
  
  @belongsTo(() => Medication, {name: 'medication'})
  medicationId: string;

  @property({
    type: 'number',
    default: 0,
  })
  intensity?: number;

  @property({
    type: 'string',
    default: '',
  })
  notes?: string;

  @property({
    type: 'date',
  })
  symptomDate?: string;

  @property({
    type: 'date',
    default: () => new Date()
  })
  created?: string;

  @property({
    type: 'date',
    default: () => new Date()
  })
  modified?: string;


  constructor(data?: Partial<SymptomHealthCondition>) {
    super(data);
  }
}

export interface SymptomHealthConditionRelations {
  // describe navigational properties here
  user?: UsersWithRelations,
  medication?: MedicationWithRelations,
  symptom?: SymptomsWithRelations,
  healthCondition?: HealthConditionWithRelations
}

export type SymptomHealthConditionWithRelations = SymptomHealthCondition & SymptomHealthConditionRelations;
