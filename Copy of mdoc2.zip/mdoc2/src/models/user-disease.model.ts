import {Entity, model, property, belongsTo} from '@loopback/repository';
import { Users, UsersWithRelations } from './users.model';
import { Disease, DiseaseWithRelations } from './disease.model';

@model()
export class UserDisease extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @belongsTo(() => Users, { name: 'user' })
  userId?: string;

  @belongsTo(() => Disease, { name: 'disease'})
  diseaseId?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified?: string;

  constructor(data?: Partial<UserDisease>) {
    super(data);
  }
}

export interface UserDiseaseRelations {
  user?: UsersWithRelations;
  disease?: DiseaseWithRelations;
}

export type UserDiseaseWithRelations = UserDisease & UserDiseaseRelations;
