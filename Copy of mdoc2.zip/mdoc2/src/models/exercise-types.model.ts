import {Entity, model, property} from '@loopback/repository';

@model()
export class ExerciseTypes extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
    required: true,
  })
  name: string;

  @property({
    type: 'string',
    required: false,
  })
  legacyId?: string;

  @property({
    type: 'date',
  })
  created?: string;

  @property({
    type: 'date',
  })
  modified?: string;


  constructor(data?: Partial<ExerciseTypes>) {
    super(data);
  }
}

export interface ExerciseTypesRelations {
  // describe navigational properties here
}

export type ExerciseTypesWithRelations = ExerciseTypes & ExerciseTypesRelations;
