import {SenderEnum} from '../utils/enums';
import {Users, UsersWithRelations} from './users.model';
import {Entity, belongsTo, model, property} from '@loopback/repository';

@model()
export class KemMessage extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @belongsTo(() => Users, {name: 'user'})
  user_id: string;

  @property({
    type: 'string',
    required: true,
  })
  message: string;

  @property({
    type: 'string',
    required: true,
    jsonSchema: {
      enum: ['user', 'kem'],
    },
  })
  sender_enum: SenderEnum;

  @property({
    type: 'string',
    required: true,
  })
  user_full_name: string;

  @property({
    type: 'string',
    required: false,
  })
  user_picture?: string;

  @property({
    type: 'string',
    required: false,
  })
  resource_url?: string;

  @property({
    type: 'boolean',
    required: false,
    default: false,
  })
  seen?: boolean;

  @property({
    type: 'string',
    required: false,
  })
  gender?: string;

  @property({
    type: 'string',
    required: false,
  })
  date_of_birth?: string;

  @property({
    type: 'number',
    required: false,
  })
  latest_bmi?: number;

  @property({
    type: 'string',
    required: false,
  })
  bmi_measurement_date?: string;

  @property({
    type: 'string',
    required: false,
  })
  latest_bp?: string;

  @property({
    type: 'string',
    required: false,
  })
  bp_measurement_date?: string;

  @property({
    type: 'boolean',
    required: false,
  })
  pregnancy_status?: boolean;

  @property({
    type: 'string',
    required: false,
  })
  pregnancy_edd?: string;

  @property({
    type: 'string',
    required: false,
  })
  health_coach_name?: string;

  @property({
    type: 'string',
    required: false,
  })
  location?: string;

  @property({
    type: 'string',
    required: false,
  })
  action_plan?: string;

  @property({
    type: 'string',
    required: false,
  })
  exercise_duration_last_30_days?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created_at?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified_at?: string;

  constructor(data?: Partial<KemMessage>) {
    super(data);
  }
}

export interface KemMessageRelations {
  user?: UsersWithRelations;
}

export type KemMessageWithRelations = KemMessage & KemMessageRelations;
