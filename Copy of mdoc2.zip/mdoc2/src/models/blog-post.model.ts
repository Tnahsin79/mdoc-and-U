import {
  model,
  Entity,
  hasMany,
  property,
  belongsTo,
} from '@loopback/repository';
import {Like, LikeWithRelations} from './like.model';
import {Admin, AdminWithRelations} from './admin.model';
import {Comment, CommentWithRelations} from './comment.model';
import {ReportPost, ReportPostWithRelations} from './report-post.model';

@model()
export class BlogPost extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
    index: true,
  })
  title?: string;

  @property({
    type: 'string',
  })
  description?: string;

  @property({
    type: 'string',
  })
  content?: string;

  @property({
    type: 'string',
  })
  imageUrl?: string;

  @property({
    type: 'number',
    default: 1,
  })
  status?: number;

  @belongsTo(() => Admin, {name: 'creator'})
  creatorId: string;

  @hasMany(() => ReportPost, {keyFrom: 'blogPostId', name: 'reportPost'})
  reportPost: ReportPost[];

  @hasMany(() => Like, {keyFrom: 'blogPostId', name: 'likes'})
  likes: Like[];

  @hasMany(() => Comment, {keyFrom: 'blogPostId', name: 'comments'})
  comments: Comment[];

  @property({
    type: 'date',
    default: () => new Date(),
  })
  displayDate: string;

  @property({
    type: 'number',
    required: false,
  })
  order?: number;

  @property({
    type: 'number',
    default: 0,
  })
  read?: number;

  @property({
    type: 'string',
    required: true,
    index: {unique: true},
  })
  slug: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created_at?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified_at?: string;
}

export interface BlogPostRelations {
  creator?: AdminWithRelations;
  likes?: LikeWithRelations;
  comments?: CommentWithRelations;
  reportPost?: ReportPostWithRelations;
}

export type BlogPostWithRelations = BlogPost & BlogPostRelations;
