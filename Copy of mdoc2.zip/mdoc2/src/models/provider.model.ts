import {Users, UsersWithRelations} from './users.model';
import {Coach, CoachWithRelations} from './coach.model';
import {Entity, belongsTo, model, property} from '@loopback/repository';

@model()
export class Provider extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
  })
  name?: string;

  @property({
    type: 'string',
  })
  hospitalName?: string;

  @property({
    type: 'boolean',
    default: false,
  })
  isProviderComplete?: boolean;

  @belongsTo(() => Users, {name: 'user'})
  userId: string;

  @belongsTo(() => Coach, {name: 'coach'})
  coachId?: string;

  @property({
    type: 'string',
    required: false,
  })
  providerId?: string;

  @property({
    type: 'string',
    required: false,
  })
  city?: string;

  @property({
    type: 'string',
    default: () =>  new Date()
  })
  address?: string;

  @property({
    type: 'date',
    default: () => new Date()
  })
  created?: Date;

  @property({
    type: 'date',
    default: () => new Date()
  })
  modified?: Date;

  constructor(data?: Partial<Provider>) {
    super(data);
  }
}

export interface ProviderRelations {
  // describe navigational properties here
  user?: UsersWithRelations;
  coach?: CoachWithRelations;
}

export type ProviderWithRelations = Provider & ProviderRelations;
