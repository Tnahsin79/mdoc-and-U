import { Entity, model, property, belongsTo } from '@loopback/repository';
import { Users, UsersWithRelations } from './users.model';
import {Coach, CoachWithRelations} from './coach.model';
import { ProcedureList, ProcedureListWithRelations } from './procedure-list.model';

@model({ settings: {} })
export class HealthProcedureSurgeries extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @belongsTo(() => Users)
  userId: string

  @belongsTo(() => Coach, {name: 'coach'})
  coachId?: string;

  @belongsTo(() => ProcedureList, { name: 'procedure' })
  procedureId: string

  @property({
    type: 'string',
    required: false,
  })
  city?: string;

  @property({
    type: 'string',
  })
  address?: string;

  @property({
    type: 'date',
    required: true,
  })
  treatmentDate: string;

  @property({
    type: 'boolean',
    default: false,
  })
  isHealthProcedureComplete?: boolean;

  @property({
    type: 'date',
    default: () => new Date()
  })
  created?: string;

  @property({
    type: 'date',
    default: () => new Date()
  })
  modified?: string;


  constructor(data?: Partial<HealthProcedureSurgeries>) {
    super(data);
  }
}

export interface HealthProcedureSurgeriesRelations {
  user?: UsersWithRelations,
  coach?: CoachWithRelations;
  procedure?: ProcedureListWithRelations,
}

export type HealthProcedureSurgeriesWithRelations = HealthProcedureSurgeries & HealthProcedureSurgeriesRelations;
