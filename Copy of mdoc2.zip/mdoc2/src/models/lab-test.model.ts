import { LabTestSampleTypeEnum, LabTestTypeEnum} from '../utils/enums';
import { Coach, CoachWithRelations } from './coach.model';
import { HubVisit, HubVisitWithRelations } from './hub-visit.model';
import {Users, UsersWithRelations} from './users.model';
import {Entity, belongsTo, model, property} from '@loopback/repository';

@model()
export class LabTest extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @belongsTo(() => Users, {name: 'user'})
  userId: string;

  @property({
    type: 'string',
    required: true,
    jsonSchema: {
      enum: Object.values(LabTestTypeEnum),
    },
  })
  testType: LabTestTypeEnum;

  @property({
    type: 'string',
    required: true,
    jsonSchema: {
      enum: Object.values(LabTestSampleTypeEnum),
    },
  })
  sampleType: LabTestSampleTypeEnum;

  @property({
    type: 'boolean',
    default: true,
  })
  isPositive: boolean;

  @belongsTo(() => Coach, {name: 'createdByCoach'})
  createdByCoachId: string;

  @belongsTo(() => HubVisit, {name: 'hubVisit'})
  hubVisitId: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created_at?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified_at?: string;

  constructor(data?: Partial<LabTest>) {
    super(data);
  }
}

export interface LabTestRelations {
  user?: UsersWithRelations;
  createdByCoach?: CoachWithRelations;
  hubVisit?: HubVisitWithRelations;
}

export type LabTestWithRelations = LabTest & LabTestRelations;
