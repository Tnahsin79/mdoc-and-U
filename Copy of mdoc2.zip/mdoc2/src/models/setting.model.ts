import {
  Entity,
  model,
  property,
} from '@loopback/repository';

@model()
export class Setting extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
    required: false,
  })
  general_settings?: string;

  @property({
    type: 'string',
    required: false,
  })
  terms_and_condition?: string;

  @property({
    type: 'string',
    required: false,
  })
  site_logo?: string;

  @property({
    type: 'string',
    required: false,
  })
  privacy_policy?: string;

  @property({
    type: 'string',
    required: false,
  })
  site_name?: string;

  constructor(data?: Partial<Setting>) {
    super(data);
  }
}

export interface SettingRelations {

}

export type SettingWithRelations = Setting & SettingRelations;
