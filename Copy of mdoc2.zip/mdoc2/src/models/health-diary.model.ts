import { Entity, model, property, AnyObject } from '@loopback/repository';

@model()
export class HealthDiary extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
    required: false,
  })
  userId: string;

  @property({
    type: 'string',
    required: false,
  })
  providerId: string;

  @property({
    type: 'string',
    required: true,
  })
  type: string;

  @property({
    type: 'object',
  })
  weight: AnyObject;

  @property({
    type: 'number',
  })
  hbaicLevel?: number;

  @property({
    type: 'object',
  })
  waist?: object;

  @property({
    type: 'object',
  })
  cholesterol?: object;

  @property({
    type: 'object',
  })
  psa?: object;

  @property({
    type: 'object',
  })
  bmi: AnyObject;

  @property({
    type: 'object',
  })
  bloodPressure?: object;

  @property({
    type: 'object',
  })
  exercise?: object;

  @property({
    type: 'boolean'
  })
  isBmiGoal?: boolean;

  @property({
    type: 'boolean',
    default: false
  })
  isHealthDiaryCompleted?: boolean;

  @property({
    type: 'object',
  })
  glucose?: object;

  @property({
    type: 'date',
    default: undefined
  })
  date?: string;

  @property({
    type: 'date',
    default: () => new Date()
  })
  created?: string;

  @property({
    type: 'date',
    default: () => new Date()
  })
  modified?: string;


  constructor(data?: Partial<HealthDiary>) {
    super(data);
  }
}

export interface HealthDiaryRelations {
  // describe navigational properties here
}

export type HealthDiaryWithRelations = HealthDiary & HealthDiaryRelations;
