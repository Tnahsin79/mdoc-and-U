import {Entity, model, property} from '@loopback/repository';

@model()
export class SymptomTypes extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
  })
  userId?: string;

  @property({
    type: 'string',
    required: true,
  })
  symptomType: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created?: string;

  @property({
    type: 'date',
  })
  modified?: string;


  constructor(data?: Partial<SymptomTypes>) {
    super(data);
  }
}

export interface SymptomTypesRelations {
  // describe navigational properties here
}

export type SymptomTypesWithRelations = SymptomTypes & SymptomTypesRelations;
