import {Question, QuestionWithRelations} from './question.model';
import {Entity, belongsTo, model, property} from '@loopback/repository';

@model()
export class Option extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @belongsTo(() => Question, {name: 'question'})
  questionId: string;

  @property({
    type: 'number',
    required: false,
    default: 0,
  })
  order?: number;

  @property({
    type: 'string',
    required: true,
  })
  optionText: string;

  @property({
    type: 'number',
    required: false,
    default: 1,
  })
  score?: number;

  @property({
    type: 'boolean',
    required: false,
    default: false,
  })
  isDeleted?: boolean;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created_at?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified_at?: string;

  constructor(data?: Partial<Option>) {
    super(data);
  }
}

export interface OptionRelations {
  // describe navigational properties here
  question?: QuestionWithRelations;
}

export type OptionWithRelations = Option & OptionRelations;
