import {Users, UsersWithRelations} from './users.model';
import {Coach, CoachWithRelations} from './coach.model';
import {Consult, ConsultWithRelations} from './consult.model';
import {HubVisit, HubVisitWithRelations} from './hub-visit.model';
import {BloodGlucoseEnum} from '../utils/health-metrics-functions';
import {Entity, belongsTo, model, property} from '@loopback/repository';
import {GoalAction, GoalActionWithRelations} from './goal-action.model';

@model()
export class BloodSugar extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @belongsTo(() => Users, {name: 'user'})
  userId: string;

  @belongsTo(() => HubVisit, {name: 'hubVisit'})
  hubVisitId?: string;

  @belongsTo(() => Consult, {name: 'consult'})
  consultId?: string;

  @belongsTo(() => Coach, {name: 'coach'})
  coachId?: string;

  @belongsTo(() => GoalAction, {name: 'goalAction'})
  goalActionId?: string;

  @property({
    type: 'string',
    required: false,
    jsonSchema: {
      enum: ['breakfast', 'lunch', 'dinner', 'fasting', 'random', 'snack'],
    },
  })
  mealType: string;

  @property({
    type: 'string',
    required: false,
  })
  beforeMeal?: string;

  @property({
    type: 'string',
    required: false,
  })
  afterMeal?: string;

  @property({
    type: 'string',
    required: true,
    jsonSchema: {
      enum: ['mmol/L', 'mg/dL'],
    },
  })
  unit: BloodGlucoseEnum;

  @property({
    type: 'number',
    default: 0,
    required: false,
  })
  defaultBeforeMeal?: number;

  @property({
    type: 'number',
    default: 0,
    required: false,
  })
  defaultAfterMeal?: number;

  @property({
    type: 'string',
    required: false,
    default: 'mgPerDL',
  })
  defaultUnit?: string;

  @property({
    type: 'string',
    required: false,
  })
  mealDetail?: string;

  @property({
    type: 'date',
    default: () => new Date(),
    required: false,
  })
  logDate?: string;

  @property({
    type: 'string',
    required: true,
    jsonSchema: {
      enum: ['web', 'mobile'],
    },
    default: 'web',
  })
  channel: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created_at?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified_at?: string;

  constructor(data?: Partial<BloodSugar>) {
    super(data);
  }
}

export interface BloodSugarRelations {
  user?: UsersWithRelations;
  coach?: CoachWithRelations;
  consult?: ConsultWithRelations;
  hubVisit?: HubVisitWithRelations;
  goalAction?: GoalActionWithRelations;
}

export type BloodSugarWithRelations = BloodSugar & BloodSugarRelations;
