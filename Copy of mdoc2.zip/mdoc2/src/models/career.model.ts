import { model, Entity, property, belongsTo } from "@loopback/repository";
import { Admin, AdminWithRelations } from "./admin.model";
import { JobCategoryEnum, JobExperienceEnum, JobStatusEnum, WorkLocationTypeEnum, JobTypeEnum } from "../utils/enums";

@model()
export class Career extends Entity {
  @property({
    type: "string",
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: "string",
    required: true,
  })
  title: string;

  @property({
    type: "string",
    required: true,
  })
  description: string;

  @property({
    type: "string",
    required: true,
  })
  location?: string;

  @property({
    type: "string",
    required: false,
    jsonSchema: {
      enum: Object.values(JobTypeEnum),
    },
  })
  jobType?: string;

  @property({
    type: "string",
    required: false,
    jsonSchema: {
      enum: Object.values(JobCategoryEnum),
    },
  })
  category?: string;

  @property({
    type: "string",
    required: false,
    jsonSchema: {
      enum: Object.values(JobExperienceEnum),
    },
  })
  experience?: string;

  @property({
    type: "string",
    required: false,
    default: "draft",
    jsonSchema: {
      enum: Object.values(JobStatusEnum),
    },
  })
  status?: string;

  @property({
    type: "string",
    required: true,
    jsonSchema: {
      enum: Object.values(WorkLocationTypeEnum),
    },
  })
  workLocationType?: string;

  @property({
    type: "string",
    required: false,
  })
  linkToApply?: string;

  @property({
    type: "string",
    required: false,
  })
  salaryRange?: string;

  @property({ type: "date", required: false })
  startDate?: string;

  @property({ type: "date", required: false })
  expiryDate?: string;

  @belongsTo(() => Admin, { name: "creator" })
  creatorId: string;

  @property({
    type: "date",
    default: () => new Date(),
  })
  created_at?: string;

  @property({
    type: "date",
    default: () => new Date(),
  })
  modified_at?: string;

  constructor(data?: Partial<Career>) {
    super(data);
  }
}

export interface CareerRelations {
  creator?: AdminWithRelations;
}

export type CareerWithRelations = Career & CareerRelations;
