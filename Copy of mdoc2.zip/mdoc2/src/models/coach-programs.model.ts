import {Entity, model, property, belongsTo} from '@loopback/repository';
import { Coach, CoachWithRelations } from './coach.model';
import { Programs, ProgramsWithRelations } from './programs.model';

@model()
export class CoachPrograms extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @belongsTo(() => Coach, { name: 'coach' })
  coachId?: string;

  @belongsTo(() => Programs, { name: 'program'})
  programId?: string;

  @property({
    type: 'number',
    default: 0
  })
  totalMembers?: number;

  @property({
    type: 'string',
    jsonSchema: {
      enum: ['active', 'inactive']
    },
    default: 'active',
  })
  status?: "active" | "inactive";

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified?: string;

  constructor(data?: Partial<CoachPrograms>) {
    super(data);
  }
}

export interface CoachProgramsRelations {
  coach?: CoachWithRelations;
  program?: ProgramsWithRelations;
}

export type CoachProgramsWithRelations = CoachPrograms & CoachProgramsRelations;
