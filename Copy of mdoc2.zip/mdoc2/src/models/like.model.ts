import {Users, UsersWithRelations} from './users.model';
import {BlogPost, BlogPostWithRelations} from './blog-post.model';
import {Entity, model, property, belongsTo} from '@loopback/repository';

@model({settings: {}})
export class Like extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @belongsTo(() => Users)
  userId: string;

  @belongsTo(() => BlogPost, {name: 'blogPost'})
  blogPostId: string;

  @property({
    type: 'date',
  })
  created?: string;

  @property({
    type: 'date',
  })
  modified?: string;

  constructor(data?: Partial<Like>) {
    super(data);
  }
}

export interface LikeRelations {
  user?: UsersWithRelations;
  blogPost?: BlogPostWithRelations;
}

export type LikeWithRelations = Like & LikeRelations;
