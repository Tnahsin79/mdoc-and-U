import {
  GlichesTypeEnum,
} from '../utils/enums';
import {belongsTo, Entity, model, property} from '@loopback/repository';
import { Consult, ConsultWithRelations } from './consult.model';
import { Coach, CoachWithRelations } from './coach.model';

@model()
export class Glitches extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id: string;

  @belongsTo(() => Consult, {name: 'consult'})
  consultId?: string;

  @property({
    type: 'date',
    required: false,
    default: () => new Date(),
  })
  startTime?: string;

  @property({
    type: 'date',
    default: () => new Date(),
    required: false,
  })                  
  endTime?: string;

  @property({
    type: 'number',
    required: true,
  })
  duration: number;                

  @property({
    type: 'string',
    required: false,
  })
  otherType?: string;

  @property({
    type: 'string',
    required: true,
    jsonSchema: {
      enum: Object.values(GlichesTypeEnum),
    },
  })
  type: GlichesTypeEnum;

  @belongsTo(() => Coach, {name: 'createdByCoach'})
  createdBy?: string;
  
  @property({
    type: 'date',
    default: () => new Date(),
  })
  created_at: Date;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified_at?: string;

  constructor(data?: Partial<Glitches>) {
    super(data);
  }
}

export interface GlitchesRelations {
  createdByCoach: CoachWithRelations;
  consult?: ConsultWithRelations;
}

export type GlitchesWithRelations = Glitches & GlitchesRelations;
