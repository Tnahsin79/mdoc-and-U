import {Users, UsersWithRelations} from './users.model';
import {Coach, CoachWithRelations} from './coach.model';
import {Consult, ConsultWithRelations} from './consult.model';
import {Entity, belongsTo, model, property} from '@loopback/repository';
import {GoalAction, GoalActionWithRelations} from './goal-action.model';

@model()
export class Hbaic extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @belongsTo(() => Users, {name: 'user'})
  userId: string;

  @belongsTo(() => Consult, {name: 'consult'})
  consultId?: string;

  @belongsTo(() => Coach, {name: 'coach'})
  coachId?: string;

  @belongsTo(() => GoalAction, {name: 'goalAction'})
  goalActionId?: string;

  @property({
    type: 'number',
    required: true,
  })
  value: number;

  @property({
    type: 'date',
    default: () => new Date(),
    required: false,
  })
  logDate?: string;

  @property({
    type: 'string',
    jsonSchema: {
      enum: ['web', 'mobile'],
    },
    default: 'web',
  })
  channel: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created_at?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified_at?: string;

  constructor(data?: Partial<Hbaic>) {
    super(data);
  }
}

export interface HbaicRelations {
  user?: UsersWithRelations;
  coach?: CoachWithRelations;
  consult?: ConsultWithRelations;
  goalAction?: GoalActionWithRelations;
}

export type HbaicWithRelations = Hbaic & HbaicRelations;
