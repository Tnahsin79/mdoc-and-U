import { Entity, model, property, belongsTo } from '@loopback/repository';
import { Users, UsersWithRelations } from './users.model'

@model({ settings: {} })
export class Journal extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @belongsTo(() => Users)
  userId: string

  @property({
    type: 'string',
    required: true,
  })
  title: string;

  @property({
    type: 'string',
  })
  description?: string;

  @property({
    type: 'array',
    itemType: 'string',
  })
  attachment?: string[];

  @property({
    type: 'array',
    itemType: 'string',
  })
  audios?: string[];

  @property({
    type: 'number',
    default: 1
  })
  status?: number;

  @property({
    type: 'date',
    default: () => new Date()
  })
  created?: string;

  @property({
    type: 'date',
    default: () => new Date()
  })
  modified?: string;


  constructor(data?: Partial<Journal>) {
    super(data);
  }
}

export interface JournalRelations {
  user: UsersWithRelations,
}

export type JournalWithRelations = Journal & JournalRelations;
