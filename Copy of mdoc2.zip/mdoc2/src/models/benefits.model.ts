import {Entity, model, property, belongsTo} from '@loopback/repository';
import {Programs, ProgramsWithRelations} from './programs.model';

@model({settings: {}})
export class Benefits extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
    required: true,
  })
  title: string;

  @property({
    type: 'string',
    enum: ['text', 'checkmark'],
    default: 'checkmark',
  })
  type: string;
  

  @property({
    type: 'number',
  })
  order?: number;

  @belongsTo(() => Programs, {})
  programId?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified?: string;

  constructor(data?: Partial<Benefits>) {
    super(data);
  }
}

export interface BenefitsRelations {
  programs?: ProgramsWithRelations;
}

export type BenefitsWithRelations = Benefits & BenefitsRelations;
