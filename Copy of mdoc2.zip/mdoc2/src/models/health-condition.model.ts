import {Users, UsersWithRelations} from './users.model';
import {Coach, CoachWithRelations} from './coach.model';
import {Disease, DiseaseWithRelations} from './disease.model';
import {HubVisit, HubVisitWithRelations} from './hub-visit.model';
import {Entity, model, property, belongsTo} from '@loopback/repository';

@model({settings: {}})
export class HealthCondition extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @belongsTo(() => Users)
  userId: string;

  @belongsTo(() => Coach)
  coachId?: string;

  @belongsTo(() => HubVisit, {name: 'hubVisit'})
  hubVisitId?: string;

  @belongsTo(() => Disease)
  diseaseId: string;

  @property({
    type: 'boolean',
    default: false,
  })
  isHealthConditionComplete?: boolean;

  @property({
    type: 'string',
    required: true,
    jsonSchema: {
      enum: ['past', 'present'],
    },
  })
  type: string;

  @property({
    type: 'date',
  })
  diseaseDate?: string;

  @property({
    type: 'string',
    required: true,
  })
  source: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified?: string;

  constructor(data?: Partial<HealthCondition>) {
    super(data);
  }
}

export interface HealthConditionRelations {
  user?: UsersWithRelations;
  coach?: CoachWithRelations;
  disease?: DiseaseWithRelations;
  hubVisit?: HubVisitWithRelations;
}

export type HealthConditionWithRelations = HealthCondition &
  HealthConditionRelations;
