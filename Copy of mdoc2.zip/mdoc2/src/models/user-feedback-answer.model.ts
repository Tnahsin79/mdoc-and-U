import {Option, OptionWithRelations} from './option.model';
import {Question, QuestionWithRelations} from './question.model';
import {Entity, belongsTo, model, property} from '@loopback/repository';
import {UserFeedback, UserFeedbackRelations} from './user-feedback.model';

@model()
export class UserFeedbackAnswer extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @belongsTo(() => UserFeedback, {name: 'userFeedback'})
  userFeedbackId: string;

  @belongsTo(() => Question, {name: 'question'})
  questionId: string;

  @belongsTo(() => Option, {name: 'selectedOption'})
  selectedOptionId: string;

  @property({type: 'string', required: false})
  response?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created_at?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified_at?: string;

  constructor(data?: Partial<UserFeedbackAnswer>) {
    super(data);
  }
}

export interface UserFeedbackAnswerRelations {
  question?: QuestionWithRelations;
  userFeedback?: UserFeedbackRelations;
  selectedOption?: OptionWithRelations;
}

export type UserFeedbackAnswerWithRelations = UserFeedbackAnswer &
  UserFeedbackAnswerRelations;
