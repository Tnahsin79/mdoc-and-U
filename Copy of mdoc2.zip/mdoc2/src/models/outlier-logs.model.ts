import {Entity, model, property} from '@loopback/repository';

@model()
export class OutlierLogs extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'number',
  })
  coachProviderId?: number;

  @property({
    type: 'number',
  })
  memberProviderId?: number;

  @property({
    type: 'string',
  })
  coachId?: string;

  @property({
    type: 'string',
  })
  userId?: string;

  @property({
    type: 'string',
  })
  outlierType?: string;

  @property({
    type: 'string',
  })
  outlierValue?: string;

  @property({
    type: 'date',
  })
  outlierNotificationDatetime?: string;


  constructor(data?: Partial<OutlierLogs>) {
    super(data);
  }
}

export interface OutlierLogsRelations {
  // describe navigational properties here
}

export type OutlierLogsWithRelations = OutlierLogs & OutlierLogsRelations;
