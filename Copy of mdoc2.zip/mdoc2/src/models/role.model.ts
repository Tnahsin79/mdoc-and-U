import {
  Entity,
  model,
  property,
  hasMany,
  belongsTo,
} from '@loopback/repository';
import {RolePrivilege, RolePrivilegeWithRelations} from './role-privilege.model';
import {PrivilegeWithRelations} from './privilege.model';
import { AdminRole, AdminRoleWithRelations } from './admin-role.model';

@model()
export class Role extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
    required: true,
  })
  title: string;

  @property({
    type: 'string',
    required: true,
  })
  description: string;

  @property({
    type: 'boolean',
    required: true,
    default: true,
  })
  active: boolean;

  @hasMany(() => RolePrivilege, {keyFrom: 'roleId', name: 'rolePrivileges'})
  rolePrivileges: RolePrivilege[];

  @hasMany(() => AdminRole, {keyFrom: 'roleId', name: 'admins'})
  admins: AdminRole[];

  constructor(data?: Partial<Role>) {
    super(data);
  }
}

export interface RoleRelations {
  // Define the relationship with Privileges model
  rolePrivileges?: RolePrivilegeWithRelations[];
  admins: AdminRoleWithRelations[];
}

export type RoleWithRelations = Role & RoleRelations;
