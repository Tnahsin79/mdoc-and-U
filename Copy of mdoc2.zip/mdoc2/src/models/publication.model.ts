import {PublicationStatusEnum} from '../utils/enums';
import {Admin, AdminWithRelations} from './admin.model';
import {model, Entity, property, belongsTo} from '@loopback/repository';

@model()
export class Publication extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
    index: true,
    required: false,
  })
  title?: string;

  @property({
    type: 'string',
    required: false,
  })
  description?: string;

  @property({
    type: 'string',
    required: false,
  })
  citation?: string;

  @property({
    type: 'string',
    required: false,
  })
  pdfUrl?: string;

  @property({
    type: 'string',
    required: true,
  })
  journalName: string;

  @property({
    type: 'string',
    required: false,
  })
  imageUrl?: string;

  @property({
    type: 'string',
    required: false,
  })
  externalLink?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  publicationDate: string;

  @property({
    type: 'string',
    default: 'drafts',
    jsonSchema: {
      enum: Object.values(PublicationStatusEnum),
    },
  })
  status?: PublicationStatusEnum;

  @belongsTo(() => Admin, {name: 'creator'})
  creatorId: string;

  @property({
    type: 'string',
    index: {unique: true},
    required: true,
  })
  slug: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created_at?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified_at?: string;
}

export interface PublicationRelations {
  creator?: AdminWithRelations;
}

export type PublicationWithRelations = Publication & PublicationRelations;
