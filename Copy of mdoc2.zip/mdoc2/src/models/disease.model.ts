import {UserDisease} from './user-disease.model';
import {Entity, hasMany, model, property} from '@loopback/repository';

@model()
export class Disease extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
  })
  legacyId?: string;

  @property({
    type: 'string',
    required: true,
  })
  name?: string;

  @property({
    type: 'string',
  })
  description?: string;

  @property({
    type: 'string',
    required: false,
    default: 'pending',
    jsonSchema: {
      enum: ['pending', 'approved', 'rejected'],
    },
  })
  approvalStatus?: string;

  // @property({
  //   type: 'string',
  // })
  // userId?: string;

  @hasMany(() => UserDisease, {keyTo: 'diseaseId'})
  users?: UserDisease[];

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified?: string;

  constructor(data?: Partial<Disease>) {
    super(data);
  }
}

export interface DiseaseRelations {
  // describe navigational properties here
}

export type DiseaseWithRelations = Disease & DiseaseRelations;
