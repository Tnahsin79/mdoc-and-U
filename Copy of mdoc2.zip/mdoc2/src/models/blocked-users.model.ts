import { Users, UsersRelations } from './users.model'
import { Coach, CoachRelations } from './coach.model';
import { Comment, CommentRelations } from './comment.model';
import { BlogPost, BlogPostWithRelations } from './blog-post.model';
import { Entity, model, property, belongsTo } from '@loopback/repository';

@model()
export class BlockedUsers extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @belongsTo(() => Users)
  userId: string

  @belongsTo(() => Users, { name: 'blockUser' })
  blockedUserId: string;

  @belongsTo(() => Coach)
  coachId: string

  @belongsTo(() => Coach, { name: 'blockCoach' })
  blockedcoachId: string

  @property({
    type: 'string',
    required: true,
    default: "" // user, coach, post, comment
  })
  blockType: string;

  @property({
    type: 'string',
    required: false,
    default: ""
  })
  reasion: string;

  @belongsTo(() => BlogPost, { name: 'blogPost' })
  postId: string

  @belongsTo(() => Comment, { name: 'comment' })
  commentId: string

  @property({
    type: 'date',
    default: () => new Date()
  })
  created?: string;


  constructor(data?: Partial<BlockedUsers>) {
    super(data);
  }
}

export interface BlockedUsersRelations {
  user?: UsersRelations,
  blockUser?: UsersRelations,
  coach?: CoachRelations,
  blockCoach?: CoachRelations,
  blogPost?: BlogPostWithRelations,
  comment?: CommentRelations,
  // describe navigational properties here
}

export type BlockedUsersWithRelations = BlockedUsers & BlockedUsersRelations;
