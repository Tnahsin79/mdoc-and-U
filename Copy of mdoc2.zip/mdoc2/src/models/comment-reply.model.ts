import {Users, UsersWithRelations} from './users.model';
import {Comment, CommentWithRelations} from './comment.model';
import {Entity, belongsTo, model, property} from '@loopback/repository';

@model()
export class CommentReply extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @belongsTo(() => Users, {name: 'user'})
  userId: string;

  @belongsTo(() => Comment, {name: 'parentComment'})
  parentCommentId: string;

  @belongsTo(() => Comment, {name: 'replyComment'})
  replyCommentId?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created_at?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified_at?: string;

  constructor(data?: Partial<CommentReply>) {
    super(data);
  }
}

export interface CommentReplyRelations {
  user?: UsersWithRelations;
  replyComment?: CommentWithRelations;
  parentComment?: CommentWithRelations;
}

export type CommentReplyWithRelations = CommentReply & CommentReplyRelations;
