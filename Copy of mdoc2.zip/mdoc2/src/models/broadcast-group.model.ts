import {Entity, model, property} from '@loopback/repository';

@model()
export class BroadcastGroup extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
  })
  name?: string;

  @property({
    type: 'string',
    required: true,
  })
  coachId: string;

  @property({
    type: 'array',
    itemType: 'string',
    required: true,
  })
  members: string[];

  @property({
    type: 'date',
    default: () => new Date()
  })
  created?: string;

  @property({
    type: 'date',
  })
  modified?: string;


  constructor(data?: Partial<BroadcastGroup>) {
    super(data);
  }
}

export interface BroadcastGroupRelations {
  // describe navigational properties here
}

export type BroadcastGroupWithRelations = BroadcastGroup & BroadcastGroupRelations;
