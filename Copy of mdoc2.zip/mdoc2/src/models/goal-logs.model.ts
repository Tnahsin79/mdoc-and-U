import {Goal, GoalWithRelations} from './goal.model';
import {Users, UsersWithRelations} from './users.model';
import {GoalAction, GoalActionWithRelations} from './goal-action.model';
import {Entity, belongsTo, model, property} from '@loopback/repository';

@model()
export class GoalLogs extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id: string;

  @belongsTo(() => Goal, {name: 'goal'})
  goalId?: string;

  @belongsTo(() => GoalAction, {name: 'goalAction'})
  goalActionId: string;

  @belongsTo(() => Users, {name: 'user'})
  userId: string;

  @property({
    type: 'string',
    required: false,
  })
  metricId?: string;

  @property({
    type: 'string',
    required: false,
  })
  value?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created_at: Date;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified_at?: string;

  constructor(data?: Partial<GoalLogs>) {
    super(data);
  }
}

export interface GoalLogsRelations {
  goal?: GoalWithRelations;
  user?: UsersWithRelations;
  goalAction?: GoalActionWithRelations;
}

export type GoalLogsWithRelations = GoalLogs & GoalLogsRelations;
