import { Entity, model, property } from '@loopback/repository';

@model()
export class Resources extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
    required: true,
  })
  name: string;

  @property({
    type: 'string',
  })
  categoryId?: string;

  @property({
    type: 'number',
    default: 1
  })
  status?: number;

  @property({
    type: 'string',
  })
  createdId?: string;

  @property({
    type: 'date',
    default: () => new Date()
  })
  created?: string;


  constructor(data?: Partial<Resources>) {
    super(data);
  }
}

export interface ResourcesRelations {
  // describe navigational properties here
}

export type ResourcesWithRelations = Resources & ResourcesRelations;
