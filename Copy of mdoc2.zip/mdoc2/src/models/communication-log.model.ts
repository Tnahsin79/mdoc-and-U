import {CallInitiatorEnum} from '../utils/enums';
import {Coach, CoachWithRelations} from './coach.model';
import {Users, UsersWithRelations} from './users.model';
import {Admin, AdminWithRelations} from './admin.model';
import {Entity, model, property, belongsTo} from '@loopback/repository';

@model({settings: {}})
export class CommunicationLog extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
    required: true,
    jsonSchema: {
      enum: [
        'hub_visit',
        'telegram_chat',
        'whatsapp_chat',
        'sms',
        'call',
        'email',
      ],
    },
  })
  logType?: string;

  @property({
    type: 'string',
    required: true,
    jsonSchema: {
      enum: Object.values(CallInitiatorEnum),
    },
  })
  callInitiator?: CallInitiatorEnum;

  @property({
    type: 'date',
    // default: () => new Date(),
  })
  entryDate?: Date;

  @property({
    type: 'date',
    // default: () => new Date(),
  })
  time?: Date;

  @property({
    type: 'date',
    // default: () => new Date(),
  })
  endTime?: Date;

  @property({
    type: 'date',
    // default: () => new Date(),
  })
  logTime?: Date;

  @property({
    type: 'string',
    required: false,
    jsonSchema: {
      enum: ['regular', 'telegram', 'whatsapp'],
    },
  })
  callType?: string;

  @property({
    type: 'string',
    required: false,
    jsonSchema: {
      enum: ['private', 'group'],
    },
  })
  conversationType?: string;

  @property({
    type: 'boolean',
    required: false,
    default: false,
  })
  isBulk?: boolean;

  @property({
    type: 'string',
    required: false,
  })
  comment?: string;

  @belongsTo(() => Users, {name: 'user'})
  userId?: string;

  @belongsTo(() => Coach, {name: 'coach'})
  coachId?: string;

  @belongsTo(() => Admin, {name: 'admin'})
  adminId?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created?: Date;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified?: Date;

  constructor(data?: Partial<CommunicationLog>) {
    super(data);
  }
}

export interface CommunicationLogRelations {
  user?: UsersWithRelations;
  admin?: AdminWithRelations;
  coach?: CoachWithRelations;
}

export type CommunicationLogWithRelations = CommunicationLog &
  CommunicationLogRelations;
