import {Users, UsersWithRelations} from './users.model';
import {Coach, CoachWithRelations} from './coach.model';
import {Weight, WeightWithRelations} from './weight.model';
import {Height, HeightWithRelations} from './height.model';
import {Entity, belongsTo, model, property} from '@loopback/repository';

@model()
export class Bmi extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @belongsTo(() => Users, {name: 'user'})
  userId: string;

  @belongsTo(() => Coach, {name: 'coach'})
  coachId?: string;

  @property({
    type: 'number',
    required: true,
  })
  bmi: number;

  @property({
    type: 'string',
    required: false,
    default: 'KG/M Square',
  })
  unit?: string;

  @belongsTo(() => Weight, {name: 'weight'})
  weightId?: string;

  @belongsTo(() => Height, {name: 'height'})
  heightId?: string;

  @property({
    type: 'number',
    required: false,
  })
  heightValue?: number;

  @property({
    type: 'string',
    required: false,
  })
  heightUnit?: string;

  @property({
    type: 'number',
    required: false,
  })
  weightValue?: number;

  @property({
    type: 'string',
    required: false,
  })
  weightUnit?: string;

  @property({
    type: 'date',
    default: () => new Date(),
    required: false,
  })
  logDate?: string;

  @property({
    type: 'string',
    enum: ['web', 'mobile'],
    default: 'web',
  })
  channel: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created_at?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified_at?: string;

  constructor(data?: Partial<Bmi>) {
    super(data);
  }
}

export interface BmiRelations {
  user?: UsersWithRelations;
  coach?: CoachWithRelations;
  weight?: WeightWithRelations;
  height?: HeightWithRelations;
}

export type BmiWithRelations = Bmi & BmiRelations;
