import {Entity, model, property} from '@loopback/repository';
import {MedicationPassportWithRelations} from './medication-passport.model';

@model({settings: {}})
export class Medication extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
  })
  userId?: string;

  @property({
    type: 'string',
    required: true,
  })
  name: string;

  @property({
    type: 'string',
    required: false,
    default: 'pending',
    jsonSchema: {
      enum: ['pending', 'approved', 'rejected'],
    },
  })
  approvalStatus?: string;

  @property({
    type: 'date',
  })
  created?: string;

  @property({
    type: 'date',
  })
  modified?: string;

  constructor(data?: Partial<Medication>) {
    super(data);
  }
}

export interface MedicationRelations {
  medicine?: MedicationPassportWithRelations;
}

export type MedicationWithRelations = Medication & MedicationRelations;
