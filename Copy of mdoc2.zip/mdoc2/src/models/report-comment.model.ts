import {Entity, belongsTo, model, property} from '@loopback/repository';
import {Comment, CommentWithRelations} from './comment.model';
import {Users, UsersWithRelations} from './users.model';

@model()
export class ReportComment extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @belongsTo(() => Comment, {name: 'comment'})
  commentId: string;

  @belongsTo(() => Users, {name: 'user'})
  reportingUserId: string;

  @property({
    type: 'string',
    required: true,
  })
  reason: string;

  @property({
    type: 'string',
  })
  additionalComment?: string;

  constructor(data?: Partial<ReportComment>) {
    super(data);
  }
}

export interface ReportCommentRelations {
  comment?: CommentWithRelations;
  user?: UsersWithRelations;
}

export type ReportCommentWithRelations = ReportComment & ReportCommentRelations;
