import {
  model,
  Entity,
  hasMany,
  property,
  belongsTo,
} from '@loopback/repository';
import {Option} from './option.model';
import {Admin, AdminWithRelations} from './admin.model';
import {Programs, ProgramsWithRelations} from './programs.model';
import {Feedback, FeedbackWithRelations} from './feedback.model';
import { restrictionTypeEnum } from '../utils/enums';

@model()
export class Question extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @belongsTo(() => Admin, {name: 'createdBy'})
  createdByUserId: string;

  @belongsTo(() => Programs, {name: 'program'})
  programId?: string;

  @property({
    type: 'string',
    required: true,
  })
  questionText: string;

  @property({
    type: 'string',
    required: false,
  })
  minValue?: string;

  @property({
    type: 'string',
    required: false,
  })
  maxValue?: string;

  @property({
    type: 'string',
    required: false,
    default: 'multiple_choice',
    jsonSchema: {
      enum: ['multiple_choice', 'theory', 'date', 'multiple_answers', 'number'],
    },
  })
  questionType?: string;

  @property({
    type: 'string',
    required: false,
    jsonSchema: {
      enum: Object.values(restrictionTypeEnum), 
    },
  })
  restrictionType?: string;

  @property({
    type: 'number',
    required: false,
    default: 1,
  })
  score?: number;

  @property({
    type: 'number',
    required: false,
    default: 0,
  })
  order?: number;

  @property({
    type: 'string',
    required: false,
  })
  group?: string; // groups can be used to group the question by a mental health group eg: GAD7 or to a forum by the forum id

  @property({
    type: 'boolean',
    required: false,
    default: false,
  })
  isPregnancy?: boolean;

  @property({
    type: 'boolean',
    required: false,
    default: true,
  })
  isRequired?: boolean;

  @property({
    type: 'string',
    required: false,
    default: 'all',
    jsonSchema: {
      enum: ['male', 'female', 'all'],
    },
  })
  specificGender?: string;

  @hasMany(() => Option, {keyTo: 'questionId', name: 'options'})
  options: Option[];

  @belongsTo(() => Feedback, {name: 'feedback'})
  feedbackId?: string;

  @property({
    type: 'array',
    itemType: 'object',
    required: false,
  })
  defaultOptions?: Option[];

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created_at?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified_at?: string;

  constructor(data?: Partial<Question>) {
    super(data);
  }
}

export interface QuestionRelations {
  // describe navigational properties here
  createdBy?: AdminWithRelations;
  program?: ProgramsWithRelations;
  feedback?: FeedbackWithRelations;
  defaultOptions?: Option[];
}

export type QuestionWithRelations = Question & QuestionRelations;
