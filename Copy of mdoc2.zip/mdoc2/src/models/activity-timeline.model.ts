import {activityTypeObj} from '../type-schema';
import {Users, UsersWithRelations} from './users.model';
import {Entity, belongsTo, model, property} from '@loopback/repository';

@model()
export class ActivityTimeline extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
    jsonSchema: {
      enum: Object.values(activityTypeObj),
    },
    required: true,
  })
  activityType: string;

  @belongsTo(() => Users, {name: 'user'})
  userId: string;

  @property({
    type: 'string',
    required: false,
  })
  metadata?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created_at?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified_at?: string;

  constructor(data?: Partial<ActivityTimeline>) {
    super(data);
  }
}

export interface ActivityTimelineRelations {
  user?: UsersWithRelations;
}

export type ActivityTimelineWithRelations = ActivityTimeline &
  ActivityTimelineRelations;
