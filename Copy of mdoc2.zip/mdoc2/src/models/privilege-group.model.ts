import { Entity, hasMany, model, property } from '@loopback/repository';
import { Privilege, PrivilegeWithRelations } from './privilege.model';

@model()
export class PrivilegeGroup extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
    required: true,
  })
  name: string;

  @property({
    type: 'string',
    required: true,
  })
  value: string;

  @hasMany(() => Privilege, {keyFrom: 'privilegeGroupId'})
  privileges?: Privilege[]

  constructor(data?: Partial<PrivilegeGroup>) {
    super(data);
  }
}

export interface PrivilegeGroupRelations {
  // Define any relationships if needed
  privileges?: PrivilegeWithRelations[]
}

export type PrivilegeGroupWithRelations = PrivilegeGroup & PrivilegeGroupRelations;
