import {
  CoachSpeciality,
  CoachSpecialityWithRelations,
} from './coach-speciality.model';
import {
  CoachTypeSpeciality,
  CoachTypeSpecialityWithRelations,
} from './coach-type-speciality.model';
import {Entity, hasMany, model, property} from '@loopback/repository';

@model()
export class Speciality extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
  })
  name?: string;

  @property({
    type: 'string',
  })
  description?: string;

  @property({
    type: 'string',
    required: false,
    default: 'pending',
    jsonSchema: {
      enum: ['pending', 'approved', 'rejected'],
    },
  })
  approvalStatus?: string;

  @hasMany(() => CoachSpeciality, {keyTo: 'specialityId'})
  coaches?: string[];

  @hasMany(() => CoachTypeSpeciality, {keyTo: 'specialityId'})
  coachTypeSpeciality?: CoachTypeSpeciality[];

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created_at?: string;

  constructor(data?: Partial<Speciality>) {
    super(data);
  }
}

export interface SpecialityRelations {
  // describe navigational properties here
  coaches?: CoachSpecialityWithRelations;
  coachTypeSpeciality?: CoachTypeSpecialityWithRelations;
}

export type SpecialityWithRelations = Speciality & SpecialityRelations;
