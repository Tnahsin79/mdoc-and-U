import {
  FacilityTypeEnum,
  ReferralTypeEnum,
  ApprovalStatusEnum,
  AcceptanceStatusEnum,
} from '../utils/enums';
import {Admin, AdminWithRelations} from './admin.model';
import {Coach, CoachWithRelations} from './coach.model';
import {Users, UsersWithRelations} from './users.model';
import {HubVisit, HubVisitWithRelations} from './hub-visit.model';
import {Speciality, SpecialityWithRelations} from './speciality.model';
import {model, Entity, property, belongsTo} from '@loopback/repository';

@model()
export class Referral extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
    required: true,
    jsonSchema: {
      enum: Object.values(ReferralTypeEnum),
    },
  })
  referralType: ReferralTypeEnum;

  @property({
    type: 'string',
    required: true,
    jsonSchema: {
      enum: Object.values(FacilityTypeEnum),
    },
  })
  facilityType: FacilityTypeEnum;

  @property({
    type: 'string',
    required: false,
  })
  facilityTypeOther?: string;

  @belongsTo(() => HubVisit, {name: 'hubVisit'})
  hubVisitId?: string;

  @property({
    type: 'string',
    required: false,
    default: ApprovalStatusEnum.APPROVED,
    jsonSchema: {
      enum: Object.values(ApprovalStatusEnum),
    },
  })
  referralStatus?: ApprovalStatusEnum;

  @property({
    type: 'string',
    required: false,
    default: AcceptanceStatusEnum.PENDING,
    jsonSchema: {
      enum: Object.values(AcceptanceStatusEnum),
    },
  })
  acceptanceStatus?: AcceptanceStatusEnum;

  @belongsTo(() => Users, {name: 'user'})
  userId: string;

  @belongsTo(() => Coach, {name: 'senderCoach'})
  senderCoachId?: string;

  @belongsTo(() => Admin, {name: 'approvedBy'})
  approvedById?: string;

  @belongsTo(() => Coach, {name: 'receiverCoach'})
  receiverCoachId?: string;

  @belongsTo(() => Speciality, {name: 'specialty'})
  specialtyId?: string;

  @property({
    type: 'string',
    required: false,
  })
  facilityId?: string;

  @property({
    type: 'string',
    required: false,
  })
  userFullName?: string;

  @property({
    type: 'string',
    required: false,
  })
  facilityName?: string;

  @property({
    type: 'string',
    required: false,
  })
  facilityEmail?: string;

  @property({
    type: 'string',
    required: false,
  })
  facilityPhone?: string;

  @property({
    type: 'string',
    required: false,
  })
  facilityLocation?: string;

  @property({
    type: 'string',
    required: false,
  })
  coachCategory?: string;

  @property({
    type: 'date',
    required: true,
    default: new Date(),
  })
  referralDate: string;

  @property({
    type: 'string',
    required: true,
  })
  referralReason: string;

  @property({
    type: 'string',
    required: true,
  })
  reasonType: string;

  @belongsTo(() => Admin, {name: 'admin'})
  adminId: string;

  @property({
    type: 'string',
    required: true,
  })
  note: string;

  @property({
    type: 'date',
    required: false,
    default: () => new Date(),
  })
  created_at?: string;

  @property({
    type: 'date',
    required: false,
    default: () => new Date(),
  })
  modified_at?: string;

  constructor(data?: Partial<Referral>) {
    super(data);
  }
}

export interface ReferralRelations {
  // describe navigational properties here
  user?: UsersWithRelations;
  name?: AdminWithRelations;
  senderCoach?: CoachWithRelations;
  hubVisit?: HubVisitWithRelations;
  receiverCoach?: CoachWithRelations;
  speciality?: SpecialityWithRelations;
}

export type ReferralWithRelations = Referral & ReferralRelations;
