import {Users, UsersWithRelations} from './users.model';
import {Coach, CoachWithRelations} from './coach.model';
import {Consult, ConsultWithRelations} from './consult.model';
import {Provider, ProviderWithRelations} from './provider.model';
import {Entity, model, property, belongsTo} from '@loopback/repository';
import {GoalAction, GoalActionWithRelations} from './goal-action.model';

@model({settings: {}})
export class EyeExamination extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @belongsTo(() => Users)
  userId: string;

  @belongsTo(() => Consult, {name: 'consult'})
  consultId?: string;

  @belongsTo(() => Coach, {name: 'coach'})
  coachId?: string;

  @belongsTo(() => GoalAction, {name: 'goalAction'})
  goalActionId?: string;

  @property({
    type: 'string',
    required: false,
  })
  providerId?: string;

  @property({
    type: 'string',
    required: false,
  })
  address?: String;

  @property({
    type: 'string',
    required: false,
  })
  name?: String;

  @property({
    type: 'date',
    required: false,
  })
  testDate: string;

  @property({
    type: 'boolean',
    default: false,
  })
  isEyeExaminationComplete?: boolean;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified?: string;

  constructor(data?: Partial<EyeExamination>) {
    super(data);
  }
}

export interface EyeExaminationRelations {
  user?: UsersWithRelations;
  coach?: CoachWithRelations;
  consult?: ConsultWithRelations;
  provider?: ProviderWithRelations;
  goalAction?: GoalActionWithRelations;
}

export type EyeExaminationWithRelations = EyeExamination &
  EyeExaminationRelations;
