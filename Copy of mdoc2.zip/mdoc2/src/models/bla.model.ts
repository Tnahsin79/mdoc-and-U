import {Users, UsersWithRelations} from './users.model';
import {Option, OptionWithRelations} from './option.model';
import {Question, QuestionWithRelations} from './question.model';
import {Programs, ProgramsWithRelations} from './programs.model';
import {BlaRecord, BlaRecordWithRelations} from './bla-record.model';
import {Entity, belongsTo, model, property} from '@loopback/repository';

@model()
export class Bla extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @belongsTo(() => Users, {name: 'user'})
  userId: string;

  @belongsTo(() => Programs, {name: 'program'})
  programId?: string;

  @belongsTo(() => Question, {name: 'question'})
  questionId: string;

  @belongsTo(() => Option, {name: 'option'})
  selectedOptionId?: string;

  @property({
    type: 'array',
    itemType: 'string',
    default: [],
  })
  selectedOptionIds?: string[];

  @belongsTo(() => BlaRecord, {name: 'blaRecord'})
  blaRecordId: string;

  @property({
    type: 'string',
    required: false,
  })
  response?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created_at?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified_at?: string;

  constructor(data?: Partial<Bla>) {
    super(data);
  }
}

export interface BlaRelations {
  // describe navigational properties here
  user?: UsersWithRelations;
  option?: OptionWithRelations;
  program?: ProgramsWithRelations;
  question?: QuestionWithRelations;
  blaRecord?: BlaRecordWithRelations;
}

export type BlaWithRelations = Bla & BlaRelations;
