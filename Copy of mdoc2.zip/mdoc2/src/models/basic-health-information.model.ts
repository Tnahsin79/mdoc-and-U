import { Entity, model, property, belongsTo } from '@loopback/repository';
import { HealthQuestion, HealthQuestionWithRelations } from './health-question.model'

@model()
export class BasicHealthInformation extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
    required: true,
  })
  userId: string;

  @property({
    type: 'array',
    itemType: 'string',
  })
  questionId?: string[];

  @property({
    type: 'array',
    itemType: 'string',
  })
  answer: string[];

  @property({
    type: 'date',
    default: () => new Date()
  })
  created?: string;

  @property({
    type: 'date',
    default: () => new Date()
  })
  modified?: string;


  constructor(data?: Partial<BasicHealthInformation>) {
    super(data);
  }
}

export interface BasicHealthInformationRelations {
  // question?: HealthQuestionWithRelations,
}

export type BasicHealthInformationWithRelations = BasicHealthInformation & BasicHealthInformationRelations;
