import {Entity, model, property} from '@loopback/repository';

@model()
export class UserDoctors extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
    required: true,
  })
  doctorName: string;

  @property({
    type: 'string',
    required: false,
  })
  hospitalName?: string;

  @property({
    type: 'string',
  })
  address?: string;

  @property({
    type: 'string',
  })
  createdBy?: string;

  @property({
    type: 'number',
    required: false,
  })
  providerId?: number;

  @property({
    type: 'string',
  })
  userId?: string;

  @property({
    type: 'date',
  })
  created?: string;

  @property({
    type: 'date',
  })
  modified?: string;


  constructor(data?: Partial<UserDoctors>) {
    super(data);
  }
}

export interface UserDoctorsRelations {
  // describe navigational properties here
}

export type UserDoctorsWithRelations = UserDoctors & UserDoctorsRelations;
