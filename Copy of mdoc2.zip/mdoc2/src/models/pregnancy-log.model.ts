import {
  PregnancyCycle,
  PregnancyCycleWithRelations,
} from './pregnancy-cycle.model';
import {Entity, belongsTo, model, property} from '@loopback/repository';

@model()
export class PregnancyLog extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @belongsTo(() => PregnancyCycle, {name: 'pregnancyCycle'})
  pregnancyCycleId: string;

  @property({
    type: 'string',
    required: true,
  })
  userId: string;

  @property({
    type: 'date',
    required: true,
    default: () => new Date(),
  })
  date: Date;

  @property({
    type: 'string',
    required: true,
    jsonSchema: {
      enum: ['ancVisit', 'complication', 'event'],
    },
  })
  logType: string;

  @property({
    type: 'string',
    required: false,
  })
  description?: string;

  
  @property({
    type: 'date',
    default: () => new Date(),
    required: false
  })
  logDate?: string;

  
  @property({
    type: 'date',
    default: () => new Date(),
  })
  created_at?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified_at?: string;

  constructor(data?: Partial<PregnancyLog>) {
    super(data);
  }
}

export interface PregnancyLogRelations {
  pregnancyCycle: PregnancyCycleWithRelations;
}

export type PregnancyLogWithRelations = PregnancyLog & PregnancyLogRelations;
