import { Entity, model, property, belongsTo } from '@loopback/repository';
import { Coach, CoachWithRelations } from './coach.model'
import { Users, UsersWithRelations } from './users.model'

@model()
export class Appointment extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
  })
  bookingId?: string;

  @property({
    type: 'string',
  })
  createrId?: string;

  @property({
    type: 'number',
    default: 0 // 0 is pending , 1 is conform, 2 is cancel 3 is reschedule
  })
  status?: number;

  @belongsTo(() => Users, {name: 'user'})
  memberId?: string;


  @property({
    type: 'date',
    default: () => new Date()
  })
  appointmentDate?: string;

  @property({
    type: 'string'
  })
  appointmentTime?: string;

  @property({
    type: 'string'
  })
  source?: string;

  @property({
    type: 'string'
  })
  notes?: string;

  @belongsTo(() => Coach)
  coachId: string

  @property({
    type: 'date',
    default: () => new Date()
  })
  created?: string;

  @property({
    type: 'date',
    default: () => new Date()
  })
  modified?: string;


  constructor(data?: Partial<Appointment>) {
    super(data);
  }
}

export interface AppointmentRelations {
  coach?: CoachWithRelations,
  user?: UsersWithRelations
  // describe navigational properties here
}

export type AppointmentWithRelations = Appointment & AppointmentRelations;
