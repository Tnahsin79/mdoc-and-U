import {Users, UsersWithRelations} from './users.model';
import {Coach, CoachWithRelations} from './coach.model';
import {Entity, belongsTo, model, property} from '@loopback/repository';

@model()
export class ActionPlan extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @belongsTo(() => Users, {name: 'user'})
  userId: string;

  @belongsTo(() => Coach, {name: 'coach'})
  coachId?: string;

  @property({
    type: 'number',
    required: false,
  })
  isDownloaded?: string;

  @property({
    type: 'string',
    required: false,
  })
  attachment?: string;

  @property({
    type: 'string',
    required: true,
  })
  body?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified?: string;

  constructor(data?: Partial<ActionPlan>) {
    super(data);
  }
}

export interface ActionPlanRelations {
  // describe navigational properties here
  user?: UsersWithRelations;
  coach?: CoachWithRelations;
}

export type ActionPlanWithRelations = ActionPlan & ActionPlanRelations;
