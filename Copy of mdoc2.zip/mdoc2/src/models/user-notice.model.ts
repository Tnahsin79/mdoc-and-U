import {Users, UsersWithRelations} from './users.model';
import {Entity, belongsTo, model, property} from '@loopback/repository';
import { Notice, NoticeWithRelations } from './notice.model';

@model()
export class UserNotice extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @belongsTo(() => Users, {name: 'user'})
  userId?: string;

  @belongsTo(() => Notice, {
    name: 'notice',
  })
  noticeId: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created_at: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified_at: string;

  constructor(data?: Partial<UserNotice>) {
    super(data);
  }
}

export interface UserNoticeRelations {
  user?: UsersWithRelations;
  notice?: NoticeWithRelations;
}

export type UserNoticeWithRelations = UserNotice & UserNoticeRelations;
