import {Entity, model, property} from '@loopback/repository';
import {PlanTypeEnum} from '../utils/enums';

@model()
export class Plans extends Entity {
  @property({
    type: 'string',
  })
  name?: string;

  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
  })
  validity?: string;

  @property({
    type: 'string',
    required: true,
    jsonSchema: {
      enum: [
        PlanTypeEnum.Monthly,
        PlanTypeEnum.Quarterly,
        PlanTypeEnum.Sixmonths,
        PlanTypeEnum.Yearly,
      ],
    },
  })
  planType?: string;

  @property({
    type: 'number',
    required: true,
  })
  subsTypeId?: number;

  @property({
    type: 'number',
    required: true,
  })
  price: number;

  @property({
    type: 'string',
  })
  period?: string;

  @property({
    type: 'string',
    default: '1',
  })
  group?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created?: string;

  constructor(data?: Partial<Plans>) {
    super(data);
  }
}

export interface PlansRelations {
  // describe navigational properties here
}

export type PlansWithRelations = Plans & PlansRelations;
