import {Users} from './users.model';
import {BlogPost, BlogPostWithRelations} from './blog-post.model';
import {Entity, belongsTo, model, property} from '@loopback/repository';

@model()
export class ReportPost extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @belongsTo(() => BlogPost, {name: 'blogPost'})
  blogPostId: String;

  @belongsTo(() => Users, {name: 'user'})
  userId: String;

  @property({
    type: 'string',
    required: true,
  })
  reason: string;

  @property({
    type: 'string',
  })
  comment?: string;

  constructor(data?: Partial<ReportPost>) {
    super(data);
  }
}

export interface ReportPostRelations {
  // describe navigational properties here
  blogPost?: BlogPostWithRelations;
}

export type ReportPostWithRelations = ReportPost & ReportPostRelations;
