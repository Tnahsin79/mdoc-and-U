import {Admin, AdminWithRelations} from './admin.model';
import {Programs, ProgramsWithRelations} from './programs.model';
import {Entity, belongsTo, model, property} from '@loopback/repository';
import {ProgramPlans, ProgramPlansWithRelations} from './program-plans.model';
import { Users } from './users.model';
import { PaymentTypeEnum, VoucherTypeEnum } from '../utils/enums';

@model()
export class Voucher extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
    required: true,
  })
  code: string;

  @property({
    type: 'string',
    required: true,
  })
  title: string;

  @property({
    type: 'string',
    default: 'inactive',
    jsonSchema: {
      enum: ['inactive', 'active'],
    },
  })
  status: string;

  @property({
    type: 'string',
    required: false,
    default: 'pending',
    jsonSchema: {
      enum: ['pending', 'approved', 'rejected'],
    },
  })
  approvalStatus: string;

  @property({
    type: 'string',
    required: false,
  })
  declineReason?: string;

  @property({
    type: 'string',
    required: true,
    default: 'percentage',
    jsonSchema: {
      enum: ['fixed', 'percentage'],
    },
  })
  discountType: string;

  @property({
    type: 'string',
    required: false,
    default: 'group',
    jsonSchema: {
      enum: Object.values(VoucherTypeEnum),
    },
  })
  voucherType: VoucherTypeEnum;



  @property({
    type: 'number',
    required: true,
  })
  amount: number;

  @belongsTo(() => Users, {name: 'createdFor'})
  createdForUserId?: string;

  @belongsTo(() => Admin, {name: 'createdBy'})
  createdById?: string;

  @belongsTo(() => Programs, {name: 'program'})
  programId?: string;

  @belongsTo(() => ProgramPlans, {name: 'plan'})
  planId?: string;


  // The temporary fields below are for offline payments
  // The voucher is created first and therefore has to store some payment information

  @property({
    type: 'string',
    required: false,
    jsonSchema: {
      enum: [PaymentTypeEnum.Cash, PaymentTypeEnum.POS]
    },
  })
  paymentType: PaymentTypeEnum;

  @property({
    type: 'string',
    required: false,
  })
  reference: string;

  @property({
    type: 'date',
  })
  paymentDate?: string;

  // Ends here



  @property({
    type: 'date',
    default: () => new Date(),
  })
  startDate?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  endDate?: Date;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created_at?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  updated_at?: string;

  constructor(data?: Partial<Voucher>) {
    super(data);
  }
}

export interface VoucherRelations {
  // describe navigational properties here
  createdBy?: AdminWithRelations;
  plan?: ProgramPlansWithRelations;
  program?: ProgramsWithRelations;
}

export type VoucherWithRelations = Voucher & VoucherRelations;
