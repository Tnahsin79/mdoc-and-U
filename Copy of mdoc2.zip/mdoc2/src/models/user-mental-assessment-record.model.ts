import {
  model,
  Entity,
  hasMany,
  property,
  belongsTo,
} from '@loopback/repository';
import {
  UserMentalAssessment,
  UserMentalAssessmentWithRelations,
} from './user-mental-assessment.model';
import {Users, UsersWithRelations} from './users.model';
import {MentalAssessmentGroupEnum} from '../utils/enums';

@model()
export class UserMentalAssessmentRecord extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @belongsTo(() => Users, {name: 'user'})
  userId?: string;

  @hasMany(() => UserMentalAssessment, {
    keyTo: 'userMentalAssessmentRecordId',
    name: 'userMentalAssessments',
  })
  userMentalAssessments: UserMentalAssessment[];

  @property({
    type: 'string',
    jsonSchema: {
      enum: Object.values(MentalAssessmentGroupEnum),
    },
    required: true,
  })
  group: MentalAssessmentGroupEnum;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created_at: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified_at: string;

  constructor(data?: Partial<UserMentalAssessmentRecord>) {
    super(data);
  }
}

export interface UserMentalAssessmentRecordRelations {
  user?: UsersWithRelations;
  userMentalAssessments?: UserMentalAssessmentWithRelations[];
}

export type UserMentalAssessmentRecordWithRelations = UserMentalAssessmentRecord &
  UserMentalAssessmentRecordRelations;
