import {Consult} from './consult.model';
import {Users, UsersWithRelations} from './users.model';
import {Coach, CoachWithRelations} from './coach.model';
import {TemperatureEnum} from '../utils/health-metrics-functions';
import {Entity, belongsTo, model, property} from '@loopback/repository';

@model()
export class Temperature extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @belongsTo(() => Users, {name: 'user'})
  userId: string;

  @belongsTo(() => Consult, {name: 'consult'})
  consultId?: string;

  @belongsTo(() => Coach, {name: 'coach'})
  coachId?: string;

  @property({
    type: 'number',
    required: true,
  })
  value: number;

  @property({
    type: 'string',
    required: true,
    jsonSchema: {
      enum: ['web', 'mobile'],
    },
    default: 'web',
  })
  channel: string;

  @property({
    type: 'string',
    required: true,
    jsonSchema: {
      enum: Object.values(TemperatureEnum),
    },
  })
  unit: TemperatureEnum;

  @property({
    type: 'number',
    required: true,
  })
  defaultValue?: number;

  @property({
    type: 'string',
    required: false,
  })
  defaultUnit?: string;

  @property({
    type: 'date',
    default: () => new Date(),
    required: false,
  })
  logDate?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created_at?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified_at?: string;

  constructor(data?: Partial<Temperature>) {
    super(data);
  }
}

export interface TemperatureRelations {
  user?: UsersWithRelations;
  coach?: CoachWithRelations;
}

export type TemperatureWithRelations = Temperature & TemperatureRelations;
