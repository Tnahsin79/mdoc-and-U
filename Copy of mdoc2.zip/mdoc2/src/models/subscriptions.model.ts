import {Entity, model, property} from '@loopback/repository';
// import {calculateExpirationDate} from '../services/common';

enum PaymentDuration {
  '1 Month' = '1 Month',
  '3 Months' = '3 Months',
  '6 Months' = '6 Months',
  '12 Months' = '12 Months',
  'Free' = 'Free',
}

@model()
export class Subscriptions extends Entity {
  @property({
    type: 'string',
  })
  userId?: string;

  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
    required: true,
    jsonSchema: {
      enum: Object.values(PaymentDuration),
    },
  })
  planName: PaymentDuration;

  @property({
    type: 'string',
  })
  subscriptionName?: string;

  @property({
    type: 'string',
  })
  payer?: string;

  @property({
    type: 'string',
  })
  state?: string;

  @property({
    type: 'number',
    default: 1,
  })
  status?: number;

  @property({
    type: 'date',
  })
  renewalDate?: string;

  @property({
    type: 'string',
    default: undefined,
  })
  expireDate?: Date | null;

  @property({
    type: 'string',
  })
  subscriptionId?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created?: string;

  @property({
    type: 'string',
    default: 'propel',
  })
  subscriptionPackage?: string;

  constructor(data?: Partial<Subscriptions>) {
    super(data);
    // this.expireDate = calculateExpirationDate(this.renewalDate, this.planName);
  }
}

export interface SubscriptionsRelations {
  // describe navigational properties here
}

export type SubscriptionsWithRelations = Subscriptions & SubscriptionsRelations;
