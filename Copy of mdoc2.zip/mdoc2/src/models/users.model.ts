import {
  model,
  Entity,
  hasMany,
  property,
  AnyObject,
} from '@loopback/repository';
import {Note} from './note.model';
import {
  UserSubscriptions,
  UserSubscriptionsWithRelations,
} from './user-subscriptions.model';
import {
  WeightEnum,
  HeightEnum,
  TemperatureEnum,
  BloodGlucoseEnum,
  WaistCircumferenceEnum,
} from '../utils/health-metrics-functions';
import {CommunicationLog} from './communication-log.model';
import {Payments, PaymentsRelations} from './payments.model';
import {UserDisease, UserDiseaseWithRelations} from './user-disease.model';

@model({
  settings: {
    hiddenProperties: ['password'],
  },
})
export class Users extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
    index: true,
  })
  name?: string;

  @property({
    type: 'string',
  })
  firstName?: string;

  @property({
    type: 'string',
  })
  lastName?: string;

  @property({
    type: 'string',
  })
  image?: string;

  @property({
    type: 'string',
  })
  city?: string;

  @property({
    type: 'string',
  })
  country?: string;

  @property({
    type: 'string',
  })
  state?: string;

  @property({
    type: 'string',
  })
  address?: string;

  @property({
    type: 'string',
  })
  zipcode?: string;

  @property({
    type: 'number',
    default: 0,
  })
  rating?: number;

  @property({
    type: 'string',
    index: true,
  })
  phone?: string;

  @property({
    type: 'string',
    required: false,
    index: {unique: true},
    jsonSchema: {
      format: 'email',
      errorMessage: 'Invalid email format',
    },
  })
  email?: string;

  @property({
    type: 'string',
    required: false,
  })
  password?: string;

  @property({
    type: 'string',
    required: false,
  })
  md5password?: string;

  @property({
    type: 'number',
    required: false,
    index: true,
  })
  providerId?: number;

  @property({
    type: 'date',
  })
  dob?: string;

  @property({
    type: 'string',
  })
  gender?: string;

  @property({
    type: 'array',
    itemType: 'string',
    default: [],
  })
  languageId?: string[];

  @property({
    type: 'boolean',
    default: false,
  })
  isProfileComplete?: boolean;

  @property({
    type: 'boolean',
    default: false,
  })
  healthDiaryComplete?: boolean;

  @property({
    type: 'boolean',
    default: false,
  })
  basicHealthComplete?: boolean;

  @property({
    type: 'boolean',
    default: false,
  })
  pregnancyChildrenComplete?: boolean;

  @property({
    type: 'boolean',
    default: false,
  })
  healthPassportComplete?: boolean;

  @property({
    type: 'number',
  })
  weightGoal?: number;

  @property({
    type: 'number',
  })
  weight?: number;

  @property({
    type: 'number',
  })
  waistGoal?: number;

  @property({
    type: 'array',
    itemType: 'string',
    default: ['bloodPressure', 'bmi', 'weight', 'myMdocTeam'],
  })
  dashboardTabs: string[];

  @property({
    type: 'array',
    itemType: 'string',
    default: [
      'top',
      'chatBot',
      'actionPlan',
      'bloodPressure',
      'bloodGlucose',
      'weight',
      'bmi',
      'cholesterolProfile',
      'myExerciseRecords',
      'medication',
      'myMdocTeam',
      'waist',
      'medicalProcedures',
      'eyeExam',
      'healthCondition',
      'myPharmacy',
      'footExam',
      'myProvider',
      'pregnancy',
      'moodTracker',
      'addItem',
      'myLabs',
    ],
  })
  itemsOrder: string[];

  @property({
    type: 'boolean',
    default: false,
  })
  symptomComplete?: boolean;

  @property({
    type: 'boolean',
    default: false,
  })
  affordabilityComplete?: boolean;

  @property({
    type: 'boolean',
    default: false,
  })
  healthPlanComplete?: boolean;

  @property({
    type: 'boolean',
    default: false,
  })
  isOnline?: boolean;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  lastSeen?: string;

  @property({
    type: 'string',
    index: {
      unique: true,
    },
  })
  socketId?: string;

  @property({
    type: 'boolean',
    default: false,
  })
  isDeleted?: boolean;

  @property({
    type: 'boolean',
    default: true,
  })
  isPushNotification?: boolean;

  @property({
    type: 'object',
  })
  health?: object;

  @property({
    type: 'object',
    default: {facebookId: '', twitterId: '', googleId: ''},
  })
  social?: AnyObject;

  @property({
    type: 'object',
    default: {homePhone: '', cellPhone: '', workPhone: ''},
  })
  contactInfo?: AnyObject;

  @property({
    type: 'object',
    default: {country: '', state: '', city: '', address: '', zipcode: ''},
  })
  locationInfo?: AnyObject;

  @property({
    type: 'object',
    default: {emPhone: '', emcell: '', emworkPhone: ''},
  })
  emergencyInfo?: AnyObject;

  @property({
    type: 'number',
  })
  height?: number;

  @property({
    type: 'string',
    required: false,
    default: '',
  })
  otp?: string;

  @property({
    type: 'string',
  })
  fcmToken?: string;

  @property({
    type: 'string',
    default: HeightEnum.CM,
    jsonSchema: {
      enum: Object.values(HeightEnum),
    },
  })
  heightUnit?: HeightEnum;

  @property({
    type: 'string',
    default: TemperatureEnum.Celsius,
    jsonSchema: {
      enum: Object.values(TemperatureEnum),
    },
  })
  temperatureUnit?: TemperatureEnum;

  @property({
    type: 'string',
  })
  customerId?: string;

  @property({
    type: 'string',
    default: WeightEnum.KG,
    jsonSchema: {
      enum: Object.values(WeightEnum),
    },
  })
  weightUnit?: WeightEnum;

  @property({
    type: 'string',
    default: WaistCircumferenceEnum.IN,
    jsonSchema: {
      enum: Object.values(WaistCircumferenceEnum),
    },
  })
  waistUnit?: WaistCircumferenceEnum;

  @property({
    type: 'string',
    default: BloodGlucoseEnum['mmol/L'],
    jsonSchema: {
      enum: Object.values(BloodGlucoseEnum),
    },
  })
  bGlucoseUnit?: BloodGlucoseEnum;

  @property({
    type: 'string',
  })
  assignCoachId?: string;

  @property({
    type: 'boolean',
  })
  isLowIncome?: boolean;

  @property({
    type: 'string',
    jsonSchema: {
      enum: ['primary', 'secondary', 'tetiary', 'masters', 'doctorate', 'none'],
    },
  })
  educationalLevel?: string;

  @property({
    type: 'string',
    jsonSchema: {
      enum: [
        'high_blood_pressure',
        'diabetes',
        'obesity',
        'cancer',
        'anxiety',
        'depression',
        'none',
      ],
    },
  })
  chronicDisease?: string;

  @property({
    type: 'string',
  })
  referralCode?: string;

  @property({
    type: 'string',
  })
  referredByCode?: string;

  @property({
    type: 'number',
    default: 0,
  })
  status?: number;

  @property({
    type: 'string',
    jsonSchema: {
      enum: ['active', 'in-active'],
    },
  })
  activeStatus?: string;

  @property({
    type: 'string',
    jsonSchema: {
      enum: ['verified', 'unverified'],
    },
    default: 'unverified',
  })
  verificationStatus?: string;

  @property({
    type: 'string',
    jsonSchema: {
      enum: ['web', 'mobile'],
    },
  })
  onboardedPlatform: 'web' | 'mobile';

  @property({type: 'string', default: ''})
  lga?: string;

  @property({type: 'string', default: ''})
  refreshToken?: string;

  @property({type: 'date', required: false})
  otpExpiry?: string;

  @property({type: 'boolean', required: false, default: false})
  lockOnInactivity?: boolean;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified?: string;

  @property({
    type: 'date',
  })
  verifiedAt?: string;

  @property({
    type: 'boolean',
    required: false,
  })
  isTroveMember?: boolean;

  @property({
    type: 'date',
    required: false,
  })
  joinedTroveOn?: string;

  @hasMany(() => Payments)
  payments: Payments[];

  @hasMany(() => Note)
  notes: Note[];

  @hasMany(() => CommunicationLog)
  communicationLogs: CommunicationLog[];

  @hasMany(() => UserSubscriptions, {keyTo: 'userId'})
  subscriptions?: UserSubscriptions[];

  @hasMany(() => UserDisease, {keyTo: 'userId'})
  diseases?: UserDisease[];

  constructor(data?: Partial<Users>) {
    super(data);
    if (this.email) this.email = this.email.toLowerCase();
  }
}

export interface UsersRelations {
  // describe navigational properties here
  payments?: PaymentsRelations;
  diseases?: UserDiseaseWithRelations[];
  subscriptions?: UserSubscriptionsWithRelations[];
  // bloodPressures?: BloodPressureWithRelations[];
}

export type UsersWithRelations = Users & UsersRelations;
