import {Users, UsersWithRelations} from './users.model';
import {Coach, CoachWithRelations} from './coach.model';
import {Entity, model, property, belongsTo} from '@loopback/repository';
import { ChatRoom, ChatRoomWithRelations } from './chat-room.model';
import { SenderTypeEnum } from '../type-schema';
@model()
export class Chat extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
  })
  message?: string;


  @belongsTo(() => ChatRoom, {name: 'chatRoom'})
  chatRoomId?: string;

  @property({
    type: 'string',
  })
  senderId?: string;

  @property({
    type: 'string',
  })
  senderName?: string;

  @property({
    type: 'string',
  })
  senderImage?: string;

  @belongsTo(() => Users, {name: 'user'})
  senderUserId?: string;

  @belongsTo(() => Coach, {name: 'coach'})
  senderCoachId?: string;

  @property({
    type: 'string',
    required: true,
    jsonSchema: {
      enum: Object.values(SenderTypeEnum),
    },
  })
  senderTypeEnum: SenderTypeEnum;

  @property({
    type: 'string',
    required: false,
    default: '',
  })
  resourceUrl?: string;



  @property({
    type: 'array',
    itemType: 'string',
  })
  seen?: string[];

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created_at?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified_at?: string;

  constructor(data?: Partial<Chat>) {
    super(data);
  }
}

export interface ChatRelations {
  user?: UsersWithRelations;
  coach?: CoachWithRelations;
  chatRoom?: ChatRoomWithRelations;
}

export type ChatWithRelations = Chat & ChatRelations;
