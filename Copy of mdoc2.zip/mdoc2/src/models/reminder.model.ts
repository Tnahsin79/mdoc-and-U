import { Entity, model, property } from '@loopback/repository';

@model()
export class Reminder extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
    required: true,
  })
  userId: string;

  @property({
    type: 'string',
    required: true,
  })
  type: string;

  @property({
    type: 'array',
    itemType: 'string',
  })
  days?: string[];

  @property({
    type: 'number',
    required: false,
  })
  weightWaist: number;

  @property({
    type: 'date',
    default: undefined,
  })
  time?: string;

  @property({
    type: 'date',
    default: () => new Date()
  })
  created?: string;


  constructor(data?: Partial<Reminder>) {
    super(data);
  }
}

export interface ReminderRelations {
  // describe navigational properties here
}

export type ReminderWithRelations = Reminder & ReminderRelations;
