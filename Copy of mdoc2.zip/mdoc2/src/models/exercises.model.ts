import { Entity, model, property } from '@loopback/repository';

@model()
export class Exercises extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
  })
  userId?: string;

  @property({
    type: 'string',
    required: true,
  })
  title: string;

  @property({
    type: 'string',
    required: true,
  })
  description: string;

  @property({
    type: 'string',
    required: true,
  })
  url: string;

  @property({
    type: 'string',
    required: false,
  })
  passcode: string;

  @property({
    type: 'string',
    required: false,
    default: ""
  })
  day: string;

  @property({
    type: 'string',
    required: false,
    default: ""
  })
  coach: string;

  @property({
    type: 'string',
    required: true,
  })
  thumbnail: string;

  @property({
    type: 'string',
    required: false,
  })
  sessionTime: string;

  @property({
    type: 'date',
  })
  created?: string;


  constructor(data?: Partial<Exercises>) {
    super(data);
  }
}

export interface ExercisesRelations {
  // describe navigational properties here
}

export type ExercisesWithRelations = Exercises & ExercisesRelations;
