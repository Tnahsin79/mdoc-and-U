import {
  model,
  Entity,
  hasMany,
  property,
  belongsTo,
} from '@loopback/repository';
import {Admin, AdminWithRelations} from './admin.model';
import {Programs, ProgramsWithRelations} from './programs.model';
import {Question, QuestionWithRelations} from './question.model';

@model()
export class Feedback extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
    required: false,
  })
  userFirstName?: string;

  @property({
    type: 'string',
    required: false,
  })
  userLastName?: string;

  @property({
    type: 'string',
    required: false,
  })
  email?: string;

  @property({
    type: 'string',
    required: true,
    unique: true,
  })
  slug: string;

  @property({
    type: 'string',
    required: false,
  })
  phoneNumber?: string;

  @property({
    type: 'string',
    required: false,
  })
  comment?: string;

  @property({
    type: 'string',
    required: false,
  })
  title?: string;

  @hasMany(() => Question, {keyTo: 'feedbackId'})
  questions?: Question[];

  @property({
    type: 'string',
    required: false,
  })
  description?: string;

  @belongsTo(() => Admin, {name: 'creator'})
  creatorId?: string;

  @belongsTo(() => Programs, {name: 'program'})
  programId?: string;

  @property({
    type: 'string',
    required: false,
    jsonSchema: {enum: ['approved', 'pending', 'rejected']},
  })
  approvalStatus?: string;

  @belongsTo(() => Admin, {name: 'approvedBy'})
  approvedById?: string;

  @property({
    type: 'string',
    required: false,
    jsonSchema: {
      enum: ['survey', 'program', 'appointment', 'customer_support'],
    },
  })
  feedbackType?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created_at?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified_at?: string;

  constructor(data?: Partial<Feedback>) {
    super(data);
  }
}

export interface FeedbackRelations {
  creator?: AdminWithRelations;
  approvedBy?: AdminWithRelations;
  program?: ProgramsWithRelations;
  questions?: QuestionWithRelations;
}

export type FeedbackWithRelations = Feedback & FeedbackRelations;
