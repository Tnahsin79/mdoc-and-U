import {Entity, model, property} from '@loopback/repository';

@model()
export class Lab extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
    required: true,
  })
  name: string;

  @property({
    type: 'string',
    required: true,
  })
  userId: string;

  @property({
    type: 'date',
    default: () => new Date()
  })
  created?: string;

  @property({
    type: 'date',
    default: () => new Date()
  })
  modified?: string;


  constructor(data?: Partial<Lab>) {
    super(data);
  }
}

export interface LabRelations {
  // describe navigational properties here
}

export type LabWithRelations = Lab & LabRelations;
