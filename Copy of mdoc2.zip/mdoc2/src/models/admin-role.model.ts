import {Role, RoleWithRelations} from './role.model';
import {Admin, AdminWithRelations} from './admin.model';
import {Entity, belongsTo, model, property} from '@loopback/repository';

@model()
export class AdminRole extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @belongsTo(() => Admin, {name: 'admin'})
  adminId: string;

  @belongsTo(() => Role, {name: 'role'})
  roleId: string;

  @property({
    type: 'date',
    default: new Date()
  })
  createdAt?: Date;

  @property({
    type: 'date',
  })
  updatedAt?: Date;

  constructor(data?: Partial<AdminRole>) {
    super(data);
  }
}

export interface AdminRoleRelations {
  admin?: AdminWithRelations;
  role?: RoleWithRelations;
}

export type AdminRoleWithRelations = AdminRole & AdminRoleRelations;
