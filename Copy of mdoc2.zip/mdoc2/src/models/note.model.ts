import {Coach, CoachWithRelations} from './coach.model';
import {Users, UsersWithRelations} from './users.model';
import {Consult, ConsultWithRelations} from './consult.model';
import {HubVisit, HubVisitWithRelations} from './hub-visit.model';
import {Entity, model, property, belongsTo} from '@loopback/repository';

@model({settings: {}})
export class Note extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @belongsTo(() => Consult, {name: 'consult'})
  consultId?: string;

  @belongsTo(() => HubVisit, {name: 'hubVisit'})
  hubVisitId?: string;

  @property({
    type: 'string',
    required: true,
  })
  title?: string;

  @property({
    type: 'string',
    required: false,
  })
  signsAndSymptoms?: string;

  @property({
    type: 'string',
    required: false,
  })
  allergies?: string;

  @property({
    type: 'string',
    required: false,
  })
  medications?: string;

  @property({
    type: 'string',
    required: false,
  })
  pastMedicalHistory?: string;

  @property({
    type: 'string',
    required: false,
  })
  lastMeal?: string;

  @property({
    type: 'string',
    required: false,
  })
  emergencyEvents?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  date?: string;

  @property({
    type: 'string',
    required: false,
  })
  levelOfConsciousness?: string;

  @property({
    type: 'string',
    required: false,
  })
  breathing?: string;

  @property({
    type: 'string',
    required: false,
  })
  circulation?: string;

  @property({
    type: 'string',
    required: false,
  })
  skin?: string;

  @property({
    type: 'string',
    required: false,
  })
  headToToe?: string;

  @property({
    type: 'string',
    required: false,
  })
  summary?: string;

  @belongsTo(() => Users, {name: 'user'})
  userId?: string;

  @belongsTo(() => Coach, {name: 'coach'})
  coachId?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified?: string;

  constructor(data?: Partial<Note>) {
    super(data);
  }
}

export interface NoteRelations {
  user?: UsersWithRelations;
  coach?: CoachWithRelations;
  consult?: ConsultWithRelations;
  hubVisit?: HubVisitWithRelations;
}

export type NoteWithRelations = Note & NoteRelations;
