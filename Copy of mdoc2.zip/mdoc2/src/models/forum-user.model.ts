import {Forum, ForumWithRelations} from './forum.model';
import {Users, UsersWithRelations} from './users.model';
import {Entity, model, property, belongsTo} from '@loopback/repository';

@model()
export class ForumUser extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @belongsTo(() => Forum, {name: 'forum'})
  forumId?: string;

  @belongsTo(() => Users, {name: 'user'})
  userId?: string;

  @property({
    type: 'string',
    required: false,
  })
  cohort?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created_at?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified_at?: string;

  constructor(data?: Partial<ForumUser>) {
    super(data);
  }
}

export interface ForumUserRelations {
  forum?: ForumWithRelations;
  user?: UsersWithRelations;
}

export type ForumUserWithRelations = ForumUser & ForumUserRelations;
