import {
  model,
  Entity,
  hasMany,
  property,
  belongsTo,
} from '@loopback/repository';
import {Admin, AdminWithRelations} from './admin.model';
import {Coach, CoachWithRelations} from './coach.model';
import {Programs, ProgramsWithRelations} from './programs.model';
import {ForumUser, ForumUserWithRelations} from './forum-user.model';

@model({settings: {}})
export class Forum extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @belongsTo(() => Coach, {name: 'createdBy'})
  coachId: string;

  @belongsTo(() => Programs, {name: 'program'})
  programId?: string;

  @property({
    type: 'string',
    required: true,
  })
  topic: string;

  @property({
    type: 'string',
    required: true,
  })
  description: string;

  @property({
    type: 'array',
    itemType: 'string',
    required: false,
    default: [],
  })
  cohorts: string[];

  @property({
    type: 'string',
    required: true,
    default: 'pending',
    jsonSchema: {
      enum: ['pending', 'approved', 'rejected'],
    },
  })
  approvalStatus: string;

  @belongsTo(() => Admin, {name: 'approver'})
  approvedBy?: string;

  @property({
    type: 'date',
    default: undefined,
  })
  approvalDate?: string;

  @property({
    type: 'string',
  })
  cancelReason?: boolean;

  @property({
    type: 'number',
    required: false,
    default: 0,
  })
  minimumEntryScore?: number;

  @hasMany(() => ForumUser, {keyTo: 'forumId'})
  participants: ForumUser[];

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created_at?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified_at?: string;

  constructor(data?: Partial<Forum>) {
    super(data);
  }
}

export interface ForumRelations {
  createdBy?: CoachWithRelations;
  approver?: AdminWithRelations;
  program?: ProgramsWithRelations;
  participants?: ForumUserWithRelations[];
}

export type ForumWithRelations = Forum & ForumRelations;
