import {
  model,
  Entity,
  hasOne,
  property,
  belongsTo,
} from '@loopback/repository';
import {
  CoachUserSubscriptions,
  CoachUserSubscriptionsWithRelations,
} from './coach-user-subscriptions.model';
import {PlanTypeEnum} from '../utils/enums';
import {Users, UsersWithRelations} from './users.model';
import { Voucher, VoucherWithRelations } from './voucher.model';
import {Programs, ProgramsWithRelations} from './programs.model';
import {Payments, PaymentsWithRelations} from './payments.model';
import {ProgramPlans, ProgramPlansWithRelations} from './program-plans.model';

@model()
export class UserSubscriptions extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @belongsTo(() => Users, {name: 'user'})
  userId?: string;

  @belongsTo(() => ProgramPlans, {name: 'plan'})
  planId?: string;

  @belongsTo(() => Voucher, {name: 'voucher'})
  voucherId?: string;

  @belongsTo(() => Programs, {name: 'program'})
  programId?: string;

  @belongsTo(() => Payments, {name: 'payment'})
  paymentId?: string;
  
  @property({
    type: 'string',
    jsonSchema: {
      enum: [
        'precontemplation',
        'contemplation',
        'preparation',
        'action',
        'maintenance',
      ]
    }
  })
  changeStage?: string;

  @property({
    type: 'string',
    required: false,
  })
  userFullName?: string; // This helps the search

  @property({
    type: 'string',
    required: false,
  })
  tag?: string;

  @property({
    type: 'string',
    required: false,
    jsonSchema: {
      enum: [
        PlanTypeEnum.Monthly,
        PlanTypeEnum.Quarterly,
        PlanTypeEnum.Sixmonths,
        PlanTypeEnum.Yearly,
      ],
    },
  })
  subscriptionType?: string;

  @property.array(Object, {itemType: 'object'})
  history?: Array<{
    startDate: Date;
    endDate: Date;
    payment: {amount: number; id: string};
    plan: {id: string; title: string};
  }>;

  @hasOne(() => CoachUserSubscriptions, {
    keyTo: 'userSubscriptionId',
    name: 'coach',
  })
  coach?: CoachUserSubscriptions;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  startDate?: Date;

  @property({
    type: 'number',
    required: false,
    default: 0,
  })
  blaCount?: number;

  @property({
    type: 'date',
    default: undefined,
  })
  endDate?: Date;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified?: string;

  constructor(data?: Partial<UserSubscriptions>) {
    super(data);
  }
}

export interface UserSubscriptionsRelations {
  user?: UsersWithRelations;
  plan?: ProgramPlansWithRelations;
  program?: ProgramsWithRelations;
  payment?: PaymentsWithRelations;
  coach?: CoachUserSubscriptionsWithRelations;
  voucher?: VoucherWithRelations
}

export type UserSubscriptionsWithRelations = UserSubscriptions &
  UserSubscriptionsRelations;
