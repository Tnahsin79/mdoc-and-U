import {Users, UsersWithRelations} from './users.model';
import {Coach, CoachWithRelations} from './coach.model';
import {Entity, belongsTo, model, property} from '@loopback/repository';

@model()
export class WeightGoal extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @belongsTo(() => Users, {name: 'user'})
  userId: string;

  @belongsTo(() => Coach, {name: 'coach'})
  coachId?: string;

  @property({
    type: 'number',
    required: true,
  })
  value: number;
  
  @property({
    type: 'date',
    default: () => new Date(),
    required: false
  })
  logDate?: string;

  @property({
    type: 'string',
    required: true,
  })
  unit: string;

  @property({
    type: 'string',
    enum: ['web', 'mobile'],
    default: 'web',
  })
  channel: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified?: string;

  constructor(data?: Partial<WeightGoal>) {
    super(data);
  }
}

export interface WeightGoalRelations {
  user?: UsersWithRelations;
  coach?: CoachWithRelations;
}

export type WeightGoalWithRelations = WeightGoal & WeightGoalRelations;
