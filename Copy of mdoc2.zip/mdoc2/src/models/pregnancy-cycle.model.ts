import {
  model,
  Entity,
  hasMany,
  property,
  belongsTo,
} from '@loopback/repository';
import {Users, UsersWithRelations} from './users.model';
import {PregnancyLog, PregnancyLogWithRelations} from './pregnancy-log.model';

@model()
export class PregnancyCycle extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @belongsTo(() => Users, {name: 'user'})
  userId: string;

  @property({
    type: 'date',
    required: false,
  })
  expectedDeliveryDate?: Date;

  @property({
    type: 'string',
    required: false,
    jsonSchema: {
      enum: [
        'Monday',
        'Tuesday',
        'Wednesday',
        'Thursday',
        'Wednesday',
        'Friday',
        'Saturday',
        'Sunday',
      ],
    },
  })
  ancDay?: string;

  @property({
    type: 'string',
    required: false,
  })
  facilityId?: string;

  @property({
    type: 'string',
    required: false,
  })
  facilityName?: string;

  @property({
    type: 'string',
    required: false,
    jsonSchema: {
      enum: ['male', 'female'],
    },
  })
  gender?: string;

  @property({
    type: 'number',
    required: false,
  })
  babyLength?: number;

  @property({
    type: 'number',
    required: false,
  })
  babyWeight?: number;

  @property({
    type: 'date',
    required: false,
  })
  miscarriageDate?: string;

  @property({
    type: 'date',
    required: false,
  })
  deliveryDate?: string;

  @property({
    type: 'date',
    required: false,
  })
  abortionDate?: string;

  @property({
    type: 'boolean',
    default: true,
  })
  isActive?: boolean;

  @hasMany(() => PregnancyLog, {keyTo: 'pregnancyCycleId'})
  pregnancyLogs: PregnancyLog[];

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created_at?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified_at?: string;

  constructor(data?: Partial<PregnancyCycle>) {
    super(data);
  }
}

export interface PregnancyCycleRelations {
  user?: UsersWithRelations;
  pregnancyLogs?: PregnancyLogWithRelations;
}

export type PregnancyCycleWithRelations = PregnancyCycle &
  PregnancyCycleRelations;
