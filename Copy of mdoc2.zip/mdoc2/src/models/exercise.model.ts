import {
  ExerciseTypes,
  ExerciseTypesWithRelations,
} from './exercise-types.model';
import {Users, UsersWithRelations} from './users.model';
import {Coach, CoachWithRelations} from './coach.model';
import {Consult, ConsultWithRelations} from './consult.model';
import {HubVisit, HubVisitWithRelations} from './hub-visit.model';
import {Entity, belongsTo, model, property} from '@loopback/repository';
import {GoalAction, GoalActionWithRelations} from './goal-action.model';

@model()
export class Exercise extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @belongsTo(() => Users, {name: 'user'})
  userId: string;

  @belongsTo(() => Consult, {name: 'consult'})
  consultId?: string;

  @belongsTo(() => GoalAction, {name: 'goalAction'})
  goalActionId?: string;

  @belongsTo(() => Coach, {name: 'coach'})
  coachId?: string;

  @belongsTo(() => ExerciseTypes, {name: 'exerciseType'})
  exerciseTypeId?: string;

  @property({
    type: 'string',
    required: true,
    jsonSchema: {
      enum: ['High', 'Medium', 'Low'],
    },
  })
  intensity: string;

  @belongsTo(() => HubVisit, {name: 'hubVisit'})
  hubVisitId?: string;

  @property({
    type: 'date',
    default: () => new Date(),
    required: false,
  })
  logDate?: string;

  @property({
    type: 'number',
    required: true,
  })
  duration: number;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  startTime: string;

  @property({
    type: 'string',
    jsonSchema: {
      enum: ['web', 'mobile'],
    },
    default: 'web',
  })
  channel: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created_at?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified_at?: string;

  constructor(data?: Partial<Exercise>) {
    super(data);
  }
}

export interface ExerciseRelations {
  user?: UsersWithRelations;
  coach?: CoachWithRelations;
  consult?: ConsultWithRelations;
  hubVisit?: HubVisitWithRelations;
  goalAction?: GoalActionWithRelations;
  exerciseType?: ExerciseTypesWithRelations;
}

export type ExerciseWithRelations = Exercise & ExerciseRelations;
