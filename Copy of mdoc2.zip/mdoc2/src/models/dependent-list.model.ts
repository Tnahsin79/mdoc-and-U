import {Entity, belongsTo, model, property} from '@loopback/repository';
import { HubVisitWithRelations } from './hub-visit.model';
import { GenderTypeEnum, RelationshipTypeEnum } from '../utils/enums';
import {Users, UsersWithRelations} from './users.model';

@model()
export class DependentList extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @belongsTo(() => Users, {name: 'user'})
  userId: string;

  @property({
    type: 'string',
    required: true,
  })
  firstName: string;

  @property({
    type: 'string',
    required: true,
  })
  lastName: string;

  @property({
    type: "string",
    required: true,
    jsonSchema: {
      enum: Object.values(GenderTypeEnum),
    },
  })
  gender: string;

  @property({
    type: "string",
    required: true,
    jsonSchema: {
      enum: Object.values(RelationshipTypeEnum),
    },
  })
  relationship: string;

  @property({
    type: 'number',
    required: true,
  })
  age: number;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created_at?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified_at?: string;

  constructor(data?: Partial<DependentList>) {
    super(data);
  }
}

export interface DependentListRelations {
  user?: UsersWithRelations;
  hubVisit: HubVisitWithRelations;
}

export type DependentListWithRelations = DependentList & DependentListRelations;
