import {
  model,
  Entity,
  hasMany,
  property,
  belongsTo,
} from '@loopback/repository';
import {Forum} from './forum.model';
import {Users, UsersWithRelations} from './users.model';
import {Coach, CoachWithRelations} from './coach.model';
import {BlogPost, BlogPostWithRelations} from './blog-post.model';
import {CommentReply, CommentReplyWithRelations} from './comment-reply.model';

@model({settings: {}})
export class Comment extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @belongsTo(() => Users, {name: 'user'})
  userId: string;

  @belongsTo(() => BlogPost, {name: 'blogPost'})
  blogPostId?: string;

  @belongsTo(() => Forum, {name: 'forum'})
  forumId?: string;

  @belongsTo(() => Coach, {name: 'coach'})
  coachId?: string;

  @property({type: 'string', default: ''})
  replyToCommentId?: string;

  @property({type: 'string', default: ''})
  userName?: string;

  @property({
    type: 'array',
    itemType: 'string',
  })
  seen?: string[];

  @property({type: 'string', default: ''})
  userImage?: string;

  @property({type: 'number', default: 0})
  totalReplies?: number;

  @property({
    type: 'array',
    itemType: 'string',
    required: false,
  })
  likes?: string[];

  @property({
    type: 'array',
    itemType: 'string',
    required: false,
  })
  dislikes?: string[];

  @property({
    type: 'string',
    required: true,
  })
  comment: string;

  @hasMany(() => CommentReply, {keyTo: 'parentCommentId'})
  replies?: CommentReply[];

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created_at?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified_at?: string;

  constructor(data?: Partial<Comment>) {
    super(data);
  }
}

export interface CommentRelations {
  blogPost?: BlogPostWithRelations;
  user?: UsersWithRelations;
  coach?: CoachWithRelations;
  replies?: CommentReplyWithRelations;
}

export type CommentWithRelations = Comment & CommentRelations;
