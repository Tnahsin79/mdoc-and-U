import {Coach, CoachWithRelations} from './coach.model';
import {Users, UsersWithRelations} from './users.model';
import {ChatRoom, ChatRoomWithRelations} from './chat-room.model';
import {Entity, belongsTo, model, property} from '@loopback/repository';

@model()
export class ChatRoomUser extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @belongsTo(() => Coach, {name: 'coach'})
  coachId: string;

  @belongsTo(() => Users, {name: 'user'})
  userId: string;

  @belongsTo(() => ChatRoom, {name: 'chatRoom'})
  chatRoomId: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created?: string;

  @property({
    type: 'date',
  })
  modified?: string;

  constructor(data?: Partial<ChatRoomUser>) {
    super(data);
  }
}

export interface ChatRoomUserRelations {
  coach?: CoachWithRelations;
  user?: UsersWithRelations;
  chatRoom?: ChatRoomWithRelations;
}

export type ChatRoomUserWithRelations = ChatRoomUser & ChatRoomUserRelations;
