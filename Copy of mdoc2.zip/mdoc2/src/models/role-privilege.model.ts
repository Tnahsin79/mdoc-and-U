import { Entity, model, property, belongsTo } from '@loopback/repository';
import { Role, RoleWithRelations } from './role.model';
import { Privilege, PrivilegeWithRelations } from './privilege.model';

@model()
export class RolePrivilege extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @belongsTo(() => Role, { name: 'role' })
  roleId: string;

  @belongsTo(() => Privilege, { name: 'privilege' })
  privilegeId: string;

  constructor(data?: Partial<RolePrivilege>) {
    super(data);
  }
}

export interface RolePrivilegeRelations {
  // Define the relationship with Role model
  role?: RoleWithRelations;
  privilege?: PrivilegeWithRelations;
}

export type RolePrivilegeWithRelations = RolePrivilege & RolePrivilegeRelations;
