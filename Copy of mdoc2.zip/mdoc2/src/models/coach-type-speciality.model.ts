import {CoachType, CoachTypeWithRelations} from './coach-type.model';
import {Speciality, SpecialityWithRelations} from './speciality.model';
import {Entity, belongsTo, model, property} from '@loopback/repository';

@model()
export class CoachTypeSpeciality extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @belongsTo(() => CoachType, {name: 'coachType'})
  coachTypeId?: string;

  @belongsTo(() => Speciality, {name: 'speciality'})
  specialityId?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified?: string;

  constructor(data?: Partial<CoachTypeSpeciality>) {
    super(data);
  }
}

export interface CoachTypeSpecialityRelations {
  coachType?: CoachTypeWithRelations;
  speciality?: SpecialityWithRelations;
}

export type CoachTypeSpecialityWithRelations = CoachTypeSpeciality &
  CoachTypeSpecialityRelations;
