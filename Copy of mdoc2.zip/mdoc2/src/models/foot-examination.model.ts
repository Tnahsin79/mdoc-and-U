import {Coach, CoachWithRelations} from './coach.model';
import {Users, UsersWithRelations} from './users.model';
import {Entity, model, property, belongsTo} from '@loopback/repository';

@model()
export class FootExamination extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @belongsTo(() => Users)
  userId: string;

  @belongsTo(() => Coach, {name: 'coach'})
  coachId?: string;

  @property({
    type: 'string',
    required: false,
  })
  providerId: string;

  @property({
    type: 'boolean',
    default: false,
  })
  isFootExaminationComplete?: boolean;

  @property({
    type: 'string',
    required: true,
  })
  name: string;

  @property({
    type: 'string',
    required: false,
  })
  city?: string;

  @property({
    type: 'string',
  })
  address?: string;

  @property({
    type: 'date',
    required: true,
  })
  testDate: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified?: string;

  constructor(data?: Partial<FootExamination>) {
    super(data);
  }
}

export interface FootExaminationRelations {
  // describe navigational properties here
  user?: UsersWithRelations;
  coach?: CoachWithRelations;
}

export type FootExaminationWithRelations = FootExamination &
  FootExaminationRelations;
