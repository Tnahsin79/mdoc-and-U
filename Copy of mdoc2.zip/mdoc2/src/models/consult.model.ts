import Utils from '../utils';
import {
  BloodPressure,
  BloodPressureWithRelations,
} from './blood-pressure.model';
import {
  EyeExamination,
  EyeExaminationWithRelations,
} from './eye-examination.model';
import {
  MedicationPassport,
  MedicationPassportWithRelations,
} from './medication-passport.model';
import {Cholestrol} from './cholestrol.model';
import {Users, UsersWithRelations} from './users.model';
import {Coach, CoachWithRelations} from './coach.model';
import {Hbaic, HbaicWithRelations} from './hbaic.model';
import {Weight, WeightWithRelations} from './weight.model';
import {Height, HeightWithRelations} from './height.model';
import {Partner, PartnerWithRelations} from './partner.model';
import {Note, NoteWithRelations} from './note.model';
import {Exercise, ExerciseWithRelations} from './exercise.model';
import {ConsultOutcomeEnum, ConsultStatusEnum, DiagnosisTypeEnum, MeetingPlatformEnum} from '../utils/enums';
import {BloodSugar, BloodSugarWithRelations} from './blood-sugar.model';
import {Temperature, TemperatureWithRelations} from './temperature.model';
import {Entity, belongsTo, hasMany, hasOne, model, property} from '@loopback/repository';
import { HubVisit } from './hub-visit.model';
import { Glitches, GlitchesWithRelations } from './gliches.model';

@model({
  settings: {
    hiddenProperties: ['passcode'],
  },
})
export class Consult extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @belongsTo(() => Users, {name: 'user'})
  userId: string;

  @belongsTo(() => Partner, {name: 'partner'})
  partnerId: string;

  @belongsTo(() => HubVisit, {name: 'hubVisit'})
  hubVisitId: string;

  @belongsTo(() => Coach, {name: 'coach'})
  coachId?: string;

  @property({
    type: 'string',
    required: false,
    jsonSchema: {
      enum: ['web', 'mobile', 'ussd'],
    },
    default: 'web',
  })
  channel?: string;

  @property({
    type: 'string',
    required: false,
    jsonSchema: {
      enum: Object.values(MeetingPlatformEnum),
    },
  })
  meetingPlatform?: MeetingPlatformEnum;

  @property({
    type: 'string',
    required: false,
  })
  userFullName?: string;

  @property({
    type: 'string',
    required: false,
  })
  additionalNotes?: string;

  @property({
    type: 'string',
    required: false,
    default: Utils.generateRandomCode(),
  })
  passcode?: string;

  @property({
    type: 'string',
    required: false,
    default: '',
  })
  meetingResource?: string;

  @property({
    type: 'string',
    required: false,
    jsonSchema: {
      enum: Object.values(ConsultStatusEnum),
    },
    default: ConsultStatusEnum.BOOKED,
  })
  status?: ConsultStatusEnum;

  @property({
    type: 'date',
    default: () => new Date(),
    required: false,
  })
  preferredDate?: string;

  @property({
    type: 'date',
    required: false,
  })
  consultDate?: string;

  @property({
    type: 'string',
    required: true,
  })
  consultReason: string;

  @property({
    type: 'string',
    required: true,
  })
  reasonType: string;

  @hasOne(() => Height, {name: 'height'})
  height?: Height;

  @hasMany(() => Glitches, {keyTo: 'consultId', name: 'glitches'})
  glitches?: Glitches[];

  @hasOne(() => Weight, {name: 'weight'})
  weight?: Weight;

  @hasOne(() => BloodPressure, {name: 'bloodPressure'})
  bloodPressure?: BloodPressure;

  @hasOne(() => BloodSugar, {name: 'bloodSugar'})
  bloodSugar?: BloodSugar;

  @hasOne(() => Hbaic, {name: 'hbaic'})
  hbaic?: Hbaic;

  @hasOne(() => MedicationPassport, {name: 'medication'})
  medication?: MedicationPassport;

  @hasOne(() => Cholestrol, {name: 'cholestrol'})
  cholestrol?: Cholestrol;

  @hasOne(() => EyeExamination, {name: 'eyeExamination'})
  eyeExamination?: EyeExamination;

  @hasOne(() => Temperature, {name: 'temperature'})
  temperature?: Temperature;

  @hasOne(() => Exercise, {name: 'exercise'})
  exercise?: Exercise;

  @hasOne(() => Note, {name: 'note'})
  note?: Note;

  @property({
    type: 'string',
    required: true,
    jsonSchema: {
      enum: Object.values(ConsultOutcomeEnum),
    },
  })
  consultOutcome: ConsultOutcomeEnum[];

  @property({
    type: "string",
    required: false,
    jsonSchema: {
      enum: Object.values(DiagnosisTypeEnum),
    },
  })
  diagnosis?: DiagnosisTypeEnum[];

  @property({
    type: 'string',
    required: false,
  })
  diagnosisOther?: string;

  @property({
    type: 'date',
    required: false,
  })
  followUpDate?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created_at?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified_at?: string;

  constructor(data?: Partial<Consult>) {
    super(data);
  }
}

export interface ConsultRelations {
  user?: UsersWithRelations;
  coach?: CoachWithRelations;
  height?: HeightWithRelations;
  weight?: WeightWithRelations;
  temperature?: TemperatureWithRelations;
  note?: NoteWithRelations;
  bloodSugar?: BloodSugarWithRelations;
  bloodPressure?: BloodPressureWithRelations;
  hbaic?: HbaicWithRelations;
  eyeExamination?: EyeExaminationWithRelations;
  exercise?: ExerciseWithRelations;
  cholestrol?: Cholestrol;
  partner?: PartnerWithRelations;
  medication?: MedicationPassportWithRelations;
  glitches?: GlitchesWithRelations[];
}

export type ConsultWithRelations = Consult & ConsultRelations;
