import {
  model,
  Entity,
  hasMany,
  property,
  belongsTo,
} from '@loopback/repository';
import {Users, UsersWithRelations} from './users.model';
import {UserFeedbackAnswer} from './user-feedback-answer.model';
import {Feedback, FeedbackWithRelations} from './feedback.model';
import {HubVisit, HubVisitWithRelations} from './hub-visit.model';

@model()
export class UserFeedback extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @belongsTo(() => Users, {name: 'user'})
  userId?: string;

  @belongsTo(() => HubVisit, {name: 'hubVisit'})
  hubVisitId?: string;

  @property({
    type: 'string',
    required: false,
  })
  userFirstName?: string;

  @property({
    type: 'string',
    required: false,
  })
  userLastName?: string;

  @property({
    type: 'string',
    required: false,
  })
  email?: string;

  @property({
    type: 'string',
    required: false,
  })
  phoneNumber?: string;

  @property({
    type: 'string',
    required: false,
  })
  comment?: string;

  @belongsTo(() => Feedback, {name: 'feedback'})
  feedbackId?: string;

  @property({
    type: 'string',
    required: true,
    default: 'pending',
    jsonSchema: {enum: ['skipped', 'completed', 'pending']},
  })
  status: string;

  @hasMany(() => UserFeedbackAnswer, {keyTo: 'userFeedbackId'})
  userFeedbackAnswers: UserFeedbackAnswer[];

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created_at?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified_at?: string;

  constructor(data?: Partial<UserFeedback>) {
    super(data);
  }
}

export interface UserFeedbackRelations {
  user?: UsersWithRelations;
  hubVisit?: HubVisitWithRelations;
  feedback?: FeedbackWithRelations;
}

export type UserFeedbackWithRelations = UserFeedback & UserFeedbackRelations;
