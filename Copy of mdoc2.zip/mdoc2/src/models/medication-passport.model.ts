import {Consult} from './consult.model';
import {Users, UsersWithRelations} from './users.model';
import {Coach, CoachWithRelations} from './coach.model';
import {HubVisit, HubVisitWithRelations} from './hub-visit.model';
import {Medication, MedicationWithRelations} from './medication.model';
import {Entity, model, property, belongsTo} from '@loopback/repository';
import {GoalAction, GoalActionWithRelations} from './goal-action.model';

@model({settings: {}})
export class MedicationPassport extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @belongsTo(() => Users)
  userId: string;

  @belongsTo(() => Consult, {name: 'consult'})
  consultId?: string;

  @belongsTo(() => Coach, {name: 'coach'})
  coachId?: string;

  @belongsTo(() => HubVisit, {name: 'hubVisit'})
  hubVisitId?: string;

  @belongsTo(() => Medication, {name: 'medicine'})
  medicationId: string;

  @belongsTo(() => GoalAction, {name: 'goalAction'})
  goalActionId?: string;

  @property({
    type: 'string',
    required: false,
  })
  type: string;

  @property({
    type: 'string',
    required: true,
  })
  frequency: string;

  @property({
    type: 'boolean',
    default: false,
  })
  isMedicationPassportComplete?: boolean;

  @property({
    type: 'date',
    required: true,
  })
  startDate: string;

  @property({
    type: 'string',
    required: true,
  })
  source: string;

  @property({
    type: 'string',
    required: false,
    default: '',
  })
  dosagesUnit: string;

  @property({
    type: 'boolean',
    default: false,
  })
  isPastMedication?: boolean;

  @property({
    type: 'string',
    required: false,
    default: '',
  })
  dosage: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified?: string;

  constructor(data?: Partial<MedicationPassport>) {
    super(data);
  }
}

export interface MedicationPassportRelations {
  user?: UsersWithRelations;
  coach?: CoachWithRelations;
  hubVisit?: HubVisitWithRelations;
  medicine?: MedicationWithRelations;
  goalAction?: GoalActionWithRelations;
}

export type MedicationPassportWithRelations = MedicationPassport &
  MedicationPassportRelations;
