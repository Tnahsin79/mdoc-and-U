import { Entity, model, property, belongsTo } from '@loopback/repository';
import { Users, UsersWithRelations } from './users.model'

@model({ settings: {} })
export class Review extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
    required: true,
  })
  userId: string;

  @property({
    type: 'number',
    required: true,
  })
  rating: number;

  @property({
    type: 'string',
  })
  review?: string;

  @belongsTo(() => Users)
  reviewerId: string

  @property({
    type: 'date',
  })
  created?: string;

  @property({
    type: 'date',
  })
  modified?: string;


  constructor(data?: Partial<Review>) {
    super(data);
  }
}

export interface ReviewRelations {
  reviewer?: UsersWithRelations,
}

export type ReviewWithRelations = Review & ReviewRelations;
