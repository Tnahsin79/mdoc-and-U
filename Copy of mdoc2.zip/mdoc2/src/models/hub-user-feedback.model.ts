import {Entity, belongsTo, model, property} from '@loopback/repository';
import { UserFeedback, UserFeedbackWithRelations } from './user-feedback.model';
import { HubVisit, HubVisitRelations } from './hub-visit.model';

@model()
export class HubUserFeedback extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @belongsTo(() => UserFeedback, {name: 'userFeedback'})
  userFeedbackId: string;

  @belongsTo(() => HubVisit, {name: 'hubVisit'})
  hubVisitId?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created_at?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified_at?: string;

  constructor(data?: Partial<HubUserFeedback>) {
    super(data);
  }
}

export interface HubUserFeedbackRelations {
  userFeedback: UserFeedbackWithRelations;
  hubVisit: HubVisitRelations;
}

export type HubUserFeedbackWithRelations = HubUserFeedback & HubUserFeedbackRelations;
