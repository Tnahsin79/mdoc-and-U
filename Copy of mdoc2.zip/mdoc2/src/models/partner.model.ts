import {Entity, belongsTo, hasOne, model, property} from '@loopback/repository';
import { Admin, AdminWithRelations } from './admin.model';
import { PartnerCategoryEnum } from '../utils/enums';
import { Coach, CoachWithRelations } from './coach.model';

@model()
export class Partner extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;


  @belongsTo(() => Admin, {name: 'creator'})
  creatorId?: string;


  @property({
    type: 'string',
    required: true,
  })
  name: string;

  @hasOne(() => Coach, {name: 'coachAccount', keyTo: 'partnerId'})
  coachAccount?: Coach


  @property({
    type: 'string',
    required: true,
  })
  email: string;


  @property({
    type: 'string',
    required: false,
  })
  website?: string;

  @property({
    type: 'string',
    required: false,
  })
  address?: string;

  @property({
    type: 'string',
    required: false,
  })
  city?: string;

  @property({
    type: 'string',
    required: false,
  })
  state?: string;

  @property({
    type: 'string',
    required: false,
  })
  country?: string;


  @property({
    type: 'string',
    required: false,
  })
  phone?: string;


  @property({
    type: 'string',
    required: false,
    default: true,
  })
  active?: boolean;


  @property({
    type: 'string',
    required: false,
    jsonSchema: {
      enum: Object.values(PartnerCategoryEnum),
    },
  })
  category?: PartnerCategoryEnum;


  @property({
    type: 'date',
    default: () => new Date(),
  })
  created_at?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified_at?: string;

  constructor(data?: Partial<Partner>) {
    super(data);
  }
}

export interface PartnerRelations {
  creator?: AdminWithRelations;
  coachAccount?: CoachWithRelations;
}

export type PartnerWithRelations = Partner & PartnerRelations;
