import {
  UserMentalAssessmentRecord,
  UserMentalAssessmentRecordWithRelations,
} from './user-mental-assessment-record.model';
import {OptionWithRelations} from './option.model';
import {Users, UsersWithRelations} from './users.model';
import {MentalAssessmentGroupEnum} from '../utils/enums';
import {Question, QuestionWithRelations} from './question.model';
import {Entity, belongsTo, model, property} from '@loopback/repository';

@model()
export class UserMentalAssessment extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @belongsTo(() => Users, {name: 'user'})
  userId?: string;

  @belongsTo(() => Question, {name: 'question'})
  questionId: string;

  @property({
    type: 'number',
    required: true,
  })
  selectedOptionId: number;

  @property({
    type: 'string',
    jsonSchema: {
      enum: Object.values(MentalAssessmentGroupEnum),
    },
    required: true,
  })
  group: MentalAssessmentGroupEnum;

  @belongsTo(() => UserMentalAssessmentRecord, {
    name: 'userMentalAssessmentRecord',
  })
  userMentalAssessmentRecordId: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created_at: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified_at: string;

  constructor(data?: Partial<UserMentalAssessment>) {
    super(data);
  }
}

export interface UserMentalAssessmentRelations {
  user?: UsersWithRelations;
  option?: OptionWithRelations;
  question?: QuestionWithRelations;
  userMentalAssessmentRecord?: UserMentalAssessmentRecordWithRelations;
}

export type UserMentalAssessmentWithRelations = UserMentalAssessment &
  UserMentalAssessmentRelations;
