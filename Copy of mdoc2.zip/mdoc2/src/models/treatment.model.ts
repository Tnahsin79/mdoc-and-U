import { Entity, model, property } from '@loopback/repository';

@model()
export class Treatment extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
    required: true,
  })
  userId: string;
  @property({
    type: 'boolean',
    default: false,
  })
  isTreatmentComplete?: boolean;

  @property({
    type: 'string',
    required: true,
  })
  name: string;

  @property({
    type: 'string',
    required: true,
  })
  cancerType: string;

  @property({
    type: 'object',
  })
  diagnosisDetails?: object;

  @property({
    type: 'object',
    required: true,
  })
  cancerStage: object;

  @property({
    type: 'date',
    default: () => new Date()
  })
  created?: string;

  @property({
    type: 'date',
    default: () => new Date()
  })
  modified?: string;


  constructor(data?: Partial<Treatment>) {
    super(data);
  }
}

export interface TreatmentRelations {
  // describe navigational properties here
}

export type TreatmentWithRelations = Treatment & TreatmentRelations;
