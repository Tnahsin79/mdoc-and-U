import {Users, UsersWithRelations} from './users.model';
import {Entity, belongsTo, model, property} from '@loopback/repository';

@model()
export class LifestyleDiary extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @belongsTo(() => Users, {name: 'user'})
  userId: string;

  @property({
    type: 'string',
    required: true,
    jsonSchema: {
      enum: ['Yes', 'No'],
    },
  })
  sleepTime: string;

  @property({
    type: 'string',
    required: true,
    jsonSchema: {
      enum: ['Yes', 'No'],
    },
  })
  exercise: string;

  @property({
    type: 'string',
    required: true,
    jsonSchema: {
      enum: ['Yes', 'No'],
    },
  })
  fluShots: string;

  @property({
    type: 'string',
    required: true,
    jsonSchema: {
      enum: ['Yes', 'No'],
    },
  })
  smokeTobacco: string;

  @property({
    type: 'string',
    required: true,
    jsonSchema: {
      enum: ['Yes', 'No'],
    },
  })
  drinkAlcohol: string;

  @property({
    type: 'string',
    required: true,
    jsonSchema: {
      enum: ['Yes', 'No'],
    },
  })
  recreatDrugs: string;

  @property({
    type: 'string',
    required: true,
    jsonSchema: {
      enum: ['Yes', 'No'],
    },
  })
  toxicChemical: string;
  
  @property({
    type: 'string',
    required: true,
    jsonSchema: {
      enum: ['Yes', 'No'],
    },
  })
  everDisabled: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified?: string;

  constructor(data?: Partial<LifestyleDiary>) {
    super(data);
  }
}

export interface LifestyleDiaryRelations {
  // describe navigational properties here
  user?: UsersWithRelations;
}

export type LifestyleDiaryWithRelations = LifestyleDiary & LifestyleDiaryRelations;
