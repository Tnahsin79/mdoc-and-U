import {Users, UsersWithRelations} from './users.model';
import {Coach, CoachWithRelations} from './coach.model';
import {Consult, ConsultWithRelations} from './consult.model';
import {HubVisit, HubVisitWithRelations} from './hub-visit.model';
import {Entity, belongsTo, model, property} from '@loopback/repository';
import {GoalAction, GoalActionWithRelations} from './goal-action.model';
import {WaistCircumferenceEnum} from '../utils/health-metrics-functions';

@model()
export class WaistCircumference extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @belongsTo(() => Users, {name: 'user'})
  userId: string;

  @belongsTo(() => Consult, {name: 'consult'})
  consultId?: string;

  @belongsTo(() => Coach, {name: 'coach'})
  coachId?: string;

  @belongsTo(() => GoalAction, {name: 'goalAction'})
  goalActionId?: string;

  @property({
    type: 'number',
    required: true,
  })
  currentWaist: number;

  @belongsTo(() => HubVisit, {name: 'hubVisit'})
  hubVisitId?: string;

  @property({
    type: 'date',
    default: () => new Date(),
    required: false,
  })
  logDate?: string;

  @property({
    type: 'number',
    required: true,
  })
  waistGoal: number;

  @property({
    type: 'string',
    jsonSchema: {
      enum: ['IN', 'CM'],
    },
    required: true,
  })
  unit: WaistCircumferenceEnum;

  @property({
    type: 'number',
    required: true,
  })
  defaultValue?: number;

  @property({
    type: 'string',
    required: false,
  })
  defaultUnit?: string;

  @property({
    type: 'string',
    required: true,
    jsonSchema: {
      enum: ['web', 'mobile'],
    },
    default: 'web',
  })
  channel: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created_at?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified_at?: string;

  constructor(data?: Partial<WaistCircumference>) {
    super(data);
  }
}

export interface WaistCircumferenceRelations {
  user?: UsersWithRelations;
  coach?: CoachWithRelations;
  consult?: ConsultWithRelations;
  hubVisit?: HubVisitWithRelations;
  goalAction?: GoalActionWithRelations;
}

export type WaistCircumferenceWithRelations = WaistCircumference &
  WaistCircumferenceRelations;
