import { Entity, model, property, belongsTo } from '@loopback/repository';
import { PrivilegeGroup } from './privilege-group.model';

@model()
export class Privilege extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
    required: true,
  })
  value: string;

  @belongsTo(() => PrivilegeGroup, { name: 'privilegeGroup' })
  privilegeGroupId: string;

  @property({
    type: 'string',
    required: true,
  })
  title: string;

  constructor(data?: Partial<Privilege>) {
    super(data);
  }
}

export interface PrivilegeRelations {
  // Define any relationships if needed
}

export type PrivilegeWithRelations = Privilege & PrivilegeRelations;
