import {
  model,
  Entity,
  hasMany,
  property,
  belongsTo,
} from '@loopback/repository';
import {Programs, ProgramsWithRelations} from './programs.model';
import {PlansBenefit, PlansBenefitWithRelations} from './plans-benefits.model';

@model()
export class ProgramPlans extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @belongsTo(() => Programs, {name: 'program'})
  programId?: string;

  @property({
    type: 'string',
    required: true,
  })
  title: string;

  @property({
    type: 'string',
    required: false,
  })
  discountData?: string;

  @property({
    type: 'boolean',
    required: false,
    default: false,
  })
  isDeleted?: boolean;

  @property({
    type: 'number',
    default: 0,
    required: false,
  })
  monthlyPrice?: number;

  @property({
    type: 'number',
    required: true,
  })
  duration: number; // Valid number of days

  @property({
    type: 'number',
    default: 0,
    required: false,
  })
  quarterlyPrice?: number;

  @property({
    type: 'number',
    default: 0,
    required: false,
  })
  biAnnualPrice?: number;

  @property({
    type: 'number',
    default: 0,
    required: false,
  })
  yearlyPrice?: number;

  @property({
    type: 'number',
    default: 0,
    required: true,
  })
  basePrice: number;

  @property({
    type: 'number',
    default: 0,
    required: false,
  })
  threeMonthPrice?: number;

  @property({
    type: 'number',
    required: true,
  })
  order?: number;

  @hasMany(() => PlansBenefit, {keyTo: 'planId'})
  plansBenefit: PlansBenefit[];

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified?: string;

  constructor(data?: Partial<ProgramPlans>) {
    super(data);
  }
}

export interface ProgramPlansRelations {
  // describe navigational properties here
  program?: ProgramsWithRelations;
  plansBenefit: PlansBenefitWithRelations;
}

export type ProgramPlansWithRelations = ProgramPlans & ProgramPlansRelations;
