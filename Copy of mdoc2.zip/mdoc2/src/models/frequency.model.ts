import {Entity, model, property} from '@loopback/repository';

@model()
export class Frequency extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
    required: true,
  })
  name: string;

  @property({
    type: 'date',
  })
  created?: string;

  @property({
    type: 'date',
  })
  modified?: string;

  constructor(data?: Partial<Frequency>) {
    super(data);
  }
}

export interface FrequencyRelations {
  // describe navigational properties here
}

export type FrequencyWithRelations = Frequency & FrequencyRelations;
