import {Coach, CoachWithRelations} from './coach.model';
import {Users, UsersWithRelations} from './users.model';
import {Consult, ConsultWithRelations} from './consult.model';
import {HubVisit, HubVisitWithRelations} from './hub-visit.model';
import {Entity, belongsTo, model, property} from '@loopback/repository';
import {GoalAction, GoalActionWithRelations} from './goal-action.model';

@model()
export class BloodPressure extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @belongsTo(() => Users, {name: 'user'})
  userId: string;

  @belongsTo(() => GoalAction, {name: 'goalAction'})
  goalActionId?: string;

  @belongsTo(() => Consult, {name: 'consult'})
  consultId?: string;

  @belongsTo(() => Coach, {name: 'coach'})
  coachId?: string;

  @property({
    type: 'string',
    required: true,
  })
  systolic: string;

  @property({
    type: 'string',
    jsonSchema: {
      enum: ['web', 'mobile'],
    },
    default: 'web',
  })
  channel: string;

  @property({
    type: 'date',
    default: () => new Date(),
    required: false,
  })
  logDate?: string;

  @belongsTo(() => HubVisit, {name: 'hubVisit'})
  hubVisitId?: string;

  @property({
    type: 'string',
    required: true,
  })
  diastolic: string;

  @property({
    type: 'string',
  })
  comment?: string;

  @property({
    type: 'string',
    default: 'mmHg',
  })
  unit?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created_at?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified_at?: string;

  constructor(data?: Partial<BloodPressure>) {
    super(data);
  }
}

export interface BloodPressureRelations {
  user?: UsersWithRelations;
  coach?: CoachWithRelations;
  consult?: ConsultWithRelations;
  hubVisit?: HubVisitWithRelations;
  goalAction?: GoalActionWithRelations;
}

export type BloodPressureWithRelations = BloodPressure & BloodPressureRelations;
