import {Users, UsersWithRelations} from './users.model';
import {Coach, CoachWithRelations} from './coach.model';
import {Entity, belongsTo, model, property} from '@loopback/repository';
import {Programs, ProgramsWithRelations} from './programs.model';
import {Admin, AdminWithRelations} from './admin.model';

@model()
export class ChangeStages extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @belongsTo(() => Programs, {name: 'program'})
  programId: string;

  @belongsTo(() => Admin, {name: 'createdBy'})
  createdByUserId?: string;

  @property({
    type: 'string',
    required: false,
    default:
      'I have not considered my health in the past six months, and I currently do not have plans for my health for the next six months.',
  })
  precontemplation?: string;

  @property({
    type: 'string',
    required: false,
    default:
      'I have not thought about my health recently. However, I am considering doing something about it in the next six months. ',
  })
  contemplation?: string;

  @property({
    type: 'string',
    required: false,
    default:
      'I have not considered any health plans for myself in the past year; however, I plan on doing something over the next 30 days.',
  })
  preparation?: string;

  @property({
    type: 'string',
    required: false,
    default:
      'I have been actively caring for my health through (exercising, health checks, prostate checkups, etc.) for less than six months. ',
  })
  action?: string;

  @property({
    type: 'string',
    required: false,
    default:
      'I have had a regular health programme ( exercising, health checks, prostate check-ups, etc.) for over six months.',
  })
  maintenance?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created_at?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified_at?: string;

  constructor(data?: Partial<ChangeStages>) {
    super(data);
  }
}

export interface ChangeStagesRelations {
  createdBy?: AdminWithRelations;
  program?: ProgramsWithRelations;
}

export type ChangeStagesWithRelations = ChangeStages & ChangeStagesRelations;
