import {Users, UsersWithRelations} from './users.model';
import {Admin, AdminWithRelations} from './admin.model';
import {Programs, ProgramsWithRelations} from './programs.model';
import {belongsTo, Entity, model, property} from '@loopback/repository';
import {CreatorTypeEnum, GoalStatusEnum, GoalTypeEnum} from '../utils/enums';

@model()
export class Goal extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id: string;

  @property({
    type: 'string',
    required: true,
  })
  title: string;

  @belongsTo(() => Users, {name: 'user'})
  userId: string;

  @property({
    type: 'string',
    required: false,
  })
  description?: string;

  @property({
    type: 'string',
    required: false,
  })
  imageUrl?: string;

  @property({
    type: 'boolean',
    required: false,
  })
  isPrivate?: boolean;

  @property({
    type: 'string',
    required: true,
    jsonSchema: {
      enum: Object.values(GoalStatusEnum),
    },
  })
  status: GoalStatusEnum;

  @property({
    type: 'string',
    required: true,
    jsonSchema: {
      enum: Object.values(CreatorTypeEnum),
    },
  })
  creatorType: CreatorTypeEnum;

  @property({
    type: 'string',
    required: true,
    jsonSchema: {
      enum: Object.values(GoalTypeEnum),
    },
  })
  goalType: GoalTypeEnum;

  @belongsTo(() => Programs, {name: 'program'})
  programId?: string;

  @belongsTo(() => Admin, {name: 'admin'})
  adminId?: string;

  // @belongsTo(() => Reward, {name: 'user'})
  // rewardId?: string; // Will link to reward when we have it

  @property({
    type: 'boolean',
    default: true,
    required: false,
  })
  isReminderEnabled?: boolean;

  @property({
    type: 'date',
    required: true,
    default: () => new Date(),
  })
  startDate: Date;

  @property({
    type: 'date',
    required: true,
    default: () => new Date(),
  })
  endDate: Date;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created_at: Date;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified_at?: string;

  constructor(data?: Partial<Goal>) {
    super(data);
  }
}

export interface GoalRelations {
  user?: UsersWithRelations;
  admin?: AdminWithRelations;
  program?: ProgramsWithRelations;
}

export type GoalWithRelations = Goal & GoalRelations;
