import {
  model,
  hasOne,
  Entity,
  hasMany,
  property,
  belongsTo,
} from '@loopback/repository';
import {
  CoachPrograms,
  CoachProgramsWithRelations,
} from './coach-programs.model';
import {
  UserSubscriptions,
  UserSubscriptionsWithRelations,
} from './user-subscriptions.model';
import {Admin, AdminWithRelations} from './admin.model';
import {Benefits, BenefitsRelations} from './benefits.model';
import {ProgramPlans, ProgramPlansRelations} from './program-plans.model';
import {ChangeStages, ChangeStagesWithRelations} from './change-stages.model';

@model({
  // settings: {}
})
export class Programs extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
    required: true,
  })
  title: string;

  @property({
    type: 'string',
    required: true,
  })
  description?: string;

  @property({
    type: 'string',
    required: true,
    default: 'pending',
    jsonSchema: {
      enum: ['pending', 'approved', 'rejected'],
    },
  })
  approvalStatus: string;

  @belongsTo(() => Admin, {name: 'admin'})
  createdBy?: string;

  @belongsTo(() => Admin, {name: 'approver'})
  approvedBy?: string;

  @property({
    type: 'date',
    default: undefined,
  })
  approvalDate?: string;

  @property({
    type: 'string',
    jsonSchema: {
      enum: ["all", "male", "female"],
    },
    default: "all",
  })
  specificGender?: string;

  @property({
    type: 'string',
  })
  cancelReason?: boolean;

  @property({
    type: 'boolean',
    default: true,
  })
  status?: boolean;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified?: string;

  @property({
    type: 'array',
    itemType: 'string',
    default: [],
  })
  validSubscriptionTypes: string[];

  @property({
    type: 'array',
    itemType: 'string',
    default: [],
  })
  tags: string[];

  @hasMany(() => Benefits, {keyTo: 'programId'})
  benefits: Benefits[];

  @hasMany(() => ProgramPlans, {keyTo: 'programId'})
  plans: ProgramPlans[];

  @hasMany(() => CoachPrograms, {keyTo: 'programId'})
  coachPrograms: CoachPrograms[];

  @hasMany(() => UserSubscriptions, {keyTo: 'programId', name: 'subscriptions'})
  subscriptions: UserSubscriptionsWithRelations[];

  @hasOne(() => ChangeStages, {name: 'changeStages', keyTo: 'programId'})
  changeStages?: ChangeStages;

  constructor(data?: Partial<Programs>) {
    super(data);
  }
}

export interface ProgramsRelations {
  // describe navigational properties here
  benefits?: BenefitsRelations;
  plans?: ProgramPlansRelations;
  coachPrograms?: CoachProgramsWithRelations;
  admin?: AdminWithRelations;
  approver?: AdminWithRelations;
  subscriptions: UserSubscriptionsWithRelations;
  changeStages?: ChangeStagesWithRelations;
}

export type ProgramsWithRelations = Programs & ProgramsRelations;
