import { Entity, model, property } from '@loopback/repository';

@model()
export class Affordablity extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
    required: true,
  })
  userId: string;

  @property({
    type: 'array',
    itemType: "string",
    required: true,
  })
  diseaseId: string[];

  @property({
    type: 'array',
    itemType: "object",
    required: true,
  })
  affordablityIncome: string[];

  @property({
    type: 'number',
    required: true,
  })
  totalIncome: number;

  @property({
    type: 'string',
  })
  healthInsurance?: string;

  @property({
    type: 'string',
  })
  insuranceDocument?: string;

  @property({
    type: 'date',
    default: () => new Date()
  })
  created?: string;

  @property({
    type: 'date',
    default: () => new Date()
  })
  modified?: string;


  constructor(data?: Partial<Affordablity>) {
    super(data);
  }
}

export interface AffordablityRelations {
  // describe navigational properties here
}

export type AffordablityWithRelations = Affordablity & AffordablityRelations;
