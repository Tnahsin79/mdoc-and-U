import { Entity, model, property } from '@loopback/repository';

@model()
export class ProcedureSurgeries extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
    required: true,
  })
  userId: string;

  @property({
    type: 'string',
    required: true,
  })
  name: string;

  @property({
    type: 'string',
    required: true,
  })
  location: string;

  @property({
    type: 'date',
    required: true,
  })
  treatmentDate: string;

  @property({
    type: 'string',
    required: false,
  })
  procedureId?: string;

  @property({
    type: 'date',
    default: () => new Date()
  })
  created?: string;

  @property({
    type: 'date',
    default: () => new Date()
  })
  modified?: string;


  constructor(data?: Partial<ProcedureSurgeries>) {
    super(data);
  }
}

export interface ProcedureSurgeriesRelations {
  // describe navigational properties here
}

export type ProcedureSurgeriesWithRelations = ProcedureSurgeries & ProcedureSurgeriesRelations;
