import {
  model,
  Entity,
  hasMany,
  property,
  belongsTo,
} from '@loopback/repository';
import {Bla, BlaWithRelations} from './bla.model';
import {Users, UsersWithRelations} from './users.model';
import {Programs, ProgramsWithRelations} from './programs.model';

@model()
export class BlaRecord extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @belongsTo(() => Users, {name: 'user'})
  userId: string;

  @belongsTo(() => Programs, {name: 'program'})
  programId?: string;

  @hasMany(() => Bla, {keyTo: 'blaRecordId', name: 'blas'})
  blas: Bla[];

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created_at?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified_at?: string;

  constructor(data?: Partial<BlaRecord>) {
    super(data);
  }
}

export interface BlaRecordRelations {
  // describe navigational properties here
  blas?: BlaWithRelations[];
  user?: UsersWithRelations;
  program?: ProgramsWithRelations;
}

export type BlaRecordWithRelations = BlaRecord & BlaRecordRelations;
