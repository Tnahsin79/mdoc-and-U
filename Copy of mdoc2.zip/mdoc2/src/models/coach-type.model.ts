import {Entity, model, property, hasMany} from '@loopback/repository';
import {Coach, CoachRelations, CoachWithRelations} from './coach.model';
import {
  CoachTypeSpeciality,
  CoachTypeSpecialityWithRelations,
} from './coach-type-speciality.model';
@model()
export class CoachType extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
    required: true,
  })
  name: string;

  // @property({
  //   type: 'array',
  //   itemType: 'string',
  // })
  // specialities?: string[];

  @hasMany(() => Coach, {keyTo: 'coachTypeId'})
  coaches: Coach[];

  @hasMany(() => CoachTypeSpeciality, {keyTo: 'coachTypeId'})
  specialities: CoachTypeSpeciality[];

  constructor(data?: Partial<CoachType>) {
    super(data);
  }
}

export interface CoachTypeRelations {
  // describe navigational properties here
  coaches?: CoachWithRelations;
  specialities?: CoachTypeSpecialityWithRelations;
}

export type CoachTypeWithRelations = CoachType & CoachTypeRelations;
