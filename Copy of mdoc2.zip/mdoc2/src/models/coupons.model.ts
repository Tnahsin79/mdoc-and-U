import {Entity, model, property} from '@loopback/repository';

@model()
export class Coupons extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
    required: true,
  })
  name: string;

  @property({
    type: 'date',
  })
  startDate?: string;

  @property({
    type: 'date',
  })
  expireDate?: string;

  @property({
    type: 'date',
  })
  created?: string;

  @property({
    type: 'number',
  })
  redeemPoint?: number;


  constructor(data?: Partial<Coupons>) {
    super(data);
  }
}

export interface CouponsRelations {
  // describe navigational properties here
}

export type CouponsWithRelations = Coupons & CouponsRelations;
