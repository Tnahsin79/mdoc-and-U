import {SourceTypeEnum} from '../type-schema';
import {Admin, AdminWithRelations} from './admin.model';
import {Coach, CoachWithRelations} from './coach.model';
import {Users, UsersWithRelations} from './users.model';
import {LoginHistoryTypeEnum, UserTypeEnum} from '../utils/enums';
import {Entity, belongsTo, model, property} from '@loopback/repository';

@model()
export class LoginHistory extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @belongsTo(() => Users, {name: 'user'})
  userId?: string;

  @property({
    type: 'date',
    required: true,
    default: () => new Date(),
  })
  loginDateTime: string;

  @property({
    type: 'string',
    required: true,
    jsonSchema: {
      enum: Object.values(SourceTypeEnum),
    },
  })
  source: SourceTypeEnum;

  @property({
    type: 'string',
    required: false,
    jsonSchema: {
      enum: Object.values(LoginHistoryTypeEnum),
    },
  })
  record_type?: LoginHistoryTypeEnum;

  @property({
    type: 'string',
    required: false,
  })
  browserAgent?: string;

  @property({
    type: 'string',
    required: false,
    jsonSchema: {
      enum: Object.values(UserTypeEnum),
    },
  })
  userType?: UserTypeEnum;

  @belongsTo(() => Admin, {name: 'admin'})
  adminId?: string;

  @belongsTo(() => Coach, {name: 'coach'})
  coachId?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created_at?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified_at?: string;
}

export interface LoginHistoryRelations {
  user?: UsersWithRelations;
  admin?: AdminWithRelations;
  coach?: CoachWithRelations;
}

export type UserLoginWithRelations = LoginHistory & LoginHistoryRelations;
