import {Users, UsersWithRelations} from './users.model';
import {Coach, CoachWithRelations} from './coach.model';
import {Consult, ConsultWithRelations} from './consult.model';
import { HubVisit, HubVisitWithRelations } from './hub-visit.model';
import {Entity, belongsTo, model, property} from '@loopback/repository';
import {GoalAction, GoalActionWithRelations} from './goal-action.model';

@model()
export class Cholestrol extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @belongsTo(() => Users, {name: 'user'})
  userId: string;

  @belongsTo(() => HubVisit, {name: 'hubVisit'})
  hubVisitId?: string;

  @belongsTo(() => Consult, {name: 'consult'})
  consultId?: string;

  @belongsTo(() => GoalAction, {name: 'goalAction'})
  goalActionId?: string;

  @belongsTo(() => Coach, {name: 'coach'})
  coachId?: string;

  @property({
    type: 'string',
    jsonSchema: {
      enum: ['web', 'mobile'],
    },
    default: 'web',
  })
  channel: string;

  @property({
    type: 'string',
    required: true,
  })
  cholesterol: string;

  @property({
    type: 'string',
    required: true,
  })
  triglycerides: string;

  @property({
    type: 'string',
    required: true,
  })
  hdl: string;

  @property({
    type: 'string',
    required: true,
  })
  ldl: string;

  @property({
    type: 'string',
    required: false,
  })
  unit?: string;

  @property({
    type: 'date',
    default: () => new Date(),
    required: false,
  })
  logDate?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created_at?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified_at?: string;

  constructor(data?: Partial<Cholestrol>) {
    super(data);
  }
}

export interface CholestrolRelations {
  user?: UsersWithRelations;
  coach?: CoachWithRelations;
  consult?: ConsultWithRelations;
  hubVisit?: HubVisitWithRelations;
  goalAction?: GoalActionWithRelations;
}

export type CholestrolWithRelations = Cholestrol & CholestrolRelations;
