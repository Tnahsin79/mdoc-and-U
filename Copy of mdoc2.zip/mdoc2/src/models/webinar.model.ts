import { Entity, model, property } from '@loopback/repository';

@model()
export class Webinar extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
  })
  userId?: string;

  @property({
    type: 'string',
    required: true,
  })
  title: string;

  @property({
    type: 'string',
    required: true,
  })
  description: string;

  @property({
    type: 'string',
    required: true,
  })
  url: string;

  @property({
    type: 'string',
    required: false,
  })
  passcode: string;

  @property({
    type: 'string',
    required: false,
    default: ""
  })
  day: string;

  @property({
    type: 'string',
    required: false,
  })
  thumbnail: string;

  @property({
    type: 'string',
    enum: ['webinar', 'publication'],
    default: 'webinar',
  })
  type: string;

  @property({
    type: 'string',
    required: false,
  })
  sessionTime: string;

  @property({
    type: 'string',
  })
  videoId?: string;

  @property({
    type: 'date',
  })
  date?: string;

  @property({
    type: 'date',
    default: () => new Date()
  })
  created?: string;


  constructor(data?: Partial<Webinar>) {
    super(data);
  }
}

export interface WebinarRelations {
  // describe navigational properties here
}

export type WebinarWithRelations = Webinar & WebinarRelations;
