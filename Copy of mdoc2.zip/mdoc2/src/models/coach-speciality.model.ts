import {Coach, CoachWithRelations} from './coach.model';
import {Entity, belongsTo, model, property} from '@loopback/repository';
import {Speciality, SpecialityWithRelations} from './speciality.model';

@model()
export class CoachSpeciality extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @belongsTo(() => Coach, {name: 'coach'})
  coachId: string;

  @belongsTo(() => Speciality, {name: 'speciality'})
  specialityId: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created?: string;

  @property({
    type: 'date',
  })
  modified?: string;

  constructor(data?: Partial<CoachSpeciality>) {
    super(data);
  }
}

export interface CoachSpecialityRelations {
  coach?: CoachWithRelations;
  speciality?: SpecialityWithRelations;
}

export type CoachSpecialityWithRelations = CoachSpeciality &
  CoachSpecialityRelations;
