import {
  model,
  Entity,
  property,
  belongsTo,
} from '@loopback/repository';
import { Admin, AdminWithRelations } from './admin.model';

@model()
export class Product extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
    required: true,
  })
  name: string;

  @property({
    type: 'string',
    required: true,
  })
  description: string;

  @property({
    type: 'boolean',
    required: false,
    default: false,
  })
  covidEssential?: boolean;

  @property({
    type: 'number',
    required: true,
  })
  price: number;

  @property({
    type: 'number',
    required: false,
  })
  percentageDiscount?: number;

  @belongsTo(() => Admin, {name: 'creator'})
  creatorId: string;

  @property({
    type: 'array',
    itemType: 'string',
  })
  images?: string[];

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created_at?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified_at?: string;

  constructor(data?: Partial<Product>) {
    super(data);
  }
}

export interface ProductRelations {
  creator?: AdminWithRelations;
}

export type ProductWithRelations = Product & ProductRelations;
