import {CalenderEventStatusEnum, CreatorTypeEnum, DayOfTheWeekEnum, EventTypeEnum, RecurringFreqencyEnum} from '../type-schema';
import {Users, UsersWithRelations} from './users.model';
import {Coach, CoachWithRelations} from './coach.model';
import {Admin, AdminWithRelations} from './admin.model';
import {Entity, belongsTo, model, property} from '@loopback/repository';

@model()
export class CalenderEvent extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
    index: true,
    required: false,
  })
  title?: string;

  @property({
    type: 'string',
    required: true,
  })
  creatorId: string;

  @belongsTo(() => Coach, {name: 'coach'})
  appointmentCoachId?: string;

  @belongsTo(() => Users, {name: 'member'})
  appointmentMemberId?: string;

  @property({
    type: 'string',
    required: false,
  })
  facilityId?: string;

  @property({
    type: 'string',
    required: false,
  })
  facilityName?: string;

  @property({
    type: 'string',
    required: true,
    jsonSchema: {
      enum: Object.values(EventTypeEnum),
    },
  })
  eventType: EventTypeEnum;

  @property({
    type: 'string',
    required: false,
    jsonSchema: {
      enum: Object.values(CreatorTypeEnum),
    },
  })
  creatorType?: CreatorTypeEnum;

  @property({
    type: 'date',
    required: true,
  })
  eventStartDate: string;

  @property({
    type: 'date',
    required: false,
  })
  eventEndDate?: string;

  @property({
    type: 'string',
    required: false,
  })
  feedbackId?: string;

  @property({
    type: 'boolean',
    default: false,
  })
  isRecurring?: boolean;

  @property({
    type: 'string',
    required: false,
  })
  notes?: string;

  @property({
    type: 'string',
    required: false,
  })
  reason?: string;

  @property({
    type: 'string',
    required: true,
    default: 'created',
    jsonSchema: {
      enum: Object.values(CalenderEventStatusEnum),
    },
  })
  status: CalenderEventStatusEnum;

  @property({
    type: 'string',
    required: false,
    jsonSchema: {
      enum: Object.values(RecurringFreqencyEnum),
    },
  })
  recurringFrequency?: RecurringFreqencyEnum;

@property({
    type: 'object',
    jsonSchema: {
      properties: {
        timeOfDay: { type: 'string' },
        dayOfWeek: {
          type: 'string',
          enum: Object.values(DayOfTheWeekEnum),
        },
        dayOfMonth: { type: 'integer' },
        custom: { type: 'array', items: { type: 'string', format: 'date-time' } },
      },
      additionalProperties: false,
    },
  })
  recurringObject?: {
    timeOfDay?: string;
    dayOfWeek?: DayOfTheWeekEnum;
    dayOfMonth?: number;
    custom?: Date[];
  };

  @property({
    type: 'boolean',
    default: false,
    required: false,
  })
  isPublicEvent?: boolean;

  @property({
    type: 'string',
    required: false,
  })
  displayImage?: string;

  @property({
    type: 'string',
    required: false,
  })
  registrationLink?: string;

  @property({
    type: 'string',
    required: false,
  })
  recordedSessionLink?: string;

  @belongsTo(() => Admin, {name: 'creatorAdmin'})
  creatorAdminId: string;

  @property({
    type: 'string',
    index: {unique: true},
    required: true,
  })
  slug: string;

  @property({
    type: 'boolean',
    default: false,
    required: false,
  })
  isPublished?: boolean;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created_at?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified_at?: string;

  constructor(data?: Partial<CalenderEvent>) {
    super(data);
  }
}

export interface CalenderEventRelations {
  coach: CoachWithRelations;
  member: UsersWithRelations;
  creatorAdmin?: AdminWithRelations;
}

export type CalenderEventWithRelations = CalenderEvent & CalenderEventRelations;
