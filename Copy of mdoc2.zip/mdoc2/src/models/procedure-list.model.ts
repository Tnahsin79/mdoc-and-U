import {Entity, belongsTo, model, property} from '@loopback/repository';

@model()
export class ProcedureList extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
    required: true,
  })
  name: string;

  @property({
    type: 'string',
    required: false,
  })
  procedureId?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created_at?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified_at?: string;

  constructor(data?: Partial<ProcedureList>) {
    super(data);
  }
}

export interface ProcedureListRelations {}

export type ProcedureListWithRelations = ProcedureList & ProcedureListRelations;
