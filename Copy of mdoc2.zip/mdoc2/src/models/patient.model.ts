import { Entity, model, property, belongsTo } from '@loopback/repository';
import { Users, UsersWithRelations } from './users.model'

@model({ settings: {} })
export class Patient extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
    required: true,
  })
  userId: string;

  @belongsTo(() => Users, { name: 'patientDetail' })
  patientId: string

  @property({
    type: 'string',
    required: true,
  })
  name: string;

  @property({
    type: 'string',
    required: true,
  })
  email: string;

  @property({
    type: 'number',
    required: true,
  })
  age: number;

  @property({
    type: 'string',
    required: true,
  })
  gender: string;

  @property({
    type: 'string',
    required: true,
  })
  phone: string;

  @property({
    type: 'string',
    default: 'pending',
  })
  stage: string; // pending , accepted, declined

  @property({
    type: 'string',
    required: true,
  })
  categoryId: string;

  @property({
    type: 'string',
  })
  description?: string;

  @property({
    type: 'string',
    required: true,
  })
  availableTime: string;

  @property({
    type: 'date',
    required: true,
  })
  availableDate: string;

  @property({
    type: 'date',
  })
  created?: string;

  @property({
    type: 'date',
  })
  modified?: string;


  constructor(data?: Partial<Patient>) {
    super(data);
  }
}

export interface PatientRelations {
  patientDetail?: UsersWithRelations,
}

export type PatientWithRelations = Patient & PatientRelations;
