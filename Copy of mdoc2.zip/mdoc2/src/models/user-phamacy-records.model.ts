import { Entity, Model, model, property } from '@loopback/repository';

@model()
export class UserPhamacyRecords extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
    required: true,
  })
  name: string;

  @property({
    type: 'string',
    required: true,
  })
  address?: string;

  @property({
    type: 'string',
  })
  createdBy?: string;

  @property({
    type: 'number',
    required: true,
  })
  providerId?: number;

  @property({
    type: 'date',
    default: () => new Date()
  })
  created?: string;

  @property({
    type: 'date',
    default: () => new Date()
  })
  modified?: string;


  constructor(data?: Partial<UserPhamacyRecords>) {
    super(data);
  }
}

export interface UserPhamacyRecordsRelations {
  // describe navigational properties here
}

export type UserPhamacyRecordsWithRelations = UserPhamacyRecords & UserPhamacyRecordsRelations;
