import {Users, UsersWithRelations} from './users.model';
import {Coach, CoachWithRelations} from './coach.model';
import {HeightEnum} from '../utils/health-metrics-functions';
import {Consult, ConsultWithRelations} from './consult.model';
import {HubVisit, HubVisitWithRelations} from './hub-visit.model';
import {Entity, belongsTo, model, property} from '@loopback/repository';
import {GoalAction, GoalActionWithRelations} from './goal-action.model';

@model()
export class Height extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @belongsTo(() => Users, {name: 'user'})
  userId: string;

  @belongsTo(() => Consult, {name: 'consult'})
  consultId?: string;

  @belongsTo(() => Coach, {name: 'coach'})
  coachId?: string;

  @belongsTo(() => GoalAction, {name: 'goalAction'})
  goalActionId?: string;

  @property({
    type: 'number',
    required: true,
  })
  value: number;

  @belongsTo(() => HubVisit, {name: 'hubVisit'})
  hubVisitId?: string;

  @property({
    type: 'string',
    required: true,
    jsonSchema: {
      enum: ['web', 'mobile'],
    },
    default: 'web',
  })
  channel: string;

  @property({
    type: 'string',
    required: true,
    jsonSchema: {
      enum: ['CM', 'FT/IN', 'M'],
    },
  })
  unit: HeightEnum;

  @property({
    type: 'number',
    required: true,
  })
  defaultValue?: number;

  @property({
    type: 'string',
    required: false,
  })
  defaultUnit?: string;

  @property({
    type: 'date',
    default: () => new Date(),
    required: false,
  })
  logDate?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created_at?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified_at?: string;

  constructor(data?: Partial<Height>) {
    super(data);
  }
}

export interface HeightRelations {
  user?: UsersWithRelations;
  coach?: CoachWithRelations;
  consult?: ConsultWithRelations;
  hubVisit?: HubVisitWithRelations;
  goalAction?: GoalActionWithRelations;
}

export type HeightWithRelations = Height & HeightRelations;
