import { Entity, model, property } from '@loopback/repository';

@model()
export class Notice extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
    required: true,
  })
  title: string;

  @property({
    type: 'string',
    required: true,
  })
  description: string;

  @property({
    type: 'string',
    required: true,
  })
  body?: string;

  @property({
    type: 'boolean',
    required: true,
  })
  isImportant?: boolean;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created_at?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified_at?: string;

  constructor(data?: Partial<Notice>) {
    super(data);
  }
}

export interface NoticeRelations {
  
}

export type NoticeWithRelations = Notice & NoticeRelations;
