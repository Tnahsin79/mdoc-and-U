import {
  CreatorTypeEnum,
  HealthMetricsTypeEnum,
  GoalActionFrequencyEnum,
  GoalActionDaysOfWeekEnum,
} from '../utils/enums';
import {Goal, GoalWithRelations} from './goal.model';
import {Users, UsersWithRelations} from './users.model';
import {Coach, CoachWithRelations} from './coach.model';
import {belongsTo, Entity, model, property} from '@loopback/repository';

@model()
export class GoalAction extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id: string;

  @belongsTo(() => Goal, {name: 'goal'})
  goalId?: string;

  @belongsTo(() => Users, {name: 'user'})
  userId: string;

  @belongsTo(() => Coach, {name: 'coach'})
  coachId?: string;

  @property({
    type: 'string',
    required: true,
    jsonSchema: {
      enum: Object.values(CreatorTypeEnum),
    },
  })
  creatorType: CreatorTypeEnum;

  @property({
    type: 'string',
    required: true,
  })
  title: string;

  @property({
    type: 'string',
    required: false,
  })
  description?: string;

  @property({
    type: 'string',
    required: false,
    jsonSchema: {
      enum: Object.values(HealthMetricsTypeEnum),
    },
  })
  linkedMetrics?: HealthMetricsTypeEnum;

  @property({
    type: 'string',
    required: true,
    jsonSchema: {
      enum: Object.values(GoalActionFrequencyEnum),
    },
  })
  frequencyEnum: GoalActionFrequencyEnum;

  @property({
    type: 'number',
    required: false,
  })
  noOfTimes?: number;

  @property({
    type: 'string',
    required: false,
    jsonSchema: {
      enum: Object.values(GoalActionDaysOfWeekEnum),
    },
  })
  daysOfWeek?: GoalActionDaysOfWeekEnum;

  @property({
    type: 'array',
    itemType: 'date',
    required: false,
  })
  customDays?: Date[];

  @property({
    type: 'number',
    required: true,
  })
  progress: number;

  @property({
    type: 'boolean',
    default: true,
    required: false,
  })
  isActionPlan?: boolean;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created_at: Date;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified_at?: string;

  constructor(data?: Partial<GoalAction>) {
    super(data);
  }
}

export interface GoalActionRelations {
  goal?: GoalWithRelations;
  user?: UsersWithRelations;
  coach?: CoachWithRelations;
}

export type GoalActionWithRelations = GoalAction & GoalActionRelations;
