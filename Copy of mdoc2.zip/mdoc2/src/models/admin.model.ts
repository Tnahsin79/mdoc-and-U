import {AdminRole, AdminRoleWithRelations} from './admin-role.model';
import {model, Entity, hasMany, property} from '@loopback/repository';

@model()
export class Admin extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
    required: true,
  })
  name: string;

  @property({
    type: 'string',
    required: true,
    index: {
      unique: true,
    },
    jsonSchema: {
      format: 'email',
      errorMessage: 'Invalid email format',
    },
  })
  email: string;

  @property({
    type: 'string',
  })
  phoneNumber: string;

  @property({
    type: 'string',
  })
  image: string;

  @property({
    type: 'string',
  })
  password: string;

  @property({
    type: 'date',
    default: new Date(),
  })
  created?: Date;

  @property({
    type: 'date',
    default: new Date(),
  })
  modified?: Date;

  @property({
    type: 'number',
  })
  forgotToken?: string;

  @property({
    type: 'array',
    itemType: 'object',
  })
  permissions: {permission: string; status: boolean}[];

  @property({
    type: 'string',
  })
  status: string;

  @property({
    type: 'string',
    required: false,
  })
  refreshToken?: string;

  @property({type: 'string', required: false})
  fcmToken?: string;

  @property({type: 'boolean', required: false, default: true})
  isPushNotification?: boolean;

  @hasMany(() => AdminRole, {keyFrom: 'adminId', name: 'roles'})
  roles: AdminRole[];

  constructor(data?: Partial<Admin>) {
    super(data);
    if (this.email) this.email = this.email.toLowerCase();
  }
}

export interface AdminRelations {
  // describe navigational properties here
  roles?: AdminRoleWithRelations[];
}

export type AdminWithRelations = Admin & AdminRelations;
