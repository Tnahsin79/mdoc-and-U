import { DiagnosisTypeEnum, ReasonForVisitTypeEnum, SoughtHealthInfoOnTypeEnum, VisitOutcomeTypeEnum } from '../utils/enums';
import { ActionPlan, ActionPlanWithRelations } from './action-plan.model';
import {Coach, CoachWithRelations} from './coach.model';
import { DependentList, DependentListWithRelations } from './dependent-list.model';
import { HubUserFeedback, HubUserFeedbackWithRelations } from './hub-user-feedback.model';
import { NudgeHubs, NudgeHubsWithRelations } from './nudge-hubs.model';
import {Users, UsersWithRelations} from './users.model';
import {Entity, belongsTo, hasMany, model, property} from '@loopback/repository';

@model()
export class HubVisit extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @belongsTo(() => Users, {name: 'user'})
  userId: string;

  @belongsTo(() => NudgeHubs, {name: 'nudgeHub'})
  nudgeHubId: string;

  @belongsTo(() => ActionPlan, {name: 'actionPlan'})
  actionPlanId: string;

  @hasMany(() => HubUserFeedback, {keyTo: 'hubVisitId'})
  hubUserFeedbacks: HubUserFeedback[];

  @hasMany(() => DependentList, {keyFrom: 'userId', keyTo: 'userId'})
  dependentList: DependentList[];

  @belongsTo(() => Coach, {name: 'coach'})
  createdById?: string;

  @property({
    type: 'string',
    required: false,
  })
  userFullName?: string;

  @property({
    type: 'date',
    required: true,
  })
  checkInTime: string;

  @property({
    type: 'date',
    required: true,
  })
  checkOutTime: string;

  @property({
    type: 'boolean',
    default: false,
  })
  hasCheckedOut: boolean;

  @property({
    type: 'boolean',
    required: true,
  })
  hasDependent: boolean;

  @property({
    type: 'boolean',
    required: true,
  })
  needConsult: boolean;

  @property({
    type: 'boolean',
    required: true,
  })
  hasFollowUp: boolean;

  @property({
    type: 'date',
    required: false,
  })
  followUpDate?: string;

  @property({
    type: "string",
    required: false,
    jsonSchema: {
      enum: Object.values(ReasonForVisitTypeEnum),
    },
  })
  reasonForVisit?: string;

  @property({
    type: 'string',
    required: false,
  })
  reasonForVisitOther?: string;

  @property({
    type: "string",
    required: false,
    jsonSchema: {
      enum: Object.values(SoughtHealthInfoOnTypeEnum),
    },
  })
  soughtHealthInfoOn?: SoughtHealthInfoOnTypeEnum[];

  @property({
    type: 'string',
    required: false,
  })
  soughtHealthInfoOtherTopics?: string;

  @property({
    type: 'string',
    required: false,
  })
  soughtHealthInfoOtherIllnesses?: string;

  @property({
    type: "string",
    required: true,
    jsonSchema: {
      enum: Object.values(VisitOutcomeTypeEnum),
    },
  })
  visitOutcome: VisitOutcomeTypeEnum[];

  @property({
    type: "string",
    required: false,
    jsonSchema: {
      enum: Object.values(DiagnosisTypeEnum),
    },
  })
  diagnosis?: DiagnosisTypeEnum[];

  @property({
    type: 'string',
    required: false,
  })
  diagnosisOther?: string;

  @property({
    type: 'string',
    jsonSchema: {
      enum: ['web', 'mobile'],
    },
    default: 'web',
  })
  channel: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created_at?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified_at?: string;

  constructor(data?: Partial<HubVisit>) {
    super(data);
  }
}

export interface HubVisitRelations {
  user?: UsersWithRelations;
  hubUserFeedbacks?: HubUserFeedbackWithRelations;
  dependentList?: DependentListWithRelations;
  actionPlan?: ActionPlanWithRelations;
  nudgeHub?: NudgeHubsWithRelations;
  coach?: CoachWithRelations
}

export type HubVisitWithRelations = HubVisit & HubVisitRelations;
