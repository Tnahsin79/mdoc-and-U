import {Users, UsersWithRelations} from './users.model';
import {Coach, CoachWithRelations} from './coach.model';
import { Entity, model, property, belongsTo } from '@loopback/repository';

@model()
export class Pharmacy extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
    required: true,
  })
  name: string;

  @property({
    type: 'string',
    required: false,
  })
  city?: string;

  @property({
    type: 'string',
    required: true,
  })
  address: string;

  @belongsTo(() => Users, {name: 'user'})
  userId: string;

  @belongsTo(() => Coach, {name: 'coach'})
  coachId?: string;

  @property({
    type: 'boolean',
    default: false,
  })
  isPharmacyComplete?: boolean;

  @property({
    type: 'string',
    default: () => new Date()
  })
  created?: string;

  @property({
    type: 'date',
    default: () => new Date()
  })
  modified?: string;


  constructor(data?: Partial<Pharmacy>) {
    super(data);
  }
}

export interface PharmacyRelations {
  // describe navigational properties here
  user?: UsersWithRelations;
  coach?: CoachWithRelations;
}

export type PharmacyWithRelations = Pharmacy & PharmacyRelations;
