import {Entity, model, property} from '@loopback/repository';

@model()
export class AppRelease extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
    required: true,
  })
  title: string;

  @property({
    type: 'string',
    required: true,
  })
  description: string;

  @property({
    type: 'string',
    required: true,
  })
  version: string;

  @property({
    type: 'date',
    required: true,
  })
  date: Date;

  @property({
    type: 'boolean',
    default: false,
  })
  isForceUpdate?: boolean;

  @property({
    type: 'date',
    default: () => new Date()
  })
  created_at?: Date;

  @property({
    type: 'date',
    default: () => new Date()
  })
  modified_at?: Date;

  constructor(data?: Partial<AppRelease>) {
    super(data);
  }
}

export interface AppReleaseRelations {
  // describe navigational properties here
}

export type AppReleaseWithRelations = AppRelease & AppReleaseRelations;
