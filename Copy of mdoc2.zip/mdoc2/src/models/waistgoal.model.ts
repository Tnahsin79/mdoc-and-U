import { Entity, model, property } from '@loopback/repository';

@model()
export class Waistgoal extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'number',
    required: false,
  })
  waistGoal: number;

  @property({
    type: 'string',
  })
  unit?: string;

  @property({
    type: 'string',
    required: true,
  })
  userId?: string;


  @property({
    type: 'date',
    default: () => new Date()
  })
  created?: string;


  constructor(data?: Partial<Waistgoal>) {
    super(data);
  }
}

export interface WaistgoalRelations {
  // describe navigational properties here
}

export type WaistgoalWithRelations = Waistgoal & WaistgoalRelations;
