import {PaymentTypeEnum} from '../utils/enums';
import {Users, UsersRelations} from './users.model';
import {Voucher, VoucherWithRelations} from './voucher.model';
import {Programs, ProgramsWithRelations} from './programs.model';
import {Entity, model, property, belongsTo} from '@loopback/repository';
import {ProgramPlans, ProgramPlansWithRelations} from './program-plans.model';
import {Coach, CoachWithRelations} from './coach.model';
import {HubVisit, HubVisitWithRelations} from './hub-visit.model';
@model()
export class Payments extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @belongsTo(() => Users, {})
  userId: string;

  @belongsTo(() => Voucher, {name: 'voucher'})
  voucherId?: string;

  @property({
    type: 'string',
  })
  email?: string;

  @property({
    type: 'string',
    required: false,
  })
  hubId?: string;

  @belongsTo(() => HubVisit, {name: 'hubVisit'})
  hubVisitId?: string;

  @belongsTo(() => Coach, {name: 'coach'})
  coachId?: string;

  @property({
    type: 'boolean',
    required: false,
  })
  isHubPayment?: boolean;

  @belongsTo(() => ProgramPlans, {name: 'plan'})
  planId?: string;

  @belongsTo(() => Programs, {name: 'program'})
  programId?: string; // remove later

  @property({
    type: 'string',
  })
  description?: string;

  // This is used for offline payments. It is defaulted to true for online transactions
  @property({
    type: 'boolean',
    default: true,
  })
  resolvedByFinance?: boolean;

  @property({
    type: 'string',
    jsonSchema: {
      enum: ['success', 'failed', 'pending', 'abandoned'],
    },
    default: 'pending',
  })
  status?: string;

  @property({
    type: 'string',
    required: false,
    jsonSchema: {
      enum: Object.values(PaymentTypeEnum),
    },
  })
  payer: PaymentTypeEnum;

  @property({
    type: 'string',
    required: false,
  })
  paymentType: string;

  @property({
    type: 'object',
  })
  billingInfo?: object;

  @property({
    type: 'number',
    default: 0,
  })
  amount: number;

  @property({
    type: 'string',
    required: false,
  })
  transactionId?: string;

  @property({
    type: 'string',
    required: true,
  })
  reference: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created?: string;

  constructor(data?: Partial<Payments>) {
    super(data);
  }
}

export interface PaymentsRelations {
  // describe navigational properties here
  user?: UsersRelations;
  coach?: CoachWithRelations;
  voucher?: VoucherWithRelations;
  program?: ProgramsWithRelations;
  hubVisit?: HubVisitWithRelations;
  plan?: ProgramPlansWithRelations;
}

export type PaymentsWithRelations = Payments & PaymentsRelations;
