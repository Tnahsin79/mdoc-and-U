import {belongsTo, Entity, model, property} from '@loopback/repository';
import { Admin, AdminWithRelations } from './admin.model';

@model()
export class NudgeHubs extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
    required: true,
  })
  title: string;

  @property({
    type: 'array',
    itemType: 'string',
    default: [],
  })
  feedbackIds?: string[];

  @property({
    type: 'object',
  })
  location?: object;

  @property({
    type: 'string',
  })
  address?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created_at?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified_at?: string;

  @belongsTo(() => Admin, {name: 'createdBy'})
  createdByAdminId?: string;

  @belongsTo(() => Admin, {name: 'updatedBy'})
  updatedByAdminId?: string;

  constructor(data?: Partial<NudgeHubs>) {
    super(data);
  }
}

export interface NudgeHubsRelations {
  createdBy?: AdminWithRelations;
  updatedBy?: AdminWithRelations;
}

export type NudgeHubsWithRelations = NudgeHubs & NudgeHubsRelations;
