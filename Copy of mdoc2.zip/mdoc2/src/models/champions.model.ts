import { Entity, model, property, belongsTo } from '@loopback/repository';
import { Users, UsersWithRelations } from './users.model'

@model({ settings: {} })
export class Champions extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @belongsTo(() => Users)
  championId: string

  @belongsTo(() => Users)
  starId: string

  @property({
    type: 'number',
    default: 0  // 0 for pending 1 for accepted
  })
  status: number;

  @property({
    type: 'array',
    itemType: "string"
  })
  profileAutherity?: string;

  @property({
    type: 'date',
    default: () => new Date()
  })
  created?: string;

  @property({
    type: 'date',
    default: () => new Date()
  })
  modified?: string;

  constructor(data?: Partial<Champions>) {
    super(data);
  }
}

export interface ChampionsRelations {
  champion?: UsersWithRelations,
  star?: UsersWithRelations,
}

export type ChampionsWithRelations = Champions & ChampionsRelations;
