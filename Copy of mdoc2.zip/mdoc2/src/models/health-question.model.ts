import { Entity, model, property } from '@loopback/repository';

@model()
export class HealthQuestion extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
    required: true,
  })
  userId: string;

  @property({
    type: 'string',
    required: true,
  })
  question: string;

  @property({
    type: 'string',
    required: true
  })
  type?: string; // basicHealth or pregnancy

  @property({
    type: 'string',
    required: false
  })
  inputType?: string;

  @property({
    type: 'array',
    itemType: 'string',
  })
  options?: string[];

  @property({
    type: 'string',
    required: true
  })
  specific?: string; // male, female, all

  @property({
    type: 'date',
    default: () => new Date()
  })
  created?: string;

  @property({
    type: 'date',
    default: () => new Date()
  })
  modified?: string;


  constructor(data?: Partial<HealthQuestion>) {
    super(data);
  }
}

export interface HealthQuestionRelations {
  // describe navigational properties here
}

export type HealthQuestionWithRelations = HealthQuestion & HealthQuestionRelations;
