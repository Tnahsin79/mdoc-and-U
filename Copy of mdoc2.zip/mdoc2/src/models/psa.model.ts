import {Coach, CoachWithRelations} from './coach.model';
import {Users, UsersWithRelations} from './users.model';
import {Entity, belongsTo, model, property} from '@loopback/repository';

@model()
export class Psa extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @belongsTo(() => Users, {name: 'user'})
  userId: string;

  @belongsTo(() => Coach, {name: 'coach'})
  coachId?: string;

  
  @property({
    type: 'date',
    default: () => new Date(),
    required: false
  })
  logDate?: string;
  
  @property({
    type: 'string',
    required: true,
  })
  totalPsa: string;

  @property({
    type: 'string',
    required: true,
  })
  freePsa: string;

  @property({
    type: 'string',
  })
  fileName?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created_at?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified_at?: string;

  constructor(data?: Partial<Psa>) {
    super(data);
  }
}

export interface PsaRelations {
  user?: UsersWithRelations;
  coach?: CoachWithRelations;
}

export type PsaWithRelations = Psa & PsaRelations;
