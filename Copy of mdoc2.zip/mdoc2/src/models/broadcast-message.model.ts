import {Entity, model, property} from '@loopback/repository';

@model()
export class BroadcastMessage extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
    required: true,
  })
  broadcastId: string;

  @property({
    type: 'string',
    required: true,
  })
  message: string;

  @property({
    type: 'date',
  })
  createdAt?: string;

  @property({
    type: 'date',
  })
  modifiedAt?: string;


  constructor(data?: Partial<BroadcastMessage>) {
    super(data);
  }
}

export interface BroadcastMessageRelations {
  // describe navigational properties here
}

export type BroadcastMessageWithRelations = BroadcastMessage & BroadcastMessageRelations;
