import {Entity, model, property} from '@loopback/repository';

@model()
export class Pregnancy extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
    required: true,
  })
  userId: string;

  @property({
    type: 'boolean',
    default: false,
  })
  isPregnancyComplete?: boolean;

  @property({
    type: 'string',
    required: true,
  })
  type: string; // past , current

  @property({
    type: 'date',
  })
  dueDate?: string;

  @property({
    type: 'date',
  })
  currentDate?: string;

  @property({
    type: 'array',
    itemType: 'string',
  })
  questionId?: string[];

  @property({
    type: 'array',
    itemType: 'string',
  })
  answer: string[];

  @property({
    type: 'number',
    required: false,
  })
  calculationIndex: number;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified?: string;

  constructor(data?: Partial<Pregnancy>) {
    super(data);
  }
}

export interface PregnancyRelations {}

export type PregnancyWithRelations = Pregnancy & PregnancyRelations;
