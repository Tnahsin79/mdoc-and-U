import {GoalStatusEnum} from '../utils/enums';
import {Goal, GoalWithRelations} from './goal.model';
import {Users, UsersWithRelations} from './users.model';
import {Entity, belongsTo, model, property} from '@loopback/repository';

@model()
export class GroupGoalParticipant extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id: string;

  @belongsTo(() => Goal, {name: 'goal'})
  goalId: string;

  @belongsTo(() => Users, {name: 'user'})
  userId: string;

  @property({
    type: 'string',
    required: true,
    jsonSchema: {
      enum: Object.values(GoalStatusEnum),
    },
  })
  status: GoalStatusEnum;

  @property({
    type: 'number',
    required: true,
  })
  progress: number;

  @property({
    type: 'booelan',
    required: false,
  })
  isWinner?: boolean;

  @property({
    type: 'number',
    required: true,
  })
  previousProgress: number;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created_at: Date;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified_at?: string;

  constructor(data?: Partial<GroupGoalParticipant>) {
    super(data);
  }
}

export interface GroupGoalParticipantRelations {
  goal?: GoalWithRelations;
  user?: UsersWithRelations;
}

export type GroupGoalParticipantWithRelations = GroupGoalParticipant &
  GroupGoalParticipantRelations;
