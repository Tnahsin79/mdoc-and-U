import {Disease} from './disease.model';
import {
  SymptomHealthCondition,
  SymptomHealthConditionWithRelations,
} from './symptom-health-condition.model';
import {Entity, model, property, belongsTo} from '@loopback/repository';
import {SymptomTypes, SymptomTypesWithRelations} from './symptom-types.model';
import { Admin, AdminWithRelations } from './admin.model';

@model({settings: {}})
export class Symptoms extends Entity {

  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
  })
  name?: string;

  @property({
    type: 'string',
  })
  description?: string;

  @property({
    type: 'string',
    required: false,
    default: 'pending',
    jsonSchema: {
      enum: ['pending', 'approved', 'rejected'],
    },
  })
  approvalStatus?: string;

  @belongsTo(() => Admin, {name: 'admin'})
  createdBy?: string;

  @belongsTo(() => Admin, {name: 'approver'})
  approvedBy?: string;

  @property({
    type: 'date',
    default: undefined,
  })
  approvalDate?: string;

  @property({
    type: 'string',
  })
  cancelReason?: boolean;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created?: string;

  constructor(data?: Partial<Symptoms>) {
    super(data);
  }
}

export interface SymptomsRelations {
  admin?: AdminWithRelations;
  approver?: AdminWithRelations;
}

export type SymptomsWithRelations = Symptoms & SymptomsRelations;
