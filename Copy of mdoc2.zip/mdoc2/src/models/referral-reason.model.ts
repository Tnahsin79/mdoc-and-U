import {Entity, model, property} from '@loopback/repository';

@model()
export class ReferralReason extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
    required: true,
  })
  title: string;

  @property({
    type: 'array',
    itemType: 'object',
  })
  reasons: {id: string; description: string}[];

  constructor(data?: Partial<ReferralReason>) {
    super(data);
  }
}

export interface ReferralReasonRelations {
  // describe navigational properties here
}

export type ReferralReasonWithRelations = ReferralReason &
  ReferralReasonRelations;
