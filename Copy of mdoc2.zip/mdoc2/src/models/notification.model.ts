import {Users, UsersWithRelations} from './users.model';
import {Admin, AdminWithRelations} from './admin.model';
import {Coach, CoachWithRelations} from './coach.model';
import {Entity, model, property, belongsTo} from '@loopback/repository';
import {NotificationPriorityEnum, NotificationTypeEnum} from '../type-schema';

@model({settings: {}})
export class Notification extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
    required: true,
  })
  title: string;

  @property({
    type: 'boolean',
    default: false,
  })
  isSeen?: boolean;

  @property({
    type: 'string',
    required: false,
    default: '',
  })
  body?: string;

  @property({
    type: 'string',
    jsonSchema: {
      enum: Object.values(NotificationTypeEnum),
    },
    required: true,
  })
  notificationType: NotificationTypeEnum;

  @property({
    type: 'string',
    jsonSchema: {
      enum: Object.values(NotificationPriorityEnum),
    },
    required: true,
    default: NotificationPriorityEnum.MEDIUM,
  })
  priority: NotificationPriorityEnum;

  @property({
    type: 'string',
    required: false,
  })
  resourceId?: string;

  @property({
    type: 'string',
    required: false,
  })
  image?: string;

  @belongsTo(() => Users, {name: 'user'})
  userId?: string;

  @belongsTo(() => Coach, {name: 'coach'})
  coachId?: string;

  @belongsTo(() => Admin, {name: 'admin'})
  adminId?: string;

  @property({
    type: 'object',
    required: false,
  })
  notificationObject?: object;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified?: string;

  constructor(data?: Partial<Notification>) {
    super(data);
  }
}

export interface NotificationRelations {
  user?: UsersWithRelations;
  coach?: CoachWithRelations;
  admin?: AdminWithRelations;
}

export type NotificationWithRelations = Notification & NotificationRelations;
//add coachId and adminId and stablish relationship
