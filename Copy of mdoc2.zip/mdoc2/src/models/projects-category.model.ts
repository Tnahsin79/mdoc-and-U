import { Entity, model, property } from '@loopback/repository';

@model()
export class ProjectsCategory extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
    required: true,
  })
  name: string;

  @property({
    type: 'date',
  })
  created?: string;

  @property({
    type: 'date',
  })
  modified?: string;


  constructor(data?: Partial<ProjectsCategory>) {
    super(data);
  }
}

export interface ProjectsCategoryRelations {
  // describe navigational properties here
}

export type ProjectsCategoryWithRelations = ProjectsCategory & ProjectsCategoryRelations;
