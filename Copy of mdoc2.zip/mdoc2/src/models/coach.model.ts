import {
  model,
  Entity,
  hasMany,
  property,
  AnyObject,
  belongsTo,
} from '@loopback/repository';
import {
  CoachPrograms,
  CoachProgramsWithRelations,
} from './coach-programs.model';
import {
  CoachSpeciality,
  CoachSpecialityWithRelations,
} from './coach-speciality.model';
import {Partner} from './partner.model';
import {Users, UsersWithRelations} from './users.model';
import {CoachType, CoachTypeWithRelations} from './coach-type.model';
import {CoachUserSubscriptions} from './coach-user-subscriptions.model';

@model()
export class Coach extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
    default: '',
  })
  name?: string;

  @property({
    type: 'object',
    default: '',
  })
  address?: string;

  @property({
    type: 'array',
    itemType: 'string',
  })
  specialities?: string[];

  @hasMany(() => CoachSpeciality, {keyTo: 'coachId', name: 'coachSpecialities'})
  coachSpecialities?: string[];

  @property({
    type: 'string',
  })
  image?: string;

  @property({
    type: 'boolean',
    default: false,
  })
  isPartnerCoachAccount?: boolean;

  @belongsTo(() => Partner, {name: 'partner'})
  partnerId?: string;

  @property({
    type: 'string',
    default: '',
    index: true,
  })
  phone?: string;

  @property({
    type: 'string',
    required: true,
    index: {
      unique: true,
    },
    jsonSchema: {
      format: 'email',
      errorMessage: 'Invalid email format',
    },
  })
  email?: string;

  @property({
    type: 'string',
    required: false,
    default: '',
  })
  firstName?: string;

  @property({
    type: 'string',
    required: false,
    default: '',
  })
  lastName?: string;

  @property({
    type: 'string',
    required: false,
    default: '',
  })
  gender?: string;

  @property({
    type: 'object',
    required: false,
    itemType: 'object',
  })
  locationInfo?: AnyObject;

  @property({
    type: 'string',
    required: false,
  })
  password?: string;

  @property({
    type: 'string',
    required: false,
  })
  md5password?: string;

  @property({
    type: 'string',
    required: false,
  })
  directReferral?: string;

  @property({
    type: 'array',
    itemType: 'string',
  })
  assignUserId?: string[];

  @property({
    type: 'string',
    required: false,
  })
  description?: string;

  @property({
    type: 'string',
    required: false,
  })
  referralCode?: string;

  @property({
    type: 'array',
    itemType: 'string',
  })
  qualifications?: string[];

  @property({
    type: 'array',
    itemType: 'string',
  })
  interests?: string[];

  @property({
    type: 'string',
  })
  otp?: string;

  @property({
    type: 'string',
  })
  resetToken?: string;

  @property({
    type: 'number',
  })
  availibility?: number;

  @property({
    type: 'number',
    index: true,
  })
  coachId?: number;

  @property({
    type: 'date',
    default: undefined,
  })
  dob?: string;

  @property({
    type: 'boolean',
    default: false,
  })
  isPushNotification?: boolean;

  @property({
    type: 'boolean',
    default: false,
  })
  isOnline?: boolean;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  lastSeen?: string;

  @property({
    type: 'string',
    index: {
      unique: true,
    },
  })
  socketId?: string;

  @property({
    type: 'string',
    default: '',
  })
  fcmToken?: string;

  @property({
    type: 'boolean',
    default: false,
  })
  islocation?: boolean;

  @property({
    type: 'boolean',
    default: true,
  })
  isActive?: boolean;

  @belongsTo(() => CoachType, {name: 'coachType'})
  coachTypeId?: string;

  @hasMany(() => Users, {keyTo: 'assignCoachId'})
  users: Users[];

  @property({
    type: 'string',
    required: false,
  })
  language?: string;

  @hasMany(() => CoachPrograms, {keyTo: 'coachId'})
  coachPrograms?: CoachPrograms[];

  @property({
    type: 'string',
    required: false,
  })
  refreshToken?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created?: string;

  @property({
    type: 'string',
    required: false,
    default: 'Others',
  })
  type?: string;

  @hasMany(() => CoachUserSubscriptions, {name: 'assignedMembers'})
  assignedMembers?: CoachUserSubscriptions[];

  constructor(data?: Partial<Coach>) {
    super(data);
    if (this.email) this.email = this.email.toLowerCase();
  }
}

export interface CoachRelations {
  // describe navigational properties here
  users?: UsersWithRelations;
  coachType?: CoachTypeWithRelations;
  coachSpecialities?: CoachSpecialityWithRelations;
  coachPrograms?: CoachProgramsWithRelations;
  assignedMembers?: CoachUserSubscriptions[];
}

export type CoachWithRelations = Coach & CoachRelations;
