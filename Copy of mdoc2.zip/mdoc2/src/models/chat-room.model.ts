import {Entity, belongsTo, hasMany, model, property} from '@loopback/repository';
import {ChatRoomUser} from './chat-room-user.model';
import { Coach, CoachWithRelations } from './coach.model';
import { Chat, ChatWithRelations } from './chat.model';
import { Users, UsersWithRelations } from './users.model';

@model()
export class ChatRoom extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
    required: true,
  })
  creatorId?: string;


  @belongsTo(() => Coach, {name: 'receiverCoach'})
  receiverCoachId: string


  @belongsTo(() => Users, {name: 'receiverMember'})
  receiverMemberId?: string
  

  @property({
    type: 'string',
    default: '',
    required: false,
  })
  groupName?: string;
  

  @property({
    type: 'string',
    default: '',
    required: false,
  })
  userFullName?: string;


  @property({
    type: 'string',
    required: false,
    jsonSchema: {
      enum: ["group", "direct"]
    },
    default: 'direct'
  })
  type?: "group" | "direct";

  @hasMany(() => Chat, {keyTo: 'chatRoomId', name: 'chats'})
  chats: Chat[]

  @property({
    type: 'string',
    required: true,
    jsonSchema: {
      enum: ["coach", "member", "system"]
    }
  })
  creatorType: "coach" | "member" | "system";


  @property({
    type: 'string',
    required: false,
  })
  imageUrl?: string;

  @property({
    type: 'array',
    required: false,
    itemType: 'string',
  })
  receiverIds: string[];


  @property({
    type: 'date',
    default: () => new Date(),
  })
  created?: string;

  @property({
    type: 'date',
  })
  modified?: string;

  @property({
    type: 'date',
    required: false,
  })
  lastMessageTime?: string;

  constructor(data?: Partial<ChatRoom>) {
    super(data);
  }
}

export interface ChatRoomRelations {
  // describe navigational properties here
  receiverCoach?: CoachWithRelations
  receiverMember?: UsersWithRelations
  chats?: ChatWithRelations[]
}

export type ChatRoomWithRelations = ChatRoom & ChatRoomRelations;
