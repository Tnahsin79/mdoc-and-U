import {Users, UsersWithRelations} from './users.model';
import {Coach, CoachWithRelations} from './coach.model';
import {Admin, AdminWithRelations} from './admin.model';
import {HealthMetricsTypeEnum, OutlierStatusEnum} from '../utils/enums';
import {Entity, belongsTo, model, property} from '@loopback/repository';

@model()
export class Outlier extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @belongsTo(() => Users, {name: 'user'})
  userId: string;

  @property({
    type: 'string',
    required: true,
  })
  userFullName: string;

  @property({
    type: 'string',
    required: true,
    jsonSchema: {
      enum: Object.values(HealthMetricsTypeEnum),
    },
  })
  metricType: HealthMetricsTypeEnum;

  @property({
    type: 'string',
    required: true,
  })
  metricId: string;

  @property({
    type: 'string',
    required: true,
  })
  metricValue: string;

  @property({
    type: 'string',
    required: true,
    jsonSchema: {
      enum: Object.values(OutlierStatusEnum),
    },
    default: OutlierStatusEnum.PENDING,
  })
  status?: OutlierStatusEnum;

  @belongsTo(() => Coach, {name: 'coach'})
  reviewerId?: string;

  @belongsTo(() => Admin, {name: 'admin'}) // If reviewed by admin
  reviewerAdminId?: string;

  @property({
    type: 'date',
  })
  reviewStartDate?: Date;

  @property({
    type: 'date',
  })
  resolutionDate?: Date;

  @property({
    type: 'string',
  })
  finalNotes?: string;

  @property({
    type: 'array',
    itemType: 'string',
  })
  programIds?: string[];

  @property({
    type: 'array',
    itemType: 'string',
  })
  userSubscriptionIds?: string[];

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created_at?: Date;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  updated_at?: Date;
}

export interface OutlierRelations {
  user?: UsersWithRelations;
  coach?: CoachWithRelations;
  admin?: AdminWithRelations;
}

export type OutlierWithRelations = Outlier & OutlierRelations;
