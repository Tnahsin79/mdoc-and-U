import {Entity, model, property, belongsTo} from '@loopback/repository';
import {Plans, PlansRelations} from './plans.model';
import {Benefits, BenefitsRelations, BenefitsWithRelations} from './benefits.model';
import { ProgramPlans, ProgramPlansWithRelations } from './program-plans.model';

@model()
export class PlansBenefit extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id: string;

  @belongsTo(() => ProgramPlans, {})
  planId?: string;

  @belongsTo(() => Benefits, { name: 'benefit' })
  benefitId?: string;

  @property({
    type: 'string',
    enum: ['text', 'checkmark'],
    default: 'checkmark',
  })
  type?: string;

  @property({
    type: 'string',
    required: false,
    default: ''
  })
  value?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  created?: string;

  @property({
    type: 'date',
    default: () => new Date(),
  })
  modified?: string;

  constructor(data?: Partial<PlansBenefit>) {
    super(data);
  }
}

export interface PlansBenefitRelations {
  // describe navigational properties here
  benefit?: BenefitsWithRelations;
  plans?: ProgramPlansWithRelations;
}

export type PlansBenefitWithRelations = PlansBenefit & PlansBenefitRelations;
