import { MdocadminapiApplication } from './application';
import { ApplicationConfig } from '@loopback/core';
import { CronController } from './controllers/cron.controller';
import { CronJob } from './cronjob/CronJob';
export { MdocadminapiApplication };

export async function main(options: ApplicationConfig = {}) {
  const app = new MdocadminapiApplication(options);
  await app.boot();
  await app.start();
  const url = app.restServer.url || app.httpServer.url;
  console.log(`Server is running at ${url}`);
  console.log(`Try ${url}/ping`);

  // Instanciate CronController
  const cronController = app.controller(CronController);
  const cronControllerInstance = await cronController.getValue(app);
  const cron = new CronJob(cronControllerInstance);

  // Invoke method
  cron.start();
  return app;
}
