import { Storage } from '@google-cloud/storage';
import path from 'path';
import fs from 'fs';

const serviceKeyPath = path.join(__dirname, './completehealth-283912-1500e2757215.json');

let storage;

if (fs.existsSync(serviceKeyPath)) {
  // Use the key file for local development
  storage = new Storage({
    keyFilename: serviceKeyPath,
    projectId: 'completehealth-283912',
  });
  console.log('Using service key for authentication.');
} else {
  // Use the default credentials for Cloud Run runtime
  storage = new Storage({
    projectId: 'completehealth-283912',
  });
  console.log('Using default application credentials for authentication.');
}

export { storage };
