export type Credentials = {
  email: string;
  password: string;
  source: SourceTypeEnum;
  browserAgent?: string;
};

export enum SourceTypeEnum {
  MobileApp = 'mobile_app',
  Web = 'web',
}

export enum EventTypeEnum {
  PersonalReminder = 'personal_reminder',
  CoachAppointment = 'coach_appointment',
  FacilityAppointment = 'facility_appointment',
  GeneralEvent = 'general_event',
  AntenatalAppointment = 'antenatal_appointment',
  Webinar = 'webinar',
}

export type EmailCredentials = {
  email: string;
};
export type ResetCredentials = {
  token: string;
  password: string;
};

export type IMember = {
  id: string;
  fName: string;
  lName: string;
  image: string;
  email: string;
  created: string;
  modified: string;
  status: number;
  password: string;
};

export type IEmail = {
  to: string;
  from: string;
  subject: string;
  html: string;
};

export type PaginatedResponse<T> = {
  data: T[];
  count: number;
  totalPages: number;
  currentPage: number;
  status: string;
};

export const UserProfileSchema = {
  type: 'object',
  required: ['id'],
  properties: {
    id: {type: 'string'},
    email: {type: 'string'},
    name: {type: 'string'},
  },
};

const CredentialsSchema = {
  type: 'object',
  required: ['email', 'password'],
  properties: {
    email: {
      type: 'string',
    },
    password: {
      type: 'string',
      // minLength: 6,
    },
    source: {
      type: 'string',
      enum: ['mobile_app', 'web'],
    },
    browserAgent: {
      type: 'string',
    },
  },
};

export const CredentialsRequestBody = {
  description: 'The input of login function',
  required: true,
  content: {
    'application/json': {schema: CredentialsSchema},
  },
};

const EmailCredentialSchema = {
  type: 'object',
  required: ['email'],
  properties: {
    email: {
      type: 'string',
      format: 'email',
    },
  },
};

export const EmailCredentialRequestBody = {
  description: 'The input of forgot password function',
  required: true,
  content: {
    'application/json': {schema: EmailCredentialSchema},
  },
};
const ResetCredentialsSchema = {
  type: 'object',
  required: ['token', 'password'],
  properties: {
    token: {
      type: 'string',
      minLength: 6,
    },
    password: {
      type: 'string',
      minLength: 6,
    },
  },
};

export const ResetCredentialsRequestBody = {
  description: 'The input of forgot password function',
  required: true,
  content: {
    'application/json': {schema: ResetCredentialsSchema},
  },
};

export const activityTypeObj = {
  PSA: 'PSA',
  BMI: 'BMI',
  BLA: 'BLA',
  LABS: 'LABS',
  HBAIC: 'HBAIC',
  WEIGHT: 'WEIGHT',
  HEIGHT: 'HEIGHT',
  PHARMACY: 'PHARMACY',
  PROVIDER: 'PROVIDER',
  EYE_EXAM: 'EYE-EXAM',
  FOOT_EXAM: 'FOOT-EXAM',
  CHOLESTROL: 'CHOLESTROL',
  BLOOD_SUGAR: 'BLOOD-SUGAR',
  TEMPERATURE: 'TEMPERATURE',
  BLOOD_PRESSURE: 'BLOOD-PRESSURE',
  HEALTH_CONDITIONS: 'HEALTH-CONDITIONS',
  MEDICAL_PROCEDURES: 'MEDICAL-PROCEDURES',
  WAIST_CIRCUMFERENCE: 'WAIST-CIRCUMFERENCE',
  MEDICATION_PASSPORT: 'MEDICATION-PASSPORT',
  USER_MENTAL_ASSESSMENT: 'USER-MENTAL-ASSESSMENT',
};

export const BulkCommunicationRequestBody = {
  type: 'object',
  content: {
    'application/json': {
      schema: {
        required: ['emails', 'phoneNumbers', 'comment', 'logType', 'entryDate'],
        type: 'object',
        properties: {
          emails: {
            type: 'array',
            items: {
              type: 'string',
            },
          },
          phoneNumbers: {
            type: 'array',
            items: {
              type: 'string',
            },
          },
          comment: {
            type: 'string',
          },
          entryDate: {
            type: 'string',
            format: 'date',
          },
          logType: {
            type: 'string',
            enum: [
              'hub_visit',
              'telegram_chat',
              'whatsapp_chat',
              'sms',
              'call',
              'email',
            ],
          },
          time: {type: 'string', format: 'date'},
          endTime: {
            type: 'string',
            format: 'date',
          },
          logTime: {
            type: 'string',
            format: 'date',
          },
          adminId: {
            type: 'string',
          },
          coachId: {
            type: 'string',
          },
          isBulk: {
            type: 'boolean',
          },
          conversationType: {
            type: 'string',
            enum: ['private', 'group', ''],
          },
        },
      },
    },
  },
};

export type BulkCommunicationLog = {
  emails: string[];
  phoneNumbers: string[];
  comment: string;
  entryDate: Date;
  logType: string;
  adminId?: string;
  coachId?: string;
  isBulk?: boolean;
};

export type DashboardStatisticsType = {
  totalCoaches: number;
  totalMaleCoaches: number;
  totalFemaleCoaches: number;
  totalMembers: number;
  totalMaleMembers: number;
  totalFemaleMembers: number;
  totalSubscriptions: number;
  totalActiveSubscriptions: number;
  totalExpiredSubscriptions: number;
  totalPrograms: number;
  totalPendingPrograms: number;
  totalApprovedPrograms: number;
};

export enum NotificationTypeEnum {
  CHAT = 'CHAT',
  REMINDER = 'REMINDER',
  NEW_SUBSCRIPTION = 'NEW_SUBSCRIPTION',
  GENERAL = 'GENERAL',
  NEW_BLOG_POST = 'NEW_BLOG_POST',
  COACH_APPOINTMENT = 'COACH_APPOINTMENT',
  SUBSCRIPTION_RENEWAL = 'SUBSCRIPTION_RENEWAL',
  NEW_OUTLIER = 'NEW_OUTLIER',
  NEW_FORUM = 'NEW_FORUM',
}

export enum NotificationPriorityEnum {
  HIGH = 'high',
  MEDIUM = 'medium',
  LOW = 'low',
}

export enum SenderTypeEnum {
  COACH = 'coach',
  USER = 'user',
}

export enum ActiveInactiveEnum {
  ACTIVE = 'active',
  INACTIVE = 'inactive',
}

export enum VerificationTypeEnum {
  activation = 'activation',
  reset = 'reset',
}
export enum CalenderEventStatusEnum {
  CREATED = 'created',
  REJECTED = 'rejected',
  COMPLETED = 'completed',
  RESCHEDULED = 'rescheduled',
  ACCEPTED = 'accepted',
}

export enum RecurringFreqencyEnum {
  DAILY = 'daily',
  WEEKLY = 'weekly',
  MONTHLY = 'monthly',
  CUSTOM = 'custom',
}

export enum DayOfTheWeekEnum {
  SUNDAY = 'sunday',
  MONDAY = 'monday',
  TUESDAY = 'tuesday',
  WEDNESDAY = 'wednesday',
  THURSDAY = 'thursday',
  FRIDAY = 'friday',
  SATURDAY = 'saturday',
}

export enum CreatorTypeEnum {
  coach = 'coach',
  user = 'user',
}
