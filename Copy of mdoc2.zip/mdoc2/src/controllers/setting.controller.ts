import { repository } from '@loopback/repository';
import { post, param, get, getModelSchemaRef, patch, requestBody, } from '@loopback/rest';
import { Setting, Symptoms } from '../models';
import { SettingRepository } from '../repositories';
import { OPERATION_SECURITY_SPEC } from '../utils/security-spec';
import { authenticate } from '@loopback/authentication';
import { inject } from '@loopback/core';
import * as _ from 'lodash'
import { SettingServiceBindings } from '../keys';
import { SettingService } from '../services';
export class SettingsController {
  constructor(
    @repository(SettingRepository) public settingRepository: SettingRepository,
    @inject(SettingServiceBindings.SETTING_SERVICE) public settingService: SettingService,
  ) { }

  @post('/settings', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Settings model instance',
        content: { 'application/json': { schema: getModelSchemaRef(Setting) } },
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Setting, {
            exclude: ['id'],
          }),
        },
      },
    })
    setting: Omit<Setting, 'id'>,
  ): Promise<Symptoms> {
    return this.settingService.createSetting(setting);
  }

  @get('/settings', {
    responses: {
      '200': {
        description: 'Array of Setting model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(Setting),
            },
          },
        },
      },
    },
  })
  async find(
  ): Promise<Setting[]> {
    return await this.settingService.find();
  }

  @get('/settings/{id}', {
    responses: {
      '200': {
        description: 'Setting model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Setting, { includeRelations: true }),
          },
        },
      },
    },
  })
  async findById(
    @param.path.string('id') id: string,
  ): Promise<Setting> {
    return this.settingService.findSettingById(id);
  }

  @patch('/settings/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Setting PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Setting, { partial: true }),
        },
      },
    })
    setting: Setting,
    ): Promise<void> {
        await this.settingService.updateSetting(id, setting);
    }
}
