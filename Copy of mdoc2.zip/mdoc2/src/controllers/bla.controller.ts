import {
  Bla,
  BlaRecord,
  BlaWithRelations,
  UserSubscriptions,
  UserSubscriptionsWithRelations,
} from '../models';
import {
  get,
  put,
  del,
  post,
  param,
  patch,
  requestBody,
  getWhereSchemaFor,
  getModelSchemaRef,
  getFilterSchemaFor,
} from '@loopback/rest';
import Utils from '../utils';
import {
  Count,
  Where,
  Filter,
  repository,
  CountSchema,
} from '@loopback/repository';
import {inject} from '@loopback/context';
import {BlaServiceBindings} from '../keys';
import {PaginatedResponse} from '../type-schema';
import {BlaService} from '../services/bla.service';
import {authenticate} from '@loopback/authentication';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';
import {BlaRepository, UserSubscriptionsRepository} from '../repositories';

export class BlaController {
  constructor(
    @repository(BlaRepository)
    public blaRepository: BlaRepository,
    @repository(UserSubscriptionsRepository)
    public userSubscriptionsRepository: UserSubscriptionsRepository,
    @inject(BlaServiceBindings.BLA_SERVICE) public blaService: BlaService,
  ) {}

  @post('/bla', {
    responses: {
      '200': {
        description: 'Bla model instance',
        content: {'application/json': {schema: getModelSchemaRef(Bla)}},
      },
    },
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Bla, {
            title: 'NewBla',
            exclude: ['id'],
          }),
        },
      },
    })
    bla: Omit<Bla, 'id'>,
  ): Promise<Bla> {
    return this.blaService.create(bla);
  }

  @post('/bla/bulk', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of Bla model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(UserSubscriptions, {
              includeRelations: true,
            }),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async createBulk(
    @requestBody({
      content: {
        'application/json': {
          schema: {
            type: 'array',
            items: getModelSchemaRef(Bla, {
              title: 'NewBla',
              exclude: ['id'],
            }),
          },
        },
      },
    })
    blaList: Omit<Bla, 'id'>[],
    @param.query.string('userSubscriptionId') userSubscriptionId: string,
  ): Promise<UserSubscriptionsWithRelations> {
    return this.blaService.createBulk(blaList, userSubscriptionId);
  }

  @get('/bla/count', {
    responses: {
      '200': {
        description: 'Bla model count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async count(
    @param.query.object('where', getWhereSchemaFor(Bla)) where?: Where<Bla>,
  ): Promise<Count> {
    return this.blaRepository.count(where);
  }


  @get('/bla', {
    responses: {
      '200': {
        description: 'Array of Bla model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(Bla, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  async find(
    @param.query.object('filter') filter?: Filter<Bla>,
  ): Promise<BlaWithRelations[]> {
    return this.blaService.findAll(filter);
  }

  @patch('/bla', {
    responses: {
      '200': {
        description: 'Bla PATCH success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Bla, {partial: true}),
        },
      },
    })
    bla: Bla,
    @param.query.object('where', getWhereSchemaFor(Bla)) where?: Where<Bla>,
  ): Promise<Count> {
    return this.blaRepository.updateAll(bla, where);
  }

  @get('/bla/{id}', {
    responses: {
      '200': {
        description: 'Bla model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Bla, {includeRelations: true}),
          },
        },
      },
    },
  })
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(Bla)) filter?: Filter<Bla>,
  ): Promise<Bla> {
    return this.blaRepository.findById(id, filter);
  }

  @patch('/bla/{id}', {
    responses: {
      '204': {
        description: 'Bla PATCH success',
      },
    },
  })
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Bla, {partial: true}),
        },
      },
    })
    bla: Bla,
  ): Promise<void> {
    await this.blaRepository.updateById(id, bla);
  }

  @put('/bla/{id}', {
    responses: {
      '204': {
        description: 'Bla PUT success',
      },
    },
  })
  async replaceById(
    @param.path.string('id') id: string,
    @requestBody() bla: Bla,
  ): Promise<void> {
    await this.blaRepository.replaceById(id, bla);
  }

  @del('/bla/{id}', {
    responses: {
      '204': {
        description: 'Bla DELETE success',
      },
    },
  })
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.blaRepository.deleteById(id);
  }

  @get('/bla-record', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of BlaRecord model instances',
        content: {
          'application/json': {
            schema: Utils.paginatedSchema(BlaRecord, true),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findAllBlaRecord(
    @param.query.object('filter') filter?: Filter<BlaRecord>,
    @param.query.number('page') page?: number,
  ): Promise<PaginatedResponse<BlaRecord>> {
    return this.blaService.findAllBlaRecord(filter, page);
  }

  @get('/bla-record/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'BlaRecord model instances',
        content: {
          'application/json': {
            schema: getModelSchemaRef(BlaRecord, {includeRelations: true}),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async blaRecordById(
    @param.path.string('id') id: string,
    @param.query.object('filter') filter?: Filter<BlaRecord>,
  ): Promise<BlaRecord> {
    return this.blaService.blaRecordById(id, filter);
  }
}
