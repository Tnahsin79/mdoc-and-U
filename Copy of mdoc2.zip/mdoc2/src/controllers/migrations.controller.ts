import * as _ from 'lodash';
import csv from 'csvtojson';
import Utils from '../utils';
import {get} from '@loopback/rest';
import {inject} from '@loopback/core';
import {MigrationService} from '../services/migration.service';
import {MigrationServiceV2} from '../services/migration-v2.service';
import {MigrationServiceBindings, MigrationServiceV2Bindings} from '../keys';
import { AnyObject } from '@loopback/repository';

export class MigrationController {
  configOption = Utils.getSiteOptions();

  constructor(
    @inject(MigrationServiceBindings.MIGRATION_SERVICE)
    public migrationService: MigrationService,
    @inject(MigrationServiceV2Bindings.MIGRATION_SERVICE)
    public migrationServiceV2: MigrationServiceV2,
  ) {}

  // New route that combines both migrations
  @get('/migration/all', {
    responses: {
      '200': {
        description: 'Combined migration instance',
      },
    },
  })
  async combinedMigration(): Promise<AnyObject> {
    // Call the logic of both migrations
    // one time migrations
    const usersMigrationResult = await this.usersModelMigration();
    console.log(usersMigrationResult)
    console.log('usersMigration Done')
    const coachesMigrationResult = await this.coachesMigration();
    console.log(coachesMigrationResult)
    console.log('coachesMigration Done')
    const medicationsMigrationResult = await this.medicationsMigration();
    console.log(medicationsMigrationResult)
    console.log('medicationsMigration Done')
    const usersExerciseTypeMigrationResult = await this.usersExerciseTypeMigration();
    console.log(usersExerciseTypeMigrationResult)
    console.log('usersExerciseTypeMigration Done')
    const proceduresListMigrationResult = await this.proceduresListMigration();
    console.log(proceduresListMigrationResult)
    console.log('proceduresListMigration Done')
    const diseaseMigrationResult = await this.diseaseMigration();
    console.log(diseaseMigrationResult)
    console.log('diseaseMigration Done')

    // repeated migrations
    const actionPlanMigrationResult = await this.usersActionPlanMigration();
    console.log(actionPlanMigrationResult)
    console.log('actionPlanMigration Done')
    const lifestyleDiaryMigrationResult = await this.usersLifestyleDiaryMigration();
    console.log(lifestyleDiaryMigrationResult)
    console.log('lifestyleDiaryMigration Done')
    const weightMigrationResult = await this.usersWeightMigration();
    console.log(weightMigrationResult)
    console.log('weightMigration Done')
    const waistCircumferenceMigrationResult = await this.usersWaistCircumferenceMigration();
    console.log(waistCircumferenceMigrationResult)
    console.log('waistCircumferenceMigration Done')
    const usersPSAMigrationResult = await this.usersPSAMigration();
    console.log(usersPSAMigrationResult)
    console.log('usersPSAMigration Done')
    const usersProviderMigrationResult = await this.usersProviderMigration();
    console.log(usersProviderMigrationResult)
    console.log('usersProviderMigration Done')
    const usersPharmacyMigrationResult = await this.usersPharmacyMigration();
    console.log(usersPharmacyMigrationResult)
    console.log('usersPharmacyMigration Done')
    const usersNotesMigrationResult = await this.usersNotesMigration();
    console.log(usersNotesMigrationResult)
    console.log('usersNotesMigration Done')
    const userMedicationPassportMigrationResult = await this.userMedicationPassportMigration();
    console.log(userMedicationPassportMigrationResult)
    console.log('userMedicationPassportMigration Done')
    const usersBloodPressureMigrationResult = await this.usersBloodPressureMigration();
    console.log(usersBloodPressureMigrationResult)
    console.log('usersBloodPressureMigration Done')
    const usersBloodSugarMigrationResult = await this.usersBloodSugarMigration();
    console.log(usersBloodSugarMigrationResult)
    console.log('usersBloodSugarMigration Done')
    const usersCholesterolMigrationResult = await this.usersCholesterolMigration();
    console.log(usersCholesterolMigrationResult)
    console.log('usersCholesterolMigration Done')
    const usersExerciseMigrationResult = await this.usersExerciseMigration();
    console.log(usersExerciseMigrationResult)
    console.log('usersExerciseMigration Done')
    const usersBMIMigrationResult = await this.usersBMIMigration();
    console.log(usersBMIMigrationResult)
    console.log('usersBMIMigration Done')
    const usersEyeExaminationMigrationResult = await this.usersEyeExaminationMigration();
    console.log(usersEyeExaminationMigrationResult)
    console.log('usersEyeExaminationMigration Done')
    const usersFootExaminationMigrationResult = await this.usersFootExaminationMigration();
    console.log(usersFootExaminationMigrationResult)
    console.log('usersFootExaminationMigration Done')
    const usersHba1cMigrationResult = await this.usersHba1cMigration();
    console.log(usersHba1cMigrationResult)
    console.log('usersHba1cMigration Done')
    const usersHealthProceduresSurgeriesMigrationResult = await this.usersHealthProceduresSurgeriesMigration();
    console.log(usersHealthProceduresSurgeriesMigrationResult)
    console.log('usersHealthProceduresSurgeriesMigration Done')
    const usersHealthConditionMigrationResult = await this.usersHealthConditionMigration();
    console.log(usersHealthConditionMigrationResult)
    console.log('usersHealthConditionMigration Done')
    const usersWeightGoalMigrationResult = await this.usersWeightGoalMigration();
    console.log(usersWeightGoalMigrationResult)
    console.log('usersWeightGoalMigration Done')
    const usersCommunicationLogMigrationResult = await this.usersCommunicationLogMigration();
    console.log(usersCommunicationLogMigrationResult)
    console.log('usersCommunicationLogMigration Done')

    const combinedResult = {
      // one time migrations
      usersMigration: usersMigrationResult,
      coachesMigration: coachesMigrationResult,
      medicationsMigration: medicationsMigrationResult,
      usersExerciseTypeMigration: usersExerciseTypeMigrationResult,
      proceduresListMigration: proceduresListMigrationResult,
      diseaseMigration: diseaseMigrationResult,
      
      // repeated migrations
      actionPlanMigration: actionPlanMigrationResult,
      lifestyleDiaryMigration: lifestyleDiaryMigrationResult,
      weightMigration: weightMigrationResult,
      waistCircumferenceMigration: waistCircumferenceMigrationResult,
      usersPSAMigration: usersPSAMigrationResult,
      usersProviderMigration: usersProviderMigrationResult,
      usersPharmacyMigration: usersPharmacyMigrationResult,
      usersNotesMigration: usersNotesMigrationResult,
      userMedicationPassportMigration: userMedicationPassportMigrationResult,
      usersBloodPressureMigration: usersBloodPressureMigrationResult,
      usersBloodSugarMigration: usersBloodSugarMigrationResult,
      usersCholesterolMigration: usersCholesterolMigrationResult,
      usersExerciseMigration: usersExerciseMigrationResult,
      usersBMIMigration: usersBMIMigrationResult,
      usersEyeExaminationMigration: usersEyeExaminationMigrationResult,
      usersFootExaminationMigration: usersFootExaminationMigrationResult,
      usersHba1cMigration: usersHba1cMigrationResult,
      usersHealthProceduresSurgeriesMigration: usersHealthProceduresSurgeriesMigrationResult,
      usersHealthConditionMigration: usersHealthConditionMigrationResult,
      usersWeightGoalMigration: usersWeightGoalMigrationResult,
      usersCommunicationLogMigration: usersCommunicationLogMigrationResult,
    };

    return combinedResult;
  }

  @get('/migration/users', {
    responses: {
      '200': {
        description: 'User migration instance',
      },
    },
  })
  async usersModelMigration(): Promise<AnyObject> {
    let validRecords = 0;
    let insertedRecords = 0;
    const invalidRecords = [];
    const stats = {
      create: [],
      accountExist: [],
      providerIdExist: []
    }
    const filePath = './public/users_records.csv';

    const usersList = await csv().fromFile(filePath);

    if (usersList?.length) {
      for (const [index, user] of usersList.entries()) {
        if ((user?.email || user?.phone) && user?.md5password && user?.providerId) {
          validRecords++;
          const response = await this.migrationServiceV2.userMigration(user);
          if (response) {
            console.log("passed: ", response.providerId)
            insertedRecords++;
            stats[response.status].push(response.providerId)
          }
        } else {
          invalidRecords.push(user);
        }
      }
    }

    return {
      totalRecords: usersList?.length,
      validRecords,
      insertedRecords,
      skippedRecords: usersList?.length - insertedRecords,
      invalidRecords,
      statsCount: {
        create: stats.create.length,
        accountExist: stats.accountExist.length,
        providerIdExist: stats.providerIdExist.length
      },
      stats,
    };
  }

  @get('/migration/weight', {
    responses: {
      '200': {
        description: 'User weight migration instance',
      },
    },
  })
  async usersWeightMigration(): Promise<AnyObject> {
    let validRecords = 0;
    let insertedRecords = 0;
    const invalidRecords = [];
    const stats = {
      CREATE: [],
      METRIC_EXIST: [],
      USER_NOT_EXIST: []
    }
    const filePath = './public/weight_diary.csv';

    const userWeightList = await csv().fromFile(filePath);
    if (userWeightList?.length) {
      for (const [index, weight] of userWeightList.entries()) {
        if (weight?.userId && weight?.value && weight?.unit && weight?.logDate) {
          validRecords++;
          const response = await this.migrationServiceV2.usersWeightMigration(weight);
          if (response) {
            console.log("passed: ", response.providerId)
            insertedRecords++;
            stats[response.status].push(response.providerId)
          }
        } else {
          invalidRecords.push(weight);
        }
      }
    }

    return {
      totalRecords: userWeightList?.length,
      validRecords,
      insertedRecords,
      skippedRecords: userWeightList?.length - insertedRecords,
      invalidRecords,
      statsCount: {
        CREATE: stats.CREATE.length,
        METRIC_EXIST: stats.METRIC_EXIST.length,
        USER_NOT_EXIST: stats.USER_NOT_EXIST.length
      },
      stats,
    };
  }

  @get('/migration/waist-circumference', {
    responses: {
      '200': {
        description: 'User waist circumference migration instance',
      },
    },
  })
  async usersWaistCircumferenceMigration(): Promise<AnyObject> {
    let validRecords = 0;
    let insertedRecords = 0;
    const invalidRecords = [];
    const stats = {
      CREATE: [],
      METRIC_EXIST: [],
      USER_NOT_EXIST: []
    }
    const filePath = './public/waist_circumference.csv';

    const userWaistCircumferenceList = await csv().fromFile(filePath);
    if (userWaistCircumferenceList?.length) {
      for (const [index, waist] of userWaistCircumferenceList.entries()) {
        if (waist?.userId && waist?.currentWaist && waist?.unit && waist?.logDate) {
          validRecords++;
          const response = await this.migrationServiceV2.userWaistCircumferenceMigration(waist);
          if (response) {
            console.log(`passed: ${response.status}`, response.providerId)
            insertedRecords++;
            stats[response.status].push(response.providerId)
          }
        } else {
          invalidRecords.push(waist);
        }
      }
    }

    return {
      totalRecords: userWaistCircumferenceList?.length,
      validRecords,
      insertedRecords,
      skippedRecords: userWaistCircumferenceList?.length - insertedRecords,
      invalidRecords,
      statsCount: {
        CREATE: stats.CREATE.length,
        METRIC_EXIST: stats.METRIC_EXIST.length,
        USER_NOT_EXIST: stats.USER_NOT_EXIST.length
      },
      stats,
    };
  }

  @get('/migration/psa', {
    responses: {
      '200': {
        description: 'User psa migration instance',
      },
    },
  })
  async usersPSAMigration(): Promise<AnyObject> {
    let validRecords = 0;
    let insertedRecords = 0;
    const invalidRecords = [];
    const stats = {
      CREATE: [],
      METRIC_EXIST: [],
      USER_NOT_EXIST: []
    }
    const filePath = './public/psa_history.csv';

    const userPSAList = await csv().fromFile(filePath);
    if (userPSAList?.length) {
      for (const [index, psa] of userPSAList.entries()) {
        if (psa?.userId && psa?.totalPsa && psa?.logDate) {
          validRecords++;
          const response = await this.migrationServiceV2.userPSAMigration(psa);
          if (response) {
            console.log("passed: ", response.providerId)
            insertedRecords++;
            stats[response.status].push(response.providerId)
          }
        } else {
          invalidRecords.push(psa);
        }
      }
    }

    return {
      totalRecords: userPSAList?.length,
      validRecords,
      insertedRecords,
      skippedRecords: userPSAList?.length - insertedRecords,
      invalidRecords,
      statsCount: {
        CREATE: stats.CREATE.length,
        METRIC_EXIST: stats.METRIC_EXIST.length,
        USER_NOT_EXIST: stats.USER_NOT_EXIST.length
      },
      stats,
    };
  }

  @get('/migration/provider', {
    responses: {
      '200': {
        description: 'User provider migration instance',
      },
    },
  })
  async usersProviderMigration(): Promise<AnyObject> {
    let validRecords = 0;
    let insertedRecords = 0;
    const invalidRecords = [];
    const stats = {
      CREATE: [],
      METRIC_EXIST: [],
      USER_NOT_EXIST: []
    }
    const filePath = './public/provider_batch.csv';

    const userProviderList = await csv().fromFile(filePath);
    if (userProviderList?.length) {
      for (const [index, provider] of userProviderList.entries()) {
        if (provider?.userId && provider?.name && provider?.hospitalName && provider?.address) {
          validRecords++;
          const response = await this.migrationServiceV2.userProviderMigration(provider);
          if (response) {
            console.log("passed: ", response.providerId)
            insertedRecords++;
            stats[response.status].push(response.providerId)
          }
        } else {
          invalidRecords.push(provider);
        }
      }
    }

    return {
      totalRecords: userProviderList?.length,
      validRecords,
      insertedRecords,
      skippedRecords: userProviderList?.length - insertedRecords,
      invalidRecords,
      statsCount: {
        CREATE: stats.CREATE.length,
        METRIC_EXIST: stats.METRIC_EXIST.length,
        USER_NOT_EXIST: stats.USER_NOT_EXIST.length
      },
      stats,
    };
  }

  @get('/migration/pharmacy', {
    responses: {
      '200': {
        description: 'User pharmacy migration instance',
      },
    },
  })
  async usersPharmacyMigration(): Promise<AnyObject> {
    let validRecords = 0;
    let insertedRecords = 0;
    const invalidRecords = [];
    const stats = {
      CREATE: [],
      METRIC_EXIST: [],
      USER_NOT_EXIST: []
    }
    const filePath = './public/pharmacy_batch.csv';

    const userPharmacyList = await csv().fromFile(filePath);
    if (userPharmacyList?.length) {
      for (const [index, pharmacy] of userPharmacyList.entries()) {
        if (pharmacy?.userId && pharmacy?.name && pharmacy?.address) {
          validRecords++;
          const response = await this.migrationServiceV2.userPharmacyMigration(pharmacy);
          if (response) {
            console.log("passed: ", response.providerId)
            insertedRecords++;
            stats[response.status].push(response.providerId)
          }
        } else {
          invalidRecords.push(pharmacy);
        }
      }
    }

    return {
      totalRecords: userPharmacyList?.length,
      validRecords,
      insertedRecords,
      skippedRecords: userPharmacyList?.length - insertedRecords,
      invalidRecords,
      statsCount: {
        CREATE: stats.CREATE.length,
        METRIC_EXIST: stats.METRIC_EXIST.length,
        USER_NOT_EXIST: stats.USER_NOT_EXIST.length
      },
      stats,
    };
  }

  @get('/migration/notes', {
    responses: {
      '200': {
        description: 'User pharmacy migration instance',
      },
    },
  })
  async usersNotesMigration(): Promise<AnyObject> {
    let validRecords = 0;
    let insertedRecords = 0;
    const invalidRecords = [];
    const stats = {
      CREATE: [],
      METRIC_EXIST: [],
      USER_NOT_EXIST: []
    }
    const filePath = './public/notes_batch.csv';

    const userNotesList = await csv().fromFile(filePath);
    if (userNotesList?.length) {
      for (const [index, note] of userNotesList.entries()) {
        if (note?.userId && note?.summary && note?.title) {
          validRecords++;
          const response = await this.migrationServiceV2.usersNotesMigration(note);
          if (response) {
            console.log("passed: ", response.providerId)
            insertedRecords++;
            stats[response.status].push(response.providerId)
          }
        } else {
          invalidRecords.push(note);
        }
      }
    }

    return {
      totalRecords: userNotesList?.length,
      validRecords,
      insertedRecords,
      skippedRecords: userNotesList?.length - insertedRecords,
      invalidRecords,
      statsCount: {
        CREATE: stats.CREATE.length,
        METRIC_EXIST: stats.METRIC_EXIST.length,
        USER_NOT_EXIST: stats.USER_NOT_EXIST.length
      },
      stats,
    };
  }

  @get('/migration/medications', {
    responses: {
      '200': {
        description: 'Medications migration instance',
      },
    },
  })
  async medicationsMigration(): Promise<AnyObject> {                               
    let validRecords = 0;
    let insertedRecords = 0;
    const invalidRecords = [];
    const stats = {
      CREATE: [],
      METRIC_EXIST: [],
      USER_NOT_EXIST: []
    }
    const filePath = './public/single/medication_list.csv';

    const medicationList = await csv().fromFile(filePath);
    if (medicationList?.length) {
      for (const [index, medication] of medicationList.entries()) {
        if (medication?.id && medication?.name) {
          validRecords++;
          const response = await this.migrationServiceV2.medicationsMigration(medication);
          if (response) {
            console.log("passed: ", response.providerId)
            insertedRecords++;
            stats[response.status].push(response.providerId)
          }
        } else {
          invalidRecords.push(medication);
        }
      }
    }

    return {
      totalRecords: medicationList?.length,
      validRecords,
      insertedRecords,
      skippedRecords: medicationList?.length - insertedRecords,
      invalidRecords,
      statsCount: {
        CREATE: stats.CREATE.length,
        METRIC_EXIST: stats.METRIC_EXIST.length,
        USER_NOT_EXIST: stats.USER_NOT_EXIST.length
      },
      stats,
    };
  }

  @get('/migration/medication-passport', {
    responses: {
      '200': {
        description: 'User medication passport migration instance',
      },
    },
  })
  async userMedicationPassportMigration(): Promise<AnyObject> {
    let validRecords = 0;
    let insertedRecords = 0;
    const invalidRecords = [];
    const stats = {
      CREATE: [],
      METRIC_EXIST: [], 
      USER_NOT_EXIST: []
    }
    const filePath = './public/medications_history.csv';

    const userMedicationPassportList = await csv().fromFile(filePath);
    if (userMedicationPassportList?.length) {
      for (const [index, medicationPassport] of userMedicationPassportList.entries()) {
        if (medicationPassport?.userId && medicationPassport?.medicationId && medicationPassport?.frequency && medicationPassport?.startDate) {
          validRecords++;
          const response = await this.migrationServiceV2.userMedicationPassportMigration(medicationPassport);
          if (response) {
            console.log("passed: ", response.providerId)
            insertedRecords++;
            stats[response.status].push(response.providerId)
          }
        } else {
          invalidRecords.push(medicationPassport);
        }
      }
    }

    return {
      totalRecords: userMedicationPassportList?.length,
      validRecords,
      insertedRecords,
      skippedRecords: userMedicationPassportList?.length - insertedRecords,
      invalidRecords,
      statsCount: {
        CREATE: stats.CREATE.length,
        METRIC_EXIST: stats.METRIC_EXIST.length,
        USER_NOT_EXIST: stats.USER_NOT_EXIST.length
      },
      stats,
    };
  }

  @get('/migration/blood-pressure', {
    responses: {
      '200': {
        description: 'User blood pressure migration instance',
      },
    },
  })
  async usersBloodPressureMigration(): Promise<AnyObject> {
    let validRecords = 0;
    let insertedRecords = 0;
    const invalidRecords = [];
    const stats = {
      CREATE: [],
      METRIC_EXIST: [],
      USER_NOT_EXIST: []
    }
    const filePath = './public/blood_pressure_history.csv';

    const userBloodPressureList = await csv().fromFile(filePath);
    if (userBloodPressureList?.length) {
      for (const [index, bloodPressure] of userBloodPressureList.entries()) {
        if (bloodPressure?.userId && bloodPressure?.systolic && bloodPressure?.diastolic && bloodPressure?.logDate) {
          validRecords++;
          const response = await this.migrationServiceV2.usersBloodPressureMigration(bloodPressure);
          if (response) {
            console.log("passed: ", response.providerId)
            insertedRecords++;
            stats[response.status].push(response.providerId)
          }
        } else {
          invalidRecords.push(bloodPressure);
        }
      }
    }

    return {
      totalRecords: userBloodPressureList?.length,
      validRecords,
      insertedRecords,
      skippedRecords: userBloodPressureList?.length - insertedRecords,
      invalidRecords,
      statsCount: {
        CREATE: stats.CREATE.length,
        METRIC_EXIST: stats.METRIC_EXIST.length,
        USER_NOT_EXIST: stats.USER_NOT_EXIST.length
      },
      stats,
    };
  }

  @get('/migration/blood-sugar', {
    responses: {
      '200': {
        description: 'User blood sugar migration instance',
      },
    },
  })
  async usersBloodSugarMigration(): Promise<AnyObject> {
    let validRecords = 0;
    let insertedRecords = 0;
    const invalidRecords = [];
    const stats = {
      CREATE: [],
      METRIC_EXIST: [],
      USER_NOT_EXIST: []
    }
    const filePath = './public/sugar_tracker.csv';

    const userBloodSugarList = await csv().fromFile(filePath);
    if (userBloodSugarList?.length) {
      for (const [index, bloodSugar] of userBloodSugarList.entries()) {
        if (bloodSugar?.userId && bloodSugar?.mealType && bloodSugar?.logDate) {
          validRecords++;
          const response = await this.migrationServiceV2.usersBloodSugarMigration(bloodSugar);
          if (response) {
            console.log("passed: ", response.providerId)
            insertedRecords++;
            stats[response.status].push(response.providerId)
          }
        } else {
          invalidRecords.push(bloodSugar);
        }
      }
    }

    return {
      totalRecords: userBloodSugarList?.length,
      validRecords,
      insertedRecords,
      skippedRecords: userBloodSugarList?.length - insertedRecords,
      invalidRecords,
      statsCount: {
        CREATE: stats.CREATE.length,
        METRIC_EXIST: stats.METRIC_EXIST.length,
        USER_NOT_EXIST: stats.USER_NOT_EXIST.length
      },
      stats,
    };
  }

  @get('/migration/cholesterol', {
    responses: {
      '200': {
        description: 'User blood sugar migration instance',
      },
    },
  })
  async usersCholesterolMigration(): Promise<AnyObject> {
    let validRecords = 0;
    let insertedRecords = 0;
    const invalidRecords = [];
    const stats = {
      CREATE: [],
      METRIC_EXIST: [],
      USER_NOT_EXIST: []
    }
    const filePath = './public/cholesterol_tracker.csv';

    const userCholesterolList = await csv().fromFile(filePath);
    if (userCholesterolList?.length) {
      for (const [index, cholesterol] of userCholesterolList.entries()) {
        if (cholesterol?.userId && cholesterol?.triglycerides && cholesterol?.hdl && cholesterol?.ldl && cholesterol?.cholestrol && cholesterol?.logDate) {
          validRecords++;
          const response = await this.migrationServiceV2.usersCholesterolMigration(cholesterol);
          if (response) {
            console.log("passed: ", response.providerId)
            insertedRecords++;
            stats[response.status].push(response.providerId)
          }
        } else {
          invalidRecords.push(cholesterol);
        }
      }
    }

    return {
      totalRecords: userCholesterolList?.length,
      validRecords,
      insertedRecords,
      skippedRecords: userCholesterolList?.length - insertedRecords,
      invalidRecords,
      statsCount: {
        CREATE: stats.CREATE.length,
        METRIC_EXIST: stats.METRIC_EXIST.length,
        USER_NOT_EXIST: stats.USER_NOT_EXIST.length
      },
      stats,
    };
  }

  @get('/migration/exercise-type', {
    responses: {
      '200': {
        description: 'Exercise types migration instance',
      },
    },
  })
  async usersExerciseTypeMigration(): Promise<AnyObject> {
    let validRecords = 0;
    let insertedRecords = 0;
    const invalidRecords = [];
    const stats = {
      CREATE: [],
      METRIC_EXIST: [],
      USER_NOT_EXIST: []
    }
    const filePath = './public/single/exercise_type.csv';

    const userExerciseTypeList = await csv().fromFile(filePath);
    if (userExerciseTypeList?.length) {
      for (const [index, exerciseType] of userExerciseTypeList.entries()) {
        if (exerciseType?.id && exerciseType?.name) {
          validRecords++;
          const response = await this.migrationServiceV2.usersExerciseTypeMigration(exerciseType);
          if (response) {
            console.log("passed: ", response.providerId)
            insertedRecords++;
            stats[response.status].push(response.providerId)
          }
        } else {
          invalidRecords.push(exerciseType);
        }
      }
    }

    return {
      totalRecords: userExerciseTypeList?.length,
      validRecords,
      insertedRecords,
      skippedRecords: userExerciseTypeList?.length - insertedRecords,
      invalidRecords,
      statsCount: {
        CREATE: stats.CREATE.length,
        METRIC_EXIST: stats.METRIC_EXIST.length,
        USER_NOT_EXIST: stats.USER_NOT_EXIST.length
      },
      stats,
    };
  }

  @get('/migration/exercise', {
    responses: {
      '200': {
        description: 'Exercise migration instance',
      },
    },
  })
  async usersExerciseMigration(): Promise<AnyObject> {
    let validRecords = 0;
    let insertedRecords = 0;
    const invalidRecords = [];
    const stats = {
      CREATE: [],
      METRIC_EXIST: [],
      USER_NOT_EXIST: []
    }
    const filePath = './public/exercise_history.csv';

    const userExerciseList = await csv().fromFile(filePath);
    if (userExerciseList?.length) {
      for (const [index, exercise] of userExerciseList.entries()) {
        if (exercise?.userId && exercise?.duration && exercise?.intensity && exercise?.exercise_activity_id && exercise?.logDate) {
          validRecords++;
          const response = await this.migrationServiceV2.usersExerciseMigration(exercise);
          if (response) {
            console.log("passed: ", response.providerId)
            insertedRecords++;
            stats[response.status].push(response.providerId)
          }
        } else {
          invalidRecords.push(exercise);
        }
      }
    }

    return {
      totalRecords: userExerciseList?.length,
      validRecords,
      insertedRecords,
      skippedRecords: userExerciseList?.length - insertedRecords,
      invalidRecords,
      statsCount: {
        CREATE: stats.CREATE.length,
        METRIC_EXIST: stats.METRIC_EXIST.length,
        USER_NOT_EXIST: stats.USER_NOT_EXIST.length
      },
      stats,
    };
  }

  @get('/migration/procedures-list', {
    responses: {
      '200': {
        description: 'Procedure List migration instance',
      },
    },
  })
  async proceduresListMigration(): Promise<AnyObject> {
    let validRecords = 0;
    let insertedRecords = 0;
    const invalidRecords = [];
    const stats = {
      CREATE: [],
      METRIC_EXIST: [],
      USER_NOT_EXIST: []
    }
    const filePath = './public/single/procedures_list.csv';

    const proceduresList = await csv().fromFile(filePath);
    if (proceduresList?.length) {
      for (const [index, procedure] of proceduresList.entries()) {
        if (procedure?.procedureId && procedure?.name) {
          validRecords++;
          const response = await this.migrationServiceV2.proceduresListMigration(procedure);
          if (response) {
            console.log("passed: ", response.providerId)
            insertedRecords++;
            stats[response.status].push(response.providerId)
          }
        } else {
          invalidRecords.push(procedure);
        }
      }
    }

    return {
      totalRecords: proceduresList?.length,
      validRecords,
      insertedRecords,
      skippedRecords: proceduresList?.length - insertedRecords,
      invalidRecords,
      statsCount: {
        CREATE: stats.CREATE.length,
        METRIC_EXIST: stats.METRIC_EXIST.length,
        USER_NOT_EXIST: stats.USER_NOT_EXIST.length
      },
      stats,
    };
  }

  @get('/migration/bmi', {
    responses: {
      '200': {
        description: 'BMI migration instance',
      },
    },
  })
  async usersBMIMigration(): Promise<AnyObject> {
    let validRecords = 0;
    let insertedRecords = 0;
    const invalidRecords = [];
    const stats = {
      CREATE: [],
      METRIC_EXIST: [],
      USER_NOT_EXIST: []
    }
    const filePath = './public/bmi_tracker.csv';

    const bmiList = await csv().fromFile(filePath);
    if (bmiList?.length) {
      for (const [index, bmi] of bmiList.entries()) {
        if (bmi?.userId && bmi?.bmi && bmi?.logDate) {
          validRecords++;
          const response = await this.migrationServiceV2.usersBMIMigration(bmi);
          if (response) {
            console.log("passed: ", response.providerId)
            insertedRecords++;
            stats[response.status].push(response.providerId)
          }
        } else {
          invalidRecords.push(bmi);
        }
      }
    }

    return {
      totalRecords: bmiList?.length,
      validRecords,
      insertedRecords,
      skippedRecords: bmiList?.length - insertedRecords,
      invalidRecords,
      statsCount: {
        CREATE: stats.CREATE.length,
        METRIC_EXIST: stats.METRIC_EXIST.length,
        USER_NOT_EXIST: stats.USER_NOT_EXIST.length
      },
      stats,
    };
  }

  @get('/migration/eye-examination', {
    responses: {
      '200': {
        description: 'Eye examination migration instance',
      },
    },
  })
  async usersEyeExaminationMigration(): Promise<AnyObject> {
    let validRecords = 0;
    let insertedRecords = 0;
    const invalidRecords = [];
    const stats = {
      CREATE: [],
      METRIC_EXIST: [],
      USER_NOT_EXIST: []
    }
    const filePath = './public/eye_exam.csv';

    const eyeExaminationList = await csv().fromFile(filePath);
    if (eyeExaminationList?.length) {
      for (const [index, eyeExamination] of eyeExaminationList.entries()) {
        if (eyeExamination?.userId && eyeExamination?.testDate && eyeExamination?.name && eyeExamination?.address) {
          validRecords++;
          const response = await this.migrationServiceV2.usersEyeExaminationMigration(eyeExamination);
          if (response) {
            console.log("passed: ", response.providerId)
            insertedRecords++;
            stats[response.status].push(response.providerId)
          }
        } else {
          invalidRecords.push(eyeExamination);
        }
      }
    }

    return {
      totalRecords: eyeExaminationList?.length,
      validRecords,
      insertedRecords,
      skippedRecords: eyeExaminationList?.length - insertedRecords,
      invalidRecords,
      statsCount: {
        CREATE: stats.CREATE.length,
        METRIC_EXIST: stats.METRIC_EXIST.length,
        USER_NOT_EXIST: stats.USER_NOT_EXIST.length
      },
      stats,
    };
  }

  @get('/migration/foot-examination', {
    responses: {
      '200': {
        description: 'Foot examination migration instance',
      },
    },
  })
  async usersFootExaminationMigration(): Promise<AnyObject> {
    let validRecords = 0;
    let insertedRecords = 0;
    const invalidRecords = [];
    const stats = {
      CREATE: [],
      METRIC_EXIST: [],
      USER_NOT_EXIST: []
    }
    const filePath = './public/foot_exam.csv';

    const footExaminationList = await csv().fromFile(filePath);
    if (footExaminationList?.length) {
      for (const [index, footExamination] of footExaminationList.entries()) {
        if (footExamination?.userId && footExamination?.testDate && footExamination?.name && footExamination?.address) {
          validRecords++;
          const response = await this.migrationServiceV2.usersFootExaminationMigration(footExamination);
          if (response) {
            console.log("passed: ", response.providerId)
            insertedRecords++;
            stats[response.status].push(response.providerId)
          }
        } else {
          invalidRecords.push(footExamination);
        }
      }
    }

    return {
      totalRecords: footExaminationList?.length,
      validRecords,
      insertedRecords,
      skippedRecords: footExaminationList?.length - insertedRecords,
      invalidRecords,
      statsCount: {
        CREATE: stats.CREATE.length,
        METRIC_EXIST: stats.METRIC_EXIST.length,
        USER_NOT_EXIST: stats.USER_NOT_EXIST.length
      },
      stats,
    };
  }

  @get('/migration/hba1c', {
    responses: {
      '200': {
        description: 'Hba1c migration instance',
      },
    },
  })
  async usersHba1cMigration(): Promise<AnyObject> {
    let validRecords = 0;
    let insertedRecords = 0;
    const invalidRecords = [];
    const stats = {
      CREATE: [],
      METRIC_EXIST: [],
      USER_NOT_EXIST: []
    }
    const filePath = './public/diabetic_hba.csv';

    const hba1cList = await csv().fromFile(filePath);
    if (hba1cList?.length) {
      for (const [index, hba1c] of hba1cList.entries()) {
        if (hba1c?.userId && hba1c?.value && hba1c?.logDate) {
          validRecords++;
          const response = await this.migrationServiceV2.usersHba1cMigration(hba1c);
          if (response) {
            console.log("passed: ", response.providerId)
            insertedRecords++;
            stats[response.status].push(response.providerId)
          }
        } else {
          invalidRecords.push(hba1c);
        }
      }
    }

    return {
      totalRecords: hba1cList?.length,
      validRecords,
      insertedRecords,
      skippedRecords: hba1cList?.length - insertedRecords,
      invalidRecords,
      statsCount: {
        CREATE: stats.CREATE.length,
        METRIC_EXIST: stats.METRIC_EXIST.length,
        USER_NOT_EXIST: stats.USER_NOT_EXIST.length
      },
      stats,
    };
  }

  @get('/migration/health-procedures-surgeries', {
    responses: {
      '200': {
        description: 'Health procedures surgeries migration instance',
      },
    },
  })
  async usersHealthProceduresSurgeriesMigration(): Promise<AnyObject> {
    let validRecords = 0;
    let insertedRecords = 0;
    const invalidRecords = [];
    const stats = {
      CREATE: [],
      METRIC_EXIST: [],
      USER_NOT_EXIST: []
    }
    const filePath = './public/surgery_history.csv';

    const healthProceduresSurgeriesList = await csv().fromFile(filePath);
    if (healthProceduresSurgeriesList?.length) {
      for (const [index, healthProceduresSurgery] of healthProceduresSurgeriesList.entries()) {
        if (healthProceduresSurgery?.userId && healthProceduresSurgery?.procedureId && healthProceduresSurgery?.treatmentDate) {
          validRecords++;
          const response = await this.migrationServiceV2.usersHealthProceduresSurgeriesMigration(healthProceduresSurgery);
          if (response) {
            console.log("passed: ", response.providerId)
            insertedRecords++;
            stats[response.status].push(response.providerId)
          }
        } else {
          invalidRecords.push(healthProceduresSurgery);
        }
      }
    }

    return {
      totalRecords: healthProceduresSurgeriesList?.length,
      validRecords,
      insertedRecords,
      skippedRecords: healthProceduresSurgeriesList?.length - insertedRecords,
      invalidRecords,
      statsCount: {
        CREATE: stats.CREATE.length,
        METRIC_EXIST: stats.METRIC_EXIST.length,
        USER_NOT_EXIST: stats.USER_NOT_EXIST.length
      },
      stats,
    };
  }

  @get('/migration/disease', {
    responses: {
      '200': {
        description: 'Disease migration instance',
      },
    },
  })
  async diseaseMigration(): Promise<AnyObject> {
    let validRecords = 0;
    let insertedRecords = 0;
    const invalidRecords = [];
    const stats = {
      CREATE: [],
      METRIC_EXIST: [],
      USER_NOT_EXIST: []
    }
    const filePath = './public/single/disease.csv';

    const diseaseList = await csv().fromFile(filePath);
    if (diseaseList?.length) {
      for (const [index, disease] of diseaseList.entries()) {
        if (disease?.id && disease?.type) {
          validRecords++;
          const response = await this.migrationServiceV2.diseaseMigration(disease);
          if (response) {
            console.log("passed: ", response.providerId)
            insertedRecords++;
            stats[response.status].push(response.providerId)
          }
        } else {
          invalidRecords.push(disease);
        }
      }
    }

    return {
      totalRecords: diseaseList?.length,
      validRecords,
      insertedRecords,
      skippedRecords: diseaseList?.length - insertedRecords,
      invalidRecords,
      statsCount: {
        CREATE: stats.CREATE.length,
        METRIC_EXIST: stats.METRIC_EXIST.length,
        USER_NOT_EXIST: stats.USER_NOT_EXIST.length
      },
      stats,
    };
  }

  @get('/migration/health-condition', {
    responses: {
      '200': {
        description: 'Health condition migration instance',
      },
    },
  })
  async usersHealthConditionMigration(): Promise<AnyObject> {
    let validRecords = 0;
    let insertedRecords = 0;
    const invalidRecords = [];
    const stats = {
      CREATE: [],
      METRIC_EXIST: [],
      USER_NOT_EXIST: []
    }
    const filePath = './public/user_conditions.csv';

    const healthConditionList = await csv().fromFile(filePath);
    if (healthConditionList?.length) {
      for (const [index, healthCondition] of healthConditionList.entries()) {
        if (healthCondition?.userId && healthCondition?.diseaseId && healthCondition?.source) {
          validRecords++;
          const response = await this.migrationServiceV2.usersHealthConditionMigration(healthCondition);
          if (response) {
            console.log("passed: ", response.providerId)
            insertedRecords++;
            stats[response.status].push(response.providerId)
          }
        } else {
          invalidRecords.push(healthCondition);
        }
      }
    }

    return {
      totalRecords: healthConditionList?.length,
      validRecords,
      insertedRecords,
      skippedRecords: healthConditionList?.length - insertedRecords,
      invalidRecords,
      statsCount: {
        CREATE: stats.CREATE.length,
        METRIC_EXIST: stats.METRIC_EXIST.length,
        USER_NOT_EXIST: stats.USER_NOT_EXIST.length
      },
      stats,
    };
  }

  @get('/migration/weight-goal', {
    responses: {
      '200': {
        description: 'Weight goal migration instance',
      },
    },
  })
  async usersWeightGoalMigration(): Promise<AnyObject> {
    let validRecords = 0;
    let insertedRecords = 0;
    const invalidRecords = [];
    const stats = {
      CREATE: [],
      METRIC_EXIST: [],
      USER_NOT_EXIST: []
    }
    const filePath = './public/weight_goal.csv';

    const weightGoalList = await csv().fromFile(filePath);
    if (weightGoalList?.length) {
      for (const [index, weightGoal] of weightGoalList.entries()) {
        if (weightGoal?.userId && weightGoal?.value && weightGoal?.logDate) {
          validRecords++;
          const response = await this.migrationServiceV2.usersWeightGoalMigration(weightGoal);
          if (response) {
            console.log("passed: ", response.providerId)
            insertedRecords++;
            stats[response.status].push(response.providerId)
          }
        } else {
          invalidRecords.push(weightGoal);
        }
      }
    }

    return {
      totalRecords: weightGoalList?.length,
      validRecords,
      insertedRecords,
      skippedRecords: weightGoalList?.length - insertedRecords,
      invalidRecords,
      statsCount: {
        CREATE: stats.CREATE.length,
        METRIC_EXIST: stats.METRIC_EXIST.length,
        USER_NOT_EXIST: stats.USER_NOT_EXIST.length
      },
      stats,
    };
  }

  @get('/migration/communication-log', {
    responses: {
      '200': {
        description: 'Communication log migration instance',
      },
    },
  })
  async usersCommunicationLogMigration(): Promise<AnyObject> {
    let validRecords = 0;
    let insertedRecords = 0;
    const invalidRecords = [];
    const stats = {
      CREATE: [],
      METRIC_EXIST: [],
      USER_NOT_EXIST: []
    }
    const filePath = './public/user_activities.csv';

    
    const communicationLogList = await csv().fromFile(filePath);
    if (communicationLogList?.length) {
      for (const [index, communicationLog] of communicationLogList.entries()) {
        if (communicationLog?.userId && communicationLog?.logType && communicationLog?.entryDate && communicationLog?.created) {
          validRecords++;
          const response = await this.migrationServiceV2.usersCommunicationLogMigration(communicationLog);
          if (response) {
            console.log(`passed: ${response.status}`, response.providerId)
            insertedRecords++;
            stats[response.status].push(response.providerId)
          }
        } else {
          invalidRecords.push(communicationLog);
        }
      }
    }

    return {
      totalRecords: communicationLogList?.length,
      validRecords,
      insertedRecords,
      skippedRecords: communicationLogList?.length - insertedRecords,
      invalidRecords,
      statsCount: {
        CREATE: stats.CREATE.length,
        METRIC_EXIST: stats.METRIC_EXIST.length,
        USER_NOT_EXIST: stats.USER_NOT_EXIST.length
      },
      stats,
    };
  }

  @get('/migration/communication-delete', {
    responses: {
      '200': {
        description: 'Communication log migration instance',
      },
    },
  })
  async usersCommunicationDeleteMigration(): Promise<AnyObject> {
    const filePath = './public/user_activities_delete.csv';

    const communicationLogList = await csv().fromFile(filePath);
    if (communicationLogList?.length) {
      const response = await this.migrationServiceV2.usersCommunicationDeleteMigration(communicationLogList);
      return {
        response
      };
    }
    return {
      response: 'No record'
    }
  }

  @get('/migration/coaches', {
    responses: {
      '200': {
        description: 'Coaches migration instance',
      },
    },
  })
  async coachesMigration(): Promise<AnyObject> {
    let validRecords = 0;
    let insertedRecords = 0;
    const invalidRecords = [];
    const stats = {
      create: [],
      accountExist: [],
      providerIdExist: []
    }
    const filePath = './public/coach_new.csv';

    const coachesList = await csv().fromFile(filePath);

    if (coachesList?.length) {
      for (const [index, user] of coachesList.entries()) {
        if ((user?.email || user?.phone) && user?.md5password && user?.providerId) {
          validRecords++;
          const response = await this.migrationServiceV2.coachesMigration(user);
          if (response) {
            console.log("passed: ", response.providerId)
            insertedRecords++;
            stats[response.status].push(response.providerId)
          }
        } else {
          invalidRecords.push(user);
        }
      }
    }

    return {
      totalRecords: coachesList?.length,
      validRecords,
      insertedRecords,
      skippedRecords: coachesList?.length - insertedRecords,
      invalidRecords,
      statsCount: {
        create: stats.create.length,
        accountExist: stats.accountExist.length,
        providerIdExist: stats.providerIdExist.length
      },
      stats,
    };
  }

  @get('/migration/action-plan', {
    responses: {
      '200': {
        description: 'Action Plan migration instance',
      },
    },
  })
  async usersActionPlanMigration(): Promise<AnyObject> {
    let validRecords = 0;
    let insertedRecords = 0;
    const invalidRecords = [];
    const stats = {
      CREATE: [],
      METRIC_EXIST: [],
      USER_NOT_EXIST: []
    }
    const filePath = './public/action_plans.csv';

    const userActionPlanList = await csv().fromFile(filePath);
    if (userActionPlanList?.length) {
      for (const [index, action] of userActionPlanList.entries()) {
        if (action?.userId && action?.body) {
          validRecords++;
          const response = await this.migrationServiceV2.usersActionPlanMigration(action);
          if (response) {
            console.log("passed: ", response.providerId)
            insertedRecords++;
            stats[response.status].push(response.providerId)
          }
        } else {
          invalidRecords.push(action);
        }
      }
    }

    return {
      totalRecords: userActionPlanList?.length,
      validRecords,
      insertedRecords,
      skippedRecords: userActionPlanList?.length - insertedRecords,
      invalidRecords,
      statsCount: {
        CREATE: stats.CREATE.length,
        METRIC_EXIST: stats.METRIC_EXIST.length,
        USER_NOT_EXIST: stats.USER_NOT_EXIST.length
      },
      stats,
    };
  }

  @get('/migration/lifestyle-diary', {
    responses: {
      '200': {
        description: 'Lifestyle Diary migration instance',
      },
    },
  })
  async usersLifestyleDiaryMigration(): Promise<AnyObject> {
    let validRecords = 0;
    let insertedRecords = 0;
    const invalidRecords = [];
    const stats = {
      CREATE: [],
      METRIC_EXIST: [],
      USER_NOT_EXIST: []
    }
    const filePath = './public/lifestyle_diary.csv';

    const userLifestyleDiaryList = await csv().fromFile(filePath);
    if (userLifestyleDiaryList?.length) {
      for (const [index, lifestyle] of userLifestyleDiaryList.entries()) {
        if (lifestyle?.userId && lifestyle?.sleepTime && lifestyle?.exercise && lifestyle?.fluShots && lifestyle?.smokeTobacco && lifestyle?.drinkAlcohol && lifestyle?.recreatDrugs && lifestyle?.toxicChemical && lifestyle?.everDisabled) {
          validRecords++;
          const response = await this.migrationServiceV2.usersLifestyleDiaryMigration(lifestyle);
          if (response) {
            console.log("passed: ", response.providerId)
            insertedRecords++;
            stats[response.status].push(response.providerId)
          }
        } else {
          invalidRecords.push(lifestyle);
        }
      }
    }

    return {
      totalRecords: userLifestyleDiaryList?.length,
      validRecords,
      insertedRecords,
      skippedRecords: userLifestyleDiaryList?.length - insertedRecords,
      invalidRecords,
      statsCount: {
        CREATE: stats.CREATE.length,
        METRIC_EXIST: stats.METRIC_EXIST.length,
        USER_NOT_EXIST: stats.USER_NOT_EXIST.length
      },
      stats,
    };
  }

  @get('/migration/user-height', {
    responses: {
      '200': {
        description: 'User Height migration instance',
      },
    },
  })
  async userHeightMigration(): Promise<AnyObject> {
    const response = await this.migrationServiceV2.userHeightMigration();
    if (response) {
      console.log("passed: ", response)
    }

    return {
      response,
      message: 'Completed the migration'
    }
  }

  @get('/migration/user-height-missing', {
    responses: {
      '200': {
        description: 'User Height missing migration instance',
      },
    },
  })
  async userHeightMissingMigration(): Promise<AnyObject> {
    let validRecords = 0;
    let insertedRecords = 0;
    const invalidRecords = [];
    const stats = {
      CREATE: [],
      METRIC_EXIST: [],
      USER_NOT_EXIST: []
    }
    const filePath = './public/height_missing.csv';

    const userMissingHeight = await csv().fromFile(filePath);
    if (userMissingHeight?.length) {
      for (const [index, action] of userMissingHeight.entries()) {
        if (action?.providerId && action?.height) {
          validRecords++;
          const response = await this.migrationServiceV2.userHeightMissingMigration(action);
          if (response) {
            console.log("passed: ", response.providerId)
            insertedRecords++;
            stats[response.status].push(response.providerId)
          }
        } else {
          invalidRecords.push(action);
        }
      }
    }

    return {
      totalRecords: userMissingHeight?.length,
      validRecords,
      insertedRecords,
      skippedRecords: userMissingHeight?.length - insertedRecords,
      invalidRecords,
      statsCount: {
        CREATE: stats.CREATE.length,
        METRIC_EXIST: stats.METRIC_EXIST.length,
        USER_NOT_EXIST: stats.USER_NOT_EXIST.length
      },
      stats,
    };
  }

  @get('/migration/user-name-update', {
    responses: {
      '200': {
        description: 'First Name and Last Name migration instance',
      },
    },
  })
  async userFirstNameLastNameUpdate(): Promise<AnyObject> {
    const { selectedResponse, noNameResponse} = await this.migrationServiceV2.userFirstNameLastNameUpdate();

    return {
      countSelected: selectedResponse.length,
      countNoName: noNameResponse.length,
      selectedResponse,
      noNameResponse,
      message: 'Complete User name update'
    }
  }

  @get('/migration/sanitize-nigeria-numbers', {
    responses: {
      '200': {
        description: 'Strip the 0 after the nigeria country code',
      },
    },
  })
  async sanitizeNigeriaPhonenumbers(): Promise<AnyObject> {
    const { filteredAccounts } = await this.migrationServiceV2.sanitizeNigeriaPhonenumbers();

    return {
      countSelected: filteredAccounts.length,
      filteredAccounts,
      message: 'Complete sanitization of Phone numbers'
    }
  }

  @get('/migration/update-erased-phone', {
    responses: {
      '200': {
        description: 'Update cleaned users phone number by providerId array',
      },
    },
  })
  async updateErasedPhoneNumber(): Promise<AnyObject> {
    const filePath = './public/users_records_excel.csv';

    const usersList = await csv().fromFile(filePath);

    if (usersList?.length) {
      const { revertedAccountCount } = await this.migrationServiceV2.updateErasedPhoneNumber(usersList);
      return {
        countSelected: revertedAccountCount,
      }
    }
    
    return {
      message: 'Error occured'
    }
  }

  @get('/migration/sanitize-user-email-account', {
    responses: {
      '200': {
        description: 'Make user emails lowercase',
      },
    },
  })
  async sanitizeUserEmailAccount(): Promise<AnyObject> {
    const { filteredAccounts } = await this.migrationServiceV2.sanitizeUserEmailAccount();
    
    return {
      counts: filteredAccounts.length,
      accounts: filteredAccounts,
    }
  }

  @get('/migration/delete-user-email-account', {
    responses: {
      '200': {
        description: 'Delete specific user emails accounts',
      },
    },
  })
  async deleteUserEmailAccount(): Promise<AnyObject> {
    const { filteredAccounts } = await this.migrationServiceV2.deleteUserEmailAccount();
    
    return {
      counts: filteredAccounts.length,
      accounts: filteredAccounts,
    }
  }

  @get('/migration/health-diary-migration', {
    responses: {
      '200': {
        description: 'Health Diary migration instance',
      },
    },
  })
  async healthDiaryMigration(): Promise<AnyObject> {
    const selectedResponse = await this.migrationServiceV2.healthDiaryMigration();

    return {
      selectedResponse,
    }
  }
}
