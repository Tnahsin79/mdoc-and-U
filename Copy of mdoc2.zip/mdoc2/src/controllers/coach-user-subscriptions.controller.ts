import {
  get,
  del,
  post,
  patch,
  param,
  requestBody,
  getModelSchemaRef,
  getFilterSchemaFor,
} from '@loopback/rest';
import Utils from '../utils';
import {inject} from '@loopback/core';
import {Filter} from '@loopback/repository';
import {PaginatedResponse} from '../type-schema';
import {CoachUserSubscriptions} from '../models';
import {authenticate} from '@loopback/authentication';
import {CoachUserSubscriptionsService} from '../services';
import {CoachUserSubscriptionsServiceBindings} from '../keys';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';

export class CoachUserSubscriptionsController {
  constructor(
    @inject(
      CoachUserSubscriptionsServiceBindings.COACHUSERSUBSCRIPTIONS_SERVICE,
    )
    public coachUserSubscriptionsService: CoachUserSubscriptionsService,
  ) {}

  @post('/coach-user-subscriptions', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'CoachUserSubscriptions model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(CoachUserSubscriptions),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(CoachUserSubscriptions, {
            title: 'CoachUserSubscriptions',
            exclude: ['id'],
          }),
        },
      },
    })
    payload: Omit<CoachUserSubscriptions, 'id'>,
  ): Promise<CoachUserSubscriptions> {
    return this.coachUserSubscriptionsService.create(payload);
  }

  @post('/coach-user-subscriptions/bulk', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'CoachUserSubscriptions model instance',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(CoachUserSubscriptions),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async createBulk(
    @requestBody({
      content: {
        'application/json': {
          schema: {
            type: 'object',
            properties: {
              programId: {type: 'string'},
              coachId: {type: 'string'},
              fromCoachId: {type: 'string'},
              userSubscriptionIds: {
                type: 'array',
                items: {type: 'string'},
              },
            },
          },
        },
      },
    })
    body: {
      programId: string;
      coachId: string;
      fromCoachId?: string;
      userSubscriptionIds: string[];
    },
  ): Promise<CoachUserSubscriptions[]> {
    return this.coachUserSubscriptionsService.createBulk(body);
  }

  @get('/coach-user-subscriptions', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of CoachUserSubscriptions model instances',
        content: {
          'application/json': {
            schema: Utils.paginatedSchema(CoachUserSubscriptions, true),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findAll(
    @param.query.object('filter', getFilterSchemaFor(CoachUserSubscriptions))
    filter?: Filter<CoachUserSubscriptions>,
    @param.query.number('page') page?: number,
    @param.query.string('programId') programId?: string,
    @param.query.boolean('includeRelationships') includeRelationships?: boolean,
    @param.query.string('startDate') startDate?: string,
    @param.query.string('endDate') endDate?: string,
  ): Promise<PaginatedResponse<CoachUserSubscriptions>> {
    return this.coachUserSubscriptionsService.findAll({
      filter,
      page,
      programId,
      includeRelationships,
      startDate,
      endDate,
    });
  }

  @get('/coach-user-subscriptions/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'CoachUserSubscriptions model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(CoachUserSubscriptions, {
              includeRelations: true,
            }),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(CoachUserSubscriptions))
    filter?: Filter<CoachUserSubscriptions>,
  ) {
    return this.coachUserSubscriptionsService.findById(id, filter);
  }

  @patch('/coach-user-subscriptions/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'CoachUserSubscriptions PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(CoachUserSubscriptions, {partial: true}),
        },
      },
    })
    payload: CoachUserSubscriptions,
  ): Promise<void> {
    return await this.coachUserSubscriptionsService.updateById(id, payload);
  }

  @patch('/coach-user-subscriptions/reassign', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'CoachUserSubscriptions PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async reassignAllMembers(
    @requestBody({
      content: {
        'application/json': {
          schema: {
            type: 'object',
            properties: {
              fromCoachId: {type: 'string'},
              toCoachId: {type: 'string'},
              programId: {type: 'string'},
            },
          },
        },
      },
    })
    payload: {
      fromCoachId: string;
      toCoachId: string;
      programId: string;
    },
  ): Promise<void> {
    return await this.coachUserSubscriptionsService.reassignAllMembers(payload);
  }

  @del('/coach-user-subscriptions/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'CoachUserSubscriptions DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async unassign(@param.path.string('id') id: string): Promise<void> {
    this.coachUserSubscriptionsService.unassign(id);
  }
}
