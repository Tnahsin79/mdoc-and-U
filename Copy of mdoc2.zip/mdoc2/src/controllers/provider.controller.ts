import _ from 'lodash';
import {
  get,
  put,
  del,
  post,
  patch,
  param,
  requestBody,
  getModelSchemaRef,
  getWhereSchemaFor,
  getFilterSchemaFor,
} from '@loopback/rest';
import {
  UsersRepository,
  ProviderRepository,
  ActivityTimelineRepository,
  ProcedureSurgeriesRepository,
  HealthProcedureSurgeriesRepository,
} from '../repositories';
import {
  Count,
  Where,
  Filter,
  AnyObject,
  repository,
  CountSchema,
} from '@loopback/repository';
import {Provider} from '../models';
import {inject} from '@loopback/core';
import {activityTypeObj} from '../type-schema';
import {authenticate} from '@loopback/authentication';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';
import {UserProfile, securityId, SecurityBindings} from '@loopback/security';

export class ProviderController {
  constructor(
    @repository(ProviderRepository)
    public providerRepository: ProviderRepository,
    @repository(UsersRepository) public userRepository: UsersRepository,
    @repository(HealthProcedureSurgeriesRepository)
    public healthProcedureSurgeriesRepository: HealthProcedureSurgeriesRepository,
    @repository(ProcedureSurgeriesRepository)
    public procedureSurgeriesRepository: ProcedureSurgeriesRepository,
    @repository(ActivityTimelineRepository)
    public activityTimelineRepository: ActivityTimelineRepository,
  ) {}

  @post('/providers', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Provider model instance',
        content: {'application/json': {schema: getModelSchemaRef(Provider)}},
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Provider, {
            title: 'NewProvider',
            exclude: ['id'],
          }),
        },
      },
    })
    provider: Omit<Provider, 'id'>,
  ): Promise<Provider> {
    provider.isProviderComplete = true;
    const data = await this.providerRepository.create(provider);
    await this.activityTimelineRepository.create({
      activityType: activityTypeObj.PROVIDER,
      userId: data.userId,
      metadata: data.id,
    });
    return data;
  }

  @get('/providers/count', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Provider model count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  @authenticate('jwt')
  async count(
    @param.query.object('where', getWhereSchemaFor(Provider))
    where?: Where<Provider>,
  ): Promise<Count> {
    return this.providerRepository.count(where);
  }

  @get('/providers', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of Provider model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(Provider, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async find(
    @param.query.object('filter', getFilterSchemaFor(Provider))
    filter?: Filter<Provider>,
  ): Promise<Provider[]> {
    return this.providerRepository.find(filter);
  }

  @patch('/providers', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Provider PATCH success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  @authenticate('jwt')
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Provider, {partial: true}),
        },
      },
    })
    provider: Provider,
    @param.query.object('where', getWhereSchemaFor(Provider))
    where?: Where<Provider>,
  ): Promise<Count> {
    return this.providerRepository.updateAll(provider, where);
  }

  @get('/providers/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Provider model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Provider, {includeRelations: true}),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(Provider))
    filter?: Filter<Provider>,
  ): Promise<Provider> {
    return this.providerRepository.findById(id, filter);
  }

  @patch('/providers/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Provider PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Provider, {partial: true}),
        },
      },
    })
    provider: Provider,
  ): Promise<void> {
    await this.providerRepository.updateById(id, provider);
  }

  @put('/providers/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Provider PUT success',
      },
    },
  })
  @authenticate('jwt')
  async replaceById(
    @param.path.string('id') id: string,
    @requestBody() provider: Provider,
  ): Promise<void> {
    await this.providerRepository.replaceById(id, provider);
  }

  @del('/providers/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Provider DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.providerRepository.deleteById(id);
  }

  @get('/providers/searchProvider/', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Providers  success',
      },
    },
  })
  @authenticate('jwt')
  async searchProvider(
    @param.query.string('name') name?: string,
    @param.query.string('address') address?: string,
  ): Promise<any> {
    let query: AnyObject = {and: []};
    let responseData: Array<AnyObject> = [];
    let anyQuery: AnyObject = {and: []};

    if (name) {
      query.and.push({
        name: new RegExp('.*' + name + '.*', 'i'),
      });

      const procedurs = await this.procedureSurgeriesRepository.find({
        where: query,
      });
      if (procedurs && procedurs.length) {
        let ids = _.map(procedurs, v => v.id);
        anyQuery.and.push({
          procedureId: {inq: ids},
        });
      }
    }
    if (address) {
      query.and.push({
        or: [
          {address: new RegExp('.*' + address + '.*', 'i')},
          {city: new RegExp('.*' + address + '.*', 'i')},
        ],
      });
      anyQuery.and.push({
        or: [
          {address: new RegExp('.*' + address + '.*', 'i')},
          {city: new RegExp('.*' + address + '.*', 'i')},
        ],
      });
    }
    let quer = (anyQuery &&
      anyQuery.and &&
      anyQuery.and.length &&
      anyQuery) || {id: ''};

    const healthProcedure = await this.healthProcedureSurgeriesRepository.find({
      where: quer,
      include: [{relation: 'user'}, {relation: 'surgeryProcedure'}],
    });
    const providers = await this.providerRepository.find({
      where: query,
    });

    if (
      (providers && providers.length) ||
      (healthProcedure && healthProcedure.length)
    ) {
      let userIds: Array<any> = _.map(providers, v => v.userId);

      return Promise.all([
        this.userRepository.find({
          where: {
            id: {inq: userIds},
          },
        }),
      ])
        .then(res => {
          let users =
            res && res[0] && res[0].length && _.groupBy(res[0], v => v.id);

          _.forEach(providers, function(val: any) {
            let obj = Object.assign({}, val);
            obj.user =
              (users && users[val.userId] && users[val.userId][0]) || {};
            responseData.push(obj);
          });

          _.forEach(healthProcedure, function(val: any) {
            responseData.push(val);
          });

          return responseData;
        })
        .catch(err => {
          return err;
        });
    } else {
      return [];
    }
  }

  @get('/providers/dashboardMyProviders/', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Providers  success',
      },
    },
  })
  @authenticate('jwt')
  async dashboardMyProviders(
    @inject(SecurityBindings.USER) currentUser: UserProfile,
  ): Promise<any> {
    const myProviders = await this.providerRepository.find({
      where: {
        userId: currentUser[securityId],
      },
      order: ['created DESC'],
    });
    if (myProviders && myProviders.length) {
      return myProviders;
    } else {
      return [];
    }
  }
}
