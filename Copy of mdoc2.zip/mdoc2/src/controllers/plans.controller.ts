import { AnyObject, Count, CountSchema, Filter, repository, Where, } from '@loopback/repository';
import { post, param, get, getFilterSchemaFor, getModelSchemaRef, getWhereSchemaFor, patch, put, del, requestBody, } from '@loopback/rest';
import { Plans } from '../models';
import { PlansRepository } from '../repositories';
import * as _ from 'lodash'
import { OPERATION_SECURITY_SPEC } from '../utils/security-spec';
import { authenticate } from '@loopback/authentication';
import { inject } from '@loopback/core';
import { MigrationServiceBindings } from '../keys';
import { MigrationService } from '../services/migration.service';
import csv from 'csvtojson'
export class PlansController {
  constructor(
    @repository(PlansRepository) public plansRepository: PlansRepository,
    @inject(MigrationServiceBindings.MIGRATION_SERVICE) public migrationService: MigrationService
  ) { }

  @post('/plans', {
    responses: {
      '200': {
        description: 'Plans model instance',
        content: { 'application/json': { schema: getModelSchemaRef(Plans) } },
      },
    },
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Plans, {
            title: 'NewPlans',
            exclude: ['id'],
          }),
        },
      },
    })
    plans: Omit<Plans, 'id'>,
  ): Promise<Plans> {
    return this.plansRepository.create(plans);
  }

  @get('/plans/count', {
    responses: {
      '200': {
        description: 'Plans model count',
        content: { 'application/json': { schema: CountSchema } },
      },
    },
  })
  async count(
    @param.query.object('where', getWhereSchemaFor(Plans)) where?: Where<Plans>,
  ): Promise<Count> {
    return this.plansRepository.count(where);
  }

  @get('/plans', {
    responses: {
      '200': {
        description: 'Array of Plans model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(Plans, { includeRelations: true }),
            },
          },
        },
      },
    },
  })
  async find(
    @param.query.object('filter', getFilterSchemaFor(Plans)) filter?: Filter<Plans>,
  ): Promise<Plans[]> {
    return this.plansRepository.find(filter);
  }

  @patch('/plans', {
    responses: {
      '200': {
        description: 'Plans PATCH success count',
        content: { 'application/json': { schema: CountSchema } },
      },
    },
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Plans, { partial: true }),
        },
      },
    })
    plans: Plans,
    @param.query.object('where', getWhereSchemaFor(Plans)) where?: Where<Plans>,
  ): Promise<Count> {
    return this.plansRepository.updateAll(plans, where);
  }

  @get('/plans/{id}', {
    responses: {
      '200': {
        description: 'Plans model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Plans, { includeRelations: true }),
          },
        },
      },
    },
  })
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(Plans)) filter?: Filter<Plans>
  ): Promise<Plans> {
    return this.plansRepository.findById(id, filter);
  }

  @patch('/plans/{id}', {
    responses: {
      '204': {
        description: 'Plans PATCH success',
      },
    },
  })
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Plans, { partial: true }),
        },
      },
    })
    plans: Plans,
  ): Promise<void> {
    await this.plansRepository.updateById(id, plans);
  }

  @put('/plans/{id}', {
    responses: {
      '204': {
        description: 'Plans PUT success',
      },
    },
  })
  async replaceById(
    @param.path.string('id') id: string,
    @requestBody() plans: Plans,
  ): Promise<void> {
    await this.plansRepository.replaceById(id, plans);
  }

  @del('/plans/{id}', {
    responses: {
      '204': {
        description: 'Plans DELETE success',
      },
    },
  })
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.plansRepository.deleteById(id);
  }

  @get('/plans/getPlanList', {
    responses: {
      '200': {
        description: 'Plans  success',
      },
    },
  })
  async getPlanList(
  ): Promise<any> {
    let response: AnyObject = {}
    let result: Array<any> = await this.plansRepository.find({
      order: ['price ASC']
    })
    if (result && result.length) {
      let types = _.map(result, v => v.planType)
      let planGrp = result && result.length && _.groupBy(result, v => v.planType)
      _.forEach(types, function (val: any) {
        response[val] = planGrp && planGrp[val] && planGrp[val].length && planGrp[val] || []
      })
      return response
    }
  }

  @get('/plansMigration', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Member Migration instance',
      },
    },
  })
  @authenticate('jwt')
  async plansMigration(
  ): Promise<any> {
    const filePath = './public/subscription_types.csv'

    let planList = await csv().fromFile(filePath);
    if (planList && planList.length) {
      for (let [index, value] of planList.entries()) {
        await this.migrationService.plansMigration(value)
      }
    }
  }
}
