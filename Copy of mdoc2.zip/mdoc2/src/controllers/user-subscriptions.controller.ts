import {
  get,
  post,
  param,
  patch,
  requestBody,
  getModelSchemaRef,
  getFilterSchemaFor,
} from '@loopback/rest';
import {
  Payments,
  Programs,
  UserSubscriptions,
  UserSubscriptionsWithRelations,
  Voucher,
} from '../models';
import Utils from '../utils';
import paystack from 'paystack';
import {inject} from '@loopback/core';
import {Filter} from '@loopback/repository';
import {PaginatedResponse} from '../type-schema';
import {authenticate} from '@loopback/authentication';
import {UserSubscriptionsServiceBindings} from '../keys';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';
import {UserSubscriptionsService} from '../services/user-subscriptions.service';
import {UserProfile, securityId, SecurityBindings} from '@loopback/security';
import {PaymentTypeEnum} from '../utils/enums';

export class UserSubscriptionsController {
  constructor(
    @inject(UserSubscriptionsServiceBindings.USER_SUBSCRIPTIONS)
    public userSubscriptionService: UserSubscriptionsService,
  ) {}

  @get('/user-subscriptions', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of UserSubscriptions model instances',
        content: {
          'application/json': {
            schema: Utils.paginatedSchema(UserSubscriptions, false),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async getAllSubscriptions(
    @param.query.number('limit') limit?: number,
    @param.query.number('page') page?: number,
    @param.query.string('startDate') startDate?: string,
    @param.query.string('endDate') endDate?: string,
    @param.query.string('search') search?: string,
    @param.query.string('programId') programId?: string,
    @param.query.string('status') status?: string,
  ): Promise<PaginatedResponse<UserSubscriptionsWithRelations>> {
    return this.userSubscriptionService.getAllSubscriptions(
      limit,
      page,
      startDate,
      endDate,
      search,
      programId,
      status,
    );
  }

  @get('/user-subscriptions/user/{userId}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of UserSubscriptions model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(UserSubscriptions, {
                includeRelations: true,
              }),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async getUserSubscriptions(
    @param.path.string('userId') userId: string,
  ): Promise<UserSubscriptionsWithRelations[]> {
    return this.userSubscriptionService.getUserSubscriptions(userId);
  }

  @patch('/user-subscriptions/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'UserSubscriptions PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(UserSubscriptions, {partial: true}),
        },
      },
    })
    userSubscriptions: UserSubscriptions,
  ): Promise<void> {
    return this.userSubscriptionService.updateUserSubscription(id, userSubscriptions);
  }

  @patch('/user-subscriptions/user/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {},
    },
  })
  @authenticate('jwt')
  async updateStageOfChange(
    @requestBody({
      content: {
        'application/json': {
          schema: {
            type: 'object',
            properties: {
              changeStage: {
                type: 'string',
                enum: [
                  'precontemplation',
                  'contemplation',
                  'preparation',
                  'action',
                  'maintenance',
                ],
              },
            },
          },
        },
      },
    })
    {changeStage}: {changeStage: string},
    @param.path.string('id') id: string,
  ): Promise<void> {
    return this.userSubscriptionService.updateStageOfChange(id, changeStage);
  }

  @get('/user-subscriptions/SubscriptionPageStats', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Subscription page statistics',
        content: {
          'application/json': {
            schema: {
              type: 'object',
              properties: {
                totalActive: {type: 'number'},
                totalInactive: {type: 'number'},
                total: {type: 'number'},
              },
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async getSubscriptionPageStats(): Promise<any> {
    return this.userSubscriptionService.getSubscriptionPageStats();
  }

  @get('/user-subscriptions/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'UserSubscriptions model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(UserSubscriptions, {
              includeRelations: true,
            }),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async getSubscriptionById(
    @param.path.string('id')
    id: string,
  ): Promise<UserSubscriptionsWithRelations> {
    return this.userSubscriptionService.getSubscriptionById(id);
  }

  @post('/user-subscriptions', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'UserSubscriptions model instance',
        content: {
          'application/json': {schema: getModelSchemaRef(UserSubscriptions)},
        },
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: {
            type: 'object',
            properties: {
              paymentData: getModelSchemaRef(Payments),
            },
          },
        },
      },
    })
    {paymentData}: {paymentData: Payments},
  ): Promise<UserSubscriptions | paystack.Response> {
    return this.userSubscriptionService.recordNewSubscription(paymentData);
  }

  @post('/user-subscriptions/offline-payment', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'Voucher model instance',
        content: {
          'application/json': {schema: getModelSchemaRef(Voucher)},
        },
      },
    },
  })
  @authenticate('jwt')
  async recordOfflinePayment(
    @requestBody({
      content: {
        'application/json': {
          schema: {
            type: 'object',
            properties: {
              userId: {type: 'string'},
              programId: {type: 'string'},
              planId: {type: 'string'},
              paymentType: {type: 'string', enum: ['cash', 'POS']},
              paymentDate: {type: 'string'},
              reference: {type: 'string'},
            },
          },
        },
      },
    })
    payload: {
      programId: string;
      planId: string;
      userId: string;
      paymentType: PaymentTypeEnum;
      paymentDate: string;
      reference: string;
    },
    @inject(SecurityBindings.USER) currentUser: UserProfile,
  ): Promise<Voucher> {
    const adminId = currentUser[securityId];
    return this.userSubscriptionService.recordOfflinePayment(payload, adminId);
  }

  @get('/user-subscriptions/program-statistics', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'UserSubscriptions model instance',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  program: getModelSchemaRef(Programs),
                  totalSubscriptions: {type: 'number'},
                  totalRevenue: {type: 'number'},
                  totalCoaches: {type: 'number'},
                },
              },
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async programStatistics(@param.query.string('programIds') ids: string) {
    const programIds = ids.split(',');
    return this.userSubscriptionService.programStatistics(programIds);
  }

  @get('/user-subscriptions/without-coaches', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'UserSubscriptions model instance',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(UserSubscriptions, {
                includeRelations: true,
              }),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async getUserSubscriptionsWithoutCoaches(
    @param.query.string('programId') programId: string,
  ): Promise<UserSubscriptions[]> {
    return this.userSubscriptionService.getUserSubscriptionsWithoutCoaches(
      programId,
    );
  }

  @get('/user-subscriptions/coach/{coachId}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'UserSubscriptions model instance',
        content: {
          'application/json': {
            schema: Utils.paginatedSchema(UserSubscriptions, true),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async getCoachUserSubscription(
    @param.path.string('coachId') coachId: string,
    @param.query.string('search') search?: string,
    @param.query.number('limit') limit?: number,
    @param.query.number('page') page?: number,
    @param.query.string('startDate') startDate?: string,
    @param.query.string('endDate') endDate?: string,
    @param.query.object('filter', getFilterSchemaFor(UserSubscriptions))
    filter?: Filter<UserSubscriptions>,
  ): Promise<PaginatedResponse<UserSubscriptions>> {
    return this.userSubscriptionService.getCoachUserSubscription(
      coachId,
      search,
      filter,
      page,
      limit,
      startDate,
      endDate,
    );
  }
}
