import {
  get,
  del,
  post,
  patch,
  param,
  requestBody,
  getModelSchemaRef,
  getFilterSchemaFor,
} from '@loopback/rest';
import {Coach, Consult} from '../models';
import {inject} from '@loopback/core';
import {ConsultService} from '../services';
import {Filter} from '@loopback/repository';
import {ConsultServiceBindings, HeightServiceBindings} from '../keys';
import {PaginatedResponse} from '../type-schema';
import {authenticate} from '@loopback/authentication';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';
import Utils from '../utils';

export class ConsultController {
  constructor(
    @inject(ConsultServiceBindings.CONSULT_SERVICE)
    public consultService: ConsultService,
  ) {}

  @post('/consult', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Consult model instance',
        content: {
          'application/json': {schema: getModelSchemaRef(Consult)},
        },
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Consult, {
            title: 'NewConsult',
            exclude: ['id'],
          }),
        },
      },
    })
    consult: Omit<Consult, 'id'>,
  ): Promise<Consult> {
    return this.consultService.create(consult);
  }

  @get('/consult', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of Consult model instances',
        content: {
          'application/json': {
            schema: Utils.paginatedSchema(Consult, true),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findAll(
    @param.query.object('filter', getFilterSchemaFor(Consult))
    filter?: Filter<Consult>,
    @param.query.number('page') page?: number,
    @param.query.string('search') search?: string,
  ): Promise<PaginatedResponse<Consult>> {
    return this.consultService.findAll(filter, page, search);
  }

  @get('/consult/statistics/{coachId}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Statistics for a coach consult',
        content: {
          'application/json': {
            schema: {
              type: 'object',
              properties: {
                totalConsults: {type: 'number'},
                totalBooked: {type: 'number'},
                totalAccepted: {type: 'number'},
                totalCompleted: {type: 'number'},
              },
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async getStatistics(
    @param.path.string('coachId')
    coachId?: string,
  ): Promise<any> {
    return this.consultService.getStatistics(coachId);
  }

  @post('/consult/verify', {
    responses: {
      '200': {
        description: 'Statistics for a coach consult',
        content: {
          'application/json': {
            schema: {
              type: 'object',
              properties: {
                consult: getModelSchemaRef(Consult, {includeRelations: true}),
                accessToken: {type: 'string'},
                refreshToken: {type: 'string'},
                coach: getModelSchemaRef(Coach),
              },
            },
          },
        },
      },
    },
  })
  async verifyConsultCode(
    @param.query.string('partnerId')
    partnerId?: string,
    @param.query.string('consultId')
    consultId?: string,
    @requestBody({
      content: {
        'application/json': {
          schema: {
            type: 'object',
            properties: {
              passcode: {type: 'string'},
            },
          },
        },
      },
    })
    body?: {passcode: string},
  ): Promise<any> {
    return this.consultService.verifyConsultCode({
      passcode: body?.passcode,
      consultId,
      partnerId,
    });
  }

  @get('/consult/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Consult model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Consult, {includeRelations: true}),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(Consult))
    filter?: Filter<Consult>,
  ) {
    return this.consultService.findById(id, filter);
  }

  @patch('/consult/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Consult PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Consult, {
            partial: true,
            exclude: ['id'],
          }),
        },
      },
    })
    consult: Consult,
  ): Promise<void> {
    return await this.consultService.updateById(id, consult);
  }

  @del('/consult/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Consult DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    this.consultService.deleteById(id);
  }
}
