import {authenticate} from '@loopback/authentication';
import {inject} from '@loopback/core';
import {
  post,
  param,
  get,
  getModelSchemaRef,
  patch,
  del,
  requestBody,
  getFilterSchemaFor,
} from '@loopback/rest';
import {NoteServiceBindings} from '../keys';
import {Note, NoteWithRelations} from '../models';
import {NoteService} from '../services';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';
import {Filter} from '@loopback/repository';
import { PaginatedResponse } from '../type-schema';

export class NotesController {
  constructor(
    @inject(NoteServiceBindings.NOTES_SERVICE)
    public noteService: NoteService,
  ) {}

  @post('/notes', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'Notes model instance',
        content: {'application/json': {schema: getModelSchemaRef(Note)}},
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Note, {
            exclude: ['id'],
          }),
        },
      },
    })
    note: Omit<Note, 'id'>,
  ): Promise<Note> {
    return this.noteService.create(note);
  }

  @get('/notes/byUserId', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'Array of Notes model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(Note, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async getByUserId(
    @param.query.string('userId') userId: string,
  ): Promise<NoteWithRelations[]> {
    return this.noteService.getByUserId(userId);
  }

  @get('/notes/byCoachId', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'Array of Notes model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(Note, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async getByCoachId(
    @param.query.string('coachId') coachId: string,
    @param.query.object('filter', getFilterSchemaFor(Note))
    filter: Filter<Note>,
    @param.query.number('page') page?: number,
  ): Promise<PaginatedResponse<NoteWithRelations>> {
    const limit = filter?.limit ? filter.limit : 25;
    return this.noteService.getByCoachId(coachId, limit, page);
  }

  @get('/notes/byUserIdAndCoachId', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'Array of Notes model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(Note, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async getByUserIdAndCoachId(
    @param.query.string('userId') userId: string,
    @param.query.string('coachId') coachId: string,
  ): Promise<NoteWithRelations[]> {
    return this.noteService.getByUserIdAndCoachId(userId, coachId);
  }

  @patch('/notes/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      204: {
        description: 'Update successful',
        content: {},
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Note, {partial: true}),
        },
      },
    })
    note: Note,
    @param.path.string('id') id: string,
  ): Promise<void> {
    return this.noteService.updateById(id, note);
  }

  @del('/notes/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      204: {
        description: 'Note deleted successfully',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.noteService.deleteById(id);
  }
}
