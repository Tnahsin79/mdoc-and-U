import {
  get,
  put,
  del,
  post,
  param,
  patch,
  requestBody,
  getModelSchemaRef,
  getWhereSchemaFor,
  getFilterSchemaFor,
} from '@loopback/rest';
import {
  FootExaminationRepository,
  ActivityTimelineRepository,
} from '../repositories';
import {
  Count,
  Where,
  Filter,
  repository,
  CountSchema,
} from '@loopback/repository';
import {inject} from '@loopback/core';
import {FootExamination} from '../models';
import {activityTypeObj} from '../type-schema';
import {authenticate} from '@loopback/authentication';
import {FootExaminationServiceBindings} from '../keys';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';
import {FootExaminationService} from '../services/foot-examination.service';
import {UserProfile, securityId, SecurityBindings} from '@loopback/security';
export class FootExaminationController {
  constructor(
    @repository(FootExaminationRepository)
    public footExaminationRepository: FootExaminationRepository,
    @repository(ActivityTimelineRepository)
    public activityTimelineRepository: ActivityTimelineRepository,
    @inject(FootExaminationServiceBindings.FOOT_EXAMINATION_SERVICE)
    public footExaminationService: FootExaminationService,
  ) {}

  @post('/foot-examinations', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'FootExamination model instance',
        content: {
          'application/json': {schema: getModelSchemaRef(FootExamination)},
        },
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(FootExamination, {
            title: 'NewFootExamination',
            exclude: ['id'],
          }),
        },
      },
    })
    footExamination: Omit<FootExamination, 'id'>,
  ): Promise<FootExamination> {
    footExamination.isFootExaminationComplete = true;
    const data = await this.footExaminationRepository.create(footExamination);
    await this.activityTimelineRepository.create({
      activityType: activityTypeObj.FOOT_EXAM,
      userId: data.userId,
      metadata: data.id,
    });
    return data;
  }

  @get('/foot-examinations/count', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'FootExamination model count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  @authenticate('jwt')
  async count(
    @param.query.object('where', getWhereSchemaFor(FootExamination))
    where?: Where<FootExamination>,
  ): Promise<Count> {
    return this.footExaminationRepository.count(where);
  }

  @get('/foot-examinations', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of FootExamination model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(FootExamination, {
                includeRelations: true,
              }),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async find(
    @param.query.object('filter', getFilterSchemaFor(FootExamination))
    filter?: Filter<FootExamination>,
    @param.query.number('page') page?: number,
  ): Promise<FootExamination[]> {
    const limit = filter?.limit ? filter?.limit : 25;
    const pageNum = page ? page : 1;
    const skip = (pageNum - 1) * limit;
    return this.footExaminationRepository.find({
      ...filter,
      order: ['created DESC'],
      skip: skip,
      limit: limit,
    });
  }

  @patch('/foot-examinations', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'FootExamination PATCH success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  @authenticate('jwt')
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(FootExamination, {partial: true}),
        },
      },
    })
    footExamination: FootExamination,
    @param.query.object('where', getWhereSchemaFor(FootExamination))
    where?: Where<FootExamination>,
  ): Promise<Count> {
    return this.footExaminationRepository.updateAll(footExamination, where);
  }

  @get('/foot-examinations/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'FootExamination model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(FootExamination, {
              includeRelations: true,
            }),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(FootExamination))
    filter?: Filter<FootExamination>,
  ): Promise<FootExamination> {
    return this.footExaminationRepository.findById(id, filter);
  }

  @patch('/foot-examinations/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'FootExamination PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(FootExamination, {partial: true}),
        },
      },
    })
    footExamination: FootExamination,
  ): Promise<void> {
    await this.footExaminationRepository.updateById(id, footExamination);
  }

  @put('/foot-examinations/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'FootExamination PUT success',
      },
    },
  })
  @authenticate('jwt')
  async replaceById(
    @param.path.string('id') id: string,
    @requestBody() footExamination: FootExamination,
  ): Promise<void> {
    await this.footExaminationRepository.replaceById(id, footExamination);
  }

  @del('/foot-examinations/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'FootExamination DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.footExaminationRepository.deleteById(id);
  }
  @get('/foot-examinations/dashboardFootExamination/', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'FootExamination  success',
      },
    },
  })
  @authenticate('jwt')
  async dashboardFootExamination(
    @inject(SecurityBindings.USER) currentUser: UserProfile,
  ): Promise<any> {
    const footCondition = await this.footExaminationRepository.find({
      where: {
        userId: currentUser[securityId],
      },
      order: ['created DESC'],
    });
    if (footCondition && footCondition.length) {
      return footCondition;
    } else {
      return [];
    }
  }
}
