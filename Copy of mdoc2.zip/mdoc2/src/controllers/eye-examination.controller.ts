import {
  get,
  put,
  del,
  post,
  param,
  patch,
  requestBody,
  getModelSchemaRef,
  getWhereSchemaFor,
  getFilterSchemaFor,
} from '@loopback/rest';
import {
  EyeExaminationRepository,
  ActivityTimelineRepository,
} from '../repositories';
import {
  Count,
  Where,
  Filter,
  repository,
  CountSchema,
} from '@loopback/repository';
import {inject} from '@loopback/core';
import {EyeExamination} from '../models';
import {activityTypeObj} from '../type-schema';
import {authenticate} from '@loopback/authentication';
import {EyeExaminationServiceBindings} from '../keys';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';
import {EyeExaminationService} from '../services/eye-examination.service';
import {UserProfile, securityId, SecurityBindings} from '@loopback/security';
export class EyeExaminationController {
  constructor(
    @repository(EyeExaminationRepository)
    public eyeExaminationRepository: EyeExaminationRepository,
    @repository(ActivityTimelineRepository)
    public activityTimelineRepository: ActivityTimelineRepository,
    @inject(EyeExaminationServiceBindings.EYE_EXAMINATION_SERVICE)
    public eyeExaminationService: EyeExaminationService,
  ) {}

  @post('/eye-examinations', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'EyeExamination model instance',
        content: {
          'application/json': {schema: getModelSchemaRef(EyeExamination)},
        },
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(EyeExamination, {
            title: 'NewEyeExamination',
            exclude: ['id'],
          }),
        },
      },
    })
    eyeExamination: Omit<EyeExamination, 'id'>,
  ): Promise<EyeExamination> {
    eyeExamination.isEyeExaminationComplete = true;
    const data = await this.eyeExaminationRepository.create(eyeExamination);
    await this.activityTimelineRepository.create({
      activityType: activityTypeObj.EYE_EXAM,
      userId: data.userId,
      metadata: data.id,
    });
    return data;
  }

  @get('/eye-examinations/count', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'EyeExamination model count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  @authenticate('jwt')
  async count(
    @param.query.object('where', getWhereSchemaFor(EyeExamination))
    where?: Where<EyeExamination>,
  ): Promise<Count> {
    return this.eyeExaminationRepository.count(where);
  }

  @get('/eye-examinations', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of EyeExamination model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(EyeExamination, {
                includeRelations: true,
              }),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async find(
    @param.query.object('filter', getFilterSchemaFor(EyeExamination))
    filter?: Filter<EyeExamination>,
    @param.query.number('page') page?: number,
  ): Promise<EyeExamination[]> {
    const limit = filter?.limit ? filter?.limit : 25;
    const pageNum = page ? page : 1;
    const skip = (pageNum - 1) * limit;
    return this.eyeExaminationRepository.find({
      ...filter,
      order: ['created DESC'],
      skip: skip,
      limit: limit,
    });
  }

  @patch('/eye-examinations', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'EyeExamination PATCH success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  @authenticate('jwt')
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(EyeExamination, {partial: true}),
        },
      },
    })
    eyeExamination: EyeExamination,
    @param.query.object('where', getWhereSchemaFor(EyeExamination))
    where?: Where<EyeExamination>,
  ): Promise<Count> {
    return this.eyeExaminationRepository.updateAll(eyeExamination, where);
  }

  @get('/eye-examinations/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'EyeExamination model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(EyeExamination, {includeRelations: true}),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(EyeExamination))
    filter?: Filter<EyeExamination>,
  ): Promise<EyeExamination> {
    return this.eyeExaminationRepository.findById(id, filter);
  }

  @patch('/eye-examinations/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'EyeExamination PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(EyeExamination, {partial: true}),
        },
      },
    })
    eyeExamination: EyeExamination,
  ): Promise<void> {
    await this.eyeExaminationRepository.updateById(id, eyeExamination);
  }

  @put('/eye-examinations/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'EyeExamination PUT success',
      },
    },
  })
  @authenticate('jwt')
  async replaceById(
    @param.path.string('id') id: string,
    @requestBody() eyeExamination: EyeExamination,
  ): Promise<void> {
    await this.eyeExaminationRepository.replaceById(id, eyeExamination);
  }

  @del('/eye-examinations/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'EyeExamination DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.eyeExaminationRepository.deleteById(id);
  }

  @get('/eye-examinations/dashboardEyeExamination/', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'EyeExamination  success',
      },
    },
  })
  @authenticate('jwt')
  async dashboardEyeExamination(
    @inject(SecurityBindings.USER) currentUser: UserProfile,
  ): Promise<any> {
    const eyeCondition = await this.eyeExaminationRepository.find({
      where: {
        userId: currentUser[securityId],
      },
      order: ['created DESC'],
    });
    if (eyeCondition && eyeCondition.length) {
      return eyeCondition;
    } else {
      return [];
    }
  }
}
