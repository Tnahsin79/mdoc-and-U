import {
  post,
  param,
  get,
  getFilterSchemaFor,
  getModelSchemaRef,
  getWhereSchemaFor,
  patch,
  put,
  del,
  requestBody,
} from '@loopback/rest';
import {
  Count,
  CountSchema,
  Filter,
  repository,
  Where,
  AnyObject,
} from '@loopback/repository';
import {Category} from '../models';
import {
  CategoryRepository,
  UsersRepository,
  ResourcesRepository,
  InterestRepository,
  BlogPostRepository,
} from '../repositories';
import csv from 'csvtojson';
import * as _ from 'lodash';
import {inject} from '@loopback/core';
import {CategoryService} from '../services/category.service';
import {MigrationService} from '../services/migration.service';
import {CategoryServiceBindings, MigrationServiceBindings} from '../keys';
export class CategoryController {
  constructor(
    @repository(CategoryRepository)
    public categoryRepository: CategoryRepository,
    @repository(UsersRepository) public usersRepository: UsersRepository,
    @repository(ResourcesRepository)
    public resourceRepository: ResourcesRepository,
    @repository(InterestRepository)
    public interestRepository: InterestRepository,
    @repository(BlogPostRepository)
    public blogPostRepository: BlogPostRepository,
    @inject(MigrationServiceBindings.MIGRATION_SERVICE)
    public migrationService: MigrationService,
    @inject(CategoryServiceBindings.CATEGORY_SERVICE)
    public categoryService: CategoryService,
  ) {}

  @post('/categories', {
    responses: {
      '200': {
        description: 'Category model instance',
        content: {'application/json': {schema: getModelSchemaRef(Category)}},
      },
    },
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Category, {
            title: 'NewCategory',
            exclude: ['id'],
          }),
        },
      },
    })
    category: Omit<Category, 'id'>,
  ): Promise<Category> {
    return this.categoryRepository.create(category);
  }

  @get('/categories/count', {
    responses: {
      '200': {
        description: 'Category model count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async count(
    @param.query.object('where', getWhereSchemaFor(Category))
    where?: Where<Category>,
  ): Promise<Count> {
    return this.categoryRepository.count(where);
  }

  @get('/categories', {
    responses: {
      '200': {
        description: 'Array of Category model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(Category, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  async find(
    @param.query.object('filter', getFilterSchemaFor(Category))
    filter?: Filter<Category>,
  ): Promise<Category[]> {
    return this.categoryRepository.find(filter);
  }

  @patch('/categories', {
    responses: {
      '200': {
        description: 'Category PATCH success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Category, {partial: true}),
        },
      },
    })
    category: Category,
    @param.query.object('where', getWhereSchemaFor(Category))
    where?: Where<Category>,
  ): Promise<Count> {
    return this.categoryRepository.updateAll(category, where);
  }

  @get('/categories/{id}', {
    responses: {
      '200': {
        description: 'Category model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Category, {includeRelations: true}),
          },
        },
      },
    },
  })
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(Category))
    filter?: Filter<Category>,
  ): Promise<Category> {
    return this.categoryRepository.findById(id, filter);
  }

  @patch('/categories/{id}', {
    responses: {
      '204': {
        description: 'Category PATCH success',
      },
    },
  })
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Category, {partial: true}),
        },
      },
    })
    category: Category,
  ): Promise<void> {
    await this.categoryRepository.updateById(id, category);
  }

  @put('/categories/{id}', {
    responses: {
      '204': {
        description: 'Category PUT success',
      },
    },
  })
  async replaceById(
    @param.path.string('id') id: string,
    @requestBody() category: Category,
  ): Promise<void> {
    await this.categoryRepository.replaceById(id, category);
  }

  @del('/categories/{id}', {
    responses: {
      '204': {
        description: 'Category DELETE success',
      },
    },
  })
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.categoryRepository.deleteById(id);
  }

  @post('/categories/getCategoryList', {
    responses: {
      '200': {
        description: 'Category Response success',
      },
    },
  })
  async getCategoryList(@requestBody() data: any): Promise<any> {
    let query: AnyObject = {and: []};
    let responseData: Array<AnyObject> = [];
    query.and.push({
      name: {neq: ''},
    });
    if (data && data.category) {
      query.and.push({
        name: new RegExp('.*' + data.category + '.*', 'i'),
      });
    }
    let categories = await this.interestRepository.find({
      where: query,
    });
    // if (categories && categories.length) {
    //   let categoryId: Array<any> = _.map(categories, v => v.id);

    //   return Promise.all([
    //     this.blogPostRepository.find({
    //       where: {
    //         interestId: {inq: categoryId},
    //       },
    //       fields: {id: true, title: true, interestId: true},
    //     }),
    //   ]).then(res => {
    //     // let resource = res && res[0] && res[0].length && _.groupBy(res[0], v => v.interestId)
    //     _.forEach(categories, function(val: any, index) {
    //       let obj = Object.assign({}, val);
    //       // obj.resources = resource && resource[val.id] && resource[val.id].length || 0
    //       obj.resources = 0;
    //       obj.followers = index + 3 * 5 || 0;
    //       responseData.push(obj);
    //     });
    //     return responseData;
    //   });
    // }
  }

  @get('/categoryMigration', {
    responses: {
      '200': {
        description: 'Category  success',
      },
    },
  })
  async categoryMigration(): Promise<any> {
    const filePath = './public/category.csv';
    let categories = await csv().fromFile(filePath);
    if (categories && categories.length) {
      for (let value of categories) {
        await this.migrationService.categoryMigration(value);
      }
    }
  }
}
