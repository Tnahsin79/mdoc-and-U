import { authenticate } from "@loopback/authentication";
import { inject } from "@loopback/core";
import {
  post,
  param,
  get,
  getModelSchemaRef,
  patch,
  requestBody,
  getFilterSchemaFor,
} from "@loopback/rest";
import { Career, CareerWithRelations } from "../models";
import { CareerService } from "../services";
import { OPERATION_SECURITY_SPEC } from "../utils/security-spec";
import { Filter } from "@loopback/repository";
import { PaginatedResponse } from "../type-schema";
import { UserProfile, SecurityBindings } from "@loopback/security";
import { CareerServiceBindings } from "../keys";
import Utils from "../utils";

export class CareerController {
  constructor(
    @inject(CareerServiceBindings.CAREER_SERVICE)
    public careerService: CareerService
  ) {}

  @post("/careers", {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      201: {
        description: "Notes model instance",
        content: { "application/json": { schema: getModelSchemaRef(Career) } },
      },
    },
  })
  @authenticate("jwt")
  async create(
    @inject(SecurityBindings.USER) currentUser: UserProfile,
    @requestBody({
      content: {
        "application/json": {
          schema: getModelSchemaRef(Career, {
            exclude: ["id"],
          }),
        },
      },
    })
    job: Omit<Career, "id">
  ): Promise<Career> {
    return this.careerService.create(job, currentUser);
  }

  @get("/careers", {
    responses: {
      200: {
        description: "Array of Career model instances",
        content: {
          "application/json": {
            schema: Utils.paginatedSchema(Career, true),
          },
        },
      },
    },
  })
  async find(
    @param.query.object("filter", getFilterSchemaFor(Career))
    filter: Filter<Career>,
    @param.query.number("page") page?: number,
    @param.query.string("search") search?: string
  ): Promise<PaginatedResponse<Career>> {
    return this.careerService.find(filter, page, search);
  }

  @get("/careers/{id}", {
    responses: {
      "200": {
        description: "Career model instance",
        content: {
          "application/json": {
            schema: getModelSchemaRef(Career, { includeRelations: true }),
          },
        },
      },
    },
  })
  async findById(
    @param.path.string("id") id: string,
    @param.query.object("filter", getFilterSchemaFor(Career))
    filter?: Filter<Career>
  ) {
    return this.careerService.findById(id, filter);
  }

  @patch("/careers/{id}", {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      204: {
        description: "Career PATCH success",
      },
    },
  })
  @authenticate("jwt")
  async updateById(
    @param.path.string("id") id: string,
    @requestBody({
      content: {
        "application/json": {
          schema: getModelSchemaRef(Career, { partial: true }),
        },
      },
    })
    job: Partial<Career>
  ): Promise<void> {
    await this.careerService.updateById(id, job);
  }

  @get('/careers/statistics', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Career model count',
        content: {'application/json': {schema: {
          type: 'object',
          properties: {
            allJobs: {type: 'number'},
            ongoingJobs: {type: 'number'},
            draftJobs: {type: 'number'},
            closedJobs: {type: 'number'},
          },
        }}},
      },
    },
  })
  @authenticate('jwt')
  async statistics(): Promise<any> {
    return await this.careerService.statistics();
  }
}
