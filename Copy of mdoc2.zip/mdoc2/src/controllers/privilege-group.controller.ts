import {Filter, repository} from '@loopback/repository';
import {PrivilegeGroupRepository} from '../repositories';
import {inject} from '@loopback/context';
import {PrivilegeGroupServiceBindings} from '../keys';
import {
  del,
  get,
  getFilterSchemaFor,
  getModelSchemaRef,
  param,
  patch,
  post,
  requestBody,
} from '@loopback/openapi-v3';
import {PrivilegeGroup} from '../models';
import {authenticate} from '@loopback/authentication';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';
import {PrivilegeGroupService} from '../services';

export class PrivilegeGroupController {
  constructor(
    @repository(PrivilegeGroupRepository)
    public privilegeGroupRepository: PrivilegeGroupRepository,
    @inject(PrivilegeGroupServiceBindings.PRIVILEGE_GROUP_SERVICE)
    public privilegeGroupService: PrivilegeGroupService,
  ) {}

  @post('/privilege-groups', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '201': {
        description: 'PrivilegeGroup model instance',
        content: {
          'application/json': {schema: getModelSchemaRef(PrivilegeGroup)},
        },
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(PrivilegeGroup, {
            title: 'NewPrivilegeGroup',
            exclude: ['id'],
          }),
        },
      },
    })
    privilegeGroup: Omit<PrivilegeGroup, 'id'>,
  ): Promise<PrivilegeGroup> {
    return this.privilegeGroupRepository.create(privilegeGroup);
  }

  @patch('/privilege-groups/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'PrivilegeGroup PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(PrivilegeGroup, {
            partial: true,
            exclude: ['id'],
          }),
        },
      },
    })
    privilegeGroup: PrivilegeGroup,
  ): Promise<void> {
    await this.privilegeGroupRepository.updateById(id, privilegeGroup);
  }

  @get('/privilege-groups', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of PrivilegeGroup model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(PrivilegeGroup, {
                includeRelations: true,
              }),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async find(
    @param.query.object('filter', getFilterSchemaFor(PrivilegeGroup))
    filter?: Filter<PrivilegeGroup>,
  ): Promise<PrivilegeGroup[]> {
    return this.privilegeGroupRepository.find({
      ...(filter || {}),
      include: [{relation: 'privileges'}],
    });
  }

  @get('/privilege-groups/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'PrivilegeGroup model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(PrivilegeGroup, {includeRelations: true}),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(PrivilegeGroup))
    filter?: Filter<PrivilegeGroup>,
  ): Promise<PrivilegeGroup> {
    return this.privilegeGroupRepository.findById(id, filter);
  }

  @del('/privilege-groups/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'PrivilegeGroup DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.privilegeGroupService.deletePrivilegesByPrivilegeGroupId(id);
    await this.privilegeGroupRepository.deleteById(id);
  }
}
