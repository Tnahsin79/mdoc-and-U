import { Count, CountSchema, Filter, repository, Where, AnyObject, } from '@loopback/repository';
import { post, param, get, getFilterSchemaFor, getModelSchemaRef, getWhereSchemaFor, patch, put, del, requestBody, } from '@loopback/rest';
import { Symptoms } from '../models';
import { SymptomsRepository, SymptomHealthConditionRepository } from '../repositories';
import { OPERATION_SECURITY_SPEC } from '../utils/security-spec';
import { authenticate } from '@loopback/authentication';
import { inject } from '@loopback/core';
import { UserProfile, securityId, SecurityBindings } from '@loopback/security';
import * as _ from 'lodash'
import { SymptomsServiceBindings } from '../keys';
import { SymptomsService } from '../services/symptoms.service';
export class SymptomsController {
  constructor(
    @repository(SymptomsRepository) public symptomsRepository: SymptomsRepository,
    @repository(SymptomHealthConditionRepository) public symptomHealthConditionRepository: SymptomHealthConditionRepository,
    @inject(SymptomsServiceBindings.SYMPTOMS_SERVICE) public symptomsService: SymptomsService,
  ) { }

  @post('/symptoms', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Symptoms model instance',
        content: { 'application/json': { schema: getModelSchemaRef(Symptoms) } },
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Symptoms, {
            title: 'NewSymptoms',
            exclude: ['id'],
          }),
        },
      },
    })
    symptoms: Omit<Symptoms, 'id'>,
  ): Promise<Symptoms> {
    return this.symptomsRepository.create(symptoms);
  }

  @get('/symptoms/count', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Symptoms model count',
        content: { 'application/json': { schema: CountSchema } },
      },
    },
  })
  @authenticate('jwt')
  async count(
    @param.query.object('where', getWhereSchemaFor(Symptoms)) where?: Where<Symptoms>,
  ): Promise<Count> {
    return this.symptomsRepository.count(where);
  }

  @get('/symptoms', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of Symptoms model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(Symptoms, { includeRelations: true }),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async find(
    @param.query.object('filter', getFilterSchemaFor(Symptoms))
    filter?: Filter<Symptoms>,
    @param.query.number('page') page?: number,
  ): Promise<Symptoms[] | any> {
    return this.symptomsService.find(filter, page);
  }

  @patch('/symptoms', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Symptoms PATCH success count',
        content: { 'application/json': { schema: CountSchema } },
      },
    },
  })
  @authenticate('jwt')
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Symptoms, { partial: true }),
        },
      },
    })
    symptoms: Symptoms,
    @param.query.object('where', getWhereSchemaFor(Symptoms)) where?: Where<Symptoms>,
  ): Promise<Count> {
    return this.symptomsRepository.updateAll(symptoms, where);
  }

  @get('/symptoms/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Symptoms model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Symptoms, { includeRelations: true }),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(Symptoms)) filter?: Filter<Symptoms>
  ): Promise<Symptoms> {
    return this.symptomsRepository.findById(id, filter);
  }

  @patch('/symptoms/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Symptoms PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Symptoms, { partial: true }),
        },
      },
    })
    symptoms: Symptoms,
  ): Promise<void> {
    await this.symptomsRepository.updateById(id, symptoms);
  }

  @put('/symptoms/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Symptoms PUT success',
      },
    },
  })
  @authenticate('jwt')
  async replaceById(
    @param.path.string('id') id: string,
    @requestBody() symptoms: Symptoms,
  ): Promise<void> {
    await this.symptomsRepository.replaceById(id, symptoms);
  }

  @del('/symptoms/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Symptoms DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.symptomsRepository.deleteById(id);
  }
  @get('/symptoms/getUserSymptoms/', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Symptoms  success',
      },
    },
  })
  @authenticate('jwt')
  async getUserSymptoms(
    @inject(SecurityBindings.USER) currentUser: UserProfile,
  ): Promise<any> {
    // let responseData: Array<AnyObject> = []
    // const symptomsData = await this.symptomsRepository.find({
    //   where: {
    //     userId: currentUser[securityId]
    //   },
    //   include: [
    //     { relation: "symptom" }
    //   ],
    //   order: ['symptomDate DESC']
    // })
    
    // if (symptomsData && symptomsData.length) {
    //   let medicationIds: Array<any> = _.map(symptomsData, v => v.healthMedicationId)
    //   const healths = await this.symptomHealthConditionRepository.find({
    //     where: {
    //       id: { inq: medicationIds }
    //     }, order: ['created DESC']
    //   })
    //   let healthData = healths && healths.length && _.groupBy(healths, v => v.id)

    //   _.forEach(symptomsData, function (val: any) {
    //     let obj = Object.assign({}, val)
    //     obj.healthCondition = healthData && healthData[val.healthMedicationId] && healthData[val.healthMedicationId][0] || {}
    //     responseData.push(obj)
    //   })

    //   return responseData
    // } else {
    //   return []
    // }
  }
}
