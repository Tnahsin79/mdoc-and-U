import {
  get,
  del,
  post,
  param,
  patch,
  requestBody,
  getModelSchemaRef,
  getFilterSchemaFor,
} from '@loopback/rest';
import Utils from '../utils';
import {GoalLogs} from '../models';
import {inject} from '@loopback/core';
import {Filter} from '@loopback/repository';
import {GoalLogsService} from '../services';
import {GoalLogsServiceBindings} from '../keys';
import {PaginatedResponse} from '../type-schema';
import {authenticate} from '@loopback/authentication';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';

export class GoalLogsController {
  constructor(
    @inject(GoalLogsServiceBindings.GOAL_LOGS_SERVICE)
    public goalLogsService: GoalLogsService,
  ) {}

  @post('/goal-logs', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'GoalLogs model instance',
        content: {'application/json': {schema: getModelSchemaRef(GoalLogs)}},
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(GoalLogs, {
            title: 'NewGoalLogs',
            exclude: ['id'],
          }),
        },
      },
    })
    goalLogs: Omit<GoalLogs, 'id'>,
  ): Promise<GoalLogs> {
    return this.goalLogsService.create(goalLogs);
  }

  @get('/goal-logs', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'Array of GoalLogs model instances',
        content: {
          'application/json': {
            schema: Utils.paginatedSchema(GoalLogs, true),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async find(
    @param.query.object('filter') filter?: Filter<GoalLogs>,
    @param.query.number('page') page?: number,
  ): Promise<PaginatedResponse<GoalLogs>> {
    return this.goalLogsService.find(filter, page);
  }

  @get('/goal-logs/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'GoalLogs model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(GoalLogs, {includeRelations: true}),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(GoalLogs))
    filter?: Filter<GoalLogs>,
  ): Promise<GoalLogs> {
    return this.goalLogsService.findById(id, filter);
  }

  @patch('/goal-logs/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      204: {
        description: 'GoalLogss PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(GoalLogs, {
            partial: true,
            exclude: ['id', 'created_at'],
          }),
        },
      },
    })
    goalLogs: GoalLogs,
  ): Promise<void> {
    await this.goalLogsService.updateById(id, goalLogs);
  }

  @del('/goal-logs/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      204: {
        description: 'GoalLogss DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.goalLogsService.deleteById(id);
  }
}
