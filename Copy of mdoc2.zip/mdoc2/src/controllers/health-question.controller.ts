import { Count, CountSchema, Filter, repository, Where, AnyObject, } from '@loopback/repository';
import { post, param, get, getFilterSchemaFor, getModelSchemaRef, getWhereSchemaFor, patch, put, del, requestBody, } from '@loopback/rest';
import { HealthQuestion } from '../models';
import { HealthQuestionRepository, BasicHealthInformationRepository, PregnancyRepository } from '../repositories';
import { OPERATION_SECURITY_SPEC } from '../utils/security-spec';
import { authenticate } from '@loopback/authentication';
import { inject } from '@loopback/core';
import { UserProfile, securityId, SecurityBindings } from '@loopback/security';
import _ from 'lodash'

export class HealthQuestionController {
  constructor(
    @repository(HealthQuestionRepository) public healthQuestionRepository: HealthQuestionRepository,
    @repository(BasicHealthInformationRepository) public basicHealthInformationRepository: BasicHealthInformationRepository,
    @repository(PregnancyRepository) public pregnancyRepository: PregnancyRepository
  ) { }

  @post('/health-questions', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'HealthQuestion model instance',
        content: { 'application/json': { schema: getModelSchemaRef(HealthQuestion) } },
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(HealthQuestion, {
            title: 'NewHealthQuestion',
            exclude: ['id'],
          }),
        },
      },
    })
    healthQuestion: Omit<HealthQuestion, 'id'>,
  ): Promise<HealthQuestion> {
    return this.healthQuestionRepository.create(healthQuestion);
  }

  @get('/health-questions/count', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'HealthQuestion model count',
        content: { 'application/json': { schema: CountSchema } },
      },
    },
  })
  @authenticate('jwt')
  async count(
    @param.query.object('where', getWhereSchemaFor(HealthQuestion)) where?: Where<HealthQuestion>,
  ): Promise<Count> {
    return this.healthQuestionRepository.count(where);
  }

  @get('/health-questions', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of HealthQuestion model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(HealthQuestion, { includeRelations: true }),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async find(
    @param.query.object('filter', getFilterSchemaFor(HealthQuestion)) filter?: Filter<HealthQuestion>,
  ): Promise<HealthQuestion[]> {
    return this.healthQuestionRepository.find(filter);
  }

  @patch('/health-questions', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'HealthQuestion PATCH success count',
        content: { 'application/json': { schema: CountSchema } },
      },
    },
  })
  @authenticate('jwt')
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(HealthQuestion, { partial: true }),
        },
      },
    })
    healthQuestion: HealthQuestion,
    @param.query.object('where', getWhereSchemaFor(HealthQuestion)) where?: Where<HealthQuestion>,
  ): Promise<Count> {
    return this.healthQuestionRepository.updateAll(healthQuestion, where);
  }

  @get('/health-questions/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'HealthQuestion model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(HealthQuestion, { includeRelations: true }),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(HealthQuestion)) filter?: Filter<HealthQuestion>
  ): Promise<HealthQuestion> {
    return this.healthQuestionRepository.findById(id, filter);
  }

  @patch('/health-questions/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'HealthQuestion PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(HealthQuestion, { partial: true }),
        },
      },
    })
    healthQuestion: HealthQuestion,
  ): Promise<void> {
    await this.healthQuestionRepository.updateById(id, healthQuestion);
  }

  @put('/health-questions/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'HealthQuestion PUT success',
      },
    },
  })
  @authenticate('jwt')
  async replaceById(
    @param.path.string('id') id: string,
    @requestBody() healthQuestion: HealthQuestion,
  ): Promise<void> {
    await this.healthQuestionRepository.replaceById(id, healthQuestion);
  }

  @del('/health-questions/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'HealthQuestion DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.healthQuestionRepository.deleteById(id);
  }

  @get('/health-questions/getBasicHealthQuestions/', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'HealthQuestion  success',
      },
    },
  })
  @authenticate('jwt')
  async getBasicHealthQuestions(
    @inject(SecurityBindings.USER) currentUser: UserProfile,
  ): Promise<any> {
    let responseData: Array<AnyObject> = []
    const healthQuestion = await this.healthQuestionRepository.find({
      where: {
        type: 'basicHealth'
      }, order: ['modified ASC']
    })
    if (healthQuestion && healthQuestion.length) {
      const questionAnswer = await this.basicHealthInformationRepository.findOne({
        where: {
          userId: currentUser[securityId]
        }
      })
      if (questionAnswer && questionAnswer.id) {

        let questionArray: Array<any> = questionAnswer && questionAnswer.questionId || []
        let answerArray: Array<any> = questionAnswer && questionAnswer.answer || []

        _.forEach(healthQuestion, function (val: any) {
          let obj = Object.assign({}, val)

          _.forEach(questionArray, function (vl: any, index) {
            if (String(val.id) === String(vl)) {
              obj.answer = answerArray && answerArray[index] || ""
              obj.answerId = questionAnswer && questionAnswer.id || ""
              responseData.push(obj)
            }
          })

        })
        return responseData;
      } else {

        return healthQuestion;
      }
    } else {

      return []
    }
  }

  @get('/health-questions/getPregnancyQuestions/', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'HealthQuestion  success',
      },
    },
  })
  @authenticate('jwt')
  async getPregnancyQuestions(
    @inject(SecurityBindings.USER) currentUser: UserProfile,
  ): Promise<any> {
    let responseData: Array<AnyObject> = []
    const healthQuestion = await this.healthQuestionRepository.find({
      where: {
        type: 'pregnancy'
      }
    })

    if (healthQuestion && healthQuestion.length) {

      const questionAnswer = await this.pregnancyRepository.findOne({
        where: {
          userId: currentUser[securityId]
        },order:['created DESC']
      })

      if (questionAnswer && questionAnswer.questionId && questionAnswer.questionId.length) {

        let questionArray: Array<any> = questionAnswer && questionAnswer.questionId || []
        let answerArray: Array<any> = questionAnswer && questionAnswer.answer || []

        _.forEach(healthQuestion, function (val: any) {
          let obj = Object.assign({}, val)

          _.forEach(questionArray, function (vl: any, index) {

            if (String(val.id) === String(vl)) {
              obj.answer = answerArray && answerArray[index] || ""
              obj.answerId = questionAnswer && questionAnswer.id || ""
              responseData.push(obj)
            }
          })
        })
        return responseData;
      } else {
        return healthQuestion;
      }
    } else {

      return []
    }
  }
}
