import _ from 'lodash';
import {
  post,
  param,
  get,
  getFilterSchemaFor,
  getModelSchemaRef,
  getWhereSchemaFor,
  patch,
  put,
  del,
  requestBody,
} from '@loopback/rest';
import {
  Count,
  CountSchema,
  Filter,
  repository,
  Where,
  AnyObject,
} from '@loopback/repository';
import {
  BasicHealthInformationRepository,
  HealthQuestionRepository,
  UsersRepository,
} from '../repositories';
import {inject} from '@loopback/core';
import {BasicHealthInformation} from '../models';
import {authenticate} from '@loopback/authentication';
import {BasicHealthInformationServiceBindings} from '../keys';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';
import {UserProfile, securityId, SecurityBindings} from '@loopback/security';
import {BasicHealthInformationService} from '../services/basic-health-information.service';
export class BasicHealthInformationController {
  constructor(
    @repository(BasicHealthInformationRepository)
    public basicHealthInformationRepository: BasicHealthInformationRepository,
    @repository(HealthQuestionRepository)
    public healthQuestionRepository: HealthQuestionRepository,
    @repository(UsersRepository) public usersRepository: UsersRepository,
    @inject(
      BasicHealthInformationServiceBindings.BASIC_HEALTH_INFORMATION_SERVICE,
    )
    public basicHealthInformationService: BasicHealthInformationService,
  ) {}

  @post('/basic-health-informations', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'BasicHealthInformation model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(BasicHealthInformation),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(BasicHealthInformation, {
            title: 'NewBasicHealthInformation',
            exclude: ['id'],
          }),
        },
      },
    })
    basicHealthInformation: Omit<BasicHealthInformation, 'id'>,
  ): Promise<any> {
    let basicHealth = await this.basicHealthInformationRepository.create(
      basicHealthInformation,
    );
    let updateUser = {
      basicHealthComplete: true,
    };
    if (basicHealth && basicHealth.userId) {
      await this.usersRepository.updateById(basicHealth.userId, updateUser);
      return basicHealth;
    }
  }

  @get('/basic-health-informations/count', {
    responses: {
      '200': {
        description: 'BasicHealthInformation model count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async count(
    @param.query.object('where', getWhereSchemaFor(BasicHealthInformation))
    where?: Where<BasicHealthInformation>,
  ): Promise<Count> {
    return this.basicHealthInformationRepository.count(where);
  }

  @get('/basic-health-informations', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of BasicHealthInformation model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(BasicHealthInformation, {
                includeRelations: true,
              }),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async find(
    @param.query.object('filter', getFilterSchemaFor(BasicHealthInformation))
    filter?: Filter<BasicHealthInformation>,
  ): Promise<BasicHealthInformation[]> {
    return this.basicHealthInformationRepository.find(filter);
  }

  @patch('/basic-health-informations', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'BasicHealthInformation PATCH success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  @authenticate('jwt')
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(BasicHealthInformation, {partial: true}),
        },
      },
    })
    basicHealthInformation: BasicHealthInformation,
    @param.query.object('where', getWhereSchemaFor(BasicHealthInformation))
    where?: Where<BasicHealthInformation>,
  ): Promise<Count> {
    return this.basicHealthInformationRepository.updateAll(
      basicHealthInformation,
      where,
    );
  }

  @get('/basic-health-informations/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'BasicHealthInformation model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(BasicHealthInformation, {
              includeRelations: true,
            }),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(BasicHealthInformation))
    filter?: Filter<BasicHealthInformation>,
  ): Promise<BasicHealthInformation> {
    return this.basicHealthInformationRepository.findById(id, filter);
  }

  @patch('/basic-health-informations/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'BasicHealthInformation PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(BasicHealthInformation, {partial: true}),
        },
      },
    })
    basicHealthInformation: BasicHealthInformation,
  ): Promise<void> {
    await this.basicHealthInformationRepository.updateById(
      id,
      basicHealthInformation,
    );
  }

  @put('/basic-health-informations/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'BasicHealthInformation PUT success',
      },
    },
  })
  @authenticate('jwt')
  async replaceById(
    @param.path.string('id') id: string,
    @requestBody() basicHealthInformation: BasicHealthInformation,
  ): Promise<void> {
    await this.basicHealthInformationRepository.replaceById(
      id,
      basicHealthInformation,
    );
  }

  @del('/basic-health-informations/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'BasicHealthInformation DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.basicHealthInformationRepository.deleteById(id);
  }

  @get('/basic-health-informations/getBasicHealthInfo/', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'HealthQuestion  success',
      },
    },
  })
  @authenticate('jwt')
  async getBasicHealthInfo(
    @inject(SecurityBindings.USER) currentUser: UserProfile,
  ): Promise<any> {
    let responseData: Array<AnyObject> = [];
    const basicHealth = await this.basicHealthInformationRepository.findOne({
      where: {
        userId: currentUser[securityId],
      },
      order: ['created DESC'],
    });
    if (basicHealth && basicHealth.id) {
      const questions = await this.healthQuestionRepository.find({
        where: {
          id: {inq: basicHealth.questionId},
        },
      });
      let result: AnyObject = {};
      let questionArray: Array<any> =
        (basicHealth && basicHealth.questionId) || [];
      let answerArray: Array<any> = (basicHealth && basicHealth.answer) || [];
      _.forEach(questions, function(val: any, index) {
        let obj = Object.assign({});
        if (String(val.id) === String(questionArray[index])) {
          obj.question = (val && val.question) || '';
          obj.id = (val && val.id) || '';
          obj.userId = (basicHealth && basicHealth.userId) || '';
          obj.created = (basicHealth && basicHealth.created) || '';
          obj.answer = (answerArray && answerArray[index]) || '';
          responseData.push(obj);
        }
      });
      return responseData;
    } else {
      return [];
    }
  }
}
