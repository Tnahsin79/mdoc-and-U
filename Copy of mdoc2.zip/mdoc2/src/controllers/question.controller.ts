import {
  get,
  put,
  del,
  post,
  param,
  patch,
  requestBody,
  getModelSchemaRef,
  getFilterSchemaFor,
} from '@loopback/rest';
import {inject} from '@loopback/core';
import {QuestionService} from '../services';
import {Filter} from '@loopback/repository';
import {QuestionServiceBindings} from '../keys';
import {authenticate} from '@loopback/authentication';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';
import {Option, Question, QuestionWithRelations} from '../models';

export class QuestionController {
  constructor(
    @inject(QuestionServiceBindings.QUESTION_SERVICE)
    public questionService: QuestionService,
  ) {}

  @post('/question', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Question model instance',
        content: {
          'application/json': {schema: getModelSchemaRef(Question)},
        },
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: {
            type: 'object',
            properties: {
              question: getModelSchemaRef(Question, {
                title: 'NewQuestion',
                exclude: ['id'],
              }),
              options: {
                type: 'array',
                itemType: getModelSchemaRef(Option, {
                  title: 'NewOption',
                  exclude: ['id'],
                }),
              },
            },
          },
        },
      },
    })
    body: {
      question: Omit<Question, 'id'>;
      options: Omit<Option, 'id'>[];
    },
  ): Promise<QuestionWithRelations> {
    return this.questionService.create(body);
  }

  @post('/question/option', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Option model instance',
        content: {
          'application/json': {schema: getModelSchemaRef(Option)},
        },
      },
    },
  })
  @authenticate('jwt')
  async createOption(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Option, {
            title: 'NewOption',
            exclude: ['id'],
          }),
        },
      },
    })
    option: Omit<Option, 'id'>,
  ): Promise<Option> {
    return this.questionService.createOption(option);
  }

  @post('/question/bulk', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Question model instance',
        content: {
          'application/json': {schema: getModelSchemaRef(Question)},
        },
      },
    },
  })
  @authenticate('jwt')
  async createQuestionBulk(
    @requestBody({
      content: {
        'application/json': {
          schema: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                question: getModelSchemaRef(Question, {
                  title: 'NewQuestion',
                  exclude: ['id'],
                }),
                options: {
                  type: 'array',
                  items: getModelSchemaRef(Option, {
                    partial: true,
                  }),
                },
              },
            },
          },
        },
      },
    })
    question: any,
  ): Promise<void> {
    return this.questionService.createQuestionBulk(question);
  }

  @get('/question', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of question model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(Question, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findAll(
    @param.query.object('filter', getFilterSchemaFor(Question))
    filter?: Filter<Question>,
  ): Promise<Question[]> {
    return this.questionService.findAll(filter);
  }

  @patch('/question/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'question PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateQuestion(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: {
            type: 'object',
            properties: {
              question: getModelSchemaRef(Question, {
                partial: true,
              }),
              options: {
                type: 'array',
                itemType: getModelSchemaRef(Option),
              },
            },
          },
        },
      },
    })
    body: any,
  ): Promise<void> {
    return await this.questionService.updateQuestion(id, body.question);
  }

  @patch('/question/option/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Option PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateOption(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Option, {partial: true}),
        },
      },
    })
    option: Option,
  ): Promise<void> {
    return await this.questionService.updateOption(id, option);
  }

  @put('/question/bulk-option', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Option success',
      },
    },
  })
  @authenticate('jwt')
  async updateOptionBulk(
    @requestBody({
      content: {
        'application/json': {
          schema: {
            type: 'array',
            items: getModelSchemaRef(Option, {partial: true}),
          },
        },
      },
    })
    options: Partial<Option>[],
  ): Promise<void> {
    return await this.questionService.updateOptionBulk(options);
  }

  @put('/question/bulk-questions', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Question order updated',
      },
    },
  })
  @authenticate('jwt')
  async updateQuestionBulk(
    @requestBody({
      content: {
        'application/json': {
          schema: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                id: {type: 'string'},
                order: {type: 'number'},
              }
            },
          },
        },
      },
    })
    questions: {id: string; order: number}[],
  ): Promise<void> {
    return await this.questionService.updateQuestionBulk(questions);
  }

  @del('/question/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'question DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    this.questionService.deleteQuestion(id);
  }

  @del('/question/option/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'option DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteOption(@param.path.string('id') id: string): Promise<void> {
    this.questionService.deleteOption(id);
  }
}
