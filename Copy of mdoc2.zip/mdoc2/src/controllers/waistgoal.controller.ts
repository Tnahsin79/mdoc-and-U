import { authenticate } from '@loopback/authentication';
import { Count, CountSchema, Filter, repository, Where, } from '@loopback/repository';
import { post, param, get, getModelSchemaRef, patch, put, del, requestBody, getFieldsJsonSchemaFor, getFilterSchemaFor } from '@loopback/rest';
import { Waistgoal } from '../models';
import { WaistgoalRepository } from '../repositories';
import { OPERATION_SECURITY_SPEC } from '../utils/security-spec';

export class WaistgoalController {
  constructor(
    @repository(WaistgoalRepository) public waistgoalRepository: WaistgoalRepository,
  ) { }

  @post('/waistWeightgoals', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'Waistgoal model instance',
        content: { 'application/json': { schema: getModelSchemaRef(Waistgoal) } },
      },
    }
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Waistgoal, {
            title: 'NewWaistgoal',
            exclude: ['id'],
          }),
        },
      },
    })
    waistgoal: Omit<Waistgoal, 'id'>,
  ): Promise<Waistgoal> {
    return this.waistgoalRepository.create(waistgoal);
  }

  // @get('/waistWeightgoals/count')
  // @response(200, {
  //   description: 'Waistgoal model count',
  //   content: { 'application/json': { schema: CountSchema } },
  // })
  // async count(
  //   @param.where(Waistgoal) where?: Where<Waistgoal>,
  // ): Promise<Count> {
  //   return this.waistgoalRepository.count(where);
  // }

  @get('/waistWeightgoals', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'Array of Waistgoal model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(Waistgoal, { includeRelations: true }),
            },
          },
        },
      },
    }
  })
  @authenticate('jwt')
  async find(
    @param.query.object('filter', getFilterSchemaFor(Waistgoal)) filter?: Filter<Waistgoal>,
  ): Promise<Waistgoal[]> {
    return this.waistgoalRepository.find(filter);
  }

  @patch('/waistWeightgoals', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'Waistgoal PATCH success count',
        content: { 'application/json': { schema: CountSchema } },
      },
    }
  })
  @authenticate('jwt')
  async updateAll(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Waistgoal, { partial: true }),
        },
      },
    })
    waistgoal: Waistgoal,
  ): Promise<void> {
    return this.waistgoalRepository.updateById(id, waistgoal);
  }

  @get('/waistWeightgoals/{id}', {
    responses: {
      200: {
        description: 'Waistgoal model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Waistgoal, { includeRelations: true }),
          },
        },
      },
    }
  })
  async findById(
    @param.path.string('id') id: string,
  ): Promise<Waistgoal> {
    return this.waistgoalRepository.findById(id);
  }

  // @patch('/waistWeightgoals/{id}')
  // @response(204, {
  //   description: 'Waistgoal PATCH success',
  // })
  // async updateById(
  //   @param.path.string('id') id: string,
  //   @requestBody({
  //     content: {
  //       'application/json': {
  //         schema: getModelSchemaRef(Waistgoal, { partial: true }),
  //       },
  //     },
  //   })
  //   waistgoal: Waistgoal,
  // ): Promise<void> {
  //   await this.waistgoalRepository.updateById(id, waistgoal);
  // }

  // @put('/waistWeightgoals/{id}')
  // @response(204, {
  //   description: 'Waistgoal PUT success',
  // })
  // async replaceById(
  //   @param.path.string('id') id: string,
  //   @requestBody() waistgoal: Waistgoal,
  // ): Promise<void> {
  //   await this.waistgoalRepository.replaceById(id, waistgoal);
  // }

  @del('/waistWeightgoals/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      204: {
        description: 'Waistgoal DELETE success',
      },
    }
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.waistgoalRepository.deleteById(id);
  }
}
