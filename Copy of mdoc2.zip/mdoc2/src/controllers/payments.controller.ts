import {
  Where,
  Count,
  Filter,
  AnyObject,
  repository,
  CountSchema,
} from '@loopback/repository';
import {
  put,
  get,
  del,
  post,
  param,
  patch,
  Request,
  Response,
  HttpErrors,
  requestBody,
  RestBindings,
  getWhereSchemaFor,
  getModelSchemaRef,
  getFilterSchemaFor,
} from '@loopback/rest';
import {
  UsersRepository,
  PlansRepository,
  PaymentsRepository,
  SubscriptionsRepository,
} from '../repositories';
import moment from 'moment';
import * as _ from 'lodash';
import Utils from '../utils';
import paystack from 'paystack';
import braintree from 'braintree';
import {inject} from '@loopback/core';
import * as common from '../services/common';
import {authenticate} from '@loopback/authentication';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';
import {Payments, PaymentsWithRelations, Users} from '../models';
import {UserProfile, securityId, SecurityBindings} from '@loopback/security';
const payStack = paystack(process.env.PAYSTACK_SECRET_KEY);
const config = common.getSiteOptions();

import {
  ChatServiceBindings,
  ControllerServiceBindings,
  PaymentsServiceBindings,
} from '../keys';
import {ControllerService} from '../services/controller.service';
import {PaymentsService} from '../services/payments.service';
import {PaginatedResponse} from '../type-schema';
import {ChatService} from '../services/chat.service';

const gateway = braintree.connect({
  environment: braintree.Environment.Sandbox,
  merchantId: process.env.BRAINTREE_MERCHANT_ID,
  publicKey: process.env.BRAINTREE_PUBLIC_KEY,
  privateKey: process.env.BRAINTREE_PRIVATE_KEY,
});

export class PaymentsController {
  configOption = Utils.getSiteOptions();
  constructor(
    @repository(PaymentsRepository)
    public paymentsRepository: PaymentsRepository,
    @repository(UsersRepository) public usersRepository: UsersRepository,
    @inject(ControllerServiceBindings.CONTROLLER_SERVICE)
    public controllerService: ControllerService,
    @repository(SubscriptionsRepository)
    public subscriptionsRepository: SubscriptionsRepository,
    @repository(PlansRepository) public plansRepository: PlansRepository,
    @inject(PaymentsServiceBindings.PAYMENTS_SERVICE)
    public paymentService: PaymentsService,
    @inject(ChatServiceBindings.CHAT_SERVICE) public chatService: ChatService,
  ) {}

  @post('/payments/initialize', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Payments model instance',
        content: {'application/json': {schema: getModelSchemaRef(Payments)}},
      },
    },
  })
  @authenticate('jwt')
  async initializePayment(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Payments, {
            title: 'NewPayments',
            exclude: ['id', 'reference'],
          }),
        },
      },
    })
    payments: Omit<Payments, 'id'>,
  ): Promise<Payments> {
    return this.paymentService.initializePayment(payments);
  }

  @get('/payments/count', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Payments model count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  @authenticate('jwt')
  async count(
    @param.query.object('where', getWhereSchemaFor(Payments))
    where?: Where<Payments>,
  ): Promise<Count> {
    return this.paymentsRepository.count(where);
  }

  @get('/payments', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of UserSubscriptions model instances',
        content: {
          'application/json': {
            schema: Utils.paginatedSchema(Payments, true),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async getAllPayments(
    @param.query.number('limit') limit?: number,
    @param.query.number('page') page?: number,
    @param.query.string('startDate') startDate?: string,
    @param.query.string('endDate') endDate?: string,
    @param.query.string('userId') userId?: string,
    @param.query.string('programId') programId?: string,
    @param.query.string('status') status?: string,
  ): Promise<PaginatedResponse<PaymentsWithRelations>> {
    return this.paymentService.getAllPayments(
      limit,
      page,
      startDate,
      endDate,
      programId,
      userId,
      status,
    );
  }

  // @get('/payments', {
  //   security: OPERATION_SECURITY_SPEC,
  //   responses: {
  //     '200': {
  //       description: 'Array of Payments model instances',
  //       content: {
  //         'application/json': {
  //           schema: {
  //             type: 'array',
  //             items: getModelSchemaRef(Payments, { includeRelations: true }),
  //           },
  //         },
  //       },
  //     },
  //   },
  // })
  // @authenticate('jwt')
  // async find(
  //   @param.query.object('filter')
  //   filter?: AnyObject,
  // ): Promise<any> {

  //   const query: any = { and: [{}] };

  //   if( filter && filter.searchBy === "state") {
  //     query.and.push({
  //       state: { eq: filter.searchState }
  //     })
  //   }

  //   if (filter && filter.searchBy === "created") {

  //     query.and.push({
  //       created: { lte: moment.utc(filter.searchCreated, 'YYYY-MM-DD').endOf('day').toISOString() }
  //     })
  //     query.and.push({
  //       created: { gte: moment.utc(filter.searchCreated, 'YYYY-MM-DD').startOf('day').toISOString() }
  //     })
  //   }

  //   const pageSize = filter?.limit || 20;
  //   const currentPage = (filter?.page || 1) - 1;
  //   const skip = currentPage * pageSize;
  //   const payments = await this.paymentsRepository.find({
  //     where: query,
  //     limit: pageSize,
  //     skip: skip,
  //     order: ['created DESC'],
  //     include: [
  //       { relation: 'user', scope: { fields: { id: true, name: true } } }
  //     ]
  //   });

  //   const totalResults = await this.paymentsRepository.count(query);
  //   const totalPages = Math.ceil(Number(totalResults.count) / pageSize);

  //   const revenue = _.filter(payments, function (val) { return val.status === "success" })
  //   const total = _.sumBy(revenue, v => v.amount);

  //   return { totalRevenue: total, payments, totalResults: totalResults.count, totalPages, currentPage: currentPage + 1 }
  // }

  @patch('/payments', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Payments PATCH success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  @authenticate('jwt')
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Payments, {partial: true}),
        },
      },
    })
    payments: Payments,
    @param.query.object('where', getWhereSchemaFor(Payments))
    where?: Where<Payments>,
  ): Promise<Count> {
    return this.paymentsRepository.updateAll(payments, where);
  }

  @get('/payments/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Payments model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Payments, {includeRelations: true}),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(Payments))
    filter?: Filter<Payments>,
  ): Promise<Payments> {
    return this.paymentsRepository.findById(id, filter);
  }

  @patch('/payments/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Payments PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Payments, {partial: true}),
        },
      },
    })
    payments: Payments,
  ): Promise<void> {
    await this.paymentsRepository.updateById(id, payments);
  }

  @put('/payments/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Payments PUT success',
      },
    },
  })
  @authenticate('jwt')
  async replaceById(
    @param.path.string('id') id: string,
    @requestBody() payments: Payments,
  ): Promise<void> {
    await this.paymentsRepository.replaceById(id, payments);
  }

  @del('/payments/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Payments DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.paymentsRepository.deleteById(id);
  }

  @post('/payments/getCustomerDetails', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Payments  success',
      },
    },
  })
  @authenticate('jwt')
  async getCustomerDetails(
    @inject(SecurityBindings.USER) currentUser: UserProfile,
    @requestBody() data: any,
  ): Promise<any> {
    let responseData: AnyObject = {};
    if (data && data.name) {
      const custom = await this.usersRepository.findOne({
        where: {
          id: currentUser[securityId],
        },
        fields: {customerId: true, id: true},
      });
      if (custom && custom.customerId) {
        return await gateway.clientToken
          .generate({
            customerId: custom.customerId,
          })
          .then(async res => {
            if (res && res.clientToken) {
              responseData = Object.assign({}, res);

              let obj = {
                userId: currentUser[securityId],
                planId: data && data.planId,
                payer: data.payer,
                paymentType: 'Braintree Paypal',
                transitionId: 'none',
              };
              let subs: AnyObject = {
                userId: currentUser[securityId],
                planName: (data && data.planDuration) || '',
                payer: (data && data.payer) || '',
                state: 'pending',
                subscriptionId: (data && data.planId) || '',
              };
              await this.subscriptionsRepository.create(subs);
              await this.paymentsRepository.create(obj);
              responseData.clientToken = _.cloneDeep(res.clientToken);
              return responseData;
            } else {
              throw new HttpErrors.UnprocessableEntity(
                'Client token not created!',
              );
            }
          })
          .catch(err => {
            throw new HttpErrors.UnprocessableEntity(err);
          });
      } else {
        return await gateway.customer
          .create({
            firstName: (data && data.name) || '',
            lastName: (data && data.name) || '',
            company: (data && data.company) || '',
            email: (data && data.email) || '',
            phone: (data && data.phone) || '',
            fax: (data && data.fax) || '',
            website: (data && data.website) || '',
          })
          .then(async res => {
            if (res && res.customer && res.customer.id) {
              let cust = {
                customerId: res.customer.id,
              };
              await this.usersRepository.updateById(
                currentUser[securityId],
                cust,
              );
              return gateway.clientToken
                .generate({
                  customerId: res.customer.id,
                })
                .then(async res => {
                  if (res && res.clientToken) {
                    let obj = {
                      userId: currentUser[securityId],
                      planId: data && data.planId,
                      payer: data.payer,
                      paymentType: 'Braintree Paypal',
                      transitionId: 'none',
                      billingInfo: {
                        firstName: (data && data.name) || '',
                        lastName: (data && data.name) || '',
                        company: (data && data.company) || '',
                        email: (data && data.email) || '',
                        phone: (data && data.phone) || '',
                        fax: (data && data.fax) || '',
                        website: (data && data.website) || '',
                        billingAddress: (data && data.billingAddress) || '',
                        city: (data && data.city) || '',
                        state: (data && data.state) || '',
                        country: (data && data.country) || '',
                      },
                    };

                    // let totalMonths = data && data.planDuration && data.planDuration.split(' ')[0] || "0";
                    // let expDate = moment().add(totalMonths, 'months')

                    let subs: AnyObject = {
                      userId: currentUser[securityId],
                      planName: (data && data.planDuration) || '',
                      payer: (data && data.payer) || '',
                      state: 'pending',
                      subscriptionId: (data && data.planId) || '',
                    };
                    await this.subscriptionsRepository.create(subs);
                    await this.paymentsRepository.create(obj);
                    responseData.clientToken = _.cloneDeep(res.clientToken);
                    return responseData;
                  } else {
                    throw new HttpErrors.UnprocessableEntity(
                      'Client token not created!',
                    );
                  }
                })
                .catch(err => {
                  console.log(err);
                  throw new HttpErrors.UnprocessableEntity(err);
                });
            } else {
              throw new HttpErrors.UnprocessableEntity('Customer not found!');
            }
          })
          .catch(err => {
            throw new HttpErrors.UnprocessableEntity(err);
          });
      }
    } else {
      throw new HttpErrors.UnprocessableEntity('Data is missing!');
    }
  }

  @post('/payments/createPayment', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Payments Customer Details success',
      },
    },
  })
  @authenticate('jwt')
  async createPayment(
    @inject(SecurityBindings.USER) currentUser: UserProfile,
    @requestBody() data: any,
  ): Promise<any> {
    let responseData: AnyObject = {};

    let transId: any = '';
    if (data && data.amount && data.amount > 0) {
      return gateway.transaction
        .sale({
          amount: data.amount,
          paymentMethodNonce: data.nonce,
          options: {
            submitForSettlement: true,
          },
        })
        .then(async res => {
          if (res && res.transaction && res.transaction.id) {
            transId = res && res.transaction && res.transaction.id;
            // responseData = Object.assign({}, res)
            const payment = await this.paymentsRepository.findOne({
              where: {
                userId: currentUser[securityId],
                transactionId: 'none',
              },
              order: ['created DESC'],
            });
            if (payment && payment.id) {
              let obj = {
                transitionId:
                  (res && res.transaction && res.transaction.id) || '',
                state: 'success',
                amount: Number(data.amount),
              };

              const planSelectd = await this.plansRepository.findOne({
                where: {
                  id: payment.planId,
                },
              });

              let totalMonths =
                (planSelectd &&
                  planSelectd.validity &&
                  planSelectd.validity.split(' ')[0]) ||
                0;
              let expDate = moment().add(totalMonths, 'months');
              let planDuration =
                (data && data.planDuration && data.planDuration) ||
                (planSelectd && planSelectd.validity && planSelectd.validity) ||
                '';
              const subscribe = await this.subscriptionsRepository.findOne({
                where: {
                  userId: currentUser[securityId],
                  state: 'pending',
                },
                order: ['created DESC'],
              });

              if (subscribe && subscribe.id) {
                let sub: AnyObject = {
                  state: 'success',
                  renewalDate: expDate,
                  expireDate: expDate,
                  planName: planDuration,
                };
                await this.subscriptionsRepository.updateById(
                  subscribe.id,
                  sub,
                );
              }
              await this.paymentsRepository.updateById(payment.id, obj);
              responseData = Object.assign({}, payment);
              (responseData.transitionId =
                (res && res.transaction && res.transaction.id) || ''),
                (responseData.state = 'success');
              responseData.planDuration = planDuration;
              responseData.expireDate = expDate;
              responseData.amount = (data && data.amount) || 0;
              responseData.name = (planSelectd && planSelectd.name) || '';
              return responseData;
            } else {
              throw new HttpErrors.NotFound('Payment data missing');
            }
          } else {
            throw new HttpErrors.NotFound('Something went wrong!');
          }
        })
        .catch(err => {
          throw new HttpErrors.UnprocessableEntity(err);
        });
    } else {
      throw new HttpErrors.UnprocessableEntity(
        'Amount should be greater than zero',
      );
    }
  }

  // @post('/payments/initialize', {
  //   security: OPERATION_SECURITY_SPEC,
  //   responses: {
  //     '200': {
  //       description: 'Payments  success',
  //     },
  //   },
  // })
  // @authenticate('jwt')
  // async initialize(
  //   @inject(SecurityBindings.USER) currentUser: UserProfile,
  //   @requestBody() data: any,
  // ): Promise<any> {
  //   let responseData: AnyObject = {};
  //   if (data && data.name) {
  //     return await payStack.transaction
  //       .initialize({
  //         amount: (data && data.amount) || '',
  //         name: (data && data.name) || '',
  //         currency: data.currency,
  //         reference: '',
  //         email: (data && data.email) || '',
  //       })
  //       .then(async res => {
  //         if (res && res.data && res.data.reference) {
  //           responseData = Object.assign({}, res);
  //           return responseData;
  //         }
  //       })
  //       .catch(er => {
  //         throw new HttpErrors.UnprocessableEntity(
  //           `Something went wrong ${er}`,
  //         );

  //       });
  //   } else {
  //     throw new HttpErrors.UnprocessableEntity('Data is missing!');
  //   }
  // }
  @post('/payments/verifyTransaction', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Payments  success',
      },
    },
  })
  @authenticate('jwt')
  async verifyTransaction(
    @inject(SecurityBindings.USER) currentUser: UserProfile,
    @requestBody() data: any,
  ): Promise<any> {
    let responseData: AnyObject = {};
    if (data && data.reference) {
      return await payStack.transaction
        .verify(data.reference)
        .then(async res => {
          if (res && res.status) {
            responseData.status = (res && res.status) || '';
            responseData.message = (res && res.message) || '';
            responseData.paymentMessage =
              (res && res.data && res.data.gateway_response) || '';

            let obj = {
              userId: currentUser[securityId],
              planId: data && data.planId,
              payer: data.payer,
              paymentType: 'PayStack',
              transitionId: (res && res.data && res.data.id) || 'null',
              state: (res && res.data && res.data.status) || 'null',
              amount: (data && data.amount) || 0,
            };
            const planSelectd = await this.plansRepository.findOne({
              where: {
                id: data && data.planId,
              },
            });

            let totalMonths =
              (data && data.planDuration && data.planDuration.split(' ')[0]) ||
              (planSelectd &&
                planSelectd.validity &&
                planSelectd.validity.split(' ')[0]) ||
              0;
            let expDate = moment().add(totalMonths, 'months');
            let planDuration =
              (data && data.planDuration && data.planDuration) ||
              (planSelectd && planSelectd.validity && planSelectd.validity) ||
              '';

            let subs: AnyObject = {
              userId: currentUser[securityId],
              planName: planDuration,
              payer: (data && data.payer) || '',
              renewalDate: expDate,
              expireDate: expDate,
              state: (res && res.data && res.data.status) || 'null',
              subscriptionId: (data && data.planId) || '',
            };
            await this.subscriptionsRepository.create(subs);
            const pay = await this.paymentsRepository.create(obj);
            responseData.payment = (pay && pay.id && pay) || {};
            responseData.expireDate = expDate;
            responseData.name = (planSelectd && planSelectd.name) || '';
            return responseData;
          } else {
            return res;
          }
        })
        .catch(err => {
          throw new HttpErrors.UnprocessableEntity(err);
        });
    } else {
      throw new HttpErrors.UnprocessableEntity('Data is missing!');
    }
  }
  @post('/payments/upload', {
    responses: {
      200: {
        content: {
          'application/json': {
            schema: {type: 'object'},
          },
        },
      },
    },
  })
  async upload(
    @requestBody({
      description: 'multipart/form-data value.',
      required: true,
      content: {
        'multipart/form-data': {
          'x-parser': 'stream',
          schema: {type: 'object'},
        },
      },
    })
    request: Request,
    @inject(RestBindings.Http.RESPONSE) response: Response,
  ): Promise<object> {
    return await this.chatService.uploadFile(request, response);
  }

  @get('/payments/paymentsChart', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of Payments model instances',
        content: {
          'application/json': {
            schema: {type: 'array'},
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async paymentsChart(
    @param.query.string('startDate') startDate?: string,
    @param.query.string('endDate') endDate?: string,
  ): Promise<any> {
    let result: Array<AnyObject> = [];

    let query: AnyObject = {
      state: 'success',
    };

    if (!this.paymentsRepository.dataSource.connected) {
      await this.paymentsRepository.dataSource.connect();
    }
    const usersCollection = (this.paymentsRepository.dataSource
      .connector as any).collection('Payments');

    return await Promise.all([
      usersCollection
        .aggregate([
          {$match: query},
          {$sort: {created: -1}},
          {
            $group: {
              _id: {
                month: {$month: '$created'},
              },
              payment: {$sum: '$amount'},
            },
          },
        ])
        .get(),
    ])
      .then((res: any) => {
        if (res && res[0] && res[0].length) {
          _.forEach(res[0], function(val, index) {
            result.push({
              name: moment(`${val._id.month}`, 'MM')
                .format('MMMM')
                .valueOf(),
              conversion: val.payment,
            });
          });
          result = _.sortBy(result, function(v) {
            return v[0];
          }).reverse();
        }

        return result;
      })
      .catch((err: any) => {
        throw new HttpErrors.InternalServerError('Something went wrong!');
      });
  }

  @get('/payments/billingHistory', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Payments  success',
      },
    },
  })
  @authenticate('jwt')
  async billingHistory(
    @inject(SecurityBindings.USER) currentUser: UserProfile,
  ): Promise<any> {
    let responseData: Array<AnyObject> = [];

    const payments = await this.paymentsRepository.find({
      where: {
        userId: currentUser[securityId],
      },
      order: ['created DESC'],
    });

    if (payments && payments.length) {
      let planIds = _.map(payments, v => v.planId);

      return Promise.all([
        this.subscriptionsRepository.find({
          where: {
            subscriptionId: {inq: planIds},
          },
          order: ['created DESC'],
        }),
      ])
        .then(res => {
          let subsGroup =
            res &&
            res[0] &&
            res[0].length &&
            _.groupBy(res[0], v => v.subscriptionId);

          _.forEach(payments, function(val: any) {
            let obj = Object.assign({}, val);
            obj.subscriptionPlan =
              (subsGroup &&
                subsGroup[val.planId] &&
                subsGroup[val.planId].length &&
                subsGroup[val.planId][0]) ||
              {};
            responseData.push(obj);
          });

          return responseData;
        })
        .catch(err => {
          console.log(err, '=============-=-');
          throw new HttpErrors.UnprocessableEntity('Something went wrong!');
        });
    } else {
      return [];
    }
  }

  @get('/payments/createFlutterPayment', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Payments  success',
      },
    },
  })
  @authenticate('jwt')
  async createFlutterPayment(
    @inject(SecurityBindings.USER) currentUser: UserProfile,
    @param.query.string('planId') planId: string,
    @param.query.string('transactionId') transactionId: string,
    @param.query.string('amount') amount: string,
  ): Promise<any> {
    let responseData: AnyObject = {};
    if (!planId && !amount && !transactionId) {
      throw new HttpErrors.UnprocessableEntity('Request Data is missing!');
    }
    let obj: AnyObject = {
      userId: currentUser[securityId],
      planId: planId,
      payer: 'flutterwave',
      paymentType: 'flutterwave',
      transitionId: transactionId,
      state: 'sucess',
      amount: amount,
    };
    const planSelectd = await this.plansRepository.findOne({
      where: {
        id: planId,
      },
    });

    let totalMonths =
      (planSelectd &&
        planSelectd.validity &&
        planSelectd.validity.split(' ')[0]) ||
      0;
    let expDate = moment().add(totalMonths, 'months');
    let planDuration =
      (planSelectd && planSelectd.validity && planSelectd.validity) || '';

    let subs: AnyObject = {
      userId: currentUser[securityId],
      planName: planDuration,
      payer: 'flutterwave',
      renewalDate: expDate,
      expireDate: expDate,
      state: 'sucess',
      subscriptionId: planId || '',
    };
    await this.subscriptionsRepository.create(subs);
    const pay = await this.paymentsRepository.create(obj);
    responseData.payment = (pay && pay.id && pay) || {};
    responseData.expireDate = expDate;
    responseData.name = (planSelectd && planSelectd.name) || '';
    return responseData;
  }

  @get('/getFinanceSummary', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Payments  success',
      },
    },
  })
  @authenticate('jwt')
  async getFinanceSummary(
    @param.query.string('filter') filter: string,
    @param.query.string('startDate') startDate: string,
    @param.query.string('endDate') endDate: string,
  ): Promise<any> {
    let query: any = {and: []};
    query.and.push({
      state: 'success',
    });

    if (filter === 'day') {
      query.and.push({
        created: {
          lte: moment
            .utc()
            .endOf('day')
            .toISOString(),
        },
      });
      query.and.push({
        created: {
          gte: moment
            .utc()
            .startOf('day')
            .toISOString(),
        },
      });
    }
    if (filter === 'month') {
      query.and.push({
        created: {
          lte: moment
            .utc()
            .endOf('month')
            .toISOString(),
        },
      });
      query.and.push({
        created: {
          gte: moment
            .utc()
            .startOf('month')
            .toISOString(),
        },
      });
    }
    if (filter === 'year') {
      query.and.push({
        created: {
          lte: moment
            .utc()
            .endOf('year')
            .toISOString(),
        },
      });
      query.and.push({
        created: {
          gte: moment
            .utc()
            .startOf('year')
            .toISOString(),
        },
      });
    }

    if (startDate && endDate) {
      query.and.push({
        created: {
          lte: moment
            .utc(endDate, 'YYYY-MM-DD')
            .endOf('day')
            .toISOString(),
        },
      });
      query.and.push({
        created: {
          gte: moment
            .utc(startDate, 'YYYY-MM-DD')
            .startOf('day')
            .toISOString(),
        },
      });
    }
    return this.paymentsRepository.find({
      where: query,
      order: ['created DESC'],
    });
  }
}
