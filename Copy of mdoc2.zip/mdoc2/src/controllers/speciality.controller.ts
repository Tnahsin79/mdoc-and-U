import {inject} from '@loopback/core';
import {
  AnyObject,
  Count,
  CountSchema,
  Filter,
  repository,
  Where,
} from '@loopback/repository';
import {
  post,
  param,
  get,
  getFilterSchemaFor,
  getModelSchemaRef,
  getWhereSchemaFor,
  patch,
  put,
  del,
  requestBody,
} from '@loopback/rest';
import {SpecialityServiceBindings} from '../keys';
import {Speciality} from '../models';
import {SpecialityRepository} from '../repositories';
import {SpecialityService} from '../services/speciality.service';
import {PaginatedResponse} from '../type-schema';
import Utils from '../utils';

export class SpecialityController {
  constructor(
    @repository(SpecialityRepository)
    public specialityRepository: SpecialityRepository,
    @inject(SpecialityServiceBindings.SPECIALITY_SERVICE)
    public specialityService: SpecialityService,
  ) {}

  @post('/specialities', {
    responses: {
      '200': {
        description: 'Speciality model instance',
        content: {'application/json': {schema: getModelSchemaRef(Speciality)}},
      },
    },
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Speciality, {
            title: 'NewSpeciality',
            exclude: ['id'],
          }),
        },
      },
    })
    speciality: Omit<Speciality, 'id'>,
  ): Promise<Speciality> {
    return this.specialityService.create(speciality);
  }

  @get('/specialities/count', {
    responses: {
      '200': {
        description: 'Speciality model count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async count(
    @param.query.object('where', getWhereSchemaFor(Speciality))
    where?: Where<Speciality>,
  ): Promise<Count> {
    return this.specialityRepository.count(where);
  }

  @get('/specialities', {
    responses: {
      '200': {
        description: 'Array of Speciality model instances',
        content: {
          'application/json': {
            schema: Utils.paginatedSchema(Speciality, true),
          },
        },
      },
    },
  })
  async find(
    @param.query.object('filter', getFilterSchemaFor(Speciality))
    filter?: Filter<Speciality>,
    @param.query.number('page') page?: number,
  ): Promise<PaginatedResponse<Speciality>> {
    return this.specialityService.find(filter, page);
  }

  @patch('/specialities', {
    responses: {
      '200': {
        description: 'Speciality PATCH success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Speciality, {partial: true}),
        },
      },
    })
    speciality: Speciality,
    @param.query.object('where', getWhereSchemaFor(Speciality))
    where?: Where<Speciality>,
  ): Promise<Count> {
    return this.specialityRepository.updateAll(speciality, where);
  }

  @get('/specialities/{id}', {
    responses: {
      '200': {
        description: 'Speciality model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Speciality, {includeRelations: true}),
          },
        },
      },
    },
  })
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(Speciality))
    filter?: Filter<Speciality>,
  ): Promise<Speciality> {
    return this.specialityRepository.findById(id, filter);
  }

  @patch('/specialities/{id}', {
    responses: {
      '204': {
        description: 'Speciality PATCH success',
      },
    },
  })
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Speciality, {partial: true}),
        },
      },
    })
    speciality: Speciality,
  ): Promise<void> {
    await this.specialityRepository.updateById(id, speciality);
  }

  @put('/specialities/{id}', {
    responses: {
      '204': {
        description: 'Speciality PUT success',
      },
    },
  })
  async replaceById(
    @param.path.string('id') id: string,
    @requestBody() speciality: Speciality,
  ): Promise<void> {
    await this.specialityRepository.replaceById(id, speciality);
  }

  @del('/specialities/{id}', {
    responses: {
      '204': {
        description: 'Speciality DELETE success',
      },
    },
  })
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.specialityRepository.deleteById(id);
  }
}
