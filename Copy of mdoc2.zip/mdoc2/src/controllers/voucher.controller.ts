import {
  get,
  put,
  del,
  post,
  patch,
  param,
  requestBody,
  getModelSchemaRef,
  getWhereSchemaFor,
} from '@loopback/rest';
import {inject} from '@loopback/context';
import {VoucherService} from '../services';
import {VoucherServiceBindings} from '../keys';
import {Voucher, VoucherWithRelations} from '../models';
import {Count, Where, Filter, CountSchema} from '@loopback/repository';
import { OPERATION_SECURITY_SPEC } from '../utils/security-spec';
import { authenticate } from '@loopback/authentication';
import {UserProfile, securityId, SecurityBindings} from '@loopback/security';

export class VoucherController {
  constructor(
    @inject(VoucherServiceBindings.VOUCHER_SERVICE)
    public voucherService: VoucherService,
  ) {}

  @post('/voucher', {
    responses: {
      '200': {
        description: 'Voucher model instance',
        content: {'application/json': {schema: getModelSchemaRef(Voucher)}},
      },
    },
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Voucher, {
            title: 'NewVoucher',
            exclude: ['id'],
          }),
        },
      },
    })
    Voucher: Omit<Voucher, 'id'>,
  ): Promise<Voucher> {
    return this.voucherService.create(Voucher);
  }

  @get('/voucher/count', {
    responses: {
      '200': {
        description: 'Voucher model count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async count(
    @param.query.object('where', getWhereSchemaFor(Voucher))
    where?: Where<Voucher>,
  ): Promise<Count> {
    return this.voucherService.voucherCount(where);
  }

  @get('/voucher/code', {
    responses: {
      security: OPERATION_SECURITY_SPEC,
      '200': {
        description: 'Array of Voucher model instances',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Voucher, {includeRelations: true}),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findByCode(
    @param.query.string('code') code: string,
    @inject(SecurityBindings.USER) currentUser: UserProfile,
    @param.query.string('programId') programId?: string,
    @param.query.string('planId') planId?: string,
    @param.query.string('userId') userId?: string,
  ): Promise<VoucherWithRelations> {
    const id = userId || currentUser[securityId];
    return this.voucherService.findByCode(id, code, programId, planId);
  }

  @get('/voucher', {
    responses: {
      '200': {
        description: 'Array of Voucher model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(Voucher, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  async find(
    @param.query.object('filter') filter?: Filter<Voucher>,
  ): Promise<VoucherWithRelations[]> {
    return this.voucherService.findAll(filter);
  }

  @get('/voucher/{id}', {
    responses: {
      '200': {
        description: 'Voucher model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Voucher, {includeRelations: true}),
          },
        },
      },
    },
  })
  async findById(@param.path.string('id') id: string): Promise<Voucher> {
    return this.voucherService.findById(id);
  }

  @patch('/voucher/{id}', {
    responses: {
      security: OPERATION_SECURITY_SPEC,
      '204': {
        description: 'Voucher PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Voucher, {partial: true}),
        },
      },
    })
    Voucher: Voucher,
  ): Promise<void> {
    await this.voucherService.updateById(id, Voucher);
  }

  @del('/voucher/{id}', {
    responses: {
      '204': {
        description: 'Voucher DELETE success',
      },
    },
  })
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.voucherService.deleteById(id);
  }
}
