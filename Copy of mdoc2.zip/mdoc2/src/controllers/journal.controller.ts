import { Count, CountSchema, Filter, repository, Where, AnyObject, } from '@loopback/repository';
import { post, param, get, getFilterSchemaFor, getModelSchemaRef, getWhereSchemaFor, patch, put, del, requestBody, } from '@loopback/rest';
import { Journal } from '../models';
import { JournalRepository, ChampionsRepository, NotificationRepository } from '../repositories';
import { OPERATION_SECURITY_SPEC } from '../utils/security-spec';
import { authenticate } from '@loopback/authentication';
import { inject } from '@loopback/core';
import { UserProfile, securityId, SecurityBindings } from '@loopback/security';
import * as _ from 'lodash'
import { FCMServiceBindings } from '../keys';
import { FCMService } from '../services/fcm.service';
export class JournalController {
  constructor(
    @repository(JournalRepository) public journalRepository: JournalRepository,
    @repository(ChampionsRepository) public championsRepository: ChampionsRepository,
    @repository(NotificationRepository) public notificationRepository: NotificationRepository,
    @inject(FCMServiceBindings.FCM_SERVICE) public fcmServices: FCMService
  ) { }

  @post('/journals', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Journal model instance',
        content: { 'application/json': { schema: getModelSchemaRef(Journal) } },
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Journal, {
            title: 'NewJournal',
            exclude: ['id'],
          }),
        },
      },
    })
    journal: Omit<Journal, 'id'>,
  ): Promise<any> {
    const journalDetails = await this.journalRepository.create(journal);
    if (journalDetails && journalDetails.userId) {
      const champions = await this.championsRepository.find({
        where: {
          starId: journalDetails.userId
        }, include: [
          { relation: "star" },
          { relation: "champion" }
        ]
      })
      if (champions && champions.length) {
        let _this = this
        _.forEach(champions, async function (val: any) {
          if (val && val.champion && val.champion.fcmToken && val.champion.isPushNotification) {
            var message = {
              to: val && val.champion && val.champion.fcmToken,
              data: {
                name: val && val.champion && val.star.name || "",
                userId: val && val.champion && val.star.id || "",
                type: 'starLst',
                notificationObject: { starId: val && val.champion && val.star.id }
              },
              notification: {
                title: 'New journal by star',
                body: journalDetails.description,
                priority: "high",
                sound: "default",
                vibrate: true,
              }
            };
            await _this.fcmServices.sendNotification({ message: message })
            let noti = {
              title: 'New journal by star',
              message: journalDetails.description,
              userId: val && val.champion && val.champion.id,
              notiObject: { starId: journalDetails.userId },
              type: 'starLst',
            }
            await _this.notificationRepository.create(noti)

          } else {
            let noti = {
              title: 'New journal by star',
              message: journalDetails.description,
              userId: val && val.champion && val.champion.id,
              notiObject: { starId: journalDetails.userId },
              type: 'starLst',
            }
            await _this.notificationRepository.create(noti)
          }
        })
        return journalDetails
      } else {
        return journalDetails
      }
    }
  }

  @get('/journals/count', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Journal model count',
        content: { 'application/json': { schema: CountSchema } },
      },
    },
  })
  @authenticate('jwt')
  async count(
    @param.query.object('where', getWhereSchemaFor(Journal)) where?: Where<Journal>,
  ): Promise<Count> {
    return this.journalRepository.count(where);
  }

  @get('/journals', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of Journal model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(Journal, { includeRelations: true }),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async find(
    @param.query.object('filter', getFilterSchemaFor(Journal)) filter?: Filter<Journal>,
  ): Promise<Journal[]> {
    return this.journalRepository.find(filter);
  }

  @patch('/journals', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Journal PATCH success count',
        content: { 'application/json': { schema: CountSchema } },
      },
    },
  })
  @authenticate('jwt')
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Journal, { partial: true }),
        },
      },
    })
    journal: Journal,
    @param.query.object('where', getWhereSchemaFor(Journal)) where?: Where<Journal>,
  ): Promise<Count> {
    return this.journalRepository.updateAll(journal, where);
  }

  @get('/journals/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Journal model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Journal, { includeRelations: true }),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(Journal)) filter?: Filter<Journal>
  ): Promise<Journal> {
    return this.journalRepository.findById(id, filter);
  }

  @patch('/journals/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Journal PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Journal, { partial: true }),
        },
      },
    })
    journal: Journal,
  ): Promise<void> {
    await this.journalRepository.updateById(id, journal);
  }

  @put('/journals/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Journal PUT success',
      },
    },
  })
  @authenticate('jwt')
  async replaceById(
    @param.path.string('id') id: string,
    @requestBody() journal: Journal,
  ): Promise<void> {
    await this.journalRepository.replaceById(id, journal);
  }

  @del('/journals/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Journal DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.journalRepository.deleteById(id);
  }

  @get('/journals/getJournalList/', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Journal  success',
      },
    },
  })
  @authenticate('jwt')
  async getJournalList(
  ): Promise<any> {
    let responseData: Array<AnyObject> = []
    let query: AnyObject = {
      status: { inq: [0, 1] }
    }

    // if (data && data.search) {
    //   query.title = new RegExp('.*' + data.search + '.*', 'i')
    // }
    const journalData = await this.journalRepository.find({
      where: query,
      include: [
        {
          relation: "user",
          scope: {
            fields: { id: true, name: true, image: true, city: true, country: true, phone: true }
          }
        }
      ],
      order: ['created DESC'],

    })
    if (journalData && journalData.length) {
      return journalData
    } else {
      return []
    }
  }

  @get('/journals/myJournals/', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Journal  success',
      },
    },
  })
  @authenticate('jwt')
  async myJournals(
    @inject(SecurityBindings.USER) currentUser: UserProfile,
    @param.query.object('data') data: any,
  ): Promise<any> {

    let responseData: Array<AnyObject> = []
    let query: AnyObject = {
      status: { inq: [0, 1] },
      userId: currentUser[securityId]
    }

    if (data && data.search) {
      query.title = new RegExp('.*' + data.search + '.*', 'i')
    }
    const journalData = await this.journalRepository.find({
      where: query,
      include: [
        {
          relation: "user",
          scope: {
            fields: { id: true, name: true, image: true, city: true, country: true, phone: true }
          }
        }
      ],
      limit: data.limit,
      skip: data.skip,
      order: ['created DESC'],

    })
    if (journalData && journalData.length) {
      return journalData
    } else {
      return []
    }
  }
}
