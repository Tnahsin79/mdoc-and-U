import { Filter, repository } from "@loopback/repository";
import { ProductRepository } from "../repositories";
import { inject } from "@loopback/context";
import { del, get, getFilterSchemaFor, getModelSchemaRef, param, post, put, requestBody } from "@loopback/openapi-v3";
import { Product } from "../models";
import { authenticate } from "@loopback/authentication";
import { OPERATION_SECURITY_SPEC } from "../utils/security-spec";
import { ProductServiceBindings } from "../keys";
import { ProductService } from "../services";
import { Request, Response, RestBindings } from "@loopback/rest";
import {UserProfile, SecurityBindings} from '@loopback/security';

export class ProductController {
    constructor(
        @repository(ProductRepository) public productRepository: ProductRepository,
        @inject(ProductServiceBindings.PRODUCT_SERVICE) public productService: ProductService,
    ) { }
    
    @post('/products', {
        security: OPERATION_SECURITY_SPEC,
        responses: {
            '201': {
                description: 'Product model instance',
                content: { 'application/json': { schema: getModelSchemaRef(Product) } },
            },
        },
    })
    @authenticate('jwt')
    async create(
        @inject(SecurityBindings.USER) currentUser: UserProfile,
        @requestBody({
            content: {
                'multipart/form-data': {
                'x-parser': 'stream',
                    schema: {
                        type: 'object',
                        properties: {
                            name: {type: 'string'},
                            description: {type: 'string'},
                            covidEssential: {type: 'boolean'},
                            price: {type: 'number'},
                            percentageDiscount: {type: 'number'}
                        },
                    },
                },
            },
        })
        request: Request,
        @inject(RestBindings.Http.RESPONSE) response: Response,
    ) {
        return this.productService.create(request, response, currentUser);
    }

    @get('/products', {
        responses: {
            '200': {
                description: 'Array of Product model instances',
                content: {
                    'application/json': {
                        schema: { type: 'array', items: getModelSchemaRef(Product, {includeRelations: true}) },
                    },
                },
            },
        },
    })
    async find(
        @param.query.object('filter', getFilterSchemaFor(Product)) filter?: Filter<Product>,
    ): Promise<Product[]> {
        return this.productService.find(filter);
    }

    @get('/products/{id}', {
        security: OPERATION_SECURITY_SPEC,
        responses: {
            '200': {
                description: 'Product model instance',
                content: { 'application/json': { schema: getModelSchemaRef(Product) } },
            },
        },
    })
    @authenticate('jwt')
    async findById(
        @param.path.string('id') id: string,
        @param.query.object('filter', getFilterSchemaFor(Product)) filter?: Filter<Product>,
    ): Promise<Product> {
        return this.productService.findById(id, filter);
    }

    @put('/products/{id}', {
        security: OPERATION_SECURITY_SPEC,
        responses: {
            '204': {
                description: 'Product PATCH success',
            },
        },
    })
    @authenticate('jwt')
    async updateById(
        @param.path.string('id') id: string,
        @requestBody({
            content: {
                'multipart/form-data': {
                'x-parser': 'stream',
                    schema: {
                        type: 'object',
                        properties: {
                            name: {type: 'string'},
                            description: {type: 'string'},
                            covidEssential: {type: 'boolean'},
                            price: {type: 'number'},
                            percentageDiscount: {type: 'number'}
                        },
                    },
                },
            },
        })
        request: Request,
        @inject(RestBindings.Http.RESPONSE) response: Response,
    ) {
        return this.productService.update(id, request, response);
    }

    @del('/products/{id}', {
        security: OPERATION_SECURITY_SPEC,
        responses: {
            '204': {
                description: 'Product DELETE success',
            },
        },
    })
    @authenticate('jwt')
    async deleteById(@param.path.string('id') id: string): Promise<void> {
        await this.productService.deleteById(id);
    }
}
