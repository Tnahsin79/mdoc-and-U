import {repository} from '@loopback/repository';
import {post, get, getModelSchemaRef, requestBody} from '@loopback/rest';
import * as _ from 'lodash';
import {ReferralReason} from '../models';
import {ReferralReasonRepository} from '../repositories';
import {inject} from '@loopback/core';
import {ReferralReasonServiceBindings} from '../keys';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';
import {authenticate} from '@loopback/authentication';
import {ReferralReasonService} from '../services';

export class ReferralReasonController {
  constructor(
    @repository(ReferralReasonRepository)
    public referralReasonRepository: ReferralReasonRepository,
    @inject(ReferralReasonServiceBindings.REFERRAL_REASON_SERVICE)
    public referralReasonService: ReferralReasonService,
  ) {}

  @post('/referral-reasons', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Referral Reason model instance',
        content: {
          'application/json': {schema: getModelSchemaRef(ReferralReason)},
        },
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(ReferralReason, {
            title: 'NewReferralReason',
            exclude: ['id'],
          }),
        },
      },
    })
    payload: Omit<ReferralReason, 'id'>,
  ): Promise<ReferralReason> {
    return this.referralReasonService.create(payload);
  }

  @get('/referral-reasons', {
    responses: {
      '200': {
        description: 'Array of Referral Reason model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(ReferralReason, {
                includeRelations: true,
              }),
            },
          },
        },
      },
    },
  })
  async getAllReasons(): Promise<ReferralReason[]> {
    return this.referralReasonService.getAllReasons();
  }
}
