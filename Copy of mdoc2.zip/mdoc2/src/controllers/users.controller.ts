import {
  FCMServiceBindings,
  UserServiceBindings,
  TokenServiceBindings,
  EmailServiceBindings,
  PasswordHasherBindings,
  MigrationServiceBindings,
  ControllerServiceBindings,
  UserServiceExtensionBindings,
  HealthDairyMigrationServiceBindings,
} from '../keys';
import {
  Users,
  Pharmacy,
  Provider,
  EyeExamination,
  LabsProcedures,
  HealthCondition,
  FootExamination,
  MedicationPassport,
  UsersWithRelations,
  HealthProcedureSurgeries,
} from '../models';
import md5 from 'md5';
var fs = require('fs');
import {
  Credentials,
  SourceTypeEnum,
  VerificationTypeEnum,
  CredentialsRequestBody,
} from '../type-schema';
import {
  get,
  put,
  del,
  post,
  param,
  patch,
  Request,
  Response,
  HttpErrors,
  requestBody,
  RestBindings,
  getModelSchemaRef,
  getWhereSchemaFor,
  getFilterSchemaFor,
} from '@loopback/rest';
import {
  Count,
  Where,
  Filter,
  AnyObject,
  repository,
  CountSchema,
} from '@loopback/repository';
import {
  UsersRepository,
  CoachRepository,
  PlansRepository,
  JournalRepository,
  DiseaseRepository,
  ChatRoomRepository,
  PaymentsRepository,
  ProviderRepository,
  SymptomsRepository,
  PharmacyRepository,
  PregnancyRepository,
  TreatmentRepository,
  ChampionsRepository,
  WaistgoalRepository,
  MedicationRepository,
  SpecialityRepository,
  HealthDiaryRepository,
  NotificationRepository,
  AffordablityRepository,
  LoginHistoryRepository,
  SubscriptionsRepository,
  LabsProceduresRepository,
  EyeExaminationRepository,
  FootExaminationRepository,
  HealthConditionRepository,
  MedicationPassportRepository,
  HealthProcedureSurgeriesRepository,
} from '../repositories';
import * as _ from 'lodash';
import moment from 'moment';
import csv from 'csvtojson';
import Utils from '../utils';
import {inject} from '@loopback/core';
import {JWTService} from '../services/jwt-service';
import {FCMService} from '../services/fcm.service';
import {validatePassword} from '../services/validator';
import {EmailService} from '../services/email.service';
import {MigrationService} from '../services/migration.service';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';
import {ControllerService} from '../services/controller.service';
import {PasswordHasher} from '../services/hash.password.bcryptjs';
import {UserService, authenticate} from '@loopback/authentication';
import {UserServiceExtention} from '../services/usersServiceExtended';
import {UserProfile, securityId, SecurityBindings} from '@loopback/security';
import {AppointmentRepository} from './../repositories/appointment.repository';
import {HealthDairyMigrationService} from '../services/healthDairyMigration.service';
export class UsersController {
  configOption = Utils.getSiteOptions();
  constructor(
    @repository(UsersRepository) public usersRepository: UsersRepository,
    @inject(UserServiceBindings.USER_SERVICE)
    public userService: UserService<Users, Credentials>,
    @inject(UserServiceExtensionBindings.USER_SERVICE_EXT)
    public userServiceExt: UserServiceExtention,
    @inject(TokenServiceBindings.TOKEN_SERVICE) public jwtService: JWTService,
    @inject(PasswordHasherBindings.PASSWORD_HASHER)
    public passwordHasher: PasswordHasher,
    @repository(AppointmentRepository)
    public appointmentRepository: AppointmentRepository,
    @repository(SubscriptionsRepository)
    public subscriptionRepository: SubscriptionsRepository,
    @repository(CoachRepository) public coachRepository: CoachRepository,
    @repository(SymptomsRepository)
    public symptomsRepository: SymptomsRepository,
    @repository(DiseaseRepository) public diseaseRepository: DiseaseRepository,
    @repository(PaymentsRepository)
    public paymentRepository: PaymentsRepository,
    @inject(RestBindings.Http.RESPONSE) public response: Response,
    @inject(EmailServiceBindings.MAIL_SERVICE)
    public emailservice: EmailService,
    @repository(ProviderRepository)
    public providerRepository: ProviderRepository,
    @repository(HealthDiaryRepository)
    public healthDiaryRepository: HealthDiaryRepository,
    @repository(PharmacyRepository)
    public pharmacyRepository: PharmacyRepository,
    @repository(FootExaminationRepository)
    public footExaminationRepository: FootExaminationRepository,
    @repository(EyeExaminationRepository)
    public eyeExaminationRepository: EyeExaminationRepository,
    @repository(HealthConditionRepository)
    public healthConditionRepository: HealthConditionRepository,
    @repository(PregnancyRepository)
    public pregnancyRepository: PregnancyRepository,
    @repository(TreatmentRepository)
    public treatmentRepository: TreatmentRepository,
    @repository(MedicationPassportRepository)
    public medicationPassportRepository: MedicationPassportRepository,
    @repository(MedicationRepository)
    public medicationRepository: MedicationRepository,
    @repository(HealthProcedureSurgeriesRepository)
    public healthProcedureSurgeriesRepository: HealthProcedureSurgeriesRepository,
    @repository(NotificationRepository)
    public notificationRepository: NotificationRepository,
    @repository(LabsProceduresRepository)
    public labsProceduresRepository: LabsProceduresRepository,
    @inject(FCMServiceBindings.FCM_SERVICE) public fcmServices: FCMService,
    @repository(AffordablityRepository)
    public affordablityRepository: AffordablityRepository,
    @repository(JournalRepository) public journalRepository: JournalRepository,
    @repository(ChampionsRepository)
    public championsRepository: ChampionsRepository,
    @repository(PaymentsRepository)
    public paymentsRepository: PaymentsRepository,
    @repository(PlansRepository) public plansRepository: PlansRepository,
    @inject(ControllerServiceBindings.CONTROLLER_SERVICE)
    public controllerService: ControllerService,
    @repository(ChatRoomRepository)
    public chatRoomRepository: ChatRoomRepository,
    @inject(MigrationServiceBindings.MIGRATION_SERVICE)
    public migrationService: MigrationService,
    @inject(HealthDairyMigrationServiceBindings.HEALTHDAIRY_MIGRATION_SERVICE)
    public healthDiaryMigration: HealthDairyMigrationService,
    @repository(WaistgoalRepository)
    public waistgoalRepository: WaistgoalRepository,
    @repository(SpecialityRepository)
    public specialityRepository: SpecialityRepository,
    @repository(LoginHistoryRepository)
    public loginHistoryRepository: LoginHistoryRepository,
  ) {}

  @post('/users', {
    responses: {
      '200': {
        description: 'Users model instance',
        content: {
          'application/json': {
            schema: {
              type: 'object',
              properties: {
                otpStatus: {type: 'object'},
                user: {
                  type: 'object',
                  properties: {
                    id: {type: 'string'},
                    email: {type: 'string'},
                    phone: {type: 'string'},
                  },
                },
              },
            },
          },
        },
      },
    },
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Users, {
            title: 'NewUsers',
            exclude: ['id', 'status'],
          }),
        },
      },
    })
    user: Omit<Users, 'id'>,
  ): Promise<any> {
    return this.userServiceExt.create(user);
  }

  @get('/users/byCoachId/{coachId}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of Users model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(Users, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async getUsersByCoachId(
    @param.path.string('coachId') coachId: string,
  ): Promise<Users[]> {
    return this.userServiceExt.getUsersByCoachId(coachId);
  }

  @get('/users/count', {
    responses: {
      '200': {
        description: 'Users model count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async count(
    @param.query.object('where', getWhereSchemaFor(Users)) where?: Where<Users>,
  ): Promise<Count> {
    return this.usersRepository.count(where);
  }

  @get('/users', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of Users model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(Users, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  //@authenticate('jwt')
  async find(
    @param.query.object('filter', getFilterSchemaFor(Users))
    filter?: Filter<Users>,
    @param.query.string('startDate') startDate?: string,
    @param.query.string('endDate') endDate?: string,
    @param.query.number('page') page?: number,
  ): Promise<any> {
    return this.userServiceExt.fetchUserByFilter(
      filter,
      page,
      startDate,
      endDate,
    );
  }

  @post('/users/login', {
    responses: {
      '200': {
        description: 'Token',
        content: {
          'application/json': {
            schema: {
              type: 'object',
              properties: {
                user: getModelSchemaRef(Users, {includeRelations: true}),
                accessToken: {type: 'string'},
                refreshToken: {type: 'string'},
              },
            },
          },
        },
      },
    },
  })
  async login(
    @requestBody(CredentialsRequestBody) credentials: Credentials,
  ): Promise<any> {
    return await this.userServiceExt.userLogin({
      email: credentials.email.toLowerCase,
      ...credentials,
    });
    // const user = await this.userService.verifyCredentials(credentials);
    // if (user.status === 1) {
    //   const userProfile = this.userService.convertToUserProfile(user);
    //   const token = await this.jwtService.generateToken(userProfile);
    //   const onlineObj: AnyObject = {isOnline: true};
    //   await this.usersRepository.updateById(user.id, onlineObj);
    //   await this.loginHistoryRepository.create({
    //     userId: user.id,
    //     loginDateTime: new Date().toString(),
    //     source: credentials.source,
    //     browserAgent: credentials.browserAgent,
    //   });
    //   return {token};
    // }

    // const result = await this.userServiceExt.sendUserOTP(
    //   user.phone,
    //   user.email,
    // );

    // if (result.status === 'Success') {
    //   return {
    //     status: 'Failed',
    //     message:
    //       'Account not activated, kindly use the OTP sent to your email and phone.',
    //   };
    // } else {
    //   return {
    //     status: 'Failed',
    //     message: 'Error, sending OTP request for account not activated.',
    //   };
    // }
  }

  @post('/users/logout', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Logout',
      },
    },
  })
  @authenticate('jwt')
  async logout(
    @inject(SecurityBindings.USER) currentUser: UserProfile,
    @requestBody({
      content: {
        'application/json': {
          schema: {
            type: 'object',
            properties: {
              source: {
                type: 'string',
                enum: Object.values(SourceTypeEnum),
              },
              browserAgent: {type: 'string'},
            },
          },
        },
      },
    })
    credentials: {source: SourceTypeEnum; browserAgent?: string},
  ): Promise<any> {
    return await this.userServiceExt.logout(currentUser, credentials);
  }

  @post('/users/userLogin', {
    responses: {
      '200': {
        description: 'Token',
        content: {
          'application/json': {
            schema: {type: 'object', properties: {token: {type: 'string'}}},
          },
        },
      },
    },
  })
  async userLogin(@requestBody() credentials: AnyObject): Promise<any> {
    const invalidCredentialsError = 'Invalid login credentials.';
    let responseData: AnyObject = {};

    const userDetails = await this.usersRepository.findOne({
      where: {
        or: [
          {phone: credentials?.phone || 'null1'},
          {email: credentials?.email || 'null2'},
        ],
      },
      include: [
        {
          relation: 'subscriptions',
          scope: {
            include: [
              {relation: 'plan'},
              {relation: 'program'},
              {relation: 'payment'},
            ],
          },
        },
      ],
    });
    if (userDetails?.id) {
      responseData = _.omit(Object.assign({}, userDetails), 'password');
      responseData = _.omit(Object.assign({}, userDetails), 'md5password');
      responseData = _.omit(Object.assign({}, userDetails), 'otp');
      const passwordMatched = await this.passwordHasher.comparePassword(
        credentials.password,
        userDetails.password || '---',
      );

      if (
        !passwordMatched &&
        md5(credentials.password) !== userDetails.md5password
      ) {
        throw new HttpErrors.Unauthorized(invalidCredentialsError);
      }

      if (userDetails.status === 1) {
        const userProfile: UserProfile = Object.assign(
          {[securityId]: '', name: '', email: ''},
          {
            [securityId]: userDetails.id,
            name: userDetails.name,
            email: userDetails.email,
          },
        );
        const token = await this.jwtService.generateToken(userProfile);
        const pay: any = await this.paymentRepository.findOne({
          where: {
            userId: userDetails?.id || 'null',
            status: 'success',
          },
          order: ['created DESC'],
        });

        const subs: any = await this.subscriptionRepository.findOne({
          where: {
            userId: userDetails?.id || 'null',
          },
          order: ['created DESC'],
        });

        const selectedPlan = await this.plansRepository.findOne({
          where: {
            id: subs?.subscriptionId || 'null',
          },
          fields: {name: true, id: true},
        });

        let pays: AnyObject = {};
        if (subs?.id && subs?.planName === 'Free') {
          pays = Object.assign({planDuration: ''}, subs);
          pays.planDuration = subs?.planName || '';
          pays.name = selectedPlan?.name || '';
        } else if (subs?.id && _.isEmpty(pay) === true) {
          pays = Object.assign({planDuration: ''}, subs);
          pays.planDuration = subs?.planName || '';
          pays.name = selectedPlan?.name || '';
        } else if (pay?.id) {
          pays = Object.assign(
            {planDuration: '', expireDate: '', name: ''},
            pay,
          );
          pays.planDuration = subs?.planName || '';
          pays.expireDate = subs?.expireDate || null;
          pays.name = selectedPlan?.name || '';
        }
        responseData.payment = pays;
        responseData.token = token;
        return responseData;
      }

      const result = await this.userServiceExt.sendUserOTP(
        userDetails.phone,
        userDetails.email,
      );

      if (result.status === 'Success') {
        return {
          status: 'Failed',
          message:
            'Account not activated, kindly use the OTP sent to your email and phone.',
        };
      } else {
        return {
          status: 'Failed',
          message: 'Error, sending OTP request for account not activated.',
        };
      }
    } else {
      throw new HttpErrors.Unauthorized(invalidCredentialsError);
    }
  }

  @get('/users/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Users model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Users, {includeRelations: true}),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(Users))
    filter?: Filter<Users>,
  ): Promise<any> {
    const userDetails = await this.usersRepository.findById(id, {
      ...filter,
      include: [
        {
          relation: 'subscriptions',
          scope: {
            include: [
              {relation: 'plan'},
              {relation: 'program'},
              {relation: 'payment'},
            ],
          },
        },
      ],
    });

    return userDetails;
  }

  @patch('/users/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Users PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Users, {
            partial: true,
            exclude: ['id', 'email', 'phone'],
          }),
        },
      },
    })
    updates: Omit<Users, 'id, email, phone'>,
  ): Promise<UsersWithRelations> {
    return await this.userServiceExt.updateById(id, updates);
  }

  @get('/users/refresh-token', {
    responses: {
      '200': {
        description: 'token refreshed',
      },
    },
  })
  async refreshUserToken(
    @param.query.string('token')
    token: string,
    @param.query.string('source', {
      schema: {type: 'string', enum: Object.values(SourceTypeEnum)},
    })
    source: SourceTypeEnum,
  ): Promise<AnyObject> {
    return this.userServiceExt.refreshUserToken(token, source);
  }

  @put('/users/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Users PUT success',
      },
    },
  })
  @authenticate('jwt')
  async replaceById(
    @param.path.string('id') id: string,
    @requestBody() users: Users,
  ): Promise<void> {
    await this.usersRepository.replaceById(id, users);
  }

  @del('/users/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Users DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.usersRepository.deleteById(id);
  }

  @post('/users/socialLogin', {
    responses: {
      '200': {
        description: 'Users model instance',
        content: {
          'application/json': {
            schema: {
              type: 'object',
              properties: {
                user: getModelSchemaRef(Users, {includeRelations: true}),
                accessToken: {type: 'string'},
                refreshToken: {type: 'string'},
              },
            },
          },
        },
      },
    },
  })
  async socialLogin(@requestBody() data: any): Promise<any> {
    return this.userServiceExt.socialLogin(data);
    //   if (
    //     !(
    //       data &&
    //       (data.facebookId || data.twitterId || data.googleId || data.appleId)
    //     )
    //   ) {
    //     throw new HttpErrors.UnprocessableEntity('Social Id is required!');
    //   }

    //   if (!data.name || !data.email) {
    //     throw new HttpErrors.UnprocessableEntity(
    //       'Email Address and Name is required!',
    //     );
    //   }

    //   let memberObj: any;
    //   let query: AnyObject = {};
    //   const socailKey = {facebookId: '', twitterId: '', googleId: ''};
    //   if (data.facebookId) {
    //     socailKey['facebookId'] = data.facebookId;
    //     query = {
    //       'social.facebookId': data.facebookId,
    //     };
    //   } else if (data.twitterId) {
    //     socailKey['twitterId'] = data.twitterId;
    //     query = {
    //       'social.twitterId': data.twitterId,
    //     };
    //   } else if (data.googleId) {
    //     socailKey['googleId'] = data.googleId;
    //     query = {
    //       'social.googleId': data.googleId,
    //     };
    //   } else if (data.appleId) {
    //     socailKey['appleId'] = data.appleId;
    //     query = {
    //       'social.appleId': data.appleId,
    //     };
    //   }

    //   let userDetail = await this.usersRepository.findOne({
    //     where: query,
    //     fields: {password: false, md5password: false, social: false},
    //     include: [
    //       {
    //         relation: 'subscriptions',
    //         scope: {
    //           include: [
    //             {relation: 'plan'},
    //             {relation: 'program'},
    //             {relation: 'payment'},
    //           ],
    //         },
    //       },
    //     ],
    //   });

    //   if (userDetail === null) {
    //     // check if the email account already exist
    //     const emailAccountExist = await this.usersRepository.findOne({
    //       where: {email: data.email},
    //       fields: {password: false, md5password: false, social: false},
    //     });

    //     if (emailAccountExist) {
    //       throw new HttpErrors.NotAcceptable('Email account already exist');
    //     }

    //     // split the username for the first and lastname property
    //     data.firstName = data.name.split(' ')[0] ?? '';
    //     data.lastName = data.name.split(' ')[1] ?? '';
    //     // create the account as social login
    //     await this.usersRepository.create({
    //       name: data.name,
    //       firstName: data.firstName,
    //       lastName: data.lastName,
    //       email: data.email,
    //       verificationStatus: 'verified',
    //       password: null,
    //       md5password: null,
    //       social: socailKey,
    //       referralCode: (
    //         await this.userServiceExt.generateReferralCode(data)
    //       ).toString(),
    //     });

    //     userDetail = await this.usersRepository.findOne({
    //       where: query,
    //       fields: {password: false, md5password: false, social: false},
    //       include: [
    //         {
    //           relation: 'subscriptions',
    //           scope: {
    //             include: [
    //               {relation: 'plan'},
    //               {relation: 'program'},
    //               {relation: 'payment'},
    //             ],
    //           },
    //         },
    //       ],
    //     });
    //   }

    //   if (userDetail?.id) {
    //     memberObj = Object.assign({}, userDetail);
    //     const userProfile: UserProfile = Object.assign(
    //       {[securityId]: '', name: '', email: ''},
    //       {
    //         [securityId]: userDetail.id,
    //         name: userDetail.name,
    //         email: userDetail.email,
    //       },
    //     );
    //     const pay: any = await this.paymentRepository.findOne({
    //       where: {
    //         userId: userDetail?.id || 'null',
    //         status: 'success',
    //       },
    //       order: ['created DESC'],
    //     });

    //     const subs: any = await this.subscriptionRepository.findOne({
    //       where: {
    //         userId: userDetail?.id || 'null',
    //       },
    //       order: ['created DESC'],
    //     });
    //     const selectedPlan = await this.plansRepository.findOne({
    //       where: {
    //         id: subs?.subscriptionId || 'nill',
    //       },
    //       fields: {name: true, id: true},
    //     });

    //     let pays: AnyObject = {};
    //     if (subs?.id && subs?.planName === 'Free') {
    //       pays = Object.assign({planDuration: ''}, subs);
    //       pays.planDuration = subs?.planName || '';
    //       pays.name = selectedPlan?.name || '';
    //     } else if (subs?.id && _.isEmpty(pay) === true) {
    //       pays = Object.assign({planDuration: ''}, subs);
    //       pays.planDuration = subs?.planName || '';
    //       pays.name = selectedPlan?.name || '';
    //     } else if (pay?.id) {
    //       pays = Object.assign({planDuration: '', expireDate: '', name: ''}, pay);
    //       pays.planDuration = subs?.planName || '';
    //       pays.expireDate = subs?.expireDate || null;
    //       pays.name = selectedPlan?.name || '';
    //     }
    //     memberObj.token = await this.jwtService.generateToken(userProfile);
    //     memberObj.payment = pays;
    //     const onlineObj: AnyObject = {isOnline: true};
    //     await this.usersRepository.updateById(memberObj.id, onlineObj);
    //     return memberObj;
    //   } else {
    //     throw new HttpErrors.NotFound('User not registered!');
    //   }
  }

  @post('/users/sendOTP', {
    responses: {
      '200': {
        description: 'Generate OTP and send via Email or Phone number',
        content: {
          'application/json': {
            schema: {
              type: 'object',
              properties: {
                status: {type: 'string', enum: ['success', 'failed']},
                message: {type: 'string'},
              },
            },
          },
        },
      },
    },
  })
  async sendOtp(
    @requestBody({
      content: {
        'application/json': {
          schema: {
            type: 'object',
            properties: {email: {type: 'string'}, phone: {type: 'string'}},
          },
        },
      },
    })
    data: {
      email: string;
      phone: string;
    },
  ): Promise<any> {
    const response = await this.userServiceExt.sendUserOTP(
      data.phone,
      data.email.toLowerCase(),
    );
    return response;
  }

  @post('/users/verifyOTP', {
    responses: {
      '200': {
        description: 'Verify the user OTP',
        content: {
          'application/json': {
            schema: {
              type: 'object',
              properties: {
                status: {type: 'string'},
                accessToken: {type: 'string'},
                refreshToken: {type: 'string'},
                user: getModelSchemaRef(Users, {includeRelations: true}),
              },
            },
          },
        },
      },
    },
  })
  async verifyOtp(
    @requestBody({
      content: {
        'application/json': {
          schema: {
            type: 'object',
            properties: {
              email: {type: 'string'},
              phone: {type: 'string'},
              otp: {type: 'string'},
              verificationType: {
                type: 'string',
                enum: ['activation', 'reset'],
              },
            },
          },
        },
      },
    })
    data: {
      email: string;
      phone: string;
      otp: string;
      verificationType: VerificationTypeEnum;
    },
  ): Promise<any> {
    return this.userServiceExt.verifyOtp(data);
  }

  @post('/users/change-password', {
    responses: {
      '200': {
        description: 'Change password after forgot password flow',
        content: {
          'application/json': {
            schema: {
              type: 'object',
              properties: {
                status: {type: 'string'},
              },
            },
          },
        },
      },
    },
  })
  async changePassword(
    @requestBody({
      content: {
        'application/json': {
          schema: {
            type: 'object',
            required: ['id', 'password'],
            properties: {
              password: {type: 'string'},
              id: {type: 'string'},
            },
          },
        },
      },
    })
    data: {
      password: string;
      id: string;
    },
  ): Promise<any> {
    return this.userServiceExt.changePassword(data);
  }

  @post('/users/update-password', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Update user password in-app',
        content: {
          'application/json': {
            schema: {
              type: 'object',
              properties: {
                status: {type: 'string'},
              },
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async updatePassword(
    @requestBody({
      content: {
        'application/json': {
          schema: {
            type: 'object',
            properties: {
              oldPassword: {type: 'string'},
              newPassword: {type: 'string'},
            },
          },
        },
      },
    })
    data: {
      oldPassword: string;
      newPassword: string;
    },
    @inject(SecurityBindings.USER) currentUser: UserProfile,
  ): Promise<any> {
    const userId = currentUser[securityId];
    return this.userServiceExt.updatePassword(userId, data);
  }

  @get('/users/health-passport', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Users recent health passports',
        content: {
          'application/json': {
            schema: {
              type: 'object',
              properties: {
                eyeExamination: getModelSchemaRef(EyeExamination),
                footExamination: getModelSchemaRef(FootExamination),
                pharmacy: getModelSchemaRef(Pharmacy),
                procedure: getModelSchemaRef(HealthProcedureSurgeries, {
                  includeRelations: true,
                }),
                provider: getModelSchemaRef(Provider),
                healthCondition: getModelSchemaRef(HealthCondition),
                medication: getModelSchemaRef(MedicationPassport),
                lab: getModelSchemaRef(LabsProcedures),
              },
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async fetchUserRecentHealthPassport(
    @inject(SecurityBindings.USER) currentUser: UserProfile,
    @param.query.string('memberId') memberId?: string,
  ): Promise<any> {
    const userId = memberId || currentUser[securityId];
    return this.userServiceExt.fetchUserRecentHealthPassport(userId);
  }

  @get('/users/dashboard', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Users model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Users, {includeRelations: true}),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async userDashboard(): Promise<any> {
    let userDashBoard: AnyObject = {};

    return Promise.all([
      this.usersRepository.count(),
      this.appointmentRepository.count(),
      this.subscriptionRepository.count(),
      this.paymentRepository.find({
        where: {
          status: 'success',
        },
      }),
    ])
      .then(res => {
        let totalPayment = res && res[3] && _.sumBy(res[3], v => v.amount);
        userDashBoard = {
          users: (res && res[0]) || 0,
          appointments: (res && res[1]) || 0,
          subscription: (res && res[2]) || 0,
          payments: totalPayment,
        };
        return userDashBoard;
      })
      .catch(err => {
        throw new HttpErrors.UnprocessableEntity('Something went wrong!');
      });
  }

  @get('/users/loginWithPhoneNumber', {
    responses: {
      '200': {
        description: 'Users  success',
      },
    },
  })
  async loginWithPhoneNumber(
    @param.query.string('phoneNumber') phoneNumber?: string,
  ): Promise<any> {
    let responseData: AnyObject = {};
    // currentUser[securityId],
    const userDetails = await this.usersRepository.findOne({
      where: {
        phone: phoneNumber,
      },
      fields: {password: false},
    });
    if (userDetails?.id) {
      if (userDetails.status === 1) {
        let pay: any = await this.paymentRepository.findOne({
          where: {
            userId: userDetails?.id,
            status: 'success',
          },
          order: ['created DESC'],
        });

        let subs = await this.subscriptionRepository.findOne({
          where: {
            userId: userDetails?.id,
            state: 'success',
          },
          order: ['created DESC'],
        });

        let pays: AnyObject = {};
        if (pay?.id) {
          pays = Object.assign({planDuration: '', expired: undefined}, pay);
          pays.expired =
            (subs && subs.expireDate && subs.expireDate) || undefined;
        }

        if (subs?.id && _.isEmpty(pay) === true) {
          pays = Object.assign({planDuration: ''}, subs);
          pays.planDuration = subs?.planName || '';
        }
        const userProfile = this.userService.convertToUserProfile(userDetails);
        const token = await this.jwtService.generateToken(userProfile);
        responseData = Object.assign({}, userDetails);
        responseData.payment = pays;
        responseData.token = token;

        return responseData;
      }

      const result = await this.userServiceExt.sendUserOTP(
        userDetails.phone,
        userDetails.email,
      );

      if (result.status === 'Success') {
        return {
          status: 'Failed',
          message:
            'Account not activated, kindly use the OTP sent to your email and phone.',
        };
      } else {
        return {
          status: 'Failed',
          message: 'Error, sending OTP request for account not activated.',
        };
      }
    } else {
      throw new HttpErrors.NotFound('Phone No not found!');
    }
  }

  @post('/users/getUserList', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Users model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Users, {includeRelations: true}),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async getUserList(@requestBody() data: any): Promise<any> {
    let query: AnyObject = {and: []};
    let anyQuery: AnyObject = {};
    let userData: Array<AnyObject> = [];
    let responseData: AnyObject = {};
    query.and.push({
      status: {inq: ['0', '1']},
    });

    if (data && data.name) {
      query.and.push({
        name: new RegExp('.*' + data.name + '.*', 'i'),
      });
    }
    if (data && data.location) {
      query.and.push({
        or: [
          {['locationInfo.city']: new RegExp('.*' + data.location + '.*', 'i')},
          {
            ['locationInfo.country']: new RegExp(
              '.*' + data.location + '.*',
              'i',
            ),
          },
        ],
      });
    }
    if (data && data.coach) {
      anyQuery = {
        name: new RegExp('.*' + data.coach + '.*', 'i'),
      };
      const coachData = await this.coachRepository.find({
        where: anyQuery,
        fields: {id: true, name: true},
      });
      //if (coachData && coachData.length) {
      const coachId = _.map(coachData, v => v.id);
      query.and.push({
        assignCoachId: {inq: coachId},
      });
      //}
    }
    if (data && data.disease) {
      query.and.push({
        email: new RegExp('.*' + data.disease + '.*', 'i'),
      });
    }
    if (data && data.symptoms) {
      anyQuery = {
        name: new RegExp('.*' + data.symptoms + '.*', 'i'),
      };
      const symptomesDetails = await this.symptomsRepository.find({
        where: anyQuery,
      });
      let symptomIds = _.map(symptomesDetails, v => v.id);
      query.and.push({
        symptomId: {inq: symptomIds},
      });
    }
    const {count} = await this.usersRepository.count({});
    responseData.count = count;
    const userDetails = await this.usersRepository.find({
      where: query,
      order: ['created DESC'],
      limit: data && data.limit ? data.limit : 10,
      skip: data && data.skip ? data.skip : 0,
    });
    if (userDetails && userDetails.length) {
      let coachIds = _.map(userDetails, v => v.assignCoachId);
      let diseaseId = _.map(userDetails, v => v.id);
      let ids = _.map(userDetails, v => v.id);
      let symptomsIds = _.map(userDetails, v => v.id);

      const coachId = _.uniq(_.flatten(coachIds));
      const sIds = _.uniq(_.flatten(symptomsIds));
      const diseaseIds = _.uniq(_.flatten(diseaseId));

      return Promise.all([
        this.coachRepository.find({
          where: {
            id: {inq: coachId},
          },
          fields: {id: true, name: true},
        }),
        this.diseaseRepository.find({
          where: {
            id: {inq: diseaseIds},
          },
          fields: {id: true, name: true},
        }),
        this.subscriptionRepository.find({
          where: {
            userId: {inq: ids},
          },
        }),
        [],
      ])
        .then(async res => {
          let coaches =
            res && res[0] && res[0].length && _.groupBy(res[0], v => v.id);
          let disease =
            res && res[1] && res[1].length && _.groupBy(res[1], v => v.id);
          let subscrption =
            res && res[2] && res[2].length && _.groupBy(res[2], v => v.userId);
          let symptomData =
            res && res[3] && res[3].length && _.groupBy(res[3], v => v.id);

          _.forEach(userDetails, function(val: any) {
            let symptom: Array<any> = [];
            let diseases: Array<any> = [];
            let coache: Array<any> = [];
            let obj: AnyObject = Object.assign({}, val);
            obj.coachDetails =
              (coaches &&
                coaches[val.assignCoachId!] &&
                Object.assign({}, coaches[val.assignCoachId!][0])) ||
              {};
            // obj.diseaseDetails = disease && disease[val.diseaseId!] && Object.assign({}, disease[val.diseaseId!][0]) || {};
            obj.subscrption =
              (subscrption &&
                subscrption[val.id!] &&
                Object.assign({}, subscrption[val.id!][0])) ||
              {};
            // obj.symptom = symptomData && symptomData[val.symptomId!] && Object.assign({}, symptomData[val.symptomId!][0]) || {};

            _.forEach(val.diseaseIds, function(vl: any) {
              diseases.push(
                disease && disease[vl!] && Object.assign({}, disease[vl!][0]),
              );
              obj.diseaseDetails = diseases || [];
            });

            _.forEach(val.symptomsIds, function(v: any) {
              symptom.push(
                symptomData &&
                  symptomData[v!] &&
                  Object.assign({}, symptomData[v!][0]),
              );
              obj.symptoms = symptom || [];
            });

            _.forEach(val.coachIds, function(v: any) {
              coache.push(
                coaches && coaches[v!] && Object.assign({}, coaches[v!][0]),
              );
              obj.coachDetails = coache || [];
            });
            userData.push(obj);
          });
          responseData.users = userData;
          return responseData;
        })
        .catch(err => {
          throw new HttpErrors.UnprocessableEntity('Something went wrong!');
        });
    } else {
      throw new HttpErrors.NotFound('Users not found!');
    }
  }

  @get('/users/usersChart', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of Users model instances',
        content: {
          'application/json': {
            schema: {type: 'array'},
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async usersChart(
    @param.query.string('startDate') startDate?: string,
    @param.query.string('endDate') endDate?: string,
  ): Promise<any> {
    let result: Array<AnyObject> = [];

    let query: AnyObject = {};

    if (startDate) {
      query.created['$gte'] = moment(startDate).toDate();
    }
    if (endDate) {
      query.created['$lte'] = moment(endDate).toDate();
    }

    if (!this.usersRepository.dataSource.connected) {
      await this.usersRepository.dataSource.connect();
    }
    const usersCollection = (this.usersRepository.dataSource
      .connector as any).collection('Users');

    return await Promise.all([
      usersCollection
        .aggregate([
          {$match: query},
          {$sort: {created: -1}},
          {
            $group: {
              _id: {
                month: {$month: '$created'},
              },
              users: {$sum: 1},
            },
          },
        ])
        .get(),
    ])
      .then((res: any) => {
        if (res && res[0] && res[0].length) {
          _.forEach(res[0], function(val, index) {
            result.push({
              name: moment(`${val._id.month}`, 'MM')
                .format('MMMM')
                .valueOf(),
              Existing: val.users,
              New: val.users,
            });
          });
          result = _.sortBy(result, function(v) {
            return v[0];
          }).reverse();
        }

        return result;
      })
      .catch((err: any) => {
        throw new HttpErrors.InternalServerError('Something went wrong!');
      });
  }

  @get('/criticalMembers/{coachId}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of Users model instances',
        content: {
          'application/json': {
            schema: {type: 'array'},
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async criticalMembers(
    @param.path.string('coachId') coachId?: string,
  ): Promise<any> {
    let responseData: Array<any> = [];
    let coachMembers = await this.usersRepository.find({
      where: {
        assignCoachId: coachId,
      },
      fields: {password: false, id: true, name: true},
    });

    if (coachMembers && coachMembers.length) {
      let memIds: Array<any> = _.map(coachMembers, w => w.id);
      let healthDiaries = await this.healthDiaryRepository.find({
        where: {
          userId: {inq: memIds},
          type: 'glucose',
        },
      });

      let bloodPressuries = await this.healthDiaryRepository.find({
        where: {
          userId: {inq: memIds},
          type: 'bloodPressure',
        },
      });

      let healthDiary =
        healthDiaries &&
        healthDiaries.length &&
        _.groupBy(healthDiaries, v => v.userId);
      let bloodPressure =
        bloodPressuries &&
        bloodPressuries.length &&
        _.groupBy(bloodPressuries, w => w.userId);

      _.forEach(coachMembers, function(val: any) {
        let obj = Object.assign({}, val);

        obj.healthDiaries =
          (healthDiary &&
            healthDiary[val.id] &&
            healthDiary[val.id].length &&
            healthDiary[val.id][0]) ||
          {};
        obj.bloodPressure =
          (bloodPressure &&
            bloodPressure[val.id] &&
            bloodPressure[val.id].length &&
            bloodPressure[val.id][0]) ||
          {};

        if (obj && obj.bloodPressure && obj.bloodPressure.id) {
          let pressures: any = obj.bloodPressure.bloodPressure;
          if (
            (pressures && Number(pressures.systolic) > 140) ||
            Number(pressures.diastolic) > 90 ||
            Number(pressures.systolic) < 90 ||
            Number(pressures.diastolic) < 55
          ) {
            obj.condition = 'Critical Condition';
          }
        }
        if (obj && obj.healthDiaries && obj.healthDiaries.id) {
          let healthDiary: any = obj && obj.healthDiaries.glucose;
          if (healthDiary && healthDiary.unit === 'mg/dL') {
            if (
              (healthDiary &&
                healthDiary.breakfast &&
                Number(healthDiary.breakfast.before) > 130) ||
              Number(healthDiary.breakfast.after) > 130 ||
              (healthDiary &&
                healthDiary.lunch &&
                Number(healthDiary.lunch.after) > 130) ||
              Number(healthDiary.lunch.before) > 130 ||
              (healthDiary &&
                healthDiary.dinner &&
                Number(healthDiary.dinner.after) > 130) ||
              Number(healthDiary.dinner.before) > 130 ||
              (healthDiary &&
                healthDiary.snacks &&
                Number(healthDiary.snacks.after) > 130) ||
              Number(healthDiary.snacks.before) > 130
            ) {
              obj.condition = 'Critical Condition';
            } else if (
              (healthDiary &&
                healthDiary.breakfast &&
                Number(healthDiary.breakfast.before) < 69) ||
              Number(healthDiary.breakfast.after) < 69 ||
              (healthDiary &&
                healthDiary.lunch &&
                Number(healthDiary.lunch.after) < 69) ||
              Number(healthDiary.lunch.before) < 69 ||
              (healthDiary &&
                healthDiary.dinner &&
                Number(healthDiary.dinner.after) < 69) ||
              Number(healthDiary.dinner.before) < 69 ||
              (healthDiary &&
                healthDiary.snacks &&
                Number(healthDiary.snacks.after) < 69) ||
              Number(healthDiary.snacks.before) < 69
            ) {
              obj.condition = 'Critical Condition';
            }
          } else if (healthDiary && healthDiary.unit === 'mmol/L') {
            if (
              (healthDiary &&
                healthDiary.breakfast &&
                Number(healthDiary.breakfast.before) < 3.8) ||
              Number(healthDiary.breakfast.after) < 3.8 ||
              (healthDiary &&
                healthDiary.lunch &&
                Number(healthDiary.lunch.after) < 3.8) ||
              Number(healthDiary.lunch.before) < 3.8 ||
              (healthDiary &&
                healthDiary.dinner &&
                Number(healthDiary.dinner.after) < 3.8) ||
              Number(healthDiary.dinner.before) < 3.8 ||
              (healthDiary &&
                healthDiary.snacks &&
                Number(healthDiary.snacks.after) < 3.8) ||
              Number(healthDiary.snacks.before) < 3.8
            ) {
              obj.condition = 'Critical Condition';
            } else if (
              (healthDiary &&
                healthDiary.breakfast &&
                Number(healthDiary.breakfast.before) > 7.2) ||
              Number(healthDiary.breakfast.after) > 7.2 ||
              (healthDiary &&
                healthDiary.lunch &&
                Number(healthDiary.lunch.after) > 7.2) ||
              Number(healthDiary.lunch.before) > 7.2 ||
              (healthDiary &&
                healthDiary.dinner &&
                Number(healthDiary.dinner.after) > 7.2) ||
              Number(healthDiary.dinner.before) > 7.2 ||
              (healthDiary &&
                healthDiary.snacks &&
                Number(healthDiary.snacks.after) > 7.2) ||
              Number(healthDiary.snacks.before) > 7.2
            ) {
              obj.condition = 'Critical Condition';
            }
          }
        }
        responseData.push(obj);
      });
      let filterData = _.filter(responseData, function(val) {
        return val.condition === 'Critical Condition';
      });
      return filterData.length;
    } else {
      return 0;
    }
  }

  @get('/MemberActivityList/{userId}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of Users model instances',
        content: {
          'application/json': {
            schema: {type: 'array'},
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async MemberActivityList(
    @param.path.string('userId') userId?: string,
  ): Promise<any> {
    let responseData: Array<any> = [];
    let result: Array<any> = [];

    return Promise.all([
      this.appointmentRepository.find({
        where: {
          memberId: userId,
        },
        order: ['modified DESC'],
      }),
      this.healthConditionRepository.find({
        where: {
          userId: userId,
        },
        order: ['modified DESC'],
      }),
      this.footExaminationRepository.find({
        where: {
          userId: userId,
        },
        order: ['modified DESC'],
      }),
      this.eyeExaminationRepository.find({
        where: {
          userId: userId,
        },
        order: ['modified DESC'],
      }),

      this.usersRepository.find({
        where: {id: userId},
        fields: {password: false},
        order: ['modified DESC'],
      }),

      await this.healthDiaryRepository.find({
        where: {
          userId: userId,
          type: {neq: 'bmi'},
        },
        order: ['modified DESC'],
      }),
    ])
      .then(res => {
        let appointment =
          res &&
          res[0].length &&
          _.groupBy(
            res[0],
            w => w && w.modified && moment(w.modified).format('DD-MM-YYYY'),
          );
        let healthCondition =
          res &&
          res[1].length &&
          _.groupBy(
            res[1],
            w => w && w.modified && moment(w.modified).format('DD-MM-YYYY'),
          );
        let footExamination =
          res &&
          res[2].length &&
          _.groupBy(
            res[2],
            w => w && w.modified && moment(w.modified).format('DD-MM-YYYY'),
          );
        let eyeExamination =
          res &&
          res[3].length &&
          _.groupBy(
            res[3],
            w => w && w.modified && moment(w.modified).format('DD-MM-YYYY'),
          );
        let healDiary =
          res &&
          res[5].length &&
          _.groupBy(
            res[5],
            w => w && w.modified && moment(w.modified).format('DD-MM-YYYY'),
          );
        let members =
          res &&
          res[4].length &&
          _.groupBy(
            res[4],
            w => w && w.modified && moment(w.modified).format('DD-MM-YYYY'),
          );

        let healthDiaryDate = _.map(res[5], w => moment(w.modified).unix());
        let appointmentDate = _.map(res[0], w => moment(w.modified).unix());
        let healthConditionDate = _.map(res[1], w => moment(w.modified).unix());
        let footDate = _.map(res[2], w => moment(w.modified).unix());
        let eyeDate = _.map(res[3], w => moment(w.modified).unix());
        let memberDate = _.map(res[4], w => moment(w.modified).unix());

        result.push(
          appointmentDate,
          healthDiaryDate,
          memberDate,
          healthConditionDate,
          footDate,
          eyeDate,
        );

        let array: Array<any> = [...new Set([].concat(...result.map(o => o)))];
        let uniqDate: Array<any> = _.uniq(array);
        let sortDate = uniqDate.sort().reverse();

        let newDate: Array<any> = [];
        _.forEach(sortDate, function(vl) {
          newDate.push(moment.unix(vl).format('DD-MM-YYYY'));
        });
        let uniqUnixDate: Array<any> = _.uniq(newDate);
        _.forEach(uniqUnixDate, function(w) {
          let appoint: any =
            (appointment &&
              appointment[w] &&
              appointment[w].length &&
              appointment[w]) ||
            [];
          let htlCond: any =
            (healthCondition &&
              healthCondition[w] &&
              healthCondition[w].length &&
              healthCondition[w]) ||
            [];
          let footExa: any =
            (footExamination &&
              footExamination[w] &&
              footExamination[w].length &&
              footExamination[w]) ||
            [];
          let eyeExa: any =
            (eyeExamination &&
              eyeExamination[w] &&
              eyeExamination[w].length &&
              eyeExamination[w]) ||
            [];
          let healthDiary: any =
            (healDiary &&
              healDiary[w] &&
              healDiary[w].length &&
              healDiary[w]) ||
            [];
          let member: any =
            (members && members[w] && members[w].length && members[w]) || [];
          let newarray = healthDiary.concat(
            member,
            htlCond,
            appoint,
            footExa,
            eyeExa,
          );
          let obj: AnyObject = {
            date: (newarray && newarray.length && w) || '',
            data: newarray,
          };
          responseData.push(obj);
        });
        return responseData;
      })
      .catch(err => {
        console.log(err);
        throw new HttpErrors.UnprocessableEntity('Something went wrong!');
      });
  }

  @get('/sendPasscode', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of Users model instances',
        content: {
          'application/json': {
            schema: {type: 'array'},
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async sendPasscode(): Promise<any> {
    let _this = this;
    let usersList = await this.usersRepository.find();
    if (usersList && usersList.length) {
      return await Promise.all(
        usersList.map(async (val: any, index) => {
          const otp = Math.floor(1000 + Math.random() * 9000);
          var body =
            'Dear ' +
            val.name +
            ', Your  passcode is ' +
            otp +
            ". You may login with the above passcode. Don't share this passcode with anyone.";

          const mailOptions: AnyObject = {
            to: val.email,
            slug: 'passcode-otp',
            message: {
              otp: otp,
              name: val.name,
            },
          };

          let passcode = await this.passwordHasher.hashPassword(String(otp));
          let payload: AnyObject = {
            password: passcode,
          };
          if (val && val.email) {
            this.emailservice.sendMail(mailOptions);
          }
          let result = await this.controllerService.sendOtpService(
            val.mobile,
            body,
          );
          await this.usersRepository.updateById(val.id, payload);
        }),
      );
    }
  }

  // @post('/sendResetPasswordOtp', {
  //   responses: {
  //     '200': {
  //       description: 'User model instance',
  //       content: {
  //         'application/json': {
  //           schema: {type: 'object', properties: {token: {type: 'string'}}},
  //         },
  //       },
  //     },
  //   },
  // })
  // async requestPasswordReset(@requestBody() data: AnyObject): Promise<any> {
  //   if (data && !data.emailPhone) {
  //     throw new HttpErrors.UnprocessableEntity('Email or Mobile  is required!');
  //   }
  //   const userDetail = await this.usersRepository.findOne({
  //     where: {
  //       or: [{email: data.emailPhone}, {phone: data.emailPhone}],
  //     },
  //   });

  //   if (userDetail && userDetail.email) {
  //     let userProfile: UserProfile = Object.assign(
  //       {[securityId]: '', otp: '', email: ''},
  //       {[securityId]: userDetail.id, otp: data.otp, email: userDetail.email},
  //     );

  //     const otp = Math.floor(1000 + Math.random() * 9000);
  //     if (userDetail && String(userDetail.email) === String(data.emailPhone)) {
  //       const mailOptions = {
  //         to: userDetail.email,
  //         slug: 'registration-otp',
  //         message: {
  //           otp: data.otp || otp,
  //         },
  //       };
  //       const emailRes = await this.emailservice.sendMail(mailOptions);
  //       if (emailRes) {
  //         const token = await this.jwtService.generateResetToken(userProfile);
  //         return {token};
  //       } else {
  //         throw new HttpErrors.UnprocessableEntity('Email sending failed!');
  //       }
  //     } else if (
  //       userDetail &&
  //       String(userDetail.phone) === String(data.emailPhone)
  //     ) {
  //       var body =
  //         'Your one time pin(OTP) is ' +
  //         data.otp +
  //         " .It expires in 10 minutes. Don't share this pin with anyone.";
  //       let result = await this.controllerService.sendOtpService(
  //         userDetail.phone,
  //         body,
  //       );
  //       const token = await this.jwtService.generateResetToken(userProfile);
  //       return {token};
  //     }
  //   } else {
  //     throw new HttpErrors.NotFound(`User not found for  ${data.emailPhone}`);
  //   }
  // }

  @get('/reset-password', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'User model instance',
        content: {'application/json': {schema: {type: 'object'}}},
      },
    },
  })
  @authenticate('jwt')
  async resetPassword(
    @param.query.string('password') password: any,
    @inject(SecurityBindings.USER) currentUser: UserProfile,
  ): Promise<void> {
    let obj: AnyObject = {};
    if (!password) {
      throw new HttpErrors.UnprocessableEntity('Password is required!');
    }
    validatePassword(password);

    const user = await this.usersRepository.findOne({
      where: {
        email: (currentUser && currentUser.email) || 'null',
      },
    });

    if (user && user.id) {
      obj.password = await this.passwordHasher.hashPassword(password);
      return await this.usersRepository
        .updateById(user.id, obj)
        .then(async (rs: any) => {
          return rs;
        })
        .catch((er: any) => {
          throw new HttpErrors.UnprocessableEntity(
            `Error in updating User password`,
          );
        });
    } else {
      throw new HttpErrors.NotFound(
        `User not found for Email ${currentUser.email}`,
      );
    }
  }

  @get('/usersMigration', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'User model instance',
      },
    },
  })
  @authenticate('jwt')
  async usersMigration(): Promise<any> {
    const filePath = './public/users_table.csv';

    let usersList = await csv().fromFile(filePath);
    if (usersList && usersList.length) {
      for (let [index, value] of usersList.entries()) {
        if (value && value.emailAddress && value.password) {
          await this.migrationService.userMigration(value);
          if (usersList.length === index + 1) {
            fs.unlinkSync(filePath);
            await this.healthDiaryMigration.healthDairyWeightMigration();
          }
        }
      }
    }
  }

  @post('/upload-profile-pic', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Profile picture uploaded successfully',
      },
    },
  })
  @authenticate('jwt')
  async uploadProfilePicture(
    @inject(SecurityBindings.USER) currentUser: UserProfile,
    @requestBody({
      description: 'multipart/form-data value.',
      required: true,
      content: {
        'multipart/form-data': {
          'x-parser': 'stream',
          schema: {type: 'object'},
        },
      },
    })
    request: Request,
    @inject(RestBindings.Http.RESPONSE) response: Response,
  ) {
    return await this.userServiceExt.uploadProfilePicture(
      request,
      response,
      currentUser,
    );
  }

  @post('/general-image-upload', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'BlogPost model instance',
        content: {
          'application/json': {schema: {file: 'string'}},
        },
      },
    },
  })
  @authenticate('jwt')
  async createWebinar(
    @requestBody({
      content: {
        'multipart/form-data': {
          'x-parser': 'stream',
          schema: {
            type: 'object',
            properties: {
              resource: {type: 'string'},
            },
          },
        },
      },
    })
    request: Request,
    @inject(RestBindings.Http.RESPONSE)
    response: Response,
  ): Promise<any> {
    try {
      return await this.userServiceExt.generalImageUpload(request, response);
    } catch (error) {
      return error;
    }
  }
}
