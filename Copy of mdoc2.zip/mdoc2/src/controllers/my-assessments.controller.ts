import {authenticate} from '@loopback/authentication';
import {
  Count,
  CountSchema,
  Filter,
  repository,
  Where,
} from '@loopback/repository';
import {
  post,
  param,
  get,
  getModelSchemaRef,
  patch,
  put,
  del,
  requestBody,
  getFilterSchemaFor,
} from '@loopback/rest';
import {MyAssessments} from '../models';
import {
  MyAssessmentsRepository,
  UsersRepository,
  UserSubscriptionsRepository,
} from '../repositories';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';
import moment from 'moment';
import fs from 'fs';
export class MyAssessmentsController {
  constructor(
    @repository(MyAssessmentsRepository)
    public myAssessmentsRepository: MyAssessmentsRepository,
    @repository(UsersRepository)
    public usersRepository: UsersRepository,
    @repository(UserSubscriptionsRepository)
    public userSubscriptionsRepository: UserSubscriptionsRepository,
  ) {}

  @post('/my-assessments', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'MyAssessments model instance',
        content: {
          'application/json': {schema: getModelSchemaRef(MyAssessments)},
        },
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(MyAssessments, {
            title: 'NewMyAssessments',
            exclude: ['id'],
          }),
        },
      },
    })
    myAssessments: Omit<MyAssessments, 'id'>,
  ): Promise<MyAssessments> {
    return this.myAssessmentsRepository.create(myAssessments);
  }

  // @get('/my-assessments/count')
  // @response(200, {
  //   description: 'MyAssessments model count',
  //   content: { 'application/json': { schema: CountSchema } },
  // })
  // async count(
  //   @param.where(MyAssessments) where?: Where<MyAssessments>,
  // ): Promise<Count> {
  //   return this.myAssessmentsRepository.count(where);
  // }

  @get('/my-assessments', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'Array of MyAssessments model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(MyAssessments, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async find(
    @param.query.object('filter', getFilterSchemaFor(MyAssessments))
    filter?: Filter<MyAssessments>,
  ): Promise<any> {
    return {};
  }

  // @patch('/my-assessments')
  // @response(200, {
  //   description: 'MyAssessments PATCH success count',
  //   content: { 'application/json': { schema: CountSchema } },
  // })
  // async updateAll(
  //   @requestBody({
  //     content: {
  //       'application/json': {
  //         schema: getModelSchemaRef(MyAssessments, { partial: true }),
  //       },
  //     },
  //   })
  //   myAssessments: MyAssessments,
  //   @param.where(MyAssessments) where?: Where<MyAssessments>,
  // ): Promise<Count> {
  //   return this.myAssessmentsRepository.updateAll(myAssessments, where);
  // }

  @get('/my-assessments/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'MyAssessments model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(MyAssessments, {includeRelations: true}),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(MyAssessments))
    filter?: Filter<MyAssessments>,
  ): Promise<MyAssessments> {
    return this.myAssessmentsRepository.findById(id, filter);
  }

  @patch('/my-assessments/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      204: {
        description: 'MyAssessments PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(MyAssessments, {partial: true}),
        },
      },
    })
    myAssessments: MyAssessments,
  ): Promise<void> {
    await this.myAssessmentsRepository.updateById(id, myAssessments);
  }

  // @put('/my-assessments/{id}')
  // @response(204, {
  //   description: 'MyAssessments PUT success',
  // })
  // async replaceById(
  //   @param.path.string('id') id: string,
  //   @requestBody() myAssessments: MyAssessments,
  // ): Promise<void> {
  //   await this.myAssessmentsRepository.replaceById(id, myAssessments);
  // }

  @del('/my-assessments/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      204: {
        description: 'MyAssessments DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.myAssessmentsRepository.deleteById(id);
  }
}
