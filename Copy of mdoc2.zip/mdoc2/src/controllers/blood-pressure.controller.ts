import {
  get,
  del,
  post,
  param,
  patch,
  requestBody,
  getModelSchemaRef,
  getFilterSchemaFor,
} from '@loopback/rest';
import {inject} from '@loopback/core';
import {BloodPressure} from '../models';
import {Filter} from '@loopback/repository';
import {BloodPressureService} from '../services';
import {PaginatedResponse} from '../type-schema';
import {BloodPressureServiceBindings} from '../keys';
import {authenticate} from '@loopback/authentication';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';

export class BloodPressureController {
  constructor(
    @inject(BloodPressureServiceBindings.BLOODPRESSURE_SERVICE)
    public bloodPressureService: BloodPressureService,
  ) {}

  @post('/blood-pressure', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'BloodPressure model instance',
        content: {
          'application/json': {schema: getModelSchemaRef(BloodPressure)},
        },
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(BloodPressure, {
            title: 'NewBloodPressure',
            exclude: ['id'],
          }),
        },
      },
    })
    bloodPressure: Omit<BloodPressure, 'id'>,
  ): Promise<BloodPressure> {
    return this.bloodPressureService.create(bloodPressure);
  }

  @get('/blood-pressures', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of BloodPressure model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(BloodPressure, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findAll(
    @param.query.object('filter', getFilterSchemaFor(BloodPressure))
    filter?: Filter<BloodPressure>,
    @param.query.number('page') page?: number,
  ): Promise<PaginatedResponse<BloodPressure>> {
    return this.bloodPressureService.findAll(filter, page);
  }

  @get('/blood-pressure/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'BloodPressure model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(BloodPressure, {includeRelations: true}),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(BloodPressure))
    filter?: Filter<BloodPressure>,
  ) {
    return this.bloodPressureService.findById(id, filter);
  }

  @patch('/blood-pressure/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'BloodPressure PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(BloodPressure, {partial: true}),
        },
      },
    })
    bloodPressure: BloodPressure,
  ): Promise<void> {
    return await this.bloodPressureService.updateById(id, bloodPressure);
  }

  @del('/blood-pressure/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'BloodPressure DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    this.bloodPressureService.deleteById(id);
  }
}
