import { authenticate } from '@loopback/authentication';
import { inject } from '@loopback/core';
import { Count, CountSchema, Filter, repository, Where, } from '@loopback/repository';
import { post, param, get, getModelSchemaRef, patch, put, del, requestBody, getFilterSchemaFor, } from '@loopback/rest';
import { MigrationServiceBindings } from '../keys';
import { UserDoctors } from '../models';
import { UserDoctorsRepository } from '../repositories';
import { MigrationService } from '../services/migration.service';
import { OPERATION_SECURITY_SPEC } from '../utils/security-spec';
import csv from 'csvtojson'

export class UserDoctorsController {
  constructor(
    @repository(UserDoctorsRepository) public userDoctorsRepository: UserDoctorsRepository,
    @inject(MigrationServiceBindings.MIGRATION_SERVICE) public migrationService: MigrationService
  ) { }

  @post('/user-doctors', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'UserDoctors model instance',
        content: { 'application/json': { schema: getModelSchemaRef(UserDoctors) } },
      },
    }
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(UserDoctors, {
            title: 'NewUserDoctors',
            exclude: ['id'],
          }),
        },
      },
    })
    userDoctors: Omit<UserDoctors, 'id'>,
  ): Promise<UserDoctors> {
    return this.userDoctorsRepository.create(userDoctors);
  }

  // @get('/user-doctors/count')
  // @response(200, {
  //   description: 'UserDoctors model count',
  //   content: { 'application/json': { schema: CountSchema } },
  // })
  // async count(
  //   @param.where(UserDoctors) where?: Where<UserDoctors>,
  // ): Promise<Count> {
  //   return this.userDoctorsRepository.count(where);
  // }

  @get('/user-doctors', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'Array of UserDoctors model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(UserDoctors, { includeRelations: true }),
            },
          },
        },
      },
    }
  })
  @authenticate('jwt')
  async find(
    @param.query.object('filter', getFilterSchemaFor(UserDoctors)) filter?: Filter<UserDoctors>,
  ): Promise<UserDoctors[]> {
    return this.userDoctorsRepository.find(filter);
  }

  // @patch('/user-doctors', {
  //   responses: {
  //     200: {
  //       description: 'UserDoctors PATCH success count',
  //       content: { 'application/json': { schema: CountSchema } },
  //     },
  //   }
  // })
  // async updateAll(
  //   @requestBody({
  //     content: {
  //       'application/json': {
  //         schema: getModelSchemaRef(UserDoctors, { partial: true }),
  //       },
  //     },
  //   })
  //   userDoctors: UserDoctors,
  //   @param.where(UserDoctors) where?: Where<UserDoctors>,
  // ): Promise<Count> {
  //   return this.userDoctorsRepository.updateAll(userDoctors, where);
  // }

  @get('/user-doctors/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'UserDoctors model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(UserDoctors, { includeRelations: true }),
          },
        },
      },
    }
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(UserDoctors)) filter?: Filter<UserDoctors>,
  ): Promise<UserDoctors> {
    return this.userDoctorsRepository.findById(id, filter);
  }

  @patch('/user-doctors/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      204: {
        description: 'UserDoctors PATCH success',
      },
    }
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(UserDoctors, { partial: true }),
        },
      },
    })
    userDoctors: UserDoctors,
  ): Promise<void> {
    await this.userDoctorsRepository.updateById(id, userDoctors);
  }

  // @put('/user-doctors/{id}')
  // @response(204, {
  //   description: 'UserDoctors PUT success',
  // })
  // async replaceById(
  //   @param.path.string('id') id: string,
  //   @requestBody() userDoctors: UserDoctors,
  // ): Promise<void> {
  //   await this.userDoctorsRepository.replaceById(id, userDoctors);
  // }

  @del('/user-doctors/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      204: {
        description: 'UserDoctors DELETE success',
      },
    }
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.userDoctorsRepository.deleteById(id);
  }

  @get('/userDoctorsMigration', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'UserDoctors Migration success',
      },
    }
  })
  @authenticate('jwt')
  async userDoctorsMigration(
  ): Promise<any> {
    const filePath = './public/user_doctors.csv'

    let usersPhamacyList = await csv().fromFile(filePath);
    if (usersPhamacyList && usersPhamacyList.length) {
      for (const value of usersPhamacyList) {
        await this.migrationService.userDoctorsMigration(value)
      }
    }
  }
}
