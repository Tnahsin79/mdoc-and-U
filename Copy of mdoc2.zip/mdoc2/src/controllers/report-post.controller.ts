import {
  post,
  param,
  get,
  getModelSchemaRef,
  patch,
  put,
  del,
  requestBody,
} from '@loopback/rest';
import {
  Count,
  CountSchema,
  Filter,
  repository,
  Where,
} from '@loopback/repository';
import {ReportPost} from '../models';
import {inject} from '@loopback/context';
import {ReportPostService} from '../services';
import {ReportPostServiceBindings} from '../keys';
import {ReportPostRepository} from '../repositories';
import {authenticate} from '@loopback/authentication';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';

export class ReportPostController {
  constructor(
    @repository(ReportPostRepository)
    public reportpostRepository: ReportPostRepository,
    @inject(ReportPostServiceBindings.REPORT_POST)
    public reportPostService: ReportPostService,
  ) {}

  @post('/report-posts', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Reportpost model instance',
        content: {'application/json': {schema: getModelSchemaRef(ReportPost)}},
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(ReportPost, {
            title: 'NewReportpost',
            exclude: ['id'],
          }),
        },
      },
    })
    reportPost: Omit<ReportPost, 'id'>,
  ): Promise<ReportPost> {
    return this.reportPostService.create(reportPost);
  }

  @get('/report-posts/count', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Reportpost model count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  @authenticate('jwt')
  async count(
    @param.query.object('where') where?: Where<ReportPost>,
  ): Promise<Count> {
    return this.reportPostService.count(where);
  }

  @get('/report-posts', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of Reportpost model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(ReportPost, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async find(
    @param.query.object('filter') filter?: Filter<ReportPost>,
  ): Promise<ReportPost[]> {
    return this.reportPostService.find();
  }

  @patch('/report-posts', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Reportpost PATCH success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  @authenticate('jwt')
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(ReportPost, {partial: true}),
        },
      },
    })
    reportpost: ReportPost,
    @param.query.object('where') where?: Where<ReportPost>,
  ): Promise<Count> {
    return this.reportpostRepository.updateAll(reportpost, where);
  }

  @get('/report-posts/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Reportpost model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(ReportPost, {includeRelations: true}),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', {exclude: 'where'})
    filter?: Filter<ReportPost>,
  ): Promise<ReportPost> {
    return this.reportPostService.findById(id);
  }

  @patch('/report-posts/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Reportpost PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(ReportPost, {partial: true}),
        },
      },
    })
    reportpost: ReportPost,
  ): Promise<void> {
    await this.reportPostService.updateById(id, reportpost);
  }

  @put('/report-posts/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Reportpost PUT success',
      },
    },
  })
  @authenticate('jwt')
  async replaceById(
    @param.path.string('id') id: string,
    @requestBody() reportpost: ReportPost,
  ): Promise<void> {
    await this.reportPostService.replaceById(id, reportpost);
  }

  @del('/report-posts/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Reportpost DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.reportPostService.deleteById(id);
  }
}
