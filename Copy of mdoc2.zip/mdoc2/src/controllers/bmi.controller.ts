import {
  get,
  param,
  getModelSchemaRef,
  getFilterSchemaFor,
} from '@loopback/rest';
import {Bmi} from '../models';
import {inject} from '@loopback/core';
import {BmiService} from '../services';
import {BmiServiceBindings} from '../keys';
import {Filter} from '@loopback/repository';
import {PaginatedResponse} from '../type-schema';
import {authenticate} from '@loopback/authentication';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';
import Utils from '../utils';

export class BmiController {
  constructor(
    @inject(BmiServiceBindings.BMI_SERVICE)
    public bmiService: BmiService,
  ) {}

  @get('/bmi', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of Bmi model instances',
        content: {
          'application/json': {
            schema: Utils.paginatedSchema(Bmi, true),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findAll(
    @param.query.object('filter', getFilterSchemaFor(Bmi))
    filter?: Filter<Bmi>,
    @param.query.number('page') page?: number,
  ): Promise<PaginatedResponse<Bmi>> {
    return this.bmiService.findAll(filter, page);
  }

  @get('/bmi/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Bmi model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Bmi, {includeRelations: true}),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(Bmi))
    filter?: Filter<Bmi>,
  ) {
    return this.bmiService.findById(id, filter);
  }
}
