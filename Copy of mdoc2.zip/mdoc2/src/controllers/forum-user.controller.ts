import {
  post,
  param,
  get,
  getModelSchemaRef,
  patch,
  del,
  requestBody,
  getFilterSchemaFor,
} from '@loopback/rest';
import {ForumUser, ForumUserWithRelations} from '../models';
import {inject} from '@loopback/core';
import {Filter} from '@loopback/repository';
import {ForumUserService} from '../services';
import {ForumUserServiceBindings} from '../keys';
import {PaginatedResponse} from '../type-schema';
import {authenticate} from '@loopback/authentication';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';

export class ForumUserController {
  constructor(
    @inject(ForumUserServiceBindings.FORUMUSER_SERVICE)
    public forumUserService: ForumUserService,
  ) {}
  @post('/forum-user', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'ForumUser model instance',
        content: {
          'application/json': {schema: getModelSchemaRef(ForumUser)},
        },
      },
    },
  })
    @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: {
            type: 'array',
            items: getModelSchemaRef(ForumUser, {
              title: 'NewForumUser',
              exclude: ['id'],
            }),
          }
        },
      },
    })
    forum: Omit<ForumUser, 'id'>[],
  ): Promise<ForumUserWithRelations[]> {
    return this.forumUserService.create(forum);
  }

  @get('/forum-user', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of ForumUser model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(ForumUser, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
    @authenticate('jwt')
  async findAll(
    @param.query.object('filter', getFilterSchemaFor(ForumUser))
    filter?: Filter<ForumUser>,
    @param.query.number('page') page?: number,
  ): Promise<PaginatedResponse<ForumUser>> {
    return this.forumUserService.findAll(filter, page);
  }

  @get('/forum-user/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'ForumUser model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(ForumUser, {includeRelations: true}),
          },
        },
      },
    },
  })
    @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(ForumUser))
    filter?: Filter<ForumUser>,
  ) {
    return this.forumUserService.findById(id, filter);
  }

  @patch('/forum-user/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'ForumUser PATCH success',
      },
    },
  })
    @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(ForumUser, {partial: true}),
        },
      },
    })
    forumUser: ForumUser,
  ): Promise<void> {
    return await this.forumUserService.updateById(id, forumUser);
  }

  @del('/forum-user/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'ForumUser DELETE success',
      },
    },
  })
    @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    return this.forumUserService.deleteById(id);
  }
}
