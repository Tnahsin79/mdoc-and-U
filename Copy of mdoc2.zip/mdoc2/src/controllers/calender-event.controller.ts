import {
  get,
  del,
  post,
  param,
  patch,
  Request,
  Response,
  requestBody,
  RestBindings,
  getModelSchemaRef,
  getFilterSchemaFor,
} from '@loopback/rest';
import {CalenderEvent} from '../models';
import {inject} from '@loopback/context';
import {Filter} from '@loopback/repository';
import {CalenderEventService} from '../services';
import {PaginatedResponse} from '../type-schema';
import {CalenderEventServiceBindings} from '../keys';
import {authenticate} from '@loopback/authentication';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';
import {UserProfile, SecurityBindings} from '@loopback/security';

export class CalenderEventController {
  constructor(
    @inject(CalenderEventServiceBindings.CALENDER_EVENT_SERVICE)
    public calenderEventService: CalenderEventService,
  ) {}

  @post('/calender-events', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '201': {
        description: 'CalenderEvent model instance',
        content: {
          'application/json': {schema: getModelSchemaRef(CalenderEvent)},
        },
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(CalenderEvent, {
            title: 'NewCalenderEvent',
            exclude: ['id', 'status'],
          }),
        },
      },
    })
    calenderEvent: Omit<CalenderEvent, 'id, status'>,
  ): Promise<CalenderEvent> {
    return this.calenderEventService.create(calenderEvent);
  }

  @get('/calender-events/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'CalenderEvent model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(CalenderEvent, {includeRelations: true}),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(CalenderEvent))
    filter?: Filter<CalenderEvent>,
  ): Promise<CalenderEvent> {
    return this.calenderEventService.findById(id, filter);
  }

  @get('/calender-events', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of CalenderEvent model instances',
        content: {
          'application/json': {
            type: 'array',
            items: getModelSchemaRef(CalenderEvent, {
              includeRelations: true,
            }),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async find(
    @param.query.object('filter', getFilterSchemaFor(CalenderEvent))
    filter?: Filter<CalenderEvent>,
  ): Promise<CalenderEvent[]> {
    return this.calenderEventService.find(filter);
  }

  @del('/calender-events/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'CalenderEvent DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    return this.calenderEventService.deleteById(id);
  }

  @patch('/calender-events/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'CalenderEvent PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(CalenderEvent, {partial: true}),
        },
      },
    })
    calenderEvent: CalenderEvent,
  ): Promise<void> {
    await this.calenderEventService.updateById(id, calenderEvent);
  }

  @post('/webinar', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'BlogPost model instance',
        content: {
          'application/json': {schema: getModelSchemaRef(CalenderEvent)},
        },
      },
    },
  })
  @authenticate('jwt')
  async createWebinar(
    @inject(SecurityBindings.USER) currentUser: UserProfile,
    @requestBody({
      content: {
        'multipart/form-data': {
          'x-parser': 'stream',
          schema: {
            type: 'object',
            properties: {
              title: {type: 'string'},
              notes: {type: 'string'},
              registrationLink: {type: 'string'},
              recordedSessionLink: {type: 'string'},
              eventDate: {type: 'string', dataType: 'date'},
              isPublished: {type: 'string', dataType: 'boolean'},
              isPublicEvent: {type: 'string', dataType: 'boolean'},
            },
          },
        },
      },
    })
    request: Request,
    @inject(RestBindings.Http.RESPONSE)
    response: Response,
  ): Promise<any> {
    try {
      return await this.calenderEventService.createWebinar(
        request,
        response,
        currentUser,
      );
    } catch (error) {
      return error;
    }
  }

  @get('/webinars/search', {
    responses: {
      '200': {
        description: 'Array of CalenderEvent model instances',
        content: {
          'application/json': {
            type: 'array',
            items: getModelSchemaRef(CalenderEvent, {
              includeRelations: true,
            }),
          },
        },
      },
    },
  })
  async findBySearch(
    @param.query.number('page') page?: number,
    @param.query.string('search') search?: string,
    @param.query.object('filter', getFilterSchemaFor(CalenderEvent))
    filter?: Filter<CalenderEvent>,
  ): Promise<PaginatedResponse<CalenderEvent>> {
    return this.calenderEventService.findBySearch(page, search, filter);
  }

  @get('/webinar/{id}', {
    responses: {
      '200': {
        description: 'CalenderEvent model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(CalenderEvent, {includeRelations: true}),
          },
        },
      },
    },
  })
  async findWebinarById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(CalenderEvent))
    filter?: Filter<CalenderEvent>,
  ): Promise<CalenderEvent> {
    return this.calenderEventService.findWebinarById(id, filter);
  }

  @get('/webinar-statistics', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'CalenderEvent model instance',
        content: {
          'application/json': {
            schema: {
              type: 'object',
              properties: {
                draftWebinars: {type: 'number'},
                totalWebinars: {type: 'number'},
                publishedWebinars: {type: 'number'},
              },
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async webinarStatistics(): Promise<{
    draftWebinars: number;
    totalWebinars: number;
    publishedWebinars: number;
  }> {
    return this.calenderEventService.webinarStatistics();
  }
}
