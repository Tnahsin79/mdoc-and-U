import { Filter, repository } from '@loopback/repository';
import { post, param, get, getFilterSchemaFor, getModelSchemaRef, del, requestBody, } from '@loopback/rest';
import { Frequency } from '../models';
import { FrequencyRepository } from '../repositories';
import { OPERATION_SECURITY_SPEC } from '../utils/security-spec';
import { authenticate } from '@loopback/authentication';
import { FrequencyServiceBindings } from '../keys';
import { FrequencyService } from '../services/frequency.service';
import { inject } from '@loopback/core';

export class FrequencyController {
  constructor(
    @repository(FrequencyRepository) public frequencyRepository: FrequencyRepository,
    @inject(FrequencyServiceBindings.FREQUENCY_SERVICE)
    public frequencyService: FrequencyService,
  ) { }

  @post('/frequency', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Frequency model instance',
        content: { 'application/json': { schema: getModelSchemaRef(Frequency) } },
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Frequency, {
            title: 'NewFrequency',
            exclude: ['id'],
          }),
        },
      },
    })
    frequency: Omit<Frequency, 'id'>,
  ): Promise<Frequency> {
    return this.frequencyService.create(frequency);
  }

  @get('/frequency', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of Frequency model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(Frequency),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async find(
    @param.query.object('filter', getFilterSchemaFor(Frequency)) filter: Filter<Frequency> = {},
  ): Promise<Frequency[]> {
    return this.frequencyService.find(filter);
  }

  @del('/frequency/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Frequency DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.frequencyService.deleteById(id);
  }
}
