import {
  AnyObject,
  Count,
  CountSchema,
  Filter,
  repository,
  Where,
} from '@loopback/repository';
import {
  post,
  param,
  get,
  getFilterSchemaFor,
  getModelSchemaRef,
  getWhereSchemaFor,
  patch,
  put,
  del,
  requestBody,
} from '@loopback/rest';
import * as _ from 'lodash';
import {CoachType, CoachTypeWithRelations} from '../models/coach-type.model';
import {SpecialityRepository} from '../repositories';
import {CoachTypeRepository} from '../repositories/coach-type.repository';
import {inject} from '@loopback/context';
import {CoachTypeServiceBindings} from '../keys';
import {CoachTypeService} from '../services/coach-type.service';

export class CoachTypeController {
  constructor(
    @repository(CoachTypeRepository)
    public coachTypeRepository: CoachTypeRepository,
    @repository(SpecialityRepository)
    public specialityRepository: SpecialityRepository,
    @inject(CoachTypeServiceBindings.COACH_TYPE_SERVICE)
    public coachTypeService: CoachTypeService,
  ) {}

  @post('/coach-types', {
    responses: {
      '200': {
        description: 'CoachType model instance',
        content: {'application/json': {schema: getModelSchemaRef(CoachType)}},
      },
    },
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(CoachType, {
            title: 'NewCoachType',
            exclude: ['id'],
          }),
        },
      },
    })
    coachType: Omit<CoachType, 'id'>,
  ): Promise<CoachType> {
    return this.coachTypeRepository.create(coachType);
  }

  @get('/coach-types/count', {
    responses: {
      '200': {
        description: 'CoachType model count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async count(
    @param.query.object('where', getWhereSchemaFor(CoachType))
    where?: Where<CoachType>,
  ): Promise<Count> {
    return this.coachTypeRepository.count(where);
  }

  @get('/coach-types', {
    responses: {
      '200': {
        description: 'Array of CoachType model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(CoachType, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  async getAllCoachTypes(): Promise<CoachTypeWithRelations[]> {
    return this.coachTypeService.getAllCoachTypes();
  }

  @patch('/coach-types', {
    responses: {
      '200': {
        description: 'CoachType PATCH success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(CoachType, {partial: true}),
        },
      },
    })
    coachType: CoachType,
    @param.query.object('where', getWhereSchemaFor(CoachType))
    where?: Where<CoachType>,
  ): Promise<Count> {
    return this.coachTypeRepository.updateAll(coachType, where);
  }

  @get('/coach-types/{id}', {
    responses: {
      '200': {
        description: 'CoachType model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(CoachType, {includeRelations: true}),
          },
        },
      },
    },
  })
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(CoachType))
    filter?: Filter<CoachType>,
  ): Promise<CoachType> {
    return this.coachTypeRepository.findById(id, filter);
  }

  @patch('/coach-types/{id}', {
    responses: {
      '204': {
        description: 'CoachType PATCH success',
      },
    },
  })
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(CoachType, {partial: true}),
        },
      },
    })
    coachType: CoachType,
  ): Promise<void> {
    await this.coachTypeRepository.updateById(id, coachType);
  }

  @put('/coach-types/{id}', {
    responses: {
      '204': {
        description: 'CoachType PUT success',
      },
    },
  })
  async replaceById(
    @param.path.string('id') id: string,
    @requestBody() coachType: CoachType,
  ): Promise<void> {
    await this.coachTypeRepository.replaceById(id, coachType);
  }

  @del('/coach-types/{id}', {
    responses: {
      '204': {
        description: 'CoachType DELETE success',
      },
    },
  })
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.coachTypeRepository.deleteById(id);
  }
}
