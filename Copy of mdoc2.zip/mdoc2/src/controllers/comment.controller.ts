import {
  get,
  del,
  post,
  param,
  patch,
  requestBody,
  getModelSchemaRef,
  getWhereSchemaFor,
  getFilterSchemaFor,
} from '@loopback/rest';
import Utils from '../utils';
import {Comment} from '../models';
import {inject} from '@loopback/core';
import {LikeAndDislike} from '../utils/type';
import {CommentServiceBindings} from '../keys';
import {PaginatedResponse} from '../type-schema';
import {authenticate} from '@loopback/authentication';
import {CommentService} from '../services/comment.service';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';
import {Where, Count, Filter, CountSchema} from '@loopback/repository';

export class CommentController {
  constructor(
    @inject(CommentServiceBindings.COMMENT_SERVICE)
    public commentService: CommentService,
  ) {}

  @post('/comments', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Comment model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Comment, {includeRelations: true}),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Comment, {
            title: 'NewComment',
            exclude: ['id'],
          }),
        },
      },
    })
    comment: Omit<Comment, 'id'>,
  ): Promise<any> {
    return await this.commentService.create(comment);
  }

  @get('/comments/count', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Comment model count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  @authenticate('jwt')
  async count(
    @param.query.object('where', getWhereSchemaFor(Comment))
    where?: Where<Comment>,
  ): Promise<Count> {
    return this.commentService.count(where);
  }

  @get('/comments/{resourceId}', {
    responses: {
      '200': {
        description: 'Array of Comment model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: Utils.paginatedSchema(Comment, true),
            },
          },
        },
      },
    },
  })
  async find(
    @param.path.string('resourceId') resourceId: string,
    @param.query.object('filter', getFilterSchemaFor(Comment))
    filter?: Filter<Comment>,
    @param.query.number('page') page?: number,
    @param.query.boolean('reverse') reverse?: boolean,
  ): Promise<PaginatedResponse<Comment>> {
    return this.commentService.find(resourceId, filter, page, reverse);
  }

  @get('/comments/replies/{id}', {
    responses: {
      '200': {
        description: 'Array of Comment model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(Comment, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  async getCommentReplies(
    @param.path.string('id') id: string,
  ): Promise<Comment[]> {
    return this.commentService.getCommentReplies(id);
  }

  @get('/comment/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Comment model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Comment, {includeRelations: true}),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findById(@param.path.string('id') id: string): Promise<Comment> {
    return this.commentService.findById(id);
  }

  @patch('/comments/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Comment PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Comment, {partial: true}),
        },
      },
    })
    comment: Comment,
  ): Promise<void> {
    await this.commentService.updateById(id, comment);
  }

  @del('/comments/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Comment DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.commentService.deleteById(id);
  }

  @post('/addLike', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Comment Like success',
      },
    },
  })
  @authenticate('jwt')
  async addLike(
    @requestBody({
      content: {
        'application/json': {
          schema: {
            type: 'object',
            properties: {userId: {type: 'string'}, commentId: {type: 'string'}},
          },
        },
      },
    })
    like: LikeAndDislike,
  ) {
    return await this.commentService.addLike(like);
  }

  @post('/addDislike', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Comment Dislike success',
      },
    },
  })
  @authenticate('jwt')
  async addDisLike(
    @requestBody({
      content: {
        'application/json': {
          schema: {
            type: 'object',
            properties: {userId: {type: 'string'}, commentId: {type: 'string'}},
          },
        },
      },
    })
    dislike: LikeAndDislike,
  ) {
    return await this.commentService.addDisLike(dislike);
  }
}
