import {
  post,
  param,
  get,
  getModelSchemaRef,
  patch,
  del,
  requestBody,
  getFilterSchemaFor,
} from '@loopback/rest';
import {Psa} from '../models';
import {inject} from '@loopback/core';
import {PsaService} from '../services';
import {PsaServiceBindings} from '../keys';
import {Filter} from '@loopback/repository';
import {PaginatedResponse} from '../type-schema';
import {authenticate} from '@loopback/authentication';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';

export class PsaController {
  constructor(
    @inject(PsaServiceBindings.PSA_SERVICE)
    public psaService: PsaService,
  ) {}

  @post('/psa', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Psa model instance',
        content: {
          'application/json': {schema: getModelSchemaRef(Psa)},
        },
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Psa, {
            title: 'NewPsa',
            exclude: ['id'],
          }),
        },
      },
    })
    psa: Omit<Psa, 'id'>,
  ): Promise<Psa> {
    return this.psaService.create(psa);
  }

  @get('/psa', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of Psa model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(Psa, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findAll(
    @param.query.object('filter', getFilterSchemaFor(Psa))
    filter?: Filter<Psa>,
    @param.query.number('page') page?: number,
  ): Promise<PaginatedResponse<Psa>> {
    return this.psaService.findAll(filter, page);
  }

  @get('/psa/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Psa model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Psa, {includeRelations: true}),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(Psa))
    filter?: Filter<Psa>,
  ) {
    return this.psaService.findById(id, filter);
  }

  @patch('/psa/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Psa PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Psa, {partial: true}),
        },
      },
    })
    psa: Psa,
  ): Promise<void> {
    return await this.psaService.updateById(id, psa);
  }

  @del('/psa/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Psa DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    this.psaService.deleteById(id);
  }
}
