import {
  get,
  del,
  post,
  param,
  patch,
  Request,
  Response,
  requestBody,
  RestBindings,
  getModelSchemaRef,
  getFilterSchemaFor,
} from '@loopback/rest';
import {
  LikeRepository,
  UsersRepository,
  CommentRepository,
  BlogPostRepository,
  InterestRepository,
} from '../repositories';
import * as _ from 'lodash';
import Utils from '../utils';
import {BlogPost} from '../models';
import {inject} from '@loopback/core';
import {OrderEnum} from '../utils/enums';
import {BlogPostServiceBindings} from '../keys';
import {PaginatedResponse} from '../type-schema';
import {authenticate} from '@loopback/authentication';
import {Filter, repository} from '@loopback/repository';
import {BlogPostService} from '../services/blog-post.service';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';
import {UserProfile, SecurityBindings} from '@loopback/security';
export class BlogPostController {
  constructor(
    @repository(BlogPostRepository)
    public blogPostRepository: BlogPostRepository,
    @repository(LikeRepository) public likeRepository: LikeRepository,
    @repository(CommentRepository) public commentRepository: CommentRepository,
    @repository(InterestRepository)
    public interestRepository: InterestRepository,
    @repository(UsersRepository) public usersRepository: UsersRepository,
    @inject(BlogPostServiceBindings.BLOG_POST_SERVICE)
    public blogPostService: BlogPostService,
  ) {}

  @post('/blog-posts', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'BlogPost model instance',
        content: {'application/json': {schema: getModelSchemaRef(BlogPost)}},
      },
    },
  })
  @authenticate('jwt')
  async create(
    @inject(SecurityBindings.USER) currentUser: UserProfile,
    @requestBody({
      content: {
        'multipart/form-data': {
          'x-parser': 'stream',
          schema: {
            type: 'object',
            properties: {
              title: {type: 'string'},
              status: {type: 'number'},
              description: {type: 'string'},
              content: {type: 'string'},
              order: {type: 'number'},
              postedDate: {type: 'string', dataType: 'date'},
            },
          },
        },
      },
    })
    request: Request,
    @inject(RestBindings.Http.RESPONSE)
    response: Response,
  ): Promise<any> {
    try {
      return await this.blogPostService.create(request, response, currentUser);
    } catch (error) {
      return error;
    }
  }

  @get('/blog-posts', {
    responses: {
      '200': {
        description: 'Array of BlogPost model instances',
        content: {
          'application/json': {
            schema: Utils.paginatedSchema(BlogPost, true),
          },
        },
      },
    },
  })
  async find(
    @param.query.string('order') order: OrderEnum,
    @param.query.string('search') search?: string,
    @param.query.string('startDate') startDate?: string,
    @param.query.string('endDate') endDate?: string,
    @param.query.object('filter', getFilterSchemaFor(BlogPost))
    filter?: Filter<BlogPost>,
    @param.query.number('page') page?: number,
  ): Promise<PaginatedResponse<BlogPost>> {
    return await this.blogPostService.find(
      order,
      search,
      filter,
      page,
      startDate,
      endDate,
    );
  }

  @get('/blog-posts/{id}', {
    responses: {
      '200': {
        description: 'BlogPost model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(BlogPost, {includeRelations: true}),
          },
        },
      },
    },
  })
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(BlogPost))
    filter?: Filter<BlogPost>,
  ): Promise<any> {
    return await this.blogPostService.findById(id, filter);
  }

  @get('/blog-post-slug/{slug}', {
    responses: {
      '200': {
        description: 'BlogPost model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(BlogPost, {includeRelations: true}),
          },
        },
      },
    },
  })
  async findBySlug(@param.path.string('slug') slug: string): Promise<any> {
    return await this.blogPostService.findBySlug(slug);
  }

  @patch('/blog-posts/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'BlogPost PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(BlogPost, {
            partial: true,
            exclude: ['id', 'creatorId', 'created_at'],
          }),
        },
      },
    })
    post: Omit<BlogPost, 'id, creatorId, created_at'>,
  ): Promise<any> {
    return await this.blogPostService.updateById(id, post);
  }

  @patch('/blog-posts/bulk', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'BlogPost PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async bulkUpdate(
    @requestBody({
      content: {
        'application/json': {
          schema: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                id: {
                  type: 'string',
                },
                order: {
                  type: 'number',
                },
              },
              required: ['id', 'order'],
            },
          },
        },
      },
    })
    payload: Array<{id: string; order: number}>,
  ): Promise<any> {
    return await this.blogPostService.bulkUpdate(payload);
  }

  @del('/blog-posts/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'BlogPost DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.blogPostService.deleteById(id);
  }
}
