import {
  get,
  del,
  post,
  param,
  patch,
  requestBody,
  getModelSchemaRef,
  getFilterSchemaFor,
} from '@loopback/rest';
import {Cholestrol} from '../models';
import {inject} from '@loopback/core';
import {Filter} from '@loopback/repository';
import {CholestrolService} from '../services';
import {CholestrolServiceBindings} from '../keys';
import {PaginatedResponse} from '../type-schema';
import {authenticate} from '@loopback/authentication';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';
export class CholestrolController {
  constructor(
    @inject(CholestrolServiceBindings.CHOLESTROL_SERVICE)
    public cholestrolService: CholestrolService,
  ) {}

  @post('/cholestrol', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Cholestrol model instance',
        content: {
          'application/json': {schema: getModelSchemaRef(Cholestrol)},
        },
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Cholestrol, {
            title: 'NewCholestrol',
            exclude: ['id'],
          }),
        },
      },
    })
    cholestrol: Omit<Cholestrol, 'id'>,
  ): Promise<Cholestrol> {
    return this.cholestrolService.create(cholestrol);
  }

  @get('/cholestrol', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of Cholestrol model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(Cholestrol, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findAll(
    @param.query.object('filter', getFilterSchemaFor(Cholestrol))
    filter?: Filter<Cholestrol>,
    @param.query.number('page') page?: number,
  ): Promise<PaginatedResponse<Cholestrol>> {
    return this.cholestrolService.findAll(filter, page);
  }

  @get('/cholestrol/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Cholestrol model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Cholestrol, {includeRelations: true}),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(Cholestrol))
    filter?: Filter<Cholestrol>,
  ) {
    return this.cholestrolService.findById(id, filter);
  }

  @patch('/cholestrol/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Cholestrol PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Cholestrol, {partial: true}),
        },
      },
    })
    cholestrol: Cholestrol,
  ): Promise<void> {
    return await this.cholestrolService.updateById(id, cholestrol);
  }

  @del('/cholestrol/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Cholestrol DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    this.cholestrolService.deleteById(id);
  }
}
