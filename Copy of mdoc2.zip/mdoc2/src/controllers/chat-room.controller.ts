import {
  Count,
  CountSchema,
  Filter,
  repository,
  Where,
  AnyObject,
} from '@loopback/repository';
import {
  post,
  param,
  get,
  getFilterSchemaFor,
  getModelSchemaRef,
  getWhereSchemaFor,
  patch,
  put,
  del,
  requestBody,
  HttpErrors,
} from '@loopback/rest';
import {
  Chat,
  ChatRoom,
  ChatRoomWithRelations,
  ChatWithRelations,
} from '../models';
import {ChatRoomRepository} from '../repositories';
import * as _ from 'lodash';
import {inject} from '@loopback/context';
import {ChatRoomServiceBindings} from '../keys';
import {ChatRoomService} from '../services/chat-room.service';
import {PaginatedResponse} from '../type-schema';
import Utils from '../utils';
import {authenticate} from '@loopback/authentication';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';
import {UserProfile, securityId, SecurityBindings} from '@loopback/security';
export class ChatRoomController {
  constructor(
    @repository(ChatRoomRepository)
    public chatRoomRepository: ChatRoomRepository,
    @inject(ChatRoomServiceBindings.CHAT_ROOM_SERVICE)
    public chatRoomService: ChatRoomService,
  ) {}

  @post('/chat-rooms', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'ChatRoom model instance',
        content: {'application/json': {schema: getModelSchemaRef(ChatRoom)}},
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(ChatRoom, {
            title: 'NewChatRoom',
            exclude: ['id'],
          }),
        },
      },
    })
    chatRoom: Omit<ChatRoom, 'id'>,
  ): Promise<any> {
    return this.chatRoomService.create(chatRoom);
  }

  @get('/chat-rooms/single-room/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'ChatRoom model instances',
        content: {
          'application/json': {
            schema: getModelSchemaRef(ChatRoom, {includeRelations: true}),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async getSingleChatroom(
    @param.query.string('type', {schema: {enum: ['user', 'coach']}})
    type: 'coach' | 'user',
    @param.path.string('id')
    id: string,
    @inject(SecurityBindings.USER) currentUser: UserProfile,
  ): Promise<ChatRoom> {
    const payload =
      type === 'coach'
        ? {coachId: currentUser[securityId], userId: id}
        : {userId: currentUser[securityId], coachId: id};
    return await this.chatRoomService.getSingleChatroom(payload);
  }

  @get('/chat-rooms/summary/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Chat settings summary',
        content: {
          'application/json': {
            schema: {
              type: 'object',
              properties: {
                chatRoom: getModelSchemaRef(ChatRoom),
                resources: {
                  type: 'array',
                  items: {
                    type: 'string',
                  },
                },
                users: {
                  type: 'array',
                  items: {
                    type: 'object',
                    properties: {
                      id: {type: 'string'},
                      name: {type: 'string'},
                      email: {type: 'string'},
                      phone: {type: 'string'},
                      image: {type: 'string'},
                    },
                  },
                },
                coach: {
                  type: 'object',
                  properties: {
                    id: {type: 'string'},
                    name: {type: 'string'},
                    image: {type: 'string'},
                  },
                },
              },
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async getSummary(
    @param.path.string('id') id: string,
    @param.query.string('userId')
    userId: string,
  ): Promise<any> {
    return this.chatRoomService.getSummary(id, userId);
  }

  @get('/chat-rooms/userList/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'User last chats',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(ChatRoom, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async getChatUserList(
    @param.path.string('id') id: string,
  ): Promise<Partial<ChatRoomWithRelations>[]> {
    return this.chatRoomService.getChatUserList(id);
  }

  @get('/chat-rooms/coach-user-list/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Coach chat list',
        content: {
          'application/json': {
            schema: Utils.paginatedSchema(ChatRoom, true),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async getCoachChatList(
    @param.path.string('id') id: string,
    @param.query.string('type', {
      schema: {type: 'string', enum: ['direct', 'group']},
    })
    type: 'direct' | 'group' = 'direct',
    @param.query.object('filter', getFilterSchemaFor(ChatRoom))
    filter?: Filter<ChatRoom>,
    @param.query.number('page') page?: number,
    @param.query.string('search') search?: string,
  ): Promise<PaginatedResponse<ChatRoomWithRelations>> {
    return this.chatRoomService.getCoachChatList(
      id,
      type,
      filter,
      page,
      search,
    );
  }

  @get('/chat-rooms/count', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'ChatRoom model count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  @authenticate('jwt')
  async count(
    @param.query.object('where', getWhereSchemaFor(ChatRoom))
    where?: Where<ChatRoom>,
  ): Promise<Count> {
    // const records = await this.chatRoomRepository.find({
    //   where: {
    //     type: 'direct',
    //     userFullName: 'xx xx'
    //   },
    //     include: [{relation: 'receiverMember', scope: {fields: {id: true, firstName: true, lastName: true}}}]
    // });
    // const records = await this.chatRoomRepository.find({
    //   where: {
    //     type: 'direct',
    //   },
    //   include: [{relation: 'receiverMember', scope: {fields: {id: true, firstName: true, lastName: true}}}]
    // });
    // for (let i = 0; i < records.length; i++) {
    //   const item = records[i];
    //   await this.chatRoomRepository.updateById(item.id, {
    //     userFullName: `${item.receiverMember?.firstName || 'xx'} ${item.receiverMember?.lastName || 'xx'}`
    //   });
    // }

    return this.chatRoomRepository.count(where);
  }

  @get('/chat-rooms', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of ChatRoom model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(ChatRoom, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async find(
    @param.query.object('filter', getFilterSchemaFor(ChatRoom))
    filter?: Filter<ChatRoom>,
  ): Promise<ChatRoom[]> {
    return await this.chatRoomService.find(filter);
  }

  @patch('/chat-rooms', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'ChatRoom PATCH success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  @authenticate('jwt')
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(ChatRoom, {partial: true}),
        },
      },
    })
    chatRoom: ChatRoom,
    @param.query.object('where', getWhereSchemaFor(ChatRoom))
    where?: Where<ChatRoom>,
  ): Promise<Count> {
    return this.chatRoomRepository.updateAll(chatRoom, where);
  }

  @get('/chat-rooms/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'ChatRoom model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(ChatRoom, {includeRelations: true}),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(ChatRoom))
    filter?: Filter<ChatRoom>,
  ): Promise<ChatRoom> {
    return this.chatRoomRepository.findById(id, filter);
  }

  @patch('/chat-rooms/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'ChatRoom PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(ChatRoom, {partial: true}),
        },
      },
    })
    chatRoom: ChatRoom,
  ): Promise<void> {
    await this.chatRoomRepository.updateById(id, chatRoom);
  }

  @put('/chat-rooms/{id}', {
    responses: {
      '204': {
        description: 'ChatRoom PUT success',
      },
    },
  })
  @authenticate('jwt')
  async replaceById(
    @param.path.string('id') id: string,
    @requestBody() chatRoom: ChatRoom,
  ): Promise<void> {
    await this.chatRoomRepository.replaceById(id, chatRoom);
  }

  @del('/chat-rooms/{id}', {
    responses: {
      '204': {
        description: 'ChatRoom DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.chatRoomRepository.deleteById(id);
  }
}
