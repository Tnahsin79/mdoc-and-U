import {
  get,
  del,
  post,
  patch,
  param,
  requestBody,
  getModelSchemaRef,
  getFilterSchemaFor,
} from '@loopback/rest';
import {Height} from '../models';
import {inject} from '@loopback/core';
import {HeightService} from '../services';
import {Filter} from '@loopback/repository';
import {HeightServiceBindings} from '../keys';
import {PaginatedResponse} from '../type-schema';
import {authenticate} from '@loopback/authentication';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';
import Utils from '../utils';

export class HeightController {
  constructor(
    @inject(HeightServiceBindings.HEIGHT_SERVICE)
    public heightService: HeightService,
  ) {}

  @post('/height', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Height model instance',
        content: {
          'application/json': {schema: getModelSchemaRef(Height)},
        },
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Height, {
            title: 'NewHeight',
            exclude: ['id', 'defaultValue', 'defaultUnit'],
          }),
        },
      },
    })
    height: Omit<Height, 'id, defaultValue, defaultUnit'>,
  ): Promise<Height> {
    return this.heightService.create(height);
  }

  @get('/height', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of Height model instances',
        content: {
          'application/json': {
            schema: Utils.paginatedSchema(Height, true),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findAll(
    @param.query.object('filter', getFilterSchemaFor(Height))
    filter?: Filter<Height>,
    @param.query.number('page') page?: number,
  ): Promise<PaginatedResponse<Height>> {
    return this.heightService.findAll(filter, page);
  }

  @get('/height/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Height model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Height, {includeRelations: true}),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(Height))
    filter?: Filter<Height>,
  ) {
    return this.heightService.findById(id, filter);
  }

  @patch('/height/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Height PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Height, {
            partial: true,
            exclude: ['id', 'defaultValue', 'defaultUnit', 'modified_at'],
          }),
        },
      },
    })
    height: Height,
  ): Promise<void> {
    return await this.heightService.updateById(id, height);
  }

  @del('/height/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Height DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    this.heightService.deleteById(id);
  }
}
