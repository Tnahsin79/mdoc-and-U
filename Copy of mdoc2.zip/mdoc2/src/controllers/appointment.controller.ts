import {CoachRepository} from './../repositories/coach.repository';
import {FCMService} from './../services/fcm.service';
import {OPERATION_SECURITY_SPEC} from './../utils/security-spec';
import {
  Appointment,
  AppointmentWithRelations,
} from './../models/appointment.model';
import {inject} from '@loopback/context';
import {
  Count,
  CountSchema,
  Filter,
  repository,
  Where,
  AnyObject,
} from '@loopback/repository';
import {
  post,
  param,
  get,
  getFilterSchemaFor,
  getModelSchemaRef,
  getWhereSchemaFor,
  patch,
  put,
  del,
  requestBody,
  HttpErrors,
} from '@loopback/rest';
// import { Appointment } from '../models';
import {UserProfile, securityId, SecurityBindings} from '@loopback/security';

import {
  AppointmentRepository,
  UsersRepository,
  DiseaseRepository,
  SymptomsRepository,
} from '../repositories';
import * as _ from 'lodash';
import moment from 'moment';
import {authenticate} from '@loopback/authentication';
import {AppointmentServiceBindings, FCMServiceBindings} from '../keys';
import {AppointmentService} from '../services/appointment.service';
export class AppointmentController {
  constructor(
    @repository(AppointmentRepository)
    public appointmentRepository: AppointmentRepository,
    @repository(UsersRepository) public userRepository: UsersRepository,
    @repository(DiseaseRepository) public diseaseRepository: DiseaseRepository,
    @repository(SymptomsRepository)
    public symptomsRepository: SymptomsRepository,
    @inject(FCMServiceBindings.FCM_SERVICE) public fcmServices: FCMService,
    @inject(AppointmentServiceBindings.APPOINTMENT_SERVICE)
    public appointmentService: AppointmentService,
    @repository(CoachRepository) public coachRepository: CoachRepository,
  ) {}

  @post('/appointments', {
    responses: {
      '200': {
        description: 'Appointment model instance',
        content: {'application/json': {schema: getModelSchemaRef(Appointment)}},
      },
    },
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Appointment, {
            title: 'NewAppointment',
            exclude: ['id'],
          }),
        },
      },
    })
    appointment: Omit<Appointment, 'id'>,
  ): Promise<Appointment> {
    if (appointment && appointment.memberId) {
      let user = await this.userRepository.findOne({
        where: {id: appointment.memberId},
      });
      if (user && user.id) {
        let coach = await this.coachRepository.findOne({
          where: {id: appointment.coachId},
        });
        let messages = `Hello Sir/Madam ${user &&
          user.name}, this is to inform you, your appointment has been scheduled with your
           coach ${(coach && coach.name) || ''}  on ${moment(
          appointment && appointment.appointmentDate,
        ).format('DD-MM-YYYY')} at
           ${appointment && appointment.appointmentTime + ' UTC'}. mDoc cares.`;

        var message = {
          to: (user && user.fcmToken) || '',
          data: {
            name: user.name,
            userId: user.id,
            type: 'userDetail',
          },
          notification: {
            title: 'New Appointment',
            body: messages,
            priority: 'high',
            sound: 'default',
            vibrate: true,
          },
        };
        await this.fcmServices.sendNotification({message: message});
      }
    }
    let booking = Math.floor(100000 + Math.random() * 900000);
    appointment.bookingId = 'BK' + booking;
    let appointments = _.omitBy(appointment, 'coachName');
    // coachName
    return this.appointmentRepository.create(appointments);
  }

  @get('/appointments/count', {
    responses: {
      '200': {
        description: 'Appointment model count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async count(
    @param.query.object('where', getWhereSchemaFor(Appointment))
    where?: Where<Appointment>,
  ): Promise<Count> {
    return this.appointmentRepository.count(where);
  }

  @get('/appointments', {
    responses: {
      '200': {
        description: 'Array of Appointment model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(Appointment, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  async find(
    @param.query.object('filter', getFilterSchemaFor(Appointment))
    filter?: Filter<Appointment>,
  ): Promise<Appointment[]> {
    return this.appointmentRepository.find({
      ...(filter || {}),
      include: [{relation: 'coach', scope: {
        fields: {
          id: true,
          name: true,
          image: true,
          email: true
        }
      }}],
    });
  }

  @patch('/appointments', {
    responses: {
      '200': {
        description: 'Appointment PATCH success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Appointment, {partial: true}),
        },
      },
    })
    appointment: Appointment,
    @param.query.object('where', getWhereSchemaFor(Appointment))
    where?: Where<Appointment>,
  ): Promise<Count> {
    return this.appointmentRepository.updateAll(appointment, where);
  }

  @get('/appointments/{id}', {
    responses: {
      '200': {
        description: 'Appointment model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Appointment, {includeRelations: true}),
          },
        },
      },
    },
  })
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(Appointment))
    filter?: Filter<Appointment>,
  ): Promise<Appointment> {
    return this.appointmentRepository.findById(id, filter);
  }

  @patch('/appointments/{id}', {
    responses: {
      '204': {
        description: 'Appointment PATCH success',
      },
    },
  })
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Appointment, {partial: true}),
        },
      },
    })
    appointment: Appointment,
  ): Promise<void> {
    await this.appointmentRepository.updateById(id, appointment);
  }

  @put('/appointments/{id}', {
    responses: {
      '204': {
        description: 'Appointment PUT success',
      },
    },
  })
  async replaceById(
    @param.path.string('id') id: string,
    @requestBody() appointment: Appointment,
  ): Promise<void> {
    await this.appointmentRepository.replaceById(id, appointment);
  }

  @del('/appointments/{id}', {
    responses: {
      '204': {
        description: 'Appointment DELETE success',
      },
    },
  })
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.appointmentRepository.deleteById(id);
  }

  @post('/appointments/getAppointmentList', {
    responses: {
      '200': {
        description: 'Appointment  success',
      },
    },
  })
  async getAppointmentList(@requestBody() data: any): Promise<any> {
    let query: AnyObject = {and: []};
    query.and.push({
      status: {inq: [0, 1, 2, 3, 4]},
    });
    let anyQuery: AnyObject = {};
    let responseData: Array<AnyObject> = [];

    if (data && data.userName) {
      anyQuery = {
        name: new RegExp('.*' + data.userName + '.*', 'i'),
      };
      const users = await this.userRepository.find({
        where: anyQuery,
        fields: {id: true, name: true},
      });
      let userIds = _.map(users, v => v.id);
      query.and.push({
        userId: {inq: userIds},
      });
    }
    if (data && data.disease) {
      anyQuery = {
        name: new RegExp('.*' + data.disease + '.*', 'i'),
      };
      const disease = await this.diseaseRepository.find({
        where: anyQuery,
        fields: {id: true, name: true},
      });
      const diseaseId = _.map(disease, v => v.id);
      query.and.push({
        diseaseId: {inq: diseaseId},
      });
    }
    if (data && data.symptoms) {
      anyQuery = {
        name: new RegExp('.*' + data.symptoms + '.*', 'i'),
      };
      let symptoms = await this.symptomsRepository.find({
        where: anyQuery,
        fields: {id: true, name: true},
      });

      const symptomId = _.map(symptoms, v => v.id);
      query.and.push({
        symptomId: {inq: symptomId},
      });
    }
    if (data && data.bookingId) {
      query.and.push({
        bookingId: new RegExp('.*' + data.bookingId + '.*', 'i'),
      });
    }
    if (data && data.doctorName) {
      query.and.push({
        doctorName: new RegExp('.*' + data.doctorName + '.*', 'i'),
      });
    }
    if (data && data.appoinmentDate) {
      query.and.push({
        appointmentDate: {$lte: data.appoinmentDate, $gte: data.appoinmentDate},
      });
    }

    const appointmentDetails = await this.appointmentRepository.find({
      where: query,
    });
    if (appointmentDetails && appointmentDetails.length) {
      let userIds: Array<any> = _.map(appointmentDetails, v => v.memberId);
      let coachIds: Array<any> = _.map(appointmentDetails, v => v.coachId);

      return Promise.all([
        this.userRepository.find({
          where: {
            id: {inq: userIds},
          },
          fields: {id: true, name: true},
        }),
      ]).then(async res => {
        let users =
          res && res[0] && res[0].length && _.groupBy(res[0], v => v.id);

        let coach = await this.coachRepository.find({
          where: {
            id: {inq: coachIds},
          },
        });

        let coachData =
          coach &&
          // @ts-ignore
          coach.length &&
          // @ts-ignore
          _.groupBy(coach, v => v.id);

        _.forEach(appointmentDetails, function(val: any) {
          let symptom: Array<any> = [];
          let diseases: Array<any> = [];
          let obj = Object.assign({}, val);
          obj.user =
            (users &&
              users[val.memberId!] &&
              Object.assign({}, users[val.memberId!][0])) ||
            {};

          obj.coach =
            (coachData &&
              coachData[val.coachId!] &&
              Object.assign({}, coachData[val.coachId!][0])) ||
            {};
          responseData.push(obj);
        });
        return responseData;
      });
    } else {
      throw new HttpErrors.NotFound('Appointment Not Found!');
    }
  }

  @get('/appointments/getCurrentAppointmentList', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Appointment  success',
      },
    },
  })
  @authenticate('jwt')
  async getCurrentAppointmentList(
    @inject(SecurityBindings.USER) currentUser: UserProfile,
  ): Promise<any> {
    let responseData: Array<AnyObject> = [];
    let query: AnyObject = {
      coachId: currentUser[securityId],
      and: [],
    };
    let dateFormat = moment().format('YYYY-MM-DD');
    let startDate = moment.utc().utcOffset(0);
    startDate.set({hour: 0, minute: 0, second: 0, millisecond: 0});
    startDate.toISOString();

    let endDate = moment.utc().utcOffset(0);
    endDate.set({hour: 23, minute: 59, second: 59, millisecond: 999});
    endDate.toISOString();
    query.and.push({
      appointmentDate: {gte: moment(startDate).toISOString()},
    });
    query.and.push({
      appointmentDate: {lte: moment(endDate).toISOString()},
    });

    let appointments = await this.appointmentRepository.find({
      where: query,
      order: ['created DESC'],
    });
    if (appointments && appointments.length) {
      let memeberIds: Array<any> = _.map(appointments, v => v.memberId);
      let members = await this.userRepository.find({
        where: {
          id: {inq: memeberIds},
        },
        fields: {password: false},
      });

      let appoints = members && members.length && _.groupBy(members, w => w.id);
      _.forEach(appointments, val => {
        let memId = String(val.memberId);
        let member =
          (appoints && appoints[memId].length && appoints[memId][0]) || {};
        let obj: any = Object.assign({}, member);
        obj.appoinments = val || {};
        responseData.push(_.cloneDeep(obj));
      });
    }

    return responseData;
  }

  @get('/appointments/getUpcomingAppointmentList/{userId}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Appointment  success',
      },
    },
  })
  @authenticate('jwt')
  async getUpcomingAppointmentList(
    @inject(SecurityBindings.USER) currentUser: UserProfile,
    @param.path.string('userId') userId: string,
  ): Promise<any> {
    let responseData: Array<AnyObject> = [];

    let dateFormat = moment().format('YYYY-MM-DD');
    let endDate = moment(dateFormat).utcOffset(0);
    endDate.set({hour: 23, minute: 59, second: 59, millisecond: 999});
    endDate.toISOString();
    let data: Array<any> = [];
    data.push(userId);

    let appointments = await this.appointmentRepository.find({
      where: {
        memberId: userId,
        coachId: currentUser[securityId],
        appointmentDate: {gte: moment(endDate).toISOString()},
      },
      include: [{relation: 'coach'}],
    });
    if (appointments && appointments.length) {
      let memeberIds: Array<any> = _.map(appointments, v => v.memberId);
      let members = await this.userRepository.find({
        where: {
          id: {inq: memeberIds},
        },
        fields: {password: false},
      });

      let appoints = members && members.length && _.groupBy(members, w => w.id);
      _.forEach(appointments, val => {
        let memId = String(val.memberId);
        let member =
          (appoints && appoints[memId].length && appoints[memId][0]) || {};
        let obj: any = Object.assign({}, member);
        obj.appoinments = val || {};
        responseData.push(_.cloneDeep(obj));
      });
    }

    return responseData;
  }

  @get('/appointments/getPastAppointmentList/{userId}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Appointment  success',
      },
    },
  })
  @authenticate('jwt')
  async getPastAppointmentList(
    @inject(SecurityBindings.USER) currentUser: UserProfile,
    @param.path.string('userId') userId: string,
  ): Promise<any> {
    let responseData: Array<AnyObject> = [];

    let dateFormat = moment().format('YYYY-MM-DD');
    let startDate = moment(dateFormat).utcOffset(0);
    startDate.set({hour: 0, minute: 0, second: 0, millisecond: 0});
    startDate.toISOString();

    let data: Array<any> = [];
    data.push(userId);

    let appointments = await this.appointmentRepository.find({
      where: {
        memberId: userId,
        coachId: currentUser[securityId],
        appointmentDate: {lt: moment(startDate).toISOString()},
      },
      include: [{relation: 'coach'}],
    });
    if (appointments && appointments.length) {
      let memeberIds: Array<any> = _.map(appointments, v => v.memberId);
      let members = await this.userRepository.find({
        where: {
          id: {inq: memeberIds},
        },
        fields: {password: false},
      });
      let appoints = members && members.length && _.groupBy(members, w => w.id);
      _.forEach(appointments, val => {
        let memId = String(val.memberId);
        let member =
          (appoints && appoints[memId].length && appoints[memId][0]) || {};
        let obj: any = Object.assign({}, member);
        obj.appoinments = val || {};
        responseData.push(_.cloneDeep(obj));
      });
    }

    return responseData;
  }

  @get('/appointments/getAppointmentsByCoachId/{coachId}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Appointment  success',
      },
    },
  })
  @authenticate('jwt')
  async getAppointmentsByCoachId(
    @param.path.string('coachId') coachId: string,
  ): Promise<AppointmentWithRelations[]> {
    return this.appointmentService.getAppointmentsByCoachId(coachId);
  }
}
