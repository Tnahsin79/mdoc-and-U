import {
  get,
  del,
  post,
  patch,
  param,
  requestBody,
  getModelSchemaRef,
  getFilterSchemaFor,
} from '@loopback/rest';
import {inject} from '@loopback/core';
import {ProcedureList} from '../models';
import {Filter} from '@loopback/repository';
import {PaginatedResponse} from '../type-schema';
import {ProcedureListService} from '../services';
import {ProcedureListServiceBindings} from '../keys';
import {authenticate} from '@loopback/authentication';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';

export class ProcedureListController {
  constructor(
    @inject(ProcedureListServiceBindings.PROCEDURE_LIST_SERVICE)
    public procedureListService: ProcedureListService,
  ) {}

  @post('/procedure-list', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'ProcedureList model instance',
        content: {
          'application/json': {schema: getModelSchemaRef(ProcedureList)},
        },
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(ProcedureList, {
            title: 'NewProcedureList',
            exclude: ['id'],
          }),
        },
      },
    })
    procedureList: Omit<ProcedureList, 'id'>,
  ): Promise<ProcedureList> {
    return this.procedureListService.create(procedureList);
  }

  @get('/procedure-list', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of ProcedureList model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(ProcedureList, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findAll(
    @param.query.object('filter', getFilterSchemaFor(ProcedureList))
    filter?: Filter<ProcedureList>,
    @param.query.number('page') page?: number,
  ): Promise<PaginatedResponse<ProcedureList>> {
    return this.procedureListService.findAll(filter, page);
  }

  @get('/procedure-list/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'ProcedureList model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(ProcedureList, {includeRelations: true}),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(ProcedureList))
    filter?: Filter<ProcedureList>,
  ) {
    return this.procedureListService.findById(id, filter);
  }

  @patch('/procedure-list/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'ProcedureList PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(ProcedureList, {partial: true}),
        },
      },
    })
    procedureList: ProcedureList,
  ): Promise<void> {
    return await this.procedureListService.updateById(id, procedureList);
  }

  @del('/procedure-list/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'ProcedureList DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    this.procedureListService.deleteById(id);
  }
}
