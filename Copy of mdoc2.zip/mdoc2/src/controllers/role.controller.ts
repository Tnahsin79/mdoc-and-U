import {Filter, repository} from '@loopback/repository';
import {
  PrivilegeRepository,
  RolePrivilegeRepository,
  RoleRepository,
} from '../repositories';
import {inject} from '@loopback/context';
import {
  del,
  get,
  getFilterSchemaFor,
  getModelSchemaRef,
  param,
  patch,
  post,
  requestBody,
} from '@loopback/openapi-v3';
import {Role} from '../models';
import {authenticate} from '@loopback/authentication';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';
import {RoleServiceBindings} from '../keys';
import {PrivilegeService, RoleService} from '../services';

export class RoleController {
  constructor(
    @repository(RoleRepository) public roleRepository: RoleRepository,
    //@repository(RolePrivilegeRepository) public rolePrivilegeRepository: RolePrivilegeRepository,
    @inject(RoleServiceBindings.ROLE_SERVICE) public roleService: RoleService,
  ) {}

  @post('/roles', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Role model instance',
        content: {'application/json': {schema: getModelSchemaRef(Role)}},
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: {
            type: 'object',
            properties: {
              title: {type: 'string'},
              description: {type: 'string'},
              privileges: {type: 'array', items: {type: 'string'}},
            },
          },
        },
      },
    })
    role: Omit<Role, 'id'> & {privileges: string[]},
  ): Promise<Role> {
    return await this.roleService.create(role);
  }

  @get('/roles', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of Role model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(Role, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async find(
    @param.query.object('filter', getFilterSchemaFor(Role))
    filter?: Filter<Role>,
  ): Promise<Role[]> {
    return await this.roleService.findAll(filter);
  }

  @patch('/roles/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Role PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: {
            type: 'object',
            properties: {
              role: getModelSchemaRef(Role, {partial: true, exclude: ['id']}),
              privileges: {
                type: 'array',
                items: {type: 'string'}
              }
            }
          }
        },
      },
    })
    Role: {role: Role; privileges: string[]},
  ): Promise<void> {
    await this.roleService.updateById(id, Role);
  }

  @del('/roles/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Role DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.roleRepository.deleteById(id);
  }

  @get('/roles/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Role model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Role, {includeRelations: true}),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
  ): Promise<Role> {
    return this.roleService.findById(id);
  }

  @post('/roles/assign', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Role model instance',
        content: {'application/json': {schema: getModelSchemaRef(Role)}},
      },
    },
  })
  @authenticate('jwt')
  async assignRolesToAdmin(
    @requestBody({
      content: {
        'application/json': {
          schema: {
            type: 'object',
            properties: {
              roles: {type: 'array', items: {type: 'string'}},
              admin: {type: 'string'},
            },
          },
        },
      },
    })
    data: {
      roles: string[];
      admin: string;
    },
  ): Promise<void> {
    await this.roleService.assignRolesToAdmin(data.admin, data.roles);
  }
}
