import _ from 'lodash';
import {
  post,
  param,
  get,
  getModelSchemaRef,
  patch,
  put,
  del,
  requestBody,
  getFilterSchemaFor,
  HttpErrors,
} from '@loopback/rest';
import {
  AnyObject,
  Count,
  CountSchema,
  Filter,
  repository,
  Where,
} from '@loopback/repository';
import {BlockedUsers} from '../models';
import {inject} from '@loopback/context';
import {BlockedUsersServiceBindings} from '../keys';
import {authenticate} from '@loopback/authentication';
import {BlockedUsersRepository} from '../repositories';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';
import {BlockedUsersService} from '../services/blocked-users.service';

export class BlockedUsersController {
  constructor(
    @repository(BlockedUsersRepository)
    public blockedUsersRepository: BlockedUsersRepository,
    @inject(BlockedUsersServiceBindings.BLOCKED_USERS_SERVICE)
    public blockedUsersService: BlockedUsersService,
  ) {}

  @post('/blocked-users', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'BlockedUsers model instance',
        content: {
          'application/json': {schema: getModelSchemaRef(BlockedUsers)},
        },
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(BlockedUsers, {
            title: 'NewBlockedUsers',
            exclude: ['id'],
          }),
        },
      },
    })
    blockedUsers: Omit<BlockedUsers, 'id'>,
  ): Promise<BlockedUsers> {
    let existPostUser = await this.blockedUsersRepository.findOne({
      where: {
        userId: blockedUsers?.userId || 'null',
        postId: blockedUsers?.postId || 'null',
      },
    });
    if (existPostUser && existPostUser.id) {
      throw new HttpErrors.UnprocessableEntity('Already report on this post!');
    }
    let existCommentUser = await this.blockedUsersRepository.findOne({
      where: {
        userId: blockedUsers?.userId || 'null',
        commentId: blockedUsers?.commentId || 'null',
      },
    });
    if (existCommentUser && existCommentUser.id) {
      throw new HttpErrors.UnprocessableEntity(
        'Already report on this comment!',
      );
    }
    return this.blockedUsersRepository.create(blockedUsers);
  }

  @get('/blocked-users/{id}', {
    responses: {
      200: {
        description: 'BlockedUsers model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(BlockedUsers, {includeRelations: true}),
          },
        },
      },
    },
  })
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(BlockedUsers))
    filter?: Filter<BlockedUsers>,
  ): Promise<BlockedUsers> {
    return this.blockedUsersRepository.findById(id, filter);
  }

  @del('/blocked-users/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      204: {
        description: 'BlockedUsers DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.blockedUsersRepository.deleteById(id);
  }

  @get('/blocked-users/getReportsPost', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'BlockedUsers model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(BlockedUsers, {includeRelations: true}),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async getReportsPost(): Promise<any> {
    let responseData: Array<AnyObject> = [];
    let result = await this.blockedUsersRepository.find({
      where: {
        blockType: 'post',
      },
      include: [
        {
          relation: 'post',
          scope: {
            include: [
              {
                relation: 'user',
                scope: {
                  fields: {password: false, email: false},
                },
              },
            ],
          },
        },
      ],
      order: ['created DESC'],
    });
    if (result && result.length) {
      let postIds = _.uniq(_.map(result, v => String(v.postId)));
      let uniqPostId = _.uniq(postIds);
      let grpPost =
        result && result.length && _.groupBy(result, v => String(v.postId));

      _.forEach(uniqPostId, function(val) {
        let posts: any = (grpPost && grpPost[val] && grpPost[val]) || 0;
        if (posts && posts.length) {
          responseData.push({
            report: posts[0],
            totalReport: posts.length,
          });
        }
      });
      return responseData;
    } else {
      return responseData;
    }
  }

  @get('/blocked-users/getReportsComment', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'BlockedUsers model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(BlockedUsers, {includeRelations: true}),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async getReportsComment(): Promise<any> {
    let responseData: Array<AnyObject> = [];
    let result = await this.blockedUsersRepository.find({
      where: {
        blockType: 'comment',
      },
      include: [
        {
          relation: 'post',
        },
        {
          relation: 'comment',
          scope: {
            include: [
              {
                relation: 'user',
                scope: {
                  fields: {password: false, email: false},
                },
              },
              {
                relation: 'post',
              },
            ],
          },
        },
      ],
      order: ['created DESC'],
    });
    if (result && result.length) {
      let commentIds = _.uniq(_.map(result, v => String(v.commentId)));
      let uniqCommentId = _.uniq(commentIds);

      let grpPost =
        result && result.length && _.groupBy(result, v => String(v.commentId));

      _.forEach(uniqCommentId, function(val) {
        let posts: any = (grpPost && grpPost[val] && grpPost[val]) || 0;
        if (posts && posts.length) {
          responseData.push({
            report: posts[0],
            totalReport: posts.length,
          });
        }
      });
      return responseData;
    } else {
      return responseData;
    }
  }
}
