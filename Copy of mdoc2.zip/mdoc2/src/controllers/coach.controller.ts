import {
  UserServiceBindings,
  TokenServiceBindings,
  EmailServiceBindings,
  CoachServiceBindings,
  PasswordHasherBindings,
  MigrationServiceBindings,
  ControllerServiceBindings,
} from '../keys';
import {
  Coach,
  Users,
  CoachPrograms,
  CoachSpeciality,
  CoachSpecialityRelations,
} from '../models';
import {
  get,
  put,
  del,
  post,
  param,
  patch,
  HttpErrors,
  requestBody,
  getModelSchemaRef,
  getWhereSchemaFor,
  getFilterSchemaFor,
} from '@loopback/rest';
import {
  Credentials,
  SourceTypeEnum,
  CredentialsRequestBody,
} from '../type-schema';
import {
  CoachRepository,
  UsersRepository,
  AdminRepository,
  SpecialityRepository,
  LoginHistoryRepository,
  CoachSpecialityRepository,
} from '../repositories';
import csv from 'csvtojson';
import dotenv from 'dotenv';
import moment from 'moment';
import {
  Where,
  Count,
  Filter,
  AnyObject,
  repository,
  CountSchema,
} from '@loopback/repository';
import _, {result} from 'lodash';
import {inject} from '@loopback/core';
import {crypt} from '../services/common';
import * as common from '../services/common';
import {JWTService} from '../services/jwt-service';
import {CoachService} from '../services/coach.service';
import {EmailService} from '../services/email.service';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';
import {MigrationService} from '../services/migration.service';
import {ControllerService} from '../services/controller.service';
import {LoginHistoryTypeEnum, UserTypeEnum} from '../utils/enums';
import {PasswordHasher} from '../services/hash.password.bcryptjs';
import {PlansRepository} from './../repositories/plans.repository';
import {UserService, authenticate} from '@loopback/authentication';
import {validateCredentials, validatePassword} from '../services/validator';
import {UserProfile, securityId, SecurityBindings} from '@loopback/security';
import {AppointmentRepository} from './../repositories/appointment.repository';
import {HealthDiaryRepository} from './../repositories/health-diary.repository';
import {SubscriptionsRepository} from './../repositories/subscriptions.repository';
import {HealthConditionRepository} from './../repositories/health-condition.repository';

dotenv.config();

export class CoachController {
  constructor(
    @repository(CoachRepository) public coachRepository: CoachRepository,
    @repository(UsersRepository) public usersRepository: UsersRepository,
    @inject(PasswordHasherBindings.PASSWORD_HASHER)
    public passwordHasher: PasswordHasher,
    @inject(TokenServiceBindings.TOKEN_SERVICE)
    public jwtService: JWTService,
    @inject(CoachServiceBindings.COACH_SERVICE)
    public coachService: CoachService,
    @inject(UserServiceBindings.USER_SERVICE)
    public userService: UserService<Users, Credentials>,
    @inject(ControllerServiceBindings.CONTROLLER_SERVICE)
    public controllerService: ControllerService,
    @repository(AdminRepository) public adminRepository: AdminRepository,
    @repository(HealthDiaryRepository)
    public healthDiaryRepository: HealthDiaryRepository,
    @repository(HealthConditionRepository)
    public healthConditionRepository: HealthConditionRepository,
    @repository(SubscriptionsRepository)
    public subscriptionsRepository: SubscriptionsRepository,
    @repository(PlansRepository) public plansRepository: PlansRepository,
    @repository(AppointmentRepository)
    public appointmentRepository: AppointmentRepository,
    @repository(CoachSpecialityRepository)
    public coachSpecialityRepository: CoachSpecialityRepository,
    @inject(MigrationServiceBindings.MIGRATION_SERVICE)
    public migrationService: MigrationService,
    @repository(SpecialityRepository)
    public specialityRepository: SpecialityRepository,
    @inject(EmailServiceBindings.MAIL_SERVICE)
    public emailService: EmailService,
    @repository(LoginHistoryRepository)
    public loginHistoryRepository: LoginHistoryRepository,
  ) {}

  @post('/coaches', {
    responses: {
      '200': {
        description: 'Coach model instance',
        content: {
          'application/json': {schema: getModelSchemaRef(Coach)},
        },
      },
    },
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Coach, {
            title: 'NewCoach',
            exclude: ['id'],
          }),
        },
      },
    })
    coach: Omit<Coach, 'id'>,
  ): Promise<Coach> {
    validateCredentials(_.pick(coach, ['email', 'password']));
    coach.email = coach.email.toLowerCase();
    const result: any = {};
    coach.email = coach?.email.toLowerCase();
    const coachDetail = await this.coachRepository.findOne({
      where: {
        or: [
          {phone: (coach && coach.phone) || 'null'},
          {email: (coach && coach.email) || 'null'},
        ],
      },
    });
    if (coachDetail && coachDetail.id) {
      let email = (coach && coach.email) || 'null';
      let phone = (coach && coach.phone) || 'null';
      let existKey =
        (coachDetail && coachDetail.email === email && 'Email') ||
        (coachDetail && coachDetail.phone === phone && 'Phone Number') ||
        'Email and Phone Number';
      result.message = existKey + ' already exists! Kindly login';
      result.status = 400;
      // throw new HttpErrors.Forbidden(existKey + ' Already exist!');
    } else {
      coach.password = await this.passwordHasher.hashPassword(
        coach.password ?? '123456',
      );
      (result.message = 'Successfully created'), (result.status = 201);
      result.data = this.coachRepository.create(coach);
    }

    return result;
  }
  @post('/coaches/login', {
    responses: {
      '200': {
        description: 'Token',
        content: {
          'application/json': {
            schema: {
              type: 'object',
              properties: {token: {type: 'string'}},
            },
            '400': {
              description: 'Cannot delete an active coach',
            },
          },
        },
      },
    },
  })
  async login(
    @requestBody(CredentialsRequestBody) credentials: Credentials,
  ): Promise<any> {
    credentials.email = credentials.email.toLowerCase();
    const invalidCredentialsError = 'Invalid email or password.';
    let responseData: AnyObject = {};
    credentials.email = credentials.email.toLowerCase();
    const coach = await this.coachRepository.findOne({
      where: {
        email: {
          regexp: `/^${credentials.email}/i`,
        },
      },
    });
    if (!coach) {
      throw new HttpErrors.Unauthorized(invalidCredentialsError);
    }
    if (!coach.isActive) {
      throw new HttpErrors.Unauthorized(
        'You are not authorized, Please contact the admin',
      );
    }
    const passwordMatched = await this.passwordHasher.comparePassword(
      credentials.password,
      coach.password ?? '',
    );

    if (!passwordMatched) {
      throw new HttpErrors.Unauthorized(invalidCredentialsError);
    }
    const userProfile = {
      [securityId]: coach.id ?? '',
      name: coach.name ?? '',
      email: coach.email ?? '',
    };
    responseData = Object.assign({}, coach);
    const token = await this.jwtService.generateToken(userProfile);
    const {refreshToken} = await this.jwtService.generateRefreshToken(
      userProfile,
    );
    const obj: AnyObject = {
      isOnline: true,
      refreshToken,
    };
    await this.loginHistoryRepository.create({
      coachId: coach.id,
      loginDateTime: moment().toISOString(),
      source: credentials.source,
      userType: UserTypeEnum.COACH,
      browserAgent: credentials.browserAgent,
      record_type: LoginHistoryTypeEnum.LOGIN,
    });
    await this.coachRepository.updateById(coach.id, obj);
    responseData.token = token;
    responseData.refreshToken = refreshToken;
    return _.omit(responseData, 'password');
  }

  @post('/coaches/logout', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Logout',
      },
    },
  })
  @authenticate('jwt')
  async logout(
    @inject(SecurityBindings.USER) currentUser: UserProfile,
    @requestBody({
      content: {
        'application/json': {
          schema: {
            type: 'object',
            properties: {
              source: {
                type: 'string',
                enum: Object.values(SourceTypeEnum),
              },
              browserAgent: {type: 'string'},
            },
          },
        },
      },
    })
    credentials: {source: SourceTypeEnum; browserAgent?: string},
  ): Promise<any> {
    return await this.coachService.logout(currentUser, credentials);
  }

  @post('/coaches/reset', {
    responses: {
      '200': {
        description: 'Member model instance',
        content: {
          'application/json': {
            schema: {
              type: 'object',
              properties: {token: {type: 'string'}},
            },
          },
        },
      },
    },
  })
  async requestPasswordReset(@requestBody() data: AnyObject): Promise<any> {
    if (!data?.email) {
      throw new HttpErrors.UnprocessableEntity('Email Id is required!');
    }
    let responseData: AnyObject = {};
    if (data && data.loginType === 'coach') {
      const member = await this.coachRepository.findOne({
        where: {
          email: {regexp: `/^${data.email}/i`},
        },
      });
      responseData = Object.assign({}, member);
    }
    if (data && data.loginType === 'admin') {
      const member = await this.adminRepository.findOne({
        where: {
          email: data.email,
        },
      });
      responseData = Object.assign({}, member);
    }

    if (responseData?.id) {
      const memberId: string = responseData.id;
      const otp = Math.floor(1000 + Math.random() * 9000);
      const userProfile: UserProfile = Object.assign(
        {[securityId]: '', otp: '', email: ''},

        {
          [securityId]: responseData.id,
          otp: otp,
          email: responseData.email,
          id: responseData.id,
        },
      );
      const token = await this.jwtService.generateResetToken(userProfile);
      const mailOptions = {
        to: data.email,
        slug: 'coach_forgot_password',
        message: {
          otp: data.otp || otp,
          email: data.email,
          frontendUrl: `${process.env.COACH_FRONTEND_URL}/resetPassword/${token}`,
        },
      };
      const email = this.emailService.sendMail(mailOptions);

      return email;
    } else {
      throw new HttpErrors.NotFound(`User not found for Email ${data.email}`);
    }
  }

  @post('/coaches/sendForgotUrl', {
    responses: {
      '200': {
        description: 'Member model instance',
        content: {
          'application/json': {
            schema: {
              type: 'object',
              properties: {token: {type: 'string'}},
            },
          },
        },
      },
    },
  })
  async sendForgotUrl(@requestBody() data: AnyObject): Promise<any> {
    if (!data?.email) {
      throw new HttpErrors.UnprocessableEntity('Email Id is required!');
    }
    let responseData: AnyObject = {};
    data.email = data.email.toLowerCase();
    const member = await this.coachRepository.findOne({
      where: {
        email: {
          regexp: `/^${data.email.toLowerCase()}/i`,
        },
      },
    });
    responseData = Object.assign({}, member);
    if (responseData?.id) {
      const otp = Math.floor(100000 + Math.random() * 900000);

      const userProfile: UserProfile = Object.assign(
        {[securityId]: '', otp: '', email: ''},
        {
          [securityId]: responseData.id,
          otp: otp,
          email: responseData.email,
          id: responseData.id,
        },
      );
      const token = await this.jwtService.generateResetToken(userProfile);
      const sanitizeToken = token.split('.').join('');
      const frontendUrl = process.env.COACH_FRONTEND_URL;
      const mailOptions = {
        to: data.email,
        slug: 'coach_forgot_password',
        message: {
          email: data.email,
          frontendUrl: `${frontendUrl}/resetPassword/${sanitizeToken}?email=${data.email}`,
        },
      };
      member.resetToken = sanitizeToken;
      await this.coachRepository.updateById(member?.id, member);
      const email = this.emailService.sendMail(mailOptions);

      return email;
    } else {
      throw new HttpErrors.NotFound(`User not found for Email ${data.email}`);
    }
  }

  @post('/coaches/reset-password', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Coaches model instance',
        content: {'application/json': {schema: {type: 'object'}}},
      },
    },
  })
  async resetPassword(
    @requestBody() data: {token: string; password: string; email: string},
  ): Promise<void> {
    data.email = data.email.toLowerCase();
    if (!data?.password && !data?.email) {
      throw new HttpErrors.UnprocessableEntity(
        'Password and email are required!',
      );
    }
    if (!data?.token) {
      throw new HttpErrors.UnprocessableEntity('Invalid token!');
    }
    validatePassword(data.password);

    return this.coachService.resetCoachPassword(data);
  }

  @get('/coaches/count', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Coach model count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  @authenticate('jwt')
  async count(
    @param.query.object('where', getWhereSchemaFor(Coach))
    where?: Where<Coach>,
  ): Promise<Count> {
    return this.coachRepository.count(where);
  }

  @get('/getCoachesBySpecialty', {
    responses: {
      '200': {
        description: 'Array of paginated Coach model instances',
      },
    },
  })
  async getCoachesBySpecialty(
    @param.query.string('query')
    query?: string,
  ): Promise<AnyObject> {
    return this.coachService.getCoachesBySpecialty(query);
  }

  @get('coaches/refresh-token', {
    responses: {
      '200': {
        description: 'token refreshed',
      },
    },
  })
  async refreshCoachToken(
    @param.query.string('token')
    token: string,
  ): Promise<AnyObject> {
    return this.coachService.refreshCoachToken(token);
  }

  @get('/getAllCoaches', {
    responses: {
      '200': {
        description: 'Array of paginated Coach model instances',
      },
    },
  })
  async getAllCoaches(
    @param.query.number('limit')
    limit?: number,
    @param.query.string('search')
    search?: string,
    @param.query.number('page') page?: number,
  ): Promise<AnyObject> {
    return this.coachService.getAllCoaches(limit, page, search);
  }

  @get('/coaches', {
    responses: {
      '200': {
        description: 'Array of Coach model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(Coach, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  async find(
    @param.query.object('filter', getFilterSchemaFor(Coach))
    filter?: Filter<Coach>,
    @param.query.number('page') page?: number,
  ): Promise<AnyObject> {
    return this.coachService.getCoaches(filter, page);
  }

  @patch('/coaches', {
    responses: {
      '200': {
        description: 'Coach PATCH success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Coach, {partial: true}),
        },
      },
    })
    coach: Coach,
    @param.query.object('where', getWhereSchemaFor(Coach))
    where?: Where<Coach>,
  ): Promise<Count> {
    return this.coachRepository.updateAll(coach, where);
  }

  @get('/coaches/{id}', {
    responses: {
      '200': {
        description: 'Coach model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Coach, {includeRelations: true}),
          },
        },
      },
    },
  })
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(Coach))
    filter?: Filter<Coach>,
  ): Promise<any> {
    let responseData: AnyObject = {};
    const resultData: Array<AnyObject> = [];
    const subsData: Array<AnyObject> = [];
    const coaches = await this.coachRepository.findById(id, filter);
    if (coaches?.id) {
      responseData = Object.assign({}, coaches);
      const users = await this.usersRepository.find({
        where: {
          assignCoachId: coaches.id,
        },
      });
      const memberId: Array<any> = _.map(users, w => w.id);
      return Promise.all([
        this.healthDiaryRepository.find({
          where: {
            type: 'glucose',
            userId: {inq: memberId},
          },
          order: ['created DESC'],
        }),

        this.subscriptionsRepository.find({
          where: {
            userId: {inq: memberId},
          },
          order: ['created DESC'],
        }),
        this.healthDiaryRepository.find({
          where: {
            type: 'bloodPressure',
            userId: {inq: memberId},
          },
          order: ['created DESC'],
        }),
        this.appointmentRepository.find({
          where: {
            memberId: {inq: memberId},
          },
          order: ['created DESC'],
        }),
        this.healthConditionRepository.find({
          where: {
            userId: {inq: memberId},
          },
          order: ['created DESC'],
          include: [{relation: 'disease'}],
        }),
      ])
        .then(async res => {
          const subssId: Array<any> = _.map(res[1], w => w.subscriptionId);
          const plans = await this.plansRepository.find({
            where: {
              id: {inq: subssId},
            },
          });
          const plansGrp = plans?.length && _.groupBy(plans, w => w.id);

          _.forEach(res[1], function(w: any) {
            const obj = Object.assign({}, w);

            obj.plan =
              (plansGrp?.[w.subscriptionId]?.length &&
                plansGrp[w.subscriptionId][0]) ||
              {};
            subsData.push(obj);
          });

          const healthDiary =
            res?.[0]?.length && _.groupBy(res[0], w => w.userId);
          const subscription =
            subsData?.length && _.groupBy(subsData, w => w.userId);
          const bloodPressure =
            res?.[2]?.length && _.groupBy(res[2], w => w.userId);
          const appointment =
            res?.[3]?.length && _.groupBy(res[3], w => w.memberId);
          const healthcondi =
            res?.[4]?.length && _.groupBy(res[4], w => w.userId);

          _.forEach(users, function(val: any) {
            const obj = Object.assign({}, val);

            obj.healthDiaries =
              (healthDiary?.[val.id]?.length && healthDiary[val.id][0]) || {};
            obj.bloodPressure =
              (bloodPressure?.[val.id]?.length && bloodPressure[val.id][0]) ||
              {};
            obj.subcription =
              (subscription?.[val.id]?.length && subscription[val.id][0]) || {};
            obj.appointment =
              (appointment?.[val.id]?.length && appointment[val.id][0]) || {};
            obj.healthcondition =
              (healthcondi?.[val.id]?.length && healthcondi[val.id][0]) || {};

            if (obj?.bloodPressure?.id) {
              const pressures: any = obj.bloodPressure.bloodPressure;
              if (
                (pressures && Number(pressures.systolic) > 140) ||
                Number(pressures.diastolic) > 90 ||
                Number(pressures.systolic) < 90 ||
                Number(pressures.diastolic) < 55
              ) {
                obj.condition = 'Critical Condition';
              }
            }
            if (obj?.healthDiaries?.id) {
              const healthDiary: any = obj?.healthDiaries.glucose;
              if (healthDiary && healthDiary.unit === 'mg/dL') {
                if (
                  (healthDiary?.breakfast &&
                    Number(healthDiary.breakfast.before) > 130) ||
                  Number(healthDiary.breakfast.after) > 130 ||
                  (healthDiary?.lunch &&
                    Number(healthDiary.lunch.after) > 130) ||
                  Number(healthDiary.lunch.before) > 130 ||
                  (healthDiary?.dinner &&
                    Number(healthDiary.dinner.after) > 130) ||
                  Number(healthDiary.dinner.before) > 130 ||
                  (healthDiary?.snacks &&
                    Number(healthDiary.snacks.after) > 130) ||
                  Number(healthDiary.snacks.before) > 130
                ) {
                  obj.condition = 'Critical Condition';
                } else if (
                  (healthDiary?.breakfast &&
                    Number(healthDiary.breakfast.before) < 69) ||
                  Number(healthDiary.breakfast.after) < 69 ||
                  (healthDiary?.lunch &&
                    Number(healthDiary.lunch.after) < 69) ||
                  Number(healthDiary.lunch.before) < 69 ||
                  (healthDiary?.dinner &&
                    Number(healthDiary.dinner.after) < 69) ||
                  Number(healthDiary.dinner.before) < 69 ||
                  (healthDiary?.snacks &&
                    Number(healthDiary.snacks.after) < 69) ||
                  Number(healthDiary.snacks.before) < 69
                ) {
                  obj.condition = 'Critical Condition';
                }
              } else if (healthDiary && healthDiary.unit === 'mmol/L') {
                if (
                  (healthDiary?.breakfast &&
                    Number(healthDiary.breakfast.before) < 3.8) ||
                  Number(healthDiary.breakfast.after) < 3.8 ||
                  (healthDiary?.lunch &&
                    Number(healthDiary.lunch.after) < 3.8) ||
                  Number(healthDiary.lunch.before) < 3.8 ||
                  (healthDiary?.dinner &&
                    Number(healthDiary.dinner.after) < 3.8) ||
                  Number(healthDiary.dinner.before) < 3.8 ||
                  (healthDiary?.snacks &&
                    Number(healthDiary.snacks.after) < 3.8) ||
                  Number(healthDiary.snacks.before) < 3.8
                ) {
                  obj.condition = 'Critical Condition';
                } else if (
                  (healthDiary?.breakfast &&
                    Number(healthDiary.breakfast.before) > 7.2) ||
                  Number(healthDiary.breakfast.after) > 7.2 ||
                  (healthDiary?.lunch &&
                    Number(healthDiary.lunch.after) > 7.2) ||
                  Number(healthDiary.lunch.before) > 7.2 ||
                  (healthDiary?.dinner &&
                    Number(healthDiary.dinner.after) > 7.2) ||
                  Number(healthDiary.dinner.before) > 7.2 ||
                  (healthDiary?.snacks &&
                    Number(healthDiary.snacks.after) > 7.2) ||
                  Number(healthDiary.snacks.before) > 7.2
                ) {
                  obj.condition = 'Critical Condition';
                }
              }
            }
            resultData.push(obj);
          });

          responseData.usersCount = resultData?.length || 0;
          responseData.users = (resultData?.length && resultData) || [];
          return responseData;
        })
        .catch(err => {
          throw new HttpErrors.UnprocessableEntity('Something wenr wrong!');
        });
    } else {
      throw new HttpErrors.NotFound('Coach not found!');
    }
  }

  @patch('/coaches/{id}', {
    responses: {
      '204': {
        description: 'Coach PATCH success',
      },
    },
  })
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Coach, {partial: true}),
        },
      },
    })
    coach: Coach,
  ): Promise<void> {
    if (coach?.password) {
      coach.password = await this.passwordHasher.hashPassword(coach.password);
    }
    await this.coachRepository.updateById(id, coach);
  }

  @put('/coaches/{id}', {
    responses: {
      '204': {
        description: 'Coach PUT success',
      },
    },
  })
  async replaceById(
    @param.path.string('id') id: string,
    @requestBody() coach: Coach,
  ): Promise<void> {
    await this.coachRepository.replaceById(id, coach);
  }

  @del('/coaches/{id}', {
    responses: {
      '204': {
        description: 'Coach DELETE success',
      },
      '404': {
        description: 'Coach not found',
      },
      '400': {
        description: 'Cannot delete an active coach',
      },
    },
  })
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    const coachToDelete = await this.coachRepository.findById(id);
    if (!coachToDelete) {
      throw new HttpErrors.NotFound(`Coach not found with id: ${id}`);
    }

    if (coachToDelete.isActive) {
      throw new HttpErrors.BadRequest('Cannot delete an active coach');
    }
    await this.coachRepository.deleteById(id);
  }

  @post('/coaches/getCoachesList', {
    //security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Coach model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Coach, {includeRelations: true}),
          },
        },
      },
    },
  })
  //@authenticate('jwt')
  async getCoachesList(@requestBody() data: any): Promise<any> {
    let query: AnyObject = {};
    let anyQuery: AnyObject = {};
    const responseData: Array<AnyObject> = [];

    if (data?.userName) {
      query = {
        name: new RegExp('.*' + data.userName + '.*', 'i'),
      };
      const userData = await this.usersRepository.find({
        where: query,
      });
      const coachIds = _.map(userData, v => v.assignCoachId);
      anyQuery = {
        id: {inq: coachIds},
      };
    }

    if (data?.name) {
      anyQuery = {
        name: new RegExp('.*' + data.name + '.*', 'i'),
      };
    }
    if (data?.speciality) {
      anyQuery = {
        speciality: new RegExp('.*' + data.speciality + '.*', 'i'),
      };
    }
    const coachList = await this.coachRepository.find({
      where: anyQuery,
    });
    if (coachList?.length) {
      const userId = _.map(coachList, v => v.id);
      return Promise.all([
        this.usersRepository.find({
          where: {
            assignCoachId: {inq: userId},
          },
          fields: {
            assignCoachId: true,
            id: true,
            name: true,
            image: true,
          },
        }),
      ])
        .then(res => {
          const userList =
            res?.[0]?.length && _.groupBy(res[0], v => v.assignCoachId);

          _.forEach(coachList, function(val: any) {
            const obj: AnyObject = Object.assign({}, val);

            obj.usersCount =
              (userList && userList[val.id!] && userList[val.id!].length) || 0;
            responseData.push(obj);
          });

          return responseData;
        })
        .catch(err => {
          console.log(err, ' ===========-=-=-');
          throw new HttpErrors.NotFound('Something went wrong');
        });
    }
  }

  @post('/coaches/sendOtp', {
    responses: {
      '200': {
        description: 'Member model instance',
        content: {
          'application/json': {
            schema: {
              type: 'object',
              properties: {token: {type: 'string'}},
            },
          },
        },
      },
    },
  })
  async sendOtp(@requestBody() data: AnyObject): Promise<any> {
    const coachOtp = common.generateOTP();
    const mobile = data?.mobile;
    const email = data?.email;
    let coach: AnyObject = {};

    let whereClause: AnyObject = {};

    if (mobile || email) {
      whereClause = mobile ? {phone: mobile} : {email};

      coach = await this.coachRepository.findOne({
        where: whereClause,
      });

      if (!coach) {
        throw new HttpErrors.UnprocessableEntity(
          'Invalid credentials provided',
        );
      }

      if (mobile) {
        const body = `Your mDoc CompleteHealth one time pin(OTP) is ${coachOtp}. It expires in 10 minutes. Don't share this pin with anyone.`;
        await this.controllerService.sendOtpService(mobile, body);
      }

      if (email) {
        const mailOptions: AnyObject = {
          to: email,
          slug: 'registration-otp',
          message: {
            otp: coachOtp,
          },
        };

        await this.emailService.sendMail(mailOptions);
      }

      // update the OTP on the database
      coach.otp = coachOtp;
      await this.coachRepository.updateById(coach.id, coach);

      return {
        status: 'Success',
      };
    } else {
      throw new HttpErrors.UnprocessableEntity(
        'Request parameters are missing.',
      );
    }
  }

  @post('/coaches/verifyOtp', {
    responses: {
      '200': {
        description: 'Verify the coach OTP',
        content: {
          'application/json': {
            schema: {
              type: 'object',
              properties: {email: 'string', otp: 'string'},
            },
          },
        },
      },
    },
  })
  async verifyOtp(
    @requestBody() data: {email: string; otp: string},
  ): Promise<any> {
    const email = data?.email;
    const coachOTP = data?.otp;

    if (email && coachOTP) {
      const coach = await this.coachRepository.findOne({
        where: {email: email},
      });

      if (!coach) {
        throw new HttpErrors.UnprocessableEntity(
          'Invalid credentials provided',
        );
      }

      if (coach.otp !== coachOTP) {
        throw new HttpErrors.UnprocessableEntity('Invalid OTP provided');
      }

      // enable user account should be done here (set status = 1)
      // and other models needs to be updated to accomodate this change

      // update the status and set OTP to null on the database
      coach.otp = null;
      coach.isActive = true; // activate user account

      await this.coachRepository.updateById(coach.id, coach);

      return {
        status: 'Success',
      };
    } else {
      throw new HttpErrors.UnprocessableEntity(
        'Request parameters are missing.',
      );
    }
  }

  @post('/coaches/change-password', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Coaches password change feature',
      },
    },
  })
  @authenticate('jwt')
  async changePassword(
    @requestBody({
      content: {
        'application/json': {
          properties: {token: {type: 'string'}},
        },
      },
    })
    body: {
      password: string;
      userId: string;
    },
  ): Promise<AnyObject> {
    const {userId, password} = body;
    return this.coachService.changePassword(userId, password);
  }

  @get('/coachesMigration', {
    responses: {
      '200': {
        description: 'Member Migration instance',
      },
    },
  })
  async coachesMigration(): Promise<any> {
    const filePath = './public/coach_table.csv';

    const coachList = await csv().fromFile(filePath);
    if (coachList?.length) {
      for (const [index, value] of coachList.entries()) {
        if (value?.emailAddress && value.password) {
          await this.migrationService.coachMigration(value);
          if (coachList.length === index + 1) {
            this.migrationService.userOutlierLogsMigration(value);
          }
        }
      }
    }
  }

  @get('/assignCoachMemberMigration', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Member Migration instance',
      },
    },
  })
  @authenticate('jwt')
  async assignCoachMemberMigration(): Promise<any> {
    const filePath = './public/user_coach_relationship.csv';

    const coachList = await csv().fromFile(filePath);
    if (coachList?.length) {
      for (const [index, value] of coachList.entries()) {
        await this.migrationService.assignCoachMemberMigration(value);
      }
    }
  }
  @post('/coaches/invite', {
    responses: {
      '200': {
        description: 'Coach Invite instance',
        content: {
          'application/json': {type: 'object'},
        },
      },
    },
  })
  async inviteCoach(
    @requestBody({
      content: {
        'application/json': {
          example: {
            email: 'example@email.com',
          },
        },
      },
    })
    data: AnyObject,
  ): Promise<AnyObject> {
    const {email, coachType} = data;
    if (!email || email.length === 0) {
      throw new Error('Email cannot  be empty');
    }
    const emailRegex = new RegExp('.*' + email + '.*', 'i');
    const coach = await this.coachRepository.findOne({
      where: {
        email: {
          regexp: emailRegex,
        },
      },
    });

    if (coach) {
      throw new Error('Coach is already registered');
    }

    const emailEncrypt = crypt('mdoc_coach', email);

    const frontendURL =
      process.env.COACH_FRONTEND_URL ?? 'https://coach-dev.mymdoc.com';

    const link = `${frontendURL}/register?token=${emailEncrypt}&coachType=${coachType}`;
    const memberPayload = {
      from: 'Admin@mymdoc.com',
      to: email,
      slug: 'coach_invite',
      message: {
        link,
      },
    };
    await this.emailService.sendMail(memberPayload);

    const response = {
      message: 'Invitation sent',
    };
    return response;
  }

  @patch('/coaches/status/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Coach PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateCoach(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Coach, {partial: true}),
        },
      },
    })
    coach: Coach,
    @param.query.string('newCoachId') newCoachId?: string,
    @param.query.boolean('isActive') isActive?: boolean,
  ): Promise<Coach> {
    const coachToUpdate = await this.coachRepository.findOne({
      where: {
        id,
        isActive: !isActive,
      },
      include: [{relation: 'users'}],
    });

    if (!coachToUpdate) {
      throw new HttpErrors.NotFound(`Coach not found with id: ${id}`);
    }
    if (isActive) {
      await this.coachRepository.updateById(coachToUpdate.id, {isActive: true});
    }
    // Update coach isActive to false
    else {
      await this.coachRepository.updateById(coachToUpdate.id, {
        isActive: false,
      });

      const coachToAssignTo = newCoachId
        ? await this.coachRepository.findById(newCoachId)
        : await this.coachRepository.findOne({where: {isActive: true}});

      if (!coachToAssignTo) {
        throw new HttpErrors.NotFound(
          'No active coach found to reassign users to',
        );
      }
      // Update users' assignCoachId to the new coach
      const pageSize = 1000; // number of records to update at once
      let offset = 0;
      let totalUpdated = 0;

      while (true) {
        const users = await this.usersRepository.find({
          where: {assignCoachId: coachToUpdate.id},
          fields: {id: true},
          limit: pageSize,
          offset,
        });

        if (users.length === 0) {
          break;
        }

        const userIds = users.map(user => user.id);

        await this.usersRepository.updateAll(
          {assignCoachId: coachToAssignTo.id},
          {id: {inq: userIds}},
        );

        totalUpdated += userIds.length;
        offset += pageSize;
      }
    }

    return this.coachRepository.findById(coachToUpdate.id);
  }

  @get('/coachBySpeciality/{id}', {
    responses: {
      '200': {
        description: 'Array of Coach model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(CoachSpeciality, {
                includeRelations: true,
              }),
            },
          },
        },
      },
    },
  })
  async findByAllCoachesSpecialityId(
    @param.path.string('id') specialityId: string,
    @param.query.object('filter', getFilterSchemaFor(CoachSpeciality))
    filter?: Filter<CoachSpeciality>,
  ): Promise<CoachSpecialityRelations[]> {
    return this.coachService.findAllCoachesBySpecialityId(specialityId, filter);
  }

  @get('/coaches/programs/{id}', {
    responses: {
      '200': {
        description: 'Array of CoachProgram model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(CoachPrograms, {
                includeRelations: true,
              }),
            },
          },
        },
      },
    },
  })
  async getCoachPrograms(
    @param.path.string('id') coachId: string,
  ): Promise<CoachSpecialityRelations[]> {
    return this.coachService.getCoachPrograms(coachId);
  }
}
