import {
  get,
  post,
  patch,
  param,
  requestBody,
  getModelSchemaRef,
  getFilterSchemaFor,
} from '@loopback/rest';
import {DependentList, HubVisit} from '../models';
import {inject} from '@loopback/core';
import {HubVisitService} from '../services';
import {Filter} from '@loopback/repository';
import {HubVisitServiceBindings} from '../keys';
import {PaginatedResponse} from '../type-schema';
import {authenticate} from '@loopback/authentication';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';
import Utils from '../utils';

export class HubVisitController {
  constructor(
    @inject(HubVisitServiceBindings.HUB_VISIT_SERVICE)
    public hubVisitService: HubVisitService,
  ) {}

  @post('/hub-visit', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'HubVisit model instance',
        content: {
          'application/json': {schema: getModelSchemaRef(HubVisit)},
        },
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: {
            type: 'object',
            properties: {
              ...getModelSchemaRef(HubVisit, {
                title: 'NewHubVisit',
                exclude: ['id'],
              }).definitions?.NewHubVisit.properties,
              dependentList: {
                type: 'array',
                items: getModelSchemaRef(DependentList, {
                  title: 'NewDependentList',
                  exclude: ['id', 'userId'],
                }),
              },
            },
          },
        },
      },
    })
    hubVisitData: Omit<HubVisit, 'id'> & { dependentList: Omit<DependentList, 'id'>[] },
  ): Promise<HubVisit> {
    const {dependentList, ...hubVisitPayload} = hubVisitData;
    return this.hubVisitService.create(hubVisitPayload, dependentList);
  }

  @get('/hub-visit', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of HubVisit model instances',
        content: {
          'application/json': {
            schema: Utils.paginatedSchema(HubVisit, true),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findAll(
    @param.query.object('filter', getFilterSchemaFor(HubVisit))
    filter?: Filter<HubVisit>,
    @param.query.number('page') page?: number,
    @param.query.string('search') search?: string,
    @param.query.string('startDate') startDate?: string,
    @param.query.string('endDate') endDate?: string,
  ): Promise<PaginatedResponse<HubVisit>> {
    return this.hubVisitService.findAll(filter, page, search, startDate, endDate);
  }

  @get('/hub-visit/statistics/{nudgeHubId}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Statistics for a NudgeHub hubVisit',
        content: {
          'application/json': {
            schema: {
              type: 'object',
              properties: {
                totalCheckedIn: {type: 'number'},
                totalCheckedOut: {type: 'number'},
                male: {type: 'number'},
                female: {type: 'number'},
                totalDependents: {type: 'number'},
              },
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async getStatistics(
    @param.path.string('nudgeHubId')
    nudgeHubId?: string,
    @param.query.string('startDate') startDate?: string,
    @param.query.string('endDate') endDate?: string,
  ): Promise<any> {
    return this.hubVisitService.getStatistics(nudgeHubId, startDate, endDate);
  }

  @get('/hub-visit/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'HubVisit model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(HubVisit, {includeRelations: true}),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(HubVisit))
    filter?: Filter<HubVisit>,
  ) {
    return this.hubVisitService.findById(id, filter);
  }

  @patch('/hub-visit/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'HubVisit PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(HubVisit, {
            partial: true,
            exclude: ['id'],
          }),
        },
      },
    })
    hubVisit: HubVisit,
  ): Promise<void> {
    return this.hubVisitService.updateById(id, hubVisit);
  }
}
