import { Filter, repository } from '@loopback/repository';
import {
  post,
  del,
  patch,
  get,
  getModelSchemaRef,
  requestBody,
  param,
  getFilterSchemaFor
} from '@loopback/rest';
import {AppRelease} from '../models';
import {AppReleaseRepository} from '../repositories';
import * as _ from 'lodash';
import {inject} from '@loopback/core';
import { AppReleaseServiceBindings } from '../keys';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';
import { authenticate } from '@loopback/authentication';
import {AppReleaseService} from '../services/app-release.service';
import { PaginatedResponse } from '../type-schema';
import Utils from '../utils';

export class AppReleaseController {
  constructor(
    @repository(AppReleaseRepository) public appReleaseRepository: AppReleaseRepository,
    @inject(AppReleaseServiceBindings.APP_RELEASE_SERVICE)
    public appReleaseService: AppReleaseService,
  ) {}

  @post('/app-release', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'New App model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(AppRelease),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(AppRelease, {
            title: 'NewAppRelease',
            exclude: ['id'],
          }),
        },
      },
    })
    appRelease: Omit<AppRelease, 'id'>,
  ) : Promise<AppRelease> {
    const newAppRelease = await this.appReleaseService.create(appRelease);
    return newAppRelease;
  }

  @get('/app-release', {
    responses: {
      '200': {
        description: 'Latest App Release model instances',
        content: {
          'application/json': {
            schema: getModelSchemaRef(AppRelease),
          },
        },
      },
    },
  })
  async find(): Promise<AppRelease> {
    const appRelease = await this.appReleaseService.getLatestAppRelease();
    return appRelease;
  }

  @get('/fetch-app-releases', {
    responses: {
      '200': {
        description: 'Array of AppRelease model instance',
        content: {
          "application/json": {
            schema: Utils.paginatedSchema(AppRelease, true),
          },
        },
      },
    },
  })
  async getAppReleases(
    @param.query.object('filter', getFilterSchemaFor(AppRelease))
    filter?: Filter<AppRelease>,
    @param.query.number('page') page?: number,
  ): Promise<PaginatedResponse<AppRelease>> {
    return await this.appReleaseService.find(
      filter,
      page,
    );
  }

  @get('/find-ip-address', {
    responses: {
      '200': {
        description: 'App IP Address',
      },
    },
  })
  async findIpAddress(
    @param.query.string('token') token?: string,
  ): Promise<any> {
    const ipAddress = await this.appReleaseService.findIpAddress(token);
    return ipAddress;
  }

  @patch('/app-release/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'App release PATCH success',
      },
    },
  })
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(AppRelease, {partial: true}),
        },
      },
    })
    appRelease: AppRelease,
  ): Promise<void> {
    await this.appReleaseRepository.updateById(id, appRelease);
  }

  @del('/app-release/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'App release DELETE success',
      },
    },
  })
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.appReleaseRepository.deleteById(id);
  }
}
