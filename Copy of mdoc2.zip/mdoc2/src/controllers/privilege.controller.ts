import { Filter, repository } from "@loopback/repository";
import { PrivilegeRepository } from "../repositories";
import { inject } from "@loopback/context";
import { del, get, getFilterSchemaFor, getModelSchemaRef, param, patch, post, requestBody } from "@loopback/openapi-v3";
import { PrivilegeGroup, Privilege } from "../models";
import { authenticate } from "@loopback/authentication";
import { OPERATION_SECURITY_SPEC } from "../utils/security-spec";
import { PrivilegeServiceBindings } from "../keys";
import { PrivilegeService } from "../services";

export class PrivilegeController {
    constructor(
        @repository(PrivilegeRepository) public privilegeRepository: PrivilegeRepository,
        @inject(PrivilegeServiceBindings.PRIVILEGE_SERVICE) public privilegeService: PrivilegeService,
    ) { }
    
    @post('/privileges', {
        security: OPERATION_SECURITY_SPEC,
        responses: {
            '200': {
                description: 'Privilege model instance',
                content: { 'application/json': { schema: getModelSchemaRef(Privilege) } },
            },
        },
    })
    @authenticate('jwt')
    async create(
        @requestBody({
            content: {
                'application/json': {
                    schema: getModelSchemaRef(Privilege, {
                        title: 'NewPrivilege',
                        exclude: ['id'],
                    }),
                },
            },
        })
        privilege: Omit<Privilege, 'id'>,
    ): Promise<Privilege> {
        return this.privilegeRepository.create(privilege);
    }

    @get('/privileges', {
        security: OPERATION_SECURITY_SPEC,
        responses: {
            '200': {
                description: 'Array of Privilege model instances',
                content: {
                    'application/json': {
                        schema: { type: 'array', items: getModelSchemaRef(Privilege, {includeRelations: true}) },
                    },
                },
            },
        },
    })
    @authenticate('jwt')
    async find(
        @param.query.object('filter', getFilterSchemaFor(Privilege)) filter?: Filter<Privilege>,
    ): Promise<Privilege[]> {
        // fetch all with privilegeGroup relation
        return this.privilegeRepository.find(filter, {include: [{relation: 'privilegeGroup'}]});
    }

    @patch('/privileges/{id}', {
        security: OPERATION_SECURITY_SPEC,
        responses: {
            '204': {
                description: 'Privilege PATCH success',
            },
        },
    })
    @authenticate('jwt')
    async updateById(
        @param.path.string('id') id: string,
        @requestBody({
            content: {
                'application/json': {
                    schema: getModelSchemaRef(Privilege, { partial: true, exclude: ['id'] }),
                },
            },
        })
        privilege: Privilege,
    ): Promise<void> {
        await this.privilegeRepository.updateById(id, privilege);
    }

    @del('/privileges/{id}', {
        security: OPERATION_SECURITY_SPEC,
        responses: {
            '204': {
                description: 'Privilege DELETE success',
            },
        },
    })
    @authenticate('jwt')
    async deleteById(@param.path.string('id') id: string): Promise<void> {
        await this.privilegeRepository.deleteById(id);
    }

    @get('/privileges/{id}', {
        security: OPERATION_SECURITY_SPEC,
        responses: {
            '200': {
                description: 'Privilege model instance',
                content: { 'application/json': { schema: getModelSchemaRef(Privilege) } },
            },
        },
    })
    @authenticate('jwt')
    async findById(@param.path.string('id') id: string): Promise<Privilege> {
        return this.privilegeRepository.findById(id);
    }
}