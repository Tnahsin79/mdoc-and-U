import {
  ControllerServiceBindings,
  HealthDiaryServiceBindings,
  HealthDairyMigrationServiceBindings,
} from '../keys';
import {
  Bmi,
  Psa,
  Hbaic,
  Weight,
  Exercise,
  BloodSugar,
  Cholestrol,
  HealthDiary,
  BloodPressure,
  PregnancyCycle,
  MedicationPassport,
  WaistCircumference,
  Temperature,
} from '../models';
import {
  get,
  del,
  put,
  post,
  param,
  patch,
  requestBody,
  getModelSchemaRef,
  getWhereSchemaFor,
  getFilterSchemaFor,
} from '@loopback/rest';
import {
  Count,
  Where,
  Filter,
  AnyObject,
  repository,
  CountSchema,
} from '@loopback/repository';
import {
  UsersRepository,
  PharmacyRepository,
  ProviderRepository,
  WaistgoalRepository,
  TreatmentRepository,
  HealthDiaryRepository,
  EyeExaminationRepository,
  HealthConditionRepository,
  FootExaminationRepository,
  ProcedureSurgeriesRepository,
  MedicationPassportRepository,
  HealthProcedureSurgeriesRepository,
} from '../repositories';
import moment from 'moment';
import * as _ from 'lodash';
import {inject} from '@loopback/core';
import {authenticate} from '@loopback/authentication';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';
import {EyeExamination} from './../models/eye-examination.model';
import {ControllerService} from '../services/controller.service';
import {FootExamination} from './../models/foot-examination.model';
import {HealthDiaryService} from '../services/health-diary.service';
import {UserProfile, securityId, SecurityBindings} from '@loopback/security';
import {LabsProceduresRepository} from '../repositories/labs-procedures.repository';
import {HealthDairyMigrationService} from '../services/healthDairyMigration.service';

export class HealthDiaryController {
  constructor(
    @repository(HealthDiaryRepository)
    public healthDiaryRepository: HealthDiaryRepository,
    @repository(HealthConditionRepository)
    public healthConditionRepository: HealthConditionRepository,
    @repository(TreatmentRepository)
    public treatmentRepository: TreatmentRepository,
    @repository(MedicationPassportRepository)
    public medicationRepository: MedicationPassportRepository,
    @repository(FootExaminationRepository)
    public footExaminationRepository: FootExaminationRepository,
    @repository(PharmacyRepository)
    public pharmacyRepository: PharmacyRepository,
    @repository(EyeExaminationRepository)
    public eyeExaminationRepository: EyeExaminationRepository,
    @repository(HealthProcedureSurgeriesRepository)
    public healthProcedureSurgeriesRepository: HealthProcedureSurgeriesRepository,
    @repository(ProviderRepository)
    public ProviderRepository: ProviderRepository,
    @repository(ProcedureSurgeriesRepository)
    public procedureSurgeriesRepository: ProcedureSurgeriesRepository,
    @repository(LabsProceduresRepository)
    public labsProceduresRepository: LabsProceduresRepository,
    @repository(UsersRepository) public usersRepository: UsersRepository,
    @inject(ControllerServiceBindings.CONTROLLER_SERVICE)
    public controllerService: ControllerService,
    @inject(HealthDiaryServiceBindings.HEALTH_DIARY_SERVICE)
    public healthDiaryService: HealthDiaryService,
    @inject(HealthDairyMigrationServiceBindings.HEALTHDAIRY_MIGRATION_SERVICE)
    public healthDairyMigration: HealthDairyMigrationService,
    @repository(WaistgoalRepository)
    public waistgoalRepository: WaistgoalRepository,
  ) {}

  @post('/health-diaries', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'HealthDiary model instance',
        content: {'application/json': {schema: getModelSchemaRef(HealthDiary)}},
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(HealthDiary, {
            title: 'NewHealthDiary',
            exclude: ['id'],
          }),
        },
      },
    })
    healthDiary: Omit<HealthDiary, 'id'>,
  ): Promise<any> {
    let responseData: AnyObject = {};
    healthDiary.isHealthDiaryCompleted = true;
    let userDetails = await this.usersRepository.findOne({
      where: {
        id: healthDiary.userId,
      },
      fields: {id: true, heightUnit: true, height: true},
    });

    if (healthDiary && healthDiary.type === 'bmi') {
      const weightRes = await this.healthDiaryRepository.findOne({
        where: {
          userId: healthDiary.userId,
          type: 'weight',
        },
        order: ['created DESC'],
      });

      if (userDetails && userDetails.height) {
        let heightInCm = 0;
        let weight = 0;
        let height = Number(userDetails && userDetails.height);
        if (
          userDetails ||
          userDetails.heightUnit === 'FT/IN' ||
          userDetails.heightUnit === 'CM'
        ) {
          heightInCm = height;
          weight = Number(
            weightRes && weightRes.weight && weightRes.weight.value,
          );
        } else {
          let convertHeightIntoMeter: any = userDetails && userDetails.height;
          let feet = convertHeightIntoMeter.split('.')[0];
          let inch = convertHeightIntoMeter.split('.')[1];

          let totalInchs = Number(feet) * 12;
          totalInchs = totalInchs + Number(inch);
          heightInCm = totalInchs * 2.54;
          weight = Number(
            weightRes && weightRes.weight && weightRes.weight.value,
          );
        }
        const datas = await this.controllerService.calculateBmi(
          weight,
          heightInCm,
        );

        healthDiary.isBmiGoal = true;
        healthDiary.bmi = {
          value: (datas && String(datas.avgBmi)) || '0',
          message: (datas && datas.message) || '',
          goal: (healthDiary && String(healthDiary.bmi.goal)) || '0',
          date: healthDiary && healthDiary.weight && healthDiary.weight.date,
        };
      }
    }
    let healthData = await this.healthDiaryRepository.create(healthDiary);
    responseData = Object.assign({}, healthData);
    if (healthDiary && healthDiary.type === 'weight') {
      // height convert into CM

      if (userDetails && userDetails.height) {
        let heightInCm = 0;
        let weight = 0;
        let height = Number(userDetails && userDetails.height);
        if (
          userDetails ||
          userDetails.heightUnit === 'FT/IN' ||
          userDetails.heightUnit === 'CM'
        ) {
          heightInCm = height;
          weight = Number(
            healthData &&
              healthData.weight &&
              Math.round(healthData.weight.value),
          );
        } else {
          let convertHeightIntoMeter: any = userDetails && userDetails.height;
          let feet = convertHeightIntoMeter.split('.')[0];
          let inch = convertHeightIntoMeter.split('.')[1];

          let totalInchs = Number(feet) * 12;
          totalInchs = totalInchs + Number(inch);
          heightInCm = totalInchs * 2.54;
          weight = Number(
            (healthData && healthData.weight && healthData.weight.value) || 0,
          );
        }

        // calculate BMI service
        const datas = await this.controllerService.calculateBmi(
          weight,
          heightInCm,
        );

        // get previouse goal
        const bmiGoalLastRecord = await this.healthDiaryRepository.findOne({
          where: {
            userId: healthDiary.userId,
            isBmiGoal: true,
          },
        });

        let bmiObject = {
          userId: healthDiary.userId,
          type: 'bmi',
          isHealthDiaryCompleted: true,
          bmi: {
            value: (datas && String(datas.avgBmi)) || '0',
            message: (datas && datas.message) || '',
            goal:
              (bmiGoalLastRecord &&
                bmiGoalLastRecord.bmi &&
                String(bmiGoalLastRecord.bmi.goal)) ||
              '0',
            date: healthDiary && healthDiary.weight && healthDiary.weight.date,
          },
        };
        let bmiRes = await this.healthDiaryRepository.create(bmiObject);
        responseData.bmi = _.cloneDeep(bmiRes);
        // return responseData;
      }
    }
    return responseData;
  }

  @get('/health-diaries/count', {
    responses: {
      '200': {
        description: 'HealthDiary model count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async count(
    @param.query.object('where', getWhereSchemaFor(HealthDiary))
    where?: Where<HealthDiary>,
  ): Promise<Count> {
    return this.healthDiaryRepository.count(where);
  }

  @get('/health-diaries', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of HealthDiary model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(HealthDiary, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async find(
    @param.query.object('filter', getFilterSchemaFor(HealthDiary))
    filter?: Filter<HealthDiary>,
  ): Promise<HealthDiary[]> {
    return this.healthDiaryRepository.find(filter);
  }

  @patch('/health-diaries', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'HealthDiary PATCH success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  @authenticate('jwt')
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(HealthDiary, {partial: true}),
        },
      },
    })
    healthDiary: HealthDiary,
    @param.query.object('where', getWhereSchemaFor(HealthDiary))
    where?: Where<HealthDiary>,
  ): Promise<Count> {
    return this.healthDiaryRepository.updateAll(healthDiary, where);
  }

  @get('/health-diaries/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'HealthDiary model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(HealthDiary, {includeRelations: true}),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(HealthDiary))
    filter?: Filter<HealthDiary>,
  ): Promise<HealthDiary> {
    return this.healthDiaryRepository.findById(id, filter);
  }

  @patch('/health-diaries/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'HealthDiary PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(HealthDiary, {partial: true}),
        },
      },
    })
    healthDiary: HealthDiary,
  ): Promise<void> {
    await this.healthDiaryRepository.updateById(id, healthDiary);
  }

  @put('/health-diaries/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'HealthDiary PUT success',
      },
    },
  })
  @authenticate('jwt')
  async replaceById(
    @param.path.string('id') id: string,
    @requestBody() healthDiary: HealthDiary,
  ): Promise<void> {
    await this.healthDiaryRepository.replaceById(id, healthDiary);
  }

  @del('/health-diaries/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'HealthDiary DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.healthDiaryRepository.deleteById(id);
  }
  @get('/health-diaries/getUserHealthDiaryById/{userId}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'HealthDiary  success',
      },
    },
  })
  @authenticate('jwt')
  async getUserHealthDiaryById(
    @param.path.string('userId') userId: string,
  ): Promise<any> {
    let responseData: Array<AnyObject> = [];
    let result: AnyObject = {};
    let resGloucose: AnyObject = {};
    const healthData = await this.healthDiaryRepository.find({
      where: {
        userId: userId,
      },
      order: ['created DESC'],
    });

    let footExamination = await this.footExaminationRepository.findOne({
      where: {userId: userId},
      order: ['created DESC'],
    });
    let eyeExamination = await this.eyeExaminationRepository.findOne({
      where: {userId: userId},
      order: ['created DESC'],
    });

    let medication = await this.medicationRepository.findOne({
      where: {userId: userId},
      order: ['created DESC'],
    });

    const waistGoal = await this.waistgoalRepository.findOne({
      where: {
        userId: userId,
      },
      order: ['created DESC'],
    });

    if (healthData && healthData.length) {
      let types = _.map(healthData, function(val: any) {
        return (val && val.type != undefined && val.type) || '';
      });

      let healthType = _.uniq(types);
      let waistObject: AnyObject = {};
      let hbaicLevelObject: AnyObject = {};
      let psaObject: AnyObject = {};
      let health =
        healthData && healthData.length && _.groupBy(healthData, v => v.type);
      _.forEach(healthType, function(val: any) {
        let healtyDiaryData: AnyObject =
          (health && health[val] && health[val][0]) || {};
        let data = (health && health[val]) || [];

        // if (val === "weight") {
        let result = _.orderBy(
          data,
          function(e: any) {
            return _.lowerCase(e[val]?.date);
          },
          ['desc'],
        );
        // }
        if (val === 'waist') {
          waistObject = {waist: result[0]};
        }

        if (val === 'hbaicLevel') {
          let hbaicLevel = _.orderBy(data, ['date'], ['desc']);
          hbaicLevelObject = {hbaicLevel: hbaicLevel[0]};
        }
        if (val === 'psa') {
          psaObject = {psa: result[0]};
        }
        responseData.push(Object.assign({}, result[0]));
      });

      let weight = responseData.reduce(
        (obj, item) => Object.assign(obj, {[item.type]: item.weight}),
        {},
      );
      let waist = responseData.reduce(
        (obj, item) => Object.assign(obj, {[item.type]: item.waist}),
        {},
      );
      let hbaicLevel = responseData.reduce(
        (obj, item) => Object.assign(obj, {[item.type]: item.hbaicLevel}),
        {},
      );
      let cholesterol = responseData.reduce(
        (obj, item) => Object.assign(obj, {[item.type]: item}),
        {},
      );
      let psa = responseData.reduce(
        (obj, item) => Object.assign(obj, {[item.type]: item.psa}),
        {},
      );
      let bmi = responseData.reduce(
        (obj, item) => Object.assign(obj, {[item.type]: item.bmi}),
        {},
      );
      let bloodPressure = responseData.reduce(
        (obj, item) => Object.assign(obj, {[item.type]: item.bloodPressure}),
        {},
      );
      let exercise = responseData.reduce(
        (obj, item) => Object.assign(obj, {[item.type]: item.exercise}),
        {},
      );
      let glucose = responseData.reduce(
        (obj, item) => Object.assign(obj, {[item.type]: item}),
        {},
      );

      result.weight = (weight && weight.weight) || {};
      result.waist = (waist && waist.waist) || {};
      result.hbaicLevel = (hbaicLevel && hbaicLevel.hbaicLevel) || 0;
      result.cholesterol = (cholesterol && cholesterol.cholesterol) || {};
      result.psa = (psa && psa.psa) || {};
      result.bmi = (bmi && bmi.bmi) || {};
      result.bloodPressure =
        (bloodPressure && bloodPressure.bloodPressure) || {};
      result.exercise = (exercise && exercise.exercise) || {};
      result.psa = (psa && psa.psa) || {};
      result.glucose = (glucose && glucose.glucose) || {};
      result.eyeExamination =
        (eyeExamination && eyeExamination.id && eyeExamination) || {};
      result.footExamination =
        (footExamination && footExamination.id && footExamination) || {};
      result.medicationPassports =
        (medication && medication.id && medication) || {};
      result.waistObject =
        (waistObject && waistObject.waist && waistObject.waist) || {};
      result.hbaicLevelObject =
        (hbaicLevelObject &&
          hbaicLevelObject.hbaicLevel &&
          hbaicLevelObject.hbaicLevel) ||
        {};
      result.psaObject = (psaObject && psaObject.psa && psaObject.psa) || {};
      result.waistWeightgoal = (waistGoal && waistGoal.id && waistGoal) || {};
      return result;
      // const weightData = _.filter(healthData, function (val: any) {
      //   return val.weight !== undefined
      // })
      // const filterData = _.orderBy(weightData, function (e) { return _.lowerCase(e.created) }, ['desc']);
      // const otherData = _.filter(healthData, function (val: any) {
      //   return val.weight === undefined
      // })
      // const weight = filterData && filterData[0] || []
      // _.forEach(otherData)
      // otherData.push(weight)
      // responseData = Object.assign({}, weight)
      // // responseData = {
      // //   otherData
      // // }
      // return otherData || [];
    } else {
      return {};
    }
  }

  @get('/health-diaries/getGlucoseDetailsByUsreId/', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'HealthDiary  success',
      },
    },
  })
  @authenticate('jwt')
  async getGlucoseDetailsByUsreId(
    @inject(SecurityBindings.USER) currentUser: UserProfile,
    @param.query.string('mealType') mealType: string,
  ): Promise<any> {
    let responseData: Array<AnyObject> = [];
    let query: AnyObject = {
      userId: currentUser[securityId],
      type: 'glucose',
    };
    if (mealType) {
      query = {
        'glucose.mealType': mealType,
      };
    }
    const healthData = await this.healthDiaryRepository.find({
      where: query,
      order: ['created DESC'],
    });
    if (healthData && healthData.length) {
      return healthData;
    } else {
      return {};
    }
  }

  @get('/health-diaries/userHealthPassportReports/', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'HealthDiary  success',
      },
    },
  })
  @authenticate('jwt')
  async userHealthPassportReports(
    @inject(SecurityBindings.USER) currentUser: UserProfile,
  ): Promise<any> {
    let responseData: AnyObject = {};
    return Promise.all([
      this.healthConditionRepository.find({
        where: {
          userId: currentUser[securityId],
        },
        include: [{relation: 'disease'}],
      }),
      this.treatmentRepository.findOne({
        where: {
          userId: currentUser[securityId],
        },
      }),
      this.medicationRepository.find({
        where: {
          userId: currentUser[securityId],
        },
        include: [{relation: 'medicine'}],
      }),
      this.footExaminationRepository.find({
        where: {
          userId: currentUser[securityId],
        },
      }),
      this.healthProcedureSurgeriesRepository.find({
        where: {
          userId: currentUser[securityId],
        },
        include: [{relation: 'surgeryProcedure'}],
      }),
      this.ProviderRepository.find({
        where: {
          userId: currentUser[securityId],
        },
      }),
      this.pharmacyRepository.find({
        where: {
          userId: currentUser[securityId],
        },
      }),
      this.procedureSurgeriesRepository.find({
        where: {
          userId: currentUser[securityId],
        },
      }),
      this.eyeExaminationRepository.find({
        where: {
          userId: currentUser[securityId],
        },
      }),
      this.labsProceduresRepository.find({
        where: {
          userId: currentUser[securityId],
        },
        include: [{relation: 'lab'}],
      }),
    ]).then(res => {
      // let pastHealth = _.filter(res[0], function (val: any) {
      //   return val.type === 'past'
      // })
      // let currentHealth = _.filter(res[0], function (val: any) {
      //   return val.type === 'current'
      // })
      // let pastMedication = _.filter(res[2], function (val: any) {
      //   return val.type === 'past'
      // })
      // let currentMedication = _.filter(res[2], function (val: any) {
      //   return val.type === 'current'
      // })
      responseData = {
        healthCondition: (res && res[0]?.length && res[0]) || [],
        healthMedication: (res && res[2]?.length && res[2]) || [],
        treatmentDetail: (res && res[1]) || {},
        footExam: (res && res[3]?.length && res[3]) || [],
        procedureSurgeries: (res && res[4]?.length && res[4]) || [],
        providers: (res && res[5]?.length && res[5]) || [],
        pharmecies: (res && res[6]?.length && res[6]) || [],
        eyeExam: (res && res[8]?.length && res[8]) || [],
        labs: (res && res[9]?.length && res[9]) || [],
      };
      return responseData;
    });
  }

  @get('/health-diaries/getHealthPassportByUserId/{userId}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'HealthDiary  success',
      },
    },
  })
  @authenticate('jwt')
  async getHealthPassportByUserId(
    @param.path.string('userId') userId: string,
  ): Promise<any> {
    let responseData: AnyObject = {};
    return Promise.all([
      this.healthConditionRepository.find({
        where: {
          userId: userId,
        },
        include: [{relation: 'disease'}],
      }),
      this.treatmentRepository.findOne({
        where: {
          userId: userId,
        },
      }),
      this.medicationRepository.find({
        where: {
          userId: userId,
        },
        include: [{relation: 'medicine'}],
      }),
      this.footExaminationRepository.find({
        where: {
          userId: userId,
        },
      }),
      this.healthProcedureSurgeriesRepository.find({
        where: {
          userId: userId,
        },
        include: [{relation: 'surgeryProcedure'}],
      }),
      this.ProviderRepository.find({
        where: {
          userId: userId,
        },
      }),
      this.pharmacyRepository.find({
        where: {
          userId: userId,
        },
      }),
      this.procedureSurgeriesRepository.find({
        where: {
          userId: userId,
        },
      }),
      this.eyeExaminationRepository.find({
        where: {
          userId: userId,
        },
      }),
      this.labsProceduresRepository.find({
        where: {
          userId: userId,
        },
        include: [{relation: 'lab'}],
      }),
    ]).then(res => {
      // let pastHealth = _.filter(res[0], function (val: any) {
      //   return val.type === 'past'
      // })
      // let currentHealth = _.filter(res[0], function (val: any) {
      //   return val.type === 'current'
      // })
      // let pastMedication = _.filter(res[2], function (val: any) {
      //   return val.type === 'past'
      // })
      // let currentMedication = _.filter(res[2], function (val: any) {
      //   return val.type === 'current'
      // })
      responseData = {
        healthCondition: (res && res[0]?.length && res[0]) || [],
        healthMedication: (res && res[2]?.length && res[2]) || [],
        treatmentDetail: (res && res[1]) || {},
        footExam: (res && res[3]?.length && res[3]) || [],
        procedureSurgeries: (res && res[4]?.length && res[4]) || [],
        providers: (res && res[5]?.length && res[5]) || [],
        pharmecies: (res && res[6]?.length && res[6]) || [],
        eyeExam: (res && res[8]?.length && res[8]) || [],
        labs: (res && res[9]?.length && res[9]) || [],
      };
      return responseData;
    });
  }

  @get('/health-diaries/dashboardHealthDiary/', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'HealthDiary  success',
      },
    },
  })
  @authenticate('jwt')
  async dashboardHealthDiary(
    @inject(SecurityBindings.USER) currentUser: UserProfile,
    @param.query.string('type') type: string,
  ): Promise<any> {
    const dashboardHealthData = await this.healthDiaryRepository.find({
      where: {
        userId: currentUser[securityId],
        type: type,
      },
      order: ['created DESC'],
    });
    if (dashboardHealthData && dashboardHealthData.length) {
      return dashboardHealthData;
    } else {
      return [];
    }
  }

  @get('/health-diaries/updateNumberToString/', {
    responses: {
      '200': {
        description: 'HealthDiary  success',
      },
    },
  })
  async updateNumberToString(): Promise<any> {
    return false;
    const healthDiary = await this.healthDiaryRepository.find({});
    if (healthDiary && healthDiary.length) {
      const _this = this;
      _.forEach(healthDiary, async function(val: any) {
        let payload: AnyObject = {};
        if (val && val.type == 'bloodPressure') {
          let payload = {
            bloodPressure: {
              systolic: String(
                (val && val.bloodPressure && val.bloodPressure.systolic) || '',
              ),
              diastolic: String(
                (val && val.bloodPressure && val.bloodPressure.diastolic) || '',
              ),
            },
          };
          await _this.healthDiaryRepository.updateById(val.id, payload);
        }
        if (val && val.type == 'exercise') {
          let payload = {
            exercise: {
              duration: String(
                (val && val.exercise && val.exercise.duration) || '',
              ),
              intensity: String(
                (val && val.exercise && val.exercise.intensity) || '',
              ),
              created: (val && val.exercise && val.exercise.created) || '',
            },
          };
          await _this.healthDiaryRepository.updateById(val.id, payload);
        }
        if (val && val.type == 'psa') {
          let payload = {
            psa: {
              totalPSA: String((val && val.psa && val.psa.totalPSA) || ''),
              freePSA: String(val && val.psa && val.psa.freePSA),
            },
          };
          await _this.healthDiaryRepository.updateById(val.id, payload);
        }
        if (val && val.type == 'weight') {
          let payload = {
            weight: {
              value: String((val && val.weight && val.weight.value) || ''),
              unit: String(val && val.weight && val.weight.unit),
              goal: String(val && val.weight && val.weight.goal),
            },
          };
          // await _this.healthDiaryRepository.updateById(val.id,payload)
        }
        if (val && val.type == 'bmi') {
          let payload = {
            bmi: {
              value: String((val && val.bmi && val.bmi.value) || ''),
              message: String((val && val.bmi && val.bmi.message) || ''),
              goal: String((val && val.bmi && val.bmi.goal) || ''),
            },
          };
          await _this.healthDiaryRepository.updateById(val.id, payload);
        }
        if (val && val.type == 'waist') {
          let payload = {
            waist: {
              value: String((val && val.waist && val.waist.value) || ''),
              unit: String((val && val.waist && val.waist.unit) || ''),
              goal: String((val && val.waist && val.waist.goal) || ''),
            },
          };
          await _this.healthDiaryRepository.updateById(val.id, payload);
        }

        if (val && val.type == 'cholesterol') {
          let payload = {
            cholesterol: {
              cholesterol: String(
                (val && val.cholesterol && val.cholesterol.cholesterol) || '',
              ),
              triglycerides: String(
                (val && val.cholesterol && val.cholesterol.triglycerides) || '',
              ),
              hdl: String(
                (val && val.cholesterol && val.cholesterol.hdl) || '',
              ),
              ldl: String(
                (val && val.cholesterol && val.cholesterol.ldl) || '',
              ),
            },
          };
          await _this.healthDiaryRepository.updateById(val.id, payload);
        }
        if (val && val.type == 'glucose') {
          let payload = {
            glucose: {
              breakfast: {
                before: String(
                  (val &&
                    val.glucose &&
                    val.glucose.breakfast &&
                    val.glucose.breakfast.before) ||
                    '',
                ),
                after: String(
                  (val &&
                    val.glucose &&
                    val.glucose.breakfast &&
                    val.glucose.breakfast.after) ||
                    '',
                ),
              },
              lunch: {
                before: String(
                  (val &&
                    val.glucose &&
                    val.glucose.lunch &&
                    val.glucose.lunch.after) ||
                    '',
                ),
                after: String(
                  (val &&
                    val.glucose &&
                    val.glucose.lunch &&
                    val.glucose.lunch.after) ||
                    '',
                ),
              },
              dinner: {
                before: String(
                  (val &&
                    val.glucose &&
                    val.glucose.dinner &&
                    val.glucose.dinner.after) ||
                    '',
                ),
                after: String(
                  (val &&
                    val.glucose &&
                    val.glucose.dinner &&
                    val.glucose.dinner.after) ||
                    '',
                ),
              },
              snacks: {
                before: String(
                  (val &&
                    val.glucose &&
                    val.glucose.snacks &&
                    val.glucose.snacks.after) ||
                    '',
                ),
                after: String(
                  (val &&
                    val.glucose &&
                    val.glucose.snacks &&
                    val.glucose.snacks.after) ||
                    '',
                ),
              },
              unit: val && val.glucose && val.glucose.unit,
            },
          };
          await _this.healthDiaryRepository.updateById(val.id, payload);
        }
      });
    }
  }

  @get('/healthDiaryExerciseChart/{userId}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of HealthDiary model instances',
        content: {
          'application/json': {
            schema: {type: 'array'},
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async healthDiaryExerciseChart(
    @param.path.string('userId') userId: string,
  ): Promise<any> {
    let result: Array<AnyObject> = [];

    let query: AnyObject = {
      userId: userId,
      type: 'exercise',
    };

    let exercises = await this.healthDiaryRepository.find({
      where: query,
    });
    _.forEach(exercises, function(val: any) {
      let exercie = val && val.exercise && val.exercise.duration;
      let strng = exercie.slice(exercie.length - 3);
      let excer: any = '';
      if (strng === 'min') {
        excer = Number(exercie.slice(0, -3));
      } else {
        excer = Number(exercie);
      }
      let obj: any = {
        name: moment(val.exercise.date).format('DD/MM'),
        value: excer,
      };
      result.push(obj);
    });
    return result;
  }

  @get('/healthDiaryBloodPressureChart/{userId}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of HealthDiary model instances',
        content: {
          'application/json': {
            schema: {type: 'array'},
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async healthDiaryBloodPressureChart(
    @param.path.string('userId') userId: string,
  ): Promise<any> {
    let response: Array<AnyObject> = [];
    let query: AnyObject = {
      userId: userId,
      type: 'bloodPressure',
    };

    let bloodPressure = await this.healthDiaryRepository.find({
      where: query,
    });
    _.forEach(bloodPressure, function(val: any) {
      let obj: any = {
        name: moment(val.bloodPressure.date).format('DD/MM'),
        systolic: Number(val.bloodPressure && val.bloodPressure.systolic),
        diastolic: Number(val.bloodPressure && val.bloodPressure.diastolic),
      };
      response.push(obj);
    });
    return response;
  }

  @post('/healthDiaryWeightChart', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of HealthDiary model instances',
        content: {
          'application/json': {
            schema: {type: 'array'},
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async healthDiaryWeightChart(@requestBody() data: any): Promise<any> {
    let response: Array<AnyObject> = [];
    let filterData: Array<AnyObject> = [];
    let query: AnyObject = {
      userId: String(data.userId),
      type: 'weight',
    };
    if (data && data.startDate) {
      query.created = {gte: moment(data.startDate).toDate()};
    }
    if (data && data.endDate) {
      query.created = {lte: moment(data.endDate).toDate()};
    }

    filterData = await this.healthDiaryRepository.find({
      where: query,
    });
    if (data && data.endDate && data.startDate) {
      filterData = _.filter(filterData, function(val: any) {
        return (
          _.gte(val.created, data.startDate) && _.lte(val.created, data.endDate)
        );
      });
    }

    _.forEach(filterData, function(val: any, index) {
      let obj: any = {
        name: moment(val.weight.date).format('DD/MM') || '',
        weight: Number(val.weight && val.weight.value),
        goal: Number(val.weight && val.weight.goal) || '',
      };
      response.push(obj);
    });
    return response;
  }

  @get('/healthDiaryWaistChart/{userId}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of HealthDiary model instances',
        content: {
          'application/json': {
            schema: {type: 'array'},
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async healthDiaryWaistChart(
    @param.path.string('userId') userId: string,
  ): Promise<any> {
    let response: Array<AnyObject> = [];
    let query: AnyObject = {
      userId: userId,
      type: 'waist',
    };

    let bloodPressure = await this.healthDiaryRepository.find({
      where: query,
    });
    _.forEach(bloodPressure, function(val: any) {
      let obj: any = {
        name: moment(val.waist.date).format('DD/MM'),
        waist: Number(val.waist && val.waist.value),
        goal: Number(val.waist && val.waist.goal) || '',
      };
      response.push(obj);
    });
    return response;
  }

  @get('/userHealthDiaryByUserId/{userId}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'User Health Metrics',
        content: {
          'application/json': {
            schema: {
              type: 'object',
              properties: {
                bmi: getModelSchemaRef(Bmi),
                prostrate: getModelSchemaRef(Psa),
                weight: getModelSchemaRef(Weight),
                bloodSugar: getModelSchemaRef(Hbaic),
                exercise: getModelSchemaRef(Exercise),
                glucose: getModelSchemaRef(BloodSugar),
                cholesterol: getModelSchemaRef(Cholestrol),
                waist: getModelSchemaRef(WaistCircumference),
                pregnancy: getModelSchemaRef(PregnancyCycle),
                bloodPressure: getModelSchemaRef(BloodPressure),
                medication: getModelSchemaRef(MedicationPassport),
                eyeExamination: getModelSchemaRef(EyeExamination),
                footExamination: getModelSchemaRef(FootExamination),
                temperature: getModelSchemaRef(Temperature),
              },
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async getUserHealthDiaryByUserId(
    @param.path.string('userId') userId: string,
  ): Promise<any> {
    return this.healthDiaryService.getUserHealthDiaryByUserId(userId);
  }
}
