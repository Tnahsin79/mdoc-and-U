import {
  get,
  del,
  post,
  param,
  patch,
  requestBody,
  getModelSchemaRef,
  getFilterSchemaFor,
} from '@loopback/rest';
import Utils from '../utils';
import {GoalAction} from '../models';
import {inject} from '@loopback/core';
import {Filter} from '@loopback/repository';
import {GoalActionService} from '../services';
import {GoalActionServiceBindings} from '../keys';
import {PaginatedResponse} from '../type-schema';
import {authenticate} from '@loopback/authentication';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';

export class GoalActionController {
  constructor(
    @inject(GoalActionServiceBindings.GOAL_ACTION_SERVICE)
    public goalActionService: GoalActionService,
  ) {}

  @post('/goal-actions', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'GoalAction model instance',
        content: {'application/json': {schema: getModelSchemaRef(GoalAction)}},
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(GoalAction, {
            title: 'NewGoalAction',
            exclude: ['id'],
          }),
        },
      },
    })
    goalAction: Omit<GoalAction, 'id'>,
  ): Promise<GoalAction> {
    return this.goalActionService.create(goalAction);
  }

  @get('/goal-actions', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'Array of GoalAction model instances',
        content: {
          'application/json': {
            schema: Utils.paginatedSchema(GoalAction, true),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async find(
    @param.query.object('filter') filter?: Filter<GoalAction>,
    @param.query.number('page') page?: number,
  ): Promise<PaginatedResponse<GoalAction>> {
    return this.goalActionService.find(filter, page);
  }

  @get('/goal-actions/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'GoalAction model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(GoalAction, {includeRelations: true}),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(GoalAction))
    filter?: Filter<GoalAction>,
  ): Promise<GoalAction> {
    return this.goalActionService.findById(id, filter);
  }

  @patch('/goal-actions/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      204: {
        description: 'GoalActions PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(GoalAction, {
            partial: true,
            exclude: ['id', 'created_at'],
          }),
        },
      },
    })
    goalAction: GoalAction,
  ): Promise<void> {
    await this.goalActionService.updateById(id, goalAction);
  }

  @del('/goal-actions/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      204: {
        description: 'GoalActions DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.goalActionService.deleteById(id);
  }
}
