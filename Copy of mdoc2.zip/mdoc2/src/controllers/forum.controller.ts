import {
  get,
  put,
  del,
  post,
  param,
  patch,
  requestBody,
  getModelSchemaRef,
  getFilterSchemaFor,
} from '@loopback/rest';
import {
  Forum,
  ForumUser,
  ForumWithRelations,
  ForumUserWithRelations,
} from '../models';
import {inject} from '@loopback/core';
import {ForumService} from '../services';
import {ForumServiceBindings} from '../keys';
import {Filter} from '@loopback/repository';
import {PaginatedResponse} from '../type-schema';
import {authenticate} from '@loopback/authentication';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';

export class ForumController {
  constructor(
    @inject(ForumServiceBindings.FORUM_SERVICE)
    public forumService: ForumService,
  ) {}

  @post('/forum', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Forum model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Forum, {includeRelations: true}),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Forum, {
            title: 'NewForum',
            exclude: ['id'],
          }),
        },
      },
    })
    forum: Omit<Forum, 'id'>,
  ): Promise<Forum> {
    return this.forumService.create(forum);
  }

  @put('/forum/participants/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'ForumUser model instance',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(ForumUser, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async updateForumParticipants(
    @requestBody({
      content: {
        'application/json': {
          schema: {
            type: 'array',
            items: getModelSchemaRef(ForumUser, {
              title: 'NewForumUser',
              exclude: ['id'],
            }),
          },
        },
      },
    })
    forumUser: Omit<ForumUser, 'id'>[],
    @param.path.string('id') forumId: string,
  ): Promise<ForumUserWithRelations[]> {
    return this.forumService.updateForumParticipants(forumId, forumUser);
  }

  @get('/forum', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of Forum model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(Forum, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findAll(
    @param.query.object('filter', getFilterSchemaFor(Forum))
    filter?: Filter<Forum>,
    @param.query.number('page') page?: number,
  ): Promise<PaginatedResponse<Forum>> {
    return this.forumService.findAll(filter, page);
  }

  @get('/forum/user/{userId}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Get forums by userId',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(Forum, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async getUserForums(
    @param.path.string('userId') userId: string,
  ): Promise<ForumWithRelations[]> {
    return this.forumService.getUserForums(userId);
  }

  @get('/forum/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Forum model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Forum, {includeRelations: true}),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(Forum))
    filter?: Filter<Forum>,
  ) {
    return this.forumService.findById(id, filter);
  }

  @patch('/forum/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Forum PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Forum, {partial: true}),
        },
      },
    })
    forum: Forum,
  ): Promise<void> {
    return await this.forumService.updateById(id, forum);
  }

  @del('/forum/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Forum DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    return this.forumService.deleteById(id);
  }
}
