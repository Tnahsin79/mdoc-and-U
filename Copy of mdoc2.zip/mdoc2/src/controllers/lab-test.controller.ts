import {
  get,
  del,
  post,
  patch,
  param,
  requestBody,
  getModelSchemaRef,
  getFilterSchemaFor,
} from '@loopback/rest';
import {LabTest} from '../models';
import {inject} from '@loopback/core';
import {Filter} from '@loopback/repository';
import {LabTestService} from '../services';
import {PaginatedResponse} from '../type-schema';
import {LabTestServiceBindings} from '../keys';
import {authenticate} from '@loopback/authentication';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';
import {UserProfile, SecurityBindings} from '@loopback/security';
import Utils from '../utils';

export class LabTestController {
  constructor(
    @inject(LabTestServiceBindings.LAB_TEST_SERVICE)
    public labTestService: LabTestService,
  ) {}

  @post('/lab-test', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'LabTest model instance',
        content: {
          'application/json': {schema: getModelSchemaRef(LabTest)},
        },
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(LabTest, {
            title: 'NewLabTest',
            exclude: ['id'],
          }),
        },
      },
    })
    labTest: Omit<LabTest, 'id'>,
    @inject(SecurityBindings.USER) currentUser: UserProfile,
  ): Promise<LabTest> {
    return this.labTestService.create(labTest, currentUser);
  }

  @get('/lab-test', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of LabTest model instances',
        content: {
          'application/json': {
            schema: Utils.paginatedSchema(LabTest, true),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findAll(
    @param.query.object('filter', getFilterSchemaFor(LabTest))
    filter?: Filter<LabTest>,
    @param.query.number('page') page?: number,
  ): Promise<PaginatedResponse<LabTest>> {
    return this.labTestService.findAll(filter, page);
  }

  @get('/lab-test/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'LabTest model instance',
        content: {'application/json': {schema: getModelSchemaRef(LabTest)}},
      },
    },
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
  ): Promise<LabTest> {
    return this.labTestService.findById(id);
  }

  @patch('/lab-test/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'LabTest PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(LabTest, {partial: true}),
        },
      },
    })
    labTest: LabTest,
  ): Promise<void> {
    return this.labTestService.updateById(id, labTest);
  }
}
