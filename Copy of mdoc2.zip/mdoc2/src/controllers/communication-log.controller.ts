import {
  post,
  del,
  get,
  patch,
  param,
  requestBody,
  getModelSchemaRef,
  getFilterSchemaFor,
} from '@loopback/rest';
import {
  PaginatedResponse,
  BulkCommunicationLog,
  BulkCommunicationRequestBody,
} from '../type-schema';
import {inject} from '@loopback/core';
import {Filter} from '@loopback/repository';
import {CommunicationLogService} from '../services';
import {authenticate} from '@loopback/authentication';
import {CommunicationLogServiceBindings} from '../keys';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';
import {CommunicationLog, CommunicationLogWithRelations} from '../models';

export class CommunicationLogController {
  constructor(
    @inject(CommunicationLogServiceBindings.COMMUNICATION_LOG)
    public communicationLogService: CommunicationLogService,
  ) {}

  @post('/communication-log', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'CommunicationLog model instance',
        content: {
          'application/json': {schema: getModelSchemaRef(CommunicationLog)},
        },
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(CommunicationLog, {
            exclude: ['id'],
          }),
        },
      },
    })
    log: Omit<CommunicationLog, 'id'>,
  ): Promise<CommunicationLogWithRelations> {
    return this.communicationLogService.create(log);
  }

  @post('/bulk-communication-log', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      201: {
        description: 'CommunicationLog model instance',
        content: {
          'application/json': {schema: getModelSchemaRef(CommunicationLog)},
        },
      },
    },
  })
  @authenticate('jwt')
  async bulkCreate(
    @requestBody(BulkCommunicationRequestBody)
    bulkCommunicationLog: BulkCommunicationLog,
  ): Promise<CommunicationLog[]> {
    console.log(bulkCommunicationLog);
    return this.communicationLogService.bulkCreate(bulkCommunicationLog);
  }

  @get('/communication-log/byUserId', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'Array of Communication Log model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(CommunicationLog, {
                includeRelations: true,
              }),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async getByUserId(
    @param.query.string('userId') userId: string,
  ): Promise<CommunicationLogWithRelations[]> {
    return this.communicationLogService.getByUserId(userId);
  }

  @get('/communication-log/byCoachId', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'Array of Communication Log model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(CommunicationLog, {
                includeRelations: true,
              }),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async getByCoachId(
    @param.query.string('coachId') coachId: string,
    @param.query.object('filter', getFilterSchemaFor(CommunicationLog))
    filter?: Filter<CommunicationLog>,
    @param.query.number('page') page?: number,
  ): Promise<PaginatedResponse<CommunicationLogWithRelations>> {
    const limit = filter?.limit ? filter.limit : 25;
    return this.communicationLogService.getByCoachId(coachId, limit, page);
  }

  @get('/communication-log/byUserIdAndCoachId', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'Array of Communication Log model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(CommunicationLog, {
                includeRelations: true,
              }),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async getByUserIdAndCoachId(
    @param.query.string('userId') userId: string,
    @param.query.string('coachId') coachId: string,
  ): Promise<CommunicationLogWithRelations[]> {
    return this.communicationLogService.getByUserIdAndCoachId(userId, coachId);
  }

  @patch('/communication-log/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      204: {
        description: 'Update successful',
        content: {},
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(CommunicationLog, {partial: true}),
        },
      },
    })
    log: CommunicationLog,
    @param.path.string('id') id: string,
  ): Promise<void> {
    return this.communicationLogService.updateById(id, log);
  }

  @del('/communication-log/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      204: {
        description: 'Communication Log deleted successfully',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.communicationLogService.deleteById(id);
  }
}
