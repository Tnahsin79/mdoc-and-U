import {
  Count,
  CountSchema,
  Filter,
  repository,
  Where,
} from '@loopback/repository';
import {
  post,
  param,
  get,
  getFilterSchemaFor,
  getModelSchemaRef,
  getWhereSchemaFor,
  patch,
  put,
  del,
  requestBody,
} from '@loopback/rest';
import {Children} from '../models';
import {ChildrenRepository} from '../repositories';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';
import {authenticate} from '@loopback/authentication';
import {inject} from '@loopback/core';
import {UserProfile, securityId, SecurityBindings} from '@loopback/security';
import {ChildrenServiceBindings} from '../keys';
import {ChildrenService} from '../services/children.service';
export class ChildrenController {
  constructor(
    @repository(ChildrenRepository)
    public childrenRepository: ChildrenRepository,
    @inject(ChildrenServiceBindings.CHILDREN_SERVICE)
    childrenService: ChildrenService,
  ) {}

  @post('/children', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Children model instance',
        content: {'application/json': {schema: getModelSchemaRef(Children)}},
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Children, {
            title: 'NewChildren',
            exclude: ['id'],
          }),
        },
      },
    })
    children: Omit<Children, 'id'>,
  ): Promise<Children> {
    return this.childrenRepository.create(children);
  }

  @get('/children/count', {
    responses: {
      '200': {
        description: 'Children model count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async count(
    @param.query.object('where', getWhereSchemaFor(Children))
    where?: Where<Children>,
  ): Promise<Count> {
    return this.childrenRepository.count(where);
  }

  @get('/children', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of Children model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(Children, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async find(
    @param.query.object('filter', getFilterSchemaFor(Children))
    filter?: Filter<Children>,
  ): Promise<Children[]> {
    return this.childrenRepository.find(filter);
  }

  @patch('/children', {
    responses: {
      '200': {
        description: 'Children PATCH success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Children, {partial: true}),
        },
      },
    })
    children: Children,
    @param.query.object('where', getWhereSchemaFor(Children))
    where?: Where<Children>,
  ): Promise<Count> {
    return this.childrenRepository.updateAll(children, where);
  }

  @get('/children/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Children model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Children, {includeRelations: true}),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(Children))
    filter?: Filter<Children>,
  ): Promise<Children> {
    return this.childrenRepository.findById(id, filter);
  }

  @patch('/children/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Children PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Children, {partial: true}),
        },
      },
    })
    children: Children,
  ): Promise<void> {
    await this.childrenRepository.updateById(id, children);
  }

  @put('/children/{id}', {
    responses: {
      '204': {
        description: 'Children PUT success',
      },
    },
  })
  async replaceById(
    @param.path.string('id') id: string,
    @requestBody() children: Children,
  ): Promise<void> {
    await this.childrenRepository.replaceById(id, children);
  }

  @del('/children/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Children DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.childrenRepository.deleteById(id);
  }

  @get('/children/getUserChildren/', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Children  success',
      },
    },
  })
  @authenticate('jwt')
  async getUserChildren(
    @inject(SecurityBindings.USER) currentUser: UserProfile,
  ): Promise<any> {
    const children = await this.childrenRepository.find({
      where: {
        userId: currentUser[securityId],
      },
    });
    if (children && children.length) {
      return children;
    } else {
      return [];
    }
  }
}
