import {
  post,
  param,
  get,
  getModelSchemaRef,
  patch,
  del,
  requestBody,
  getFilterSchemaFor,
} from '@loopback/rest';
import {Exercise} from '../models';
import {inject} from '@loopback/core';
import {ExerciseService} from '../services';
import {Filter} from '@loopback/repository';
import {ExerciseServiceBindings} from '../keys';
import {PaginatedResponse} from '../type-schema';
import {authenticate} from '@loopback/authentication';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';

export class ExerciseController {
  constructor(
    @inject(ExerciseServiceBindings.EXERCISE_SERVICE)
    public exerciseService: ExerciseService,
  ) {}

  @post('/exercise', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Exercise model instance',
        content: {
          'application/json': {schema: getModelSchemaRef(Exercise)},
        },
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Exercise, {
            title: 'NewExercise',
            exclude: ['id'],
          }),
        },
      },
    })
    exercise: Omit<Exercise, 'id'>,
  ): Promise<Exercise> {
    return this.exerciseService.create(exercise);
  }

  @get('/exercise', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of Exercise model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(Exercise, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findAll(
    @param.query.object('filter', getFilterSchemaFor(Exercise))
    filter?: Filter<Exercise>,
    @param.query.number('page') page?: number,
  ): Promise<PaginatedResponse<Exercise>> {
    return this.exerciseService.findAll(filter, page);
  }

  @get('/exercise/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Exercise model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Exercise, {includeRelations: true}),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(Exercise))
    filter?: Filter<Exercise>,
  ) {
    return this.exerciseService.findById(id, filter);
  }

  @patch('/exercise/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Exercise PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Exercise, {partial: true}),
        },
      },
    })
    exercise: Exercise,
  ): Promise<void> {
    return await this.exerciseService.updateById(id, exercise);
  }

  @del('/exercise/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Exercise DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    this.exerciseService.deleteById(id);
  }
}
