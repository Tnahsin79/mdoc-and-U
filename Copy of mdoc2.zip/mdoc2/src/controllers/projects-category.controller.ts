import { authenticate } from '@loopback/authentication';
import { Count, CountSchema, Filter, repository, Where, } from '@loopback/repository';
import { post, param, get, getModelSchemaRef, patch, put, del, requestBody, getFilterSchemaFor, } from '@loopback/rest';
import { ProjectsCategory } from '../models';
import { ProjectsCategoryRepository } from '../repositories';
import { OPERATION_SECURITY_SPEC } from '../utils/security-spec';
import csv from 'csvtojson'
import { inject } from '@loopback/core';
import { MigrationServiceBindings } from '../keys';
import { MigrationService } from '../services/migration.service';
export class ProjectsCategoryController {
  constructor(
    @repository(ProjectsCategoryRepository) public projectsCategoryRepository: ProjectsCategoryRepository,
    @inject(MigrationServiceBindings.MIGRATION_SERVICE) public migrationService: MigrationService
  ) { }

  @post('/projects-categories', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'ProjectsCategory model instance',
        content: { 'application/json': { schema: getModelSchemaRef(ProjectsCategory) } },
      },
    }
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(ProjectsCategory, {
            title: 'NewProjectsCategory',
            exclude: ['id'],
          }),
        },
      },
    })
    projectsCategory: Omit<ProjectsCategory, 'id'>,
  ): Promise<ProjectsCategory> {
    return this.projectsCategoryRepository.create(projectsCategory);
  }

  // @get('/projects-categories/count')
  // @response(200, {
  //   description: 'ProjectsCategory model count',
  //   content: { 'application/json': { schema: CountSchema } },
  // })
  // async count(
  //   @param.where(ProjectsCategory) where?: Where<ProjectsCategory>,
  // ): Promise<Count> {
  //   return this.projectsCategoryRepository.count(where);
  // }

  @get('/projects-categories', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'Array of ProjectsCategory model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(ProjectsCategory, { includeRelations: true }),
            },
          },
        },
      },
    }
  })
  @authenticate('jwt')
  async find(
    @param.query.object('filter', getFilterSchemaFor(ProjectsCategory)) filter?: Filter<ProjectsCategory>,
  ): Promise<ProjectsCategory[]> {
    return this.projectsCategoryRepository.find(filter);
  }

  // @patch('/projects-categories', {
  //   responses: {
  //     200: {
  //       description: 'ProjectsCategory PATCH success count',
  //       content: { 'application/json': { schema: CountSchema } },
  //     },
  //   }
  // })
  // async updateAll(
  //   @requestBody({
  //     content: {
  //       'application/json': {
  //         schema: getModelSchemaRef(ProjectsCategory, { partial: true }),
  //       },
  //     },
  //   })
  //   projectsCategory: ProjectsCategory,
  //   @param.where(ProjectsCategory) where?: Where<ProjectsCategory>,
  // ): Promise<Count> {
  //   return this.projectsCategoryRepository.updateAll(projectsCategory, where);
  // }

  @get('/projects-categories/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'ProjectsCategory model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(ProjectsCategory, { includeRelations: true }),
          },
        },
      },
    }
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(ProjectsCategory)) filter?: Filter<ProjectsCategory>,
  ): Promise<ProjectsCategory> {
    return this.projectsCategoryRepository.findById(id, filter);
  }

  @patch('/projects-categories/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      204: {
        description: 'ProjectsCategory PATCH success',
      },
    }
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(ProjectsCategory, { partial: true }),
        },
      },
    })
    projectsCategory: ProjectsCategory,
  ): Promise<void> {
    await this.projectsCategoryRepository.updateById(id, projectsCategory);
  }

  // @put('/projects-categories/{id}')
  // @response(204, {
  //   description: 'ProjectsCategory PUT success',
  // })
  // async replaceById(
  //   @param.path.string('id') id: string,
  //   @requestBody() projectsCategory: ProjectsCategory,
  // ): Promise<void> {
  //   await this.projectsCategoryRepository.replaceById(id, projectsCategory);
  // }

  @del('/projects-categories/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      204: {
        description: 'ProjectsCategory DELETE success',
      },
    }
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.projectsCategoryRepository.deleteById(id);
  }

  @get('/projectsCategoriesMigration', {
    responses: {
      200: {
        description: 'ProjectsCategory Migration success',
      },
    }
  })
  async projectsCategoriesMigration(
  ): Promise<any> {
    const filePath = './public/projects_category.csv'

    let usersPhamacyList = await csv().fromFile(filePath);
    if (usersPhamacyList && usersPhamacyList.length) {
      for (const value of usersPhamacyList) {
        await this.migrationService.userProjectCategoriesMigration(value)
      }
    }
  }
}
