import {
  get,
  del,
  post,
  param,
  patch,
  requestBody,
  getModelSchemaRef,
  getFilterSchemaFor,
} from '@loopback/rest';
import {
  PdfServiceBindings,
  EmailServiceBindings,
  ReferralServiceBindings,
  ControllerServiceBindings,
} from '../keys';
import {
  UsersRepository,
  CoachRepository,
  ReferralRepository,
  MedicationRepository,
  MedicationPassportRepository,
} from '../repositories';
import Utils from '../utils';
import * as _ from 'lodash';
import {Referral} from '../models';
import {inject} from '@loopback/core';
import {PaginatedResponse} from '../type-schema';
import {PdfService} from '../services/pdf.service';
import {authenticate} from '@loopback/authentication';
import {EmailService} from '../services/email.service';
import {Filter, repository} from '@loopback/repository';
import {ReferralService} from '../services/referral.service';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';
import {ControllerService} from '../services/controller.service';
import {UserProfile, securityId, SecurityBindings} from '@loopback/security';

export class ReferralController {
  constructor(
    @repository(ReferralRepository)
    public referralRepository: ReferralRepository,
    @repository(UsersRepository)
    public usersRepository: UsersRepository,
    @repository(CoachRepository)
    public coachRepository: CoachRepository,
    @repository(MedicationRepository)
    public medicationRepository: MedicationRepository,
    @repository(MedicationPassportRepository)
    public medicationPassportlRepository: MedicationPassportRepository,
    @inject(ControllerServiceBindings.CONTROLLER_SERVICE)
    public controllerService: ControllerService,
    @inject(EmailServiceBindings.MAIL_SERVICE)
    public emailService: EmailService,
    @inject(PdfServiceBindings.PDF_SERVICE)
    public pdfService: PdfService,
    @inject(ReferralServiceBindings.REFERRAL_SERVICE)
    public referralService: ReferralService,
  ) {}

  @post('/referrals', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Referral model instance',
        content: {'application/json': {schema: getModelSchemaRef(Referral)}},
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Referral, {
            title: 'NewReferral',
            exclude: ['id', 'referralStatus', 'approvedById'],
          }),
        },
      },
    })
    referral: Omit<Referral, 'id'>,
  ): Promise<Referral> {
    return await this.referralService.create(referral);
  }

  @get('/referrals', {
    responses: {
      '200': {
        description: 'Array of Referral model instances',
        content: {
          'application/json': {
            schema: Utils.paginatedSchema(Referral, true),
          },
        },
      },
    },
  })
  async find(
    @param.query.object('filter', getFilterSchemaFor(Referral))
    filter?: Filter<Referral>,
    @param.query.number('page') page?: number,
    @param.query.string('search') search?: string,
  ): Promise<PaginatedResponse<Referral>> {
    return this.referralService.find(filter, +page, search);
  }

  @get('/referrals/coach-statistics', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Coach referral statistics',
        content: {
          'application/json': {
            schema: {
              type: 'object',
              properties: {
                totalReferrals: {type: 'number'},
                totalOutboundReferrals: {type: 'number'},
                totalPendingReferrals: {type: 'number'},
                totalAcceptedRefferals: {type: 'number'},
              },
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async getCoachStatistics(
    @inject(SecurityBindings.USER) currentUser: UserProfile,
  ): Promise<{
    totalReferrals: number;
    totalOutboundReferrals: number;
    totalPendingReferrals: number;
    totalAcceptedRefferals: number;
  }> {
    const coachId = currentUser[securityId];
    return this.referralService.getCoachStatistics(coachId);
  }

  @get('/referrals/{id}', {
    responses: {
      '200': {
        description: 'Referral model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Referral, {includeRelations: true}),
          },
        },
      },
    },
  })
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(Referral))
    filter?: Filter<Referral>,
  ): Promise<Referral> {
    return this.referralService.findById(id, filter);
  }

  @patch('/referrals/{id}', {
    responses: {
      '204': {
        description: 'Referral PATCH success',
      },
    },
  })
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Referral, {partial: true}),
        },
      },
    })
    referral: Referral,
  ) {
    await this.referralService.updateById(id, referral);
  }

  @del('/referrals/{id}', {
    responses: {
      '204': {
        description: 'Referral DELETE success',
      },
    },
  })
  async deleteById(@param.path.string('id') id: string) {
    await this.referralService.deleteById(id);
  }
}
