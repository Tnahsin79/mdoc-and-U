import {
  MigrationServiceBindings,
  HealthConditionServiceBindings,
} from '../keys';
import {
  get,
  put,
  del,
  post,
  param,
  patch,
  requestBody,
  getModelSchemaRef,
  getWhereSchemaFor,
  getFilterSchemaFor,
} from '@loopback/rest';
import {
  HealthConditionRepository,
  ActivityTimelineRepository,
} from '../repositories';
import csv from 'csvtojson';
import {
  Count,
  Where,
  Filter,
  repository,
  CountSchema,
} from '@loopback/repository';
import {inject} from '@loopback/core';
import {HealthCondition} from '../models';
import {activityTypeObj} from '../type-schema';
import {authenticate} from '@loopback/authentication';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';
import {MigrationService} from '../services/migration.service';
import {UserProfile, securityId, SecurityBindings} from '@loopback/security';
import {HealthConditionService} from '../services/health-condition.service';

export class HealthConditionController {
  constructor(
    @repository(HealthConditionRepository)
    public healthConditionRepository: HealthConditionRepository,
    @inject(MigrationServiceBindings.MIGRATION_SERVICE)
    public migrationService: MigrationService,
    @inject(HealthConditionServiceBindings.HEALTH_CONDITION_SERVICE)
    public healthCondition: HealthConditionService,
    @repository(ActivityTimelineRepository)
    public activityTimelineRepository: ActivityTimelineRepository,
  ) {}

  @post('/health-conditions', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'HealthCondition model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(HealthCondition, {
              includeRelations: true,
            }),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(HealthCondition, {
            title: 'NewHealthCondition',
            exclude: ['id'],
          }),
        },
      },
    })
    healthCondition: Omit<HealthCondition, 'id'>,
  ): Promise<any> {
    healthCondition.isHealthConditionComplete = true;
    const healthConditionData = await this.healthConditionRepository.create(
      healthCondition,
    );
    const healthconditionResult = await this.healthConditionRepository.findOne({
      where: {
        id: healthConditionData.id,
      },
      include: [{relation: 'disease'}],
    });
    await this.activityTimelineRepository.create({
      activityType: activityTypeObj.HEALTH_CONDITIONS,
      userId: healthConditionData.userId,
      metadata: healthConditionData.id,
    });
    return healthconditionResult;
  }

  @get('/health-conditions/count', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'HealthCondition model count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  @authenticate('jwt')
  async count(
    @param.query.object('where', getWhereSchemaFor(HealthCondition))
    where?: Where<HealthCondition>,
  ): Promise<Count> {
    return this.healthConditionRepository.count(where);
  }

  @get('/health-conditions', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of HealthCondition model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(HealthCondition, {
                includeRelations: true,
              }),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async find(
    @param.query.object('filter', getFilterSchemaFor(HealthCondition))
    filter?: Filter<HealthCondition>,
  ): Promise<HealthCondition[]> {
    return this.healthConditionRepository.find({
      where: filter?.where,
      include: [{relation: 'disease'}],
    });
  }

  @patch('/health-conditions', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'HealthCondition PATCH success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  @authenticate('jwt')
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(HealthCondition, {partial: true}),
        },
      },
    })
    healthCondition: HealthCondition,
    @param.query.object('where', getWhereSchemaFor(HealthCondition))
    where?: Where<HealthCondition>,
  ): Promise<Count> {
    return this.healthConditionRepository.updateAll(healthCondition, where);
  }

  @get('/health-conditions/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'HealthCondition model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(HealthCondition, {
              includeRelations: true,
            }),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(HealthCondition))
    filter?: Filter<HealthCondition>,
  ): Promise<HealthCondition> {
    return this.healthConditionRepository.findById(id, filter);
  }

  @patch('/health-conditions/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'HealthCondition PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(HealthCondition, {partial: true}),
        },
      },
    })
    healthCondition: HealthCondition,
  ): Promise<void> {
    await this.healthConditionRepository.updateById(id, healthCondition);
  }

  @put('/health-conditions/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'HealthCondition PUT success',
      },
    },
  })
  @authenticate('jwt')
  async replaceById(
    @param.path.string('id') id: string,
    @requestBody() healthCondition: HealthCondition,
  ): Promise<void> {
    await this.healthConditionRepository.replaceById(id, healthCondition);
  }

  @del('/health-conditions/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'HealthCondition DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.healthConditionRepository.deleteById(id);
  }

  @get('/health-conditions/dashboardHealthCondition/', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'HealthCondition  success',
      },
    },
  })
  @authenticate('jwt')
  async dashboardHealthCondition(
    @inject(SecurityBindings.USER) currentUser: UserProfile,
  ): Promise<any> {
    const healthCondition = await this.healthConditionRepository.find({
      where: {
        userId: currentUser[securityId],
      },
      order: ['created DESC'],
      include: [{relation: 'disease'}],
    });
    if (healthCondition && healthCondition.length) {
      return healthCondition;
    } else {
      return [];
    }
  }

  @get('/healthConditionsMigration', {
    responses: {
      '200': {
        description: 'HealthCondition  success',
      },
    },
  })
  async healthConditionsMigration(): Promise<any> {
    const filePath = './public/user_conditions.csv';
    let healthData = await csv().fromFile(filePath);
    if (healthData && healthData.length) {
      for (let value of healthData) {
        await this.migrationService.HealthConditionMigration(value);
      }
    }
  }
}
