import { inject } from '@loopback/core';
import { ControllerServiceBindings } from '../keys';
import { ControllerService } from '../services/controller.service';

const file = require('fs')

export class CronController {
  constructor(
    @inject(ControllerServiceBindings.CONTROLLER_SERVICE) public controllerService: ControllerService
  ) { }

  async subscriptionNotification() {
    const coins = await this.controllerService.subscriptionNotification();
    return coins;
  }
}
