import {
  get,
  del,
  post,
  patch,
  param,
  requestBody,
  getModelSchemaRef,
  getFilterSchemaFor,
} from '@loopback/rest';
import {Partner} from '../models';
import {inject} from '@loopback/core';

import {Filter} from '@loopback/repository';
import {
  PartnerServiceBindings,
} from '../keys';
import {PaginatedResponse} from '../type-schema';
import {authenticate} from '@loopback/authentication';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';
import Utils from '../utils';
import {PartnerService} from '../services/partner.service';

export class PartnerController {
  constructor(
    @inject(PartnerServiceBindings.PARTNER_SERVICE)
    public partnerService: PartnerService,
  ) {}

  @post('/partner', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Partner model instance',
        content: {
          'application/json': {schema: getModelSchemaRef(Partner)},
        },
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Partner, {
            title: 'NewPartner',
            exclude: ['id'],
          }),
        },
      },
    })
    partner: Omit<Partner, 'id'>,
  ): Promise<Partner> {
    return this.partnerService.create(partner);
  }

  @get('/partner', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of Partner model instances',
        content: {
          'application/json': {
            schema: Utils.paginatedSchema(Partner, true),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findAll(
    @param.query.object('filter', getFilterSchemaFor(Partner))
    filter?: Filter<Partner>,
    @param.query.number('page') page?: number,
    @param.query.string('search') search?: string,
  ): Promise<PaginatedResponse<Partner>> {
    return this.partnerService.findAll(filter, page, search);
  }



  @get('/partner/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Partner model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Partner, {includeRelations: true}),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(Partner))
    filter?: Filter<Partner>,
  ) {
    return this.partnerService.findById(id, filter);
  }

  @patch('/partner/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Consult PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Partner, {
            partial: true,
            exclude: ['id'],
          }),
        },
      },
    })
    partner: Partner,
  ): Promise<void> {
    return await this.partnerService.updateById(id, partner);
  }

  @del('/partner/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Partner DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    this.partnerService.deleteById(id);
  }
}
