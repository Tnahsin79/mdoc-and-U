import {authenticate} from '@loopback/authentication';
import {
  AnyObject,
  Count,
  CountSchema,
  Filter,
  repository,
  Where,
} from '@loopback/repository';
import {
  post,
  param,
  get,
  getModelSchemaRef,
  patch,
  put,
  del,
  requestBody,
  getFilterSchemaFor,
} from '@loopback/rest';
import {Exercises} from '../models';
import {ExercisesRepository} from '../repositories';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';
import * as _ from 'lodash';
import moment from 'moment';
import {inject} from '@loopback/context';
import {ExercisesServiceBindings} from '../keys';
import {ExercisesService} from '../services/exercises.service';
export class ExercisesController {
  constructor(
    @repository(ExercisesRepository)
    public exercisesRepository: ExercisesRepository,
    @inject(ExercisesServiceBindings.EXERCISES_SERVICE)
    public exercisesService: ExercisesService,
  ) {}

  @post('/exercises', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'Exercises model instance',
        content: {'application/json': {schema: getModelSchemaRef(Exercises)}},
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Exercises, {
            title: 'NewExercises',
            exclude: ['id'],
          }),
        },
      },
    })
    exercises: Omit<Exercises, 'id'>,
  ): Promise<Exercises> {
    return this.exercisesRepository.create(exercises);
  }

  // @get('/exercises/count')
  // @response(200, {
  //   description: 'Exercises model count',
  //   content: { 'application/json': { schema: CountSchema } },
  // })
  // async count(
  //   @param.where(Exercises) where?: Where<Exercises>,
  // ): Promise<Count> {
  //   return this.exercisesRepository.count(where);
  // }

  @get('/exercises', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'Array of Exercises model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(Exercises, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async find(
    @param.query.object('filter', getFilterSchemaFor(Exercises))
    filter?: Filter<Exercises>,
  ): Promise<Exercises[]> {
    return this.exercisesRepository.find(filter);
  }

  // @patch('/exercises')
  // @response(200, {
  //   description: 'Exercises PATCH success count',
  //   content: { 'application/json': { schema: CountSchema } },
  // })
  // async updateAll(
  //   @requestBody({
  //     content: {
  //       'application/json': {
  //         schema: getModelSchemaRef(Exercises, { partial: true }),
  //       },
  //     },
  //   })
  //   exercises: Exercises,
  //   @param.where(Exercises) where?: Where<Exercises>,
  // ): Promise<Count> {
  //   return this.exercisesRepository.updateAll(exercises, where);
  // }

  // @get('/exercises/{id}')
  // @response(200, {
  //   description: 'Exercises model instance',
  //   content: {
  //     'application/json': {
  //       schema: getModelSchemaRef(Exercises, { includeRelations: true }),
  //     },
  //   },
  // })
  // async findById(
  //   @param.path.string('id') id: string,
  //   @param.filter(Exercises, { exclude: 'where' }) filter?: FilterExcludingWhere<Exercises>
  // ): Promise<Exercises> {
  //   return this.exercisesRepository.findById(id, filter);
  // }

  @patch('/exercises/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      204: {
        description: 'Exercises PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Exercises, {partial: true}),
        },
      },
    })
    exercises: Exercises,
  ): Promise<void> {
    await this.exercisesRepository.updateById(id, exercises);
  }

  // @put('/exercises/{id}')
  // @response(204, {
  //   description: 'Exercises PUT success',
  // })
  // async replaceById(
  //   @param.path.string('id') id: string,
  //   @requestBody() exercises: Exercises,
  // ): Promise<void> {
  //   await this.exercisesRepository.replaceById(id, exercises);
  // }

  @del('/exercises/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      204: {
        description: 'Exercises DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.exercisesRepository.deleteById(id);
  }

  @get('/exercises/createdExercises', {
    responses: {
      200: {
        description: 'Exercises PUT success',
      },
    },
  })
  async createdExercises(): Promise<any> {
    return false;
    const data = [
      {
        title: 'Upper Body Exercise - Free Weight',
        description: 'Bent Over Row',
        url:
          'https://storage.googleapis.com/pre-recorded-exercises-videos/Bent%20Over%20Row.mp4',
        thumbnail:
          'https://storage.googleapis.com/pre-recorded-exercises-videos/Bent%20Over%20Row.png',
      },
      {
        title: 'Upper Body Exercise - Free Weight',
        description: 'Biceps Curls + Shoulder Press',
        url:
          'https://storage.googleapis.com/pre-recorded-exercises-videos/Biceps%20Curls%20%2B%20Shoulder%20Press.mp4',
        thumbnail:
          'https://storage.googleapis.com/pre-recorded-exercises-videos/Biceps%20Curls%20%2B%20Shoulder%20Press.png',
      },
      {
        title: 'Upper Body Exercise - Free Weight',
        description: 'Overhead Tricep Extension',
        url:
          'https://storage.googleapis.com/pre-recorded-exercises-videos/Overhead%20Tricep%20Extension.mp4',
        thumbnail:
          'https://storage.googleapis.com/pre-recorded-exercises-videos/Overhead%20Tricep%20Extension.png',
      },
      {
        title: 'Upper Body Exercise - Free Weight',
        description: 'Alternate Jabs',
        url:
          'https://storage.googleapis.com/pre-recorded-exercises-videos/Alternate%20Jabs.mp4',
        thumbnail:
          'https://storage.googleapis.com/pre-recorded-exercises-videos/Alternate%20Jabs.png',
      },
      {
        title: 'Upper Body Exercise - Free Weight',
        description: 'Seated Bicep Curls',
        url:
          'https://storage.googleapis.com/pre-recorded-exercises-videos/Seated%20Bicep%20Curls.mp4',
        thumbnail:
          'https://storage.googleapis.com/pre-recorded-exercises-videos/Seated%20Bicep%20Curls.png',
      },
      {
        title: 'Upper Body Exercise - Free Weight',
        description: 'Push-ups (Basics)',
        url:
          'https://storage.googleapis.com/pre-recorded-exercises-videos/Push-ups%20(Basics).mp4',
        thumbnail:
          'https://storage.googleapis.com/pre-recorded-exercises-videos/Push-ups%20(Basics).png',
      },
      {
        title: 'Upper Body Exercise - Free Weight',
        description: 'Shoulder Tap',
        url:
          'https://storage.googleapis.com/pre-recorded-exercises-videos/Shoulder%20Tap.mp4',
        thumbnail:
          'https://storage.googleapis.com/pre-recorded-exercises-videos/Shoulder%20Tap.png',
      },
      {
        title: 'Full Body / Aerobics Exercise',
        description: 'Full Body / Aerobics Exercise',
        url:
          'https://storage.googleapis.com/pre-recorded-exercises-videos/Full%20Body_Aerobics.mp4',
        thumbnail:
          'https://storage.googleapis.com/pre-recorded-exercises-videos/Full%20Body%20%3A%20Aerobics%20Exercise.png',
      },
      {
        title: 'Pre-natal Exercise',
        description: 'Lateral Leg Raise',
        url:
          'https://storage.googleapis.com/pre-recorded-exercises-videos/Lateral%20Leg%20Raise.mp4',
        thumbnail:
          'https://storage.googleapis.com/pre-recorded-exercises-videos/Lateral%20Leg%20Raise.png',
      },
      {
        title: 'Pre-natal Exercise',
        description: 'Squat',
        url:
          'https://storage.googleapis.com/pre-recorded-exercises-videos/Squat.mp4',
        thumbnail:
          'https://storage.googleapis.com/pre-recorded-exercises-videos/Squat.png',
      },
      {
        title: 'Pre-natal Exercise',
        description: 'Chair Squat',
        url:
          'https://storage.googleapis.com/pre-recorded-exercises-videos/Chair%20Squat.mp4',
        thumbnail:
          'https://storage.googleapis.com/pre-recorded-exercises-videos/Chair%20Squat.png',
      },
      {
        title: 'Pre-natal Exercise',
        description: 'Basic rhythmic Aerobics Dance Exercise',
        url:
          'https://storage.googleapis.com/pre-recorded-exercises-videos/Basic%20rhythmic%20Aerobics%20Dance%20Exercise.mp4',
        thumbnail:
          'https://storage.googleapis.com/pre-recorded-exercises-videos/Basic%20rhythmic%20Aerobics%20Dance%20Exercise.png',
      },
      {
        title: 'Leg and Glute Exercise',
        description: 'Alternate Lungs',
        url:
          'https://storage.googleapis.com/pre-recorded-exercises-videos/Alternate%20Lungs.mp4',
        thumbnail:
          'https://storage.googleapis.com/pre-recorded-exercises-videos/Alternate%20Lungs.png',
      },
      {
        title: 'Leg and Glute Exercise',
        description: 'Barbell Seated Squat',
        url:
          'https://storage.googleapis.com/pre-recorded-exercises-videos/Barbell%20Seated%20Squat.mp4',
        thumbnail:
          'https://storage.googleapis.com/pre-recorded-exercises-videos/Barbell%20Seated%20Squat.png',
      },
      {
        title: 'Leg and Glute Exercise',
        description: 'Donkey Kicks',
        url:
          'https://storage.googleapis.com/pre-recorded-exercises-videos/Donkey%20Kicks.mp4',
        thumbnail:
          'https://storage.googleapis.com/pre-recorded-exercises-videos/Donkey%20Kicks.png',
      },
      {
        title: 'Kegel Exercise',
        description: 'Kegel Exercise',
        url:
          'https://storage.googleapis.com/pre-recorded-exercises-videos/Kegel%20Exercise.mp4',
        thumbnail:
          'https://storage.googleapis.com/pre-recorded-exercises-videos/Kegel%20Exercise.png',
      },
      {
        title: 'Chair Exercise',
        description: 'Seated Exercises',
        url:
          'https://storage.googleapis.com/pre-recorded-exercises-videos/Seated%20Exercises.mp4',
        thumbnail:
          'https://storage.googleapis.com/pre-recorded-exercises-videos/Seated%20Exercises.png',
      },
    ];
    let _this = this;
    _.forEach(data, async function(val) {
      let obj: AnyObject = {
        title: val.title,
        description: val.description,
        url: val.url,
        thumbnail: val.thumbnail,
      };
      await _this.exercisesRepository.create(obj);
    });
    // await this.webinarRepository.replaceById(id, webinar);
  }

  @get('/exercises/getExercisesList', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'Exercises PUT success',
      },
    },
  })
  @authenticate('jwt')
  async getExercisesList(): Promise<any> {
    let responseData: AnyObject = {};
    let exercises: any = await this.exercisesRepository.find();
    if (exercises && exercises.length) {
      let upExercise = _.filter(exercises, function(val) {
        return (
          (_.gte(moment(val.created).unix(), moment().unix()) &&
            val.created !== undefined) ||
          val.day !== ''
        );
      });
      let pastExercise = _.filter(exercises, function(val) {
        return (
          _.lte(moment(val.created).unix(), moment().unix()) && val.day === ''
        );
      });
      responseData.upcomingExercise = upExercise;
      responseData.pastExercise = pastExercise;

      return responseData;
    } else {
      return [];
    }
  }
}
