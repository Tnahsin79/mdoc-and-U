import {
  get,
  param,
  post,
  requestBody,
  getModelSchemaRef,
  getFilterSchemaFor,
  patch,
  del,
} from '@loopback/rest';
import {inject} from '@loopback/core';
import {CommentReply} from '../models';
import {Filter} from '@loopback/repository';
import {CommentReplyService} from '../services';
import {PaginatedResponse} from '../type-schema';
import {CommentReplyServiceBindings} from '../keys';
import {authenticate} from '@loopback/authentication';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';

export class CommentReplyController {
  constructor(
    @inject(CommentReplyServiceBindings.COMMENT_REPLY_SERVICE)
    public commentReplyService: CommentReplyService,
  ) {}

  @post('/comment-reply', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'CommentReply model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(CommentReply, {includeRelations: true}),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(CommentReply, {
            title: 'NewCommentReply',
            exclude: ['id'],
          }),
        },
      },
    })
    commentReply: Omit<CommentReply, 'id'>,
  ) {
    return this.commentReplyService.create(commentReply);
  }

  @get('/replies', {
    responses: {
      '200': {
        description: 'Array of CommentReply model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(CommentReply, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  async findAll(
    @param.query.object('filter', getFilterSchemaFor(CommentReply))
    filter?: Filter<CommentReply>,
    @param.query.number('page') page?: number,
  ): Promise<PaginatedResponse<CommentReply>> {
    return this.commentReplyService.findAll(filter, page);
  }

  @get('/comment-reply/{id}', {
    responses: {
      '200': {
        description: 'Array of CommentReply model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(CommentReply, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  async findById(@param.path.string('id') id: string) {
    return this.commentReplyService.findById(id);
  }

  @patch('/comment-reply', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'CommentReply PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async update(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(CommentReply, {partial: true}),
        },
      },
    })
    commentReply: CommentReply,
  ) {
    return this.commentReplyService.updateById(id, commentReply);
  }

  @del('/comment-reply/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'CommentReply DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    this.commentReplyService.deleteById(id);
  }
}
