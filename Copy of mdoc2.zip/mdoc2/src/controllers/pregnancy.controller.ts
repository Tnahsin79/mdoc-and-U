import {
  get,
  put,
  del,
  post,
  param,
  patch,
  requestBody,
  getModelSchemaRef,
  getWhereSchemaFor,
  getFilterSchemaFor,
} from '@loopback/rest';
import {
  Where,
  Count,
  Filter,
  AnyObject,
  repository,
  CountSchema,
} from '@loopback/repository';
import {Pregnancy} from '../models';
import {inject} from '@loopback/core';
import {authenticate} from '@loopback/authentication';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';
import {PregnancyRepository, ChildrenRepository} from '../repositories';
import {UserProfile, securityId, SecurityBindings} from '@loopback/security';
export class PregnancyController {
  constructor(
    @repository(PregnancyRepository)
    public pregnancyRepository: PregnancyRepository,
    @repository(ChildrenRepository)
    public childrenRepository: ChildrenRepository,
  ) {}

  @post('/pregnancies', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Pregnancy model instance',
        content: {'application/json': {schema: getModelSchemaRef(Pregnancy)}},
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Pregnancy, {
            title: 'NewPregnancy',
            exclude: ['id'],
          }),
        },
      },
    })
    pregnancy: Omit<Pregnancy, 'id'>,
  ): Promise<Pregnancy> {
    pregnancy.isPregnancyComplete = true;
    return this.pregnancyRepository.create(pregnancy);
  }

  @get('/pregnancies/count', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Pregnancy model count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  @authenticate('jwt')
  async count(
    @param.query.object('where', getWhereSchemaFor(Pregnancy))
    where?: Where<Pregnancy>,
  ): Promise<Count> {
    return this.pregnancyRepository.count(where);
  }

  @get('/pregnancies', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of Pregnancy model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(Pregnancy, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async find(
    @param.query.object('filter', getFilterSchemaFor(Pregnancy))
    filter?: Filter<Pregnancy>,
  ): Promise<Pregnancy[]> {
    return this.pregnancyRepository.find({
      ...filter,
      order: ['created DESC'],
    });
  }

  @patch('/pregnancies', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Pregnancy PATCH success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  @authenticate('jwt')
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Pregnancy, {partial: true}),
        },
      },
    })
    pregnancy: Pregnancy,
    @param.query.object('where', getWhereSchemaFor(Pregnancy))
    where?: Where<Pregnancy>,
  ): Promise<Count> {
    return this.pregnancyRepository.updateAll(pregnancy, where);
  }

  @get('/pregnancies/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Pregnancy model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Pregnancy, {includeRelations: true}),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(Pregnancy))
    filter?: Filter<Pregnancy>,
  ): Promise<Pregnancy> {
    return this.pregnancyRepository.findById(id, filter);
  }

  @patch('/pregnancies/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Pregnancy PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Pregnancy, {partial: true}),
        },
      },
    })
    pregnancy: Pregnancy,
  ): Promise<void> {
    await this.pregnancyRepository.updateById(id, pregnancy);
  }

  @put('/pregnancies/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Pregnancy PUT success',
      },
    },
  })
  @authenticate('jwt')
  async replaceById(
    @param.path.string('id') id: string,
    @requestBody() pregnancy: Pregnancy,
  ): Promise<void> {
    await this.pregnancyRepository.replaceById(id, pregnancy);
  }

  @del('/pregnancies/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Pregnancy DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.pregnancyRepository.deleteById(id);
  }

  @get('/pregnancies/getCurrentPregnancyDetail/', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Pregnancy  success',
      },
    },
  })
  @authenticate('jwt')
  async getCurrentPregnancyDetail(
    @inject(SecurityBindings.USER) currentUser: UserProfile,
    @param.query.string('type') type: string,
  ): Promise<any> {
    const pregancyData = await this.pregnancyRepository.findOne({
      where: {
        type: type,
        userId: currentUser[securityId],
      },
      order: ['created DESC'],
    });
    if (pregancyData && pregancyData.id) {
      // let pregnacyObj = Object.assign({}, pregancyData)

      return pregancyData;
    } else {
      return {};
    }
  }

  @get('/pregnancies/dashBoardPregnancyDetail/', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Pregnancy  success',
      },
    },
  })
  @authenticate('jwt')
  async dashBoardPregnancyDetail(
    @inject(SecurityBindings.USER) currentUser: UserProfile,
  ): Promise<any> {
    let responseData: Array<AnyObject> = [];

    const pregancyData = await this.pregnancyRepository.find({
      where: {
        userId: currentUser[securityId],
      },
      order: ['created DESC'],
    });

    if (pregancyData && pregancyData.length) {
      responseData.push(pregancyData);

      const childres = await this.childrenRepository.find({
        where: {
          userId: currentUser[securityId],
        },
        order: ['created DESC'],
      });

      if (childres && childres.length) {
        responseData.concat(childres);
        return responseData;
      } else {
        return responseData;
      }
    } else {
      return {};
    }
  }
}
