import {authenticate} from '@loopback/authentication';
import {
  AnyObject,
  Count,
  CountSchema,
  Filter,
  repository,
  Where,
} from '@loopback/repository';
import {
  post,
  param,
  get,
  getModelSchemaRef,
  patch,
  put,
  del,
  requestBody,
} from '@loopback/rest';
import {MyAssessmentsInformation} from '../models';
import {
  MyAssessmentsInformationRepository,
  MyAssessmentsRepository,
} from '../repositories';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';
import {inject} from '@loopback/core';
import {UserProfile, securityId, SecurityBindings} from '@loopback/security';
import * as _ from 'lodash';
export class MyAssessmentsInformationController {
  constructor(
    @repository(MyAssessmentsInformationRepository)
    public myAssessmentsInformationRepository: MyAssessmentsInformationRepository,
    @repository(MyAssessmentsRepository)
    public myAssessmentsRepository: MyAssessmentsRepository,
  ) {}

  @post('/my-assessments-informations', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'MyAssessmentsInformation model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(MyAssessmentsInformation),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(MyAssessmentsInformation, {
            title: 'NewMyAssessmentsInformation',
            exclude: ['id'],
          }),
        },
      },
    })
    myAssessmentsInformation: Omit<MyAssessmentsInformation, 'id'>,
  ): Promise<MyAssessmentsInformation> {
    return this.myAssessmentsInformationRepository.create(
      myAssessmentsInformation,
    );
  }

  // @get('/my-assessments-informations/count')
  // @response(200, {
  //   description: 'MyAssessmentsInformation model count',
  //   content: { 'application/json': { schema: CountSchema } },
  // })
  // async count(
  //   @param.where(MyAssessmentsInformation) where?: Where<MyAssessmentsInformation>,
  // ): Promise<Count> {
  //   return this.myAssessmentsInformationRepository.count(where);
  // }

  // @get('/my-assessments-informations')
  // @response(200, {
  //   description: 'Array of MyAssessmentsInformation model instances',
  //   content: {
  //     'application/json': {
  //       schema: {
  //         type: 'array',
  //         items: getModelSchemaRef(MyAssessmentsInformation, { includeRelations: true }),
  //       },
  //     },
  //   },
  // })
  // async find(
  //   @param.filter(MyAssessmentsInformation) filter?: Filter<MyAssessmentsInformation>,
  // ): Promise<MyAssessmentsInformation[]> {
  //   return this.myAssessmentsInformationRepository.find(filter);
  // }

  // @patch('/my-assessments-informations')
  // @response(200, {
  //   description: 'MyAssessmentsInformation PATCH success count',
  //   content: { 'application/json': { schema: CountSchema } },
  // })
  // async updateAll(
  //   @requestBody({
  //     content: {
  //       'application/json': {
  //         schema: getModelSchemaRef(MyAssessmentsInformation, { partial: true }),
  //       },
  //     },
  //   })
  //   myAssessmentsInformation: MyAssessmentsInformation,
  //   @param.where(MyAssessmentsInformation) where?: Where<MyAssessmentsInformation>,
  // ): Promise<Count> {
  //   return this.myAssessmentsInformationRepository.updateAll(myAssessmentsInformation, where);
  // }

  // @get('/my-assessments-informations/{id}')
  // @response(200, {
  //   description: 'MyAssessmentsInformation model instance',
  //   content: {
  //     'application/json': {
  //       schema: getModelSchemaRef(MyAssessmentsInformation, { includeRelations: true }),
  //     },
  //   },
  // })
  // async findById(
  //   @param.path.string('id') id: string,
  //   @param.filter(MyAssessmentsInformation, { exclude: 'where' }) filter?: FilterExcludingWhere<MyAssessmentsInformation>
  // ): Promise<MyAssessmentsInformation> {
  //   return this.myAssessmentsInformationRepository.findById(id, filter);
  // }

  @patch('/my-assessments-informations/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      204: {
        description: 'MyAssessmentsInformation PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(MyAssessmentsInformation, {partial: true}),
        },
      },
    })
    myAssessmentsInformation: MyAssessmentsInformation,
  ): Promise<void> {
    await this.myAssessmentsInformationRepository.updateById(
      id,
      myAssessmentsInformation,
    );
  }

  // @put('/my-assessments-informations/{id}')
  // @response(204, {
  //   description: 'MyAssessmentsInformation PUT success',
  // })
  // async replaceById(
  //   @param.path.string('id') id: string,
  //   @requestBody() myAssessmentsInformation: MyAssessmentsInformation,
  // ): Promise<void> {
  //   await this.myAssessmentsInformationRepository.replaceById(id, myAssessmentsInformation);
  // }

  // @del('/my-assessments-informations/{id}',
  // @response(204, {
  //   description: 'MyAssessmentsInformation DELETE success',
  // })
  // async deleteById(@param.path.string('id') id: string): Promise<void> {
  //   await this.myAssessmentsInformationRepository.deleteById(id);
  // }

  @get('/getMyAssessmentsInformation', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'MyAssessmentsInformation  success',
      },
    },
  })
  @authenticate('jwt')
  async getBasicHealthInfo(
    @inject(SecurityBindings.USER) currentUser: UserProfile,
  ): Promise<any> {
    let responseData: Array<AnyObject> = [];
    const myAssessments = await this.myAssessmentsInformationRepository.find({
      where: {
        userId: currentUser[securityId],
      },
      order: ['created DESC'],
    });

    const questions = await this.myAssessmentsRepository.find();
    if (myAssessments.length > 0) {
      _.forEach(myAssessments, function(myAssessment: any) {
        const obj = Object.assign({}, {...myAssessment});
        const currentQuestionIds = myAssessment.questionIds;
        let newQuestions: any = [];
        currentQuestionIds.forEach(questionId => {
          const result = questions.find(
            question => String(question?.id) === String(questionId),
          );
          if (result) {
            newQuestions = [...newQuestions, result.question];
          }
        });
        obj.questionIds = newQuestions;
        responseData.push(obj);
      });
    }

    const myAssessmentsGrp =
      responseData?.length && _.groupBy(responseData, w => w.type);

    return {
      data: responseData.length ? myAssessmentsGrp : [],
      status: 'Success',
    };
  }
}
