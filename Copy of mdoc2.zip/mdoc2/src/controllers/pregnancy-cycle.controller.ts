import {
  post,
  param,
  get,
  getModelSchemaRef,
  patch,
  del,
  requestBody,
  getFilterSchemaFor,
} from '@loopback/rest';
import {inject} from '@loopback/core';
import {PregnancyCycle} from '../models';
import {Filter} from '@loopback/repository';
import {PaginatedResponse} from '../type-schema';
import {PregnancyCycleService} from '../services';
import {PregnancyCycleServiceBindings} from '../keys';
import {authenticate} from '@loopback/authentication';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';

export class PregnancyCycleController {
  constructor(
    @inject(PregnancyCycleServiceBindings.PREGNANCY_CYCLE)
    public pregnancyCycleService: PregnancyCycleService,
  ) {}
  @post('/pregnancy-cycle', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'PregnancyCycle model instance',
        content: {
          'application/json': {schema: getModelSchemaRef(PregnancyCycle)},
        },
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(PregnancyCycle, {
            title: 'NewPregnancyCycle',
            exclude: ['id'],
          }),
        },
      },
    })
    pregnancyCycle: Omit<PregnancyCycle, 'id'>,
  ): Promise<PregnancyCycle> {
    return this.pregnancyCycleService.create(pregnancyCycle);
  }

  @get('/pregnancy-cycle', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of PregnancyCycle model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(PregnancyCycle, {
                includeRelations: true,
              }),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findAll(
    @param.query.object('filter', getFilterSchemaFor(PregnancyCycle))
    filter?: Filter<PregnancyCycle>,
    @param.query.number('page') page?: number,
  ): Promise<PaginatedResponse<PregnancyCycle>> {
    return this.pregnancyCycleService.findAll(filter, page);
  }

  @get('/pregnancy-cycle/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'PregnancyCycle model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(PregnancyCycle, {includeRelations: true}),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(PregnancyCycle))
    filter?: Filter<PregnancyCycle>,
  ) {
    return this.pregnancyCycleService.findById(id, filter);
  }

  @patch('/pregnancy-cycle/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'PregnancyCycle PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(PregnancyCycle, {partial: true}),
        },
      },
    })
    pregnancyCycle: PregnancyCycle,
  ): Promise<void> {
    return await this.pregnancyCycleService.updateById(id, pregnancyCycle);
  }

  @del('/pregnancy-cycle/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'PregnancyCycle DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    return this.pregnancyCycleService.deleteById(id);
  }
}
