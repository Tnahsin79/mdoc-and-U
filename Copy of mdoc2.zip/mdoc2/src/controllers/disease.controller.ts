import {
  Count,
  CountSchema,
  Filter,
  repository,
  Where,
  AnyObject,
} from '@loopback/repository';
import {
  post,
  param,
  get,
  getFilterSchemaFor,
  getModelSchemaRef,
  getWhereSchemaFor,
  patch,
  put,
  del,
  requestBody,
  HttpErrors,
} from '@loopback/rest';
import {Disease, DiseaseWithRelations, UserDisease, Users} from '../models';
import {DiseaseRepository, UsersRepository} from '../repositories';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';
import {authenticate} from '@loopback/authentication';
import _ from 'lodash';
import csv from 'csvtojson';
import {inject} from '@loopback/core';
import {DiseaseServiceBindings, MigrationServiceBindings} from '../keys';
import {MigrationService} from '../services/migration.service';
import {DiseaseService} from '../services/disease.service';

export class DiseaseController {
  constructor(
    @repository(DiseaseRepository) public diseaseRepository: DiseaseRepository,
    @repository(UsersRepository) public usersRepository: UsersRepository,
    @inject(MigrationServiceBindings.MIGRATION_SERVICE)
    public migrationService: MigrationService,
    @inject(DiseaseServiceBindings.DISEASE_SERVICE)
    public diseaseService: DiseaseService,
  ) {}

  @post('/diseases', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Disease model instance',
        content: {'application/json': {schema: getModelSchemaRef(Disease)}},
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Disease, {
            title: 'NewDisease',
            exclude: ['id'],
          }),
        },
      },
    })
    disease: Omit<Disease, 'id'>,
  ): Promise<Disease> {
    return this.diseaseRepository.create(disease);
  }

  @post('/diseases/addUser', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'UserDisease model instance',
        content: {'application/json': {schema: getModelSchemaRef(UserDisease)}},
      },
    },
  })
  @authenticate('jwt')
  async addUserToDisease(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(UserDisease, {
            title: 'NewUserDisease',
            exclude: ['id'],
          }),
        },
      },
    })
    disease: Omit<UserDisease, 'id'>,
  ): Promise<UserDisease> {
    return this.diseaseService.addUserToDisease(disease);
  }

  @get('/diseases/count', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Disease model count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  @authenticate('jwt')
  async count(
    @param.query.object('where', getWhereSchemaFor(Disease))
    where?: Where<Disease>,
  ): Promise<Count> {
    return this.diseaseRepository.count(where);
  }

  @get('/diseases', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of Disease model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(Disease, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async find(
    @param.query.object('filter', getFilterSchemaFor(Disease))
    filter?: AnyObject,
    @param.query.number('page') page?: number,
  ): Promise<any> {
    return this.diseaseService.find(filter, page);
  }

  @get('/diseases/users/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of Users model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(Users, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async getDiseaseUsers(
    @param.query.object('filter', getFilterSchemaFor(UserDisease))
    filter?: AnyObject,
    @param.query.number('page') page?: number,
    @param.path.string('id') diseaseId?: string,
  ): Promise<any> {
    return this.diseaseService.getUsersByDisease(diseaseId, filter, page);
  }

  @patch('/diseases', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Disease PATCH success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  @authenticate('jwt')
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Disease, {partial: true}),
        },
      },
    })
    disease: Disease,
    @param.query.object('where', getWhereSchemaFor(Disease))
    where?: Where<Disease>,
  ): Promise<Count> {
    return this.diseaseRepository.updateAll(disease, where);
  }

  @get('/diseases/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Disease model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Disease, {includeRelations: true}),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(Disease))
    filter?: Filter<Disease>,
  ): Promise<DiseaseWithRelations> {
    return this.diseaseService.findById(id);
  }

  @patch('/diseases/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Disease PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Disease, {partial: true}),
        },
      },
    })
    disease: Disease,
  ): Promise<void> {
    await this.diseaseRepository.updateById(id, disease);
  }

  @put('/diseases/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Disease PUT success',
      },
    },
  })
  @authenticate('jwt')
  async replaceById(
    @param.path.string('id') id: string,
    @requestBody() disease: Disease,
  ): Promise<void> {
    await this.diseaseRepository.replaceById(id, disease);
  }

  @del('/diseases/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Disease DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.diseaseService.deleteById(id);
  }

  @post('/diseases/getDiseasesList', {
    //security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Coach model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Disease, {includeRelations: true}),
          },
        },
      },
    },
  })
  //@authenticate('jwt')
  async getDiseasesList(@requestBody() data: any): Promise<any> {
    let query: AnyObject = {};
    let anyQuery: AnyObject = {};
    let responseData: Array<AnyObject> = [];

    if (data && data.userName) {
      query = {
        name: new RegExp('.*' + data.userName + '.*', 'i'),
      };
      const userData = await this.usersRepository.find({
        where: query,
      });
      // let diseaseIds = _.map(userData, v => v.id)
      // anyQuery = {
      //   id: { inq: diseaseIds }
      // }
    }

    if (data && data.name) {
      anyQuery = {
        name: new RegExp('.*' + data.name + '.*', 'i'),
      };
    }
    if (data && data.symptomes) {
      anyQuery = {
        symptomes: new RegExp('.*' + data.symptomes + '.*', 'i'),
      };
    }
    const diseaseList = await this.diseaseRepository.find({
      where: anyQuery,
    });
    if (diseaseList && diseaseList.length) {
      let diseaseId = _.map(diseaseList, v => '');
      return Promise.all([
        this.usersRepository.find({
          where: {
            id: {inq: diseaseId},
          },
          fields: {name: true, id: true},
        }),
      ])
        .then(res => {
          let userList =
            res && res[0] && res[0].length && _.groupBy(res[0], v => v.id);
          _.forEach(diseaseList, function(val: any) {
            let obj: AnyObject = Object.assign({}, val);
            obj.usersCount =
              (userList && userList[val.id!] && userList[val.id!].length) || 0;
            responseData.push(obj);
          });
          return responseData;
        })
        .catch(err => {
          throw new HttpErrors.NotFound('Something went wrong');
        });
    }
  }

  @post('/diseasesMigration', {
    responses: {
      '200': {
        description: 'Disease model instance',
      },
    },
  })
  async diseasesMigration(): Promise<any> {
    const filePath = './public/medical_history_list_disease.csv';
    let data = await csv().fromFile(filePath);
    if (data && data.length) {
      for (const value of data) {
        await this.migrationService.diseasesMigration(value);
      }
    }
  }
}
