import {
  get,
  post,
  patch,
  param,
  requestBody,
  getModelSchemaRef,
  getFilterSchemaFor,
} from '@loopback/rest';
import Utils from '../utils';
import {Outlier} from '../models';
import {inject} from '@loopback/context';
import {OutlierService} from '../services';
import {Filter} from '@loopback/repository';
import {OutlierServiceBindings} from '../keys';
import {PaginatedResponse} from '../type-schema';
import {authenticate} from '@loopback/authentication';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';

export class OutlierController {
  constructor(
    @inject(OutlierServiceBindings.OUTLIER_SERVICE)
    public outlierService: OutlierService,
  ) {}

  @post('/outlier', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Outlier model instance',
        content: {
          'application/json': {schema: getModelSchemaRef(Outlier)},
        },
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Outlier, {
            title: 'NewOutlier',
            exclude: [
              'id',
              'status',
              'reviewerId',
              'finalNotes',
              'userFullName',
              'resolutionDate',
              'reviewStartDate',
            ],
          }),
        },
      },
    })
    outlier: Omit<Outlier, 'id'>,
  ): Promise<Outlier> {
    return this.outlierService.create(outlier);
  }

  @get('/outliers', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of Outlier model instances',
        content: {
          'application/json': {
            schema: Utils.paginatedSchema(Outlier, true),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findAll(
    @param.query.object('filter', getFilterSchemaFor(Outlier))
    filter?: Filter<Outlier>,
    @param.query.number('page') page?: number,
    @param.query.string('search') search?: string,
  ): Promise<PaginatedResponse<Outlier>> {
    return this.outlierService.findAll(page, search, filter);
  }

  @get('/outlier/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Outlier model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Outlier, {includeRelations: true}),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(Outlier))
    filter?: Filter<Outlier>,
  ) {
    return this.outlierService.findById(id, filter);
  }

  @patch('/outlier/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Outlier PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Outlier, {
            partial: true,
            exclude: ['created_at', 'id', 'userId', 'userFullName'],
          }),
        },
      },
    })
    outlier: Outlier,
  ): Promise<void> {
    return await this.outlierService.updateById(id, outlier);
  }

  @get('/outlier-statistics', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Outlier Statistics',
        content: {
          'application/json': {
            schema: {
              type: 'object',
              properties: {
                in_review: {type: 'number'},
                resolved: {type: 'number'},
                pending: {type: 'number'},
              },
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async outlierStatistics(
    @param.query.string('reviewerId') reviewerId?: string,
  ) {
    return await this.outlierService.outlierStatistics(reviewerId);
  }
}
