import { Count, CountSchema, Filter, repository, Where, AnyObject, } from '@loopback/repository';
import { post, param, get, getFilterSchemaFor, getModelSchemaRef, getWhereSchemaFor, patch, put, del, requestBody, HttpErrors, } from '@loopback/rest';
import { Resources } from '../models';
import { ResourcesRepository, UsersRepository, CategoryRepository } from '../repositories';
import * as _ from 'lodash'
export class ResourcesController {
  constructor(
    @repository(ResourcesRepository) public resourcesRepository: ResourcesRepository,
    @repository(UsersRepository) public usersRepository: UsersRepository,
    @repository(CategoryRepository) public categoryRepository: CategoryRepository
  ) { }

  @post('/resources', {
    responses: {
      '200': {
        description: 'Resources model instance',
        content: { 'application/json': { schema: getModelSchemaRef(Resources) } },
      },
    },
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Resources, {
            title: 'NewResources',
            exclude: ['id'],
          }),
        },
      },
    })
    resources: Omit<Resources, 'id'>,
  ): Promise<Resources> {
    return this.resourcesRepository.create(resources);
  }

  @get('/resources/count', {
    responses: {
      '200': {
        description: 'Resources model count',
        content: { 'application/json': { schema: CountSchema } },
      },
    },
  })
  async count(
    @param.query.object('where', getWhereSchemaFor(Resources)) where?: Where<Resources>,
  ): Promise<Count> {
    return this.resourcesRepository.count(where);
  }

  @get('/resources', {
    responses: {
      '200': {
        description: 'Array of Resources model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(Resources, { includeRelations: true }),
            },
          },
        },
      },
    },
  })
  async find(
    @param.query.object('filter', getFilterSchemaFor(Resources)) filter?: Filter<Resources>,
  ): Promise<Resources[]> {
    return this.resourcesRepository.find(filter);
  }

  @patch('/resources', {
    responses: {
      '200': {
        description: 'Resources PATCH success count',
        content: { 'application/json': { schema: CountSchema } },
      },
    },
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Resources, { partial: true }),
        },
      },
    })
    resources: Resources,
    @param.query.object('where', getWhereSchemaFor(Resources)) where?: Where<Resources>,
  ): Promise<Count> {
    return this.resourcesRepository.updateAll(resources, where);
  }

  @get('/resources/{id}', {
    responses: {
      '200': {
        description: 'Resources model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Resources, { includeRelations: true }),
          },
        },
      },
    },
  })
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(Resources)) filter?: Filter<Resources>
  ): Promise<Resources> {
    return this.resourcesRepository.findById(id, filter);
  }

  @patch('/resources/{id}', {
    responses: {
      '204': {
        description: 'Resources PATCH success',
      },
    },
  })
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Resources, { partial: true }),
        },
      },
    })
    resources: Resources,
  ): Promise<void> {
    await this.resourcesRepository.updateById(id, resources);
  }

  @put('/resources/{id}', {
    responses: {
      '204': {
        description: 'Resources PUT success',
      },
    },
  })
  async replaceById(
    @param.path.string('id') id: string,
    @requestBody() resources: Resources,
  ): Promise<void> {
    await this.resourcesRepository.replaceById(id, resources);
  }

  @del('/resources/{id}', {
    responses: {
      '204': {
        description: 'Resources DELETE success',
      },
    },
  })
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.resourcesRepository.deleteById(id);
  }
  @post('/resources/getResourceList', {
    responses: {
      '200': {
        description: 'Resources  success',
      },
    },
  })
  async getResourceList(
    @requestBody() data: any,
  ): Promise<any> {
    let query: AnyObject = { and: [] }
    let anyQuery: AnyObject = {}
    let responseData: Array<AnyObject> = []

    query.and.push({
      status: 1
    })
    if (data && data.category) {
      anyQuery = {
        name: new RegExp('.*' + data.category + '.*', 'i')
      }
      const categories = await this.categoryRepository.find({
        where: anyQuery,
        fields: { id: true, name: true }
      })
      let categoryId = _.map(categories, v => v.id)
      query.and.push({
        categoryId: { inq: categoryId }
      })
    }
    if (data && data.name) {
      query.and.push({
        name: new RegExp('.*' + data.name + '.*', 'i')
      })
    }

    let resourceDetails = await this.resourcesRepository.find({
      where: query
    })
    if (resourceDetails && resourceDetails.length) {

      let categoryId = _.map(resourceDetails, v => v.categoryId)
      let userIds = _.map(resourceDetails, v => v.createdId)

      return Promise.all([
        this.categoryRepository.find({
          where: {
            id: { inq: categoryId }
          }, fields: { id: true, name: true }
        }),
        this.usersRepository.find({
          where: {
            id: { inq: userIds }
          }, fields: { id: true, name: true }
        })

      ]).then(res => {

        let category = res && res[0] && res[0].length && _.groupBy(res[0], v => v.id)
        let users = res && res[1] && res[1].length && _.groupBy(res[1], v => v.id)

        _.forEach(resourceDetails, function (val: any, index) {
          let obj: AnyObject = Object.assign({}, val)
          obj.category = category && category[val.categoryId!] && Object.assign({}, category[val.categoryId!][0]) || {};
          obj.user = users && users[val.createdId!] && Object.assign({}, users[val.createdId!][0]) || {};
          obj.like = index + 2 * 5
          obj.comment = index + 5 * 6
          obj.share = index + 7 * 7
          responseData.push(obj)
        })
        return responseData;
      }).catch(err => {
        throw new HttpErrors.UnprocessableEntity("Something went wrong")
      })
    } else {
      throw new HttpErrors.NotFound("Resource Not found!")
    }
  }
}
