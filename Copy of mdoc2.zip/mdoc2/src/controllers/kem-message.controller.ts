import {
  get,
  del,
  post,
  patch,
  param,
  requestBody,
  getModelSchemaRef,
  getFilterSchemaFor,
} from '@loopback/rest';
import {KemMessage} from '../models';
import {inject} from '@loopback/core';
import {Filter} from '@loopback/repository';
import {KemMessageService} from '../services';
import {PaginatedResponse} from '../type-schema';
import {KemMessageSerivceBindings} from '../keys';
import {authenticate} from '@loopback/authentication';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';
import {UserProfile, SecurityBindings} from '@loopback/security';

export class KemMessageController {
  constructor(
    @inject(KemMessageSerivceBindings.KEM_MESSAGE)
    public kemMessageService: KemMessageService,
  ) {}

  @post('/kem-message', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'KemMessage model instance',
        content: {
          'application/json': {schema: getModelSchemaRef(KemMessage)},
        },
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(KemMessage, {
            title: 'NewKemMessage',
            exclude: ['id', 'user_id'],
          }),
        },
      },
    })
    kemMessage: Omit<KemMessage, 'id, user_id'>,
    @inject(SecurityBindings.USER) currentUser: UserProfile,
  ): Promise<KemMessage> {
    return this.kemMessageService.create(kemMessage, currentUser);
  }

  @get('/kem-message', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of KemMessage model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(KemMessage, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findAll(
    @inject(SecurityBindings.USER) currentUser: UserProfile,
    @param.query.object('filter', getFilterSchemaFor(KemMessage))
    filter?: Filter<KemMessage>,
    @param.query.number('page') page?: number,
  ): Promise<PaginatedResponse<KemMessage>> {
    return this.kemMessageService.findAll(filter, currentUser, page);
  }

  @get('/kem-message/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'KemMessage model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(KemMessage, {includeRelations: true}),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findById(
    @inject(SecurityBindings.USER) currentUser: UserProfile,
    @param.path.string('id') id: string,
  ) {
    return this.kemMessageService.findById(id, currentUser);
  }

  @get('/kem-message/chat-payload', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Payload to initialize a kem chat',
        content: {
          'application/json': {
            schema: {
              type: 'object',
              properties: {
                location: {type: 'string'},
                user_id: {type: 'string'},
                user_full_name: {type: 'string'},
                date_of_birth: {type: 'string'},
                gender: {type: 'string'},
                exercise_duration_last_30_days: {type: 'number'},
                latest_bmi: {type: 'string'},
                bmi_measurement_date: {type: 'string'},
                latest_bp: {type: 'string'},
                bp_measurement_date: {type: 'string'},
                pregnancy_status: {type: 'boolean'},
                pregnancy_edd: {type: 'string'},
                summarized_notes: {type: 'string'},
                health_coach_name: {type: 'string'},
                action_plan: {type: 'string'},
              },
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async getKemPayload(@inject(SecurityBindings.USER) currentUser: UserProfile) {
    return this.kemMessageService.getKemPayload(currentUser);
  }

  @patch('/kem-message/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'KemMessage PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(KemMessage, {
            partial: true,
            exclude: ['id', 'created_at'],
          }),
        },
      },
    })
    @inject(SecurityBindings.USER)
    currentUser: UserProfile,
    kemMessage: KemMessage,
  ): Promise<void> {
    return await this.kemMessageService.updateById(id, kemMessage, currentUser);
  }

  @del('/kem-message/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'KemMessage DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(
    @param.path.string('id') id: string,
    @inject(SecurityBindings.USER) currentUser: UserProfile,
  ): Promise<void> {
    this.kemMessageService.deleteById(id, currentUser);
  }
}
