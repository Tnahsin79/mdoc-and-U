import {
  get,
  put,
  del,
  post,
  patch,
  param,
  requestBody,
  getModelSchemaRef,
  getWhereSchemaFor,
  getFilterSchemaFor,
} from '@loopback/rest';
import {
  ActivityTimelineRepository,
  ProcedureSurgeriesRepository,
} from '../repositories';
import csv from 'csvtojson';
import {
  Count,
  Where,
  Filter,
  repository,
  CountSchema,
} from '@loopback/repository';
import {inject} from '@loopback/core';
import {ProcedureSurgeries} from '../models';
import {activityTypeObj} from '../type-schema';
import {MigrationServiceBindings} from '../keys';
import {authenticate} from '@loopback/authentication';
import {MigrationService} from '../services/migration.service';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';
export class ProcedureSurgeriesController {
  constructor(
    @repository(ProcedureSurgeriesRepository)
    public procedureSurgeriesRepository: ProcedureSurgeriesRepository,
    @repository(ActivityTimelineRepository)
    public activityTimelineRepository: ActivityTimelineRepository,
    @inject(MigrationServiceBindings.MIGRATION_SERVICE)
    public migrationService: MigrationService,
  ) {}

  @post('/procedure-surgeries', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'ProcedureSurgeries model instance',
        content: {
          'application/json': {schema: getModelSchemaRef(ProcedureSurgeries)},
        },
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(ProcedureSurgeries, {
            title: 'NewProcedureSurgeries',
            exclude: ['id'],
          }),
        },
      },
    })
    procedureSurgeries: Omit<ProcedureSurgeries, 'id'>,
  ): Promise<ProcedureSurgeries> {
    const data = await this.procedureSurgeriesRepository.create(
      procedureSurgeries,
    );
    await this.activityTimelineRepository.create({
      activityType: activityTypeObj.MEDICAL_PROCEDURES,
      userId: data.userId,
      metadata: data.id,
    });
    return data;
  }

  @get('/procedure-surgeries/count', {
    responses: {
      '200': {
        description: 'ProcedureSurgeries model count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async count(
    @param.query.object('where', getWhereSchemaFor(ProcedureSurgeries))
    where?: Where<ProcedureSurgeries>,
  ): Promise<Count> {
    return this.procedureSurgeriesRepository.count(where);
  }

  @get('/procedure-surgeries', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of ProcedureSurgeries model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(ProcedureSurgeries, {
                includeRelations: true,
              }),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async find(
    @param.query.object('filter', getFilterSchemaFor(ProcedureSurgeries))
    filter?: Filter<ProcedureSurgeries>,
  ): Promise<ProcedureSurgeries[]> {
    return this.procedureSurgeriesRepository.find(filter);
  }

  @patch('/procedure-surgeries', {
    responses: {
      '200': {
        description: 'ProcedureSurgeries PATCH success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(ProcedureSurgeries, {partial: true}),
        },
      },
    })
    procedureSurgeries: ProcedureSurgeries,
    @param.query.object('where', getWhereSchemaFor(ProcedureSurgeries))
    where?: Where<ProcedureSurgeries>,
  ): Promise<Count> {
    return this.procedureSurgeriesRepository.updateAll(
      procedureSurgeries,
      where,
    );
  }

  @get('/procedure-surgeries/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'ProcedureSurgeries model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(ProcedureSurgeries, {
              includeRelations: true,
            }),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(ProcedureSurgeries))
    filter?: Filter<ProcedureSurgeries>,
  ): Promise<ProcedureSurgeries> {
    return this.procedureSurgeriesRepository.findById(id, filter);
  }

  @patch('/procedure-surgeries/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'ProcedureSurgeries PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(ProcedureSurgeries, {partial: true}),
        },
      },
    })
    procedureSurgeries: ProcedureSurgeries,
  ): Promise<void> {
    await this.procedureSurgeriesRepository.updateById(id, procedureSurgeries);
  }

  @put('/procedure-surgeries/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'ProcedureSurgeries PUT success',
      },
    },
  })
  @authenticate('jwt')
  async replaceById(
    @param.path.string('id') id: string,
    @requestBody() procedureSurgeries: ProcedureSurgeries,
  ): Promise<void> {
    await this.procedureSurgeriesRepository.replaceById(id, procedureSurgeries);
  }

  @del('/procedure-surgeries/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'ProcedureSurgeries DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.procedureSurgeriesRepository.deleteById(id);
  }

  @get('/procedureSurgeriesMigration', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'ProcedureSurgeries Migration instance',
      },
    },
  })
  @authenticate('jwt')
  async procedureSurgeriesMigration(): Promise<any> {
    const filePath = './public/surgery_and_procedures.csv';

    let procedure = await csv().fromFile(filePath);
    if (procedure && procedure.length) {
      for (let [index, value] of procedure.entries()) {
        await this.migrationService.ProcedureSurgeryMigration(value);
      }
    }
  }
}
