import {
  Count,
  CountSchema,
  Filter,
  repository,
  Where,
} from '@loopback/repository';
import {
  post,
  param,
  get,
  getModelSchemaRef,
  patch,
  put,
  del,
  requestBody,
  getWhereSchemaFor,
} from '@loopback/rest';
import {BroadcastMessage} from '../models';
import {BroadcastMessageRepository} from '../repositories';
import { inject } from '@loopback/context';
import { BroadcastMessageService } from '../services';
import { BroadcastMessageServiceBinding } from '../keys';

export class BroadcastMessageController {
  constructor(
    @repository(BroadcastMessageRepository)
    public broadcastMessageRepository : BroadcastMessageRepository,
    @inject(BroadcastMessageServiceBinding.BROADCAST_SERVICE_BINDING)
    public broadCastMsgService: BroadcastMessageService

  ) {}

  @post('/broadcast-messages', {
    responses: {
      '200': {
      description: 'BroadcastMessage model instance',
      content: {'application/json': {schema: getModelSchemaRef(BroadcastMessage)}},
    }}
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(BroadcastMessage, {
            title: 'NewBroadcastMessage',
            exclude: ['id'],
          }),
        },
      },
    })
    broadcastMessage: Omit<BroadcastMessage, 'id'>,
  ): Promise<BroadcastMessage> {
    return this.broadcastMessageRepository.create(broadcastMessage);
  }

  @get('/broadcast-messages/count', {
    responses: {
      '200':{
      description: 'BroadcastMessage model count',
      content: {'application/json': {schema: CountSchema}},
    }}
  })
  async count(
    @param.query.object('where', getWhereSchemaFor(BroadcastMessage)) where?: Where<BroadcastMessage>,
  ): Promise<Count> {
    return this.broadcastMessageRepository.count(where);
  }

  @get('/broadcast-messages', {
    responses: {
      '200': {
      description: 'Array of BroadcastMessage model instances',
      content: {
        'application/json': {
          schema: {
            type: 'array',
            items: getModelSchemaRef(BroadcastMessage, {includeRelations: true}),
          },
        },
      },
    }}
  })
  async find(
    @param.query.object('filter', BroadcastMessage) filter?: Filter<BroadcastMessage>,
  ): Promise<BroadcastMessage[]> {
    return this.broadCastMsgService.fetchBroadcastMessage(filter);
  }

  @patch('/broadcast-messages', {
    responses: {
      '200': {
      description: 'BroadcastMessage PATCH success count',
      content: {'application/json': {schema: CountSchema}},
    }}
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(BroadcastMessage, {partial: true}),
        },
      },
    })
    broadcastMessage: BroadcastMessage,
    @param.query.object('where', BroadcastMessage) where?: Where<BroadcastMessage>,
  ): Promise<Count> {
    return this.broadcastMessageRepository.updateAll(broadcastMessage, where);
  }

  @get('/broadcast-messages/{id}', {
    responses:{
      '200': {
      description: 'BroadcastMessage model instance',
      content: {
        'application/json': {
          schema: getModelSchemaRef(BroadcastMessage, {includeRelations: true}),
        },
      },
    }}
  })
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', BroadcastMessage, {exclude: 'where'}) filter?: Filter<BroadcastMessage>
  ): Promise<BroadcastMessage> {
    return this.broadcastMessageRepository.findById(id, filter);
  }

  @patch('/broadcast-messages/{id}', {
    responses: {
      '204':{
      description: 'BroadcastMessage PATCH success',
    }}
  })
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(BroadcastMessage, {partial: true}),
        },
      },
    })
    broadcastMessage: BroadcastMessage,
  ): Promise<void> {
    await this.broadcastMessageRepository.updateById(id, broadcastMessage);
  }

  @put('/broadcast-messages/{id}', {
    responses:{
      '204': {
      description: 'BroadcastMessage PUT success',
    }}
  })
  async replaceById(
    @param.path.string('id') id: string,
    @requestBody() broadcastMessage: BroadcastMessage,
  ): Promise<void> {
    await this.broadcastMessageRepository.replaceById(id, broadcastMessage);
  }

  @del('/broadcast-messages/{id}', {
    responses:{
      '204': {
      description: 'BroadcastMessage DELETE success',
    }}
  })
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.broadcastMessageRepository.deleteById(id);
  }
}
