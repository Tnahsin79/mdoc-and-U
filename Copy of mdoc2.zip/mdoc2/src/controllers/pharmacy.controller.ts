import {
  get,
  put,
  del,
  post,
  patch,
  param,
  requestBody,
  getModelSchemaRef,
  getWhereSchemaFor,
  getFilterSchemaFor,
} from '@loopback/rest';
import csv from 'csvtojson';
import {
  Count,
  Where,
  Filter,
  repository,
  CountSchema,
} from '@loopback/repository';
import {Pharmacy} from '../models';
import {inject} from '@loopback/core';
import {activityTypeObj} from '../type-schema';
import {MigrationServiceBindings} from '../keys';
import {authenticate} from '@loopback/authentication';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';
import {MigrationService} from '../services/migration.service';
import {UserProfile, securityId, SecurityBindings} from '@loopback/security';
import {ActivityTimelineRepository, PharmacyRepository} from '../repositories';
export class PharmacyController {
  constructor(
    @repository(PharmacyRepository)
    public pharmacyRepository: PharmacyRepository,
    @repository(ActivityTimelineRepository)
    public activityTimelineRepository: ActivityTimelineRepository,
    @inject(MigrationServiceBindings.MIGRATION_SERVICE)
    public migrationService: MigrationService,
  ) {}

  @post('/pharmacies', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Pharmacy model instance',
        content: {'application/json': {schema: getModelSchemaRef(Pharmacy)}},
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Pharmacy, {
            title: 'NewPharmacy',
            exclude: ['id'],
          }),
        },
      },
    })
    pharmacy: Omit<Pharmacy, 'id'>,
  ): Promise<Pharmacy> {
    pharmacy.isPharmacyComplete = true;
    const data = await this.pharmacyRepository.create(pharmacy);
    await this.activityTimelineRepository.create({
      activityType: activityTypeObj.PHARMACY,
      userId: data.userId,
      metadata: data.id,
    });
    return data;
  }

  @get('/pharmacies/count', {
    responses: {
      '200': {
        description: 'Pharmacy model count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async count(
    @param.query.object('where', getWhereSchemaFor(Pharmacy))
    where?: Where<Pharmacy>,
  ): Promise<Count> {
    return this.pharmacyRepository.count(where);
  }

  @get('/pharmacies', {
    responses: {
      '200': {
        description: 'Array of Pharmacy model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(Pharmacy, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  async find(
    @param.query.object('filter', getFilterSchemaFor(Pharmacy))
    filter?: Filter<Pharmacy>,
  ): Promise<Pharmacy[]> {
    return this.pharmacyRepository.find(filter);
  }

  @patch('/pharmacies', {
    responses: {
      '200': {
        description: 'Pharmacy PATCH success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Pharmacy, {partial: true}),
        },
      },
    })
    pharmacy: Pharmacy,
    @param.query.object('where', getWhereSchemaFor(Pharmacy))
    where?: Where<Pharmacy>,
  ): Promise<Count> {
    return this.pharmacyRepository.updateAll(pharmacy, where);
  }

  @get('/pharmacies/{id}', {
    responses: {
      '200': {
        description: 'Pharmacy model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Pharmacy, {includeRelations: true}),
          },
        },
      },
    },
  })
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(Pharmacy))
    filter?: Filter<Pharmacy>,
  ): Promise<Pharmacy> {
    return this.pharmacyRepository.findById(id, filter);
  }

  @patch('/pharmacies/{id}', {
    responses: {
      '204': {
        description: 'Pharmacy PATCH success',
      },
    },
  })
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Pharmacy, {partial: true}),
        },
      },
    })
    pharmacy: Pharmacy,
  ): Promise<void> {
    await this.pharmacyRepository.updateById(id, pharmacy);
  }

  @put('/pharmacies/{id}', {
    responses: {
      '204': {
        description: 'Pharmacy PUT success',
      },
    },
  })
  async replaceById(
    @param.path.string('id') id: string,
    @requestBody() pharmacy: Pharmacy,
  ): Promise<void> {
    await this.pharmacyRepository.replaceById(id, pharmacy);
  }

  @del('/pharmacies/{id}', {
    responses: {
      '204': {
        description: 'Pharmacy DELETE success',
      },
    },
  })
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.pharmacyRepository.deleteById(id);
  }

  @get('/pharmacies/dashboardMyPharmacy/', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Pharmacy  success',
      },
    },
  })
  @authenticate('jwt')
  async dashboardMyPharmacy(
    @inject(SecurityBindings.USER) currentUser: UserProfile,
  ): Promise<any> {
    const myPharmacy = await this.pharmacyRepository.find({
      where: {
        userId: currentUser[securityId],
      },
      order: ['created DESC'],
    });
    if (myPharmacy && myPharmacy.length) {
      return myPharmacy;
    } else {
      return [];
    }
  }

  @get('/pharmaciesMigration', {
    responses: {
      '200': {
        description: 'Pharmacy  success',
      },
    },
  })
  async pharmaciesMigration(): Promise<any> {
    const filePath = './public/user_phamacy_record.csv';
    let mediData = await csv().fromFile(filePath);
    if (mediData && mediData.length) {
      for (let value of mediData) {
        await this.migrationService.userPhamacyRecordMigration(value);
      }
    }
  }
}
