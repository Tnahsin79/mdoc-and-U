import {authenticate} from '@loopback/authentication';
import {
  Count,
  CountSchema,
  Filter,
  repository,
  Where,
} from '@loopback/repository';
import {
  post,
  param,
  get,
  getModelSchemaRef,
  patch,
  put,
  del,
  requestBody,
  getFilterSchemaFor,
} from '@loopback/rest';
import {ExerciseTypes} from '../models';
import {ExerciseTypesRepository} from '../repositories';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';
import csv from 'csvtojson';
import {inject} from '@loopback/core';
import {ExerciseTypesServiceBindings, MigrationServiceBindings} from '../keys';
import {MigrationService} from '../services/migration.service';
import {ExerciseTypesService} from '../services/exercise-types.service';

export class ExerciseTypesController {
  constructor(
    @repository(ExerciseTypesRepository)
    public exerciseTypesRepository: ExerciseTypesRepository,
    @inject(MigrationServiceBindings.MIGRATION_SERVICE)
    public migrationService: MigrationService,
    @inject(ExerciseTypesServiceBindings.EXERCISE_TYPES_SERVICE)
    public exerciseTypesService: ExerciseTypesService,
  ) {}

  @post('/exercise-types', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'ExerciseTypes model instance',
        content: {
          'application/json': {schema: getModelSchemaRef(ExerciseTypes)},
        },
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(ExerciseTypes, {
            title: 'NewExerciseTypes',
            exclude: ['id'],
          }),
        },
      },
    })
    exerciseTypes: Omit<ExerciseTypes, 'id'>,
  ): Promise<ExerciseTypes> {
    return this.exerciseTypesRepository.create(exerciseTypes);
  }

  // @get('/exercise-types/count')
  // @response(200, {
  //   description: 'ExerciseTypes model count',
  //   content: { 'application/json': { schema: CountSchema } },
  // })
  // async count(
  //   @param.where(ExerciseTypes) where?: Where<ExerciseTypes>,
  // ): Promise<Count> {
  //   return this.exerciseTypesRepository.count(where);
  // }

  @get('/exercise-types', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'Array of ExerciseTypes model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(ExerciseTypes, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async find(
    @param.query.object('filter', getFilterSchemaFor(ExerciseTypes))
    filter?: Filter<ExerciseTypes>,
  ): Promise<ExerciseTypes[]> {
    return this.exerciseTypesRepository.find(filter);
  }

  // @patch('/exercise-types')
  // @response(200, {
  //   description: 'ExerciseTypes PATCH success count',
  //   content: { 'application/json': { schema: CountSchema } },
  // })
  // async updateAll(
  //   @requestBody({
  //     content: {
  //       'application/json': {
  //         schema: getModelSchemaRef(ExerciseTypes, { partial: true }),
  //       },
  //     },
  //   })
  //   exerciseTypes: ExerciseTypes,
  //   @param.where(ExerciseTypes) where?: Where<ExerciseTypes>,
  // ): Promise<Count> {
  //   return this.exerciseTypesRepository.updateAll(exerciseTypes, where);
  // }

  @get('/exercise-types/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'ExerciseTypes model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(ExerciseTypes, {includeRelations: true}),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(ExerciseTypes))
    filter?: Filter<ExerciseTypes>,
  ): Promise<ExerciseTypes> {
    return this.exerciseTypesRepository.findById(id, filter);
  }

  @patch('/exercise-types/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      204: {
        description: 'ExerciseTypes PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(ExerciseTypes, {partial: true}),
        },
      },
    })
    exerciseTypes: ExerciseTypes,
  ): Promise<void> {
    await this.exerciseTypesRepository.updateById(id, exerciseTypes);
  }

  // @put('/exercise-types/{id}')
  // @response(204, {
  //   description: 'ExerciseTypes PUT success',
  // })
  // async replaceById(
  //   @param.path.string('id') id: string,
  //   @requestBody() exerciseTypes: ExerciseTypes,
  // ): Promise<void> {
  //   await this.exerciseTypesRepository.replaceById(id, exerciseTypes);
  // }

  @del('/exercise-types/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      204: {
        description: 'ExerciseTypes DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.exerciseTypesRepository.deleteById(id);
  }

  @del('/exerciseTypesMigration', {
    responses: {
      200: {
        description: 'ExerciseTypes Migration success',
      },
    },
  })
  async exerciseTypesMigration(): Promise<any> {
    const filePath = './public/exercise_types.csv';

    let usersExerciseList = await csv().fromFile(filePath);
    if (usersExerciseList && usersExerciseList.length) {
      for (const value of usersExerciseList) {
        await this.migrationService.exerciseTypesMigration(value);
      }
    }
  }
}
