import {
  post,
  param,
  get,
  getFilterSchemaFor,
  getModelSchemaRef,
  getWhereSchemaFor,
  patch,
  put,
  del,
  requestBody,
  HttpErrors,
} from '@loopback/rest';
import {
  Count,
  CountSchema,
  Filter,
  repository,
  Where,
  AnyObject,
} from '@loopback/repository';
import {inject} from '@loopback/core';
import {Affordablity} from '../models';
import {AffordablityServiceBindings} from '../keys';
import {authenticate} from '@loopback/authentication';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';
import {AffordablityService} from '../services/affordability.service';
import {AffordablityRepository, DiseaseRepository} from '../repositories';
import {UserProfile, securityId, SecurityBindings} from '@loopback/security';
export class AffordablityController {
  constructor(
    @repository(AffordablityRepository)
    public affordablityRepository: AffordablityRepository,
    @repository(DiseaseRepository) public diseaseRepository: DiseaseRepository,
    @inject(AffordablityServiceBindings.AFFORDABILITY_SERVICE)
    public affordablityService: AffordablityService,
  ) {}

  @post('/affordablities', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Affordablity model instance',
        content: {
          'application/json': {schema: getModelSchemaRef(Affordablity)},
        },
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Affordablity, {
            title: 'NewAffordablity',
            exclude: ['id'],
          }),
        },
      },
    })
    affordablity: Omit<Affordablity, 'id'>,
  ): Promise<Affordablity> {
    return this.affordablityRepository.create(affordablity);
  }

  @get('/affordablities/count', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Affordablity model count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  @authenticate('jwt')
  async count(
    @param.query.object('where', getWhereSchemaFor(Affordablity))
    where?: Where<Affordablity>,
  ): Promise<Count> {
    return this.affordablityRepository.count(where);
  }

  @get('/affordablities', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of Affordablity model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(Affordablity, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async find(
    @param.query.object('filter', getFilterSchemaFor(Affordablity))
    filter?: Filter<Affordablity>,
  ): Promise<Affordablity[]> {
    return this.affordablityRepository.find(filter);
  }

  @patch('/affordablities', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Affordablity PATCH success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  @authenticate('jwt')
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Affordablity, {partial: true}),
        },
      },
    })
    affordablity: Affordablity,
    @param.query.object('where', getWhereSchemaFor(Affordablity))
    where?: Where<Affordablity>,
  ): Promise<Count> {
    return this.affordablityRepository.updateAll(affordablity, where);
  }

  @get('/affordablities/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Affordablity model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Affordablity, {includeRelations: true}),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(Affordablity))
    filter?: Filter<Affordablity>,
  ): Promise<Affordablity> {
    return this.affordablityRepository.findById(id, filter);
  }

  @patch('/affordablities/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Affordablity PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Affordablity, {partial: true}),
        },
      },
    })
    affordablity: Affordablity,
  ): Promise<void> {
    await this.affordablityRepository.updateById(id, affordablity);
  }

  @put('/affordablities/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Affordablity PUT success',
      },
    },
  })
  @authenticate('jwt')
  async replaceById(
    @param.path.string('id') id: string,
    @requestBody() affordablity: Affordablity,
  ): Promise<void> {
    await this.affordablityRepository.replaceById(id, affordablity);
  }

  @del('/affordablities/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Affordablity DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.affordablityRepository.deleteById(id);
  }

  @get('/affordablities/getUserAffordablities', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Affordablity model instance',
      },
    },
  })
  @authenticate('jwt')
  async getUserAffordablities(
    @inject(SecurityBindings.USER) currentUser: UserProfile,
  ): Promise<any> {
    let responseData: AnyObject = {};
    const affordablity = await this.affordablityRepository.findOne({
      where: {
        userId: currentUser[securityId],
      },
    });

    if (affordablity && affordablity.userId) {
      responseData = Object.assign({}, affordablity);

      const disease = await this.diseaseRepository.find({
        where: {
          id: {inq: affordablity.diseaseId},
        },
        fields: {id: true, name: true},
      });

      responseData.diseases = (disease && disease.length && disease) || [];
      return responseData;
    } else {
      throw new HttpErrors.NotFound('Affordablity not found!');
    }
  }
}
