import {
  get,
  del,
  post,
  patch,
  param,
  requestBody,
  getModelSchemaRef,
  getFilterSchemaFor,
} from '@loopback/rest';
import {Weight} from '../models';
import {inject} from '@loopback/core';
import {WeightService} from '../services';
import {Filter} from '@loopback/repository';
import {WeightServiceBindings} from '../keys';
import {PaginatedResponse} from '../type-schema';
import {authenticate} from '@loopback/authentication';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';

export class WeightController {
  constructor(
    @inject(WeightServiceBindings.WEIGHT_SERVICE)
    public weightService: WeightService,
  ) {}

  @post('/weight', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Weight model instance',
        content: {
          'application/json': {schema: getModelSchemaRef(Weight)},
        },
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Weight, {
            title: 'NewWeight',
            exclude: ['id', 'defaultValue', 'defaultUnit'],
          }),
        },
      },
    })
    weight: Omit<Weight, 'id, defaultValue, defaultUnit'>,
  ): Promise<Weight> {
    return this.weightService.create(weight);
  }

  @get('/weight', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of Weight model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(Weight, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findAll(
    @param.query.object('filter', getFilterSchemaFor(Weight))
    filter?: Filter<Weight>,
    @param.query.number('page') page?: number,
  ): Promise<PaginatedResponse<Weight>> {
    return this.weightService.findAll(filter, page);
  }

  @get('/weight/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Weight model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Weight, {includeRelations: true}),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(Weight))
    filter?: Filter<Weight>,
  ) {
    return this.weightService.findById(id, filter);
  }

  @patch('/weight/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Weight PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Weight, {
            partial: true,
            exclude: ['id', 'defaultValue', 'defaultUnit', 'created_at'],
          }),
        },
      },
    })
    weight: Weight,
  ): Promise<void> {
    return await this.weightService.updateById(id, weight);
  }

  @del('/weight/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Weight DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    this.weightService.deleteById(id);
  }
}
