import {
  Count,
  CountSchema,
  Filter,
  repository,
  Where,
} from '@loopback/repository';
import {
  post,
  param,
  get,
  getModelSchemaRef,
  patch,
  put,
  del,
  requestBody,
} from '@loopback/rest';
import {BroadcastGroup} from '../models';
import {BroadcastGroupRepository} from '../repositories';
import { log } from 'console';
import { inject } from '@loopback/context';
import { BroadcastGroupServiceBinding } from '../keys';
import { BroadcastGroupService } from '../services';

export class BroadcastGroupController {
  constructor(
    @repository(BroadcastGroupRepository)
    public broadcastGroupRepository : BroadcastGroupRepository,
    @inject(BroadcastGroupServiceBinding.BROADCAST_GROUP_SERVICE_BINDING)
    public broadcastGroupService: BroadcastGroupService
  ) {}

  @post('/broadcast-groups', {
    responses: {
      '201': {
        description: 'BroadcastGroup model instance',
        content: {
          'application/json': {
            schema: {schema: getModelSchemaRef(BroadcastGroup)},
          },
        },
      }
    }
  })
  async createBroadcastGrp(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(BroadcastGroup, {
            title: 'NewBroadcastGroup',
            exclude: ['id'],
          }),
        },
      },
    })
    broadcastGroup: Omit<BroadcastGroup, 'id'>,
  ): Promise<BroadcastGroup> {
    return this.broadcastGroupRepository.create(broadcastGroup)
  }

  @get('/broadcast-groups/count', {
    responses: {
      '200': {
      description: 'BroadcastGroup model count',
      content: {'application/json': {schema: CountSchema}},
    }}
  })
  async count(
    @param.query.object('where', BroadcastGroup) where?: Where<BroadcastGroup>,
  ): Promise<Count> {
    return this.broadcastGroupRepository.count(where);
  }

  @get('/broadcast-groups', {
    responses: {
      '200': {
        description: 'Array of Broadcast groups model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(BroadcastGroup, { includeRelations: true }),
            },
          },
        },
      },
    },
  })
  async getBroadcastGrp(
    @param.query.object('filter', BroadcastGroup)
    filter?: Filter<BroadcastGroup>,
  ): Promise<BroadcastGroup[]> {
    return this.broadcastGroupService.getbroadcastGroup(filter);
  }

  @patch('/broadcast-groups', {
    responses:{
      '200': {
      description: 'BroadcastGroup PATCH success count',
      content: {'application/json': {schema: CountSchema}},
    }}
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(BroadcastGroup, {partial: true}),
        },
      },
    })
    broadcastGroup: BroadcastGroup,
    @param.query.object('where', BroadcastGroup) where?: Where<BroadcastGroup>,
  ): Promise<Count> {
    return this.broadcastGroupRepository.updateAll(broadcastGroup, where);
  }

  @get('/broadcast-groups/{id}', {
    responses: {
      '200': {
        description: 'Broadcast group model instances',
        content: {
          'application/json': {
            schema: {
              items: getModelSchemaRef(BroadcastGroup, { includeRelations: true }),
            },
          },
        },
      },
    },
  })
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', BroadcastGroup, {exclude: 'where'}) filter?: Filter<BroadcastGroup>
  ): Promise<BroadcastGroup> {
    return this.broadcastGroupRepository.findById(id, filter);
  }

  @patch('/broadcast-groups/{id}', {
    responses:{
      '200': {
      description: 'BroadcastGroup PATCH success',
      content: {'application/json': {schema: getModelSchemaRef(BroadcastGroup)}},
    }}
  })
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(BroadcastGroup, {partial: true}),
        },
      },
    })
    broadcastGroup: BroadcastGroup,
  ): Promise<BroadcastGroup> {
    return this.broadcastGroupService.updateBroadcastGroup({id, broadcastGroup})
  }

  @put('/broadcast-groups/{id}', {
    responses: {
      '204':{
      description: 'BroadcastGroup PUT success',
    }}
  })
  async replaceById(
    @param.path.string('id') id: string,
    @requestBody() broadcastGroup: BroadcastGroup,
  ): Promise<void> {
    await this.broadcastGroupRepository.replaceById(id, broadcastGroup);
  }

  @del('/broadcast-groups/{id}', {
    responses: {
      '204': {
      description: 'BroadcastGroup DELETE success',
    }}
  })
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.broadcastGroupRepository.deleteById(id);
  }
}
