import {
    get,
    del,
    post,
    patch,
    param,
    requestBody,
    getModelSchemaRef,
    getFilterSchemaFor,
  } from '@loopback/rest';
  import {Height, Temperature} from '../models';
  import {inject} from '@loopback/core';
  import {HeightService, TemperatureService} from '../services';
  import {Filter} from '@loopback/repository';
  import {HeightServiceBindings, TemperatureServiceBindings} from '../keys';
  import {PaginatedResponse} from '../type-schema';
  import {authenticate} from '@loopback/authentication';
  import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';
  import Utils from '../utils';
  
  export class TemperatureController {
    constructor(
      @inject(TemperatureServiceBindings.TEMPERATURE_SERVICE)
      public temperatureService: TemperatureService,
    ) {}
  
    @post('/temperature', {
      security: OPERATION_SECURITY_SPEC,
      responses: {
        '200': {
          description: 'Temperature model instance',
          content: {
            'application/json': {schema: getModelSchemaRef(Temperature)},
          },
        },
      },
    })
    @authenticate('jwt')
    async create(
      @requestBody({
        content: {
          'application/json': {
            schema: getModelSchemaRef(Temperature, {
              title: 'NewTemperature',
              exclude: ['id', 'defaultValue', 'defaultUnit'],
            }),
          },
        },
      })
      temperature: Omit<Temperature, 'id, defaultValue, defaultUnit'>,
    ): Promise<Temperature> {
      return this.temperatureService.create(temperature);
    }
  
    @get('/temperature', {
      security: OPERATION_SECURITY_SPEC,
      responses: {
        '200': {
          description: 'Array of Temperature model instances',
          content: {
            'application/json': {
              schema: Utils.paginatedSchema(Temperature, true),
            },
          },
        },
      },
    })
    @authenticate('jwt')
    async findAll(
      @param.query.object('filter', getFilterSchemaFor(Temperature))
      filter?: Filter<Temperature>,
      @param.query.number('page') page?: number,
    ): Promise<PaginatedResponse<Temperature>> {
      return this.temperatureService.findAll(filter, page);
    }
  
    @get('/temperature/{id}', {
      security: OPERATION_SECURITY_SPEC,
      responses: {
        '200': {
          description: 'Temperature model instance',
          content: {
            'application/json': {
              schema: getModelSchemaRef(Temperature, {includeRelations: true}),
            },
          },
        },
      },
    })
    @authenticate('jwt')
    async findById(
      @param.path.string('id') id: string,
      @param.query.object('filter', getFilterSchemaFor(Temperature))
      filter?: Filter<Temperature>,
    ) {
      return this.temperatureService.findById(id, filter);
    }
  
    @patch('/temperature/{id}', {
      security: OPERATION_SECURITY_SPEC,
      responses: {
        '204': {
          description: 'Temperature PATCH success',
        },
      },
    })
    @authenticate('jwt')
    async updateById(
      @param.path.string('id') id: string,
      @requestBody({
        content: {
          'application/json': {
            schema: getModelSchemaRef(Temperature, {
              partial: true,
              exclude: ['id', 'defaultValue', 'defaultUnit', 'modified_at'],
            }),
          },
        },
      })
      temp: Temperature,
    ): Promise<void> {
      return await this.temperatureService.updateById(id, temp);
    }
  
    @del('/temperature/{id}', {
      security: OPERATION_SECURITY_SPEC,
      responses: {
        '204': {
          description: 'Temperature DELETE success',
        },
      },
    })
    @authenticate('jwt')
    async deleteById(@param.path.string('id') id: string): Promise<void> {
      this.temperatureService.deleteById(id);
    }
  }
  