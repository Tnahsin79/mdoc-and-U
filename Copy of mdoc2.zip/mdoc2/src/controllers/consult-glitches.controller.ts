import {
  get,
  del,
  post,
  patch,
  param,
  requestBody,
  getModelSchemaRef,
  getFilterSchemaFor,
} from '@loopback/rest';
import {Glitches} from '../models';
import {inject} from '@loopback/core';
import {Filter} from '@loopback/repository';
import {ConsultGlitchesService } from '../services';
import {PaginatedResponse} from '../type-schema';
import {ConsultGlitchesServiceBindings} from '../keys';
import {authenticate} from '@loopback/authentication';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';
import {UserProfile, SecurityBindings} from '@loopback/security';
import Utils from '../utils';

export class ConsultGlitchesController {
  constructor(
    @inject(ConsultGlitchesServiceBindings.CONSULT_GLITCHES_SERVICE)
    public consultGlitchesService: ConsultGlitchesService,
  ) {}

    @post('/consult-glitches', {
        security: OPERATION_SECURITY_SPEC,
            responses: {
            '201': {
                description: 'ConsultGlitches model instance',
                content: {'application/json': {schema: getModelSchemaRef(Glitches)}},
            },
        },
    })
    @authenticate('jwt')
    async create(
        @inject(SecurityBindings.USER) currentUser: UserProfile,
        @requestBody({
            content: {
                'application/json': {
                schema: getModelSchemaRef(Glitches, {
                    title: 'NewGlitches',
                    exclude: ['id'],
                }),
                },
            },
        })
        glitches: Omit<Glitches, 'id'>,
    ): Promise<Glitches> {
        return this.consultGlitchesService.create(glitches, currentUser);
    }

    @get('/consult-glitches', {
        security: OPERATION_SECURITY_SPEC,
        responses: {
            '200': {
                description: 'Array of ConsultGlitches model instances',
                content: {
                    'application/json': {
                        schema: Utils.paginatedSchema(Glitches, true),
                    },
                },
            },
        },
    })
    @authenticate('jwt')
    async find(
        @param.query.object('filter', getFilterSchemaFor(Glitches))
        filter?: Filter<Glitches>,
        @param.query.number('page') page?: number,
    ): Promise<PaginatedResponse<Glitches>> {
        return this.consultGlitchesService.find(filter, page);
    }

    @del('/consult-glitches/{id}', {
        security: OPERATION_SECURITY_SPEC,
        responses: {
            '204': {
                description: 'ConsultGlitches DELETE success',
            },
        },
    })
    @authenticate('jwt')
    async deleteById(@param.path.string('id') id: string): Promise<void> {
        return this.consultGlitchesService.deleteById(id);
    }

    @get('/consult-glitches/{id}', {
        security: OPERATION_SECURITY_SPEC,
        responses: {
            '200': {
                description: 'ConsultGlitches model instance',
                content: {
                    'application/json': {
                        schema: getModelSchemaRef(Glitches, {includeRelations: true}),
                    },
                },
            },
        },
    })
    @authenticate('jwt')
    async findById(
        @param.path.string('id') id: string,
    ): Promise<any> {
        return this.consultGlitchesService.findById(id);
    }

    @patch('/consult-glitches/{id}', {
        security: OPERATION_SECURITY_SPEC,
        responses: {
            '204': {
                description: 'ConsultGlitches PATCH success',
            },
        },
    })
    @authenticate('jwt')
    async updateById(
        @param.path.string('id') id: string,
        @requestBody({
            content: {
                'application/json': {
                    schema: getModelSchemaRef(Glitches, {
                        partial: true,
                        exclude: ['id'],
                    }),
                },
            },
        })
        glitches: Glitches,
    ): Promise<void> {
        return this.consultGlitchesService.updateById(id, glitches);
    }
}
