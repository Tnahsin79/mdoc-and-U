import {Filter, repository} from '@loopback/repository';
import {
  post,
  param,
  get,
  getFilterSchemaFor,
  getModelSchemaRef,
  requestBody,
  patch,
  put,
  del,
} from '@loopback/rest';
import {
  Benefits,
  ChangeStages,
  CoachPrograms,
  CoachProgramsWithRelations,
  PlansBenefit,
  ProgramPlans,
  ProgramPlansWithRelations,
  Programs,
  ProgramsWithRelations,
} from '../models';
import {ProgramsRepository} from '../repositories';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';
import {authenticate} from '@loopback/authentication';
import {ProgramsServiceBindings} from '../keys';
import {ProgramsService} from '../services/programs.service';
import {inject} from '@loopback/core';

export class ProgramsController {
  constructor(
    @repository(ProgramsRepository)
    public programsRepository: ProgramsRepository,
    @inject(ProgramsServiceBindings.PROGRAMS_SERVICE)
    public programsService: ProgramsService,
  ) {}

  @post('/programs', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'Created a new Program',
      },
    },
  })
  @authenticate('jwt')
  async createNewProgram(
    @requestBody({
      content: {
        'application/json': {},
      },
    })
    payload: any,
  ): Promise<{
    planBenefits: PlansBenefit[];
    plans: ProgramPlans[];
    program: Programs;
    benefits: Benefits[];
  }> {
    return this.programsService.createNewProgram(payload);
  }

  @get('/programs', {
    responses: {
      '200': {
        description: 'Array of Programs model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(Programs, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  async find(
    @param.query.object('filter', getFilterSchemaFor(Programs))
    filter: Filter<Programs> = {},
  ): Promise<ProgramsWithRelations[]> {
    return this.programsService.find(filter);
  }

  @get('/programs/{id}/coaches', {
    responses: {
      '200': {
        description: 'Array of CoachProgram model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(CoachPrograms, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  async getCoaches(
    @param.path.string('id') id,
  ): Promise<CoachProgramsWithRelations[]> {
    return this.programsService.getCoaches(id);
  }

  @get('/programs/coach-programs', {
    responses: {
      '200': {
        description: 'Array of CoachProgram model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(CoachPrograms, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  async getCoachProgramsCollection(
    @param.query.object('filter', getFilterSchemaFor(CoachPrograms))
    filter: Filter<CoachPrograms> = {},
    @param.query.boolean('includeRelations') includeRelations?: boolean,
  ): Promise<CoachProgramsWithRelations[]> {
    return this.programsService.getCoachProgramsCollection(
      filter,
      includeRelations,
    );
  }

  @get('/programs/{id}', {
    // security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Programs model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Programs, {includeRelations: true}),
          },
        },
      },
    },
  })
  // @authenticate('jwt')
  async getProgramById(
    @param.path.string('id')
    id: string,
  ): Promise<ProgramsWithRelations> {
    return this.programsService.getProgramById(id);
  }

  @patch('/programs/change-stages/{programId}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'ChangeStages model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(ChangeStages, {includeRelations: false}),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async updateStagesOfChange(
    @param.path.string('programId')
    programId: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(ChangeStages, {partial: true}),
        },
      },
    })
    updates: ChangeStages,
  ): Promise<ChangeStages | void> {
    return this.programsService.updateStagesOfChange(programId, updates);
  }

  @get('/programs/getProgramForUpdate', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Programs model instance',
        content: {
          'application/json': {
            schema: {
              type: 'object',
              properties: {
                plans: {
                  type: 'array',
                  items: getModelSchemaRef(ProgramPlans, {
                    includeRelations: false,
                  }),
                },
                benefits: {
                  type: 'array',
                  items: getModelSchemaRef(Benefits, {
                    includeRelations: false,
                  }),
                },
                program: getModelSchemaRef(Programs, {
                  includeRelations: false,
                }),
              },
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async getProgramForUpdate(
    @param.query.string('programId')
    programId: string,
  ): Promise<any> {
    return this.programsService.getProgramForUpdate(programId);
  }

  @patch('/programs/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      204: {
        description: 'Update successful',
        content: {},
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Programs, {partial: true}),
        },
      },
    })
    program: Partial<Programs>,
    @param.path.string('id') id: string,
  ): Promise<void> {
    return this.programsService.updateById(id, program);
  }

  @patch('/programs/coach/{coachProgramId}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      204: {
        description: 'Update successful',
        content: {},
      },
    },
  })
  @authenticate('jwt')
  async updateCoachStatusInProgram(
    @requestBody({
      content: {
        'application/json': {
          schema: {
            type: 'object',
            properties: {
              status: {type: 'string', enum: ['active', 'inactive']},
            },
          },
        },
      },
    })
    body: {status: 'active' | 'inactive'},
    @param.path.string('coachProgramId') coachProgramId: string,
  ): Promise<void> {
    return this.programsService.updateCoachStatusInProgram({
      coachProgramId,
      status: body.status,
    });
  }

  @post('/programs/addBenefit', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Benefits model instance',
        content: {
          'application/json': {schema: getModelSchemaRef(Benefits)},
        },
      },
    },
  })
  @authenticate('jwt')
  async addBenefit(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Benefits, {
            title: 'Benefits',
            exclude: ['id'],
          }),
        },
      },
    })
    payload: Omit<Benefits, 'id'>,
  ): Promise<{benefit: Benefits; plansBenefits: PlansBenefit[]}> {
    return this.programsService.addBenefit(payload);
  }

  @put('/programs/updateBenefit', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Update successfull',
        content: {
          'application/json': {},
        },
      },
    },
  })
  @authenticate('jwt')
  async updateBenefit(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Benefits, {
            title: 'Benefits',
            exclude: ['id'],
          }),
        },
      },
    })
    payload: Benefits,
  ): Promise<any> {
    return this.programsService.updateBenefit(payload);
  }

  @del('/programs/deleteBenefit/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Deleted successfull',
        content: {
          'application/json': {},
        },
      },
    },
  })
  @authenticate('jwt')
  async deleteBenefit(@param.path.string('id') id: string): Promise<any> {
    return this.programsService.deleteBenefit(id);
  }

  @del('/programs/deletePlan/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Deleted successfull',
        content: {
          'application/json': {},
        },
      },
    },
  })
  @authenticate('jwt')
  async deletePlan(@param.path.string('id') id: string): Promise<any> {
    return this.programsService.deletePlan(id);
  }

  @patch('/programs/updatePlansBenefitValue/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      204: {
        description: 'Update successful',
        content: {},
      },
    },
  })
  @authenticate('jwt')
  async updatePlansBenefitValue(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(PlansBenefit, {partial: true}),
        },
      },
    })
    payload: Partial<PlansBenefit>,
    @param.path.string('id') id: string,
  ): Promise<void> {
    return this.programsService.updatePlansBenefitValue(id, payload);
  }

  @post('/programs/addPlan', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'ProgramPlans model instance',
        content: {
          'application/json': {schema: getModelSchemaRef(ProgramPlans)},
        },
      },
    },
  })
  @authenticate('jwt')
  async addPlan(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(ProgramPlans, {
            title: 'ProgramPlans',
            exclude: ['id'],
          }),
        },
      },
    })
    payload: Omit<ProgramPlans, 'id'>,
  ): Promise<ProgramPlansWithRelations> {
    return this.programsService.addPlan(payload);
  }

  @patch('/programs/updatePlan/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      204: {
        description: 'Update successful',
        content: {},
      },
    },
  })
  @authenticate('jwt')
  async updatePlanById(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(ProgramPlans, {partial: true}),
        },
      },
    })
    plan: Partial<ProgramPlans>,
    @param.path.string('id') id: string,
  ): Promise<void> {
    return this.programsService.updatePlanById(id, plan);
  }

  @post('/programs/updatePlansBulk', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'ProgramPlans model order bulk update',
        content: {
          'application/json': {schema: getModelSchemaRef(ProgramPlans)},
        },
      },
    },
  })
  @authenticate('jwt')
  async updatePlansBulk(
    @requestBody({
      content: {
        'application/json': {
          schema: {
            type: 'array',
            items: getModelSchemaRef(ProgramPlans, {
              includeRelations: false,
              partial: true,
            }),
          },
        },
      },
    })
    payload: Partial<ProgramPlans>[],
  ): Promise<any> {
    return this.programsService.updatePlansBulk(payload);
  }

  @post('/programs/updateBenefitsBulk', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Benefits model order bulk update',
        content: {
          'application/json': {schema: getModelSchemaRef(Benefits)},
        },
      },
    },
  })
  @authenticate('jwt')
  async updateBenefitsBulk(
    @requestBody({
      content: {
        'application/json': {
          schema: {
            type: 'array',
            items: getModelSchemaRef(Benefits, {
              includeRelations: false,
              partial: true,
            }),
          },
        },
      },
    })
    payload: Partial<Benefits>[],
  ): Promise<any> {
    return this.programsService.updateBenefitsBulk(payload);
  }

  @post('/programs/assignCoachesToProgram', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Benefits model order bulk update',
        content: {
          'application/json': {schema: getModelSchemaRef(Benefits)},
        },
      },
    },
  })
  @authenticate('jwt')
  async assignCoachesToProgram(
    @requestBody({
      content: {
        'application/json': {
          schema: {
            type: 'array',
            items: getModelSchemaRef(CoachPrograms, {
              includeRelations: false,
              partial: true,
            }),
          },
        },
      },
    })
    payload: Partial<CoachPrograms>[],
  ): Promise<any> {
    return this.programsService.assignCoachesToProgram(payload);
  }

  @post('/programs/removeCoachFromProgram', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Benefits model order bulk update',
        content: {
          'application/json': {schema: getModelSchemaRef(Benefits)},
        },
      },
    },
  })
  @authenticate('jwt')
  async removeCoachFromProgram(
    @requestBody({
      content: {
        'application/json': {
          schema: {
            type: 'object',

            properties: {
              programId: {
                type: 'string',
              },
              coachId: {
                type: 'string',
              },
            },
          },
        },
      },
    })
    payload: {
      coachId: string;
      programId: string;
    },
  ): Promise<any> {
    return this.programsService.removeCoachFromProgram(payload);
  }
}
