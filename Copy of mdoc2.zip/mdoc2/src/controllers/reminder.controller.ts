import { authenticate } from '@loopback/authentication';
import { Count, CountSchema, Filter, repository, Where, } from '@loopback/repository';
import { post, param, get, getModelSchemaRef, patch, put, del, requestBody, getFilterSchemaFor, } from '@loopback/rest';
import _ from 'lodash';
import { Reminder } from '../models';
import { ReminderRepository } from '../repositories';
import { OPERATION_SECURITY_SPEC } from '../utils/security-spec';

export class ReminderController {
  constructor(@repository(ReminderRepository) public reminderRepository: ReminderRepository,) { }

  @post('/reminders', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'Reminder model instance',
        content: { 'application/json': { schema: getModelSchemaRef(Reminder) } },
      },
    }
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Reminder, {
            title: 'NewReminder',
            exclude: ['id'],
          }),
        },
      },
    })
    reminder: Omit<Reminder, 'id'>,
  ): Promise<Reminder> {
    return this.reminderRepository.create(reminder);
  }

  // @get('/reminders/count')
  // @response(200, {
  //   description: 'Reminder model count',
  //   content: { 'application/json': { schema: CountSchema } },
  // })
  // async count(
  //   @param.where(Reminder) where?: Where<Reminder>,
  // ): Promise<Count> {
  //   return this.reminderRepository.count(where);
  // }

  @get('/reminders', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'Array of Reminder model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(Reminder, { includeRelations: true }),
            },
          },
        },
      },
    }
  })
  @authenticate('jwt')
  async find(
    @param.query.object('filter', getFilterSchemaFor(Reminder)) filter?: Filter<Reminder>,
  ): Promise<Reminder[]> {
    return this.reminderRepository.find(filter);
  }

  // @patch('/reminders')
  // @response(200, {
  //   description: 'Reminder PATCH success count',
  //   content: { 'application/json': { schema: CountSchema } },
  // })
  // async updateAll(
  //   @requestBody({
  //     content: {
  //       'application/json': {
  //         schema: getModelSchemaRef(Reminder, { partial: true }),
  //       },
  //     },
  //   })
  //   reminder: Reminder,
  //   @param.where(Reminder) where?: Where<Reminder>,
  // ): Promise<Count> {
  //   return this.reminderRepository.updateAll(reminder, where);
  // }

  @get('/reminders/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'Reminder model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Reminder, { includeRelations: true }),
          },
        },
      },
    }
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(Reminder)) filter?: Filter<Reminder>
  ): Promise<Reminder> {
    return this.reminderRepository.findById(id, filter);
  }

  @patch('/reminders/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      204: {
        description: 'Reminder PATCH success',
      },
    }
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Reminder, { partial: true }),
        },
      },
    })
    reminder: Reminder,
  ): Promise<void> {
    await this.reminderRepository.updateById(id, reminder);
  }

  // @put('/reminders/{id}')
  // @response(204, {
  //   description: 'Reminder PUT success',
  // })
  // async replaceById(
  //   @param.path.string('id') id: string,
  //   @requestBody() reminder: Reminder,
  // ): Promise<void> {
  //   await this.reminderRepository.replaceById(id, reminder);
  // }

  @del('/reminders/deleteByUserId/{userId}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      204: {
        description: 'Reminder DELETE success',
      },
    }
  })
  @authenticate('jwt')
  async deleteByUserId(
    @param.path.string('userId') userId: string
  ): Promise<void> {
    let remiders = await this.reminderRepository.find({
      where: {
        userId: userId
      }
    })

    if (remiders && remiders.length) {
      const _this = this
      _.forEach(remiders, async function (val) {
        await _this.reminderRepository.deleteById(val.id);
      })
    }
  }

  @get('/reminders/getReminderByUserId/{userId}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'Reminder model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Reminder, { includeRelations: true }),
          },
        },
      },
    }
  })
  @authenticate('jwt')
  async getReminderByUserId(
    @param.path.string('userId') userId: string,
  ): Promise<any> {
    return this.reminderRepository.findOne({
      where: {
        userId: userId
      }, order: ['created DESC']
    });
  }
}
