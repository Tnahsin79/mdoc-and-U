import {
  get,
  put,
  del,
  post,
  param,
  patch,
  requestBody,
  getModelSchemaRef,
  getWhereSchemaFor,
  getFilterSchemaFor,
} from '@loopback/rest';
import {
  AnyObject,
  Count,
  CountSchema,
  Filter,
  repository,
  Where,
} from '@loopback/repository';
import {inject} from '@loopback/core';
import {MedicationServiceBindings} from '../keys';
import {MedicationRepository} from '../repositories';
import {authenticate} from '@loopback/authentication';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';
import {Medication, MedicationPassport, Users} from '../models';
import {MedicationService} from '../services/medication.service';

export class MedicationController {
  constructor(
    @repository(MedicationRepository)
    public medicationRepository: MedicationRepository,
    @inject(MedicationServiceBindings.MEDICATION_SERVICE)
    public medicationService: MedicationService,
  ) {}

  @post('/medications', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Medication model instance',
        content: {'application/json': {schema: getModelSchemaRef(Medication)}},
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Medication, {
            title: 'NewMedication',
            exclude: ['id'],
          }),
        },
      },
    })
    medication: Omit<Medication, 'id'>,
  ): Promise<Medication> {
    return this.medicationRepository.create(medication);
  }

  @get('/medications/count', {
    responses: {
      '200': {
        description: 'Medication model count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async count(
    @param.query.object('where', getWhereSchemaFor(Medication))
    where?: Where<Medication>,
  ): Promise<Count> {
    return this.medicationRepository.count(where);
  }

  @get('/medications', {
    responses: {
      '200': {
        description: 'Array of Medication model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(Medication, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  async find(
    @param.query.object('filter', getFilterSchemaFor(Medication))
    filter?: AnyObject,
    @param.query.number('page') page?: number,
  ): Promise<Medication[] | any> {
    return this.medicationService.find(filter, page);
  }

  @patch('/medications', {
    responses: {
      '200': {
        description: 'Medication PATCH success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Medication, {partial: true}),
        },
      },
    })
    medication: Medication,
    @param.query.object('where', getWhereSchemaFor(Medication))
    where?: Where<Medication>,
  ): Promise<Count> {
    return this.medicationRepository.updateAll(medication, where);
  }

  @get('/medications/{id}', {
    responses: {
      '200': {
        description: 'Medication model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Medication, {includeRelations: true}),
          },
        },
      },
    },
  })
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(Medication))
    filter?: Filter<Medication>,
  ): Promise<Medication> {
    return this.medicationRepository.findById(id, filter);
  }

  @get('/medications/users/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of Users model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(Users, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async getMedicationUsers(
    @param.query.object('filter', getFilterSchemaFor(MedicationPassport))
    filter?: AnyObject,
    @param.query.number('page') page?: number,
    @param.path.string('id') medicationId?: string,
  ): Promise<any> {
    return this.medicationService.getUsersByMedication(
      medicationId,
      filter,
      page,
    );
  }

  @patch('/medications/{id}', {
    responses: {
      '204': {
        description: 'Medication PATCH success',
      },
    },
  })
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Medication, {partial: true}),
        },
      },
    })
    medication: Medication,
  ): Promise<void> {
    await this.medicationRepository.updateById(id, medication);
  }

  @put('/medications/{id}', {
    responses: {
      '204': {
        description: 'Medication PUT success',
      },
    },
  })
  async replaceById(
    @param.path.string('id') id: string,
    @requestBody() medication: Medication,
  ): Promise<void> {
    await this.medicationRepository.replaceById(id, medication);
  }

  @del('/medications/{id}', {
    responses: {
      '204': {
        description: 'Medication DELETE success',
      },
    },
  })
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.medicationRepository.deleteById(id);
  }
}
