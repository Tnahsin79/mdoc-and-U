import {get} from '@loopback/rest';
import {inject} from '@loopback/context';
import {DashboardStatisticsService} from '../services';
import {DashboardStatisticsServiceBindings} from '../keys';
import {DashboardStatisticsType} from '../type-schema';
import {authenticate} from '@loopback/authentication';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';

export class DashboardStatisticsController {
  constructor(
    @inject(DashboardStatisticsServiceBindings.DASHBOARD_STATISTICS_SERVICE)
    public dashboardStatistics: DashboardStatisticsService,
  ) {}

  @get('/dashboard-statistics', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Dashboard Statistics',
        content: {
          'application/json': {
            schema: {
              type: 'object',
              properties: {
                totalCoaches: {type: 'number'},
                totalMaleCoaches: {type: 'number'},
                totalFemaleCoaches: {type: 'number'},
                totalMembers: {type: 'number'},
                totalMaleMembers: {type: 'number'},
                totalFemaleMembers: {type: 'number'},
                totalSubscriptions: {type: 'number'},
                totalActiveSubscriptions: {type: 'number'},
                totalExpiredSubscriptions: {type: 'number'},
                totalPrograms: {type: 'number'},
                totalPendingPrograms: {type: 'number'},
                totalApprovedPrograms: {type: 'number'},
              },
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async getDashboardStatistics(): Promise<DashboardStatisticsType> {
    return this.dashboardStatistics.getDashboardStatistics();
  }
}
