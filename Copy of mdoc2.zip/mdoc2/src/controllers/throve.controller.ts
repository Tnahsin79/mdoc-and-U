import {
  Count,
  CountSchema,
  Filter,
  repository,
  Where,
} from '@loopback/repository';
import {
  post,
  param,
  get,
  getFilterSchemaFor,
  getModelSchemaRef,
  getWhereSchemaFor,
  patch,
  put,
  del,
  requestBody,
} from '@loopback/rest';
import {Throve} from '../models';
import {ThroveRepository} from '../repositories';
import {ThroveSerivceBindings} from '../keys';
import {ThroveService} from '../services';
import { inject } from '@loopback/context';

export class ThroveController {
  constructor(
    @repository(ThroveRepository)
    public thoveRepository : ThroveRepository,
    @inject(ThroveSerivceBindings.THROVE_SERVICE)
    public throveService: ThroveService,
  ) {}

  @post('/throve/book-appointment', {
    responses: {
      '200': {
        description: 'Throve model instance',
        content: {'application/json': {schema: getModelSchemaRef(ThroveRepository)}},
      },
    },
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Throve, {
            title: 'NewThrove',
            exclude: ['id'],
          }),
        },
      },
    })
    throve: Omit<Throve, 'id'>,
  ): Promise<Throve> {
    return this.throveService.create(throve);
  }

  @get('/throve/appointments', {
    responses: {
      '200': {
        description: 'Array of Throve model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(Throve, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  async find(
  ): Promise<Throve[]> {
    return this.throveService.find();
  }

  @get('/throve/appointments/{id}', {
    responses: {
      '200': {
        description: 'Tag model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Throve, {includeRelations: true}),
          },
        },
      },
    },
  })
  async findById(
    @param.path.string('id') id: string,
  ): Promise<Throve> {
    return this.throveService.findById(id);
  }
}
