import {
  get,
  del,
  post,
  patch,
  param,
  requestBody,
  getModelSchemaRef,
  getFilterSchemaFor,
} from '@loopback/rest';
import {BloodSugar} from '../models';
import {inject} from '@loopback/core';
import {Filter} from '@loopback/repository';
import {BloodSugarService} from '../services';
import {PaginatedResponse} from '../type-schema';
import {BloodSugarServiceBindings} from '../keys';
import {authenticate} from '@loopback/authentication';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';

export class BloodSugarController {
  constructor(
    @inject(BloodSugarServiceBindings.BLOODSUGAR_SERVICE)
    public bloodSugarService: BloodSugarService,
  ) {}

  @post('/blood-sugar', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'BloodSugar model instance',
        content: {
          'application/json': {schema: getModelSchemaRef(BloodSugar)},
        },
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(BloodSugar, {
            title: 'NewBloodSugar',
            exclude: [
              'id',
              'defaultUnit',
              'defaultAfterMeal',
              'defaultBeforeMeal',
            ],
          }),
        },
      },
    })
    bloodSugar: Omit<
      BloodSugar,
      'id, defaultAfterMeal, defaultBeforeMeal, defaultUnit'
    >,
  ): Promise<BloodSugar> {
    return this.bloodSugarService.create(bloodSugar);
  }

  @get('/blood-sugars', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of BloodSugar model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(BloodSugar, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findAll(
    @param.query.object('filter', getFilterSchemaFor(BloodSugar))
    filter?: Filter<BloodSugar>,
    @param.query.number('page') page?: number,
  ): Promise<PaginatedResponse<BloodSugar>> {
    return this.bloodSugarService.findAll(filter, page);
  }

  @get('/blood-sugar/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'BloodSugar model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(BloodSugar, {includeRelations: true}),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(BloodSugar))
    filter?: Filter<BloodSugar>,
  ) {
    return this.bloodSugarService.findById(id, filter);
  }

  @patch('/blood-sugar/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'BloodSugar PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(BloodSugar, {
            partial: true,
            exclude: [
              'id',
              'defaultUnit',
              'defaultAfterMeal',
              'defaultBeforeMeal',
              'modified_at',
            ],
          }),
        },
      },
    })
    bloodSugar: BloodSugar,
  ): Promise<void> {
    return await this.bloodSugarService.updateById(id, bloodSugar);
  }

  @del('/blood-sugar/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'BloodSugar DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    this.bloodSugarService.deleteById(id);
  }
}
