import { inject } from '@loopback/context';
import { UserLocationsRepository } from './../repositories/user-locations.repository';
import { authenticate } from '@loopback/authentication';
import { Count, CountSchema, Filter, repository, Where, AnyObject } from '@loopback/repository';
import { post, param, get, getModelSchemaRef, patch, put, del, requestBody, getFilterSchemaFor, HttpErrors, } from '@loopback/rest';
import { UserLocations } from '../models';
import { OPERATION_SECURITY_SPEC } from '../utils/security-spec';
import { UserProfile, securityId, SecurityBindings } from '@loopback/security';
import * as _ from 'lodash';
import moment from 'moment';
export class UserLocationsController {
  constructor(
    @repository(UserLocationsRepository) public userLocationsRepository: UserLocationsRepository,
  ) { }

  @post('/user-locations', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'UserLocations model instance',
        content: { 'application/json': { schema: getModelSchemaRef(UserLocations) } },
      },
    }
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(UserLocations, {
            title: 'NewUserLocations',
            exclude: ['id'],
          }),
        },
      },
    })
    userLocations: Omit<UserLocations, 'id'>,
  ): Promise<any> {
    const checkIn = await this.userLocationsRepository.findOne({
      where: {
        userId: userLocations.userId,
        checkIn: { neq: "" },
        checkOut: ""
      }
    })
    if (checkIn && checkIn.id) {
      return { status: 404, "message": "Checkout is missing!" }
      throw new HttpErrors.NotFound('Checkout is missing!');
    }
    return this.userLocationsRepository.create(userLocations);
  }

  // @get('/user-locations/count')
  // @response(200, {
  //   description: 'UserLocations model count',
  //   content: {'application/json': {schema: CountSchema}},
  // })
  // async count(
  //   @param.where(UserLocations) where?: Where<UserLocations>,
  // ): Promise<Count> {
  //   return this.userLocationsRepository.count(where);
  // }

  @get('/user-locations', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'Array of UserLocations model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(UserLocations, { includeRelations: true }),
            },
          },
        }
      }
    },
  })
  @authenticate('jwt')
  async find(
    @param.query.object('filter', getFilterSchemaFor(UserLocations)) filter?: Filter<UserLocations>,
  ): Promise<UserLocations[]> {
    return this.userLocationsRepository.find(filter);
  }

  // @patch('/user-locations')
  // @response(200, {
  //   description: 'UserLocations PATCH success count',
  //   content: {'application/json': {schema: CountSchema}},
  // })
  // async updateAll(
  //   @requestBody({
  //     content: {
  //       'application/json': {
  //         schema: getModelSchemaRef(UserLocations, {partial: true}),
  //       },
  //     },
  //   })
  //   userLocations: UserLocations,
  //   @param.where(UserLocations) where?: Where<UserLocations>,
  // ): Promise<Count> {
  //   return this.userLocationsRepository.updateAll(userLocations, where);
  // }

  // @get('/user-locations/{id}')
  // @response(200, {
  //   description: 'UserLocations model instance',
  //   content: {
  //     'application/json': {
  //       schema: getModelSchemaRef(UserLocations, {includeRelations: true}),
  //     },
  //   },
  // })
  // async findById(
  //   @param.path.string('id') id: string,
  //   @param.filter(UserLocations, {exclude: 'where'}) filter?: FilterExcludingWhere<UserLocations>
  // ): Promise<UserLocations> {
  //   return this.userLocationsRepository.findById(id, filter);
  // }

  @patch('/user-locations/{id}', {
    responses: {
      204: {
        description: 'UserLocations PATCH success',
      }
    }
  })
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(UserLocations, { partial: true }),
        },
      },
    })
    userLocations: UserLocations,
  ): Promise<void> {
    await this.userLocationsRepository.updateById(id, userLocations);
  }

  // @put('/user-locations/{id}')
  // @response(204, {
  //   description: 'UserLocations PUT success',
  // })
  // async replaceById(
  //   @param.path.string('id') id: string,
  //   @requestBody() userLocations: UserLocations,
  // ): Promise<void> {
  //   await this.userLocationsRepository.replaceById(id, userLocations);
  // }

  // @del('/user-locations/{id}')
  // @response(204, {
  //   description: 'UserLocations DELETE success',
  // })
  // async deleteById(@param.path.string('id') id: string): Promise<void> {
  //   await this.userLocationsRepository.deleteById(id);
  // }
  @get('/user-locations/getUserLocation', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'Array of UserLocations model instances',
      }
    },
  })
  @authenticate('jwt')
  async getUserLocaltion(
    @inject(SecurityBindings.USER) currentUser: UserProfile,

  ): Promise<any> {
    let responseData: Array<any> = []
    let userLocations = await this.userLocationsRepository.find({
      where: {
        userId: currentUser[securityId]
      }
    })
    const checkIn = await this.userLocationsRepository.findOne({
      where: {
        userId: currentUser[securityId],
        checkIn: { neq: "" },
        checkOut: ""
      }
    })


    if (userLocations && userLocations.length) {
      let userGroup = userLocations && userLocations.length && _.groupBy(userLocations, w => moment(w.created).format('YYYY-MM-DD'))
      let dates = _.map(userLocations, w => moment(w.created).format('YYYY-MM-DD'))
      dates = _.uniq(dates)
      _.forEach(dates, function (val: any) {
        let date = userGroup && userGroup[val].length && userGroup[val][0].created
        let obj: AnyObject = {
          date: moment(date).format('YYYY-MM-DD'),
          data: userGroup && userGroup[val].length && userGroup[val] || []
        }
        responseData.push(obj)
      })
      return responseData
    } else {
      return []
    }
  }

  @get('/user-locations/getUserCheckInStatus', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'Object of UserLocations model instances',
      }
    },
  })
  @authenticate('jwt')
  async getUserCheckInStatus(
    @inject(SecurityBindings.USER) currentUser: UserProfile,

  ): Promise<any> {
    const checkIn = await this.userLocationsRepository.findOne({
      where: {
        userId: currentUser[securityId],
        checkIn: { neq: "" },
        checkOut: ""
      }
    })


    if (checkIn && checkIn.id) {
      return checkIn
    } else {
      return {}
    }
  }

}
