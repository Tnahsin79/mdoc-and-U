import {
  get,
  del,
  post,
  param,
  patch,
  requestBody,
  getModelSchemaRef,
  getFilterSchemaFor,
} from '@loopback/rest';
import {Hbaic} from '../models';
import {inject} from '@loopback/core';
import {HbaicService} from '../services';
import {Filter} from '@loopback/repository';
import {HbaicServiceBindings} from '../keys';
import {PaginatedResponse} from '../type-schema';
import {authenticate} from '@loopback/authentication';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';
export class HbaicController {
  constructor(
    @inject(HbaicServiceBindings.HBAIC_SERVICE)
    public hbaicService: HbaicService,
  ) {}

  @post('/hbaic', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Hbaic model instance',
        content: {
          'application/json': {schema: getModelSchemaRef(Hbaic)},
        },
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Hbaic, {
            title: 'NewHbaic',
            exclude: ['id'],
          }),
        },
      },
    })
    hbaic: Omit<Hbaic, 'id'>,
  ): Promise<Hbaic> {
    return this.hbaicService.create(hbaic);
  }

  @get('/hbaic', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of Hbaic model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(Hbaic, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findAll(
    @param.query.object('filter', getFilterSchemaFor(Hbaic))
    filter?: Filter<Hbaic>,
    @param.query.number('page') page?: number,
  ): Promise<PaginatedResponse<Hbaic>> {
    return this.hbaicService.findAll(filter, page);
  }

  @get('/hbaic/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Hbaic model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Hbaic, {includeRelations: true}),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(Hbaic))
    filter?: Filter<Hbaic>,
  ) {
    return this.hbaicService.findById(id, filter);
  }

  @patch('/hbaic/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Hbaic PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Hbaic, {partial: true}),
        },
      },
    })
    hbaic: Hbaic,
  ): Promise<void> {
    return await this.hbaicService.updateById(id, hbaic);
  }

  @del('/hbaic/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Hbaic DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    this.hbaicService.deleteById(id);
  }
}
