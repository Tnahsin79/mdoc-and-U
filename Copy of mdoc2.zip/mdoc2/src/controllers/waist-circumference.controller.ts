import {
  get,
  del,
  post,
  param,
  patch,
  requestBody,
  getModelSchemaRef,
  getFilterSchemaFor,
} from '@loopback/rest';
import {inject} from '@loopback/core';
import {Filter} from '@loopback/repository';
import {WaistCircumference} from '../models';
import {PaginatedResponse} from '../type-schema';
import {WaistCircumferenceService} from '../services';
import {WaistCirumferenceServiceBindings} from '../keys';
import {authenticate} from '@loopback/authentication';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';

export class WaistCircumferenceController {
  constructor(
    @inject(WaistCirumferenceServiceBindings.WAISTCIRCUMGERENCE_SERVICE)
    public waistCircumferenceService: WaistCircumferenceService,
  ) {}

  @post('/waist-circumference', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'WaistCircumference model instance',
        content: {
          'application/json': {schema: getModelSchemaRef(WaistCircumference)},
        },
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(WaistCircumference, {
            title: 'NewWaistCircumference',
            exclude: ['id', 'defaultValue', 'defaultUnit'],
          }),
        },
      },
    })
    waistCircumference: Omit<
      WaistCircumference,
      'id, defaultValue, defaultUnit'
    >,
  ): Promise<WaistCircumference> {
    return this.waistCircumferenceService.create(waistCircumference);
  }

  @get('/waist-circumference', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of WaistCircumference model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(WaistCircumference, {
                includeRelations: true,
              }),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findAll(
    @param.query.object('filter', getFilterSchemaFor(WaistCircumference))
    filter?: Filter<WaistCircumference>,
    @param.query.number('page') page?: number,
  ): Promise<PaginatedResponse<WaistCircumference>> {
    return this.waistCircumferenceService.findAll(filter, page);
  }

  @get('/waist-circumference/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'WaistCircumference model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(WaistCircumference, {
              includeRelations: true,
            }),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(WaistCircumference))
    filter?: Filter<WaistCircumference>,
  ) {
    return this.waistCircumferenceService.findById(id, filter);
  }

  @patch('/waist-circumference/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'WaistCircumference PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(WaistCircumference, {
            partial: true,
            exclude: ['id', 'defaultValue', 'defaultUnit'],
          }),
        },
      },
    })
    waistCircumference: WaistCircumference,
  ): Promise<void> {
    return await this.waistCircumferenceService.updateById(
      id,
      waistCircumference,
    );
  }

  @del('/waist-circumference/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'WaistCircumference DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    this.waistCircumferenceService.deleteById(id);
  }
}
