import {
  get,
  del,
  post,
  param,
  patch,
  requestBody,
  getModelSchemaRef,
  getFilterSchemaFor,
} from '@loopback/rest';
import Utils from '../utils';
import {Goal} from '../models';
import {inject} from '@loopback/core';
import {GoalService} from '../services';
import {Filter} from '@loopback/repository';
import {GoalServiceBindings} from '../keys';
import {PaginatedResponse} from '../type-schema';
import {authenticate} from '@loopback/authentication';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';

export class GoalController {
  constructor(
    @inject(GoalServiceBindings.GOAL_SERVICE)
    public goalService: GoalService,
  ) {}

  @post('/goals', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'Goal model instance',
        content: {'application/json': {schema: getModelSchemaRef(Goal)}},
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Goal, {
            title: 'NewGoal',
            exclude: ['id'],
          }),
        },
      },
    })
    goal: Omit<Goal, 'id'>,
  ): Promise<Goal> {
    return this.goalService.create(goal);
  }

  @get('/goals', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'Array of Goal model instances',
        content: {
          'application/json': {
            schema: Utils.paginatedSchema(Goal, true),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async find(
    @param.query.object('filter') filter?: Filter<Goal>,
    @param.query.number('page') page?: number,
  ): Promise<PaginatedResponse<Goal>> {
    return this.goalService.find(filter, page);
  }

  @get('/goals/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'Goal model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Goal, {includeRelations: true}),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(Goal))
    filter?: Filter<Goal>,
  ): Promise<Goal> {
    return this.goalService.findById(id, filter);
  }

  @patch('/goals/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      204: {
        description: 'Goal PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Goal, {
            partial: true,
            exclude: ['id', 'created_at'],
          }),
        },
      },
    })
    goal: Goal,
  ): Promise<void> {
    await this.goalService.updateById(id, goal);
  }

  @del('/goals/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      204: {
        description: 'Goal DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.goalService.deleteById(id);
  }
}
