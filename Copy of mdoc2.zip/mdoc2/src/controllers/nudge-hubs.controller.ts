import { Filter } from '@loopback/repository';
import { post, param, get, getModelSchemaRef, patch, put, del, requestBody, getFilterSchemaFor } from '@loopback/rest';
import { NudgeHubs } from '../models';
import { NudgeHubsServiceBindings } from '../keys';
import { inject } from '@loopback/context';
import {UserProfile, SecurityBindings} from '@loopback/security';
import { NudgeHubsService } from '../services';
import { authenticate } from '@loopback/authentication';
import { OPERATION_SECURITY_SPEC } from '../utils/security-spec';
import Utils from '../utils';
import { PaginatedResponse } from '../type-schema';

export class NudgeHubsController {
  constructor(
    @inject(NudgeHubsServiceBindings.NUDGE_HUBS_SERVICE) public nudgeHubsService: NudgeHubsService,
  ) {}

  @post('/nudge-hubs', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'NudgeHubs model instance',
        content: { 'application/json': { schema: getModelSchemaRef(NudgeHubs) } },
      },
    }
  })
  @authenticate('jwt')
  async create(
    @inject(SecurityBindings.USER) currentUser: UserProfile,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(NudgeHubs, {
            title: 'NewNudgeHubs',
            exclude: ['id'],
          }),
        },
      },
    })
    nudgeHubs: Omit<NudgeHubs, 'id'>,
  ): Promise<NudgeHubs> {
    return this.nudgeHubsService.create(nudgeHubs, currentUser);
  }

  @get('/nudge-hubs', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'Array of NudgeHubs model instances',
        content: {
          'application/json': {
            schema: Utils.paginatedSchema(NudgeHubs, true),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async find(
    @param.query.object('filter', getFilterSchemaFor(NudgeHubs)) 
    filter?: Filter<NudgeHubs>,
    @param.query.number('page') page?: number,
  ): Promise<PaginatedResponse<NudgeHubs>> {
    return this.nudgeHubsService.find(filter, page);
  }

  @get('/nudge-hubs/{id}', {
    responses: {
      '200': {
        description: 'NudgeHubs model instance',
        content: { 'application/json': { schema: getModelSchemaRef(NudgeHubs) } },
      },
    },
  })
  async findById(@param.path.string('id') id: string): Promise<NudgeHubs> {
    return this.nudgeHubsService.findById(id);
  }

  @del('/nudge-hubs/{id}', {
    responses: {
      '204': {
        description: 'NudgeHubs DELETE success',
      },
    },
  })
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    return this.nudgeHubsService.deleteById(id);
  }

  @patch('/nudge-hubs/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'NudgeHubs PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @inject(SecurityBindings.USER) currentUser: UserProfile,
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(NudgeHubs, { partial: true }),
        },
      },
    })
    nudgeHubs: NudgeHubs,
  ): Promise<void> {
    return this.nudgeHubsService.updateById(id, nudgeHubs, currentUser);
  }
}
