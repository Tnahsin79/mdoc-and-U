import {
  Count,
  CountSchema,
  Filter,
  repository,
  Where,
  AnyObject,
} from '@loopback/repository';
import {
  post,
  param,
  get,
  getFilterSchemaFor,
  getModelSchemaRef,
  getWhereSchemaFor,
  patch,
  put,
  del,
  requestBody,
  HttpErrors,
  RestBindings,
} from '@loopback/rest';
import {Champions, MedicationPassport} from '../models';
import {
  ChampionsRepository,
  UsersRepository,
  HealthDiaryRepository,
  BasicHealthInformationRepository,
  PaymentsRepository,
  ProviderRepository,
  PharmacyRepository,
  FootExaminationRepository,
  EyeExaminationRepository,
  HealthConditionRepository,
  PregnancyRepository,
  TreatmentRepository,
  MedicationPassportRepository,
  MedicationRepository,
  HealthProcedureSurgeriesRepository,
  JournalRepository,
  HealthQuestionRepository,
  NotificationRepository,
  SymptomsRepository,
  AffordablityRepository,
  DiseaseRepository,
} from '../repositories';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';
import {authenticate} from '@loopback/authentication';
import {inject} from '@loopback/core';
import {UserProfile, securityId, SecurityBindings} from '@loopback/security';
import * as _ from 'lodash';
import {ChampionsServiceBindings, FCMServiceBindings} from '../keys';
import {FCMService} from '../services/fcm.service';
import {uniq} from 'lodash';
import {ChampionsService} from '../services/champions.service';
export class ChampionsController {
  constructor(
    @repository(ChampionsRepository)
    public championsRepository: ChampionsRepository,
    @repository(UsersRepository) public usersRepository: UsersRepository,
    @repository(HealthDiaryRepository)
    public healthDiaryRepository: HealthDiaryRepository,
    @repository(BasicHealthInformationRepository)
    public basicHealthInformationRepository: BasicHealthInformationRepository,
    @repository(PaymentsRepository)
    public paymentRepository: PaymentsRepository,
    @repository(ProviderRepository)
    public providerRepository: ProviderRepository,
    @repository(PharmacyRepository)
    public pharmacyRepository: PharmacyRepository,
    @repository(FootExaminationRepository)
    public footExaminationRepository: FootExaminationRepository,
    @repository(EyeExaminationRepository)
    public eyeExaminationRepository: EyeExaminationRepository,
    @repository(HealthConditionRepository)
    public healthConditionRepository: HealthConditionRepository,
    @repository(PregnancyRepository)
    public pregnancyRepository: PregnancyRepository,
    @repository(TreatmentRepository)
    public treatmentRepository: TreatmentRepository,
    @repository(MedicationPassportRepository)
    public medicationPassportRepository: MedicationPassportRepository,
    @repository(MedicationRepository)
    public medicationRepository: MedicationRepository,
    @repository(HealthProcedureSurgeriesRepository)
    public healthProcedureSurgeriesRepository: HealthProcedureSurgeriesRepository,
    @repository(JournalRepository) public journalRepository: JournalRepository,
    @repository(HealthQuestionRepository)
    public healthQuestionRepository: HealthQuestionRepository,
    @inject(FCMServiceBindings.FCM_SERVICE) public fcmServices: FCMService,
    @repository(NotificationRepository)
    public notificationRepository: NotificationRepository,
    @repository(SymptomsRepository)
    public symptomsRepository: SymptomsRepository,
    @repository(AffordablityRepository)
    public affordablityRepository: AffordablityRepository,
    @repository(DiseaseRepository) public diseaseRepository: DiseaseRepository,
    @inject(ChampionsServiceBindings.CHAMPIONS_SERVICE)
    public championsService: ChampionsService,
  ) {}

  @post('/champions', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Champions model instance',
        content: {'application/json': {schema: getModelSchemaRef(Champions)}},
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Champions, {
            title: 'NewChampions',
            exclude: ['id'],
          }),
        },
      },
    })
    champions: Omit<Champions, 'id'>,
  ): Promise<any> {
    const championData = await this.championsRepository.findOne({
      where: {
        championId: champions.championId,
        starId: champions.starId,
      },
    });
    if (championData && championData.id) {
      throw new HttpErrors.UnprocessableEntity('Already champion!');
    } else {
      const champion = await this.championsRepository.create(champions);
      if (champion && champion.id) {
        const championDetails = await this.championsRepository.findOne({
          where: {
            championId: champion.championId,
            starId: champion.starId,
          },
          include: [{relation: 'star'}, {relation: 'champion'}],
        });
        if (
          championDetails &&
          championDetails.champion &&
          championDetails.champion.fcmToken &&
          championDetails.champion.isPushNotification
        ) {
          var message = {
            to:
              championDetails &&
              championDetails.champion &&
              championDetails.champion.fcmToken,
            data: {
              name:
                (championDetails &&
                  championDetails.champion &&
                  championDetails.champion.name) ||
                '',
              userId:
                (championDetails &&
                  championDetails.champion &&
                  championDetails.champion.id) ||
                '',
              type: 'starLst',
              notificationObject: {starId: champion.starId},
            },
            notification: {
              title: 'Champion Request',
              body:
                championDetails &&
                championDetails.champion &&
                championDetails.champion.name + ' sent you champion request',
              priority: 'high',
              sound: 'default',
              vibrate: true,
            },
          };
          await this.fcmServices.sendNotification({message: message});
          let noti = {
            title: 'Champion Request',
            message:
              (championDetails &&
                championDetails.star &&
                championDetails.star.name + ' sent you champion request') ||
              'unknown' + ' sent you champion request',
            userId: champion.championId,
            notiObject: {starId: champion.starId},
            type: 'starLst',
          };
          await this.notificationRepository.create(noti);
          return champion;
        } else {
          let notis: AnyObject = {
            title: 'Champion Request',
            message:
              (championDetails &&
                championDetails.star &&
                championDetails.star.name + ' sent you champion request') ||
              'unknown' + ' sent you champion request',
            userId: champion.championId,
            notiObject: {starId: champion.starId},
            type: 'starLst',
          };
          await this.notificationRepository.create(notis);
          return champion;
        }
      }
    }
  }

  @get('/champions/count', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Champions model count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  @authenticate('jwt')
  async count(
    @param.query.object('where', getWhereSchemaFor(Champions))
    where?: Where<Champions>,
  ): Promise<Count> {
    return this.championsRepository.count(where);
  }

  @get('/champions', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of Champions model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(Champions, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async find(
    @param.query.object('filter', getFilterSchemaFor(Champions))
    filter?: Filter<Champions>,
  ): Promise<Champions[]> {
    return this.championsRepository.find(filter);
  }

  @patch('/champions', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Champions PATCH success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  @authenticate('jwt')
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Champions, {partial: true}),
        },
      },
    })
    champions: Champions,
    @param.query.object('where', getWhereSchemaFor(Champions))
    where?: Where<Champions>,
  ): Promise<Count> {
    return this.championsRepository.updateAll(champions, where);
  }

  @get('/champions/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Champions model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Champions, {includeRelations: true}),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(Champions))
    filter?: Filter<Champions>,
  ): Promise<Champions> {
    return this.championsRepository.findById(id, filter);
  }

  @patch('/champions/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Champions PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Champions, {partial: true}),
        },
      },
    })
    champions: Champions,
  ): Promise<void> {
    await this.championsRepository.updateById(id, champions);
    if (champions && champions.status === 1) {
      const championDetails = await this.championsRepository.findOne({
        where: {
          id: id,
        },
        include: [{relation: 'star'}, {relation: 'champion'}],
      });
      if (
        championDetails &&
        championDetails.star &&
        championDetails.star.fcmToken &&
        championDetails.star.isPushNotification
      ) {
        var message = {
          to:
            championDetails &&
            championDetails.star &&
            championDetails.star.fcmToken,
          data: {
            name:
              (championDetails &&
                championDetails.champion &&
                championDetails.champion.name) ||
              '',
            userId:
              (championDetails &&
                championDetails.champion &&
                championDetails.champion.id) ||
              '',
            type: 'championList',
            notificationObject: {
              championId: (championDetails && championDetails.championId) || '',
            },
          },
          notification: {
            title: 'Champion Request',
            body:
              championDetails &&
              championDetails.champion &&
              championDetails.champion.name + ' accept your champion request',
            priority: 'high',
            sound: 'default',
            vibrate: true,
          },
        };
        await this.fcmServices.sendNotification({message: message});
        let noti = {
          title: 'Champion Request',
          message:
            championDetails &&
            championDetails.champion &&
            championDetails.champion.name + ' accept your champion request',
          userId: championDetails.starId,
          notiObject: {
            championId: (championDetails && championDetails.championId) || '',
          },
          type: 'championList',
        };
        await this.notificationRepository.create(noti);
      } else {
        let notis: AnyObject = {
          title: 'Champion Request',
          message:
            championDetails &&
            championDetails.champion &&
            championDetails.champion.name + ' accept your champion request',
          userId: (championDetails && championDetails.starId) || '',
          notiObject: {
            championId: (championDetails && championDetails.championId) || '',
          },
          type: 'championList',
        };
        await this.notificationRepository.create(notis);
      }
    }
  }

  @put('/champions/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Champions PUT success',
      },
    },
  })
  @authenticate('jwt')
  async replaceById(
    @param.path.string('id') id: string,
    @requestBody() champions: Champions,
  ): Promise<void> {
    await this.championsRepository.replaceById(id, champions);
  }

  @del('/champions/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Champions DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.championsRepository.deleteById(id);
  }

  @get('/champions/myChampions/', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Champions  success',
      },
    },
  })
  @authenticate('jwt')
  async myChampions(
    @inject(SecurityBindings.USER) currentUser: UserProfile,
  ): Promise<any> {
    const champions = await this.championsRepository.find({
      where: {
        starId: currentUser[securityId],
      },
      order: ['created DESC'],
      include: [
        {
          relation: 'champion',
          scope: {
            fields: {
              id: true,
              name: true,
              image: true,
              city: true,
              country: true,
              phone: true,
              locationInfo: true,
            },
          },
        },
      ],
    });
    if (champions && champions.length) {
      return champions;
    } else {
      return [];
    }
  }
  @get('/champions/myStars/', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Champions  success',
      },
    },
  })
  @authenticate('jwt')
  async myStars(
    @inject(SecurityBindings.USER) currentUser: UserProfile,
  ): Promise<any> {
    const stars = await this.championsRepository.find({
      where: {
        championId: currentUser[securityId],
      },
      order: ['created DESC'],
      include: [
        {
          relation: 'star',
          scope: {
            fields: {
              id: true,
              name: true,
              image: true,
              city: true,
              country: true,
              phone: true,
              locationInfo: true,
            },
          },
        },
      ],
    });
    if (stars && stars.length) {
      return stars;
    } else {
      return [];
    }
  }

  @get('/champions/profileAutherity/', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Champions  success',
      },
    },
  })
  @authenticate('jwt')
  async profileAutherity(
    @inject(SecurityBindings.USER) currentUser: UserProfile,
    @param.query.string('starId') starId: string,
  ): Promise<any> {
    let responseData: AnyObject = {};
    let healthObject: AnyObject = {};
    let result: Array<AnyObject> = [];
    let afford: AnyObject = {};

    const profileDetails = await this.championsRepository.findOne({
      where: {
        championId: currentUser[securityId],
        starId: starId,
        status: 1,
      },
      include: [
        {
          relation: 'star',
          scope: {
            fields: {
              id: true,
              name: true,
              image: true,
              city: true,
              country: true,
              phone: true,
              locationInfo: true,
            },
          },
        },
      ],
    });
    if (
      profileDetails &&
      profileDetails.profileAutherity &&
      profileDetails.profileAutherity.length
    ) {
      responseData = Object.assign({}, profileDetails);
      responseData = JSON.parse(JSON.stringify(responseData));
      return Promise.all([
        this.usersRepository.findOne({
          where: {
            id: starId,
          },
        }),
        this.healthProcedureSurgeriesRepository.find({
          where: {
            userId: starId,
          },
          order: ['created DESC'],
          include: [{relation: 'surgeryProcedure'}],
        }),
        this.medicationPassportRepository.find({
          where: {
            userId: starId,
          },
          order: ['created DESC'],
          include: [{relation: 'medicine'}],
        }),
        this.eyeExaminationRepository.find({
          where: {
            userId: starId,
          },
          order: ['created DESC'],
        }),
        this.healthConditionRepository.find({
          where: {
            userId: starId,
          },
          include: [{relation: 'disease'}],
          order: ['created DESC'],
        }),
        this.treatmentRepository.find({
          where: {
            userId: starId,
          },
          order: ['created DESC'],
        }),
        this.pharmacyRepository.find({
          where: {
            userId: starId,
          },
          order: ['created DESC'],
        }),
        this.footExaminationRepository.find({
          where: {
            userId: starId,
          },
          order: ['created DESC'],
        }),
        this.providerRepository.find({
          where: {
            userId: starId,
          },
          order: ['created DESC'],
        }),
        this.pregnancyRepository.findOne({
          where: {
            userId: starId,
            type: 'current',
          },
          order: ['created DESC'],
        }),
      ])
        .then(async res => {
          const journalData = await this.journalRepository.find({
            where: {
              userId: starId,
            },
            include: [
              {
                relation: 'user',
                scope: {
                  fields: {
                    id: true,
                    firstName: true,
                    lastName: true,
                    name: true,
                    image: true,
                    city: true,
                    country: true,
                    phone: true,
                  },
                },
              },
            ],
            order: ['created DESC'],
          });

          const healthDiary = await this.healthDiaryRepository.find({
            where: {
              userId: starId,
            },
            order: ['created DESC'],
          });

          const basicHealth = await this.basicHealthInformationRepository.findOne(
            {
              where: {
                userId: starId,
              },
              order: ['created DESC'],
            },
          );

          const symptoms = []

          const affordablity: any = await this.affordablityRepository.findOne({
            where: {
              userId: starId,
            },
            order: ['created DESC'],
          });

          if (affordablity && affordablity.id) {
            afford = Object.assign({}, affordablity);
            const disease = await this.diseaseRepository.find({
              where: {
                id: {inq: affordablity.diseaseId},
              },
              fields: {id: true, name: true},
            });
            afford.diseases = (disease && disease.length && disease) || [];
          }

          if (basicHealth && basicHealth.id) {
            const questions = await this.healthQuestionRepository.find({
              where: {
                id: {inq: basicHealth.questionId},
              },
            });

            let questionArray: Array<any> =
              (basicHealth && basicHealth.questionId) || [];
            let answerArray: Array<any> =
              (basicHealth && basicHealth.answer) || [];

            _.forEach(questions, function(val: any, index) {
              let obj = Object.assign({});
              if (String(val.id) === String(questionArray[index])) {
                obj.question = (val && val.question) || '';
                obj.id = (val && val.id) || '';
                obj.userId = (basicHealth && basicHealth.userId) || '';
                obj.created = (basicHealth && basicHealth.created) || '';
                obj.answer = (answerArray && answerArray[index]) || '';
                result.push(obj);
              }
            });
          }
          // if (healthDiary && healthDiary.length) {
          let types = _.map(healthDiary, function(val: any) {
            return (val && val.type != undefined && val.type) || '';
          });
          let healthType = _.uniq(types);

          healthType = _.filter(healthType, function(vl: any) {
            return vl != '';
          });
          const healthData =
            healthDiary &&
            healthDiary &&
            healthDiary.length &&
            _.groupBy(healthDiary, v => v.type);

          // }
          _.forEach(healthType, function(vl: any) {
            healthObject[vl] = _.cloneDeep(
              (healthData && healthData[vl].length && healthData[vl]) || [],
            );
          });
          _.forEach(
            profileDetails && profileDetails.profileAutherity,
            async function(val: any) {
              if (val === 'personalProfile') {
                responseData[val] = (res && res[0]) || {};
              }
              if (val === 'healthDiary') {
                responseData[val] = _.cloneDeep(healthObject);
              }
              if (val === 'healthPassport') {
                responseData[val] = {
                  medicalProcedures:
                    (res && res[1] && res[1].length && res[1]) || [],
                  medication: (res && res[2] && res[2].length && res[2]) || [],
                  eyeExam: (res && res[3] && res[3].length && res[3]) || [],
                  healthCondition:
                    (res && res[4] && res[4].length && res[4]) || [],
                  treatment: (res && res[5] && res[5].length && res[5]) || [],
                  myPharmacy: (res && res[6] && res[6].length && res[6]) || [],
                  footExam: (res && res[7] && res[7].length && res[7]) || [],
                  myProviers: (res && res[8] && res[8].length && res[8]) || [],
                  pregnancy: (res && res[9] && res[9]) || {},
                };
              }

              if (val === 'journals') {
                responseData[val] =
                  (journalData && journalData.length && journalData) || [];
              }
              if (val === 'basicHealthInformation') {
                responseData[val] = (result && result.length && result) || [];
              }
              if (val === 'symptomTracker') {
                responseData[val] =
                  (symptoms && symptoms.length && symptoms) || [];
              }
              if (val === 'affordability') {
                responseData[val] = (afford && afford.id && afford) || [];
              }
            },
          );

          return responseData;
        })
        .catch(err => {
          console.log(err, '-------------------');
          throw new HttpErrors.UnprocessableEntity('Something went wrong!');
        });
    } else {
      return null;
    }
  }
  @post('/champions/getChampionList', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Category Response success',
      },
    },
  })
  @authenticate('jwt')
  async getChampionList(@requestBody() data: any): Promise<any> {
    let query: AnyObject = {and: []};
    let anyQuery: AnyObject = {};
    let responseData: Array<AnyObject> = [];
    query.and.push({
      status: {inq: [0, 1]},
    });
    if (data && data.name) {
      anyQuery.name = new RegExp('.*' + data.name + '.*', 'i');

      const user = await this.usersRepository.find({
        where: anyQuery,
      });
      // if (user && user.length) {
      let champId: Array<any> = _.map(user, v => v.id);
      query.and.push({
        championId: {inq: champId},
      });
      // }
    }

    const champion = await this.championsRepository.find({
      where: query,
      include: [{relation: 'champion'}, {relation: 'star'}],
    });
    if (champion && champion.length) {
      let ids: Array<any> = _.map(champion, v => v.championId);

      return Promise.all([
        this.championsRepository.find({
          where: {
            championId: {inq: ids},
          },
          include: [{relation: 'champion'}, {relation: 'star'}],
        }),
      ])
        .then(res => {
          let star =
            res &&
            res[0] &&
            res[0].length &&
            _.groupBy(res[0], v => v.championId);

          _.forEach(champion, function(val: any) {
            let obj = Object.assign({}, val);
            obj.stars =
              (star && star[val.championId] && star[val.championId].length) ||
              0;
            responseData.push(obj);
          });
          return responseData;
        })
        .catch(err => {
          return err;
        });
    } else {
      throw new HttpErrors.NotFound('Champion not found!');
    }
  }
}
