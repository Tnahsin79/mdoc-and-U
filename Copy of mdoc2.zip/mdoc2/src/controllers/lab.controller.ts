import {
  get,
  put,
  del,
  post,
  patch,
  param,
  requestBody,
  getModelSchemaRef,
  getWhereSchemaFor,
  getFilterSchemaFor,
} from '@loopback/rest';
import {
  Count,
  Where,
  Filter,
  repository,
  CountSchema,
} from '@loopback/repository';
import {Lab} from '../models';
import {activityTypeObj} from '../type-schema';
import {authenticate} from '@loopback/authentication';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';
import {ActivityTimelineRepository, LabRepository} from '../repositories';

export class LabController {
  constructor(
    @repository(LabRepository) public labRepository: LabRepository,
    @repository(ActivityTimelineRepository)
    public activityTimelineRepository: ActivityTimelineRepository,
  ) {}

  @post('/labs', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Lab model instance',
        content: {'application/json': {schema: getModelSchemaRef(Lab)}},
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Lab, {
            title: 'NewLab',
            exclude: ['id'],
          }),
        },
      },
    })
    lab: Omit<Lab, 'id'>,
  ): Promise<Lab> {
    const data = await this.labRepository.create(lab);
    await this.activityTimelineRepository.create({
      activityType: activityTypeObj.LABS,
      userId: data.userId,
      metadata: data.id,
    });
    return data;
  }

  @get('/labs/count', {
    responses: {
      '200': {
        description: 'Lab model count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async count(
    @param.query.object('where', getWhereSchemaFor(Lab)) where?: Where<Lab>,
  ): Promise<Count> {
    return this.labRepository.count(where);
  }

  @get('/labs', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of Lab model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(Lab, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async find(
    @param.query.object('filter', getFilterSchemaFor(Lab)) filter?: Filter<Lab>,
  ): Promise<Lab[]> {
    return this.labRepository.find(filter);
  }

  @patch('/labs', {
    responses: {
      '200': {
        description: 'Lab PATCH success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Lab, {partial: true}),
        },
      },
    })
    lab: Lab,
    @param.query.object('where', getWhereSchemaFor(Lab)) where?: Where<Lab>,
  ): Promise<Count> {
    return this.labRepository.updateAll(lab, where);
  }

  @get('/labs/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Lab model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Lab, {includeRelations: true}),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(Lab)) filter?: Filter<Lab>,
  ): Promise<Lab> {
    return this.labRepository.findById(id, filter);
  }

  @patch('/labs/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Lab PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Lab, {partial: true}),
        },
      },
    })
    lab: Lab,
  ): Promise<void> {
    await this.labRepository.updateById(id, lab);
  }

  @put('/labs/{id}', {
    responses: {
      '204': {
        description: 'Lab PUT success',
      },
    },
  })
  async replaceById(
    @param.path.string('id') id: string,
    @requestBody() lab: Lab,
  ): Promise<void> {
    await this.labRepository.replaceById(id, lab);
  }

  @del('/labs/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Lab DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.labRepository.deleteById(id);
  }
}
