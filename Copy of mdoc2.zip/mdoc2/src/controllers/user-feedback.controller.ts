import {
  get,
  post,
  param,
  requestBody,
  getModelSchemaRef,
  getFilterSchemaFor,
} from '@loopback/rest';
import {inject} from '@loopback/core';
import {Filter} from '@loopback/repository';
import {UserFeedbackService} from '../services';
import {PaginatedResponse} from '../type-schema';
import {UserFeedbackServiceBindings} from '../keys';
import {authenticate} from '@loopback/authentication';
import {UserFeedback, UserFeedbackAnswer} from '../models';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';

export class UserFeedbackController {
  constructor(
    @inject(UserFeedbackServiceBindings.USER_FEEDBACK_SERVICE)
    public userFeedbackService: UserFeedbackService,
  ) {}

  @post('/userFeedback', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description:
          'Array of UserFeedbackAnswer excluding id and userFeedbackId',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(UserFeedbackAnswer, {
                title: 'NewUserFeedback',
                exclude: ['id', 'userFeedbackId'],
              }),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: {
            type: 'array',
            items: getModelSchemaRef(UserFeedbackAnswer, {
              title: 'NewUserFeedback',
              exclude: ['id', 'userFeedbackId'],
            }),
          },
        },
      },
    })
    userFeedbackAnswers: Omit<UserFeedbackAnswer, 'id, feedbackId'>[],
    @param.query.string('userId') userId: string,
    @param.query.string('feedbackId') feedbackId: string,
  ): Promise<UserFeedback> {
    return this.userFeedbackService.create(
      userFeedbackAnswers,
      feedbackId,
      userId,
    );
  }

  @get('/userFeedback', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of UserFeedback model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(UserFeedback, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findAll(
    @param.query.object('filter', getFilterSchemaFor(UserFeedback))
    filter?: Filter<UserFeedback>,
    @param.query.number('page') page?: number,
  ): Promise<PaginatedResponse<UserFeedback>> {
    return this.userFeedbackService.findAll(filter, page);
  }

  @get('/userFeedback/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'UserFeedback model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(UserFeedback, {includeRelations: true}),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(UserFeedback))
    filter?: Filter<UserFeedback>,
  ) {
    return this.userFeedbackService.findById(id, filter);
  }
}
