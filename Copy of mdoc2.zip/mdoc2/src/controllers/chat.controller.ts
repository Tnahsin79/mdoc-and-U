import {
  get,
  post,
  param,
  patch,
  Request,
  Response,
  requestBody,
  RestBindings,
  getModelSchemaRef,
  getFilterSchemaFor,
} from '@loopback/rest';
import Utils from '../utils';
import {
  ChatRepository,
  UsersRepository,
  CoachRepository,
  ChatRoomRepository,
  SpecialityRepository,
} from '../repositories';
import * as _ from 'lodash';
import {inject} from '@loopback/core';
import {ChatServiceBindings} from '../keys';
import {Chat, ChatWithRelations} from '../models';
import {ChatService} from '../services/chat.service';
import {authenticate} from '@loopback/authentication';
import {Filter, repository} from '@loopback/repository';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';
import {PaginatedResponse, SenderTypeEnum} from '../type-schema';
import {BlockedUsersRepository} from '../repositories/blocked-users.repository';
import {HealthDiaryRepository} from './../repositories/health-diary.repository';
export class ChatController {
  constructor(
    @repository(ChatRepository) public chatRepository: ChatRepository,
    @repository(UsersRepository) public usersRepository: UsersRepository,
    @repository(ChatRoomRepository)
    public chatRoomRepository: ChatRoomRepository,
    @repository(CoachRepository) public coachRepository: CoachRepository,
    @repository(HealthDiaryRepository)
    public healthDiaryRepository: HealthDiaryRepository,
    @repository(BlockedUsersRepository)
    public blockedUsersRepository: BlockedUsersRepository,
    @repository(SpecialityRepository)
    public specialityRepository: SpecialityRepository,
    @inject(ChatServiceBindings.CHAT_SERVICE) public chatService: ChatService,
  ) {}

  @post('/chats', {
    responses: {
      '200': {
        description: 'Chat model instance',
        content: {'application/json': {schema: getModelSchemaRef(Chat)}},
      },
    },
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Chat, {
            title: 'NewChat',
            exclude: ['id'],
          }),
        },
      },
    })
    chat: Omit<Chat, 'id'>,
  ): Promise<Chat> {
    return this.chatService.create(chat);
  }

  @get('/chats', {
    responses: {
      '200': {
        description: 'Array of Chat model instances',
        content: {
          'application/json': {
            schema: Utils.paginatedSchema(Chat, true),
          },
        },
      },
    },
  })
  async find(
    @param.query.object('filter', getFilterSchemaFor(Chat))
    filter?: Filter<Chat>,
    @param.query.number('page') page?: number,
    @param.query.boolean('reverse') reverse?: boolean,
    @param.query.object('chatRoomUsers', {coachId: 'string', userId: 'string'})
    chatRoomUsers?: {coachId: string; userId: string},
  ): Promise<PaginatedResponse<ChatWithRelations>> {
    return this.chatService.find(filter, page, reverse, chatRoomUsers);
  }

  @get('/chats/{id}', {
    responses: {
      '200': {
        description: 'Chat model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Chat, {includeRelations: true}),
          },
        },
      },
    },
  })
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(Chat))
    filter?: Filter<Chat>,
  ): Promise<Chat> {
    return this.chatService.findById(id, filter);
  }

  @get('/chats/unread/{id}', {
    responses: {
      '200': {
        description: 'Get unread messages',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Chat, {includeRelations: false}),
          },
        },
      },
    },
  })
  async getUnreadMessages(
    @param.path.string('id') id: string,
    @param.query.string('senderType', {type: 'string', enum: ['coach', 'user']})
    senderType: SenderTypeEnum,
  ): Promise<Chat[]> {
    return this.chatService.getUnreadMessages(id, senderType);
  }

  @patch('/chats/{id}', {
    responses: {
      '204': {
        description: 'Chat PATCH success',
      },
    },
  })
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Chat, {partial: true}),
        },
      },
    })
    chat: Chat,
  ): Promise<void> {
    await this.chatService.updateById(id, chat);
  }

  @post('/chats-upload-file', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        content: {
          'application/json': {
            schema: {type: 'object'},
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async uploadFile(
    @requestBody({
      description: 'multipart/form-data value.',
      required: true,
      content: {
        'multipart/form-data': {
          'x-parser': 'stream',
          schema: {type: 'object'},
        },
      },
    })
    request: Request,
    @inject(RestBindings.Http.RESPONSE) response: Response,
  ): Promise<Object> {
    return await this.chatService.uploadFile(request, response);
  }

  // look into this issue
  // @get('/chats/getUnseenMessages', {
  //   security: OPERATION_SECURITY_SPEC,
  //   responses: {
  //     '200': {
  //       description: 'Chat  success',
  //     },
  //   },
  // })
  // @authenticate('jwt')
  // async getUnseenMessages(
  //   @inject(SecurityBindings.USER) currentUser: UserProfile,
  // ): Promise<any> {

  //   let roomId: Array<any> = [];
  //   roomId.push(currentUser[securityId]);

  //   const chatGroup: Array<any> = await this.chatRoomRepository.find({
  //     where: {
  //       roomIds: { inq: roomId },
  //     },
  //     order: ['created DESC'],
  //   });

  //   let unseen: Array<any> = [];
  //   unseen.push(currentUser[securityId]);

  //   const roomIds: Array<any> = _.map(chatGroup, v => v.id);
  //   const unseenMessage: any = await this.chatRepository.find({
  //     where: {
  //       chatRoomId: { inq: roomIds },
  //       seen: { nin: unseen }
  //     }, order: ['created DESC']
  //   })
  //   return unseenMessage.length;
  // }
}
// @post('/chats', {
//   responses: {
//     '200': {
//       description: 'Chat model instance',
//       content: {'application/json': {schema: getModelSchemaRef(Chat)}},
//     },
//   },
// })
// async create(
//   @requestBody({
//     content: {
//       'application/json': {
//         schema: getModelSchemaRef(Chat, {
//           title: 'NewChat',
//           exclude: ['id'],
//         }),
//       },
//     },
//   })
//   chat: Omit<Chat, 'id'>,
// ): Promise<Chat> {
//   return this.chatRepository.create(chat);
// }

// @get('/chats/count', {
//   responses: {
//     '200': {
//       description: 'Chat model count',
//       content: {'application/json': {schema: CountSchema}},
//     },
//   },
// })
// async count(
//   @param.query.object('where', getWhereSchemaFor(Chat))
//   where?: Where<Chat>,
// ): Promise<Count> {
//   return this.chatRepository.count(where);
// }

// @get('/chats', {
//   responses: {
//     '200': {
//       description: 'Array of Chat model instances',
//       content: {
//         'application/json': {
//           schema: {
//             type: 'array',
//             items: getModelSchemaRef(Chat, {includeRelations: true}),
//           },
//         },
//       },
//     },
//   },
// })
// async find(
//   @param.query.object('filter', getFilterSchemaFor(Chat))
//   filter?: Filter<Chat>,
// ): Promise<Chat[]> {
//   return this.chatRepository.find(filter);
// }

// @patch('/chats', {
//   responses: {
//     '200': {
//       description: 'Chat PATCH success count',
//       content: {'application/json': {schema: CountSchema}},
//     },
//   },
// })
// async updateAll(
//   @requestBody({
//     content: {
//       'application/json': {
//         schema: getModelSchemaRef(Chat, {partial: true}),
//       },
//     },
//   })
//   chat: Chat,
//   @param.query.object('where', getWhereSchemaFor(Chat))
//   where?: Where<Chat>,
// ): Promise<Count> {
//   return this.chatRepository.updateAll(chat, where);
// }

// @get('/chats/{id}', {
//   responses: {
//     '200': {
//       description: 'Chat model instance',
//       content: {
//         'application/json': {
//           schema: getModelSchemaRef(Chat, {includeRelations: true}),
//         },
//       },
//     },
//   },
// })
// async findById(
//   @param.path.string('id') id: string,
//   @param.query.object('filter', getFilterSchemaFor(Chat))
//   filter?: Filter<Chat>,
// ): Promise<Chat> {
//   return this.chatRepository.findById(id, filter);
// }

// @patch('/chats/{id}', {
//   responses: {
//     '204': {
//       description: 'Chat PATCH success',
//     },
//   },
// })
// async updateById(
//   @param.path.string('id') id: string,
//   @requestBody({
//     content: {
//       'application/json': {
//         schema: getModelSchemaRef(Chat, {partial: true}),
//       },
//     },
//   })
//   chat: Chat,
// ): Promise<void> {
//   await this.chatRepository.updateById(id, chat);
// }

// @put('/chats/{id}', {
//   responses: {
//     '204': {
//       description: 'Chat PUT success',
//     },
//   },
// })
// async replaceById(
//   @param.path.string('id') id: string,
//   @requestBody() chat: Chat,
// ): Promise<void> {
//   await this.chatRepository.replaceById(id, chat);
// }

// @del('/chats/{id}', {
//   security: OPERATION_SECURITY_SPEC,
//   responses: {
//     '204': {
//       description: 'Chat DELETE success',
//     },
//   },
// })
// @authenticate('jwt')
// async deleteById(@param.path.string('id') id: string): Promise<void> {
//   await this.chatRepository.deleteById(id);
// }
// @get('/chats/getChatList/{roomId}', {
//   security: OPERATION_SECURITY_SPEC,
//   responses: {
//     '200': {
//       description: 'Chat  success',
//     },
//   },
// })
// @authenticate('jwt')
// async getChatList(
//   @inject(SecurityBindings.USER) currentUser: UserProfile,
//   @param.path.string('roomId') roomId: string,
//   @param.query.number('limit') limit: number,
//   @param.query.string('pageNo') pageNo: string,
//   @param.query.number('skip') skip: number,
// ): Promise<any> {
//   let responseData: Array<AnyObject> = [];
//   let query: AnyObject = {and: []};
//   let chatRooms: Array<any> = [];

//   const chatRoom = await this.chatRoomRepository.findOne({
//     where: {
//       id: roomId,
//     },
//   });

//   if (chatRoom && chatRoom.id) {
//     return Promise.all([
//       this.usersRepository.find({
//         where: {
//           id: {inq: chatRoom.roomIds},
//         },
//         fields: {
//           name: true,
//           image: true,
//           firstName: true,
//           lastName: true,
//           id: true,
//         },
//       }),
//       this.chatRepository.find({
//         where: {
//           chatRoomId: chatRoom.id,
//         },
//         order: ['created DESC'],
//         limit: limit || 25,
//         skip: skip || 0,
//       }),
//     ])
//       .then(async res => {
//         let coach = await this.coachRepository.find({
//           where: {
//             id: {inq: chatRoom.roomIds},
//           },
//           fields: {
//             id: true,
//             name: true,
//             firstName: true,
//             lastName: true,
//             image: true,
//           },
//         });

//         let users =
//           res && res[0] && res[0].length && _.groupBy(res[0], v => v.id);
//         let coachs =
//           coach && coach && coach.length && _.groupBy(coach, v => v.id);

//         _.forEach(res[1], function(val: any, index) {
//           let obj: any = Object.assign({user: {}, sender: {}}, val);
//           obj.user =
//             (users && users[val.userId] && users[val.userId][0]) || {};
//           obj.sender =
//             (users && users[val.senderId] && users[val.senderId][0]) || {};

//           if (!isEmpty(obj.user)) {
//             let index = _.findIndex(chatRoom.roomIds, e => {
//               return String(e) == String(val.userId);
//             });
//             const detail: any = Object.assign({}, obj.user);
//             detail.color =
//               (chatRoom.colores &&
//                 chatRoom.colores.length &&
//                 chatRoom.colores[index]) ||
//               '';
//             obj.user = detail;
//           }
//           if (!isEmpty(obj.sender)) {
//             let index = _.findIndex(chatRoom.roomIds, e => {
//               return String(e) == String(val.senderId);
//             });
//             const detail: any = Object.assign({}, obj.sender);
//             detail.color =
//               (chatRoom.colores &&
//                 chatRoom.colores.length &&
//                 chatRoom.colores[index]) ||
//               '';
//             obj.sender = detail;
//           }

//           if (chatRoom && chatRoom.groupName == '') {
//             if (obj && isEmpty(obj.user)) {
//               obj.user =
//                 (coachs && coachs[val.userId] && coachs[val.userId][0]) || {};

//               if (!isEmpty(obj.user)) {
//                 let index = _.findIndex(chatRoom.roomIds, e => {
//                   return String(e) == String(val.userId);
//                 });
//                 const detail: any = Object.assign({}, obj.user);
//                 detail.color =
//                   (chatRoom.colores &&
//                     chatRoom.colores.length &&
//                     chatRoom.colores[index]) ||
//                   '';
//                 obj.user = detail;
//               }
//             }
//             if (obj && isEmpty(obj.sender)) {
//               obj.sender =
//                 (coachs && coachs[val.senderId] && coachs[val.senderId][0]) ||
//                 {};
//               if (!isEmpty(obj.sender)) {
//                 let index = _.findIndex(chatRoom.roomIds, e => {
//                   return String(e) == String(val.senderId);
//                 });
//                 const detail: any = Object.assign({}, obj.sender);
//                 detail.color =
//                   (chatRoom.colores &&
//                     chatRoom.colores.length &&
//                     chatRoom.colores[index]) ||
//                   '';
//                 obj.sender = detail;
//               }
//             }
//           } else {
//             if (obj && isEmpty(obj.user)) {
//               obj.user =
//                 (coachs && coachs[val.userId] && coachs[val.userId][0]) || {};
//               if (!isEmpty(obj.user)) {
//                 let index = _.findIndex(chatRoom.roomIds, e => {
//                   return String(e) == String(val.userId);
//                 });
//                 const detail: any = Object.assign({}, obj.user);
//                 detail.color =
//                   (chatRoom.colores &&
//                     chatRoom.colores.length &&
//                     chatRoom.colores[index]) ||
//                   '';
//                 obj.user = detail;
//               }
//             }
//           }
//           responseData.push(obj);
//         });
//         return responseData;
//       })
//       .catch(err => {
//         console.log(err);
//       });
//   } else {
//     return [];
//   }
// }

// @get('/chats/getChatUsersList/', {
//   security: OPERATION_SECURITY_SPEC,
//   responses: {
//     '200': {
//       description: 'Chat  success',
//     },
//   },
// })
// @authenticate('jwt')
// async getChatUsersList(
//   @inject(SecurityBindings.USER) currentUser: UserProfile,
//   @param.query.string('coachId') coachId?: string,
// ): Promise<any> {
// let responseData: Array<AnyObject> = [];
// let response: Array<AnyObject> = [];
// let userObject: AnyObject = {};
// let query: AnyObject = {};
// query.roomIds = {inq: [coachId || String(currentUser[securityId])]};
// let message: Array<AnyObject> = [];
// let unseenId: Array<any> = [];
// unseenId.push(currentUser[securityId]);
// const chatRoom = await this.chatRoomRepository.find({
//   where: query,
//   order: ['created DESC'],
// });
// let blockCoach = await this.blockedUsersRepository.find({
//   where: {
//     userId: coachId || currentUser[securityId],
//     blockType: 'user',
//   },
//   include: [
//     {
//       relation: 'blockUser',
//     },
//   ],
// });
// let blockedUserIds: Array<any> = _.map(blockCoach, v => v.blockedUserId);
// if (chatRoom && chatRoom.length) {
//   let roomId: Array<any> = _.map(chatRoom, v => v.id);
//   let userId: Array<any> = _.map(chatRoom, v => String(v.userId));
//   let senderId: Array<any> = _.map(chatRoom, v => String(v.senderId));
//   let userIds = userId.concat(senderId);
//   let filterIds = _.filter(userIds, function(val: any) {
//     return val !== coachId || currentUser[securityId]
//   });
//   let uniqueIds = _.uniq(filterIds);
//   return Promise.all([
//     this.chatRepository.find({
//       where: {
//         chatRoomId: {inq: roomId},
//       },
//       order: ['created DESC'],
//     }),
//     this.usersRepository.find({
//       where: {
//         assignCoachId: coachId || currentUser[securityId],
//         id: {nin: blockedUserIds},
//       },
//       fields: {
//         id: true,
//         name: true,
//         image: true,
//         assignCoachId: true,
//         isOnline: true,
//       },
//     }),
//     this.chatRepository.find({
//       where: {
//         chatRoomId: {inq: roomId},
//         seen: {nin: unseenId},
//       },
//       order: ['created DESC'],
//     }),
//   ])
//     .then(async res => {
//       let memIds: Array<any> = _.map(res[1], w => w.id);
//       let healthDiaries = await this.healthDiaryRepository.find({
//         where: {
//           userId: {inq: memIds},
//           type: 'glucose',
//         },
//       });
//       let bloodPressuries = await this.healthDiaryRepository.find({
//         where: {
//           userId: {inq: memIds},
//           type: 'bloodPressure',
//         },
//       });
//       let healthDiary =
//         healthDiaries &&
//         healthDiaries.length &&
//         _.groupBy(healthDiaries, v => v.userId);
//       let bloodPressure =
//         bloodPressuries &&
//         bloodPressuries.length &&
//         _.groupBy(bloodPressuries, w => w.userId);
//       let users =
//         res && res[1] && res[1].length && _.groupBy(res[1], v => v.id);
//       let seen =
//         res && res[2] && res[2].length && _.groupBy(res[2], v => v.userId);
//       let unSenderseen =
//         res &&
//         res[2] &&
//         res[2].length &&
//         _.groupBy(res[2], v => v.chatRoomId);
//       let chat =
//         res && res[0] && res[0].length && _.groupBy(res[0], v => v.userId);
//       let roomchat =
//         res &&
//         res[0] &&
//         res[0].length &&
//         _.groupBy(res[0], v => v.chatRoomId);
//       let userobj: any = '';
//       let respon: any = [];
//       _.forEach(res[1], function(val: any, index) {
//         let obj1 = Object.assign({}, val);
//         obj1.color = '';
//         respon.push(obj1);
//         let obj = Object.assign({}, val);
//         userobj = (users && users[val] && users[val][0]) || {};
//         obj.healthDiaries =
//           (healthDiary &&
//             healthDiary[val.id] &&
//             healthDiary[val.id].length &&
//             healthDiary[val.id][0]) ||
//           {};
//         obj.bloodPressure =
//           (bloodPressure &&
//             bloodPressure[val.id] &&
//             bloodPressure[val.id].length &&
//             bloodPressure[val.id][0]) ||
//           {};
//         if (obj && obj.bloodPressure && obj.bloodPressure.id) {
//           let pressures: any = obj.bloodPressure.bloodPressure;
//           if (
//             (pressures && Number(pressures.systolic) > 140) ||
//             Number(pressures.diastolic) > 90 ||
//             Number(pressures.systolic) < 90 ||
//             Number(pressures.diastolic) < 55
//           ) {
//             obj.condition = 'Critical Condition';
//           }
//         }
//         if (obj && obj.healthDiaries && obj.healthDiaries.id) {
//           let healthDiary: any = obj && obj.healthDiaries.glucose;
//           if (healthDiary && healthDiary.unit === 'mg/dL') {
//             if (
//               (healthDiary &&
//                 healthDiary.breakfast &&
//                 Number(healthDiary.breakfast.before) > 130) ||
//               Number(healthDiary.breakfast.after) > 130 ||
//               (healthDiary &&
//                 healthDiary.lunch &&
//                 Number(healthDiary.lunch.after) > 130) ||
//               Number(healthDiary.lunch.before) > 130 ||
//               (healthDiary &&
//                 healthDiary.dinner &&
//                 Number(healthDiary.dinner.after) > 130) ||
//               Number(healthDiary.dinner.before) > 130 ||
//               (healthDiary &&
//                 healthDiary.snacks &&
//                 Number(healthDiary.snacks.after) > 130) ||
//               Number(healthDiary.snacks.before) > 130
//             ) {
//               obj.condition = 'Critical Condition';
//             } else if (
//               (healthDiary &&
//                 healthDiary.breakfast &&
//                 Number(healthDiary.breakfast.before) < 69) ||
//               Number(healthDiary.breakfast.after) < 69 ||
//               (healthDiary &&
//                 healthDiary.lunch &&
//                 Number(healthDiary.lunch.after) < 69) ||
//               Number(healthDiary.lunch.before) < 69 ||
//               (healthDiary &&
//                 healthDiary.dinner &&
//                 Number(healthDiary.dinner.after) < 69) ||
//               Number(healthDiary.dinner.before) < 69 ||
//               (healthDiary &&
//                 healthDiary.snacks &&
//                 Number(healthDiary.snacks.after) < 69) ||
//               Number(healthDiary.snacks.before) < 69
//             ) {
//               obj.condition = 'Critical Condition';
//             }
//           } else if (healthDiary && healthDiary.unit === 'mmol/L') {
//             if (
//               (healthDiary &&
//                 healthDiary.breakfast &&
//                 Number(healthDiary.breakfast.before) < 3.8) ||
//               Number(healthDiary.breakfast.after) < 3.8 ||
//               (healthDiary &&
//                 healthDiary.lunch &&
//                 Number(healthDiary.lunch.after) < 3.8) ||
//               Number(healthDiary.lunch.before) < 3.8 ||
//               (healthDiary &&
//                 healthDiary.dinner &&
//                 Number(healthDiary.dinner.after) < 3.8) ||
//               Number(healthDiary.dinner.before) < 3.8 ||
//               (healthDiary &&
//                 healthDiary.snacks &&
//                 Number(healthDiary.snacks.after) < 3.8) ||
//               Number(healthDiary.snacks.before) < 3.8
//             ) {
//               obj.condition = 'Critical Condition';
//             } else if (
//               (healthDiary &&
//                 healthDiary.breakfast &&
//                 Number(healthDiary.breakfast.before) > 7.2) ||
//               Number(healthDiary.breakfast.after) > 7.2 ||
//               (healthDiary &&
//                 healthDiary.lunch &&
//                 Number(healthDiary.lunch.after) > 7.2) ||
//               Number(healthDiary.lunch.before) > 7.2 ||
//               (healthDiary &&
//                 healthDiary.dinner &&
//                 Number(healthDiary.dinner.after) > 7.2) ||
//               Number(healthDiary.dinner.before) > 7.2 ||
//               (healthDiary &&
//                 healthDiary.snacks &&
//                 Number(healthDiary.snacks.after) > 7.2) ||
//               Number(healthDiary.snacks.before) > 7.2
//             ) {
//               obj.condition = 'Critical Condition';
//             }
//           }
//         }
//         responseData.push({user: obj});
//       });
//       _.forEach(responseData, function(val: any, index) {
//         let obj = Object.assign({}, val.user);
//         if (obj && obj.name) {
//           let groups = _.filter(chatRoom, function(val) {
//             return val.groupName == '';
//           });
//           if (groups && groups.length > 0) {
//             obj.roomId =
//               (chat &&
//                 chat[val.user.id] &&
//                 chat[val.user.id].length &&
//                 chat[val.user.id][0]) ||
//               {};
//             if (
//               obj.roomId &&
//               obj.roomId.senderId !== '' &&
//               obj.roomId.userId !== ''
//             ) {
//               const rooms: any = _.find(groups, {id: obj.roomId});
//               if (!isEmpty(rooms)) {
//                 let index = _.findIndex(rooms.roomIds, e => {
//                   return String(e) == String(obj.id);
//                 });
//                 obj.color =
//                   (rooms.colores != undefined &&
//                     rooms.colores.length &&
//                     rooms.colores[index]) ||
//                   '';
//               }
//               obj.unSeenMessage =
//                 (unSenderseen &&
//                   unSenderseen[obj.roomId?.chatRoomId] &&
//                   unSenderseen[obj.roomId?.chatRoomId].length) ||
//                 0;
//             } else {
//               obj.unSeenMessage = 0;
//             }
//           }
//           response.push(obj);
//         }
//       });
//       let groups = _.filter(chatRoom, function(val) {
//         return val.groupName !== '';
//       });
//       _.forEach(groups, function(val: any) {
//         let obj = Object.assign({}, val);
//         obj.roomId =
//           (roomchat && roomchat[val.id] && roomchat[val.id][0]) || {};
//         obj.unSeenMessage =
//           (unSenderseen &&
//             unSenderseen[val.id] &&
//             unSenderseen[val.id].length) ||
//           0;
//         let caochList = _.filter(respon, (v: any) => {
//           return (
//             _.findIndex(val.roomIds, w => String(w) === String(v.id)) !== -1
//           );
//         });
//         caochList = _.map(caochList, function(w) {
//           let cobj = Object.assign({}, w);
//           if (val.colores !== undefined && val.colores.length) {
//             let index = _.findIndex(val.roomIds, e => {
//               return String(e) == String(w.id);
//             });
//             cobj.color =
//               (val.colores !== undefined &&
//                 val.colores.length &&
//                 val.colores[index]) ||
//               '';
//           }
//           return cobj;
//         });
//         obj.coaches = caochList;
//         response.push(obj);
//       });
//       return response;
//     })
//     .catch(err => {
//       return err;
//     });
// } else {
//   let users = await this.usersRepository.find({
//     where: {
//       assignCoachId: currentUser[securityId],
//       id: {nin: blockedUserIds},
//     },
//     fields: {
//       id: true,
//       name: true,
//       image: true,
//       assignCoachId: true,
//       isOnline: true,
//     },
//   });
//   return users;
// }
// }

// @get('/chats/getChatCoachsList/', {
//   security: OPERATION_SECURITY_SPEC,
//   responses: {
//     '200': {
//       description: 'Chat  success',
//     },
//   },
// })
// @authenticate('jwt')
// async getChatCoachsList(
//   @inject(SecurityBindings.USER) currentUser: UserProfile,
// ): Promise<any> {
//   // let responseData: Array<AnyObject> = [];
//   // let response: Array<AnyObject> = [];
//   // let query: AnyObject = {};
//   // let unseenId: Array<any> = [];
//   // unseenId.push(currentUser[securityId]);
//   // query.roomIds = {inq: [String(currentUser[securityId])]};
//   // const chatRoom = await this.chatRoomRepository.find({
//   //   where: query,
//   //   order: ['created DESC'],
//   // });
//   // let blockCoach = await this.blockedUsersRepository.find({
//   //   where: {
//   //     coachId: currentUser[securityId],
//   //     blockType: 'coach',
//   //   },
//   //   include: [
//   //     {
//   //       relation: 'blockCoach',
//   //     },
//   //   ],
//   // });
//   // let blockCoachIds: Array<any> = _.map(blockCoach, v => v.blockedcoachId);
//   // if (chatRoom && chatRoom.length) {
//   //   let roomId: Array<any> = _.map(chatRoom, v => v.id);
//   //   let userId: Array<any> = _.map(chatRoom, v => String(v.userId));
//   //   let senderId: Array<any> = _.map(chatRoom, v => String(v.senderId));
//   //   let userIds = userId.concat(senderId);
//   //   let filterIds = _.filter(userIds, function(val: any) {
//   //     return val !== currentUser[securityId];
//   //   });
//   //   return Promise.all([
//   //     this.chatRepository.find({
//   //       where: {
//   //         chatRoomId: {inq: roomId},
//   //       },
//   //       order: ['created DESC'],
//   //     }),
//   //     this.coachRepository.find({
//   //       where: {
//   //         id: {nin: blockCoachIds},
//   //       },
//   //       fields: {
//   //         id: true,
//   //         name: true,
//   //         specialities: true,
//   //         firstName: true,
//   //         lastName: true,
//   //         image: true,
//   //         isOnline: true,
//   //       },
//   //     }),
//   //     this.chatRepository.find({
//   //       where: {
//   //         chatRoomId: {inq: roomId},
//   //         seen: {nin: unseenId},
//   //       },
//   //       order: ['created DESC'],
//   //     }),
//   //   ])
//   //     .then(res => {
//   //       let unSenderseen =
//   //         res &&
//   //         res[2] &&
//   //         res[2].length &&
//   //         _.groupBy(res[2], v => v.chatRoomId);
//   //       let chat =
//   //         res && res[0] && res[0].length && _.groupBy(res[0], v => v.userId);
//   //       let roomchat =
//   //         res &&
//   //         res[0] &&
//   //         res[0].length &&
//   //         _.groupBy(res[0], v => v.chatRoomId);
//   //       _.forEach(res[1], function(val: any) {
//   //         let obj = Object.assign({}, val);
//   //         if (obj && obj.name) {
//   //           obj.roomId = (chat && chat[val.id] && chat[val.id][0]) || {};
//   //           let groups = _.filter(chatRoom, function(val) {
//   //             return val.groupName == '';
//   //           });
//   //           if (groups && groups.length > 0) {
//   //             const rooms: any = _.find(groups, {id: obj.roomId});
//   //             if (!isEmpty(rooms)) {
//   //               let index = _.findIndex(rooms.roomIds, e => {
//   //                 return String(e) == String(obj.id);
//   //               });
//   //               obj.color =
//   //                 (rooms.colores != undefined &&
//   //                   rooms.colores.length &&
//   //                   rooms.colores[index]) ||
//   //                 '';
//   //             }
//   //             obj.unSeenMessage =
//   //               (unSenderseen &&
//   //                 unSenderseen[val.chatRoomId] &&
//   //                 unSenderseen[val.chatRoomId].length) ||
//   //               0;
//   //           } else {
//   //             obj.unSeenMessage = 0;
//   //           }
//   //           response.push(obj);
//   //         }
//   //       });
//   //       let groups = _.filter(chatRoom, function(val) {
//   //         return val.groupName !== '';
//   //       });
//   //       _.forEach(groups, function(val: any) {
//   //         let obj = Object.assign({}, val);
//   //         obj.roomId =
//   //           (roomchat && roomchat[val.id] && roomchat[val.id][0]) || {};
//   //         obj.unSeenMessage =
//   //           (unSenderseen &&
//   //             unSenderseen[val.id] &&
//   //             unSenderseen[val.id].length) ||
//   //           0;
//   //         let caochList = _.filter(res[1], v => {
//   //           return (
//   //             _.findIndex(val.roomIds, w => String(w) === String(v.id)) !== -1
//   //           );
//   //         });
//   //         caochList = _.map(caochList, function(w) {
//   //           let cobj: any = Object.assign({}, w);
//   //           if (val.colores !== undefined && val.colores.length) {
//   //             let index = _.findIndex(val.roomIds, e => {
//   //               return String(e) == String(w.id);
//   //             });
//   //             cobj.color =
//   //               (val.colores !== undefined &&
//   //                 val.colores.length &&
//   //                 val.colores[index]) ||
//   //               '';
//   //           }
//   //           return cobj;
//   //         });
//   //         obj.coaches = caochList;
//   //         response.push(obj);
//   //       });
//   //       return response;
//   //     })
//   //     .catch(err => {
//   //       return err;
//   //     });
//   // } else {
//   //   let coach = await this.coachRepository.find({
//   //     where: {
//   //       id: {nin: blockCoachIds},
//   //     },
//   //     fields: {
//   //       id: true,
//   //       name: true,
//   //       specialities: true,
//   //       firstName: true,
//   //       lastName: true,
//   //       image: true,
//   //     },
//   //   });
//   //   return coach;
//   // }
// }

// @get('/chats/updateUnReadMessage/{roomId}', {
//   security: OPERATION_SECURITY_SPEC,
//   responses: {
//     '200': {
//       description: 'Chat  success',
//     },
//   },
// })
// @authenticate('jwt')
// async updateUnReadMessage(
//   @param.path.string('roomId') roomId: string,
//   @inject(SecurityBindings.USER) currentUser: UserProfile,
// ): Promise<any> {
//   let data: Array<any> = [];
//   data.push(currentUser[securityId]);
//   let messages = await this.chatRepository.find({
//     where: {
//       chatRoomId: roomId,
//       seen: {nin: data},
//     },
//   });
//   let _this = this;
//   if (messages && (await messages).length) {
//     _.forEach(messages, async function(val: any) {
//       val.seen.push(currentUser[securityId]);
//       let payload = {
//         seen: val.seen,
//       };
//       await _this.chatRepository.updateById(val.id, payload);
//     });
//     return true;
//   }
// }

// @get('/chats/countUnreadMessage/', {
//   security: OPERATION_SECURITY_SPEC,
//   responses: {
//     '200': {
//       description: 'Chat  success',
//     },
//   },
// })
// @authenticate('jwt')
// async countUnreadMessage(
//   @inject(SecurityBindings.USER) currentUser: UserProfile,
// ): Promise<any> {
//   let unseen: Array<any> = [];
//   unseen.push(currentUser[securityId]);
//   const unSeencounts = await this.chatRepository.find({
//     where: {
//       senderId: currentUser[securityId],
//       seen: {nin: unseen},
//     },
//   });
//   if (unSeencounts && unSeencounts.length) {
//     return unSeencounts.length;
//   } else {
//     return unSeencounts.length;
//   }
// }
// @get('/chats/count/{roomId}', {
//   security: OPERATION_SECURITY_SPEC,
//   responses: {
//     '200': {
//       description: 'Chat  success',
//     },
//   },
// })
// @authenticate('jwt')
// async chatCount(
//   @inject(SecurityBindings.USER) currentUser: UserProfile,
//   @param.path.string('roomId') roomId: string,
// ): Promise<any> {
//   const chatCount = await this.chatRepository.count({
//     chatRoomId: roomId,
//   });
//   return chatCount;
// }

// @get('/chats/userChatInbox', {
//   security: OPERATION_SECURITY_SPEC,
//   responses: {
//     '200': {
//       description: 'Chat  success',
//     },
//   },
// })
// @authenticate('jwt')
// async userChatInbox(
//   @inject(SecurityBindings.USER) currentUser: UserProfile,
// ): Promise<any> {
//   let response: Array<AnyObject> = [];
//   let user: any = await this.usersRepository.findOne({
//     where: {
//       id: currentUser[securityId],
//     },
//     fields: {id: true, name: true, assignCoachId: true, actionPlan: true},
//   });
//   if (!isEmpty(user)) {
//     const coach: any = await this.coachRepository.findOne({
//       where: {id: (user && user.assignCoachId) || null},
//       fields: {password: false},
//     });

//     if (!isEmpty(coach)) {
//       const specialities = await this.specialityRepository.find({
//         where: {
//           id: {inq: coach?.specialities},
//         },
//         fields: {id: true, name: true},
//       });
//       coach.specialities = specialities;
//     }
//     let roomId: Array<any> = [];
//     roomId.push(currentUser[securityId]);

//     const chatGroup: any = await this.chatRoomRepository.find({
//       where: {
//         roomIds: {inq: roomId},
//       },
//       order: ['created DESC'],
//     });

//     if (chatGroup && chatGroup.length) {
//       const roomId: Array<any> = _.map(chatGroup, w => w.id);

//       const chats: any = await this.chatRepository.find({
//         where: {
//           chatRoomId: {inq: roomId},
//         },
//         order: ['created DESC'],
//       });

//       let unseen: Array<any> = [];
//       unseen.push(currentUser[securityId]);

//       const unseenMessage: any = await this.chatRepository.find({
//         where: {
//           seen: {nin: unseen},
//         },
//         order: ['created DESC'],
//       });

//       const chatGrp =
//         chats && chats.length && _.groupBy(chats, v => v.chatRoomId);
//       const undeenChatGroup =
//         unseenMessage &&
//         unseenMessage.length &&
//         _.groupBy(unseenMessage, v => v.chatRoomId);

//       const chatGroups = _.filter(chatGroup, function(val) {
//         return val.groupName !== '';
//       });
//       const coachRoom = _.filter(chatGroup, function(val) {
//         return val.groupName == '';
//       });
//       if (coachRoom && coachRoom.length) {
//         _.forEach(coachRoom, function(val) {
//           let obj = Object.assign({}, val);
//           obj.coach = (coach && coach.id && coach) || null;
//           obj.unseen =
//             (undeenChatGroup &&
//               undeenChatGroup[val.id] &&
//               undeenChatGroup[val.id].length) ||
//             0;
//           if (obj && obj.unseen > 0) {
//             obj.lastMessage =
//               (undeenChatGroup &&
//                 undeenChatGroup[val.id] &&
//                 undeenChatGroup[val.id][0]) ||
//               {};
//           } else {
//             obj.lastMessage =
//               (chatGrp && chatGrp[val.id] && chatGrp[val.id][0]) || {};
//           }
//           response.push(obj);
//         });
//       } else {
//         if (!isEmpty(coach)) {
//           response.push({coach: coach});
//         }
//       }

//       _.forEach(chatGroups, function(val) {
//         let obj = Object.assign({}, val);
//         obj.unseen =
//           (undeenChatGroup &&
//             undeenChatGroup[val.id] &&
//             undeenChatGroup[val.id].length) ||
//           0;
//         if (obj && obj.unseen > 0) {
//           obj.lastMessage =
//             (undeenChatGroup &&
//               undeenChatGroup[val.id] &&
//               undeenChatGroup[val.id][0]) ||
//             {};
//         } else {
//           obj.lastMessage =
//             (chatGrp && chatGrp[val.id] && chatGrp[val.id][0]) || {};
//         }
//         response.push(obj);
//       });

//       let result = _.orderBy(
//         response,
//         function(e: any) {
//           return e.lastMessage?.created;
//         },
//         ['desc'],
//       );
//       return result;
//     } else {
//       if (!isEmpty(coach)) {
//         response.push({coach: coach});
//       }
//       return response;
//     }
//   } else {
//     throw new HttpErrors.NotFound('User not found');
//   }
// }

// @get('/chats/getUnseenMessages', {
//   security: OPERATION_SECURITY_SPEC,
//   responses: {
//     '200': {
//       description: 'Chat  success',
//     },
//   },
// })
// @authenticate('jwt')
// async getUnseenMessages(
//   @inject(SecurityBindings.USER) currentUser: UserProfile,
// ): Promise<any> {
//   let roomId: Array<any> = [];
//   roomId.push(currentUser[securityId]);

//   const chatGroup: Array<any> = await this.chatRoomRepository.find({
//     where: {
//       roomIds: {inq: roomId},
//     },
//     order: ['created DESC'],
//   });

//   let unseen: Array<any> = [];
//   unseen.push(currentUser[securityId]);

//   const roomIds: Array<any> = _.map(chatGroup, v => v.id);
//   const unseenMessage: any = await this.chatRepository.find({
//     where: {
//       chatRoomId: {inq: roomIds},
//       seen: {nin: unseen},
//     },
//     order: ['created DESC'],
//   });
//   return unseenMessage.length;
// }
// }
