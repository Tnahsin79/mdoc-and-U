import {
  get,
  del,
  post,
  param,
  patch,
  requestBody,
  getModelSchemaRef,
  getFilterSchemaFor,
} from '@loopback/rest';
import {inject} from '@loopback/core';
import {FeedbackService} from '../services';
import {Filter} from '@loopback/repository';
import {FeedbackServiceBindings} from '../keys';
import {Feedback, UserFeedback} from '../models';
import {PaginatedResponse} from '../type-schema';
import {authenticate} from '@loopback/authentication';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';

export class FeedbackController {
  constructor(
    @inject(FeedbackServiceBindings.FEEDBACK_SERVICE)
    public feedbackService: FeedbackService,
  ) {}

  @post('/feedback', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Feedback model instance',
        content: {
          'application/json': {schema: getModelSchemaRef(Feedback)},
        },
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Feedback, {
            title: 'NewFeedback',
            exclude: ['id'],
          }),
        },
      },
    })
    feedback: Omit<Feedback, 'id'>,
  ): Promise<Feedback> {
    return this.feedbackService.create(feedback);
  }

  @get('/feedback', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of Feedback model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(Feedback, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findAll(
    @param.query.object('filter', getFilterSchemaFor(Feedback))
    filter?: Filter<Feedback>,
    @param.query.number('page') page?: number,
  ): Promise<PaginatedResponse<Feedback>> {
    return this.feedbackService.findAll(filter, page);
  }

  @get('/feedback/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Feedback model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Feedback, {includeRelations: true}),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(Feedback))
    filter?: Filter<Feedback>,
  ) {
    return this.feedbackService.findById(id, filter);
  }

  @patch('/feedback/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Feedback PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Feedback, {partial: true}),
        },
      },
    })
    feedback: Feedback,
  ): Promise<void> {
    return await this.feedbackService.updateById(id, feedback);
  }

  @del('/feedback/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Feedback DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    this.feedbackService.deleteById(id);
  }

  @post('/contact-us', {
    responses: {
      '200': {
        description: 'UserFeedback model instance',
        content: {
          'application/json': {schema: getModelSchemaRef(UserFeedback)},
        },
      },
    },
  })
  async createContactUs(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(UserFeedback, {
            exclude: ['id'],
          }),
        },
      },
    })
    feedback: Partial<Omit<UserFeedback, 'id'>>,
  ): Promise<UserFeedback> {
    return this.feedbackService.createContactUs(feedback);
  }
}
