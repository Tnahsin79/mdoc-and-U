import { Count, CountSchema, Filter, repository, Where, AnyObject, } from '@loopback/repository';
import { post, param, get, getFilterSchemaFor, getModelSchemaRef, getWhereSchemaFor, patch, put, del, requestBody, HttpErrors } from '@loopback/rest';
import { LabsProcedures } from '../models';
import { LabsProceduresRepository } from '../repositories';
import { OPERATION_SECURITY_SPEC } from '../utils/security-spec';
import { authenticate } from '@loopback/authentication';
import moment from 'moment';
export class LabsProceduresController {
  constructor(
    @repository(LabsProceduresRepository) public labsProceduresRepository: LabsProceduresRepository,
  ) { }

  @post('/labs-procedures', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'LabsProcedures model instance',
        content: { 'application/json': { schema: getModelSchemaRef(LabsProcedures) } },
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(LabsProcedures, {
            title: 'NewLabsProcedures',
            exclude: ['id'],
          }),
        },
      },
    })
    labsProcedures: Omit<LabsProcedures, 'id'>,
  ): Promise<any> {

    let startDate = moment(labsProcedures.date).utcOffset(0);
    startDate.set({ hour: 0, minute: 0, second: 0, millisecond: 0 })
    startDate.toISOString()

    let endDate = moment(labsProcedures.date).utcOffset(0);
    endDate.set({ hour: 23, minute: 59, second: 59, millisecond: 999 })
    endDate.toISOString()

    let labsResponse: AnyObject = {}
    const existCheck = await this.labsProceduresRepository.findOne({
      where: {
        labId: labsProcedures.labId,
        userId: labsProcedures.userId,
        and: [
          { date: { gte: moment(startDate).toISOString() } },
          { date: { lte: moment(endDate).toISOString() } },
        ]
      }
    })
    if (existCheck && existCheck.id) {
      throw new HttpErrors.UnprocessableEntity('Labs procedures already exist!')
    }
    labsProcedures.isLabComplete = true
    const labsProcedure = await this.labsProceduresRepository.create(labsProcedures);
    const labsResult = await this.labsProceduresRepository.findOne({
      where: {
        id: labsProcedure.id
      },
      include: [
        { relation: "lab" }
      ]
    })
    return labsResult
  }

  @get('/labs-procedures/count', {
    responses: {
      '200': {
        description: 'LabsProcedures model count',
        content: { 'application/json': { schema: CountSchema } },
      },
    },
  })
  async count(
    @param.query.object('where', getWhereSchemaFor(LabsProcedures)) where?: Where<LabsProcedures>,
  ): Promise<Count> {
    return this.labsProceduresRepository.count(where);
  }

  @get('/labs-procedures', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of LabsProcedures model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(LabsProcedures, { includeRelations: true }),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async find(
    @param.query.object('filter', getFilterSchemaFor(LabsProcedures)) filter?: Filter<LabsProcedures>,
  ): Promise<LabsProcedures[]> {
    return this.labsProceduresRepository.find(filter);
  }

  @patch('/labs-procedures', {
    responses: {
      '200': {
        description: 'LabsProcedures PATCH success count',
        content: { 'application/json': { schema: CountSchema } },
      },
    },
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(LabsProcedures, { partial: true }),
        },
      },
    })
    labsProcedures: LabsProcedures,
    @param.query.object('where', getWhereSchemaFor(LabsProcedures)) where?: Where<LabsProcedures>,
  ): Promise<Count> {
    return this.labsProceduresRepository.updateAll(labsProcedures, where);
  }

  @get('/labs-procedures/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'LabsProcedures model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(LabsProcedures, { includeRelations: true }),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(LabsProcedures)) filter?: Filter<LabsProcedures>
  ): Promise<LabsProcedures> {
    return this.labsProceduresRepository.findById(id, filter);
  }

  @patch('/labs-procedures/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'LabsProcedures PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(LabsProcedures, { partial: true }),
        },
      },
    })
    labsProcedures: LabsProcedures,
  ): Promise<void> {
    await this.labsProceduresRepository.updateById(id, labsProcedures);
  }

  @put('/labs-procedures/{id}', {
    responses: {
      '204': {
        description: 'LabsProcedures PUT success',
      },
    },
  })
  async replaceById(
    @param.path.string('id') id: string,
    @requestBody() labsProcedures: LabsProcedures,
  ): Promise<void> {
    await this.labsProceduresRepository.replaceById(id, labsProcedures);
  }

  @del('/labs-procedures/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'LabsProcedures DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.labsProceduresRepository.deleteById(id);
  }
}
