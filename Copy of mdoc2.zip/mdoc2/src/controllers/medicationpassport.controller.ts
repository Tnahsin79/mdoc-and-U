import {
  get,
  put,
  del,
  post,
  patch,
  param,
  requestBody,
  getModelSchemaRef,
  getWhereSchemaFor,
  getFilterSchemaFor,
} from '@loopback/rest';
import {
  Count,
  Where,
  Filter,
  repository,
  CountSchema,
} from '@loopback/repository';
import {
  ActivityTimelineRepository,
  MedicationPassportRepository,
} from '../repositories';
import csv from 'csvtojson';
import {inject} from '@loopback/core';
import {MedicationPassport} from '../models';
import {activityTypeObj} from '../type-schema';
import {MigrationServiceBindings} from '../keys';
import {authenticate} from '@loopback/authentication';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';
import {MigrationService} from '../services/migration.service';
import {UserProfile, securityId, SecurityBindings} from '@loopback/security';
export class MedicationpassportController {
  constructor(
    @repository(MedicationPassportRepository)
    public medicationPassportRepository: MedicationPassportRepository,
    @repository(ActivityTimelineRepository)
    public activityTimelineRepository: ActivityTimelineRepository,
    @inject(MigrationServiceBindings.MIGRATION_SERVICE)
    public migrationService: MigrationService,
  ) {}

  @post('/medication-passports', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'MedicationPassport model instance',
        content: {
          'application/json': {schema: getModelSchemaRef(MedicationPassport)},
        },
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(MedicationPassport, {
            title: 'NewMedicationPassport',
            exclude: ['id'],
          }),
        },
      },
    })
    medicationPassport: Omit<MedicationPassport, 'id'>,
  ): Promise<any> {
    medicationPassport.isMedicationPassportComplete = true;
    const mmedications = await this.medicationPassportRepository.create(
      medicationPassport,
    );
    const medicationResult = await this.medicationPassportRepository.findOne({
      where: {
        id: mmedications.id,
      },
      include: [{relation: 'medicine'}],
    });
    await this.activityTimelineRepository.create({
      activityType: activityTypeObj.MEDICATION_PASSPORT,
      userId: mmedications.userId,
      metadata: mmedications.id,
    });
    return medicationResult;
  }

  @get('/medication-passports/count', {
    responses: {
      '200': {
        description: 'MedicationPassport model count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async count(
    @param.query.object('where', getWhereSchemaFor(MedicationPassport))
    where?: Where<MedicationPassport>,
  ): Promise<Count> {
    return this.medicationPassportRepository.count(where);
  }

  @get('/medication-passports', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of MedicationPassport model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(MedicationPassport, {
                includeRelations: true,
              }),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async find(
    @param.query.object('filter', getFilterSchemaFor(MedicationPassport))
    filter?: Filter<MedicationPassport>,
  ): Promise<MedicationPassport[]> {
    return this.medicationPassportRepository.find({
      ...(filter || {}),
      order: ['name ASC'],
      include: [{relation: 'medicine'}],
    });
  }

  @patch('/medication-passports', {
    responses: {
      '200': {
        description: 'MedicationPassport PATCH success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(MedicationPassport, {partial: true}),
        },
      },
    })
    medicationPassport: MedicationPassport,
    @param.query.object('where', getWhereSchemaFor(MedicationPassport))
    where?: Where<MedicationPassport>,
  ): Promise<Count> {
    return this.medicationPassportRepository.updateAll(
      medicationPassport,
      where,
    );
  }

  @get('/medication-passports/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'MedicationPassport model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(MedicationPassport, {
              includeRelations: true,
            }),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(MedicationPassport))
    filter?: Filter<MedicationPassport>,
  ): Promise<MedicationPassport> {
    return this.medicationPassportRepository.findById(id, filter);
  }

  @patch('/medication-passports/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'MedicationPassport PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(MedicationPassport, {partial: true}),
        },
      },
    })
    medicationPassport: MedicationPassport,
  ): Promise<void> {
    await this.medicationPassportRepository.updateById(id, medicationPassport);
  }

  @put('/medication-passports/{id}', {
    responses: {
      '204': {
        description: 'MedicationPassport PUT success',
      },
    },
  })
  async replaceById(
    @param.path.string('id') id: string,
    @requestBody() medicationPassport: MedicationPassport,
  ): Promise<void> {
    await this.medicationPassportRepository.replaceById(id, medicationPassport);
  }

  @del('/medication-passports/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'MedicationPassport DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.medicationPassportRepository.deleteById(id);
  }

  @get('/medication-passports/dashboardMedicationPassport/', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'MedicationPassport  success',
      },
    },
  })
  @authenticate('jwt')
  async dashboardMedicationPassport(
    @inject(SecurityBindings.USER) currentUser: UserProfile,
  ): Promise<any> {
    const healthCondition = await this.medicationPassportRepository.find({
      where: {
        userId: currentUser[securityId],
      },
      order: ['name ASC'],
      include: [{relation: 'medicine'}],
    });
    if (healthCondition && healthCondition.length) {
      return healthCondition;
    } else {
      return [];
    }
  }

  @get('/medicationPassportsMigration', {
    responses: {
      '200': {
        description: 'MedicationPassport  success',
      },
    },
  })
  async medicationPassportsMigration(): Promise<any> {
    const filePath = './public/medications_history.csv';
    let mediData = await csv().fromFile(filePath);
    if (mediData && mediData.length) {
      for (let value of mediData) {
        await this.migrationService.MedicationPassportsMigration(value);
      }
    }
  }
}
