import {
  AnyObject,
  Count,
  CountSchema,
  Filter,
  repository,
  Where,
} from '@loopback/repository';
import {
  post,
  param,
  get,
  getFilterSchemaFor,
  getModelSchemaRef,
  getWhereSchemaFor,
  patch,
  put,
  del,
  requestBody,
} from '@loopback/rest';
import {SymptomHealthCondition} from '../models';
import {SymptomHealthConditionRepository} from '../repositories';
import {SymptomHealthConditionServiceBindings} from '../keys';
import {inject} from '@loopback/core';
import {SymptomHealthConditionService} from '../services/symptom-health-condition.service';

export class SymptomHealthConditionController {
  constructor(
    @repository(SymptomHealthConditionRepository)
    public symptomHealthConditionRepository: SymptomHealthConditionRepository,
    @inject(
      SymptomHealthConditionServiceBindings.SYMPTOM_HEALTH_CONDITION_SERVICE,
    )
    public symptomHealthConditionService: SymptomHealthConditionService,
  ) {}

  @post('/symptom-health-conditions', {
    responses: {
      '200': {
        description: 'SymptomHealthCondition model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(SymptomHealthCondition),
          },
        },
      },
    },
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(SymptomHealthCondition, {
            title: 'NewSymptomHealthCondition',
            exclude: ['id'],
          }),
        },
      },
    })
    symptomHealthCondition: Omit<SymptomHealthCondition, 'id'>,
  ): Promise<SymptomHealthCondition> {
    return this.symptomHealthConditionService.create(symptomHealthCondition);
  }

  @get('/symptom-health-conditions/count', {
    responses: {
      '200': {
        description: 'SymptomHealthCondition model count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async count(
    @param.query.object('where', getWhereSchemaFor(SymptomHealthCondition))
    where?: Where<SymptomHealthCondition>,
  ): Promise<Count> {
    return this.symptomHealthConditionRepository.count(where);
  }

  @get('/symptom-health-conditions', {
    responses: {
      '200': {
        description: 'Array of SymptomHealthCondition model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(SymptomHealthCondition, {
                includeRelations: true,
              }),
            },
          },
        },
      },
    },
  })
  async find(
    @param.query.object('filter', getFilterSchemaFor(SymptomHealthCondition))
    filter?: AnyObject,
  ): Promise<SymptomHealthCondition[] | any> {
    return this.symptomHealthConditionRepository.find({
      where: filter?.where,
      include: [{relation: 'symptom'}, {relation: 'medication'}]
    });
  }

  @patch('/symptom-health-conditions', {
    responses: {
      '200': {
        description: 'SymptomHealthCondition PATCH success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(SymptomHealthCondition, {partial: true}),
        },
      },
    })
    symptomHealthCondition: SymptomHealthCondition,
    @param.query.object('where', getWhereSchemaFor(SymptomHealthCondition))
    where?: Where<SymptomHealthCondition>,
  ): Promise<Count> {
    return this.symptomHealthConditionRepository.updateAll(
      symptomHealthCondition,
      where,
    );
  }

  @get('/symptom-health-conditions/{id}', {
    responses: {
      '200': {
        description: 'SymptomHealthCondition model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(SymptomHealthCondition, {
              includeRelations: true,
            }),
          },
        },
      },
    },
  })
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(SymptomHealthCondition))
    filter?: Filter<SymptomHealthCondition>,
  ): Promise<SymptomHealthCondition> {
    return this.symptomHealthConditionRepository.findById(id, filter);
  }

  @patch('/symptom-health-conditions/{id}', {
    responses: {
      '204': {
        description: 'SymptomHealthCondition PATCH success',
      },
    },
  })
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(SymptomHealthCondition, {partial: true}),
        },
      },
    })
    symptomHealthCondition: SymptomHealthCondition,
  ): Promise<void> {
    await this.symptomHealthConditionRepository.updateById(
      id,
      symptomHealthCondition,
    );
  }

  @put('/symptom-health-conditions/{id}', {
    responses: {
      '204': {
        description: 'SymptomHealthCondition PUT success',
      },
    },
  })
  async replaceById(
    @param.path.string('id') id: string,
    @requestBody() symptomHealthCondition: SymptomHealthCondition,
  ): Promise<void> {
    await this.symptomHealthConditionRepository.replaceById(
      id,
      symptomHealthCondition,
    );
  }

  @del('/symptom-health-conditions/{id}', {
    responses: {
      '204': {
        description: 'SymptomHealthCondition DELETE success',
      },
    },
  })
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.symptomHealthConditionRepository.deleteById(id);
  }
}
