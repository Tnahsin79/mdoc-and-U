import {
  get,
  del,
  post,
  param,
  patch,
  requestBody,
  getModelSchemaRef,
  getFilterSchemaFor,
} from '@loopback/rest';
import Utils from '../utils';
import {inject} from '@loopback/context';
import {Filter} from '@loopback/repository';
import {PaginatedResponse} from '../type-schema';
import {authenticate} from '@loopback/authentication';
import {UserMentalAssessmentService} from '../services';
import {UserMentalAssessmentServiceBindings} from '../keys';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';
import {UserMentalAssessment, UserMentalAssessmentRecord} from '../models';
import {UserProfile, securityId, SecurityBindings} from '@loopback/security';

export class UserMentalAssessmentController {
  constructor(
    @inject(UserMentalAssessmentServiceBindings.USER_MENTAL_ASSESSMENT_SERVICE)
    public userMentalAssessmentService: UserMentalAssessmentService,
  ) {}

  @post('/user-mental-assessment', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'UserMentalAssessment model instance',
        content: {
          'application/json': {schema: getModelSchemaRef(UserMentalAssessment)},
        },
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(UserMentalAssessment, {
            title: 'NewUserMentalAssessment',
            exclude: ['id'],
          }),
        },
      },
    })
    userMentalAssessment: Omit<UserMentalAssessment, 'id'>,
  ): Promise<UserMentalAssessment> {
    return this.userMentalAssessmentService.create(userMentalAssessment);
  }

  @post('/user-mental-assessment/bulk', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'UserMentalAssessment model instance',
      },
    },
  })
  @authenticate('jwt')
  async createBulk(
    @requestBody({
      content: {
        'application/json': {
          schema: {
            type: 'array',
            items: getModelSchemaRef(UserMentalAssessment, {
              title: 'NewUserMentalAssessment',
              exclude: ['id'],
            }),
          },
        },
      },
    })
    userMentalAssessment: Omit<UserMentalAssessment, 'id'>[],
    @inject(SecurityBindings.USER) currentUser: UserProfile,
  ): Promise<void> {
    const userId = currentUser[securityId];
    return this.userMentalAssessmentService.createBulk(
      userId,
      userMentalAssessment,
    );
  }

  @get('/user-mental-assessment', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of UserMentalAssessment model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(UserMentalAssessment, {
                includeRelations: true,
              }),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findAll(
    @param.query.object('filter', getFilterSchemaFor(UserMentalAssessment))
    filter?: Filter<UserMentalAssessment>,
    @param.query.number('page') page?: number,
  ): Promise<PaginatedResponse<UserMentalAssessment>> {
    return this.userMentalAssessmentService.findAll(filter, page);
  }

  @get('/user-mental-assessment/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'UserMentalAssessment model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(UserMentalAssessment, {
              includeRelations: true,
            }),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(UserMentalAssessment))
    filter?: Filter<UserMentalAssessment>,
  ) {
    return this.userMentalAssessmentService.findById(id, filter);
  }

  @patch('/user-mental-assessment/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'UserMentalAssessment PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(UserMentalAssessment, {partial: true}),
        },
      },
    })
    userMentalAssessment: UserMentalAssessment,
  ): Promise<void> {
    return await this.userMentalAssessmentService.updateById(
      id,
      userMentalAssessment,
    );
  }

  @del('/user-mental-assessment/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'UserMentalAssessment DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    this.userMentalAssessmentService.deleteById(id);
  }

  @get('/user-mental-assessment-record', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of UserMentalAssessment model iinanstances',
        content: {
          'application/json': {
            schema: Utils.paginatedSchema(UserMentalAssessmentRecord, true),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findAllUserMentalAssessmentRecord(
    @param.query.object(
      'filter',
      getFilterSchemaFor(UserMentalAssessmentRecord),
    )
    filter?: Filter<UserMentalAssessmentRecord>,
    @param.query.number('page') page?: number,
  ): Promise<PaginatedResponse<UserMentalAssessmentRecord>> {
    return this.userMentalAssessmentService.findAllUserMentalAssessmentRecord(
      filter,
      page,
    );
  }

  @get('/user-mental-assessment-record/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'UserMentalAssessmentRecord model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(UserMentalAssessmentRecord, {
              includeRelations: true,
            }),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async userMentalAssessmentRecordById(
    @param.path.string('id') id: string,
    @param.query.object(
      'filter',
      getFilterSchemaFor(UserMentalAssessmentRecord),
    )
    filter?: Filter<UserMentalAssessmentRecord>,
  ): Promise<UserMentalAssessmentRecord> {
    return this.userMentalAssessmentService.userMentalAssessmentRecordById(
      id,
      filter,
    );
  }

  @get('/user-mental-assessment-record/exists/{userId}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Check if mental health assessment record exists',
        content: {
          'application/json': {
            schema: {
              type: 'object',
              properties: {
                gadExists: {type: 'boolean'},
                phqExists: {type: 'boolean'},
              },
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async checkIfMentalHealthAssessmentRecordExists(
    @param.path.string('userId') userId: string,
  ) {
    return this.userMentalAssessmentService.checkIfMentalHealthAssessmentRecordExists(
      userId,
    );
  }
}
