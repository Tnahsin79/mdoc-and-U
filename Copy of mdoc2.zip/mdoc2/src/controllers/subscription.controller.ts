import {
  Count,
  CountSchema,
  Filter,
  repository,
  Where,
  AnyObject,
} from '@loopback/repository';
import {
  post,
  param,
  get,
  getFilterSchemaFor,
  getModelSchemaRef,
  getWhereSchemaFor,
  patch,
  put,
  del,
  requestBody,
  HttpErrors,
} from '@loopback/rest';
import {Subscriptions} from '../models';
import {
  PaymentsRepository,
  SubscriptionsRepository,
  UsersRepository,
} from '../repositories';
import * as _ from 'lodash';
import {inject} from '@loopback/core';
import {ControllerService} from '../services/controller.service';
import {
  ControllerServiceBindings,
  EmailServiceBindings,
  MigrationServiceBindings,
} from '../keys';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';
import {authenticate} from '@loopback/authentication';
import csv from 'csvtojson';
import {MigrationService} from '../services/migration.service';
import {EmailService} from '../services/email.service';
import * as common from '../services/common';
import moment from 'moment';

export class SubscriptionController {
  constructor(
    @repository(SubscriptionsRepository)
    public subscriptionsRepository: SubscriptionsRepository,
    @repository(UsersRepository) public usersRepository: UsersRepository,
    @inject(ControllerServiceBindings.CONTROLLER_SERVICE)
    public controllerService: ControllerService,
    @inject(MigrationServiceBindings.MIGRATION_SERVICE)
    public migrationService: MigrationService,
    @inject(EmailServiceBindings.MAIL_SERVICE)
    public emailService: EmailService,
    @repository(PaymentsRepository)
    public paymentsRepository: PaymentsRepository,
  ) {}

  @post('/subscriptions', {
    responses: {
      '200': {
        description: 'Subscriptions model instance',
        content: {
          'application/json': {schema: getModelSchemaRef(Subscriptions)},
        },
      },
    },
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Subscriptions, {
            title: 'NewSubscriptions',
            exclude: ['id'],
          }),
        },
      },
    })
    subscriptions: Omit<Subscriptions, 'id'>,
  ): Promise<Subscriptions> {
    const userDetails = await this.usersRepository.find({
      where: {
        id: subscriptions.userId,
      },
    });

    if (!userDetails) {
      throw new HttpErrors.Unauthorized('User not found');
    }

    const uniqId = Math.floor(100000 + Math.random() * 900000);
    subscriptions.subscriptionId = 'SID' + uniqId.toString();

    // check if the member has initial subscription
    let method = 'a new';
    const initialSubscription = await this.subscriptionsRepository.find({
      where: {
        userId: subscriptions.userId,
      },
      order: ['expireDate DESC'],
    });

    if (initialSubscription.length > 0) {
      method = 'renewed';
      subscriptions.expireDate = common.calculateExpirationDate(
        subscriptions.renewalDate,
        subscriptions.planName,
        initialSubscription[0].expireDate,
      );
    } else {
      subscriptions.expireDate = common.calculateExpirationDate(
        subscriptions.renewalDate,
        subscriptions.planName,
      );
    }
    subscriptions.subscriptionPackage = common.getSubscriptionProgram(
      subscriptions.subscriptionPackage,
    );

    const staffPayload = {
      to: 'payment-test@mymdoc.com',
      slug: 'subcription_notification_staff',
      message: {
        name: userDetails[0].name,
        program: common.getSubscriptionProgram(
          subscriptions.subscriptionPackage ?? '',
        ),
        phone: userDetails[0].phone,
        plan: subscriptions.subscriptionName,
        duration: subscriptions.planName,
        method,
      },
    };
    const result = await this.subscriptionsRepository.create(subscriptions);
    const memberPayload = {
      to: userDetails[0].email,
      slug: 'subcription_notification_member',
      message: {
        name: userDetails[0].name,
        program: common.getSubscriptionProgram(
          subscriptions.subscriptionPackage ?? '',
        ),
        plan: common.getPackageType(subscriptions.planName),
        expiryDate: result.expireDate,
      },
    };
    await this.paymentsRepository.create({
      userId: userDetails[0].id,
      planId: subscriptions.planName,
      transactionId: result.id,
      paymentType: result.subscriptionName,
      // payer: result.payer,
      status: 'success',
      amount: common.calculateAmount(
        subscriptions.subscriptionName ?? '',
        subscriptions.planName,
      ),
    });
    await this.emailService.sendMail(staffPayload);
    // await this.emailService.sendMail(memberPayload);
    return result;
  }

  @get('/subscriptions/count', {
    responses: {
      '200': {
        description: 'Subscriptions model count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async count(
    @param.query.object('where', getWhereSchemaFor(Subscriptions))
    where?: Where<Subscriptions>,
  ): Promise<Count> {
    return this.subscriptionsRepository.count(where);
  }

  @get('/subscriptions', {
    responses: {
      '200': {
        description: 'Array of Subscriptions model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(Subscriptions, {
                includeRelations: true,
              }),
            },
          },
        },
      },
    },
  })
  async find(
    @param.query.object('filter')
    filter?: AnyObject,
    @param.query.number('page')
    page?: number
  ): Promise<AnyObject> {
    const query: any = { and: [] };
    const responseData: any = {};

    const subscriptions: Array<AnyObject> = [];

    query.and.push({
      status: {inq: [0, 1]},
    });
    if (filter && filter.searchBy === 'member') {
      const newQuery: AnyObject = {};
      newQuery.name = new RegExp('.*' + filter.searchName + '.*', 'i');

      const users = await this.usersRepository.find({where: newQuery});
      if (users?.length) {
        const userIds: Array<any> = _.map(users, v => v.id);

        query.and.push({
          userId: {inq: userIds},
        });
      }
    }

    if (filter && filter.searchBy === 'duration') {
      query.and.push({
        planName: new RegExp('.*' + filter.searchDuration + '.*', 'i'),
      });
    }
    if (filter && filter.searchBy === 'paymentChannel') {
      query.and.push({
        payer: new RegExp('.*' + filter.searchPaymentChannel + '.*', 'i'),
      });
    }
    if (filter && filter.searchBy === 'renewalDate') {
      query.and.push({
        renewalDate: {
          lte: moment
            .utc(filter.searchRenewalDate)
            .endOf('day')
            .format('YYYY-MM-DD'),
        },
      });
      query.and.push({
        renewalDate: {
          gte: moment
            .utc(filter.searchRenewalDate)
            .startOf('day')
            .format('YYYY-MM-DD'),
        },
      });
    }
    if (filter && filter.searchBy === 'expireDate') {
      query.and.push({
        expireDate: {neq: null},
      });
      query.and.push({
        expireDate: {
          lte: moment
            .utc(filter.searchExpireDate)
            .endOf('day')
            .format('YYYY-MM-DD'),
        },
      });
      query.and.push({
        expireDate: {
          gte: moment
            .utc(filter.searchExpireDate)
            .startOf('day')
            .format('YYYY-MM-DD'),
        },
      });
    }

    // const subscriptionData = await this.subscriptionsRepository.find({
    //   where: query,
    //   limit: filter?.limit || 20,
    //   skip: filter?.skip || 0,
    //   order: ['created DESC']
    // });


    const pageSize =  filter?.limit || 20;
    const pageNum = page ? page : 1;
    const skip = (pageNum - 1) * pageSize;
    let totalCount;
    let subscriptionData
    const count = await this.subscriptionsRepository.count(query)
      .then(async (itemCount)=>{
        totalCount = itemCount.count;
        if (skip > totalCount) {
           throw new HttpErrors.BadRequest();
        }
         subscriptionData = await this.subscriptionsRepository.find({
          where: query,
          limit: pageSize,
          skip: skip,
          order: ['created DESC']
        });
        return subscriptionData;
      })
      .catch((e)=>{
        console.log({e});
        return e

      })

    const totalPages = Math.ceil(totalCount / pageSize);
    responseData.count = totalCount;

    if (subscriptionData?.length) {
      const userIds = _.map(
        subscriptionData,
        subscription => subscription.userId,
      );

      return Promise.all([
        this.usersRepository.find({
          where: {
            id: {inq: userIds},
          },
          fields: {id: true, name: true},
        }),
      ]).then(res => {
        const users = res?.[0]?.length && _.groupBy(res[0], user => user.id);

        _.forEach(subscriptionData, function(val: any) {
          const obj = Object.assign({}, val);

          // get active and inactive subscriptions using the obj.expireDate key
          //  and assign to obj.status
          if (new Date() > new Date(obj.expireDate)) {
            obj.status = 'inactive';
          } else {
            obj.status = 'active';
          }
          obj.user =
            (users?.[val.userId] && Object.assign({}, users[val.userId!][0])) ||
            {};
          subscriptions.push(obj);
        });

        // Due to an issue with the model, I had to write a conditional statement above
        //  to update the status response to be either active or inactive so that I
        //  can use the search by status query to get active and inactive subscriptions

        const subscriptionsFilter: Array<AnyObject> = [];
        if (filter && filter.searchBy === 'status') {
          _.forEach(subscriptions, function(val: any) {
            const obj = Object.assign({}, val);
            if (obj.status === filter.searchStatus) {
              subscriptionsFilter.push(obj);
            }
          })
          }
          if(filter && filter.searchBy === "status"){
            responseData.subscriptions = subscriptionsFilter;
          } else{
            responseData.subscriptions = subscriptions;
          }
        return {
          data: responseData,
          totalCount,
          currentPage: pageNum,
          totalPages
        };
      });
    } else {
      throw new HttpErrors.NotFound('Subscription not found!');
    }
    // return this.subscriptionsRepository.find(filter);
  }

  @patch('/subscriptions', {
    responses: {
      '200': {
        description: 'Subscriptions PATCH success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Subscriptions, {partial: true}),
        },
      },
    })
    subscriptions: Subscriptions,
    @param.query.object('where', getWhereSchemaFor(Subscriptions))
    where?: Where<Subscriptions>,
  ): Promise<Count> {
    return this.subscriptionsRepository.updateAll(subscriptions, where);
  }

  @get('/subscriptions/user/{userId}', {
    responses: {
      '200': {
        description: 'Subscriptions model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Subscriptions, {
              includeRelations: true,
            }),
          },
        },
      },
    },
  })
  async findByUserId(
    @param.path.string('userId') userId: string,
    @param.query.object('filter', getFilterSchemaFor(Subscriptions))
    filter?: Filter<Subscriptions>,
  ): Promise<Subscriptions> {
    const responseData: any = {}
    const userSubscription = await this.subscriptionsRepository.find({
      where: {
        userId: userId,
      },
    });

    responseData.status = 200;
    responseData.subscriptions = userSubscription;

    return responseData;
  }

  @get('/subscriptions/{id}', {
    responses: {
      '200': {
        description: 'Subscriptions model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Subscriptions, {
              includeRelations: true,
            }),
          },
        },
      },
    },
  })
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(Subscriptions))
    filter?: Filter<Subscriptions>,
  ): Promise<Subscriptions> {
    return this.subscriptionsRepository.findById(id, filter);
  }

  @patch('/subscriptions/{id}', {
    responses: {
      '204': {
        description: 'Subscriptions PATCH success',
      },
    },
  })
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Subscriptions, {partial: true}),
        },
      },
    })
    subscriptions: Subscriptions,
  ): Promise<void> {
    await this.subscriptionsRepository.updateById(id, subscriptions);
  }

  @put('/subscriptions/{id}', {
    responses: {
      '204': {
        description: 'Subscriptions PUT success',
      },
    },
  })
  async replaceById(
    @param.path.string('id') id: string,
    @requestBody() subscriptions: Subscriptions,
  ): Promise<void> {
    await this.subscriptionsRepository.replaceById(id, subscriptions);
  }

  @del('/subscriptions/{id}', {
    responses: {
      '204': {
        description: 'Subscriptions DELETE success',
      },
    },
  })
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.subscriptionsRepository.deleteById(id);
  }

  @post('/subscriptions/getSubscriptionList', {
    responses: {
      '204': {
        description: 'Subscriptions PUT success',
      },
    },
  })
  async getSubscriptionList(@requestBody() data: any): Promise<any> {
    const query: AnyObject = {and: []};
    query.and.push({
      status: 1,
    });
    let anyQuery: AnyObject = {};
    const responseData: AnyObject = {};
    const subscriptions: Array<AnyObject> = [];
    if (data?.userName) {
      anyQuery = {
        name: new RegExp('.*' + data.userName + '.*', 'i'),
      };
      const userDetails = await this.usersRepository.find({
        where: anyQuery,
        fields: {id: true, name: true},
      });
      const userId = _.map(userDetails, v => v.id);
      query.and.push({
        userId: {inq: userId},
      });
    }
    if (data?.renewalDate) {
      const dateOne = new Date(data.renewalDate[0]);
      const dateTwo = new Date(data.renewalDate[1]);
      query.and.push({
        renewalDate: {
          between: [dateOne, dateTwo],
        },
      });
    }
    const {count} = await this.subscriptionsRepository.count();

    responseData.count = count;

    const subscriptionData = await this.subscriptionsRepository.find({
      where: query,
      order: ['created DESC'],
      limit: data?.limit ? data.limit : 10,
      skip: data?.skip ? data.skip : 0,
    });
    if (subscriptionData?.length) {
      const userIds = _.map(subscriptionData, v => v.userId);

      return Promise.all([
        this.usersRepository.find({
          where: {
            id: {inq: userIds},
          },
          fields: {id: true, name: true},
        }),
      ]).then(res => {
        const users = res?.[0]?.length && _.groupBy(res[0], v => v.id);

        _.forEach(subscriptionData, function(val: any) {
          const obj = Object.assign({}, val);
          obj.user =
            (users?.[val.userId] && Object.assign({}, users[val.userId!][0])) ||
            {};
          subscriptions.push(obj);
        });
        responseData.subscriptions = subscriptions;
        return responseData;
      });
    } else {
      throw new HttpErrors.NotFound('Subscription not found!');
    }
  }

  @get('/subscriptions/subscriptionNotification', {
    responses: {
      '204': {
        description: 'Subscriptions PUT success',
      },
    },
  })
  async subscriptionNotification(): Promise<any> {
    const result = await this.controllerService.subscriptionNotification();
  }

  @get('/subscriptionsMigration', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Subscriptions Migration instance',
      },
    },
  })
  @authenticate('jwt')
  async subscriptions(): Promise<any> {
    const filePath = './public/subscription_transactions.csv';

    const sub = await csv().fromFile(filePath);
    if (sub?.length) {
      for (const [index, value] of sub.entries()) {
        await this.migrationService.subscriptionTrasitionMigration(value);
      }
    }
  }

  @post('/getSubscriptions', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Subscriptions  instance',
      },
    },
  })
  @authenticate('jwt')
  async getSubscriptions(@requestBody() data: any): Promise<any> {
    const query: any = {and: []};
    query.and.push({
      status: {inq: [0, 1]},
    });
    if (data?.userId) {
      query.and.push({
        userId: data.userId,
      });
    }
    if (data?.status) {
      query.and.push({
        state: data.status,
      });
    }
    if (data?.duration) {
      query.and.push({
        planName: new RegExp('.*' + data.duration + '.*', 'i'),
      });
    }
    if (data?.paymentChannel) {
      query.and.push({
        payer: data.paymentChannel,
      });
    }
    if (data?.programType) {
      query.and.push({
        subscriptionId: data.programType,
      });
    }
    if (data?.renewalDate) {
      query.and.push({
        renewalDate: {
          lte: moment
            .utc(data.renewalDate, 'YYYY-MM-DD')
            .endOf('day')
            .toISOString(),
        },
      });
      query.and.push({
        renewalDate: {
          gte: moment
            .utc(data.renewalDate, 'YYYY-MM-DD')
            .startOf('day')
            .toISOString(),
        },
      });
    }
    if (data?.expireDate) {
      query.and.push({
        expireDate: {
          lte: moment
            .utc(data.expireDate, 'YYYY-MM-DD')
            .endOf('day')
            .toISOString(),
        },
      });
      query.and.push({
        expireDate: {
          gte: moment
            .utc(data.expireDate, 'YYYY-MM-DD')
            .startOf('day')
            .toISOString(),
        },
      });
    }

    return this.subscriptionsRepository.find({
      where: query,
      order: ['created DESC'],
    });
  }
}
