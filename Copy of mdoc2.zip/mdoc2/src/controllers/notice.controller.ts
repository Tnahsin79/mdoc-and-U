import {authenticate} from '@loopback/authentication';
import {inject} from '@loopback/core';
import {
  post,
  param,
  get,
  getModelSchemaRef,
  patch,
  del,
  requestBody,
  getFilterSchemaFor,
} from '@loopback/rest';
import {NoticeServiceBindings} from '../keys';
import { Notice, UserNotice} from '../models';
import { NoticeService} from '../services';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';
import {Filter} from '@loopback/repository';
import { PaginatedResponse } from '../type-schema';
import Utils from '../utils';

export class NoticeController {
  constructor(
    @inject(NoticeServiceBindings.NOTICE_SERVICE)
    public noticeService: NoticeService,
  ) {}

  @post('/notices', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'Notice model instance',
        content: {'application/json': {schema: getModelSchemaRef(Notice)}},
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Notice, {
            exclude: ['id'],
          }),
        },
      },
    })
    notice: Omit<Notice, 'id'>,
  ): Promise<Notice> {
    return this.noticeService.create(notice);
  }

  @get('/notices/user/{userId}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'Array of User Notices model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(UserNotice, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async getByUserId(
    @param.path.string('userId') userId: string
  ): Promise<Notice[]> {
    return this.noticeService.getByUserId(userId);
  }

  @patch('/notices/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      204: {
        description: 'Update successful',
        content: {},
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Notice, {partial: true}),
        },
      },
    })
    notice: Notice,
    @param.path.string('id') id: string,
  ): Promise<void> {
    return this.noticeService.updateById(id, notice);
  }

  @get('/notices/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'Notice model instance',
        content: {'application/json': {schema: getModelSchemaRef(Notice)}},
      },
    },
  })
  @authenticate('jwt')
  async findById(@param.path.string('id') id: string): Promise<Notice> {
    return this.noticeService.findById(id);
  }

  @del('/notices/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      204: {
        description: 'Notice deleted successfully',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.noticeService.deleteById(id);
  }

  @patch('/notices/{id}/read-notice/{userId}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      204: {
        description: 'Notice read successful',
      },
    },
  })
  @authenticate('jwt')
    async markNoticeAsRead(
      @param.path.string('id') id: string,
      @param.path.string('userId') userId: string,
    ): Promise<void> {
      await this.noticeService.markNoticeAsRead(id, userId);
    }

  @get('/notices', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'Array of Notice model instances',
        content: {
          'application/json': {
            schema: Utils.paginatedSchema(Notice, true),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async find(
    @param.query.object('filter', getFilterSchemaFor(Notice))
    filter?: Filter<Notice>,
    @param.query.number('page') page?: number,
  ): Promise<PaginatedResponse<Notice>> {
    return this.noticeService.findAll(filter, page);
  }
}
