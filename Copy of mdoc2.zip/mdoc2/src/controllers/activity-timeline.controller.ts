import {
  get,
  del,
  post,
  param,
  patch,
  requestBody,
  getModelSchemaRef,
  getFilterSchemaFor,
} from '@loopback/rest';
import {inject} from '@loopback/core';
import {ActivityTimeline} from '../models';
import {Filter} from '@loopback/repository';
import {PaginatedResponse} from '../type-schema';
import {authenticate} from '@loopback/authentication';
import {ActivityTimelineServiceBindings} from '../keys';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';
import {ActivityTimelineService} from '../services/activity-timeline.service';

export class ActivityTimelineController {
  constructor(
    @inject(ActivityTimelineServiceBindings.ACTIVITY_TIMELINE_SERVICE)
    public activityTimelineService: ActivityTimelineService,
  ) {}

  @post('/activity-timeline', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'ActivityTimeline model instance',
        content: {
          'application/json': {schema: getModelSchemaRef(ActivityTimeline)},
        },
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(ActivityTimeline, {
            title: 'NewActivityTimeline',
            exclude: ['id'],
          }),
        },
      },
    })
    activityTimeline: Omit<ActivityTimeline, 'id'>,
  ): Promise<ActivityTimeline> {
    return this.activityTimelineService.create(activityTimeline);
  }

  @get('/activity-timelines', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of ActivityTimeline model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(ActivityTimeline, {
                includeRelations: true,
              }),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findAll(
    @param.query.object('filter', getFilterSchemaFor(ActivityTimeline))
    filter?: Filter<ActivityTimeline>,
    @param.query.number('page') page?: number,
  ): Promise<PaginatedResponse<ActivityTimeline>> {
    return this.activityTimelineService.findAll(filter, page);
  }

  @get('/activity-timeline/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'ActivityTimeline model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(ActivityTimeline, {
              includeRelations: true,
            }),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(ActivityTimeline))
    filter?: Filter<ActivityTimeline>,
  ) {
    return this.activityTimelineService.findById(id, filter);
  }

  @patch('/activity-timeline/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'ActivityTimeline PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(ActivityTimeline, {partial: true}),
        },
      },
    })
    activityTimeline: ActivityTimeline,
  ): Promise<void> {
    return await this.activityTimelineService.updateById(id, activityTimeline);
  }

  @del('/activity-timeline/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'ActivityTimeline DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    this.activityTimelineService.deleteById(id);
  }
}
