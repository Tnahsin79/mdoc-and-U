import {
  get,
  del,
  post,
  param,
  patch,
  Request,
  Response,
  requestBody,
  RestBindings,
  getModelSchemaRef,
  getFilterSchemaFor,
} from '@loopback/rest';
import {UsersRepository, PublicationRepository} from '../repositories';
import * as _ from 'lodash';
import Utils from '../utils';
import {Publication} from '../models';
import {inject} from '@loopback/core';
import {PublicationServiceBindings} from '../keys';
import {PaginatedResponse} from '../type-schema';
import {authenticate} from '@loopback/authentication';
import {Filter, repository} from '@loopback/repository';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';
import {UserProfile, SecurityBindings} from '@loopback/security';
import {PublicationService} from '../services/publication.service';
export class PublicationController {
  constructor(
    @repository(PublicationRepository)
    public publicationRepository: PublicationRepository,
    @repository(UsersRepository) public usersRepository: UsersRepository,
    @inject(PublicationServiceBindings.PUBLICATION_SERVICE)
    public publicationService: PublicationService,
  ) {}

  @post('/publications', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Publication model instance',
        content: {'application/json': {schema: getModelSchemaRef(Publication)}},
      },
    },
  })
  @authenticate('jwt')
  async create(
    @inject(SecurityBindings.USER) currentUser: UserProfile,
    @requestBody({
      content: {
        'multipart/form-data': {
          'x-parser': 'stream',
          schema: {
            type: 'object',
            properties: {
              title: {type: 'string'},
              description: {type: 'string'},
              externalLink: {type: 'string'},
              citation: {type: 'string'},
              journalName: {type: 'string'},
              publicationDate: {type: 'string', dataType: 'date'},
            },
          },
        },
      },
    })
    request: Request,
    @inject(RestBindings.Http.RESPONSE)
    response: Response,
  ): Promise<any> {
    try {
      return await this.publicationService.create(
        request,
        response,
        currentUser,
      );
    } catch (error) {
      return error;
    }
  }

  @get('/publications', {
    responses: {
      '200': {
        description: 'Array of Publication model instances',
        content: {
          'application/json': {
            schema: Utils.paginatedSchema(Publication, true),
          },
        },
      },
    },
  })
  async find(
    @param.query.string('search') search?: string,
    @param.query.string('status') status?: string,
    @param.query.object('filter', getFilterSchemaFor(Publication))
    filter?: Filter<Publication>,
    @param.query.number('page') page?: number,
  ): Promise<PaginatedResponse<Publication>> {
    return await this.publicationService.find(search, status, filter, page);
  }

  @get('/publications/{id}', {
    responses: {
      '200': {
        description: 'Publication model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Publication, {includeRelations: true}),
          },
        },
      },
    },
  })
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(Publication))
    filter?: Filter<Publication>,
  ): Promise<any> {
    return await this.publicationService.findById(id, filter);
  }

  @patch('/publications/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Publication PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'multipart/form-data': {
          'x-parser': 'stream',
          schema: {
            type: 'object',
            properties: {
              title: {type: 'string'},
              description: {type: 'string'},
              externalLink: {type: 'string'},
              citation: {type: 'string'},
              status: {type: 'string'},
              journalName: {type: 'string'},
              publicationDate: {type: 'string', dataType: 'date'},
            },
          },
        },
      },
    })
    request: Request,
    @inject(RestBindings.Http.RESPONSE)
    response: Response,
  ): Promise<any> {
    return await this.publicationService.update(id, request, response);
  }

  @del('/publications/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Publication DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.publicationService.deleteById(id);
  }

  @get('/publications/statistics', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Publication model count',
        content: {
          'application/json': {
            schema: {
              type: 'object',
              properties: {
                publicationCount: {type: 'number'},
                publishedCount: {type: 'number'},
                unpublishedCount: {type: 'number'},
              },
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async statistics(): Promise<any> {
    return await this.publicationService.statistics();
  }
}
