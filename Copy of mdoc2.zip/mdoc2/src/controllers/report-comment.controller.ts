import {
  post,
  param,
  get,
  getModelSchemaRef,
  patch,
  put,
  del,
  requestBody,
  getFilterSchemaFor,
} from '@loopback/rest';
import {
  Count,
  CountSchema,
  Filter,
  Where,
  repository,
} from '@loopback/repository';
import {inject} from '@loopback/context';
import {ReportCommentService} from '../services';
import {ReportCommentServiceBindings} from '../keys';
import {authenticate} from '@loopback/authentication';
import {ReportCommmentRepository} from '../repositories';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';
import {ReportCommentWithRelations, ReportComment} from '../models';

export class ReportCommentController {
  constructor(
    @repository(ReportCommmentRepository)
    public reportcommentRepository: ReportCommmentRepository,
    @inject(ReportCommentServiceBindings.REPORT_COMMENT)
    public reportCommentService: ReportCommentService,
  ) {}

  @post('/report-comment', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Reportcomment model instance',
        content: {
          'application/json': {schema: getModelSchemaRef(ReportComment)},
        },
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(ReportComment, {
            title: 'NewReportcomment',
            exclude: ['id'],
          }),
        },
      },
    })
    reportcomment: Omit<ReportComment, 'id'>,
  ): Promise<ReportComment> {
    return this.reportCommentService.create(reportcomment);
  }

  @get('/report-comments/count', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Reportcomment model count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  @authenticate('jwt')
  async count(
    @param.query.object('where') where?: Where<ReportComment>,
  ): Promise<Count> {
    return this.reportCommentService.count(where);
  }

  @get('/report-comments', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of Reportcomment model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(ReportComment, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async find(
    @param.query.object('filter', getFilterSchemaFor(ReportComment))
    filter?: Filter<ReportComment>,
  ): Promise<ReportCommentWithRelations[]> {
    return this.reportCommentService.find();
  }

  @get('/report-comment/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Reportcomment model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(ReportComment, {includeRelations: true}),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', {exclude: 'where'})
    filter?: Filter<ReportComment>,
  ): Promise<ReportComment> {
    return this.reportCommentService.findById(id);
  }

  @patch('/report-comment/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Reportcomment PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(ReportComment, {partial: true}),
        },
      },
    })
    reportcomment: ReportComment,
  ): Promise<void> {
    return this.reportCommentService.updateById(id, reportcomment);
  }

  @put('/report-comment/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Reportcomment PUT success',
      },
    },
  })
  @authenticate('jwt')
  async replaceById(
    @param.path.string('id') id: string,
    @requestBody() reportcomment: ReportComment,
  ): Promise<void> {
    return this.reportCommentService.replaceById(id, reportcomment);
  }

  @del('/report-comment/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Reportcomment DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    return this.reportCommentService.deleteById(id);
  }
}
