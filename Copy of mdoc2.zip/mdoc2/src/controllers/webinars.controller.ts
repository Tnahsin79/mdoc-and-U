import { authenticate } from '@loopback/authentication';
import { AnyObject, AnyType, Count, CountSchema, Filter, repository, Where, } from '@loopback/repository';
import { post, param, get, getModelSchemaRef, patch, put, del, requestBody, getFilterSchemaFor, } from '@loopback/rest';
import { Webinar } from '../models';
import { WebinarRepository } from '../repositories';
import { OPERATION_SECURITY_SPEC } from '../utils/security-spec';
import * as _ from 'lodash'
import moment from 'moment';
export class WebinarsController {
  constructor(
    @repository(WebinarRepository) public webinarRepository: WebinarRepository,
  ) { }

  @post('/webinars', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'Webinar model instance',
        content: { 'application/json': { schema: getModelSchemaRef(Webinar) } },
      },
    }
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Webinar, {
            title: 'NewWebinar',
            exclude: ['id'],
          }),
        },
      },
    })
    webinar: Omit<Webinar, 'id'>,
  ): Promise<Webinar> {
    if (webinar && webinar.day === "None") {
      webinar.day = ""
    }
    return this.webinarRepository.create(webinar);
  }

  // @get('/webinars/count', {
  //   responses: {
  //     200: {
  //       description: 'Webinar model count',
  //       content: { 'application/json': { schema: CountSchema } },
  //     },
  //   }
  // })
  // async count(
  //   @param.where(Webinar) where?: Where<Webinar>,
  // ): Promise<Count> {
  //   return this.webinarRepository.count(where);
  // }

  @get('/webinars', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'Array of Webinar/publication model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(Webinar, { includeRelations: true }),
            },
          },
        },
      },
    }
  })
  @authenticate('jwt')
  async find(
    @param.query.object('filter', getFilterSchemaFor(Webinar)) filter?: Filter<Webinar>,
  ): Promise<Webinar[]> {
    return this.webinarRepository.find(filter);
  }

  // @patch('/webinars')
  // @response(200, {
  //   description: 'Webinar PATCH success count',
  //   content: {'application/json': {schema: CountSchema}},
  // })
  // async updateAll(
  //   @requestBody({
  //     content: {
  //       'application/json': {
  //         schema: getModelSchemaRef(Webinar, {partial: true}),
  //       },
  //     },
  //   })
  //   webinar: Webinar,
  //   @param.where(Webinar) where?: Where<Webinar>,
  // ): Promise<Count> {
  //   return this.webinarRepository.updateAll(webinar, where);
  // }

  @get('/webinars/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'Webinar model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Webinar, { includeRelations: true }),
          },
        },
      },
    }
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(Webinar)) filter?: Filter<Webinar>,
  ): Promise<Webinar> {
    return this.webinarRepository.findById(id, filter);
  }

  @patch('/webinars/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      204: {
        description: 'Webinar PATCH success',
      },
    }
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Webinar, { partial: true }),
        },
      },
    })
    webinar: Webinar,
  ): Promise<void> {
    if (webinar && webinar.day === "None") {
      webinar.day = ""
    }
    await this.webinarRepository.updateById(id, webinar);
  }

  // @put('/webinars/{id}')
  // @response(204, {
  //   description: 'Webinar PUT success',
  // })
  // async replaceById(
  //   @param.path.string('id') id: string,
  //   @requestBody() webinar: Webinar,
  // ): Promise<void> {
  //   await this.webinarRepository.replaceById(id, webinar);
  // }

  @del('/webinars/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      204: {
        description: 'Webinar DELETE success',
      },
    }
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.webinarRepository.deleteById(id);
  }

  @get('/webinars/createdWebnar', {
    responses: {
      200: {
        description: 'Webinar PUT success',
      },
    }
  })
  async createdWebnar(
  ): Promise<any> {
    return false
    const data = [
      {
        "title": "Tele-ECHO - Healthcare Workers",
        "description": "Managing Sickle Cell Disease in Pregnancy: What Can we Do Better?",
        "url": "https://youtu.be/eZjEIaYe8hQ",
        "videoId": "eZjEIaYe8hQ",
        "date": "18/02/2021"
      },
      {
        "title": "Tele-ECHO - Pregnant Mums",
        "description": "Hypertension, My Pregnancy and Me: All You Need to Know About Hypertension in Pregnancy",
        "url": "https://youtu.be/lwviuznKJsU",
        "videoId": "lwviuznKJsU",
        "date": "24/04/2021"
      },
      {
        "title": "Tele-ECHO - Healthcare Workers",
        "description": "Co-managing Diabetes and Obesity in a Pregnant Woman",
        "url": "https://youtu.be/eZFQ7vVynf0",
        "videoId": "eZFQ7vVynf0",
        "date": "10/12/2020"
      },
      {
        "title": "Tele-ECHO - Healthcare Workers",
        "description": "RICOM3 Project Implementation: End of Project Dissemination",
        "url": "https://youtu.be/KzYSWSuLgts",
        "videoId": "KzYSWSuLgts",
        "date": "10/12/2020"
      },
      {
        "title": "Tele-ECHO - Healthcare Workers",
        "description": "In-Service Of The Little Ones: Best Practice In Management Of Jaundice in Newborns",
        "url": "https://youtu.be/w4L-ZFefKKk",
        "videoId": "w4L-ZFefKKk",
        "date": "22/10/2020"
      },
      {
        "title": "Tele-ECHO - Healthcare Workers",
        "description": "COVID-19 Vaccination in Pregnancy and Breastfeeding: Evidence and Recommendations to Date",
        "url": "https://youtu.be/weruu5HlYjQ",
        "videoId": "weruu5HlYjQ",
        "date": "20/05/2021"
      },
      {
        "title": "Tele-ECHO - Healthcare Workers",
        "description": "Recurrent Miscarriages: Work Up Guidance For Women Trying Again",
        "url": "https://youtu.be/gpVak-LWUBw",
        "videoId": "gpVak-LWUBw",
        "date": "17/09/2020"
      },
      {
        "title": "Tele-ECHO - Healthcare Workers",
        "description": "Hepatitis B Virus & Pregnancy: Best Practices in Management of HBV During and After Pregnancy",
        "url": "https://youtu.be/Rnszgh50Joo",
        "videoId": "Rnszgh50Joo",
      },
      {
        "title": "Tele-ECHO - Healthcare Workers",
        "description": "Predicting and Preventing Pre-eclampsia/Eclampsia: Early Maternal Warning Signs",
        "url": "https://youtu.be/52W71O0m-cw",
        "videoId": "52W71O0m-cw",
        "date": "17/09/2021"
      },
      {
        "title": "Tele-ECHO - Healthcare Workers",
        "description": "COVID-19 Vaccination in Pregnancy and Breastfeeding: Evidence and Recommendations to Date",
        "url": "https://youtu.be/hVhSIql43oU",
        "videoId": "hVhSIql43oU",
      },
      {
        "title": "Tele-ECHO - Healthcare Workers",
        "description": "Diabetes in the time of Covid-19",
        "url": "https://youtu.be/YnVS8ro9pa4",
        "videoId": "YnVS8ro9pa4",
      },
      {
        "title": "Tele-ECHO - Healthcare Workers",
        "description": "Management Of Pre-eclampsia in The Face Of Covid-19",
        "url": "https://youtu.be/mffMzIj8gOs",
        "videoId": "mffMzIj8gOs",
      },
      {
        "title": "Tele-ECHO - Healthcare Workers",
        "description": "Screening And Caring For A Woman Who Has Experienced A Sexual Assault",
        "url": "https://youtu.be/JAiSHuBGnLM",
        "videoId": "JAiSHuBGnLM",
      },
      {
        "title": "Tele-ECHO - Healthcare Workers",
        "description": "Cut Through The Noise: Get The Latest Evidence Behind Medications for Covid-19",
        "url": "https://youtu.be/80ClVgSQZNw",
        "videoId": "80ClVgSQZNw",
      },
      {
        "title": "Tele-ECHO - Healthcare Workers",
        "description": "I Am Happy but Sad! How Do I Cope with Postpartum Depression?",
        "url": "https://youtu.be/ZhFFOhT35P8",
        "videoId": "ZhFFOhT35P8",
        "date": "24/07/2021"
      },
      {
        "title": "TeCLA",
        "description": "Managing Hypertension in Sub-Saharan Africa in 2021: What You Need to Know",
        "url": "https://youtu.be/8q5G9chqgvE",
        "videoId": "8q5G9chqgvE",
        "date": "29/07/2021"
      },
      {
        "title": "Tele-ECHO - Healthcare Workers",
        "description": "Management of a COVlD-19-Positive Pregnant Woman With Diabetes",
        "url": "https://youtu.be/O1HoocTX7Ds",
        "videoId": "O1HoocTX7Ds",
        "date": "20/05/2021"
      },
      {
        "title": "Tele-ECHO - Healthcare Workers",
        "description": "Diabetes: Getting a Grip on the Highs and Lows of Blood Glucose Management",
        "url": "https://youtu.be/oQ__1y5z-gw",
        "videoId": "oQ__1y5z-gw",
        "date": "19/08/2021"
      },
      {
        "title": "Tele-ECHO - Healthcare Workers",
        "description": "Preparing Ahead: What Do I Do for the New Born of a Woman With COVID-19",
        "url": "https://youtu.be/caQIcafWPbY",
        "videoId": "caQIcafWPbY",
      },
      {
        "title": "TeCLA",
        "description": "Gestational Diabetes",
        "url": "https://youtu.be/-KvVeFr6C-g",
        "videoId": "-KvVeFr6C-g",
        "date": "26/08/2021"
      },
      {
        "title": "Tele-ECHO - Pregnan moms",
        "description": "The Why and How of Exclusive Breastfeeding: Tips for a Rewarding Experience",
        "url": "https://youtu.be/0zZ3KzW20Hs",
        "videoId": "0zZ3KzW20Hs",
        "date": "25/09/2021"
      },
      {
        "title": "TeCLA",
        "description": "Breast Cancer: Screening and Management",
        "url": "https://youtu.be/ri84gSGhbeU",
        "videoId": "ri84gSGhbeU",
        "date": "28/09/2021"
      },
      {
        "title": "TeCLA",
        "description": "Managing Thromboembolic Diseases",
        "url": "https://youtu.be/-mAEI6l0xQs",
        "videoId": "-mAEI6l0xQs",
        "date": "14/10/2021"
      },
      {
        "title": "Tele-ECHO - Pregnant Mums",
        "description": "Respectful Maternity Care: What Matters, Especially to 'Her'?",
        "url": "https://youtu.be/KZatxlp5AAI",
        "videoId": "KZatxlp5AAI",
        "date": "21/10/2021"
      },
      {
        "title": "TeCLA",
        "description": "Management of Pre-eclampsia in a Cost-Constrained Setting",
        "url": "https://youtu.be/lB84w3Lo_KU",
        "videoId": "lB84w3Lo_KU",
        "date": "28/10/2021"
      },
      {
        "title": "(TeCLA) mDoc in collaboration with B.I ",
        "description": "Patient Safety Leadership in Africa.",
        "url": "https://youtu.be/h04Y3bZzcAw",
        "videoId": "h04Y3bZzcAw",
        "date": "18/11/2021"
      },
      {
        "title": "Tele-ECHO - Pregnant Mums",
        "description": "What to know about sex during pregnancy and post delivery",
        "url": "https://youtu.be/Z2S9a2cs0Pg",
        "videoId": "Z2S9a2cs0Pg",
        "date": "27/11/2021"
      },
    ]
    let _this = this
    _.forEach(data, async function (val) {
      let obj: AnyObject = {
        title: val.title,
        description: val.description,
        url: val.url,
        videoId: val.videoId,
        date: moment(val.date).toISOString()
      }
      await _this.webinarRepository.create(obj)
    })
    // await this.webinarRepository.replaceById(id, webinar);
  }


  @get('/webinars/getwebinarsList', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'Webinars  success',
      },
    }
  })
  @authenticate('jwt')
  async getwebinarsList(
    @param.query.string('type') type: string,
  ): Promise<any> {
    const responseData: AnyObject = {};
    const query = type ? type : 'webinar';
    const orderQuery = ['date DESC'];
    if (query === 'webinar') {
      const webinars: any = await this.webinarRepository.find({
        where: { type },
        order: orderQuery
      })
      if (webinars?.length) {
        const upwebinars = _.filter(webinars, function (val) {
          return _.gte(moment(val.date).unix(), moment().unix()) || val.day !== ""
        })
        const pastwebinars = _.filter(webinars, function (val) {
          return _.lte(moment(val.date).unix(), moment().unix()) && val.day == ""
        })
        responseData.upcomingWebinars = upwebinars
        responseData.pastWebinars = pastwebinars
      }
    } else {
      const publications: any = await this.webinarRepository.find({
        where: { type: 'publication' },
        fields: {
          sessionTime: false,
          type: false,
          created: false
        },
        order: orderQuery
      });
      responseData.publications = publications;
    }
    return responseData;
  }
}
