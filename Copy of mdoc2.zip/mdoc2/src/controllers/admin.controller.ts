import {
  UserServiceBindings,
  AdminServiceBindings,
  EmailServiceBindings,
  TokenServiceBindings,
  PasswordHasherBindings,
} from '../keys';
import {
  Credentials,
  SourceTypeEnum,
  EmailCredentials,
  ResetCredentials,
  CredentialsRequestBody,
  EmailCredentialRequestBody,
  ResetCredentialsRequestBody,
} from '../type-schema';
import {
  get,
  del,
  post,
  param,
  patch,
  HttpErrors,
  requestBody,
  getModelSchemaRef,
  getFilterSchemaFor,
} from '@loopback/rest';
import * as _ from 'lodash';
import moment from 'moment';
import {inject} from '@loopback/core';
import {Admin, Users} from '../models';
import {crypt, decrypt} from '../services/common';
import {JWTService} from '../services/jwt-service';
import {AdminService} from '../services/admin.service';
import {EmailService} from '../services/email.service';
import {validateCredentials} from '../services/validator';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';
import {UserTypeEnum, LoginHistoryTypeEnum} from '../utils/enums';
import {PasswordHasher} from '../services/hash.password.bcryptjs';
import {Filter, repository, AnyObject} from '@loopback/repository';
import {UserService, authenticate} from '@loopback/authentication';
import {AdminRepository, LoginHistoryRepository} from '../repositories';
import {UserProfile, securityId, SecurityBindings} from '@loopback/security';

export class AdminController {
  constructor(
    @repository(AdminRepository) public adminRepository: AdminRepository,
    @inject(PasswordHasherBindings.PASSWORD_HASHER)
    public passwordHasher: PasswordHasher,
    @inject(TokenServiceBindings.TOKEN_SERVICE)
    public jwtService: JWTService,
    @inject(UserServiceBindings.USER_SERVICE)
    public userService: UserService<Users, Credentials>,
    @inject(AdminServiceBindings.ADMIN_SERVICE)
    public adminService: AdminService,
    @inject(EmailServiceBindings.MAIL_SERVICE)
    public emailService: EmailService,
    @repository(LoginHistoryRepository)
    public loginHistoryRepository: LoginHistoryRepository,
  ) {}

  @post('/admins', {
    responses: {
      '200': {
        description: 'Admin model instance',
        content: {
          'application/json': {schema: getModelSchemaRef(Admin)},
        },
      },
    },
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Admin, {
            title: 'NewAdmin',
            exclude: ['id'],
          }),
        },
      },
    })
    admin: Omit<Admin, 'id'>,
  ): Promise<Admin> {
    admin.email = admin.email.toLowerCase();
    validateCredentials(_.pick(admin, ['email', 'password']));
    admin.password = await this.passwordHasher.hashPassword(
      admin.password || '123456',
    );
    admin.email = admin.email.toLowerCase();
    return this.adminRepository.create(admin);
  }
  @post('/admins/invite', {
    responses: {
      '200': {
        description: 'Admin model instance',
        content: {
          'application/json': {schema: getModelSchemaRef(Admin)},
        },
      },
    },
  })
  async createAdmin(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Admin, {
            title: 'NewAdmin',
            exclude: ['id'],
          }),
        },
      },
    })
    admin: Omit<Admin, 'id'>,
  ): Promise<AnyObject> {
    admin.email = admin.email.toLowerCase();
    const {email} = admin;
    if (!email || email.length === 0) {
      throw new Error('Email cannot  be empty');
    }
    const emailRegex = new RegExp('.*' + admin.email + '.*', 'i');
    const adminMember = await this.adminRepository.findOne({
      where: {
        email: {
          regexp: emailRegex,
        },
      },
    });

    if (adminMember) {
      throw new HttpErrors.Unauthorized('User is already registered');
    }

    const emailEncrypt = crypt('mdoc_coach', admin.email);

    const frontendURL =
      process.env.ADMIN_FRONTEND_URL ?? 'https://management-dev.mymdoc.com';

    const link = `${frontendURL}/signup?token=${emailEncrypt}`;
    const memberPayload = {
      from: 'Admin@mymdoc.com',
      to: admin.email,
      slug: 'admin_invite',
      message: {
        link,
        name: admin.name,
      },
    };
    admin.status = 'incomplete';
    await this.adminRepository.create(admin);
    await this.emailService.sendMail(memberPayload);

    const response = {
      message: 'Invitation sent',
    };
    return response;
  }

  @get('/admins', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of Admin model instances',
        content: {
          'application/json': {
            schema: {
              type: 'object',
              properties: {
                admins: {
                  type: 'array',
                  items: getModelSchemaRef(Admin, {includeRelations: true}),
                },
                count: {type: 'number'},
              },
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async find(
    @param.query.object('filter', getFilterSchemaFor(Admin))
    filter?: Filter<Admin>,
  ): Promise<{count: number; admins: Admin[]}> {
    return this.adminService.findAll(filter);
  }

  @patch('/admins/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Admin PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Admin, {partial: true}),
        },
      },
    })
    admin: Admin,
  ): Promise<void> {
    await this.adminRepository.updateById(id, admin);
  }

  @post('/admins/assign-roles/{adminId}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Admin PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async assignRoles(
    @param.path.string('adminId') adminId: string,
    @requestBody({
      content: {
        'application/json': {
          schema: {
            type: 'array',
            items: {
              type: 'string',
            },
          },
        },
      },
    })
    roleIds: string[],
  ): Promise<void> {
    await this.adminService.assignRoles(adminId, roleIds);
  }

  @post('/admins/login', {
    responses: {
      '200': {
        description: 'Token',
        content: {
          'application/json': {
            schema: {
              type: 'object',
              properties: {token: {type: 'string'}},
            },
          },
        },
      },
    },
  })
  async login(
    @requestBody(CredentialsRequestBody) credentials: Credentials,
  ): Promise<any> {
    const invalidCredentialsError = 'Invalid email or password.';
    let responseData: AnyObject = {};
    const admin = await this.adminRepository.findOne({
      where: {
        and: [
          {
            email: {
              regexp: `/^${credentials.email.toLowerCase()}/i`,
            },
          },
          {
            status: 'active',
          },
        ],
      },
      include: [
        {
          relation: 'roles',
          scope: {
            include: [
              {
                relation: 'role',
                scope: {
                  include: [
                    {
                      relation: 'rolePrivileges',
                      scope: {
                        include: [{relation: 'privilege'}],
                      },
                    },
                  ],
                },
              },
            ],
          },
        },
      ],
    });
    if (!admin) {
      throw new HttpErrors.Unauthorized(invalidCredentialsError);
    }
    if (admin.status === 'deactivated') {
      throw new HttpErrors.Unauthorized(
        'Sorry your account has been deactivated',
      );
    }

    const passwordMatched = await this.passwordHasher.comparePassword(
      credentials.password,
      admin.password || '',
    );

    if (!passwordMatched) {
      throw new HttpErrors.Unauthorized(invalidCredentialsError);
    }
    const userProfile = {
      [securityId]: admin.id || '',
      name: admin.name || '',
      email: admin.email || '',
    };
    responseData = Object.assign({}, admin);
    const token = await this.jwtService.generateToken(userProfile);

    const {refreshToken} = await this.jwtService.generateRefreshToken(
      userProfile,
    );
    await this.loginHistoryRepository.create({
      adminId: admin.id,
      loginDateTime: moment().toISOString(),
      source: credentials.source,
      userType: UserTypeEnum.ADMIN,
      browserAgent: credentials.browserAgent,
      record_type: LoginHistoryTypeEnum.LOGIN,
    });
    await this.adminRepository.updateById(admin.id, {refreshToken});
    responseData.token = token;
    responseData.refreshToken = refreshToken;
    return responseData;
  }

  @post('/admins/logout', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Logout',
      },
    },
  })
  @authenticate('jwt')
  async logout(
    @inject(SecurityBindings.USER) currentUser: UserProfile,
    @requestBody({
      content: {
        'application/json': {
          schema: {
            type: 'object',
            properties: {
              source: {
                type: 'string',
                enum: Object.values(SourceTypeEnum),
              },
              browserAgent: {type: 'string'},
            },
          },
        },
      },
    })
    credentials: {source: SourceTypeEnum; browserAgent?: string},
  ): Promise<any> {
    return await this.adminService.logout(currentUser, credentials);
  }

  @get('admins/refresh-token', {
    responses: {
      '200': {
        description: 'token refreshed',
      },
    },
  })
  async refreshAdminToken(
    @param.query.string('token')
    token: string,
  ): Promise<AnyObject> {
    return this.adminService.refreshAdminToken(token);
  }

  @post('/admins/forgot-password', {
    responses: {
      '204': {
        description: 'Forgot password',
        content: {
          'application/json': {
            schema: {
              type: 'object',
              properties: {message: {type: 'string'}},
            },
          },
        },
      },
    },
  })
  async forgotPassword(
    @requestBody(EmailCredentialRequestBody)
    credentials: EmailCredentials,
  ): Promise<any> {
    const invalidCredentialsError = 'Invalid email';
    let responseData: AnyObject = {};
    credentials.email = credentials.email.toLowerCase();
    const admin = await this.adminRepository.findOne({
      where: {
        email: credentials.email.toLowerCase(),
      },
    });
    if (!admin) {
      throw new HttpErrors.Unauthorized(invalidCredentialsError);
    }
    admin.forgotToken = this.adminService.generateOTP();
    await this.adminRepository.updateById(admin.id, admin);
    await this.adminService.sendEmail(admin.email, admin.forgotToken);
    const message = `OTP sent to your email ${admin.email}`;
    responseData = {message};
    return responseData;
  }

  @post('/admins/reset-password', {
    responses: {
      '204': {
        description: 'Reset password',
        content: {
          'application/json': {
            schema: {
              type: 'object',
              properties: {message: {type: 'string'}},
            },
          },
        },
      },
    },
  })
  async resetPassword(
    @requestBody(ResetCredentialsRequestBody)
    credentials: ResetCredentials,
  ) {
    const invalidCredentialsError = 'Invalid OTP';
    let responseData: AnyObject = {};
    const admin = await this.adminRepository.findOne({
      where: {
        forgotToken: credentials.token,
      },
    });
    if (!admin) {
      throw new HttpErrors.Unauthorized(invalidCredentialsError);
    }
    admin.password = await this.passwordHasher.hashPassword(
      credentials.password,
    );
    admin.forgotToken = '';
    await this.adminRepository.updateById(admin.id, admin);
    const message = `Password reset successfully`;
    responseData = {message};
    return responseData;
  }

  @get('/admins/get-user-by-token', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Admin GET success',
      },
    },
  })
  async getUserByToken(
    @param.query.string('token') token: string,
  ): Promise<Admin> {
    if (!token) {
      throw new HttpErrors.Unauthorized('Invalid OTP');
    }
    const email = decrypt('mdoc_coach', token);
    const admin = await this.adminRepository.findOne({
      where: {
        email,
      },
      fields: {
        id: true,
        email: true,
        name: true,
        phoneNumber: true,
      },
    });
    if (!admin) {
      throw new HttpErrors[404]();
    }
    return admin;
  }

  @post('/admins/register', {
    responses: {
      '204': {
        description: 'Admin PATCH success',
      },
    },
  })
  async register(
    @requestBody({
      content: {
        'application/json': {
          properties: {token: {type: 'string'}},
        },
      },
    })
    admin: Admin,
  ): Promise<any> {
    let responseData: AnyObject = {};
    const oldAdmin = await this.adminRepository.findById(admin.id);

    if (!oldAdmin) {
      throw new HttpErrors[404]();
    }

    if (oldAdmin.status === 'active') {
      throw new HttpErrors[400]('User already registered');
    }

    admin.password = await this.passwordHasher.hashPassword(admin.password);
    admin.forgotToken = '';
    admin.status = 'active';

    const data = await this.adminRepository.updateById(admin.id, admin);
    const userProfile = {
      [securityId]: admin.id || '',
      name: admin.name || '',
      email: admin.email || '',
    };
    responseData = Object.assign({}, admin);
    const token = await this.jwtService.generateToken(userProfile);
    responseData.token = token;
    responseData.permissions = oldAdmin.permissions;
    return responseData;
  }

  @del('/admins/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Admin DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.adminRepository.deleteById(id);
  }

  @del('/admins/deactivate/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Admin deactivate success',
      },
    },
  })
  @authenticate('jwt')
  async deactivateUserById(
    @param.path.string('id') id: string,
  ): Promise<AnyObject> {
    const admin = await this.adminRepository.findById(id);

    if (!admin) {
      throw new HttpErrors[404]();
    }
    admin.status = 'deactivated';
    await this.adminRepository.updateById(admin.id, admin);
    const response = {
      message: `${admin.name} deactivated`,
    };
    return response;
  }
  @patch('/admins/activate/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Admin activate success',
      },
    },
  })
  @authenticate('jwt')
  async activateUserById(
    @param.path.string('id') id: string,
  ): Promise<AnyObject> {
    const admin = await this.adminRepository.findById(id);

    if (!admin) {
      throw new HttpErrors[404]();
    }
    admin.status = 'active';
    await this.adminRepository.updateById(admin.id, admin);
    const response = {
      message: `${admin.name} activated successfully`,
    };
    return response;
  }

  @post('/admins/change-password', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Admin activate success',
      },
    },
  })
  @authenticate('jwt')
  async changePassword(
    @requestBody({
      content: {
        'application/json': {
          properties: {token: {type: 'string'}},
        },
      },
    })
    body: {
      oldPassword: string;
      newPassword: string;
      userId: string;
    },
  ): Promise<AnyObject> {
    const responseData: AnyObject = {};

    const admin = await this.adminRepository.findById(body.userId);

    if (!admin) {
      throw HttpErrors[404];
    }

    const passwordMatched = await this.passwordHasher.comparePassword(
      body.oldPassword,
      admin.password || '',
    );

    if (!passwordMatched) {
      throw new HttpErrors.Unauthorized('Invalid password');
    }

    admin.password = await this.passwordHasher.hashPassword(body.newPassword);
    await this.adminRepository.updateById(body.userId, admin);
    return responseData;
  }
}
