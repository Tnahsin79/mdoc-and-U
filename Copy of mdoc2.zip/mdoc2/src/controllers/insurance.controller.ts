import { Count, CountSchema, Filter, repository, Where, } from '@loopback/repository';
import { post, param, get, getFilterSchemaFor, getModelSchemaRef, getWhereSchemaFor, patch, put, del, requestBody, } from '@loopback/rest';
import { Insurance } from '../models';
import { InsuranceRepository } from '../repositories';
import { OPERATION_SECURITY_SPEC } from '../utils/security-spec';
import { authenticate } from '@loopback/authentication';

export class InsuranceController {
  constructor(
    @repository(InsuranceRepository) public insuranceRepository: InsuranceRepository,
  ) { }

  @post('/insurances', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Insurance model instance',
        content: { 'application/json': { schema: getModelSchemaRef(Insurance) } },
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Insurance, {
            title: 'NewInsurance',
            exclude: ['id'],
          }),
        },
      },
    })
    insurance: Omit<Insurance, 'id'>,
  ): Promise<Insurance> {
    return this.insuranceRepository.create(insurance);
  }

  @get('/insurances/count', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Insurance model count',
        content: { 'application/json': { schema: CountSchema } },
      },
    },
  })
  @authenticate('jwt')
  async count(
    @param.query.object('where', getWhereSchemaFor(Insurance)) where?: Where<Insurance>,
  ): Promise<Count> {
    return this.insuranceRepository.count(where);
  }

  @get('/insurances', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of Insurance model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(Insurance, { includeRelations: true }),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async find(
    @param.query.object('filter', getFilterSchemaFor(Insurance)) filter?: Filter<Insurance>,
  ): Promise<Insurance[]> {
    return this.insuranceRepository.find(filter);
  }

  @patch('/insurances', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Insurance PATCH success count',
        content: { 'application/json': { schema: CountSchema } },
      },
    },
  })
  @authenticate('jwt')
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Insurance, { partial: true }),
        },
      },
    })
    insurance: Insurance,
    @param.query.object('where', getWhereSchemaFor(Insurance)) where?: Where<Insurance>,
  ): Promise<Count> {
    return this.insuranceRepository.updateAll(insurance, where);
  }

  @get('/insurances/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Insurance model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Insurance, { includeRelations: true }),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(Insurance)) filter?: Filter<Insurance>
  ): Promise<Insurance> {
    return this.insuranceRepository.findById(id, filter);
  }

  @patch('/insurances/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Insurance PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Insurance, { partial: true }),
        },
      },
    })
    insurance: Insurance,
  ): Promise<void> {
    await this.insuranceRepository.updateById(id, insurance);
  }

  @put('/insurances/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Insurance PUT success',
      },
    },
  })
  @authenticate('jwt')
  async replaceById(
    @param.path.string('id') id: string,
    @requestBody() insurance: Insurance,
  ): Promise<void> {
    await this.insuranceRepository.replaceById(id, insurance);
  }

  @del('/insurances/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Insurance DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.insuranceRepository.deleteById(id);
  }
}
