import {AnyObject, repository} from '@loopback/repository';
import _, {isEmpty} from 'lodash';
import {Socket} from 'socket.io';
import {
  UsersRepository,
  ChatRoomRepository,
  CoachRepository,
} from '../repositories';
import {ws} from '../websockets/decorators/websocket.decorator';
import {ChatRepository} from '../repositories';
import {inject} from '@loopback/core';
import {
  ChatRoomServiceBindings,
  ChatServiceWsBindings,
  FCMServiceBindings,
} from '../keys';
import {FCMService} from '../services/fcm.service';
import cron from 'node-cron';
import {ChatServiceWs} from '../services/chat.service.ws';
import {ChatRoomService} from '../services/chat-room.service';
import {authenticate} from '@loopback/authentication';
import {UserProfile, securityId, SecurityBindings} from '@loopback/security';

@ws({name: 'chatNsp', namespace: /^\/chats\/\d+$/})
export class ChatControllerWs {
  constructor(
    @ws.socket() private socket: Socket, // Equivalent to `@inject('ws.socket')`
    // @repository(MessageRepository) public messageRepository: MessageRepository,
    @repository(UsersRepository) public userRepository: UsersRepository,
    @repository(ChatRepository) public chatRepository: ChatRepository,
    @repository(ChatRoomRepository) public chatRoomRepository: ChatRepository,
    @inject(FCMServiceBindings.FCM_SERVICE) public fcmService: FCMService,
    @repository(CoachRepository) public coachRepository: CoachRepository,
    @inject(ChatServiceWsBindings.CHAT_WS_SERVICE)
    public chatServiceWS: ChatServiceWs,
    @inject(ChatRoomServiceBindings.CHAT_ROOM_SERVICE)
    public chatRoomService: ChatRoomService,
  ) {}

  /**
   * The method is invoked when a client connects to the server
   * @param socket
   */
  @ws.connect()
  connect(socket: Socket) {
    // console.log('Client connected to chat: %s', this.socket.id);
    socket.join('room 1');
  }

  /**
   * Register a handler for 'new_chat' events
   * @param msg
   */
  @ws.subscribe('new_chat')
  // @ws.emit('namespace' | 'requestor' | 'broadcast')
  async handleChatMessage(msg: unknown) {
    if (msg && typeof msg === 'string') {
      const msgObj = JSON.parse(msg);
      const isFirstMessage = msgObj?.isFirstMessage;
      const frontendId = msgObj?.frontendId;
      delete msgObj?.isFirstMessage;
      delete msgObj?.frontendId;
      const newChat = await this.chatServiceWS.createNewChat(msgObj);
      const response = JSON.stringify({...newChat, frontendId});
      if (isFirstMessage) {
        newChat?.chatRoom?.receiverIds?.forEach(
          async id =>
            await this.socket.nsp.to(id).emit('incoming_chat', `${response}`),
        );
      }
      await this.socket.nsp
        .to(newChat?.chatRoomId?.toString())
        .emit('incoming_chat', `${response}`);
    }
  }

  @ws.subscribe('read_chat_message')
  // @ws.emit('namespace' | 'requestor' | 'broadcast')
  async handleReadChatMessage(msg: unknown) {
    if (msg && typeof msg === 'string') {
      const payload: {chatId: string; userId: string} = JSON.parse(msg);
      const chat = await this.chatServiceWS.updateChatReaders(payload);
      this.socket.nsp
        .to(chat?.chatRoomId?.toString())
        .emit('incoming_read_chat_message', `${JSON.stringify(chat)}`);
    }
  }

  @ws.subscribe('new_chat_room')
  // @ws.emit('namespace' | 'requestor' | 'broadcast')
  async createRoom(msg: unknown) {
    if (msg && typeof msg === 'string') {
      const msgObj = JSON.parse(msg);
      const newRoom = await this.chatRoomService.create(msgObj);
      const response = JSON.stringify(newRoom);
      this.socket.join(newRoom?.id);

      if (newRoom?.creatorType === 'member') {
        this.socket.nsp
          .to(newRoom?.receiverCoachId?.toString())
          .emit('incoming_chat_room', `${response}`);
      }

      this.socket.nsp
        .to(newRoom?.creatorId?.toString())
        .emit('incoming_chat_room', `${response}`);
      // Emitting event to all online receivers
      newRoom.receiverIds.forEach(item => {
        this.socket.nsp
          .to(item?.toString())
          .emit('incoming_chat_room', `${response}`);
      });
    }
  }

  @ws.subscribe('join_chat_rooms')
  async joinRooms(msg: any) {
    if (msg && _.isString(msg)) {
      const roomIds = msg.split(',');
      this.socket.join(roomIds);
    }
  }

  @ws.subscribe('go_online')
  async goOnline(msg: any) {
    if (msg && _.isString(msg)) {
      const data: {id: string; type: 'coach' | 'user'} = JSON.parse(msg);
      const callback = (roomIds?: string[] | string) => {
        if (roomIds) {
          this.socket.join(roomIds)
        }
        this.socket.nsp.emit("online_user", data.id)
      };
      if (data.type === 'coach') {
        await this.chatServiceWS.goOnlineCoach(
          data.id,
          this.socket.id,
          callback,
        );
      } else {
        await this.chatServiceWS.goOnlineMember(data.id, this.socket.id, callback);
      }
    }
  }

  @ws.subscribe('ping')
  async ping(id: any) {
    if (id && _.isString(id)) {
       this.socket.emit("online_user", id)
    }
  }

  @ws.subscribe('go_offline')
  async goOffline(msg: any) {
    await this.chatServiceWS.goOffline(this.socket.id, 
      (id: string) => {
        this.socket.nsp.emit(`offline_user`, id);
        this.socket?.disconnect();
      },
    );
  }

  @ws.subscribe('groupChat message')
  // @ws.emit('namespace' | 'requestor' | 'broadcast')
  async handleGroupChatMessage(msg: unknown) {
    if (msg && _.isString(msg)) {
      let msgObj = JSON.parse(msg);
      const message = await this.chatServiceWS.createNewChat(msgObj);
      const emitMsg = JSON.stringify(message);
      this.socket.nsp.emit('groupChat message', `${emitMsg}`);
    }
  }

  @ws.subscribe('new_broadcast_message')
  async sendBroadcast(msg: string) {
    const msgObj = JSON.parse(msg);
    return await this.chatServiceWS.createBroadcastMessage(
      msg,
      (chat, userId) => {
        this.socket.nsp
          .to(userId)
          .emit('incoming_chat', `${JSON.stringify(chat)}`);
        this.socket.nsp
          .to(msgObj?.coachId)
          .emit('incoming_chat', `${JSON.stringify(chat)}`);
      },
    );
  }

  /**
   * Register a handler for all events
   * @param msg
   */
  @ws.subscribe(/.+/)
  logMessage(...args: unknown[]) {
    // console.log('Message: %s', args);
  }

  /**
   * The method is invoked when a client disconnects from the server
   * @param socket
   */
  @ws.disconnect()
  async disconnect() {
    // console.log('Client disconnected: %s', this.socket.id);
    await this.chatServiceWS.goOffline(
      this.socket.id,
      (id: string) => {
        this.socket.nsp.emit(`offline_user`, id);
        this.socket?.disconnect();
      },
    ); 
  }
}
