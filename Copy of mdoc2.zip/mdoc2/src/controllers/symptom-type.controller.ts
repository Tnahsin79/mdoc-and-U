import {
  Count,
  CountSchema,
  Filter,
  repository,
  Where,
  AnyObject,
} from '@loopback/repository';
import {
  post,
  param,
  get,
  getFilterSchemaFor,
  getModelSchemaRef,
  getWhereSchemaFor,
  patch,
  put,
  del,
  requestBody,
} from '@loopback/rest';
import {SymptomTypes} from '../models';
import {
  SymptomTypesRepository,
  SymptomHealthConditionRepository,
  DiseaseRepository,
} from '../repositories';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';
import {authenticate} from '@loopback/authentication';
import * as _ from 'lodash';
import {SymptomTypeServiceBindings} from '../keys';
import {SymptomTypeService} from '../services/symptom-type.service';
import {inject} from '@loopback/core';
export class SymptomTypeController {
  constructor(
    @repository(SymptomTypesRepository)
    public symptomTypesRepository: SymptomTypesRepository,
    @repository(SymptomHealthConditionRepository)
    public symptomHealthConditionRepository: SymptomHealthConditionRepository,
    @repository(DiseaseRepository) public diseaseRepository: DiseaseRepository,
    @inject(SymptomTypeServiceBindings.SYMPTOM_TYPE_SERVICE)
    public symptomTypesService: SymptomTypeService,
  ) {}

  @post('/symptom-types', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'SymptomTypes model instance',
        content: {
          'application/json': {schema: getModelSchemaRef(SymptomTypes)},
        },
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(SymptomTypes, {
            title: 'NewSymptomTypes',
            exclude: ['id'],
          }),
        },
      },
    })
    symptomTypes: Omit<SymptomTypes, 'id'>,
  ): Promise<SymptomTypes> {
    return this.symptomTypesRepository.create(symptomTypes);
  }

  @get('/symptom-types/count', {
    responses: {
      '200': {
        description: 'SymptomTypes model count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async count(
    @param.query.object('where', getWhereSchemaFor(SymptomTypes))
    where?: Where<SymptomTypes>,
  ): Promise<Count> {
    return this.symptomTypesRepository.count(where);
  }

  @get('/symptom-types', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of SymptomTypes model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(SymptomTypes, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async find(
    @param.query.object('filter', getFilterSchemaFor(SymptomTypes))
    filter?: AnyObject,
    @param.query.number('page') page?: number,
  ): Promise<SymptomTypes[] | AnyObject> {
    return this.symptomTypesService.find(filter, page);
  }

  @patch('/symptom-types', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'SymptomTypes PATCH success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  @authenticate('jwt')
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(SymptomTypes, {partial: true}),
        },
      },
    })
    symptomTypes: SymptomTypes,
    @param.query.object('where', getWhereSchemaFor(SymptomTypes))
    where?: Where<SymptomTypes>,
  ): Promise<Count> {
    return this.symptomTypesRepository.updateAll(symptomTypes, where);
  }

  @get('/symptom-types/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'SymptomTypes model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(SymptomTypes, {includeRelations: true}),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(SymptomTypes))
    filter?: Filter<SymptomTypes>,
  ): Promise<SymptomTypes> {
    return this.symptomTypesRepository.findById(id, filter);
  }

  @patch('/symptom-types/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'SymptomTypes PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(SymptomTypes, {partial: true}),
        },
      },
    })
    symptomTypes: SymptomTypes,
  ): Promise<void> {
    await this.symptomTypesRepository.updateById(id, symptomTypes);
  }

  @put('/symptom-types/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'SymptomTypes PUT success',
      },
    },
  })
  @authenticate('jwt')
  async replaceById(
    @param.path.string('id') id: string,
    @requestBody() symptomTypes: SymptomTypes,
  ): Promise<void> {
    await this.symptomTypesRepository.replaceById(id, symptomTypes);
  }

  @del('/symptom-types/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'SymptomTypes DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.symptomTypesRepository.deleteById(id);
  }

  @get('/symptom-types/getSymptomTypes/', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'SymptomTypes  success',
      },
    },
  })
  @authenticate('jwt')
  async getSymptomTypes(): Promise<any> {
    let responseData: AnyObject = {};

    const disease = await this.diseaseRepository.find({
      fields: {id: true, name: true},
      order: ['name ASC'],
    });
    // if (disease && disease.length) {
    //   let ids: Array<any> = _.map(disease, v => v.id);

    //   return Promise.all([
    //     this.symptomHealthConditionRepository.find({
    //       fields: {id: true, name: true, emoji: true},
    //       order: ['name ASC'],
    //     }),
    //   ])
    //     .then(res => {
    //       // let healthCondition = res && res[0] && res[0].length && _.groupBy(res[0], v => v.diseaseId)

    //       // _.forEach(symptomType, function (val: any) {
    //       //   let obj = Object.assign({}, val)
    //       //   obj.healthCondition = healthCondition && healthCondition[val.id] && healthCondition[val.id].length && healthCondition[val.id] || []

    //       //   responseData.push(obj)
    //       // })
    //       // responseData.push(symptomType, { healthCondition: res[0] })
    //       responseData.symptomType = _.cloneDeep(disease);
    //       responseData.healthCondition = _.cloneDeep(
    //         (res[0] && res[0].length && res[0]) || [],
    //       );

    //       return responseData;
    //     })
    //     .catch(err => {
    //       throw err;
    //     });
    // } else {
    //   return [];
    // }
  }
}
