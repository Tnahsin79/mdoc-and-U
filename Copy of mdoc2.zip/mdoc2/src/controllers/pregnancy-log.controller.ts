import {
  post,
  param,
  get,
  getModelSchemaRef,
  patch,
  del,
  requestBody,
  getFilterSchemaFor,
} from '@loopback/rest';
import {inject} from '@loopback/core';
import {PregnancyLog} from '../models';
import {Filter} from '@loopback/repository';
import {PregnancyLogService} from '../services';
import {PaginatedResponse} from '../type-schema';
import {PregnancyLogServiceBindings} from '../keys';
import {authenticate} from '@loopback/authentication';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';

export class PregnancyLogController {
  constructor(
    @inject(PregnancyLogServiceBindings.PREGNANCY_LOG)
    public pregnancyLogService: PregnancyLogService,
  ) {}
  @post('/pregnancy-log', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'PregnancyLog model instance',
        content: {
          'application/json': {schema: getModelSchemaRef(PregnancyLog)},
        },
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(PregnancyLog, {
            title: 'NewPregnancyLog',
            exclude: ['id'],
          }),
        },
      },
    })
    pregnancyLog: Omit<PregnancyLog, 'id'>,
  ): Promise<PregnancyLog> {
    return this.pregnancyLogService.create(pregnancyLog);
  }

  @get('/pregnancy-log', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of PregnancyLog model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(PregnancyLog, {
                includeRelations: true,
              }),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findAll(
    @param.query.object('filter', getFilterSchemaFor(PregnancyLog))
    filter?: Filter<PregnancyLog>,
    @param.query.number('page') page?: number,
  ): Promise<PaginatedResponse<PregnancyLog>> {
    return this.pregnancyLogService.findAll(filter, page);
  }

  @get('/pregnancy-log/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'PregnancyLog model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(PregnancyLog, {includeRelations: true}),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(PregnancyLog))
    filter?: Filter<PregnancyLog>,
  ) {
    return this.pregnancyLogService.findById(id, filter);
  }

  @patch('/pregnancy-log/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'PregnancyLog PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(PregnancyLog, {partial: true}),
        },
      },
    })
    pregnancyLog: PregnancyLog,
  ): Promise<void> {
    return await this.pregnancyLogService.updateById(id, pregnancyLog);
  }

  @del('/pregnancy-log/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'PregnancyLog DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    return this.pregnancyLogService.deleteById(id);
  }
}
