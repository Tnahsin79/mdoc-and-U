import {
  Count,
  CountSchema,
  Filter,
  repository,
  Where,
} from '@loopback/repository';
import {
  post,
  param,
  get,
  getFilterSchemaFor,
  getModelSchemaRef,
  getWhereSchemaFor,
  patch,
  put,
  del,
  requestBody,
} from '@loopback/rest';
import {Language} from '../models';
import {LanguageRepository} from '../repositories';

export class LanguageController {
  constructor(
    @repository(LanguageRepository)
    public languageRepository : LanguageRepository,
  ) {}

  @post('/languages', {
    responses: {
      '200': {
        description: 'Language model instance',
        content: {'application/json': {schema: getModelSchemaRef(Language)}},
      },
    },
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Language, {
            title: 'NewLanguage',
            exclude: ['id'],
          }),
        },
      },
    })
    language: Omit<Language, 'id'>,
  ): Promise<Language> {
    return this.languageRepository.create(language);
  }

  @get('/languages/count', {
    responses: {
      '200': {
        description: 'Language model count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async count(
    @param.query.object('where', getWhereSchemaFor(Language)) where?: Where<Language>,
  ): Promise<Count> {
    return this.languageRepository.count(where);
  }

  @get('/languages', {
    responses: {
      '200': {
        description: 'Array of Language model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(Language, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  async find(
    @param.query.object('filter', getFilterSchemaFor(Language)) filter?: Filter<Language>,
  ): Promise<Language[]> {
    return this.languageRepository.find(filter);
  }

  @patch('/languages', {
    responses: {
      '200': {
        description: 'Language PATCH success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Language, {partial: true}),
        },
      },
    })
    language: Language,
    @param.query.object('where', getWhereSchemaFor(Language)) where?: Where<Language>,
  ): Promise<Count> {
    return this.languageRepository.updateAll(language, where);
  }

  @get('/languages/{id}', {
    responses: {
      '200': {
        description: 'Language model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Language, {includeRelations: true}),
          },
        },
      },
    },
  })
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(Language)) filter?: Filter<Language>
  ): Promise<Language> {
    return this.languageRepository.findById(id, filter);
  }

  @patch('/languages/{id}', {
    responses: {
      '204': {
        description: 'Language PATCH success',
      },
    },
  })
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Language, {partial: true}),
        },
      },
    })
    language: Language,
  ): Promise<void> {
    await this.languageRepository.updateById(id, language);
  }

  @put('/languages/{id}', {
    responses: {
      '204': {
        description: 'Language PUT success',
      },
    },
  })
  async replaceById(
    @param.path.string('id') id: string,
    @requestBody() language: Language,
  ): Promise<void> {
    await this.languageRepository.replaceById(id, language);
  }

  @del('/languages/{id}', {
    responses: {
      '204': {
        description: 'Language DELETE success',
      },
    },
  })
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.languageRepository.deleteById(id);
  }
}
