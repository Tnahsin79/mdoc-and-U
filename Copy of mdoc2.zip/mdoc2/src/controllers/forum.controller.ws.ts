import _ from 'lodash';
import {Socket} from 'socket.io';
import {inject} from '@loopback/core';
import {repository} from '@loopback/repository';
import {FCMService} from '../services/fcm.service';
import {CommentService} from '../services/comment.service';
import {ws} from '../websockets/decorators/websocket.decorator';
import {UsersRepository, CoachRepository} from '../repositories';
import {CommentServiceBindings, FCMServiceBindings} from '../keys';

@ws({name: 'forumNsp', namespace: /^\/forum\/\d+$/})
export class ForumControllerWs {
  constructor(
    @ws.socket() private socket: Socket, // Equivalent to `@inject('ws.socket')`
    @repository(UsersRepository) public userRepository: UsersRepository,
    @inject(FCMServiceBindings.FCM_SERVICE) public fcmService: FCMService,
    @repository(CoachRepository) public coachRepository: CoachRepository,
    @inject(CommentServiceBindings.COMMENT_SERVICE)
    public commentService: CommentService,
  ) {}

  /**
   * The method is invoked when a client connects to the server
   * @param socket
   */
  @ws.connect()
  connect(socket: Socket) {
    console.log('Client connected to forums: %s', this.socket.id);
  }

  /**
   * Register a handler for 'new_comment' events
   * @param msg
   */
  @ws.subscribe('new_comment')
  async handleNewComment(msg: unknown) {
    console.log('received new comment');
    if (msg && typeof msg === 'string') {
      const comment = JSON.parse(msg);
      const {
        newComment,
        status,
        error,
      } = await this.commentService.createComment(comment);
      const response = JSON.stringify(newComment);
      this.socket.nsp
        .to(newComment?.forumId?.toString())
        .emit('incoming_comment', response);
    }
  }

  @ws.subscribe('read_forum_comment')
  async handleReadForumMessage(msg: unknown) {
    if (msg && typeof msg === 'string') {
      const payload: {commentId: string; userId: string} = JSON.parse(msg);
      const comment = await this.commentService.updateCommentReaders(payload);
      this.socket.nsp
        .to(comment?.forumId?.toString())
        .emit('incoming_read_comment', `${JSON.stringify(comment)}`);
    }
  }

  @ws.subscribe('join_rooms')
  async joinRooms(msg: any) {
    if (msg && _.isString(msg)) {
      const roomIds = msg.split(',');
      console.log('roomIds: ', roomIds);
      this.socket.join(roomIds, err => console.log('error joining: ', err));
    }
  }

  /**
   * Register a handler for all events
   * @param msg
   */
  @ws.subscribe(/.+/)
  logMessage(...args: unknown[]) {
    console.log('Message: %s', args);
  }

  /**
   * The method is invoked when a client disconnects from the server
   * @param socket
   */
  @ws.disconnect()
  disconnect() {
    console.log('Client disconnected: %s', this.socket.id);
  }
}
