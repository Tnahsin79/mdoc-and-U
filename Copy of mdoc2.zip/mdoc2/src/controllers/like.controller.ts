import {
  get,
  del,
  post,
  param,
  patch,
  requestBody,
  getModelSchemaRef,
  getWhereSchemaFor,
  getFilterSchemaFor,
} from '@loopback/rest';
import Utils from '../utils';
import {Like} from '../models';
import {inject} from '@loopback/context';
import {LikeServiceBindings} from '../keys';
import {PaginatedResponse} from '../type-schema';
import {LikeService} from '../services/like.service';
import {authenticate} from '@loopback/authentication';
import {OPERATION_SECURITY_SPEC} from '../utils/security-spec';
import {Count, Where, Filter, CountSchema} from '@loopback/repository';
export class LikeController {
  constructor(
    @inject(LikeServiceBindings.LIKE_SERVICE)
    public likeService: LikeService,
  ) {}

  @post('/likes', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Like model instance',
        content: {'application/json': {schema: getModelSchemaRef(Like)}},
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Like, {
            title: 'NewLike',
            exclude: ['id'],
          }),
        },
      },
    })
    like: Omit<Like, 'id'>,
  ): Promise<any> {
    return await this.likeService.create(like);
  }

  @get('/likes/count', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Like model count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  @authenticate('jwt')
  async count(
    @param.query.object('where', getWhereSchemaFor(Like)) where?: Where<Like>,
  ): Promise<Count> {
    return await this.likeService.getLikeCount(where);
  }

  @get('/likes', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of Like model instances',
        content: {
          'application/json': {
            schema: Utils.paginatedSchema(Like, true),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async find(
    @param.query.object('filter', getFilterSchemaFor(Like))
    filter?: Filter<Like>,
    @param.query.number('page') page?: number,
  ): Promise<PaginatedResponse<Like>> {
    return await this.likeService.find(filter, page);
  }

  @get('/likes/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Like model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Like, {includeRelations: true}),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(Like))
    filter?: Filter<Like>,
  ): Promise<Like> {
    return await this.likeService.findById(id, filter);
  }

  @patch('/likes/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Like PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Like, {
            partial: true,
            exclude: ['id', 'created'],
          }),
        },
      },
    })
    like: Like,
  ): Promise<void> {
    await this.likeService.updateById(id, like);
  }

  @del('/likes/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'Like DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.likeService.deleteById(id);
  }
}
