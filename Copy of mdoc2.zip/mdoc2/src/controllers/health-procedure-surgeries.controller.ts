import { Count, CountSchema, Filter, repository, Where, } from '@loopback/repository';
import { post, param, get, getFilterSchemaFor, getModelSchemaRef, getWhereSchemaFor, patch, put, del, requestBody, } from '@loopback/rest';
import { HealthProcedureSurgeries } from '../models';
import { HealthProcedureSurgeriesRepository } from '../repositories';
import { OPERATION_SECURITY_SPEC } from '../utils/security-spec';
import { authenticate } from '@loopback/authentication';
import { inject } from '@loopback/context';
import { MigrationServiceBindings } from '../keys';
import { MigrationService } from '../services/migration.service';
import csv from 'csvtojson'
export class HealthProcedureSurgeriesController {
  constructor(
    @repository(HealthProcedureSurgeriesRepository) public healthProcedureSurgeriesRepository: HealthProcedureSurgeriesRepository,
    @inject(MigrationServiceBindings.MIGRATION_SERVICE) public migrationService: MigrationService
  ) { }

  @post('/health-procedure-surgeries', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'HealthProcedureSurgeries model instance',
        content: { 'application/json': { schema: getModelSchemaRef(HealthProcedureSurgeries) } },
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(HealthProcedureSurgeries, {
            title: 'NewHealthProcedureSurgeries',
            exclude: ['id'],
          }),
        },
      },
    })
    healthProcedureSurgeries: Omit<HealthProcedureSurgeries, 'id'>,
  ): Promise<any> {
    healthProcedureSurgeries.isHealthProcedureComplete = true
    const procuders = await this.healthProcedureSurgeriesRepository.create(healthProcedureSurgeries);
    const procudereSurgeries = await this.healthProcedureSurgeriesRepository.findOne({
      where: {
        id: procuders.id
      },
      include: [
        { relation: "procedure" }
      ]
    })
    return procudereSurgeries
  }

  @get('/health-procedure-surgeries/count', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'HealthProcedureSurgeries model count',
        content: { 'application/json': { schema: CountSchema } },
      },
    },
  })
  @authenticate('jwt')
  async count(
    @param.query.object('where', getWhereSchemaFor(HealthProcedureSurgeries)) where?: Where<HealthProcedureSurgeries>,
  ): Promise<Count> {
    return this.healthProcedureSurgeriesRepository.count(where);
  }

  @get('/health-procedure-surgeries', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'Array of HealthProcedureSurgeries model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(HealthProcedureSurgeries, { includeRelations: true }),
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async find(
    @param.query.object('filter', getFilterSchemaFor(HealthProcedureSurgeries)) filter?: Filter<HealthProcedureSurgeries>,
  ): Promise<HealthProcedureSurgeries[]> {
    return this.healthProcedureSurgeriesRepository.find({where: filter?.where, include: [{relation: 'procedure'}]});
  }

  @patch('/health-procedure-surgeries', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'HealthProcedureSurgeries PATCH success count',
        content: { 'application/json': { schema: CountSchema } },
      },
    },
  })
  @authenticate('jwt')
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(HealthProcedureSurgeries, { partial: true }),
        },
      },
    })
    healthProcedureSurgeries: HealthProcedureSurgeries,
    @param.query.object('where', getWhereSchemaFor(HealthProcedureSurgeries)) where?: Where<HealthProcedureSurgeries>,
  ): Promise<Count> {
    return this.healthProcedureSurgeriesRepository.updateAll(healthProcedureSurgeries, where);
  }

  @get('/health-procedure-surgeries/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'HealthProcedureSurgeries model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(HealthProcedureSurgeries, { includeRelations: true }),
          },
        },
      },
    },
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(HealthProcedureSurgeries)) filter?: Filter<HealthProcedureSurgeries>
  ): Promise<HealthProcedureSurgeries> {
    return this.healthProcedureSurgeriesRepository.findById(id, filter);
  }

  @patch('/health-procedure-surgeries/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'HealthProcedureSurgeries PATCH success',
      },
    },
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(HealthProcedureSurgeries, { partial: true }),
        },
      },
    })
    healthProcedureSurgeries: HealthProcedureSurgeries,
  ): Promise<void> {
    await this.healthProcedureSurgeriesRepository.updateById(id, healthProcedureSurgeries);
  }

  @put('/health-procedure-surgeries/{id}', {
    responses: {
      '204': {
        description: 'HealthProcedureSurgeries PUT success',
      },
    },
  })
  async replaceById(
    @param.path.string('id') id: string,
    @requestBody() healthProcedureSurgeries: HealthProcedureSurgeries,
  ): Promise<void> {
    await this.healthProcedureSurgeriesRepository.replaceById(id, healthProcedureSurgeries);
  }

  @del('/health-procedure-surgeries/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '204': {
        description: 'HealthProcedureSurgeries DELETE success',
      },
    },
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.healthProcedureSurgeriesRepository.deleteById(id);
  }

  @get('/healthProcedureSurgeriesMigration', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      '200': {
        description: 'HealthProcedureSurgeries Migration instance',
      },
    },
  })
  @authenticate('jwt')
  async healthProcedureSurgeries(
  ): Promise<any> {
    const filePath = './public/procedures_surgery_history.csv'

    let procedure = await csv().fromFile(filePath);
    if (procedure && procedure.length) {
      for (let [index, value] of procedure.entries()) {
        await this.migrationService.healthProcedureSurgeryMigration(value)
      }
    }
  }
}
