import { authenticate } from '@loopback/authentication';
import { Count, CountSchema, Filter, repository, Where, } from '@loopback/repository';
import { post, param, get, getModelSchemaRef, patch, put, del, requestBody, getFilterSchemaFor } from '@loopback/rest';
import { OutlierLogs } from '../models';
import { OutlierLogsRepository } from '../repositories';
import { OPERATION_SECURITY_SPEC } from '../utils/security-spec';
import csv from 'csvtojson'
import { inject } from '@loopback/core';
import { MigrationServiceBindings } from '../keys';
import { MigrationService } from '../services/migration.service';

export class OutlierLogsController {
  constructor(
    @repository(OutlierLogsRepository) public outlierLogsRepository: OutlierLogsRepository,
    @inject(MigrationServiceBindings.MIGRATION_SERVICE) public migrationService: MigrationService
  ) { }

  @post('/outlier-logs', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'OutlierLogs model instance',
        content: { 'application/json': { schema: getModelSchemaRef(OutlierLogs) } },
      },
    },
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(OutlierLogs, {
            title: 'NewOutlierLogs',
            exclude: ['id'],
          }),
        },
      },
    })
    outlierLogs: Omit<OutlierLogs, 'id'>,
  ): Promise<OutlierLogs> {
    return this.outlierLogsRepository.create(outlierLogs);
  }

  @get('/outlier-logs/count', {
    responses: {
      200: {
        description: 'OutlierLogs model count',
        content: { 'application/json': { schema: CountSchema } },
      },
    }
  })
  async count(
    // @param.where(OutlierLogs) where?: Where<OutlierLogs>,
  ): Promise<Count> {
    return this.outlierLogsRepository.count();
  }

  @get('/outlier-logs', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'Array of OutlierLogs model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(OutlierLogs, { includeRelations: true }),
            },
          },
        },
      },
    }
  })
  @authenticate('jwt')
  async find(
    @param.query.object('filter', getFilterSchemaFor(OutlierLogs)) filter?: Filter<OutlierLogs>,
  ): Promise<OutlierLogs[]> {
    return this.outlierLogsRepository.find(filter);
  }

  // @patch('/outlier-logs')
  // @response(200, {
  //   description: 'OutlierLogs PATCH success count',
  //   content: { 'application/json': { schema: CountSchema } },
  // })
  // async updateAll(
  //   @requestBody({
  //     content: {
  //       'application/json': {
  //         schema: getModelSchemaRef(OutlierLogs, { partial: true }),
  //       },
  //     },
  //   })
  //   outlierLogs: OutlierLogs,
  //   @param.where(OutlierLogs) where?: Where<OutlierLogs>,
  // ): Promise<Count> {
  //   return this.outlierLogsRepository.updateAll(outlierLogs, where);
  // }

  @get('/outlier-logs/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'OutlierLogs model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(OutlierLogs, { includeRelations: true }),
          },
        },
      },
    }
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(OutlierLogs)) filter?: Filter<OutlierLogs>,
  ): Promise<OutlierLogs> {
    return this.outlierLogsRepository.findById(id, filter);
  }

  @patch('/outlier-logs/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      204: {
        description: 'OutlierLogs PATCH success',
      },
    }
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(OutlierLogs, { partial: true }),
        },
      },
    })
    outlierLogs: OutlierLogs,
  ): Promise<void> {
    await this.outlierLogsRepository.updateById(id, outlierLogs);
  }

  // @put('/outlier-logs/{id}')
  // @response(204, {
  //   description: 'OutlierLogs PUT success',
  // })
  // async replaceById(
  //   @param.path.string('id') id: string,
  //   @requestBody() outlierLogs: OutlierLogs,
  // ): Promise<void> {
  //   await this.outlierLogsRepository.replaceById(id, outlierLogs);
  // }

  @del('/outlier-logs/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      204: {
        description: 'OutlierLogs DELETE success',
      },
    }
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.outlierLogsRepository.deleteById(id);
  }
}
