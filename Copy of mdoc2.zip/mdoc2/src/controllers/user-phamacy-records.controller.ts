import { authenticate } from '@loopback/authentication';
import { inject } from '@loopback/core';
import { Count, CountSchema, Filter, repository, Where, } from '@loopback/repository';
import { post, param, get, getModelSchemaRef, patch, put, del, requestBody, getFilterSchemaFor } from '@loopback/rest';
import { MigrationServiceBindings } from '../keys';
import { UserPhamacyRecords } from '../models';
import { UserPhamacyRecordsRepository } from '../repositories';
import { MigrationService } from '../services/migration.service';
import { OPERATION_SECURITY_SPEC } from '../utils/security-spec';
import csv from 'csvtojson'

export class UserPhamacyRecordsController {
  constructor(
    @repository(UserPhamacyRecordsRepository) public userPhamacyRecordsRepository: UserPhamacyRecordsRepository,
    @inject(MigrationServiceBindings.MIGRATION_SERVICE) public migrationService: MigrationService
  ) { }

  @post('/user-phamacy-records', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'UserPhamacyRecords model instance',
        content: { 'application/json': { schema: getModelSchemaRef(UserPhamacyRecords) } },
      },
    }
  })
  @authenticate('jwt')
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(UserPhamacyRecords, {
            title: 'NewUserPhamacyRecords',
            exclude: ['id'],
          }),
        },
      },
    })
    userPhamacyRecords: Omit<UserPhamacyRecords, 'id'>,
  ): Promise<UserPhamacyRecords> {
    return this.userPhamacyRecordsRepository.create(userPhamacyRecords);
  }

  // @get('/user-phamacy-records/count')
  // @response(200, {
  //   description: 'UserPhamacyRecords model count',
  //   content: { 'application/json': { schema: CountSchema } },
  // })
  // async count(
  //   @param.where(UserPhamacyRecords) where?: Where<UserPhamacyRecords>,
  // ): Promise<Count> {
  //   return this.userPhamacyRecordsRepository.count(where);
  // }

  @get('/user-phamacy-records', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'Array of UserPhamacyRecords model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(UserPhamacyRecords, { includeRelations: true }),
            },
          },
        },
      },
    }
  })
  @authenticate('jwt')
  async find(
    @param.query.object('filter', getFilterSchemaFor(UserPhamacyRecords)) filter?: Filter<UserPhamacyRecords>,
  ): Promise<UserPhamacyRecords[]> {
    return this.userPhamacyRecordsRepository.find(filter);
  }

  // @patch('/user-phamacy-records')
  // @response(200, {
  //   description: 'UserPhamacyRecords PATCH success count',
  //   content: { 'application/json': { schema: CountSchema } },
  // })
  // async updateAll(
  //   @requestBody({
  //     content: {
  //       'application/json': {
  //         schema: getModelSchemaRef(UserPhamacyRecords, { partial: true }),
  //       },
  //     },
  //   })
  //   userPhamacyRecords: UserPhamacyRecords,
  //   @param.where(UserPhamacyRecords) where?: Where<UserPhamacyRecords>,
  // ): Promise<Count> {
  //   return this.userPhamacyRecordsRepository.updateAll(userPhamacyRecords, where);
  // }

  @get('/user-phamacy-records/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      200: {
        description: 'UserPhamacyRecords model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(UserPhamacyRecords, { includeRelations: true }),
          },
        },
      },
    }
  })
  @authenticate('jwt')
  async findById(
    @param.path.string('id') id: string,
    @param.query.object('filter', getFilterSchemaFor(UserPhamacyRecords)) filter?: Filter<UserPhamacyRecords>,
  ): Promise<UserPhamacyRecords> {
    return this.userPhamacyRecordsRepository.findById(id, filter);
  }

  @patch('/user-phamacy-records/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      204: {
        description: 'UserPhamacyRecords PATCH success',
      },
    }
  })
  @authenticate('jwt')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(UserPhamacyRecords, { partial: true }),
        },
      },
    })
    userPhamacyRecords: UserPhamacyRecords,
  ): Promise<void> {
    await this.userPhamacyRecordsRepository.updateById(id, userPhamacyRecords);
  }

  // @put('/user-phamacy-records/{id}')
  // @response(204, {
  //   description: 'UserPhamacyRecords PUT success',
  // })
  // async replaceById(
  //   @param.path.string('id') id: string,
  //   @requestBody() userPhamacyRecords: UserPhamacyRecords,
  // ): Promise<void> {
  //   await this.userPhamacyRecordsRepository.replaceById(id, userPhamacyRecords);
  // }

  @del('/user-phamacy-records/{id}', {
    security: OPERATION_SECURITY_SPEC,
    responses: {
      204: {
        description: 'UserPhamacyRecords DELETE success',
      },
    }
  })
  @authenticate('jwt')
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.userPhamacyRecordsRepository.deleteById(id);
  }

  @get('/userPhamacyRecordsMigration', {
    responses: {
      200: {
        description: 'UserPhamacyRecords Migration success',
      },
    }
  })
  async userPhamacyRecordsMigration():
    Promise<any> {
    const filePath = './public/user_phamacy_record.csv'

    let usersPhamacyList = await csv().fromFile(filePath);
    if (usersPhamacyList && usersPhamacyList.length) {
      for (const value of usersPhamacyList) {
        await this.migrationService.userPhamacyRecordsMigration(value)
      }
    }
  }
}
