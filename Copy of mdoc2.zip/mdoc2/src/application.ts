import {BootMixin} from '@loopback/boot';
import {ApplicationConfig, BindingKey} from '@loopback/core';
import {
  RestExplorerBindings,
  RestExplorerComponent,
} from '@loopback/rest-explorer';
import {RepositoryMixin} from '@loopback/repository';
// import {ComponentsObject} from '@loopback/rest';
import {ServiceMixin} from '@loopback/service-proxy';
import path from 'path';
//import { AuthenticationSequence } from './sequence';
import {JWTAuthenticationStrategy} from './authentication-strategies/jwt-strategy';
import {
  AuthenticationComponent,
  registerAuthenticationStrategy,
} from '@loopback/authentication';
import {MySequence} from './sequence';
import {
  TokenServiceBindings,
  UserServiceBindings,
  UserServiceExtensionBindings,
  TokenServiceConstants,
  PasswordHasherBindings,
  EmailServiceBindings,
  PdfServiceBindings,
  ControllerServiceBindings,
  FCMServiceBindings,
  MigrationServiceBindings,
  MigrationServiceV2Bindings,
  HealthDairyMigrationServiceBindings,
  AdminServiceBindings,
  AppReleaseServiceBindings,
  ReferralReasonServiceBindings,
  HealthDiaryServiceBindings,
  CoachServiceBindings,
  AppointmentServiceBindings,
  FrequencyServiceBindings,
  ProgramsServiceBindings,
  SpecialityServiceBindings,
  NoteServiceBindings,
  CommunicationLogServiceBindings,
  BroadcastMessageServiceBinding,
  BroadcastGroupServiceBinding,
  UserSubscriptionsServiceBindings,
  HealthConditionServiceBindings,
  AffordablityServiceBindings,
  BasicHealthInformationServiceBindings,
  BlaServiceBindings,
  BlockedUsersServiceBindings,
  CategoryServiceBindings,
  ChampionsServiceBindings,
  ChatRoomServiceBindings,
  ChatServiceBindings,
  ChildrenServiceBindings,
  CoachTypeServiceBindings,
  CouponsServiceBindings,
  DiseaseServiceBindings,
  ExerciseTypesServiceBindings,
  ExercisesServiceBindings,
  EyeExaminationServiceBindings,
  FootExaminationServiceBindings,
  HealthProcedureSurgeriesServiceBindings,
  HealthQuestionServiceBindings,
  InsuranceServiceBindings,
  InterestSeviceBindings,
  JournalServiceBindings,
  LabServiceBindings,
  LabsProceduresServiceBindings,
  LanguageServiceBindings,
  LikeServiceBindings,
  MedicationPassportServiceBindings,
  MedicationServiceBindings,
  MyAssessmentsInformationServiceBindings,
  MyAssessmentsServiceBindings,
  NotificationServiceBindings,
  NudgeHubsServiceBindings,
  OutlierLogsServiceBindings,
  PatientServiceBindings,
  PaymentsServiceBindings,
  PlansServiceBindings,
  BlogPostServiceBindings,
  ProjectsCategoryServiceBindings,
  ProviderServiceBindings,
  ReminderServiceBindings,
  ResourcesServiceBindings,
  ReviewServiceBindings,
  SubscriptionServiceBindings,
  SymptomHealthConditionServiceBindings,
  SymptomTypeServiceBindings,
  SymptomsServiceBindings,
  TagServiceBindings,
  TreatmentServiceBindings,
  UserDoctorsServiceBindings,
  UserLocationsServiceBindings,
  UserPharmacyRecordsServiceBindings,
  WaistgoalServiceBindings,
  WebinarServiceBindings,
  ReportCommentServiceBindings,
  ReportPostServiceBindings,
  CommentServiceBindings,
  WaistCirumferenceServiceBindings,
  HbaicServiceBindings,
  CholestrolServiceBindings,
  BloodPressureServiceBindings,
  BloodSugarServiceBindings,
  PsaServiceBindings,
  WeightServiceBindings,
  HeightServiceBindings,
  CoachUserSubscriptionsServiceBindings,
  ForumServiceBindings,
  ForumUserServiceBindings,
  PregnancyCycleServiceBindings,
  PregnancyLogServiceBindings,
  ExerciseServiceBindings,
  ChatServiceWsBindings,
  QuestionServiceBindings,
  PrivilegeGroupServiceBindings,
  PrivilegeServiceBindings,
  RoleServiceBindings,
  ReferralServiceBindings,
  CommentReplyServiceBindings,
  CalenderEventServiceBindings,
  FeedbackServiceBindings,
  UserFeedbackServiceBindings,
  ActivityTimelineServiceBindings,
  UserMentalAssessmentServiceBindings,
  VoucherServiceBindings,
  ProcedureListServiceBindings,
  OutlierServiceBindings,
  DashboardStatisticsServiceBindings,
  BmiServiceBindings,
  KemMessageSerivceBindings,
  ProductServiceBindings,
  TemperatureServiceBindings,
  ConsultServiceBindings,
  HubVisitServiceBindings,
  PartnerServiceBindings,
  ThroveSerivceBindings,
  CareerServiceBindings,
  PublicationServiceBindings,
  SettingServiceBindings,
  NoticeServiceBindings,
  UserNoticeServiceBindings,
  GoalServiceBindings,
  GoalActionServiceBindings,
  GoalLogsServiceBindings,
  LabTestServiceBindings,
  ConsultGlitchesServiceBindings,
} from './keys';
import {JWTService} from './services/jwt-service';
import {UsersService} from './services/user-service';
import {UserServiceExtention} from './services/usersServiceExtended';
import {BcryptHasher} from './services/hash.password.bcryptjs';
import {SECURITY_SCHEME_SPEC} from './utils/security-spec';
import {EmailService} from './services/email.service';
import {ControllerService} from './services/controller.service';
import {FCMService} from './services/fcm.service';
import {WebsocketApplication} from './websockets/websocket.application';
import {WebsocketControllerBooter} from './websockets/websocket.booter';
import {MigrationService} from './services/migration.service';
import {MigrationServiceV2} from './services/migration-v2.service';
import {HealthDairyMigrationService} from './services/healthDairyMigration.service';
import {AdminService} from './services/admin.service';
import {AppReleaseService} from './services/app-release.service';
import {PdfService} from './services/pdf.service';
// import {RabbitMQ} from './services/rabbitEventHandler.service';
import {
  BloodPressureService,
  BloodSugarService,
  BroadcastGroupService,
  BroadcastMessageService,
  CholestrolService,
  CoachUserSubscriptionsService,
  ExerciseService,
  ForumService,
  ForumUserService,
  HbaicService,
  HeightService,
  PregnancyLogService,
  PsaService,
  ReferralReasonService,
  ReportPostService,
  WaistCircumferenceService,
  WeightService,
  PrivilegeGroupService,
  PrivilegeService,
  RoleService,
  CommentReplyService,
  CalenderEventService,
  FeedbackService,
  UserFeedbackService,
  UserMentalAssessmentService,
  ActivityTimelineService,
  VoucherService,
  OutlierService,
  DashboardStatisticsService,
  BmiService,
  KemMessageService,
  ProductService,
  TemperatureService,
  ThroveService,
  CareerService,
  PublicationService,
  SettingService,
  NoticeService,
  UserNoticeService,
  GoalService,
  GoalActionService,
  LabTestService,
  ConsultGlitchesService,
} from './services';
import {HealthDiaryService} from './services/health-diary.service';
import {CoachService} from './services/coach.service';
import {AppointmentService} from './services/appointment.service';
import {FrequencyService} from './services/frequency.service';
import {ProgramsService} from './services/programs.service';
import {SpecialityService} from './services/speciality.service';
import {NoteService} from './services/note.service';
import {CommunicationLogService} from './services/communication-log.service';
import {UserSubscriptionsService} from './services/user-subscriptions.service';
import {HealthConditionService} from './services/health-condition.service';
import {AffordablityService} from './services/affordability.service';
import {BasicHealthInformationService} from './services/basic-health-information.service';
import {BlaService} from './services/bla.service';
import {BlockedUsersService} from './services/blocked-users.service';
import {CategoryService} from './services/category.service';
import {ChampionsService} from './services/champions.service';
import {ChatRoomService} from './services/chat-room.service';
import {ChatService} from './services/chat.service';
import {ChatServiceWs} from './services/chat.service.ws';
import {ChildrenService} from './services/children.service';
import {CoachTypeService} from './services/coach-type.service';
import {CouponsService} from './services/coupons.service';
import {DiseaseService} from './services/disease.service';
import {ExerciseTypesService} from './services/exercise-types.service';
import {ExercisesService} from './services/exercises.service';
import {EyeExaminationService} from './services/eye-examination.service';
import {FootExaminationService} from './services/foot-examination.service';
import {HealthProcedureSurgeriesService} from './services/health-procedure-surgeries.service';
import {HealthQuestionService} from './services/health-question.service';
import {InsuranceService} from './services/insurance.service';
import {InterestSevice} from './services/interest.service';
import {JournalService} from './services/journal.service';
import {LabService} from './services/lab.service';
import {LabsProceduresService} from './services/labs-procedures.service';
import {LanguageService} from './services/language.service';
import {LikeService} from './services/like.service';
import {MedicationService} from './services/medication.service';
import {MedicationPassportService} from './services/medication-passport.service';
import {MyAssessmentsInformationService} from './services/my-assessments-information.service';
import {MyAssessmentsService} from './services/my-assessments.service';
import {NotificationService} from './services/notification.service';
import {NudgeHubsService} from './services/nudge-hubs.service';
import {OutlierLogsService} from './services/outlier-logs.service';
import {PatientService} from './services/patient.service';
import {PaymentsService} from './services/payments.service';
import {PlansService} from './services/plans.service';
import {BlogPostService} from './services/blog-post.service';
import {ProjectsCategoryService} from './services/projects-category.service';
import {ProviderService} from './services/provider.service';
import {ReminderService} from './services/reminder.service';
import {ResourcesService} from './services/resources.service';
import {ReviewService} from './services/review.service';
import {SubscriptionService} from './services/subscription.service';
import {SymptomHealthConditionService} from './services/symptom-health-condition.service';
import {SymptomTypeService} from './services/symptom-type.service';
import {SymptomsService} from './services/symptoms.service';
import {TagService} from './services/tag.service';
import {TreatmentService} from './services/treatment.service';
import {UserDoctorsService} from './services/user-doctors.service';
import {UserLocationsService} from './services/user-locations.service';
import {UserPharmacyRecordsService} from './services/user-phamacy-records.service';
import {WaistgoalService} from './services/waistgoal.service';
import {WebinarService} from './services/webinars.service';
import {ReportCommentService} from './services/report-comment.service';
import {CommentService} from './services/comment.service';
import {PregnancyCycleService} from './services/pregnancy-cycle.service';
import {QuestionService} from './services/question.service';
import {ReferralService} from './services/referral.service';
import {ProcedureListService} from './services/procedure-list.service';
import {ConsultService} from './services/consult.service';
import {HubVisitService} from './services/hub-visit.service';
import {PartnerService} from './services/partner.service';
import {GoalLogsService} from './services/goal-logs.service';

export interface PackageInfo {
  name: string;
  version: string;
  description: string;
}

export const PackageKey = BindingKey.create<PackageInfo>('application.package');

const pkg: PackageInfo = require('../package.json');

export class MdocadminapiApplication extends BootMixin(
  ServiceMixin(RepositoryMixin(WebsocketApplication)),
) {
  constructor(options: ApplicationConfig = {}) {
    super(options);
    // const obj: ComponentsObject = {};
    this.api({
      openapi: '3.0.0',
      info: {title: pkg.name, version: pkg.version},
      paths: {},
      components: {securitySchemes: SECURITY_SCHEME_SPEC},
      servers: [{url: '/'}],
    });
    // Set up the custom sequence
    this.setUpBindings();

    // Bind authentication component related elements
    this.component(AuthenticationComponent);

    registerAuthenticationStrategy(this, JWTAuthenticationStrategy);
    this.sequence(MySequence);

    // Set up default home page
    this.static('/', path.join(__dirname, '../public'));

    // Customize @loopback/rest-explorer configuration here
    this.bind(RestExplorerBindings.CONFIG).to({
      path: '/explorer',
    });
    this.component(RestExplorerComponent);
    this.booters(WebsocketControllerBooter);
    this.projectRoot = __dirname;
    // Customize @loopback/boot Booter Conventions here
    this.bootOptions = {
      controllers: {
        // Customize ControllerBooter Conventions here
        dirs: ['controllers'],
        extensions: ['.controller.js'],
        nested: true,
      },
      websocketControllers: {
        dirs: ['controllers'],
        extensions: ['.controller.ws.js'],
        nested: true,
      },
    };

    // RabbitMQ.startConsumer();
  }

  setUpBindings(): void {
    this.bind(TokenServiceBindings.TOKEN_SECRET).to(
      TokenServiceConstants.TOKEN_SECRET_VALUE,
    );
    this.bind(TokenServiceBindings.TOKEN_EXPIRES_IN).to(
      TokenServiceConstants.TOKEN_EXPIRES_IN_VALUE,
    );
    this.bind(TokenServiceBindings.TOKEN_SERVICE).toClass(JWTService);
    this.bind(UserServiceBindings.USER_SERVICE).toClass(UsersService);
    this.bind(UserServiceExtensionBindings.USER_SERVICE_EXT).toClass(
      UserServiceExtention,
    );
    this.bind(EmailServiceBindings.MAIL_SERVICE).toClass(EmailService);
    this.bind(PdfServiceBindings.PDF_SERVICE).toClass(PdfService);
    this.bind(FCMServiceBindings.FCM_SERVICE).toClass(FCMService);
    this.bind(PasswordHasherBindings.ROUNDS).to(10);
    this.bind(PasswordHasherBindings.PASSWORD_HASHER).toClass(BcryptHasher);
    this.bind(ControllerServiceBindings.CONTROLLER_SERVICE).toClass(
      ControllerService,
    );
    // enable the lines below when needed for security reasons
    this.bind(MigrationServiceBindings.MIGRATION_SERVICE).toClass(
      MigrationService,
    );
    this.bind(MigrationServiceV2Bindings.MIGRATION_SERVICE).toClass(
      MigrationServiceV2,
    );
    this.bind(
      HealthDairyMigrationServiceBindings.HEALTHDAIRY_MIGRATION_SERVICE,
    ).toClass(HealthDairyMigrationService);
    this.bind(AdminServiceBindings.ADMIN_SERVICE).toClass(AdminService);
    this.bind(AppReleaseServiceBindings.APP_RELEASE_SERVICE).toClass(
      AppReleaseService,
    );
    this.bind(ReferralServiceBindings.REFERRAL_SERVICE).toClass(
      ReferralService,
    );
    this.bind(ReferralReasonServiceBindings.REFERRAL_REASON_SERVICE).toClass(
      ReferralReasonService,
    );
    this.bind(HealthDiaryServiceBindings.HEALTH_DIARY_SERVICE).toClass(
      HealthDiaryService,
    );
    this.bind(CoachServiceBindings.COACH_SERVICE).toClass(CoachService);
    this.bind(BroadcastMessageServiceBinding.BROADCAST_SERVICE_BINDING).toClass(
      BroadcastMessageService,
    );
    this.bind(
      BroadcastGroupServiceBinding.BROADCAST_GROUP_SERVICE_BINDING,
    ).toClass(BroadcastGroupService);
    this.bind(AppointmentServiceBindings.APPOINTMENT_SERVICE).toClass(
      AppointmentService,
    );
    this.bind(FrequencyServiceBindings.FREQUENCY_SERVICE).toClass(
      FrequencyService,
    );
    this.bind(ProgramsServiceBindings.PROGRAMS_SERVICE).toClass(
      ProgramsService,
    );
    this.bind(SpecialityServiceBindings.SPECIALITY_SERVICE).toClass(
      SpecialityService,
    );
    this.bind(AppointmentServiceBindings.APPOINTMENT_SERVICE).toClass(
      AppointmentService,
    );
    this.bind(FrequencyServiceBindings.FREQUENCY_SERVICE).toClass(
      FrequencyService,
    );
    this.bind(ProgramsServiceBindings.PROGRAMS_SERVICE).toClass(
      ProgramsService,
    );
    this.bind(SpecialityServiceBindings.SPECIALITY_SERVICE).toClass(
      SpecialityService,
    );
    this.bind(NoteServiceBindings.NOTES_SERVICE).toClass(NoteService);
    this.bind(CommunicationLogServiceBindings.COMMUNICATION_LOG).toClass(
      CommunicationLogService,
    );
    this.bind(UserSubscriptionsServiceBindings.USER_SUBSCRIPTIONS).toClass(
      UserSubscriptionsService,
    );
    this.bind(HealthConditionServiceBindings.HEALTH_CONDITION_SERVICE).toClass(
      HealthConditionService,
    );
    this.bind(AffordablityServiceBindings.AFFORDABILITY_SERVICE).toClass(
      AffordablityService,
    );
    this.bind(
      BasicHealthInformationServiceBindings.BASIC_HEALTH_INFORMATION_SERVICE,
    ).toClass(BasicHealthInformationService);
    this.bind(BlaServiceBindings.BLA_SERVICE).toClass(BlaService);
    this.bind(BlockedUsersServiceBindings.BLOCKED_USERS_SERVICE).toClass(
      BlockedUsersService,
    );
    this.bind(CategoryServiceBindings.CATEGORY_SERVICE).toClass(
      CategoryService,
    );
    this.bind(ChampionsServiceBindings.CHAMPIONS_SERVICE).toClass(
      ChampionsService,
    );
    this.bind(ChatRoomServiceBindings.CHAT_ROOM_SERVICE).toClass(
      ChatRoomService,
    );
    this.bind(QuestionServiceBindings.QUESTION_SERVICE).toClass(
      QuestionService,
    );
    this.bind(ChatServiceBindings.CHAT_SERVICE).toClass(ChatService);
    this.bind(ChatServiceWsBindings.CHAT_WS_SERVICE).toClass(ChatServiceWs);
    this.bind(ChildrenServiceBindings.CHILDREN_SERVICE).toClass(
      ChildrenService,
    );
    this.bind(CoachTypeServiceBindings.COACH_TYPE_SERVICE).toClass(
      CoachTypeService,
    );
    this.bind(CouponsServiceBindings.COUPONS_SERVICE).toClass(CouponsService);
    this.bind(DiseaseServiceBindings.DISEASE_SERVICE).toClass(DiseaseService);
    this.bind(ExerciseTypesServiceBindings.EXERCISE_TYPES_SERVICE).toClass(
      ExerciseTypesService,
    );
    this.bind(ExercisesServiceBindings.EXERCISES_SERVICE).toClass(
      ExercisesService,
    );
    this.bind(EyeExaminationServiceBindings.EYE_EXAMINATION_SERVICE).toClass(
      EyeExaminationService,
    );
    this.bind(FootExaminationServiceBindings.FOOT_EXAMINATION_SERVICE).toClass(
      FootExaminationService,
    );
    this.bind(
      HealthProcedureSurgeriesServiceBindings.HEALTH_PROCEDURE_SURGERIES_SERVICE,
    ).toClass(HealthProcedureSurgeriesService);
    this.bind(HealthQuestionServiceBindings.HEALTH_QUESTIONS_SERVICE).toClass(
      HealthQuestionService,
    );
    this.bind(InsuranceServiceBindings.INSURANCE_SERVICE).toClass(
      InsuranceService,
    );
    this.bind(InterestSeviceBindings.INTEREST_SERVICE).toClass(InterestSevice);
    this.bind(JournalServiceBindings.JOURNAL_SERVICE).toClass(JournalService);
    this.bind(LabServiceBindings.LAB_SERVICE).toClass(LabService);
    this.bind(LabsProceduresServiceBindings.LABS_PROCEDURES_SERVICE).toClass(
      LabsProceduresService,
    );
    this.bind(LanguageServiceBindings.LANGUAGE_SERVICE).toClass(
      LanguageService,
    );
    this.bind(LikeServiceBindings.LIKE_SERVICE).toClass(LikeService);
    this.bind(MedicationServiceBindings.MEDICATION_SERVICE).toClass(
      MedicationService,
    );
    this.bind(
      MedicationPassportServiceBindings.MEDICATION_PASSPORT_SERVICE,
    ).toClass(MedicationPassportService);
    this.bind(
      MyAssessmentsInformationServiceBindings.MY_ASSESSMENT_INFORMATION_SERVICE_BINDINGS,
    ).toClass(MyAssessmentsInformationService);
    this.bind(
      MyAssessmentsServiceBindings.MY_ASSESSMENT_SERVICE_BINDINGS,
    ).toClass(MyAssessmentsService);
    this.bind(NotificationServiceBindings.NOTIFICATION_SERVICE).toClass(
      NotificationService,
    );
    this.bind(NudgeHubsServiceBindings.NUDGE_HUBS_SERVICE).toClass(
      NudgeHubsService,
    );
    this.bind(OutlierLogsServiceBindings.OUTLIER_LOGS_SERVICE).toClass(
      OutlierLogsService,
    );
    this.bind(PatientServiceBindings.PATIENT_SERVICE).toClass(PatientService);
    this.bind(PaymentsServiceBindings.PAYMENTS_SERVICE).toClass(
      PaymentsService,
    );
    this.bind(PlansServiceBindings.PLANS_SERVICE).toClass(PlansService);
    this.bind(BlogPostServiceBindings.BLOG_POST_SERVICE).toClass(
      BlogPostService,
    );
    this.bind(
      ProjectsCategoryServiceBindings.PROJECTS_CATEGORY_SERVICE,
    ).toClass(ProjectsCategoryService);
    this.bind(ProviderServiceBindings.PROVIDER_SERVICE).toClass(
      ProviderService,
    );
    this.bind(ReminderServiceBindings.REMINDER_SERVICE).toClass(
      ReminderService,
    );
    this.bind(ResourcesServiceBindings.RESOURCES_SERVICE).toClass(
      ResourcesService,
    );
    this.bind(ReviewServiceBindings.REVIEW_SERVICE).toClass(ReviewService);
    this.bind(SubscriptionServiceBindings.SUBSCRIPTION_SERVICE).toClass(
      SubscriptionService,
    );
    this.bind(
      SymptomHealthConditionServiceBindings.SYMPTOM_HEALTH_CONDITION_SERVICE,
    ).toClass(SymptomHealthConditionService);
    this.bind(SymptomTypeServiceBindings.SYMPTOM_TYPE_SERVICE).toClass(
      SymptomTypeService,
    );
    this.bind(SymptomsServiceBindings.SYMPTOMS_SERVICE).toClass(
      SymptomsService,
    );
    this.bind(TagServiceBindings.TAG_SERVICE).toClass(TagService);
    this.bind(TreatmentServiceBindings.TREATMENT_SERVICE).toClass(
      TreatmentService,
    );
    this.bind(UserDoctorsServiceBindings.USER_DOCTORS_SERVICE).toClass(
      UserDoctorsService,
    );
    this.bind(UserLocationsServiceBindings.USER_LOCATIONS_SERVICE).toClass(
      UserLocationsService,
    );
    this.bind(
      UserPharmacyRecordsServiceBindings.USER_PHARMACY_RECORDS_SERVICE,
    ).toClass(UserPharmacyRecordsService);
    this.bind(WaistgoalServiceBindings.WAISTGOAL_SERVICE).toClass(
      WaistgoalService,
    );
    this.bind(WebinarServiceBindings.WEBINAR_SERVICE).toClass(WebinarService);
    this.bind(ReportCommentServiceBindings.REPORT_COMMENT).toClass(
      ReportCommentService,
    );
    this.bind(ReportPostServiceBindings.REPORT_POST).toClass(ReportPostService);
    this.bind(CommentServiceBindings.COMMENT_SERVICE).toClass(CommentService);
    this.bind(
      WaistCirumferenceServiceBindings.WAISTCIRCUMGERENCE_SERVICE,
    ).toClass(WaistCircumferenceService);
    this.bind(HbaicServiceBindings.HBAIC_SERVICE).toClass(HbaicService);
    this.bind(CholestrolServiceBindings.CHOLESTROL_SERVICE).toClass(
      CholestrolService,
    );
    this.bind(BloodPressureServiceBindings.BLOODPRESSURE_SERVICE).toClass(
      BloodPressureService,
    );
    this.bind(BloodSugarServiceBindings.BLOODSUGAR_SERVICE).toClass(
      BloodSugarService,
    );
    this.bind(PsaServiceBindings.PSA_SERVICE).toClass(PsaService);
    this.bind(WeightServiceBindings.WEIGHT_SERVICE).toClass(WeightService);
    this.bind(HeightServiceBindings.HEIGHT_SERVICE).toClass(HeightService);
    this.bind(TemperatureServiceBindings.TEMPERATURE_SERVICE).toClass(
      TemperatureService,
    );
    this.bind(PartnerServiceBindings.PARTNER_SERVICE).toClass(PartnerService);
    this.bind(ConsultServiceBindings.CONSULT_SERVICE).toClass(ConsultService);
    this.bind(HubVisitServiceBindings.HUB_VISIT_SERVICE).toClass(HubVisitService);
    this.bind(
      CoachUserSubscriptionsServiceBindings.COACHUSERSUBSCRIPTIONS_SERVICE,
    ).toClass(CoachUserSubscriptionsService);
    this.bind(ForumServiceBindings.FORUM_SERVICE).toClass(ForumService);
    this.bind(ForumUserServiceBindings.FORUMUSER_SERVICE).toClass(
      ForumUserService,
    );
    this.bind(PregnancyCycleServiceBindings.PREGNANCY_CYCLE).toClass(
      PregnancyCycleService,
    );
    this.bind(PregnancyLogServiceBindings.PREGNANCY_LOG).toClass(
      PregnancyLogService,
    );
    this.bind(ExerciseServiceBindings.EXERCISE_SERVICE).toClass(
      ExerciseService,
    );
    this.bind(PrivilegeGroupServiceBindings.PRIVILEGE_GROUP_SERVICE).toClass(
      PrivilegeGroupService,
    );
    this.bind(PrivilegeServiceBindings.PRIVILEGE_SERVICE).toClass(
      PrivilegeService,
    );
    this.bind(RoleServiceBindings.ROLE_SERVICE).toClass(RoleService);
    this.bind(CommentReplyServiceBindings.COMMENT_REPLY_SERVICE).toClass(
      CommentReplyService,
    );
    this.bind(CalenderEventServiceBindings.CALENDER_EVENT_SERVICE).toClass(
      CalenderEventService,
    );
    this.bind(FeedbackServiceBindings.FEEDBACK_SERVICE).toClass(
      FeedbackService,
    );
    this.bind(UserFeedbackServiceBindings.USER_FEEDBACK_SERVICE).toClass(
      UserFeedbackService,
    );
    this.bind(
      ActivityTimelineServiceBindings.ACTIVITY_TIMELINE_SERVICE,
    ).toClass(ActivityTimelineService);
    this.bind(
      UserMentalAssessmentServiceBindings.USER_MENTAL_ASSESSMENT_SERVICE,
    ).toClass(UserMentalAssessmentService);
    this.bind(VoucherServiceBindings.VOUCHER_SERVICE).toClass(VoucherService);
    this.bind(ProcedureListServiceBindings.PROCEDURE_LIST_SERVICE).toClass(
      ProcedureListService,
    );
    this.bind(OutlierServiceBindings.OUTLIER_SERVICE).toClass(OutlierService);
    this.bind(
      DashboardStatisticsServiceBindings.DASHBOARD_STATISTICS_SERVICE,
    ).toClass(DashboardStatisticsService);
    this.bind(BmiServiceBindings.BMI_SERVICE).toClass(BmiService);
    this.bind(KemMessageSerivceBindings.KEM_MESSAGE).toClass(KemMessageService);
    this.bind(ProductServiceBindings.PRODUCT_SERVICE).toClass(ProductService);
    this.bind(ThroveSerivceBindings.THROVE_SERVICE).toClass(ThroveService);
    this.bind(CareerServiceBindings.CAREER_SERVICE).toClass(CareerService);
    this.bind(PublicationServiceBindings.PUBLICATION_SERVICE).toClass(
      PublicationService,
    );
    this.bind(SettingServiceBindings.SETTING_SERVICE).toClass(SettingService);
    this.bind(NoticeServiceBindings.NOTICE_SERVICE).toClass(NoticeService);
    this.bind(UserNoticeServiceBindings.USER_NOTICE_SERVICE).toClass(UserNoticeService);
    this.bind(GoalServiceBindings.GOAL_SERVICE).toClass(GoalService);
    this.bind(GoalActionServiceBindings.GOAL_ACTION_SERVICE).toClass(
      GoalActionService,
    );
    this.bind(GoalLogsServiceBindings.GOAL_LOGS_SERVICE).toClass(
      GoalLogsService,
    );
    this.bind(LabTestServiceBindings.LAB_TEST_SERVICE).toClass(LabTestService);
    this.bind(ConsultGlitchesServiceBindings.CONSULT_GLITCHES_SERVICE).toClass(
      ConsultGlitchesService,
    );
  }
}
