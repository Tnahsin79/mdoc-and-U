import axios, {
  AxiosInstance,
  AxiosResponse,
  AxiosError,
  AxiosRequestConfig,
} from 'axios'

interface CustomAxiosRequestConfig extends AxiosRequestConfig {
  _retry?: boolean
}

const axiosInstance: AxiosInstance = axios.create()

axiosInstance.interceptors.response.use(
  (response: AxiosResponse) => response,
  async (error: AxiosError) => {
    const originalRequest = error.config as CustomAxiosRequestConfig

    if (error.response?.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true

      try {
        await axios.get('/api/auth/refresh')

        return axiosInstance(originalRequest)
      } catch (refreshError) {
        console.error('Error refreshing access token:', refreshError)
      }
    }

    return Promise.reject(error)
  },
)

export default axiosInstance
