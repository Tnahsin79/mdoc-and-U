import { z } from 'zod'

export const createEventTemplateSchema = z.object({
  templateName: z.string({
    required_error: 'Vorlagenname ist erforderlich.',
  }),
})

export const editEventTemplateSchema = z.object({
  ...createEventTemplateSchema.shape,
  templateId: z.number({
    required_error: 'Vorlagen-ID ist erforderlich.',
  }),
})
