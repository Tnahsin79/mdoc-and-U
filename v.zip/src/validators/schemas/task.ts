import { TaskType } from '@prisma/client'
import { z } from 'zod'

export const createTaskSchema = z.object({
  assignees: z
    .array(
      z.union([
        z.literal('All Collaborator'),
        z.literal('All Candidate'),
        z.number(),
      ]),
    )
    .nonempty({
      message: 'Assignees must contain at least one value',
    }),
  type: z
    .nativeEnum(TaskType)
    .refine((value) => value !== null && value !== undefined, {
      message: 'Task type is required',
    }),
  title: z.string({
    required_error: 'Title is required',
  }),
  dueDate: z.date({
    required_error: 'Due date is required',
  }),
  note: z.string().optional(),
  attachments: z.array(z.string()).optional(),
  done: z.boolean().optional(),
})
