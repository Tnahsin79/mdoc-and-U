import { z } from 'zod'
import { validators } from '../index'

export const createEventSchema = z.object({
  templateId: z.number().int('Die Vorlage muss gültig sein.').optional(),
  subjectAreaId: z
    .number({
      required_error: 'Fachgebiet ist erforderlich.',
    })
    .int('Der Themenbereich muss gültig sein.'),
  subjectModule: z.string({
    required_error: 'Fachmodul ist erforderlich.',
  }),
  eventTypeId: z
    .number({
      required_error: 'Ereignistyp ist erforderlich.',
    })
    .int('Der Ereignistyp muss gültig sein.'),
  phaseId: z
    .number({
      required_error: 'Phase ist erforderlich.',
    })
    .int('Phase muss gültig sein.'),
  title: z.string({
    required_error: 'Titel ist erforderlich.',
  }),
  minParticipants: z.number({
    required_error: 'Mindestteilnehmerzahl ist erforderlich.',
    invalid_type_error: 'Die Mindestteilnehmerzahl muss eine Zahl sein.',
  }),
  maxParticipants: z.number({
    required_error: 'Es ist eine maximale Teilnehmerzahl erforderlich.',
    invalid_type_error:
      'Die maximale Anzahl an Teilnehmern muss eine Zahl sein.',
  }),
  description: z.string({
    required_error: 'Beschreibung ist erforderlich.',
  }),
  eventManner: z.string({
    required_error: 'Veranstaltungsart ist erforderlich.',
  }),
  accessLink: z
    .string()
    .optional()
    .refine((value) => !value || validators.link.test(value), {
      message: 'Der Zugriffslink muss eine gültige URL sein',
    }),
  eventStatus: z.number({
    required_error: 'Der Ereignisstatus ist erforderlich.',
  }),
  reason: z.string().optional(),
  bookedFrom: z
    .string({
      required_error: 'Das Startdatum der Veranstaltung ist erforderlich.',
    })
    .datetime('Das Startdatum des Ereignisses muss gültig sein.'),
  bookedTo: z
    .string({
      required_error: 'Das Enddatum der Veranstaltung ist erforderlich.',
    })
    .datetime('Das Enddatum des Ereignisses muss gültig sein.')
    .optional(),
  startTime: z
    .string({
      required_error: 'Die Startzeit des Ereignisses ist erforderlich.',
    })
    .datetime('Die Startzeit des Ereignisses muss gültig sein.'),
  endTime: z
    .string({
      required_error: 'Die Endzeit des Ereignisses ist erforderlich.',
    })
    .datetime('Die Endzeit des Ereignisses muss gültig sein.'),

  eventRepeatId: z.union([z.number().int(), z.null()]).optional(),
  lmsLink: z
    .string()
    .optional()
    .refine((value) => !value || validators.link.test(value), {
      message: 'Der LMS-Link muss eine gültige URL sein',
    }),
  locationId: z
    .union([
      z.number().int('Der Standort muss gültig sein.'),
      z.undefined(),
      z.null(),
    ])
    .optional(),
  barrierFreeAccess: z.union([z.boolean(), z.undefined(), z.null()]).optional(),
  suitableRoomId: z
    .union([z.number().int(), z.undefined(), z.null()])
    .optional(),
  equipmentId: z.array(
    z
      .number({
        required_error: 'Ausrüstung ist erforderlich.',
      })
      .int('Die Ausrüstung muss gültig sein.'),
  ),
  suitableCollaboratorId: z
    .number({
      required_error: 'Geeigneter Mitarbeiter ist erforderlich.',
    })
    .int('Der geeignete Mitarbeiter muss gültig sein.'),
  attendeesId: z.array(
    z.string({
      required_error: 'Teilnehmerzahl ist erforderlich.',
    }),
  ),
  eventKey: z.string({
    required_error: 'Der Ereignisschlüssel ist erforderlich.',
  }),
})

export const editEventSchema = z.object({
  ...createEventSchema.shape,
  eventId: z.number({
    required_error: 'Ereignis-ID ist erforderlich.',
  }),
})
