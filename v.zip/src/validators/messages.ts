export const validationMessages = {
  required: 'Dieses Feld ist erforderlich.',
  onlyNumbers: 'Dieses Feld kann nur Zahlen enthalten.',
  validLink: 'Bitte geben Sie eine gültige URL ein.',
  validEmail: 'Bitte geben Sie eine gültige Email-Adresse ein.',
  validPhone: 'Bitte geben Sie eine gültige Nummer ein.',
  postalCode: 'Bitte geben Sie eine gültige Postleitzahl ein.',
  iban: 'Bitte geben Sie eine gültige IBAN ein',
  bic: 'Bitte geben Sie einen gültigen BIC ein.',
}
