export const validators = {
  fullName: /^[a-zA-Z ]{3,}$/,
  email: /^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/,
  password:
    /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&,.#^()[\]{}|\;:'"<>?\/~`=+-_]).{8,}$/,
  lastName: /^[A-Za-z]+(?:[-' ][A-Za-z]+)*$/,
  street: /^.*$/,
  postalCode: /^\d{5},?\s?[A-Za-zäöüßÄÖÜ\s\-]+$/,
  phoneNumber: /^\+?\d{1,4}?\s?\(?\d{1,3}\)?[-.\s]?\d{1,4}[-.\s]?\d{1,9}$/,
  yyyy_mm_dd: /^\d{4}-\d{2}-\d{2}$/,
  number: /^[0-9]*$/,
  link: /^(https?:\/\/)?(www\.)?[-a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_\+.~#?&//=]*)/,
  iban: /^([A-Z]{2}\d{2}\s\d{4}\s\d{4}\s\d{4}\s\d{4}\s\d{2})$/,
  bic: /^([a-zA-Z0-9_-]){8}$/,
  yyyy: /^\d{4}$/,
  numericAndSlash: /^[0-9/]+$/,
}

// * iban = 'DE89370400440532013000'
// * bic = 'AAAABB11222'
