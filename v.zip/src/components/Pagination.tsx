import ArrowLeft from '@/components/Icons/IconComponentsList/ArrowLeft'
import ArrowRight from '@/components/Icons/IconComponentsList/ArrowRight'

import { Pagination as MUIPagination, PaginationItem } from '@mui/material'

interface PaginationProps {
  count: number
  page: number
  onChange: (_: React.ChangeEvent<unknown>, value: number) => void
  sx?: React.CSSProperties
}

const Pagination: React.FC<PaginationProps> = ({
  count,
  page,
  onChange,
  sx,
}) => {
  return (
    <MUIPagination
      shape="rounded"
      count={count}
      defaultPage={1}
      page={page}
      boundaryCount={2}
      onChange={onChange}
      renderItem={(item) => (
        <PaginationItem
          slots={{ next: ArrowRight, previous: ArrowLeft }}
          {...item}
        />
      )}
      sx={sx}
    />
  )
}

export default Pagination
