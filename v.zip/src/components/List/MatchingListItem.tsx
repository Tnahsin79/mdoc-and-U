import { Grid } from '@mui/material'

import Matching from './Matching'
import IconSwitcher from '../Icons'
import CustomButton from '../Buttons/CustomButton'
import { useScopedI18n } from '../../../locales/client'

interface MatchingListItemProps {
  candidate: {
    firstName: string
    lastName: string | null
    school: {
      city: string
      postalCode: string
    }
  }
  mentor?: {
    collaboratorId: number | null
    city: string
    postalCode: string
    firstName: string
    lastName: string
  }
  modalOpenHandler: () => void
  deleteMentorHandler: () => void
}

const MatchingListItem: React.FC<MatchingListItemProps> = ({
  candidate,
  mentor,
  modalOpenHandler,
  deleteMentorHandler,
}) => {
  const tScoped = useScopedI18n('dashboard')

  return (
    <>
      <Grid
        container
        justifyContent="space-between"
        alignItems="center"
        gap={25}
        mb={12}
      >
        <Matching
          firstName={candidate.firstName}
          lastName={candidate.lastName}
          address={`${candidate.school.postalCode} ${candidate.school.city}`}
          />
        <IconSwitcher icon="ArrowMatching" />
        {mentor ? (
          <Matching
            address={`${mentor.postalCode} ${mentor.city}`}
            firstName={mentor.firstName}
            lastName={mentor.lastName}
            matched
            deleteMentorHandler={deleteMentorHandler}
          />
        ) : (
          <Grid
            container
            justifyContent="flex-start"
            alignItems="center"
            flex={1}
            gap={15}
          >
            <CustomButton
              label={true}
              labelText={tScoped('Find Match')}
              icon={true}
              onClick={modalOpenHandler}
            />
            <CustomButton
              label={true}
              labelText={tScoped('Add Comment')}
              icon={true}
              disabled
            />
          </Grid>
        )}
      </Grid>
    </>
  )
}

export default MatchingListItem
