import styled from '@emotion/styled'
import IconSwitcher from '@/components/Icons'
import { Typography } from '@mui/material'

const FlexContainer = styled('div')({
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  gap: '10px',
})

const MatchingContainer = styled(FlexContainer)({
  flex: 1,
})

const MatchingCard = styled(FlexContainer)({
  flex: 1,
  padding: '23px 20px',
  border: '1px solid #000',
})

interface MatchingProps {
  matched?: boolean
  firstName: string
  lastName: string | null
  address: string
  deleteMentorHandler?: () => void
}

const Matching: React.FC<MatchingProps> = ({
  matched = false,
  firstName,
  lastName,
  address,
  deleteMentorHandler,
}) => {
  return (
    <MatchingContainer>
      <MatchingCard>
        <Typography variant="h3">
          {firstName} {lastName || ''}
        </Typography>
        <FlexContainer>
          <Typography variant="h3">{address}</Typography>
          <IconSwitcher icon="redArrowRight" />
        </FlexContainer>
      </MatchingCard>
      {matched ? (
        <div onClick={deleteMentorHandler} style={{ cursor: 'pointer' }}>
          <IconSwitcher icon="bin2" />
        </div>
      ) : null}
    </MatchingContainer>
  )
}

export default Matching
