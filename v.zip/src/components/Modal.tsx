import React from 'react'
import { Box, IconButton, Modal, Theme } from '@mui/material'
import CloseIcon from '@mui/icons-material/Close'
import styled from '@emotion/styled'

interface IModalProps {
  open: boolean
  onClose: () => void
  children: React.ReactNode
  sx?: React.CSSProperties
}

const style = {
  position: 'absolute' as const,
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: '50%',
  maxHeight: '80%',
  bgcolor: 'background.paper',
  boxShadow: 24,
  p: '24px',
  overflowY: 'auto',
}

const StyledIconButton = styled(IconButton)(({ theme }: { theme?: Theme }) => ({
  position: 'absolute',
  right: 0,
  top: 0,
  background: '#fff',
  color: theme?.palette.primary.main,
  '&:hover': {
    backgroundColor: theme?.palette.primary.main,
    color: theme?.palette?.text?.primary,
  },
}))

const CustomModal = ({ children, onClose, sx, ...rest }: IModalProps) => {
  return (
    <Modal {...rest} onClose={onClose}>
      <Box sx={{ ...style, ...sx }}>
        <StyledIconButton onClick={onClose}>
          <CloseIcon />
        </StyledIconButton>
        {children}
      </Box>
    </Modal>
  )
}

export default CustomModal
