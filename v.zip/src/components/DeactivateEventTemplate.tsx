import React from 'react'
import CustomModal from './Modal'
import { Box, Grid, Typography } from '@mui/material'

import Button from '@/components/Buttons/CustomButton'

interface IDeactivateEventTemplate {
  open: boolean
  onClose: () => void
  onDeactivate: () => void
  confirmLabel: string
}

const DeactivateEventTemplate = ({
  open,
  onClose,
  onDeactivate,
  confirmLabel,
}: IDeactivateEventTemplate) => {
  return (
    <CustomModal open={open} onClose={onClose}>
      <Typography
        variant="h6"
        component="h2"
        mb={10}
        sx={{ fontWeight: 700, fontSize: '28px', color: '#E40422' }}
      >
        {confirmLabel} Event Template
      </Typography>

      <Box>
        <Grid container spacing={10} justifyContent="center">
          <Grid item>
            <Button
              label
              labelText="Cancel"
              sx={{ minWidth: '200px' }}
              onClick={onClose}
            />
          </Grid>

          <Grid item>
            <Button
              label
              labelText={confirmLabel}
              sx={{ minWidth: '200px' }}
              variant="contained"
              onClick={onDeactivate}
            />
          </Grid>
        </Grid>
      </Box>
    </CustomModal>
  )
}

export default DeactivateEventTemplate
