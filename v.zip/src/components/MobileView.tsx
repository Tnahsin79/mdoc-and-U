'use client'
import { UserProvider } from '@/contexts/userContext'
import ThemeRegistry from '@/theme/ThemeRegistry'
import { Typography } from '@mui/material'
import ProtectedLayout from '@/components/layout/ProtectedLayout'

import React, { useEffect, useState } from 'react'
import { CandidatesMatchedToMentorsProvider } from '@/contexts/useCandidatesMatchedToMentors'

const IsMobileView = ({ children }: { children: React.ReactNode }) => {
  const [isMobile, setIsMobile] = useState<boolean>(false)

  const handleResize = () => {
    setIsMobile(window.innerWidth < 768)
  }

  useEffect(() => {
    handleResize()
    window.addEventListener('resize', handleResize)
    return () => window.removeEventListener('resize', handleResize)
  }, [])
  return (
    <>
      {isMobile ? (
        <Typography sx={{ fontWeight: 700, fontSize: '20px' }}>
          The app does not support mobile view yet, We recommend to open this
          app on tablet/desktop
        </Typography>
      ) : (
        <ThemeRegistry options={{ key: 'mui' }}>
          <UserProvider>
          <CandidatesMatchedToMentorsProvider>
            <ProtectedLayout>{children}</ProtectedLayout>
            </CandidatesMatchedToMentorsProvider>
          </UserProvider>
        </ThemeRegistry>
      )}
    </>
  )
}

export default IsMobileView
