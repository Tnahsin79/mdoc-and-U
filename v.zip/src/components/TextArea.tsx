'use client'
import styled from '@emotion/styled'
import { CSSProperties } from 'react'
import { TextareaAutosize } from '@mui/base'
import { Box, InputLabel, Typography } from '@mui/material'
import { Controller, FieldError } from 'react-hook-form'
import { validationMessages } from '@/validators/messages'

interface textAreaProps {
  label: string
  direction?: 'vertical' | 'horizontal'
}

const StyledTextareaAutosize = styled(TextareaAutosize)(
  (props: { error?: FieldError; direction?: 'vertical' | 'horizontal' }) => ({
    resize: 'none',
    padding: '10px',
    height: '146px !important',
    border: props.error ? '1px solid red' : '1px solid #000',
    width: props.direction === 'horizontal' ? 'calc(50% - 10px)' : '100%',

    '&:focus-visible': {
      border: props.error ? '1px solid red' : '2px solid grey',
      outline: 'none',
    },
  }),
)

const StyledBox = styled(Box)({
  display: 'flex',
  gap: '10px',
})

const TextArea = ({ label }: textAreaProps) => {
  return (
    <StyledBox>
      <Typography variant="h6">{label}</Typography>
      <StyledTextareaAutosize minRows={6} maxRows={6} />
    </StyledBox>
  )
}

interface textAreaProps {
  label: string
  control: any
  name: string
  required?: boolean
  defaultValue?: string
  disabled?: boolean
  readOnly?: boolean
  direction?: 'vertical' | 'horizontal'
  sx?: CSSProperties
}

export const RHFTextArea = ({
  label,
  control,
  name,
  required,
  defaultValue = '',
  disabled = false,
  readOnly = false,
  direction = 'vertical',
  sx,
}: textAreaProps) => {
  return (
    <StyledBox
      sx={
        direction === 'horizontal'
          ? {
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'flex-start',
              flexDirection: 'row',
              ...sx,
            }
          : { flexDirection: 'column', ...sx }
      }
    >
      <InputLabel>{label}</InputLabel>
      <Controller
        render={({ field, fieldState: { error } }) => (
          <>
            <StyledTextareaAutosize
              {...field}
              minRows={6}
              maxRows={6}
              error={error}
              disabled={disabled || readOnly}
              direction={direction}
            />
            {error?.message && (
              <Box
                sx={{
                  color: 'red',
                  fontSize: '0.75rem !important',
                }}
              >
                {error.message}
              </Box>
            )}
          </>
        )}
        control={control}
        name={name}
        rules={{
          required: required ? validationMessages.required : false,
        }}
        defaultValue={defaultValue}
      />
    </StyledBox>
  )
}

export default TextArea
