import styled from '@emotion/styled'
import IconSwitcher from './Icons'

const StyledDiv1 = styled('div')({
  display: 'flex',
  alignItems: 'center',
})

const StyledDiv2 = styled('div')({
  width: '508px',
  height: '73px',
  border: '1px solid #000000',
  alignItems: 'center',
})

const StyledDiv3 = styled('div')({
  fontSize: '20px',
  fontWeight: 700,
  height: '100%',
})

const StyledDiv4 = styled('div')({
  fontSize: '20px',
  fontWeight: 700,
  height: '100%',
})

const StyledWrapper = styled('div')({
  display: 'flex',
  height: '28px',
  padding: '23px 20px 22px',
  justifyContent: 'space-between',
})

const StyledIcon = styled(IconSwitcher)({
  width: '25px',
  height: '25px',
  paddingLeft: '20px',
})

const StyledDiv5 = styled('div')({
  paddingLeft: '20px',
})

const Rectangle17 = () => {
  return (
    <StyledDiv1>
      <StyledDiv2>
        <StyledWrapper>
          <StyledDiv3>Mara Musterfrau</StyledDiv3>
          <StyledDiv4>11111 Berlin</StyledDiv4>
        </StyledWrapper>
      </StyledDiv2>
      <StyledDiv5>
        <StyledIcon icon="bin2" />
      </StyledDiv5>
    </StyledDiv1>
  )
}

export default Rectangle17
