'use client'

import { useForm } from 'react-hook-form'
import { useRouter } from 'next/navigation'
import { AxiosError, AxiosResponse } from 'axios'
import { UserContext } from '@/contexts/userContext'
import { RHFTextArea } from '@/components/TextArea'
import { errorMessages } from '@/utils/errorMessages'
import { Condition, ITask, Query } from '@/interface/common'
import { TASK_COLUMNS, taskRoutes } from '@/utils/constants/frontend'
import { successMessages } from '@/utils/successMessages'
import { validationMessages } from '@/validators/messages'
import { RHFAutocompleteField } from '@/components/DropDown'
import { Person, Role, TaskType } from '@prisma/client'
import { ChangeEvent, useContext, useEffect, useState } from 'react'
import {
  MAX_TASK_COUNT,
  paginationLimit,
  specialAssigneesList,
} from '@/utils/constants/common'
import {
  Box,
  FormLabel,
  Grid,
  Table,
  TableBody,
  TableContainer,
  Typography,
} from '@mui/material'

import Toast from '@/components/Toast'
import Filter from '@/components/Filter'
import CustomModal from '@/components/Modal'
import Pagination from '@/components/Pagination'
import InputField from '@/components/InputField'
import axiosInstance from '@/services/axiosInstance'
import CustomDatePicker from '@/components/DatePicker'
import CustomButton from '@/components/Buttons/CustomButton'
import SwitchButton from '@/components/Buttons/SwitchButton'
import TaskTableRow from '@/components/TableRows/TaskTableRow'
import AddAttachment from '@/components/Buttons/AddAttachment'
import { useScopedI18n } from '../../locales/client'
import moment from 'moment'

const TasksComponent = ({ isDashboard = false }: { isDashboard?: boolean }) => {
  const tScoped = useScopedI18n('dashboard')
  const { user } = useContext(UserContext)
  const [page, setPage] = useState<number>(1)
  const [taskList, setTaskList] = useState<ITask[]>([])
  const [serverError, setServerError] = useState<string>('')
  const [openModal, setOpenModal] = useState<boolean>(false)
  const [totalRecords, setTotalRecords] = useState<number>(0)
  const [taskCreated, setTaskCreated] = useState<boolean>(false)

  const [overDue, setOverDue] = useState<boolean>(false)
  const [onlyFuture, setOnlyFuture] = useState<boolean>(false)
  const [doneTasks, setDoneTasks] = useState<boolean>(false)
  const [fileUploading, setFileUploading] = useState<boolean>(false)
  const [currentFiles, setCurrentFiles] = useState<FileList | null>(null)
  const [query, setQuery] = useState<Query>({
    AND: [{ done: { equals: false } }],
  })

  const [assignees, setAssignees] = useState<
    {
      id: number | string
      label:
        | string
        | {
            firstName: string
            lastName: string
            email: string
            role: Role
          }
    }[]
  >([])

  const {
    control,
    handleSubmit,
    formState: { errors },
    setValue,
    clearErrors,
    reset,
    setError,
  } = useForm<ITask>({
    mode: 'all',
    defaultValues: {
      title: '',
      assignees: [],
      type: undefined,
      dueDate: undefined,
      note: '',
    },
    shouldFocusError: true,
  })

  const onPageChangeHandler = async (
    _: React.ChangeEvent<unknown>,
    value: number,
  ) => {
    setPage(value)
  }

  const createTaskHandler = async (payload: ITask) => {
    setTaskCreated(false)
    setServerError('')
    try {
      let response: AxiosResponse | null = null

      try {
        const formData = new FormData()
        if (currentFiles) {
          for (let i = 0; i < currentFiles.length; i++) {
            formData.append('file', currentFiles[i])
          }
          response = await axiosInstance.post('/api/upload', formData)

          if (response && response.status === 201) {
            setFileUploading(false)
          } else {
            throw new Error(errorMessages.FAILED_TO_UPLOAD_ATTACHMENT)
          }
        }
      } catch (error) {
        const errorMessage =
          error instanceof AxiosError
            ? error.response?.data?.error
            : errorMessages.DEFAULT_ERROR

        setServerError(errorMessage)
      }

      await axiosInstance.post('/api/task/create/', {
        ...payload,
        ownerId: user?.personId,
        attachments:
          response && Array.isArray(response.data.responseData)
            ? response.data.responseData.map(
                (file: { fileURLs: string; fileName: string }) => file.fileName,
              )
            : [],
      })
      setTaskCreated(true)
      await getTasks()
      setOpenModal(false)
      setCurrentFiles(null)
      reset()
    } catch (error) {
      const errorMessage =
        error instanceof AxiosError
          ? error.response?.data?.error
          : errorMessages.DEFAULT_ERROR

      setServerError(errorMessage)
    }
  }

  const getAllAssignees = async () => {
    const response = await axiosInstance.post('/api/task/assignees-list', {
      role: user?.role,
      id:
        user?.role === Role.Collaborator ? user.collaboratorId : user?.personId,
    })

    let assignees = []
    if (response.data.persons.length !== 0) {
      assignees = response.data.persons.map((person: Person) => ({
        id: person.personId,
        label: {
          firstName: person.firstName,
          lastName: person.lastName || '',
          email: person.email || '',
          role: person.role || '',
        },
      }))
    }

    if (user?.role === Role.Employee) {
      specialAssigneesList.forEach((value) =>
        assignees.unshift({ id: value, label: value }),
      )
    }

    setAssignees(assignees)
  }

  const getTasks = async () => {
    const response = await axiosInstance.post('/api/task', {
      personId: user?.personId,
      query,
      page,
    })
    setTotalRecords(response.data.totalRecords)
    if (isDashboard) {
      setTaskList(response.data.tasks.slice(0, MAX_TASK_COUNT))
    } else {
      setTaskList(response.data.tasks)
    }
  }

  useEffect(() => {
    setServerError('')
    const fetchData = async () => {
      try {
        await Promise.all([getAllAssignees(), getTasks()])
      } catch (error) {
        const errorMessage =
          error instanceof AxiosError
            ? error.response?.data?.error
            : errorMessages.DEFAULT_ERROR

        setServerError(errorMessage)
      }
    }
    fetchData()
  }, [])

  useEffect(() => {
    getTasks()
  }, [page, query])

  const handleFilter = (filterQuery: Query) => {
    const updatedQuery: Query = {
      AND: [...filterQuery.AND],
    }

    setQuery(updatedQuery)
  }

  const handleRadioFilter = (
    name: string,
    e: ChangeEvent<HTMLInputElement>,
  ) => {
    const condition: Condition = {}
    const updatedQuery: Query = { AND: [...query.AND] }
    const selected = e.target.checked

    if (name === 'doneTasks') {
      setDoneTasks(selected)
      if (!selected) {
        condition['done'] = {
          equals: false,
        }
        updatedQuery.AND.push(condition)
      } else {
        updatedQuery.AND = updatedQuery.AND.filter(
          (obj) => obj.done === undefined,
        )
      }
    } else if (name === 'overdue') {
      setOverDue(selected)
      if (selected) {
        condition['dueDate'] = {
          lt: new Date(),
        }
        updatedQuery.AND.push(condition)
      } else {
        updatedQuery.AND = updatedQuery.AND.filter(
          (obj) => !obj.dueDate || !obj.dueDate.hasOwnProperty('lt'),
        )
      }
    } else if (name === 'onlyFuture') {
      setOnlyFuture(selected)
      if (selected) {
        condition['dueDate'] = {
          gt: new Date(),
        }
        updatedQuery.AND.push(condition)
      } else {
        updatedQuery.AND = updatedQuery.AND.filter(
          (obj) => !obj.dueDate || !obj.dueDate.hasOwnProperty('gt'),
        )
      }
    }
    setQuery(updatedQuery)
  }

  const router = useRouter()

  const today = moment()
  const oneWeekAhead = moment(today).add(7, 'days')

  return (
    <>
      {!isDashboard ? (
        <Grid container justifyContent="space-between" mb={25}>
          <Grid item display="flex" alignItems="flex-end" gap={10}>
            <Typography variant="h1" mb={0}>
              {tScoped('Tasks')}
            </Typography>
          </Grid>
          <Grid item>
            <CustomButton
              icon
              label
              labelText={tScoped('Back')}
              iconName="arrowLeft"
              onClick={() => router.back()}
            />
          </Grid>
        </Grid>
      ) : (
        ''
      )}

      <Grid container sx={{ alignItems: 'center' }}>
        {isDashboard ? (
          <Grid item xs={3}>
            <Typography variant="h2">
              {tScoped('Tasks')} ({totalRecords})
            </Typography>
          </Grid>
        ) : null}
        <Grid
          item
          container
          spacing={10}
          justifyContent="flex-end"
          alignItems="center"
          marginBottom="28px"
          xs={isDashboard ? 9 : 12}
        >
          <Grid
            item
            sx={{ display: 'flex', alignItems: 'center', marginRight: '20px' }}
          >
            <Filter
              columns={TASK_COLUMNS}
              handleFilter={handleFilter}
              defaultValues={{
                column: 'dueDate',
                operator: 'lte',
                value: moment(oneWeekAhead).toISOString(),
              }}
            />
          </Grid>
          <Grid
            item
            sx={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            <SwitchButton
              label={tScoped('Also Done')}
              name="doneTasks"
              handleChange={(e) => handleRadioFilter('doneTasks', e)}
              checked={doneTasks}
            />
          </Grid>
          <Grid
            item
            sx={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            <SwitchButton
              label={tScoped('Only future')}
              name="onlyFutureEvents"
              handleChange={(e) => handleRadioFilter('onlyFuture', e)}
              checked={onlyFuture}
            />
          </Grid>
          <Grid
            item
            sx={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            <SwitchButton
              label={tScoped('Overdue')}
              name="overdue"
              handleChange={(e) => handleRadioFilter('overdue', e)}
              checked={overDue}
            />
            <CustomButton
              label={true}
              labelText={tScoped('New Task')}
              icon={true}
              iconName="plus"
              onClick={() => {
                reset()
                setOpenModal(true)
              }}
            />
          </Grid>
        </Grid>
      </Grid>

      <TableContainer>
        <Table sx={{ minWidth: '744px', marginBottom: '25px' }}>
          <TableBody>
            {taskList.map((task) => (
              <TaskTableRow key={task.taskId} task={task} />
            ))}
          </TableBody>
        </Table>

        <Grid container justifyContent="flex-end" mb={62.5}>
          {isDashboard && totalRecords > MAX_TASK_COUNT ? (
            <Grid item>
              <CustomButton
                icon
                label
                labelText={tScoped('Show More')}
                onClick={() => router.push(taskRoutes[0].path)}
              />
            </Grid>
          ) : null}
        </Grid>

        {!isDashboard && totalRecords > paginationLimit ? (
          <Pagination
            count={Math.ceil(totalRecords / paginationLimit)}
            page={page}
            onChange={onPageChangeHandler}
          />
        ) : null}
      </TableContainer>

      <CustomModal
        open={openModal}
        onClose={() => {
          setOpenModal(false)
          setCurrentFiles(null)
        }}
        sx={{ width: '800px' }}
      >
        <Box
          component="form"
          autoComplete="off"
          onSubmit={handleSubmit(createTaskHandler)}
        >
          <Typography variant="h2" mb={15}>
            {tScoped('Create New Task')}
          </Typography>

          <Grid container mb={10}>
            <Grid item xs={12}>
              <RHFAutocompleteField
                control={control}
                name="assignees"
                label={tScoped('Assignees')}
                multiple
                options={assignees}
                required
              />
            </Grid>

            <Grid item xs={12}>
              <FormLabel>{tScoped('Type')}</FormLabel>
              <RHFAutocompleteField
                control={control}
                name="type"
                label=""
                options={Object.keys(TaskType).map((key) => ({
                  id: key,
                  label: key,
                }))}
                required
              />
            </Grid>

            <Grid item xs={12}>
              <InputField
                control={control}
                name="title"
                label={tScoped('Title')}
                fullWidth
                rules={{
                  required: {
                    value: true,
                    message: validationMessages.required,
                  },
                }}
                error={!!errors.title}
                helperText={errors.title?.message}
              />
            </Grid>

            <Grid item xs={12}>
              <FormLabel sx={{ display: 'block' }}>
                {tScoped('Due Date')}
              </FormLabel>
              <CustomDatePicker
                name="dueDate"
                label=""
                control={control}
                setValue={setValue}
                clearErrors={clearErrors}
                setError={setError}
                dateFormat="dd/MM/yyyy"
                required
              />
            </Grid>

            <Grid item xs={12}>
              <RHFTextArea
                name="note"
                label={tScoped('Note')}
                control={control}
              />
            </Grid>
          </Grid>

          <Grid container justifyContent="space-between" gap={10}>
            <Grid item xs={12}>
              <AddAttachment
                currentFiles={currentFiles}
                fileUploading={fileUploading}
                setCurrentFiles={setCurrentFiles}
                sx={{ marginBottom: '20px' }}
              />
            </Grid>
          </Grid>

          <Grid container justifyContent="flex-end" gap={10}>
            <CustomButton
              label={true}
              labelText={tScoped('Discard')}
              icon={false}
              onClick={() => setOpenModal(false)}
            />
            <CustomButton
              label={true}
              labelText={tScoped('Create')}
              icon={false}
              variant="contained"
              type="submit"
            />
          </Grid>
        </Box>
      </CustomModal>

      {serverError !== '' ? (
        <Toast message={serverError} severity="error" />
      ) : null}

      {taskCreated ? (
        <Toast message={successMessages.taskCreated} severity="success" />
      ) : null}
    </>
  )
}

export default TasksComponent
