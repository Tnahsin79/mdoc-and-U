import AddIcon from '@mui/icons-material/Add'
import CloseIcon from '@mui/icons-material/Close'
import DeleteForeverIcon from '@mui/icons-material/DeleteForever'
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown'

import { useState } from 'react'
import { Condition, Operator, Query } from '@/interface/common'
import {
  Button,
  Grid,
  MenuItem,
  Select,
  TextField,
  Typography,
} from '@mui/material'
import CustomModal from './Modal'
import { useI18n, useScopedI18n } from '../../locales/client'
import moment from 'moment'

interface Filter {
  column: string
  operator: Operator
  value: string
}

interface DataTypeMap {
  string: string
  date: string
  enum: string
  boolean: string
}

interface FilterProps {
  columns: {
    columnName: string
    displayValue:
      | 'Type'
      | 'Title'
      | 'Due Date'
      | 'Note'
      | 'School Type'
      | 'School Name'
      | 'Year Group'
      | 'School Type'
      | 'School Name'
      | 'Year Group'
      | 'Kick Off Group'
      | 'Kick Off'
      | 'First Steps'
      | 'Setup'
      | 'Studies'
      | 'Start School Year'
    dataType: string
    options?: string[]
  }[]
  handleFilter: (query: Query) => void
  defaultValues?: Filter
}
// Event: 'Event',
//   Document: 'Document',
//   Data: 'Data',
//   Message: 'Message'

const getOperatorOptions = (
  dataType: string,
  tScoped: any,
): React.ReactNode => {
  switch (dataType) {
    case 'string':
      return [
        <MenuItem key="equals" value="equals">
          {tScoped('Equals')}
        </MenuItem>,
        <MenuItem key="contains" value="contains">
          {tScoped('Contains')}
        </MenuItem>,
        <MenuItem key="startsWith" value="startsWith">
          {tScoped('Start With')}
        </MenuItem>,
      ]
    case 'enum':
      return [
        <MenuItem key="equals" value="equals">
          {tScoped('Equals')}
        </MenuItem>,
        <MenuItem key="not" value="not">
          {tScoped('Not Equals')}
        </MenuItem>,
      ]
    case 'number':
      return [
        <MenuItem key="equals" value="equals">
          {tScoped('Equals')}
        </MenuItem>,
        <MenuItem key="lt" value="lt">
          {tScoped('Less Than')}
        </MenuItem>,
        <MenuItem key="lte" value="lte">
          {tScoped('Less Than Equals To')}
        </MenuItem>,
        <MenuItem key="gt" value="gt">
          {tScoped('Greater Than')}
        </MenuItem>,
        <MenuItem key="gte" value="gte">
          {tScoped('Greater Than Equals To')}
        </MenuItem>,
      ]
    case 'date':
      return [
        <MenuItem key="equals" value="equals">
          {tScoped('Equals')}
        </MenuItem>,
        <MenuItem key="lt" value="lt">
          {tScoped('Before')}
        </MenuItem>,
        <MenuItem key="lte" value="lte">
          {tScoped('Before or Equals To')}
        </MenuItem>,
        <MenuItem key="gt" value="gt">
          {tScoped('After')}
        </MenuItem>,
        <MenuItem key="gte" value="gte">
          {tScoped('After or Equals To')}
        </MenuItem>,
      ]
    case 'boolean':
      return [
        <MenuItem key="equals" value="equals">
          {tScoped('Equals')}
        </MenuItem>,
      ]
    default:
      return null
  }
}

const getColumnDataType = (
  columns: {
    columnName: string
    displayValue: string
    dataType: string
    options?: string[]
  }[],
  columnName: string,
): string => {
  const dataTypeMap: DataTypeMap = {
    string: 'string',
    date: 'date',
    enum: 'enum',
    boolean: 'boolean',
  }

  const foundColumn = columns.find((col) => col.columnName === columnName)
  return foundColumn
    ? dataTypeMap[foundColumn.dataType as keyof DataTypeMap] || 'unknown'
    : 'unknown'
}

const getValueInput = (
  dataType: string | 'date',
  value: string,
  onChange: (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>,
  ) => void,
  t: any,
  options?: string[],
): React.ReactNode => {
  switch (dataType) {
    case 'string':
      return (
        <TextField
          style={{ marginBottom: 0 }}
          value={value}
          onChange={onChange}
          fullWidth
          variant="outlined"
        />
      )
    case 'number':
      return (
        <TextField
          style={{ marginBottom: 0 }}
          type="number"
          value={value}
          onChange={onChange}
          fullWidth
          variant="outlined"
        />
      )
    case 'boolean':
      return (
        <Select
          value={value}
          onChange={(e) =>
            onChange(
              e as React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>,
            )
          }
          fullWidth
          variant="outlined"
        >
          <MenuItem value="true">{t('True')}</MenuItem>
          <MenuItem value="false">{t('False')}</MenuItem>
        </Select>
      )
    case 'enum':
      return (
        <Select
          value={value}
          onChange={(e) =>
            onChange(
              e as React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>,
            )
          }
          fullWidth
          variant="outlined"
        >
          {options &&
            options.map((option) => (
              <MenuItem key={option} value={option}>
                {option}
              </MenuItem>
            ))}
        </Select>
      )
    case 'date':
      return (
        <TextField
          type="date"
          style={{ marginBottom: 0 }}
          defaultValue={moment(value).format('YYYY-MM-DD')}
          onChange={onChange}
          fullWidth
          variant="outlined"
          placeholder="DD/MM/YYYY"
        />
        // <DateField value={value} onChange={onChange} format="DD/MM/YYYY" />
      )
    default:
      return (
        <TextField
          style={{ marginBottom: 0 }}
          value={value}
          // onChange={onChange}
          onChange={(e) => {
            onChange(e)
          }}
          fullWidth
          variant="outlined"
        />
      )
  }
}

const Filter: React.FC<FilterProps> = ({
  columns,
  handleFilter,
  defaultValues,
}) => {
  const tScoped = useScopedI18n('dashboard')
  const t = useI18n()
  const [open, setOpen] = useState<boolean>(false)
  const [filters, setFilters] = useState<Filter[]>([
    {
      column: defaultValues?.column ? defaultValues?.column : '',
      operator: defaultValues?.operator ? defaultValues?.operator : 'equals',
      value:
        defaultValues?.column === 'dueDate' && defaultValues?.value
          ? defaultValues?.value
          : '',
    },
  ])

  const handleAddFilter = () => {
    setFilters([...filters, { column: '', operator: 'equals', value: '' }])
  }

  const handleRemoveFilter = () => {
    setFilters([])
  }

  const removeFilter = (id: number) => {
    setFilters((filters) => filters.filter((_, index) => index !== id))
  }

  const handleColumnChange = (
    index: number,
    event: React.ChangeEvent<{ value: unknown }>,
  ) => {
    const newFilters = [...filters]
    const selectedColumn = event.target.value as string

    if (selectedColumn !== 'dueDate') {
      newFilters[index].column = selectedColumn
      newFilters[index].value = ''
    } else {
      newFilters[index].column = selectedColumn
      newFilters[index].value = ''
    }

    setFilters(newFilters)
  }

  const handleOperatorChange = (
    index: number,
    event: React.ChangeEvent<{ value: unknown }>,
  ) => {
    const newFilters = [...filters]
    newFilters[index].operator = event.target.value as Operator
    setFilters(newFilters)
  }

  const handleValueChange = (
    index: number,
    event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>,
    dataType?: string,
  ) => {
    // if (dataType === 'date') {
    // } else {
    // }
    // console.log(event.target.value, "Filter Comp Bool Value")
    // if(dataType === 'boolean'){

    // }
    const newFilters = [...filters]
    newFilters[index].value = event.target.value
    setFilters(newFilters)
  }

  const getData = () => {
    const query: Query = {
      AND: [],
    }
    filters.forEach((filter) => {
      const { column, operator, value } = filter
      const col = columns.find((col) => col.columnName === column)

      if (operator && value !== '') {
        const condition: Condition = {} // Define condition here

        if (
          column === 'kickOff' ||
          column === 'firstSteps' ||
          column === 'setUp' ||
          column === 'studies'
        ) {
          condition[column] = value === 'true' ? true : false
        } else if (operator === 'lt' || operator === 'lte') {
          const numericalValue =
            col?.dataType === 'date' ? moment(value).toISOString() : value
          condition[column] = {
            [operator]: numericalValue,
          }
        } else if (operator === 'not' || operator === 'equals') {
          const val =
            col?.dataType === 'enum' || col?.dataType === 'string' ? value : ''
          condition[column] = {
            [operator]: val,
          }
        } else {
          condition[column] = {
            [operator]: col?.dataType === 'date' ? new Date(value) : value,
            ...(operator === 'contains' ||
            col?.dataType !== 'date' ||
            operator === 'startsWith'
              ? { mode: 'insensitive' }
              : {}),
          } as Condition[keyof Condition]
        }

        query.AND.push(condition)
      }
    })

    handleFilter(query)
    setOpen(false)
  }

  return (
    <>
      <Button
        variant="outlined"
        size="small"
        startIcon={<KeyboardArrowDownIcon />}
        onClick={() => setOpen(true)}
        sx={{
          background: 'none',
          '&:focus': {
            background: 'none',
          },
        }}
        disableFocusRipple
      >
        {tScoped('Open Filter')}
      </Button>
      <CustomModal
        open={open}
        onClose={() => setOpen(false)}
        sx={{ width: '700px' }}
      >
        <Grid container spacing={12} alignItems="center" mb={12}>
          <Grid item xs={1}></Grid>
          <Grid item xs={4}>
            <Typography variant="subtitle2">{tScoped('Columns')}</Typography>
          </Grid>
          <Grid item xs={3}>
            <Typography variant="subtitle2">{tScoped('Operator')}</Typography>
          </Grid>
          <Grid item xs={4}>
            <Typography variant="subtitle2">{tScoped('Value')}</Typography>
          </Grid>
        </Grid>
        <Grid container alignItems="center" spacing={12} mb={12}>
          {filters.map((filter, index) => {
            return (
              <Grid
                item
                xs={12}
                container
                spacing={12}
                key={index}
                alignItems="center"
              >
                <Grid item xs={1}>
                  <Button
                    variant="outlined"
                    size="small"
                    startIcon={<CloseIcon />}
                    onClick={() => removeFilter(index)}
                    sx={{ float: 'right' }}
                  />
                </Grid>
                <Grid item xs={4}>
                  <Select
                    value={filter.column}
                    onChange={(e) =>
                      handleColumnChange(
                        index,
                        e as React.ChangeEvent<{ value: unknown }>,
                      )
                    }
                    fullWidth
                  >
                    {columns.map((column) => (
                      <MenuItem
                        key={column.columnName}
                        value={column.columnName}
                      >
                        {tScoped(column.displayValue)}
                      </MenuItem>
                    ))}
                  </Select>
                </Grid>
                <Grid item xs={3}>
                  <Select
                    value={filter.operator}
                    onChange={(e) =>
                      handleOperatorChange(
                        index,
                        e as React.ChangeEvent<{ value: unknown }>,
                      )
                    }
                    fullWidth
                  >
                    {getOperatorOptions(
                      columns.find((col) => col.columnName === filter.column)
                        ?.dataType ?? 'string',
                      tScoped,
                    )}
                  </Select>
                </Grid>
                <Grid item xs={4}>
                  {getValueInput(
                    getColumnDataType(columns, filter.column),
                    filter.value,
                    (e) => {
                      handleValueChange(
                        index,
                        e,
                        getColumnDataType(columns, filter.column),
                      )
                    },
                    t,
                    columns.find((col) => col.columnName === filter.column)
                      ?.options,
                  )}
                </Grid>
              </Grid>
            )
          })}
        </Grid>

        <Grid container justifyContent="space-between" alignItems="center">
          <Grid item xs={6}>
            <Button
              variant="outlined"
              size="small"
              startIcon={<DeleteForeverIcon />}
              onClick={handleRemoveFilter}
            >
              {tScoped('Remove All Filters')}
            </Button>
          </Grid>
          <Grid
            item
            xs={6}
            container
            alignItems="center"
            justifyContent="flex-end"
          >
            <Button
              variant="outlined"
              size="small"
              startIcon={<AddIcon />}
              onClick={handleAddFilter}
              sx={{ marginRight: '10px' }}
            >
              {tScoped('Add Filter')}
            </Button>

            <Button variant="contained" size="small" onClick={getData}>
              {tScoped('Get Data')}
            </Button>
          </Grid>
        </Grid>
      </CustomModal>
    </>
  )
}

export default Filter
