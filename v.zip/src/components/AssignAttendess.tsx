import { Box, Grid, Typography } from '@mui/material'
import React from 'react'
import { useFormContext } from 'react-hook-form'

import Button from '@/components/Buttons/CustomButton'
import { RHFAutocompleteField } from './DropDown'
import InputField from './InputField'
import CustomModal from './Modal'
import CustomRadioGroup from './RadioGroup'
import { IList } from '@/interface/common'
import { useScopedI18n } from '../../locales/client'

interface IAssignAttendeesProps {
  open: boolean
  handleClose: () => void
  phases: IList
  attendees: any
  subjectAreas: IList
  readOnly?: boolean
  suitableCollaboratorId?: number
}

const AssignAttendees = ({
  open,
  handleClose,
  phases,
  attendees,
  subjectAreas,
  readOnly = false,
  suitableCollaboratorId,
}: IAssignAttendeesProps) => {
  const tScoped = useScopedI18n('event')
  const { control, trigger, getValues } = useFormContext()
  const values = getValues()

  const onSave = async () => {
    const isValid = await trigger('attendeesId')
    if (isValid) {
      handleClose()
    } else {
      return
    }
  }

  const getFullName = (person: any) =>
    `${person.firstName}${person.lastName ? ' ' + person.lastName : ''}`

  const attendeesDropdownData = attendees.group && [
    ...attendees?.group?.map((group: any) => ({
      id: group.groupId,
      value: group.name,
      type: 'Group',
    })),
    ...attendees?.persons.map((person: any) => ({
      id: +person.personId,
      value: getFullName(person),
      type: person.role,
    })),
  ]

  const attendeesDropdownOptions = attendeesDropdownData
    ?.filter((item: any) => item?.id !== suitableCollaboratorId)
    ?.sort((a: any, b: any) => {
      return a?.type?.localeCompare(b.type)
    })
    .map((item: any) => ({
      id: `${item.type}_${item.id}`,
      label: item?.value,
      type: item?.type,
    }))

  return (
    <>
      <CustomModal open={open} onClose={handleClose}>
        <Typography
          variant="h6"
          component="h2"
          mb={10}
          sx={{ fontWeight: 700, fontSize: '28px', color: '#E40422' }}
        >
          {tScoped('Assign Attendees')}
        </Typography>

        <Box>
          <Grid item xs={12} md={6} justifyContent="center" alignItems="center">
            <CustomRadioGroup
              disabled
              name="phaseId"
              row
              required
              label={tScoped('Phase (Not Editable)')}
              control={control}
              options={phases?.map((item) => {
                return {
                  value: item.listId.toString(),
                  label: item.listValue,
                }
              })}
            />
          </Grid>
          <InputField
            control={control}
            name="subjectAreaId"
            label={tScoped('Subject Area (Not Editable)')}
            disabled
            fullWidth
            value={
              subjectAreas?.filter(
                (item) => item?.listId === values?.subjectAreaId,
              )?.[0]?.listValue
            }
          />
          <InputField
            control={control}
            name="subjectModule"
            label={tScoped('Module (Not Editable)')}
            disabled
            fullWidth
          />

          <RHFAutocompleteField
            multiple
            groupBy={(option: any) => option.type}
            required={!readOnly}
            control={control}
            options={attendeesDropdownOptions}
            name="attendeesId"
            label={tScoped('Attendees')}
            readOnly={readOnly}
          />
          <Grid
            container
            justifyContent="flex-end"
            alignItems="center"
            marginY={10}
          >
            <Button
              label
              icon
              labelText="Save"
              iconName="save"
              onClick={onSave}
            />
          </Grid>
        </Box>
      </CustomModal>
    </>
  )
}

export default AssignAttendees
