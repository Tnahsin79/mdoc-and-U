import { TableCell, TableRow, Typography } from '@mui/material'
import CustomButton from './Buttons/CustomButton'

interface ProfileAddressProps {
  primary?: boolean
}

const ProfileAddressRow: React.FC<ProfileAddressProps> = (props) => {
  const { primary = false } = props

  return (
    <TableRow>
      <TableCell>
        <Typography variant="h5" sx={{ fontWeight: 700, width: '300px' }}>
          Hauptstraße 5a, 1231 Wanne-Eikel
        </Typography>
      </TableCell>

      <TableCell align="right" width="144px">
        <Typography variant="h6">mara@musterfrau.de</Typography>
      </TableCell>

      <TableCell align="right" width="72px">
        <Typography variant="h6">01731294</Typography>
      </TableCell>

      {primary ? (
        <TableCell align="right" width="150px">
          <Typography
            sx={{
              color: '#E40422',
              fontSize: '16px',
              fontWeight: 700,
              width: '100%',
            }}
          >
            Primary Address
          </Typography>
        </TableCell>
      ) : (
        <TableCell align="right" width="290px">
          <CustomButton
            icon
            label
            labelText="Make Primary Address"
            iconName="arrowRight"
          />
        </TableCell>
      )}
    </TableRow>
  )
}

export default ProfileAddressRow
