import { Box, Chip, TableCell, TableRow, Typography } from '@mui/material'
import { Event } from '@prisma/client'
import moment from 'moment'
import { useRouter } from 'next/navigation'
import { useContext } from 'react'

import { UserContext } from '@/contexts/userContext'
import IconSwitcher from '../Icons'
import { useScopedI18n } from '../../../locales/client'

interface eventTableRowInterface {
  event: Event & {
    suitableRooms: {
      listId: number
      listType: string
      listValue: string
      isActive: boolean
    }
    location: {
      listId: number
      listType: string
      listValue: string
      isActive: boolean
    }
  }
  phase: {
    listId: number
    listType: string
    listValue: string
    isActive: boolean
  }
}

const timeFormatter = (time: string) => {
  return moment(time).format('HH:mm')
}

const EventTableRow: React.FC<eventTableRowInterface> = ({
  event,
  phase,
}: eventTableRowInterface) => {
  const tScoped = useScopedI18n('event')
  const router = useRouter()
  const { user } = useContext(UserContext)

  return (
    <TableRow
      sx={{ cursor: 'pointer' }}
      onClick={() =>
        user?.role === 'Collaborator'
          ? router.push(`/collaborator/confirm-participants/${event.eventId}`)
          : router.push(`/event/edit/${event.eventId}`)
      }
    >
      <TableCell width="90px" align="left">
        <Typography variant="h6">{timeFormatter(event.startTime)} -</Typography>
        <Typography variant="h6">{timeFormatter(event.endTime)}</Typography>
      </TableCell>

      <TableCell scope="row" align="left">
        <Typography variant="h5">{event.title}</Typography>
      </TableCell>

      <TableCell align="right" width="245px">
        <Box display="flex" gap="10px" flexWrap="wrap">
          <Chip label={phase.listValue} sx={{ background: '#E40422' }} />
        </Box>
      </TableCell>
      <TableCell align="right" width="130px">
        <Typography variant="h6">
          {tScoped('Room')} {event?.suitableRooms?.listValue}
        </Typography>
      </TableCell>

      <TableCell align="right" width="200px">
        <Typography variant="h6">{event?.location?.listValue}</Typography>
      </TableCell>

      <TableCell align="right" width="44px">
        <IconSwitcher icon="redArrowRight" />
      </TableCell>
    </TableRow>
  )
}

export default EventTableRow
