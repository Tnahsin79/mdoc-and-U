'use client'
import { ICollaborator } from '@/interface/common'
import {
  Box,
  Grid,
  Chip as MUIChip,
  TableCell,
  TableRow,
  Typography,
} from '@mui/material'

import { styled } from '@mui/system'

import IconSwitcher from '../Icons'
import { frontendRoutes } from '@/utils/constants/frontend'
import { phasesOptions } from '@/utils/constants/common'

import Button from '@/components/Buttons/CustomButton'
import axiosInstance from '@/services/axiosInstance'
import Toast from '../Toast'
import { useEffect, useState } from 'react'
import { IToastData } from '@/interface/common'
import { errorMessages } from '@/utils/errorMessages'
import { useRouter } from 'next/navigation'
import { useScopedI18n } from '../../../locales/client'
import Phases from '../Phases'

const Chip = styled(MUIChip)({
  border: '1px solid #000',
  padding: '0px',
  height: '24px',
  width: '24px',
  color: '#000',
  background: 'transparent',
})

const ActiveChip = styled(Chip)({
  background: '#E40422',
  color: '#fff',
})

const CollaboratorTableRow: React.FC<ICollaborator> = ({
  collaboratorId,
  person: { firstName, lastName, email, isActive, phoneNumber },
  phasePreferenceId,
  pinNo,
  schoolTypeId,
  collaboratorSchoolRole,
  jobTitle,
  onClick,
}) => {

  const phase = phasesOptions.find((phase) => phase.id === phasePreferenceId)
  const tScoped = useScopedI18n('collaborators')

  const [toastData, setToastData] = useState<IToastData>({
    type: undefined,
    message: '',
  })
  const [loading, setLoading] = useState<boolean>(false)

  const router = useRouter()

  useEffect(() => {
    setTimeout(() => {
      setToastData({
        type: undefined,
        message: '',
      })
    }, 5000)
  }, [JSON.stringify(toastData)])

  const sendActivationEmail = async () => {
    setLoading(true)
    try {
      const res = await axiosInstance.post(`/api/send-set-password-mail`, {
        email,
      })
      setToastData({
        type: 'success',
        message: res.data.message,
      })
    } catch (error: any) {
      setToastData({
        type: 'error',
        message: error?.message || errorMessages.DEFAULT_ERROR,
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <>
      {toastData.message !== '' ? (
        <Toast message={toastData.message} severity={toastData.type} />
      ) : null}

      <TableRow
        sx={{ cursor: 'pointer' }}
        onClick={() => {
          router.push(`${frontendRoutes.collaborator.edit}/${collaboratorId}`)
        }}
      >
        <TableCell>
          <Typography variant="h5">
            {firstName} {lastName}
          </Typography>
        </TableCell>

        <TableCell align="right" width="225px">
          {phasePreferenceId ? <Phases phase={phasePreferenceId} /> : null}
        </TableCell>

        <TableCell>
          <Typography variant="h6">{pinNo}</Typography>
        </TableCell>

        <TableCell>
          <Grid container flexDirection="column">
            <Grid item xs={4}>
              <Typography variant="h6">{schoolTypeId}</Typography>
            </Grid>
            <Grid item xs={8}>
              <Typography variant="h6">{collaboratorSchoolRole}</Typography>
            </Grid>
          </Grid>
        </TableCell>

        <TableCell>
          <Typography variant="h6">{jobTitle}</Typography>
        </TableCell>

        <TableCell align="right">
          <Typography variant="h6">{phoneNumber}</Typography>
        </TableCell>

        <TableCell align="right" width="44px">
          <IconSwitcher icon="redArrowRight" />
        </TableCell>
      </TableRow>
    </>
  )
}

export default CollaboratorTableRow
