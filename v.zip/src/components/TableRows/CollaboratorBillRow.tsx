'use client'
import { Bill } from '@prisma/client'
import { Grid, TableCell, TableRow, Typography } from '@mui/material'

import moment from 'moment'
import IconSwitcher from '../Icons'
interface IBill extends Omit<Bill, 'attachment'> {
  collaborator?: {
    person: {
      firstName: string
      lastName: string
    }
  }
}

const CollaboratorBillRow = ({
  bill: { amount, title, date, billId, collaborator },
  onClickHandler,
}: {
  bill: IBill
  onClickHandler?: (billId: number) => void
}) => {
  return (
    <TableRow onClick={() => onClickHandler && onClickHandler(billId)}>
      {collaborator ? (
        <TableCell align="left" width={200}>
          <Typography variant="h5">
            {collaborator.person.firstName} {collaborator.person.lastName}
          </Typography>
        </TableCell>
      ) : null}
      <TableCell align="left">
        <Typography variant="h5">{title}</Typography>
      </TableCell>

      <TableCell align="left">
        <Typography variant="h4" sx={{ fontSize: '20px !important' }}>
          {amount.toString()} €
        </Typography>
      </TableCell>

      <TableCell align="right">
        <Grid
          container
          columnSpacing={20}
          justifyContent="flex-end"
          alignItems="center"
        >
          <Grid item>
            <Typography variant="h5">
              {moment(date).format('DD.MM.YY')}
            </Typography>
          </Grid>
          <Grid item onClick={() => onClickHandler && onClickHandler(billId)}>
            <IconSwitcher icon="redArrowRight" />
          </Grid>
        </Grid>
      </TableCell>
    </TableRow>
  )
}

export default CollaboratorBillRow
