import { TableCell, TableRow, Typography } from '@mui/material'
import { School } from '@prisma/client'
import Link from 'next/link'
import { frontendRoutes } from '@/utils/constants/frontend'
import IconSwitcher from '../Icons'
import { useEffect, useState } from 'react'
import { PLZ } from '@/utils/constants/berlin_district_PLZ'

const SchoolTableRow = ({
  school: {
    schoolName,
    phoneNumber,
    emailAddress,
    streetAndHouseNo,
    schoolId,
    postalCode,
    BSN,
  },
  onClick,
}: {
  school: School
  onClick: () => void
}) => {
  const [plz, setPlz] = useState<{
    PLZ: string
    District: string
  }>({
    PLZ: '',
    District: '',
  })

  const getPLZ = () => {
    const currPlz = PLZ.find((plz) => plz.PLZ === postalCode)
    if (currPlz) {
      setPlz(currPlz)
    }
    setPlz(currPlz!)
  }

  useEffect(() => {
    getPLZ()
  }, [])

  return (
    <TableRow onClick={onClick} sx={{ cursor: 'pointer' }}>
      <TableCell>
        <Typography variant="h5">{BSN}</Typography>
      </TableCell>
      <TableCell>
        <Typography variant="h5">-</Typography>
      </TableCell>
      <TableCell>
        <Typography variant="h5">{schoolName}</Typography>
      </TableCell>

      <TableCell align="right" width="260px">
        <Typography variant="h6">
          {streetAndHouseNo ? `${streetAndHouseNo}, ` : ''}
          {(plz?.District && plz?.PLZ) ? `${plz?.District} (${plz?.PLZ})` : ''}
        </Typography>
      </TableCell>

      <TableCell align="right" width="140px">
        <Typography variant="h6">{phoneNumber}</Typography>
      </TableCell>

      <TableCell align="right" width="140px">
        <Typography variant="h6">{emailAddress}</Typography>
      </TableCell>

      <TableCell align="right" width="44px">
        <Link href={`${frontendRoutes.school.edit}/${schoolId}`}>
          <IconSwitcher icon="redArrowRight" />
        </Link>
      </TableCell>
    </TableRow>
  )
}

export default SchoolTableRow
