import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Box,
  Grid,
  Typography,
  styled,
  Link,
  InputLabel,
} from '@mui/material'
import IconSwitcher from '../Icons'
import CustomButton from '../Buttons/CustomButton'
import moment from 'moment'
import axiosInstance from '@/services/axiosInstance'
import { useEffect, useState } from 'react'
import { useScopedI18n } from '../../../locales/client'
import { useForm } from 'react-hook-form'
import CustomRadioGroup from '../RadioGroup'
import InputField from '../InputField'
import { RHFAutocompleteField } from '../DropDown'
import { IList } from '@/interface/common'
import { List } from '@prisma/client'
import Toast from '../Toast'

interface IMessageRow {
  preposition: 'From' | 'To'
  sender: {
    email: string
    firstName: string
    lastName: string | null
  }
  recipient: {
    email: string
    firstName: string
    lastName: string | null
  }
  topic: string
  date: string
  message: string
  role: 'Candidate' | 'Employee' | 'Collaborator'
  id: number
  read: boolean
  isNote: boolean
  onReply?: () => void
  attachment?: string
  openTaskModal?: () => void
  nonAssigned?: boolean
  onAssign?: () => void
  isBuddyRequest?: boolean
  availableId?: number
  howFarDistance?: number
  howManyToSupport?: number
  schoolTypesIds?: number[]
  isSubmitted?: boolean
  yesOrNo?: IList
  schoolType?: IList
}

const FileName = styled(Link)({
  fontWeight: 400,
  maxWidth: '150px',
  overflow: 'hidden',
  textOverflow: 'ellipsis',
  whiteSpace: 'nowrap',
  color: '#0000EE',
  textDecoration: 'none',
  cursor: 'pointer',
})

const MessageRow: React.FC<IMessageRow> = ({
  preposition,
  sender,
  recipient,
  topic,
  date,
  message,
  role = 'Candidate',
  id,
  read,
  isNote,
  onReply,
  attachment,
  openTaskModal,
  nonAssigned = false,
  onAssign,
  isBuddyRequest,
  yesOrNo,
  schoolType,
  availableId,
  howFarDistance,
  howManyToSupport,
  schoolTypesIds,
  isSubmitted,
}) => {
  const tScoped = useScopedI18n('communication')

  const [serverError, setServerError] = useState<string>('')
  const [buddyRequestSubmitted, setBuddyRequestSubmitted] = useState<string>('')
  const [submitted, setSubmitted] = useState<boolean>(false)

  const formattedDate = moment(date.toString().split('T')[0]).format(
    'DD.MM.YYYY',
  )

  const [readReceipt, setReadReceipt] = useState<boolean>(read)

  const {
    handleSubmit,
    formState: { errors },
    control,
    clearErrors,
    setValue,
    setError,
    watch,
    reset,
    resetField,
  } = useForm<any>({
    mode: 'all',
    shouldFocusError: true,
  })

  const getBuddyRequestDetails = async () => {
    try {
      setValue('availableId', availableId?.toString())
      setValue('howFarDistance', howFarDistance)
      setValue('howManyToSupport', howManyToSupport)
      setValue('schoolTypeIds', schoolTypesIds)
      if (isSubmitted) {
        setSubmitted(isSubmitted)
      }
    } catch (error) {}
  }

  useEffect(() => {
    if (role === 'Collaborator' && isBuddyRequest) {
      getBuddyRequestDetails()
    }
  }, [])

  const buddyRequestSubmitHandler = async (payload: any) => {
    try {
      setBuddyRequestSubmitted('')
      const res = await axiosInstance.post('/api/buddy-request', {
        availableId: +payload.availableId,
        howFarDistance: payload.howFarDistance,
        howManyToSupport: payload.howManyToSupport,
        schoolTypeIds: payload.schoolTypeIds,
        communicationId: id,
      })

      if (res.status === 201) {
        setBuddyRequestSubmitted('Success')
        setSubmitted(true)
      }
    } catch (error: any) {
      setServerError(error.message)
    }
  }

  const readReceiptHandler = async () => {
    if (!read && !readReceipt && preposition === 'From') {
      await axiosInstance.post(`/api/communication/read`, {
        id,
      })
      setReadReceipt(true)
    }
  }

  const openFileInNewTab = async (file: string) => {
    const responseFromFileServer = await axiosInstance.post(
      '/api/attachment/get-attachment-link',
      { fileName: file },
    )

    let fileURLFromFileServer = ''
    if (responseFromFileServer.status === 200) {
      fileURLFromFileServer = responseFromFileServer.data.url
    }

    window.open(fileURLFromFileServer, '_blank')
  }

  return (
    <>
      <Accordion
        TransitionProps={{ unmountOnExit: true }}
        sx={{
          display: 'flex',
          flexDirection: 'column',
          marginBottom: '10px',
          border: '1px solid black',
        }}
        onClick={readReceiptHandler}
      >
        <AccordionSummary
          expandIcon={<IconSwitcher icon="redArrowDown" />}
          sx={{
            width: '100%',
            paddingY: '22px',
            paddingX: '15px',
          }}
        >
          <Box
            sx={{
              display: 'flex',
              justifyContent: 'space-around',
              width: '50%',
            }}
          >
            <Grid container sx={{ flexDirection: 'column' }}>
              <Grid container sx={{ alignItems: 'center' }} item>
                <Grid item>
                  <Typography sx={{ fontSize: '16px', fontWeight: 400 }}>
                    {tScoped('From')}: 
                  </Typography>
                </Grid>
                <Grid item>
                  <Typography sx={{ fontSize: '16px', fontWeight: 700 }}>
                    {sender.firstName} {sender.lastName && sender.lastName}
                  </Typography>
                </Grid>
              </Grid>
              {!isNote && (
                <Grid item>
                  <Typography sx={{ fontSize: '16px', fontWeight: 400 }}>
                    {sender.email}
                  </Typography>
                </Grid>
              )}
            </Grid>
            <Grid container sx={{ flexDirection: 'column' }}>
              <Grid container sx={{ alignItems: 'center' }} item>
                <Grid item>
                  <Typography sx={{ fontSize: '16px', fontWeight: 400 }}>
                    {tScoped('To')}: 
                  </Typography>
                </Grid>
                <Grid item>
                  <Typography sx={{ fontSize: '16px', fontWeight: 700 }}>
                    {recipient.firstName} 
                    {recipient.lastName && recipient.lastName}
                  </Typography>
                </Grid>
              </Grid>
              {!isNote && (
                <Grid item>
                  <Typography sx={{ fontSize: '16px', fontWeight: 400 }}>
                    {recipient.email}
                  </Typography>
                </Grid>
              )}
            </Grid>
            {isNote && (
              <Typography
                sx={{
                  backgroundColor: '#0000FF',
                  color: '#FFFFFF',
                  width: '100px',
                  height: '23px',
                  display: 'flex',
                  justifyContent: 'center',
                  fontSize: '16px',
                  fontWeight: 700,
                  marginLeft: '16px',
                }}
              >
                {tScoped('Note')}
              </Typography>
            )}
          </Box>

          <Box
            sx={{
              display: 'flex',
              justifyContent: 'space-around',
              alignItems: 'center',
              width: '50%',
            }}
          >
            <Box sx={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
              {attachment !== '' && <IconSwitcher icon="attachment" />}
              <Typography sx={{ fontSize: '16px', fontWeight: 400 }}>
                {tScoped('Topic')}: 
              </Typography>
              <Typography
                sx={{ fontSize: '16px', fontWeight: 700, maxWidth: '180px' }}
              >
                {topic}
              </Typography>
            </Box>

            <Box>
              {' '}
              {!readReceipt && (
                <Typography
                  sx={{
                    backgroundColor: '#E40422',
                    color: '#FFFFFF',
                    width: '50px',
                    height: '23px',
                    display: 'flex',
                    justifyContent: 'center',
                    fontSize: '16px',
                    fontWeight: 700,
                    marginLeft: '16px',
                  }}
                >
                  {tScoped('New')}
                </Typography>
              )}
            </Box>

            <Box>
              <Typography sx={{ fontWeight: 400, fontSize: '16px' }}>
                {formattedDate}
              </Typography>
            </Box>
          </Box>
        </AccordionSummary>

        <AccordionDetails
          sx={{
            paddingX: '15px',
            paddingY: '22px',
            display: 'flex',
            flexDirection: 'column',
          }}
        >
          <Box>
            <Typography sx={{ whiteSpace: 'pre-line' }}>{message}</Typography>
          </Box>

          <Box paddingTop={10}>
            {attachment ? (
              <FileName onClick={() => openFileInNewTab(attachment)}>
                {tScoped('Attachment')}
              </FileName>
            ) : null}
          </Box>
          {role === 'Employee' && (
            <Box
              sx={{
                display: 'flex',
                justifyContent: 'flex-end',
                gap: '20px',
                marginTop: '20px',
              }}
            >
              {preposition === 'From' && nonAssigned === false && (
                <CustomButton
                  icon
                  label
                  labelText={tScoped('Reply')}
                  iconName="arrowRight"
                  onClick={onReply ? () => onReply() : () => {}}
                />
              )}
              {nonAssigned === true && (
                <CustomButton
                  icon
                  label
                  labelText={tScoped('Assign')}
                  iconName="folderAdd"
                  onClick={onAssign}
                />
              )}
              {nonAssigned === false && (
                <CustomButton
                  icon
                  label
                  labelText={tScoped('Create Task')}
                  iconName="plus"
                  onClick={openTaskModal}
                />
              )}
            </Box>
          )}

          {role === 'Collaborator' && (
            <>
              {isBuddyRequest ? (
                <Box
                  sx={
                    {
                      // display: 'flex',
                      // justifyContent: 'flex-end',
                      // gap: '20px',
                      // marginTop: '20px',
                    }
                  }
                  component="form"
                  autoComplete="off"
                  onSubmit={handleSubmit(buddyRequestSubmitHandler)}
                >
                  <CustomRadioGroup
                    name="availableId"
                    row
                    required
                    label={tScoped(
                      'Are you available for the buddy program during the requested time period ?',
                    )}
                    control={control}
                    options={
                      yesOrNo?.map((item) => ({
                        value: item?.listId?.toString() || '',
                        label: item?.listValue || '',
                      })) || []
                    }
                    readOnly={submitted}
                  />
                  <InputField
                    control={control}
                    name="howManyToSupport"
                    label={tScoped(
                      'How many Lehrkräfte im Quereinstieg are you willing to accompany',
                    )}
                    readOnly={submitted}
                  />
                  <InputField
                    control={control}
                    name="howFarDistance"
                    label={tScoped(
                      'In which distance can the school be located at which the Lehrkraft im Quereinstieg is working. ',
                    )}
                    readOnly={submitted}
                  />
                  <RHFAutocompleteField
                    control={control}
                    options={(schoolType || []).map((item) => ({
                      id: item?.listId || -1,
                      label: item?.listValue || '',
                    }))}
                    multiple
                    name="schoolTypeIds"
                    readOnly={submitted}
                    label={tScoped('Which school type do you prefer ?')}
                  />
                  <CustomButton
                    label
                    labelText={tScoped('Submit')}
                    type="submit"
                    disabled={submitted}
                  />
                </Box>
              ) : (
                <Box
                  sx={{
                    display: 'flex',
                    justifyContent: 'flex-end',
                    gap: '20px',
                    marginTop: '20px',
                  }}
                >
                  {preposition === 'From' && (
                    <CustomButton
                      icon
                      label
                      labelText={tScoped('Answer')}
                      iconName="arrowRight"
                      onClick={onReply ? () => onReply() : () => {}}
                    />
                  )}
                </Box>
              )}
            </>
          )}

          {role === 'Candidate' && (
            <Grid
              sx={{
                display: 'flex',
                justifyContent: 'flex-end',
                gap: '20px',
                marginTop: '20px',
              }}
            >
              {preposition === 'From' && (
                <CustomButton
                  icon
                  label
                  labelText={tScoped('Reply')}
                  iconName="arrowRight"
                  onClick={onReply ? () => onReply() : () => {}}
                />
              )}
            </Grid>
          )}
        </AccordionDetails>
      </Accordion>
      {buddyRequestSubmitted !== '' ? (
        <Toast message={buddyRequestSubmitted} severity="success" />
      ) : null}
      {serverError !== '' ? (
        <Toast message={serverError} severity="error" />
      ) : null}
    </>
  )
}

export default MessageRow
