import React from 'react'
import { TableCell, TableRow, Typography } from '@mui/material'
import { useRouter } from 'next/navigation'
import { frontendRoutes } from '@/utils/constants/frontend'

export interface IEmployee {
  firstName: string
  lastName: string
  email: string
  personId: number
}

interface EmployeeTableRowProps {
  employee: IEmployee
}

const EmployeeTableRow: React.FC<EmployeeTableRowProps> = ({
  employee: { firstName, lastName, email, personId },
}) => {
  const router = useRouter()

  return (
    <>
      <TableRow
        sx={{ cursor: 'pointer' }}
        onClick={() =>
          router.push(`${frontendRoutes.employee.data}/${personId}`)
        }
      >
        <TableCell>
          <Typography variant="h5">{`${firstName} ${lastName}`}</Typography>
        </TableCell>
        <TableCell align="right" width="171px">
          {email}
        </TableCell>
      </TableRow>
    </>
  )
}

export default EmployeeTableRow
