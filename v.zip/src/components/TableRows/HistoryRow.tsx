import moment from 'moment'
import { TableCell, TableRow, Typography } from '@mui/material'

interface IHistoryTableRow {
  actionType: string
  actionDetail: string
  actionReference: string
  createdAt: Date
}

const HistoryTableRow = ({
  actionType,
  actionDetail,
  actionReference,
  createdAt,
}: IHistoryTableRow) => {
  return (
    <TableRow>
      <TableCell width="400px">
        <Typography variant="h5">{actionType}</Typography>
      </TableCell>

      <TableCell align="right" width="400px">
        <Typography variant="h6">{actionDetail}</Typography>
      </TableCell>

      <TableCell align="right" width="200px" sx={{ whiteSpace: 'nowrap' }}>
        <Typography variant="h6">{actionReference}</Typography>
      </TableCell>

      <TableCell align="right" width="200px" sx={{ whiteSpace: 'nowrap' }}>
        {moment(createdAt).format('DD.MM.YY')}
      </TableCell>
    </TableRow>
  )
}

export default HistoryTableRow
