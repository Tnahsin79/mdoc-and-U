import Phases from '../Phases'
import IconSwitcher from '../Icons'

import { useRouter } from 'next/navigation'
import { frontendRoutes } from '@/utils/constants/frontend'
import { Grid, TableCell, TableRow, Typography } from '@mui/material'

import Toast from '../Toast'
import { useEffect, useState } from 'react'
import { IToastData } from '@/interface/common'
import { schoolTypeValues } from '@/utils/constants/common'

interface ICandidateTableRow {
  candidate: {
    candidateId: number
    startSchoolYear: number
    person: {
      firstName: string
      lastName: string
      isActive: boolean
      email: string
    }
    phaseRequiredId: number
    school: {
      schoolName: string
      schoolType: {
        listValue: string
      }
      BSN: string
    }
    yearGroup: {
      listValue: string
    }
    kickOffGroup: {
      listValue: string
    }
    fromDate: string
    untilDate: string
    firstSubjectToBeStudied: {
      listValue: string
    }
    secondSubjectToBeStudied: {
      listValue: string
    }
    startSubjectA: {
      listValue: string
    }
    startSubjectB: {
      listValue: string
    }
    studiesGroupSubjectA: {
      listValue: string
    }
    studiesGroupSubjectB: {
      listValue: string
    }
  }
}

const CandidateTableRow: React.FC<ICandidateTableRow> = ({
  candidate: {
    candidateId,
    startSchoolYear,
    person: { firstName, lastName, isActive },
    phaseRequiredId,
    yearGroup,
    kickOffGroup,
    school: { schoolName, schoolType, BSN },
    fromDate,
    untilDate,
    firstSubjectToBeStudied,
    secondSubjectToBeStudied,
    startSubjectA,
    startSubjectB,
    studiesGroupSubjectA,
    studiesGroupSubjectB,
  },
}) => {
  const router = useRouter()
  const [toastData, setToastData] = useState<IToastData>({
    type: undefined,
    message: '',
  })
  const [isOnleave, setIsOnLeave] = useState<boolean>(false)

  const onLeaveHandler = () => {
    const now = new Date()
    const from = new Date(fromDate)
    const to = new Date(untilDate)
    const check = new Date(now.toISOString())
    if (check >= from && check <= to) {
      setIsOnLeave(true)
    } else {
      setIsOnLeave(false)
    }
  }

  useEffect(() => {
    onLeaveHandler()
  }, [])

  useEffect(() => {
    setTimeout(() => {
      setToastData({
        type: undefined,
        message: '',
      })
    }, 5000)
  }, [JSON.stringify(toastData)])

  return (
    <>
      {toastData.message !== '' ? (
        <Toast message={toastData.message} severity={toastData.type} />
      ) : null}

      <TableRow
        sx={{ cursor: 'pointer', backgroundColor: isActive ? '' : '#d9d9d9' }}
        onClick={() =>
          router.push(`${frontendRoutes.candidate.data}/${candidateId}`)
        }
      >
        <TableCell>{isOnleave && <IconSwitcher icon="onLeave" />}</TableCell>
        <TableCell>
          <Typography variant="h5">{`${firstName} ${lastName}`}</Typography>
        </TableCell>
        <TableCell align="right">
          <Phases phase={phaseRequiredId} />
        </TableCell>
        <TableCell
          align="right"
          // sx={{width:"0.625rem"}}
        >
          {startSchoolYear && (
            <Typography variant="h6" whiteSpace="nowrap">
              {startSchoolYear}-{yearGroup?.listValue}-{kickOffGroup?.listValue}
            </Typography>
          )}
        </TableCell>
        <TableCell>
          <Typography variant="h6">
            {schoolTypeValues[`${schoolType.listValue}`]}
          </Typography>
        </TableCell>
        <TableCell>
          <Grid container flexDirection="column" spacing={4}>
            <Grid item>
              <Typography variant="h6">
                {firstSubjectToBeStudied?.listValue}
              </Typography>
            </Grid>
            <Grid item>
              <Typography variant="h6">
                {secondSubjectToBeStudied?.listValue}
              </Typography>
            </Grid>
          </Grid>
        </TableCell>
        <TableCell>
          <Grid container flexDirection="column" spacing={4}>
            <Grid item>
              <Typography variant="h6">{startSubjectA?.listValue}</Typography>
            </Grid>
            <Grid item>
              <Typography variant="h6">{startSubjectB?.listValue}</Typography>
            </Grid>
          </Grid>
        </TableCell>
        <TableCell>
          <Grid container flexDirection="column" spacing={4}>
            <Grid item container>
              <Typography variant="h6" whiteSpace="nowrap">
                {studiesGroupSubjectA?.listValue}
              </Typography>
            </Grid>
            <Grid item container>
              <Typography variant="h6" whiteSpace="nowrap">
                {studiesGroupSubjectB?.listValue}
              </Typography>
            </Grid>
          </Grid>
        </TableCell>
        <TableCell align="right">
          <Typography variant="h6">
            {schoolName} ({BSN})
          </Typography>
        </TableCell>
        <TableCell
          align="right"
          onClick={() =>
            router.push(`${frontendRoutes.candidate.data}/${candidateId}`)
          }
        >
          <IconSwitcher icon="redArrowRight" />
        </TableCell>
      </TableRow>
    </>
  )
}

export default CandidateTableRow
