import { Box, Chip, TableCell, TableRow, Typography } from '@mui/material'
import CustomButton from '../Buttons/CustomButton'

const CandidateTableRow = () => {
  return (
    <TableRow>
      <TableCell>
        <Typography variant="h5">Max Mustermann</Typography>
      </TableCell>

      <TableCell align="right" width="225px">
        <Box display="flex" gap="10px">
          <Typography variant="h6">Phases</Typography>
          <Chip
            label="1"
            sx={{
              background: '#E40422',
              border: '1px solid #000',
              padding: '0px',
              height: '24px',
              width: '24px',
            }}
          />
          <Chip
            label="2"
            sx={{
              border: '1px solid #000',
              padding: '0px',
              height: '24px',
              width: '24px',
              color: '#000',
              background: 'transparent',
            }}
          />

          <Chip
            label="3"
            sx={{
              border: '1px solid #000',
              padding: '0px',
              height: '24px',
              width: '24px',
              color: '#000',
              background: 'transparent',
            }}
          />

          <Chip
            label="4"
            sx={{
              border: '1px solid #000',
              padding: '0px',
              height: '24px',
              width: '24px',
              color: '#000',
              background: 'transparent',
            }}
          />
        </Box>
      </TableCell>

      <TableCell align="right" width="130px">
        <Typography variant="h6">School ABC</Typography>
      </TableCell>

      <TableCell align="right" width="190px">
        <Typography variant="h6">Elementary Education</Typography>
      </TableCell>

      <TableCell align="right" width="140px">
        <Typography variant="h6">Group 1/2025</Typography>
      </TableCell>

      <TableCell align="right" width="44px">
        <CustomButton
          label={false}
          icon={true}
          iconName="redArrowDown"
          iconWithBg={false}
          onClick={() => {}}
        />
      </TableCell>
    </TableRow>
  )
}

export default CandidateTableRow
