import moment from 'moment'

import { Task, TaskType } from '@prisma/client'
import { useRouter } from 'next/navigation'
import { frontendRoutes } from '@/utils/constants/frontend'
import {
  Box,
  Grid,
  Chip as MUIChip,
  TableCell,
  TableRow,
  Typography,
} from '@mui/material'
import { useContext } from 'react'
import { UserContext } from '@/contexts/userContext'
import { useScopedI18n } from '../../../locales/client'
import IconSwitcher from '../Icons'

const Chip: React.FC<{ type?: TaskType; done?: boolean }> = ({ type }) => {
  const tScoped = useScopedI18n('dashboard')
  if (type === TaskType.Document) {
    return (
      <MUIChip label={tScoped('Document')} sx={{ background: '#0443E4' }} />
    )
  } else if (type === TaskType.Event) {
    return <MUIChip label={tScoped('Event')} sx={{ background: '#009231' }} />
  } else if (type === TaskType.Message) {
    return <MUIChip label={tScoped('Message')} sx={{ background: '#DB7600' }} />
  } else if (type === TaskType.Data) {
    return <MUIChip label={tScoped('Data')} sx={{ background: '#999999' }} />
  } else {
    return (
      <MUIChip label={type ?? tScoped('Done')} sx={{ background: '#E40422' }} />
    )
  }
}

interface ITask extends Omit<Task, 'attachments'> {
  attachments: {
    url: string
    fileName: string
  }[]
  creator?: {
    firstName: string
    lastName: string | null
  }
  assignee?: {
    firstName: string
    lastName: string | null
  }
}

const TaskTableRow: React.FC<{ task: ITask }> = ({ task }) => {
  const {
    title,
    note,
    type,
    dueDate,
    done,
    taskId,
    creator,
    assignee,
    creatorId,
  } = task
  const tScoped = useScopedI18n('dashboard')
  const router = useRouter()
  const { user } = useContext(UserContext)

  const today = moment()
  const isPastDueAndNotDone =
    moment(dueDate).isBefore(today, 'day') && done === false

  function truncateString(str: string) {
    if (str.length <= 120) {
      return str
    } else {
      return str.substring(0, 120) + '...'
    }
  }

  return (
    <TableRow
      onClick={() => router.push(`${frontendRoutes.task.list}/${taskId}`)}
      sx={{ cursor: 'pointer' }}
    >
      <TableCell>
        <Typography variant="h5" sx={{ textTransform: 'capitalize' }}>
          {title}
        </Typography>
        <Typography
          variant="h6"
        >
          {truncateString(note)}
        </Typography>
      </TableCell>

      <TableCell>
        <Grid container flexDirection="column">
          <Grid item container alignItems="center">
            <Typography variant="h6">{tScoped('To')}:</Typography> 
            <Typography variant="h5">
              {assignee?.firstName} {assignee?.lastName ?? ''}
            </Typography>
          </Grid>
          <Grid item container alignItems="center">
            <Typography variant="h6">{tScoped('From')}:</Typography> 
            <Typography variant="h6">
              {creator?.firstName} {creator?.lastName ?? ''}
            </Typography>
          </Grid>
        </Grid>
      </TableCell>

      <TableCell align="right" width="100px">
        {done ? <Chip done={true} /> : ''}
      </TableCell>

      <TableCell align="right" width="145px">
        <Box display="flex" gap="10px" flexWrap="wrap">
          <Chip type={type} />
        </Box>
      </TableCell>

      <TableCell
        align="right"
        width="123px"
        sx={{
          whiteSpace: 'nowrap',
          color: isPastDueAndNotDone ? '#E40422' : '',
        }}
      >
        <Typography variant="h5">{tScoped('Due')}</Typography>
        <Typography variant="h5">{moment(dueDate).format('DD.MM.YY')}</Typography>
      </TableCell>

      <TableCell align="right">
        <IconSwitcher icon="redArrowRight" />
      </TableCell>
    </TableRow>
  )
}

export default TaskTableRow
