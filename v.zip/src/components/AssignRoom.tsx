import { Box, FormGroup, FormLabel, Grid, Typography } from '@mui/material'
import React, { useEffect, useState } from 'react'
import { useFormContext } from 'react-hook-form'
import { Rooms } from '@prisma/client'

import Button from '@/components/Buttons/CustomButton'
import { RHFAutocompleteField } from './DropDown'
import InputField from './InputField'
import CustomCheckbox from './Buttons/CustomCheckbox'
import CustomModal from './Modal'
import { IList } from '@/interface/common'
import { FIND_NUMBER_REGEX } from '@/utils/constants'
import { useScopedI18n } from '../../locales/client'

interface IAssignRoomProps {
  open: boolean
  handleClose: () => void
  locations: IList
  equipments: IList
  suitableRooms: Rooms[]
  readOnly?: boolean
  roomData?: Rooms[]
  maxAttendees?: number
  barrierFreeAccess?: boolean | null
  locationId?: string
  equipmentId?: string[] | number[]
  isEdit?: boolean
  suitableRoomId?: string
  clearSuitableRoomId?: () => void
  loading?: boolean
}

interface IEquipmentData {
  type: string
  value: boolean | number
}

const AssignRoom = ({
  open,
  handleClose,
  locations,
  equipments,
  suitableRooms,
  readOnly = false,
  roomData,
  maxAttendees,
  barrierFreeAccess,
  locationId,
  equipmentId,
  isEdit = false,
  suitableRoomId,
  loading,
  clearSuitableRoomId,
}: IAssignRoomProps) => {
  const tScoped = useScopedI18n('event')
  const {
    control,
    trigger,
    formState: { errors },
  } = useFormContext()
  const [selectableRooms, setSelectableRooms] = useState<string[] | undefined>(
    suitableRooms?.map((item: Rooms) => {
      return item.roomName
    }),
  )
  const [selectedEquipmentsData, setSelectedEquipmentsData] = useState<
    IEquipmentData[]
  >([
    {
      type: 'smartboard',
      value: false,
    },
    {
      type: 'beamer',
      value: false,
    },
    {
      type: 'flipchart',
      value: false,
    },
    {
      type: 'whiteboard',
      value: false,
    },
    {
      type: 'moderationskoffer',
      value: false,
    },
    {
      type: 'dokumentenkamera',
      value: false,
    },
    {
      type: 'pinnwand',
      value: false,
    },
    {
      type: 'tische',
      value: false,
    },
    {
      type: 'beleuchtungsanlage',
      value: false,
    },
    {
      type: 'rednerpult',
      value: false,
    },
    {
      type: 'mikrofon headset (1 Stück)',
      value: false,
    },
    {
      type: 'mikrofon headset (2 Stück)',
      value: false,
    },
    {
      type: 'mikrofon headset (3 Stück)',
      value: false,
    },
    {
      type: 'mikrofon headset (4 Stück)',
      value: false,
    },
    {
      type: 'mikrofon handsender (1 Stück)',
      value: false,
    },
    {
      type: 'mikrofon handsender (2 Stück)',
      value: false,
    },
    {
      type: 'mikrofon handsender (3 Stück)',
      value: false,
    },
    {
      type: 'mikrofon handsender (4 Stück)',
      value: false,
    },
  ])

  const suitableRoomsOptions = suitableRooms
    ?.filter((item: Rooms) => {
      return selectableRooms?.includes(item.roomName)
    })
    .map((item: Rooms) => {
      return {
        id: item.roomId,
        label: item.roomName,
      }
    })

  const fieldsToInclude = [
    'smartboard',
    'beamer',
    'flipchart',
    'whiteboard',
    'moderationskoffer',
    'dokumentenkamera',
    'pinnwand',
    'tische',
    'beleuchtungsanlage',
    'rednerpult',
  ]

  useEffect(() => {
    applyFilters()
  }, [selectedEquipmentsData, maxAttendees, barrierFreeAccess, locationId])

  useEffect(() => {
    if (suitableRoomId && !loading) {
      const isSelectedOptionNotAvailable = suitableRoomsOptions.filter(
        (option) => option.id === +suitableRoomId!,
      )
      if (!!isSelectedOptionNotAvailable.toString() && suitableRoomId) {  
        // clearSuitableRoomId && clearSuitableRoomId()
      }
    }
  }, [suitableRoomsOptions, loading, suitableRoomId])

  useEffect(() => {
    if (isEdit && equipmentId && equipmentId.length > 0) {
      const updatedSelectedEquipmentsData = equipments.map((equipment) => {
        const isSelected = (equipmentId as number[]).includes(equipment.listId)

        const existingEquipment = selectedEquipmentsData.find(
          (e) => e.type.toLowerCase() === equipment.listValue.toLowerCase(),
        )

        return {
          type: existingEquipment
            ? existingEquipment.type
            : equipment.listValue,
          value: isSelected,
        }
      })

      setSelectedEquipmentsData(updatedSelectedEquipmentsData)
    }
  }, [
    isEdit,
    JSON.stringify(equipmentId),
    JSON.stringify(equipments),
    JSON.stringify(selectedEquipmentsData),
  ])

  const applyFilters = () => {
    let filteredRooms = roomData

    if (equipmentId && equipmentId?.length > 0) {
      filteredRooms = roomData?.filter((room) => {
        return selectedEquipmentsData.reduce((includeRoom, equipment) => {
          if (
            equipment.type.toLowerCase().includes('headset') &&
            equipment.value
          ) {
            const val = equipment.type.match(FIND_NUMBER_REGEX)
            if (!(room.mikrofonHeadsetNumber >= (val ? +val[0] : 0))) {
              return false
            }
          } else if (
            equipment.type.toLowerCase().includes('handsender') &&
            equipment.value
          ) {
            const val = equipment.type.match(FIND_NUMBER_REGEX)
            if (!(room.mikrofonHandsenderNumber >= (val ? +val[0] : 0))) {
              return false
            }
          } else if (
            fieldsToInclude.includes(equipment.type.toLowerCase()) &&
            equipment.value &&
            room[equipment.type as keyof Rooms] !== equipment.value
          ) {
            return false
          }
          return includeRoom
        }, true)
      })
    }

    if (maxAttendees) {
      filteredRooms = filteredRooms?.filter(
        (room) => room.maxAttendees >= maxAttendees,
      )
    }

    if (barrierFreeAccess !== null) {
      filteredRooms = filteredRooms?.filter(
        (room) => room.barrierFreeAccess === barrierFreeAccess,
      )
    }

    if (locationId) {
      const locationNames = locations
        .filter((item) => item.listId === +locationId)
        .map((item) => item.listValue)
      filteredRooms = filteredRooms?.filter((room) =>
        locationNames.includes(room.locationName),
      )
    }

    setSelectableRooms(filteredRooms?.map((item) => item.roomName))
  }

  const onSave = async () => {
    const isValid = await trigger([
      'locationId',
      'equipmentId',
      'suitableRoomId',
    ])
    if (isValid) {
      handleClose()
    } else {
      return
    }
  }

  return (
    <>
      <CustomModal open={open} onClose={handleClose}>
        <Typography
          variant="h6"
          component="h2"
          mb={10}
          sx={{ fontWeight: 700, fontSize: '28px', color: '#E40422' }}
        >
          {tScoped('Assign Room')}
        </Typography>

        <Box>
          <RHFAutocompleteField
            required={!readOnly}
            control={control}
            options={locations?.map((item) => {
              return {
                id: item.listId,
                label: item.listValue,
              }
            })}
            name="locationId"
            label={tScoped('Location')}
            readOnly={readOnly}
          />
          <InputField
            control={control}
            name="maxParticipants"
            label={tScoped('Max Attendes (Not Editable)')}
            disabled
            fullWidth
            readOnly={readOnly}
          />
          <CustomCheckbox
            label={tScoped('Barrier-free access needed')}
            control={control}
            name="barrierFreeAccess"
            readOnly={readOnly}
          />

          <Grid container mt={10} spacing={10}>
            <Grid item xs={12}>
              <FormLabel component="legend">{tScoped('Equipment')}</FormLabel>
              <FormGroup row>
                {equipments?.map((item, index) => (
                  <Grid key={index} item xs={8} sm={8} md={5} lg={4}>
                    <CustomCheckbox
                      readOnly={readOnly}
                      control={control}
                      label={item.listValue}
                      value={item.listId}
                      name="equipmentId"
                      isMulti
                      onChange={(e, a) => {
                        console.log(e, a, item.listValue)
                        const type = item.listValue.toLowerCase()

                        setSelectedEquipmentsData((prev) => {
                          const existingItemIndex = prev.findIndex(
                            (p) => p.type.toLowerCase() === type,
                          )

                          if (existingItemIndex >= 0) {
                            return prev.map((item, index) =>
                              index === existingItemIndex
                                ? { ...item, value: e }
                                : item,
                            )
                          } else {
                            return [
                              ...prev,
                              {
                                type: type,
                                value: e,
                              },
                            ]
                          }
                        })
                      }}
                    />
                  </Grid>
                ))}
              </FormGroup>
              {errors.equipmentId && (
                <Box sx={{ color: 'red', fontSize: '12px', my: 3 }}>
                  {String(errors.equipmentId.message)}
                </Box>
              )}
            </Grid>
            <Grid item xs={12}>
              <RHFAutocompleteField
                control={control}
                options={suitableRoomsOptions}
                name="suitableRoomId"
                required={!readOnly}
                label={tScoped('Suitable Rooms')}
                readOnly={readOnly}
              />
            </Grid>
          </Grid>

          <Grid
            container
            justifyContent="flex-end"
            alignItems="center"
            marginY={10}
          >
            <Button
              label
              icon
              labelText="Save"
              iconName="save"
              onClick={onSave}
            />
          </Grid>
        </Box>
      </CustomModal>
    </>
  )
}

export default AssignRoom
