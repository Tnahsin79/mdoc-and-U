import { Dispatch, SetStateAction, useEffect, useState } from 'react'
import Snackbar from '@mui/material/Snackbar'
import IconButton from '@mui/material/IconButton'
import CloseIcon from '@mui/icons-material/Close'
import { Alert, Typography } from '@mui/material'
import IconSwitcher from './Icons'

interface ToastInterface {
  message: string
  severity?: 'success' | 'info' | 'warning' | 'error'
  setServerError?: Dispatch<SetStateAction<string>>
}

const Toast: React.FC<ToastInterface> = ({
  message,
  severity = 'success',
  setServerError,
}) => {
  const [open, setOpen] = useState(!!message)

  useEffect(() => {
    if (!open && setServerError) {
      setServerError('')
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open])

  const IconColor = {
    success: '#00CC99',
    info: '#5458F7',
    warning: '#F2C94D',
    error: '#E40422',
  }

  const ToastIcon = {
    success: <IconSwitcher icon="successToast" />,
    info: <IconSwitcher icon="infoToast" />,
    warning: <IconSwitcher icon="warningToast" />,
    error: <IconSwitcher icon="errorToast" />,
  }

  const action = (
    <IconButton
      sx={{
        display: 'flex',
        background: 'transparent',
        color: `${IconColor[severity]}`,
        padding: '0px',
        width: '24px',
        height: '24px',
        ':hover': { background: 'transparent' },
      }}
      size="small"
      aria-label="close"
      onClick={() => setOpen(false)}
    >
      <CloseIcon
        fontSize="small"
        sx={{ width: '100%', height: '100%', color: '#000' }}
      />
    </IconButton>
  )

  return (
    <Snackbar
      open={open}
      anchorOrigin={{ horizontal: 'left', vertical: 'bottom' }}
      autoHideDuration={8000}
      onClose={() => setOpen(false)}
    >
      <Alert
        onClose={() => setOpen(false)}
        severity={severity}
        icon={ToastIcon[severity]}
        sx={{
          width: '100%',
          height: '100%',
          alignItems: 'center',
          borderLeft: `6px solid ${IconColor[severity]}`,
        }}
        action={action}
      >
        <Typography variant="h3" sx={{ height: '28px' }}>
          {severity.charAt(0).toUpperCase() + severity.slice(1)}
        </Typography>
        <Typography
          sx={{ fontSize: '16px', fontWeight: 400, color: '#000000' }}
        >
          {message}
        </Typography>
      </Alert>
    </Snackbar>
  )
}

export default Toast
