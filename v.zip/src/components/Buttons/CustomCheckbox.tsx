import { Controller } from 'react-hook-form'
import { Box, Checkbox, FormControlLabel } from '@mui/material'

import IconSwitcher from '../Icons'
import { validationMessages } from '@/validators/messages'

interface CheckboxProps {
  label?: string
  control?: any
  name?: string
  defaultValue?: boolean
  value?: string | number | boolean
  required?: boolean
  isMulti?: boolean
  readOnly?: boolean
  style?: React.CSSProperties
  onChange?: (checked: boolean, name: string) => void
}

const CustomCheckbox = ({
  label,
  control,
  name,
  defaultValue = false,
  value = false,
  required,
  isMulti,
  readOnly = false,
  style,
  onChange,
}: CheckboxProps) => {
  const CheckboxContent = (
    <Checkbox
      icon={<IconSwitcher icon="checkboxUnchecked" />}
      checkedIcon={<IconSwitcher icon="checkboxChecked" />}
      disableRipple
    />
  )

  if (control && name) {
    return (
      <Controller
        name={name}
        control={control}
        rules={{
          required: required ? validationMessages.required : false,
        }}
        defaultValue={defaultValue}
        render={({ field, fieldState: { error } }) => {
          let isChecked: boolean

          if (Array.isArray(field.value)) {
            isChecked = field.value.includes(value)
          } else {
            isChecked = field.value
          }
          return (
            <>
              <FormControlLabel
                style={style}
                control={
                  <Checkbox
                    inputRef={field.ref}
                    readOnly
                    disabled={readOnly}
                    checked={!!isChecked}
                    inputProps={{ readOnly }}
                    onChange={(e) => {
                      onChange && onChange(e.target.checked, name)
                      if (Array.isArray(field.value)) {
                        const newArr = isChecked
                          ? field.value.filter((item) => item !== value)
                          : [...field.value, value]
                        field.onChange(newArr)
                      } else {
                        field.onChange(e.target.checked)
                      }
                    }}
                    icon={<IconSwitcher icon="checkboxUnchecked" />}
                    checkedIcon={<IconSwitcher icon="checkboxChecked" />}
                  />
                }
                label={label}
              />
              {error && !isMulti && (
                <Box style={{ color: 'red', fontSize: '12px' }}>
                  {error.message}
                </Box>
              )}
            </>
          )
        }}
      />
    )
  }

  return label ? (
    <FormControlLabel control={CheckboxContent} label={label} />
  ) : (
    CheckboxContent
  )
}

export default CustomCheckbox
