'use client'

import IconSwitcher from '../Icons'
import IconButton from '@mui/material/IconButton'
import {
  Button as MUIButton,
  ButtonProps,
  CircularProgress,
  Box,
} from '@mui/material'

import { Icon } from '@/components/Icons/iconsList'
import { ReactNode } from 'react'

interface buttonProps extends ButtonProps {
  label?: boolean
  labelText?: string
  icon?: boolean
  iconName?: Icon
  iconWithBg?: boolean
  loading?: boolean
  disabled?: boolean
  children?: ReactNode
}

const CustomButton: React.FC<buttonProps> = (props) => {
  const {
    variant = 'outlined',
    label,
    icon,
    labelText,
    onClick,
    iconName = 'arrowRight',
    iconWithBg = true,
    sx,
    disabled,
    loading,
    children,
    ...rest
  } = props
  if (!label && icon) {
    return (
      <IconButton
        {...rest}
        disabled={disabled || loading}
        onClick={onClick}
        sx={{
          background: iconWithBg ? 'primary.main' : 'transparent',
        }}
      >
        <IconSwitcher icon={iconName} />
      </IconButton>
    )
  }
  return (
    <>
      <MUIButton
        {...rest}
        sx={{
          ...sx,
          borderColor: icon ? 'secondary.main' : 'primary.main',
          paddingRight: icon ? 'calc(1.5rem + 44px)' : '1.5rem',
          '&:hover': { borderColor: icon ? 'secondary.main' : 'primary.main' },
        }}
        disableRipple
        variant={variant}
        endIcon={icon ? <IconSwitcher icon={iconName} /> : null}
        onClick={onClick}
        disabled={disabled || loading}
      >
        <Box pr={2}>
          {loading ? <CircularProgress color="error" size={14} /> : labelText}
        </Box>
        <Box>{children}</Box>
      </MUIButton>
    </>
  )
}

export default CustomButton
