import { Box, FormControlLabel, InputLabel, Radio, styled } from '@mui/material'
import IconSwitcher from '../Icons'

interface radioButtonProps {
  label?: string | null
}

const StyledRadio = styled(Radio)({
  width: '23px',
  height: '23px',
  padding: 0,
  marginLeft: '0',
  marginRight: '0',
})

const StyledBox = styled(Box)({
  display: 'flex',
  gap: '10px',
  width: '71px',
  height: '23px',
  '.MuiFormControlLabel-root': {
    marginLeft: '0',
    marginRight: '0',
  },
})

const StyledFormControlLabel = styled(FormControlLabel)({})

const StyledInputLabel = styled(InputLabel)({
  width: '38px',
  height: '22px',
  fontSize: '16px',
  fontWeight: 400,
  color: '#000000',
  textOverflow: 'unset',
  letterSpacing: 'unset',
})

const RadioButton = ({ label = null }: radioButtonProps) => {
  return (
    <>
      {!label && (
        <StyledBox>
          <FormControlLabel
            value={label}
            control={
              <StyledRadio
                icon={<IconSwitcher icon="radioUnchecked" />}
                checkedIcon={<IconSwitcher icon="radioChecked" />}
                disableRipple
              />
            }
            label={label}
          />
        </StyledBox>
      )}
      {label && (
        <StyledBox>
          <StyledFormControlLabel
            control={
              <StyledRadio
                icon={<IconSwitcher icon="radioUnchecked" />}
                checkedIcon={<IconSwitcher icon="radioChecked" />}
                disableRipple
              />
            }
            label=""
          />
          <StyledInputLabel>{label}</StyledInputLabel>
        </StyledBox>
      )}
    </>
  )
}

export default RadioButton
