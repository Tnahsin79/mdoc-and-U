'use client'

import { Button as MUIButton } from '@mui/material'
import styled from '@emotion/styled'

import SearchIcon from '@mui/icons-material/Search'

const StyledSearchButton = styled(MUIButton)`
  width: 2.625rem;
  height: 2.625rem;
  background-color: #8e8e8e;
  color: #ffffff;
  border-radius: 0;
  min-width: unset;

  &:hover {
    width: 2.625rem;
    height: 2.625rem;
    background-color: #8e8e8e;
    color: #ffffff;
    border-radius: 0;
  }
`

const CustomSearchButton: React.FC = () => {
  return (
    <StyledSearchButton>
      <SearchIcon fontSize="large" />
    </StyledSearchButton>
  )
}

export default CustomSearchButton
