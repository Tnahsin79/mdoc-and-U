import { FormControlLabel, Switch, SwitchProps } from '@mui/material'
import { Control, Controller, FieldValues, Path } from 'react-hook-form'

interface SwitchButtonProps<T extends FieldValues>
  extends Omit<SwitchProps, 'name'> {
  label?: string | null
  control?: Control<T>
  name: Path<T>
  handleChange?: (e: React.ChangeEvent<HTMLInputElement>) => void
}

const SwitchButton = <T extends FieldValues>({
  label = null,
  control,
  name,
  handleChange,
  ...rest
}: SwitchButtonProps<T>) => {
  if (!control) {
    return (
      <FormControlLabel
        control={
          <Switch
            disableRipple
            onChange={(e) => {
              handleChange && handleChange(e)
            }}
            {...rest}
          />
        }
        label={label}
      />
    )
  }

  return (
    <Controller
      name={name}
      control={control}
      render={({ field: { onChange, value, ref } }) => (
        <FormControlLabel
          control={
            <Switch
              inputRef={ref}
              disableRipple
              checked={value || false}
              onChange={(e) => {
                handleChange && handleChange(e)
                onChange(e.target.checked)
              }}
              {...rest}
            />
          }
          label={label}
        />
      )}
    />
  )
}

export default SwitchButton
