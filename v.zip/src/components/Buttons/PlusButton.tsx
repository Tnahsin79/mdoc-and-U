'use client'
import { Button as MUIButton } from '@mui/material'
import styled from '@emotion/styled'
import AddIcon from '@mui/icons-material/Add'

const StyledPlusButton = styled(MUIButton)`
  width: 25px;
  height: 25px;
  border-radius: 50%;
  background-color: #e40422;
  min-width: unset;

  &: hover {
    width: 25px;
    height: 25px;
    border-radius: 50%;
    background-color: #e40422;
    min-width: unset;
  }
`

const StyledAddIcon = styled(AddIcon)`
  color: #ffffff;
`

const CustomPlusButton = () => {
  return (
    <StyledPlusButton>
      <StyledAddIcon />
    </StyledPlusButton>
  )
}

export default CustomPlusButton
