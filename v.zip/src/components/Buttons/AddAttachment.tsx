import { styled } from '@mui/system'
import IconSwitcher from '../Icons'
import CustomButton from './CustomButton'

import { Icon } from '../Icons/iconsList'
import { Grid, Typography } from '@mui/material'
import { CSSProperties, ChangeEvent, Dispatch, SetStateAction } from 'react'
import { useScopedI18n } from '../../../locales/client'
import axiosInstance from '@/services/axiosInstance'

const InputFile = styled('input')({
  height: '100%',
  position: 'absolute',
  top: 0,
  bottom: 0,
  left: 0,
  right: 0,
  whiteSpace: 'nowrap',
  width: '100%',
  opacity: 0,
  zIndex: 3,
})

const FileName = styled(Typography)({
  fontWeight: 800,
  maxWidth: '150px',
  overflow: 'hidden',
  textOverflow: 'ellipsis',
  whiteSpace: 'nowrap',
})

const AttachmentGrid = styled(Grid)({
  flex: 1,
  gap: '10px',
  display: 'flex',
})

const MAX_FILE_SIZE = 25 * 1000000

interface IAddAttachment {
  sx?: CSSProperties
  fileUploading: boolean
  setCurrentFiles: Dispatch<SetStateAction<FileList | null>>
  currentFiles: FileList | null
  iconName?: Icon
  labelText?: string
  multiple?: boolean
  uploadedAttachments?: {
    url: string
    fileName: string
  }[]
  setUploadedAttachments?: Dispatch<
    SetStateAction<{
      url: string
      fileName: string
    } | null>
  >
}

const AddAttachment: React.FC<IAddAttachment> = ({
  sx,
  fileUploading,
  setCurrentFiles,
  currentFiles,
  iconName = 'attach',
  labelText,
  multiple = false,
  uploadedAttachments,
  setUploadedAttachments,
}) => {
  const tScoped = useScopedI18n('dashboard')
  const fileChangeHandler = async (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files
    setCurrentFiles(file)
  }

  const removeFile = (fileToRemove: File) => {
    const filteredFiles = Array.from(currentFiles || []).filter(
      (file) => file !== fileToRemove,
    )
    setCurrentFiles(
      filteredFiles.length > 0 ? (filteredFiles as unknown as FileList) : null,
    )
  }

  const openFileInNewTab = async (file: string) => {
    const responseFromFileServer = await axiosInstance.post(
      '/api/attachment/get-attachment-link',
      { fileName: file },
    )

    let fileURLFromFileServer = ''
    if (responseFromFileServer.status === 200) {
      fileURLFromFileServer = responseFromFileServer.data.url
    }

    window.open(fileURLFromFileServer, '_blank')
  }

  const openNotYetUploadedFile = (file: File) => {
    const fileURL = URL.createObjectURL(file)
    window.open(fileURL, '_blank')
  }

  return (
    <Grid
      display="flex"
      justifyContent="space-between"
      gap={10}
      alignItems="center"
      sx={{ ...sx }}
    >
      <CustomButton
        label={true}
        labelText={labelText || tScoped('Add Attachment')}
        icon={true}
        iconName={iconName}
        sx={{ position: 'relative' }}
        loading={fileUploading}
      >
        <InputFile
          type="file"
          accept="image/*, application/pdf"
          size={MAX_FILE_SIZE}
          multiple={multiple}
          onChange={fileChangeHandler}
          sx={{ cursor: 'pointer' }}
        />
      </CustomButton>

      {currentFiles &&
        Array.from(currentFiles).map((file, index) => (
          <AttachmentGrid key={index}>
            <FileName onClick={() => openNotYetUploadedFile(file)} sx={{cursor: 'pointer', '&:hover': {color: '#E40422'}}}>
              {file.name}
            </FileName>
            <div onClick={() => removeFile(file)} style={{ cursor: 'pointer' }}>
              <IconSwitcher icon="close" />
            </div>
          </AttachmentGrid>
        ))}

      {uploadedAttachments &&
        uploadedAttachments.map((attachment, index) => (
          <AttachmentGrid key={index}>
            <FileName onClick={() => openFileInNewTab(attachment.fileName)} sx={{cursor: 'pointer', '&:hover': {color: '#E40422'}}}>
              {attachment.fileName}
            </FileName>
            {setUploadedAttachments ? (
              <div
                onClick={() => {
                  setUploadedAttachments(null)
                }}
                style={{ cursor: 'pointer' }}
              >
                <IconSwitcher icon="close" />
              </div>
            ) : null}
          </AttachmentGrid>
        ))}
    </Grid>
  )
}

export default AddAttachment
