'use client'
import { Button as MUIButton } from '@mui/material'
import styled from '@emotion/styled'
import IconSwitcher from '../Icons'

const StyledFlagButton = styled(MUIButton)`
  width: 2.625rem;
  height: 2.625rem;
  background-color: #c5c5c5;
  border-radius: 0;
  min-width: unset;
  padding: 9px;
  &:hover {
    width: 2.625rem;
    height: 2.625rem;
    background-color: #c5c5c5;
    border-radius: 0;
  }
`

const CustomFlagButton = () => {
  return (
    <StyledFlagButton>
      <IconSwitcher icon="Icon7" />
    </StyledFlagButton>
  )
}

export default CustomFlagButton
