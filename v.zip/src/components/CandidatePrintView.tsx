import React from 'react'

const CandidatePrintView = ({ candidates }: any) => {
  return (
    <div style={{ padding: '20px' }}>
      <ul style={{ listStyleType: 'none', padding: 0 }}>
        {candidates.map((person: any) => (
          <li
            key={person.personId}
            style={{
              margin: '10px 0',
              padding: '10px',
              border: '1px solid #ccc',
              borderRadius: '4px',
            }}
          >
            <div>
              <strong>ID:</strong> {person.personId}
            </div>
            <div>
              <strong>Name:</strong>
              {`${person.firstName} ${person.lastName || ''}`.trim()}
            </div>
            <div>
              <strong>Email:</strong> {person.email}
            </div>
            <div>
              <strong>Role:</strong> {person.role}
            </div>
          </li>
        ))}
      </ul>
    </div>
  )
}

export default CandidatePrintView
