import React from 'react'
import {
  Box,
  Grid,
  List,
  ListItem,
  ListItemText,
  Typography,
} from '@mui/material'

import CustomButton from './Buttons/CustomButton'
import CustomModal from './Modal'
import { useScopedI18n } from '../../locales/client'

interface IMassImportModal {
  importFailedModal: boolean
  handleImportFailed: () => void
  importFailedData: {
    error: string
    data: string[]
  }
}

const MassImportModal = ({
  importFailedModal,
  handleImportFailed,
  importFailedData,
}: IMassImportModal) => {
  const tScoped = useScopedI18n('massImportCandidate')
  return (
    <CustomModal open={importFailedModal} onClose={handleImportFailed}>
      <Typography
        variant="h6"
        component="h2"
        mb={10}
        sx={{ fontWeight: 700, fontSize: '28px', color: '#E40422' }}
      >
        {tScoped('Import failed!')}
      </Typography>

      <Box>
        <Typography variant="h3">
          {importFailedData?.error?.startsWith('Duplicate')
            ? `${tScoped(
                'The following email addresses are getting duplicated in csv file',
              )} :`
            : `${tScoped(
                'The following email addresses are already registered to other users in the database',
              )}:`}
        </Typography>
        <List
          sx={{
            width: '100%',
            bgcolor: 'background.paper',
            '.MuiListItemText-root': {
              padding: 2,
              borderBottom: '1px solid black',
            },
          }}
        >
          {importFailedData?.data?.map((item, index: number) => {
            if (index < 5) {
              return (
                <ListItem key={index}>
                  <ListItemText primary={`${index + 1}  ${item}`} />
                </ListItem>
              )
            }
          })}
        </List>
        <Grid
          container
          justifyContent="center"
          alignItems="center"
          marginY={10}
        >
          <CustomButton
            label
            labelText={tScoped('Close')}
            onClick={handleImportFailed}
            sx={{
              background: '#E40422',
              color: '#fff',
            }}
          />
        </Grid>
      </Box>
    </CustomModal>
  )
}

export default MassImportModal
