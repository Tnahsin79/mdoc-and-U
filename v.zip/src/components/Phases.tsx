import { phasesOptions } from '@/utils/constants/common'
import { Box, Chip, Grid } from '@mui/material'

const Phases = ({ phase }: { phase: number }) => {
  const phaseRequired = phasesOptions.find(
    (phaseOption) => phaseOption.id === phase,
  )

  return (
    <Box  width='100px'>
      <Grid container spacing={2} justifyContent='space-evenly'>
        <Grid item xs={3}>
        <Chip
          label="1"
          sx={{
            background: phaseRequired?.kickOff ? '#E40422' : 'transparent',
            border: '1px solid #000',
            padding: '0px',
            height: '1.5rem',
            width: '1.5rem',
            color: phaseRequired?.kickOff ? '#FFFFFF' : '#000',
          }}
        />
        </Grid>
        <Grid item xs={3}>
        <Chip
          label="2"
          sx={{
            background: phaseRequired?.firstStep ? '#E40422' : 'transparent',
            border: '1px solid #000',
            padding: '0px',
            height: '1.5rem',
            width: '1.5rem',
            color: phaseRequired?.firstStep ? '#FFFFFF' : '#000',
          }}
        />
        </Grid>
        <Grid item xs={3}>
        <Chip
          label="3"
          sx={{
            background: phaseRequired?.setUp ? '#E40422' : 'transparent',
            border: '1px solid #000',
            padding: '0px',
            height: '1.5rem',
            width: '1.5rem',
            color: phaseRequired?.setUp ? '#FFFFFF' : '#000',
          }}
        />
        </Grid>
        <Grid item xs={3}>
        <Chip
          label="4"
          sx={{
            background: phaseRequired?.studies ? '#E40422' : 'transparent',
            border: '1px solid #000',
            padding: '0px',
            height: '1.5rem',
            width: '1.5rem',
            color: phaseRequired?.studies ? '#FFFFFF' : '#000',
          }}
        />
        </Grid>
      </Grid>
    </Box>
  )
}

export default Phases
