import styled from '@emotion/styled'
import IconSwitcher from './Icons'

const StyledDiv = styled('div')({
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  backgroundColor: '#E40422',
  height: '100%',
  width: '44px',
  border: 'none',
})

const StyledIconSwitcher = styled(IconSwitcher)({})

const ArrowDown_Red = () => {
  return (
    <StyledDiv>
      <StyledIconSwitcher icon="arrowDown" />
    </StyledDiv>
  )
}

export default ArrowDown_Red
