import { useEffect, useState } from 'react'
import {
  Autocomplete,
  Chip,
  InputLabel,
  TextField,
  Typography,
} from '@mui/material'
import styled from '@emotion/styled'
import { Controller, Control, Path, FieldValues } from 'react-hook-form'
import { createFilterOptions } from '@mui/material/Autocomplete'

import IconSwitcher from './Icons'
import ArrowDown_Red from './ArrowDown(Red)'
import { OptionInterface } from '@/interface/common'
import { validationMessages } from '@/validators/messages'

export interface dropDownProps {
  label: string
  options: OptionInterface[]
  selectedOption?: null
  multiple?: boolean
}

const AutocompleteField = styled(Autocomplete)({
  '& .MuiInputBase-root': {
    minHeight: '44px',
    height: 'unset',
  },
  '& .MuiAutocomplete-endAdornment': {
    height: '44px',
    width: '44px',
    position: 'absolute',
    top: '0',
    right: '0 !important',
  },
  '& .MuiIconButton-root': {
    height: '100%',
    width: '100%',
    padding: '0 !important',
    border: 'none',
  },
  '&.autocomplete-error .MuiOutlinedInput-root .MuiOutlinedInput-notchedOutline':
    {
      borderColor: 'red !important',
    },

  '&.autocomplete-error .MuiOutlinedInput-root:hover .MuiOutlinedInput-notchedOutline':
    {
      borderColor: 'red !important',
    },

  '&.autocomplete-error .MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-notchedOutline':
    {
      borderColor: 'red !important',
    },
})

const DropDown = ({ label, options }: dropDownProps) => {
  return (
    <>
      <InputLabel>{label}</InputLabel>
      <AutocompleteField
        disablePortal
        options={options}
        renderOption={(props, option) => {
          const { label, value } = option as { label: string; value: number }
          return (
            <li key={value} {...props}>
              {label}
            </li>
          )
        }}
        renderInput={(params) => (
          <TextField {...params} label="" variant="outlined" />
        )}
        popupIcon={<ArrowDown_Red />}
        disableClearable
      />
    </>
  )
}

interface RHFAutocompleteFieldProps<
  O extends OptionInterface,
  TField extends FieldValues,
> {
  control: Control<TField>
  name: Path<TField>
  options: O[]
  placeholder?: string
  required?: boolean
  label: string
  defaultValue?: string | number
  readOnly?: boolean
  direction?: 'vertical' | 'horizontal'
  multiple?: boolean
  onSelect?: (value: OptionInterface[]) => Promise<void>
  groupBy?: ((option: unknown) => string) | undefined
  creatable?: boolean
  dynamicOptionId?: boolean
  isEdit?: boolean
}

export const RHFAutocompleteField = <
  O extends OptionInterface,
  TField extends FieldValues,
>(
  props: RHFAutocompleteFieldProps<O, TField>,
) => {
  const {
    control,
    options = [],
    name,
    required,
    label,
    defaultValue,
    readOnly = false,
    direction,
    multiple,
    onSelect,
    groupBy = undefined,
    creatable = false,
    dynamicOptionId = false,
    isEdit,
  } = props
  const filter = createFilterOptions()
  const [creatableValue, setCreatableValue] = useState<string | number | null>(
    null,
  )

  useEffect(() => {
    if (isEdit && defaultValue) {
      setCreatableValue(defaultValue)
    }
  }, [])

  return (
    <Controller
      name={name}
      control={control}
      rules={{
        required: required ? validationMessages.required : false,
      }}
      render={({ field, fieldState: { error } }) => {
        const { onChange, value = defaultValue, ref } = field

        return (
          <div
            style={
              direction === 'horizontal'
                ? {
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                  }
                : {}
            }
          >
            <InputLabel>{label}</InputLabel>

            {multiple ? (
              <AutocompleteField
                ListboxProps={{
                  style: { maxHeight: 250, overflow: 'auto' },
                }}
                componentsProps={{
                  popper: {
                    modifiers: [
                      {
                        name: 'flip',
                        enabled: false,
                      },
                    ],
                  },
                }}
                disabled={readOnly}
                groupBy={groupBy}
                style={
                  direction === 'horizontal'
                    ? {
                        width: 'calc(50% - 10px)',
                      }
                    : {}
                }
                multiple
                options={options}
                getOptionLabel={(option) => {
                  if (option) {
                    const { label } = option as OptionInterface
                    if (
                      typeof label === 'string' ||
                      typeof label === 'number'
                    ) {
                      return `${label}`
                    } else return `${label.firstName} ${label.lastName ?? ''}`
                  } else return ''
                }}
                defaultValue={undefined}
                renderInput={(params) => (
                  <TextField
                    inputRef={ref}
                    {...params}
                    variant="outlined"
                    name={name}
                    label=""
                    error={Boolean(error)}
                    helperText={error ? error.message : ''}
                  />
                )}
                renderOption={(props, option) => {
                  const { label, id } = option as OptionInterface
                  if (typeof label === 'string') {
                    return (
                      <li {...props} key={id}>
                        {label}
                      </li>
                    )
                  } else {
                    return (
                      <li
                        {...props}
                        key={id}
                        style={{
                          display: 'flex',
                          justifyContent: 'space-between',
                        }}
                      >
                        <Typography
                          sx={{
                            fontSize: '12px',
                            fontWeight: 400,
                            color: '#000000',
                            display: 'flex',
                            justifyContent: 'space-between',
                          }}
                        >
                          {label.firstName} {label.lastName ?? ''} 
                          {label.email && (
                            <Typography
                              sx={{
                                fontWeight: 400,
                                fontSize: '12px',
                                color: '#999999',
                              }}
                            >
                              ({label.email})
                            </Typography>
                          )}
                        </Typography>

                        <Typography variant="subtitle2">
                          {label?.role}
                        </Typography>
                      </li>
                    )
                  }
                }}
                renderTags={(value, getTagProps) =>
                  value.map((option, index) => (
                    <Chip
                      {...getTagProps({ index })}
                      key={index}
                      label={(() => {
                        const label = (option as OptionInterface).label
                        if (typeof label === 'string') {
                          return label
                        } else {
                          return `${label.firstName} ${label.lastName ?? ''}`
                        }
                      })()}
                    />
                  ))
                }
                popupIcon={<ArrowDown_Red />}
                disableClearable
                value={
                  Array.isArray(value)
                    ? options?.filter((option) => value.includes(option.id)) ??
                      []
                    : []
                }
                onChange={(event, newValue) => {
                  if (Array.isArray(newValue)) {
                    onSelect && onSelect(newValue.map((item) => item.id))
                    onChange(
                      newValue.map((item) => {
                        return item.id
                      }),
                    )
                  }
                }}
                className={error ? 'autocomplete-error' : ''}
              />
            ) : (
              <AutocompleteField
                filterOptions={(options, params) => {
                  const filtered = filter(options, params)
                  if (!creatable) return filtered
                  else {
                    const { inputValue } = params
                    const isExisting = options.some(
                      (option: any) => inputValue === option.label,
                    )
                    if (inputValue !== '' && !isExisting && creatable) {
                      filtered.push({
                        inputValue,
                        title: `Add "${inputValue}"`,
                      })
                    }

                    return filtered
                  }
                }}
                selectOnFocus
                clearOnBlur
                handleHomeEndKeys
                style={
                  direction === 'horizontal'
                    ? {
                        width: 'calc(50% - 10px)',
                      }
                    : {}
                }
                defaultValue={undefined}
                disabled={readOnly}
                className={error ? 'autocomplete-error' : ''}
                disablePortal
                options={options}
                renderOption={(props, option) => {
                  const { label, id } = option as OptionInterface
                  if ((option as any).inputValue && creatable) {
                    return (
                      <li {...props} key={id}>
                        {(option as any).title}
                      </li>
                    )
                  }
                  if (typeof label === 'string') {
                    return (
                      <li {...props} key={id}>
                        {label}
                      </li>
                    )
                  } else {
                    return (
                      <li
                        {...props}
                        key={id}
                        style={{
                          display: 'flex',
                          justifyContent: 'space-between',
                        }}
                      >
                        <Typography
                          sx={{
                            fontSize: '12px',
                            fontWeight: 400,
                            color: '#000000',
                            display: 'flex',
                            justifyContent: 'space-between',
                          }}
                        >
                          {label?.firstName} {label?.lastName ?? ''} 
                          <Typography
                            sx={{
                              fontWeight: 400,
                              fontSize: '12px',
                              color: '#999999',
                            }}
                          >
                            ({label?.email})
                          </Typography>
                        </Typography>

                        <Typography variant="subtitle2">
                          {label?.role}
                        </Typography>
                      </li>
                    )
                  }
                }}
                getOptionLabel={(option: any) => {
                  if (option?.inputValue && creatable) {
                    return option.inputValue
                  }
                  if (creatable && typeof option === 'string') {
                    return option
                  }
                  if (dynamicOptionId) {
                    return `${option.label}`
                  }
                  if (option) {
                    const { label } = option as OptionInterface
                    if (
                      typeof label === 'string' ||
                      typeof label === 'number'
                    ) {
                      return `${label}`
                    } else return `${label?.firstName} ${label?.lastName ?? ''}`
                  } else return ''
                }}
                value={
                  creatable
                    ? creatableValue
                    : options?.find((option) => {
                        return value === option.id
                      }) ?? null
                }
                onChange={(event, newValue: any) => {
                  if (newValue && newValue.inputValue && creatable) {
                    setCreatableValue(newValue.inputValue)
                    onChange(newValue.inputValue)
                  } else if (newValue) {
                    setCreatableValue(newValue.label)
                    onChange(newValue.id)
                  } else {
                    onChange()
                  }
                }}
                renderInput={(params) => (
                  <TextField
                    inputRef={ref}
                    name={name}
                    {...params}
                    label=""
                    error={Boolean(error)}
                    helperText={error ? error.message : ''}
                  />
                )}
                popupIcon={<ArrowDown_Red />}
                onInputChange={(event, newInputValue, reason) => {
                  if (reason === 'clear' && creatable) {
                    setCreatableValue(null)
                    onChange(null)
                  }
                }}
                clearIcon={<IconSwitcher icon="close" />}
              />
            )}
          </div>
        )
      }}
    />
  )
}

export default DropDown
