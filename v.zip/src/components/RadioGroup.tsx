import React from 'react'
import { Controller, UseFormReturn } from 'react-hook-form'
import {
  RadioGroup,
  FormControlLabel,
  Radio,
  RadioGroupProps,
  FormControl,
  FormLabel,
  FormHelperText,
} from '@mui/material'
import { validationMessages } from '@/validators/messages'

interface Option {
  label: string
  value: string
}

interface HookFormRadioGroupProps extends RadioGroupProps {
  name: string
  control: UseFormReturn<any>['control']
  options: Option[]
  label: string
  required?: boolean
  disabled?: boolean
  direction?: 'vertical' | 'horizontal'
  readOnly?: boolean
}

const CustomRadioGroup: React.FC<HookFormRadioGroupProps> = ({
  name,
  control,
  options,
  label,
  required,
  disabled,
  direction = 'vertical',
  readOnly = false,
  ...radioGroupProps
}) => {
  return (
    <Controller
      name={name}
      control={control}
      rules={{
        required: required ? validationMessages.required : false,
      }}
      render={({ field: { ref, value, onChange }, fieldState }) => (
        <FormControl
          component={direction === 'horizontal' ? 'div' : 'fieldset'}
          style={
            direction === 'horizontal'
              ? {
                  display: 'flex',
                  flexDirection: 'row',
                  alignItems: 'center',
                  gap: '20px',
                }
              : {}
          }
        >
          <FormLabel
            component="legend"
            style={direction ? { marginBottom: 0 } : {}}
          >
            {label}
          </FormLabel>
          <RadioGroup
            {...radioGroupProps}
            value={value || ''}
            onChange={(e) => (readOnly ? null : onChange(e.target.value))}
          >
            {options?.map((option, index) => (
              <FormControlLabel
                inputRef={ref}
                disabled={disabled || readOnly}
                key={index}
                value={option.value}
                control={<Radio checked={value === option.value} />}
                label={option.label}
              />
            ))}
          </RadioGroup>
          {required && fieldState?.error && (
            <FormHelperText error>{fieldState.error.message}</FormHelperText>
          )}
        </FormControl>
      )}
    />
  )
}

export default CustomRadioGroup
