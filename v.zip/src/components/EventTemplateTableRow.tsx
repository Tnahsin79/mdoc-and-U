import { TableCell, TableRow, Typography } from '@mui/material'
import { EventTemplate } from '@prisma/client'
import Link from 'next/link'

import { frontendRoutes } from '@/utils/constants/frontend'
import IconSwitcher from './Icons'

const EventTemplateTableRow = ({
  template: { templateId, templateName },
  onClick,
}: {
  template: EventTemplate
  onClick: () => void
}) => {
  return (
    <TableRow onClick={onClick}>
      <TableCell>
        <Typography variant="h5">{templateName}</Typography>
      </TableCell>

      <TableCell align="right" width="44px">
        <Link href={`${frontendRoutes.events.templateEdit}/${templateId}`}>
          <IconSwitcher icon="redArrowRight" />
        </Link>
      </TableCell>
    </TableRow>
  )
}

export default EventTemplateTableRow
