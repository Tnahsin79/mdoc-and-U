'use client'

import { AxiosError } from 'axios'
import { styled } from '@mui/system'
import { useRouter } from 'next/navigation'
import { errorMessages } from '@/utils/errorMessages'
import {
  Container as MUIContainer,
  List,
  ListItem as MUIListItem,
  Box,
  Button,
  Grid,
} from '@mui/material'

import Link from 'next/link'
import BerlinLogo from '@/components/BerlinLogo'
import axiosInstance from '@/services/axiosInstance'
import LogoutRoundedIcon from '@mui/icons-material/LogoutRounded'
import { unprotectedFrontendRoutes } from '@/utils/constants/frontend'
import { useContext } from 'react'
import { UserContext } from '@/contexts/userContext'
import { Role } from '@prisma/client'
import { useI18n, useScopedI18n } from '../../../locales/client'

const Header = styled('header')({
  height: '75px',
  background: '#fff',
  display: 'flex',
  alignItems: 'center',
})

const Main = styled('main')({
  minHeight: 'calc(100vh - 75px - 65px)',
  background: '#F5F7FB',
  padding: '50px 0',
})

const Footer = styled('footer')({
  height: '65px',
  background: '#fff',
})

const Container = styled(MUIContainer)({
  maxWidth: '1200px',
})

const HorizontalList = styled(List)({
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  paddingTop: '14px',
})

const ListItem = styled(MUIListItem)({
  width: 'fit-content',
})

const ListDivider = styled('li')({
  width: '1px',
  height: '20px',
  background: 'red',
})

const Layout = ({
  children,
  path,
}: {
  children: React.ReactNode
  path: string
}) => {
  const tHeader = useScopedI18n('header')
  const tFooter = useScopedI18n('footer')
  const tScoped = useScopedI18n('dashboard')
  const candidateTScoped = useScopedI18n('candidate')
  const t = useI18n()
  const router = useRouter()
  const { user, setPagination } = useContext(UserContext)

  const isEmployee = user?.role === Role.Employee
  const isCandidate = user?.role === Role.Candidate
  const linkStyle = { color: '#495057', fontWeight: 'bold' }
  const navigation = () => {
    if (isEmployee && !isCandidate) {
      return (
        <div style={{ display: 'flex', margin: 'auto' }}>
          <Box mr={10}>
            <Link style={linkStyle} href={'/'}>
              {candidateTScoped('Overview')}
            </Link>
          </Box>
          <Box mr={10}>
            <Link style={linkStyle} href={'/communication-employee'}>
              {tScoped('Communication')}
            </Link>
          </Box>
          <Box mr={10}>
            <Link style={linkStyle} href={'/event'}>
              {tScoped('Events')}
            </Link>
          </Box>
        </div>
      )
    } else if (!isEmployee && isCandidate) {
      //  router.replace('/candidate')
      return (
        <div style={{ display: 'flex', margin: 'auto' }}>
          <Box mr={10}>
            <Link style={linkStyle} href={'/candidate/dashboard'}>
              {candidateTScoped('Overview')}
            </Link>
          </Box>
          <Box mr={10}>
            <Link style={linkStyle} href={'/event'}>
              {tScoped('Events')}
            </Link>
          </Box>
          <Box mr={10}>
            <Link style={linkStyle} href={'/communication-candidate'}>
              {tScoped('Communication')}
            </Link>
          </Box>
        </div>
      )
    } else {
      //  router.replace('/collaborator/dashboard')
      return (
        <div style={{ display: 'flex', margin: 'auto' }}>
          <Box mr={10}>
            <Link style={linkStyle} href={'/collaborator/dashboard'}>
              {candidateTScoped('Overview')}
            </Link>
          </Box>
          <Box mr={10}>
            <Link style={linkStyle} href={'/event'}>
              {tScoped('Events')}
            </Link>
          </Box>
          <Box mr={10}>
            <Link style={linkStyle} href={'/communication-collaborator'}>
              {tScoped('Communication')}
            </Link>
          </Box>
          <Box mr={10}>
            <Link style={linkStyle} href={`/collaborator/collaborator-data/${user?.collaboratorId ?? undefined}`}>
              {tScoped('Collaboration Data')}
            </Link>
          </Box>
        </div>
      )
    }
  }

  const landingPage = unprotectedFrontendRoutes.includes(path)
    ? '/login'
    : user?.role === Role.Employee
      ? '/dashboard'
      : user?.role === Role.Collaborator
        ? '/collaborator/dashboard'
        : user?.role === Role.Candidate
          ? '/candidate/dashboard'
          : ''

  const signOutHandler = async () => {
    try {
      const response = await axiosInstance.post('/api/auth/signout')

      if (response.status === 200) {
        router.push('/login')
      }
    } catch (error) {
      // eslint-disable-next-line @typescript-eslint/no-unused-vars
      const errorMessage =
        error instanceof AxiosError
          ? error.response?.data?.error
          : errorMessages.DEFAULT_ERROR
    }
  }
  return (
    <>
      <Header>
        <Container
          sx={{
            margin: 'auto',
          }}
        >
          <Grid
            container
            justifyContent="space-between"
            mb={25}
            sx={{
              margin: 'auto',
            }}
          >
            <Grid item display="flex" alignItems="flex-end" gap={10}>
              <Link
                href={landingPage}
                onClick={() =>
                  setPagination({ candidate: 1, collaborator: 1, school: 1 })
                }
              >
                <BerlinLogo />
              </Link>
              {unprotectedFrontendRoutes.includes(path) ? null : navigation()}
            </Grid>
            <Grid item display="flex">
              {unprotectedFrontendRoutes.includes(path) ? null : (
                <Box display="flex" gap={10}>
                  <Button
                    variant="outlined"
                    size="small"
                    startIcon={<LogoutRoundedIcon />}
                    onClick={signOutHandler}
                  >
                    {tHeader('Sign Out')}
                  </Button>
                </Box>
              )}
            </Grid>
          </Grid>
        </Container>
      </Header>
      <Main
        sx={{
          display: unprotectedFrontendRoutes.includes(path) ? 'flex' : 'block',
          alignItems: unprotectedFrontendRoutes.includes(path)
            ? 'center'
            : 'unset',
        }}
      >
        <Container>{children}</Container>
      </Main>
      <Footer>
        <HorizontalList>
          <ListItem>Quereinstieg Berlin</ListItem>
          <ListDivider />
          <ListItem>{tFooter('Imprint')}</ListItem>
          <ListDivider />
          <ListItem>{tFooter('Data Protection')}</ListItem>
          <ListDivider />
          <ListItem>{tFooter('Contact')}</ListItem>
          <ListDivider />
          <ListItem>{tFooter('Accessibility')}</ListItem>
          <ListDivider />
          <ListItem>{tFooter('Terms of Use')}</ListItem>
        </HorizontalList>
      </Footer>
    </>
  )
}

export default Layout
