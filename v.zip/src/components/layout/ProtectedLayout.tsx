'use client'
import { useRouter } from 'next/navigation'
import { useContext, useEffect, useState } from 'react'
import { usePathname } from 'next/navigation'
import { LinearProgress } from '@mui/material'

import Layout from './Layout'
import axiosInstance from '@/services/axiosInstance'
import { unprotectedFrontendRoutes } from '@/utils/constants/frontend'
import { errorMessages } from '@/utils/errorMessages'
import { landingPage } from '@/utils/constants/frontend'
import { UserContext } from '@/contexts/userContext'

const Protected = ({ children }: { children: React.ReactNode }) => {
  const path = usePathname()
  const router = useRouter()
  const [loading, setLoading] = useState<boolean>(true)
  const [authenticated, setAuthenticated] = useState<boolean>(false)
  const { user, setUser } = useContext(UserContext)

  useEffect(() => {
    setLoading(true)
    if (path === '/') {
      router.replace(landingPage)
      return
    }
    const checkAuthentication = async () => {
      try {
        if (unprotectedFrontendRoutes.includes(path)) {
          setAuthenticated(true)
        } else {
          const res = await axiosInstance.get('/api/auth/me')
          if (res.status === 200) {
            if (!user?.personId) {
              setUser(res.data.person)
            }
            setAuthenticated(true)
          } else {
            throw new Error(errorMessages.INVALID_TOKEN)
          }
        }
      } catch (error) {
        const errorMessage =
          error instanceof Error ? error.message : errorMessages.DEFAULT_ERROR
        if (errorMessage === errorMessages.INVALID_TOKEN) {
          const refresh = async () => {
            try {
              const response = await axiosInstance.get('/api/auth/refresh')
              if (response.status === 200) {
                setAuthenticated(true)
              } else {
                throw new Error(errorMessages.EXPIRED_REFRESH_TOKEN)
              }
            } catch (error) {
              router.replace('/login')
            }
          }

          refresh()
        } else {
          router.replace('/login')
        }
      } finally {
        setLoading(false)
      }
    }

    checkAuthentication()
  }, [path, router])

  if (loading) {
    return <LinearProgress />
  }

  if (authenticated) {
    return (
      <>
        <Layout path={path}>{children}</Layout>
      </>
    )
  }

  return null
}

export default Protected
