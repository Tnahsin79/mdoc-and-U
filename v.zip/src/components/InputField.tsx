import { InputLabel, TextField } from '@mui/material'
import React from 'react'
import { Controller } from 'react-hook-form'

type InputFieldProps = import('@mui/material').TextFieldProps & {
  label: string
  control?: any
  name?: string
  rules?: any
  defaultValue?: string | number
  readOnly?: boolean
  direction?: 'vertical' | 'horizontal'
  withCheckbox?: boolean
}

const InputField = ({
  label,
  control,
  name,
  rules,
  defaultValue,
  readOnly = false,
  style,
  direction = 'vertical',
  withCheckbox = false,
  ...rest
}: InputFieldProps) => {
  if (control && name) {
    return (
      <Controller
        name={name}
        control={control}
        rules={rules}
        defaultValue={defaultValue ?? ''}
        render={({ field: { ref, ...restField } }) => (
          <div
            style={
              direction === 'horizontal'
                ? {
                    ...style,
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                  }
                : {}
            }
          >
            <InputLabel
              style={
                direction === 'horizontal' && withCheckbox
                  ? {
                      width: '100%',
                    }
                  : {}
              }
            >
              {label}
            </InputLabel>
            <TextField
              {...restField}
              {...rest}
              inputRef={ref}
              placeholder={rest.placeholder}
              disabled={readOnly}
              style={
                direction === 'horizontal'
                  ? {
                      width: `calc(50% - ${withCheckbox ? '26' : '10'}px)`,
                    }
                  : {}
              }
            />
          </div>
        )}
      />
    )
  }
}
export default InputField
