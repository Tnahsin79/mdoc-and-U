import React from 'react'
import { Controller } from 'react-hook-form'
import TextField from '@mui/material/TextField'
import { Box, Theme } from '@mui/material'
import styled from '@emotion/styled'
import DatePicker from 'react-datepicker'
import 'react-datepicker/dist/react-datepicker.css'

import { validationMessages } from '@/validators/messages'
import { useI18n } from '../../locales/client'
import IconSwitcher from './Icons'

import close from '../../public/assets/close.svg'

interface DatepickerProps {
  name: string
  label?: string
  control: any
  setValue?: any
  getValues?: any
  setError?: any
  clearErrors: any
  required?: boolean
  minSelectableTime?: Date | undefined
  minSelectableDate?: Date | undefined
  showTimeSelectOnly?: boolean
  showFromText?: boolean
  showUntilText?: boolean
  dateFormat?: string
  showTimeSelect?: boolean
  timeCaption?: string
  timeIntervals?: number
  onChange?: (date: Date) => void
  excludeDates?: Date[]
  minDate?: Date | null
  maxDate?: Date | null
  showMonthYearPicker?: boolean
  readOnly?: boolean
  allowPastDates?: boolean
  clearable?: boolean
}

const DatePickerWrapper = styled('div')(
  ({ theme, readOnly }: { theme?: Theme; readOnly: boolean }) => ({
    border: 'none',
    fontFamily: 'Inter, sans-serif',
    width: '100%',
    display: 'block',

    '&': {
      pointerEvents: readOnly ? 'none' : 'auto',
    },

    '& .time-picker .react-datepicker__triangle': {
      left: '-50% !important',
    },

    '.MuiFormLabel-root': {
      lineHeight: '13px',
    },

    '.react-datepicker-wrapper': {
      display: 'block !important',
      '& .MuiFormControl-root': {
        marginBottom: 0,
      },
    },

    '.react-datepicker__time-box': {
      width: '100% !important',
    },

    '.react-datepicker__close-icon::after': {
      backgroundColor: 'transparent !important',
      content: 'url(/assets/close.svg) !important',
      outline: 'none'
    },

    '.react-datepicker__time-list-item': {
      paddingTop: '12px !important',
    },
    '.react-datepicker__time-container': {
      width: '200px !important',
    },

    '& .react-datepicker-popper': {
      zIndex: 9,
    },
    '& .react-datepicker__navigation--previous, & .react-datepicker__navigation--next':
      {
        marginTop: '5px',
      },

    '& .react-datepicker__month-container': {
      border: 'none',
    },
    '& .react-datepicker__time-list-item--disabled': {
      color: '#000',
    },

    '& select': {
      padding: '5px 10px',
      borderRadius: '5px',
      overflow: 'hidden',
      outline: 'none',
      background: 'white',
    },

    '& .react-datepicker__day': {
      color: theme?.palette?.text?.primary,
      fontSize: '12px',
      fontWeight: 400,
      '&:hover': {
        backgroundColor: theme?.palette.primary.main,
        color: theme?.palette.common.white,
      },
      '&:focus-visible': {
        outline: 'none',
      },
      '&--keyboard-selected': {
        backgroundColor: theme?.palette.primary.main,
        color: theme?.palette.common.white,
        '&:hover': {
          background: theme?.palette.primary.main,
          color: theme?.palette.common.white,
        },
        '&--selected': {
          backgroundColor: theme?.palette.primary.main,
          color: theme?.palette.common.white,
          '&:hover': {
            background: theme?.palette.primary.main,
            color: theme?.palette.common.white,
          },
        },
      },
      '&--selected': {
        backgroundColor: theme?.palette.primary.main,
        color: theme?.palette.common.white,
        '&:hover': {
          background: theme?.palette.primary.main,
          color: theme?.palette.common.white,
        },
      },
      '&-name': {
        color: theme?.palette.primary.main,
      },
      '&--disabled': {
        opacity: 0.5,
        '&:hover': {
          color: theme?.palette.common.white,
          background: 'none',
        },
      },
    },
    '& .react-datepicker': {
      border: 'none',

      '&__header': {
        background: 'transparent',
        border: 'none',
      },
      '&__triangle': {
        '&:after,&:before': {
          borderBottomColor: '#fff !important',
        },
      },
      '&__time-list-item': {
        '&--selected': {
          backgroundColor: `${theme?.palette.primary.main} !important`,
        },
        '&:hover': {
          backgroundColor: `${theme?.palette.primary.main} !important`,
          color: `${theme?.palette.common.white} !important`,
        },
      },
    },

    '& .react-datepicker__day-name, .react-datepicker__day, .react-datepicker__time-name':
      {
        width: '70px',
        height: '35px',
        lineHeight: '35px',
      },

    '& .react-datepicker__month-option': {
      border: `1px solid #f4f4f2`,
      padding: '2px',
      background: theme?.palette.common.white,
    },
    '& .react-datepicker__year-option': {
      border: `1px solid #f4f4f2`,
      padding: '2px',
      background: theme?.palette.common.white,
      height: '100%',
    },

    '.MuiInputLabel-root.Mui-focused': {
      color: theme?.palette.secondary.main,
    },

    '& .react-datepicker__navigation--years': {
      height: '100%',
    },

    '@media (max-width: 1199px)': {
      '& .react-datepicker__day-name, .react-datepicker__day, .react-datepicker__time-name':
        {
          width: '60px',
        },
    },
    '@media (max-width: 767px)': {
      '& .react-datepicker__day-name, .react-datepicker__day, .react-datepicker__time-name':
        {
          width: '50px',
        },
    },
    '@media (max-width: 375px)': {
      '& .react-datepicker__day-name, .react-datepicker__day, .react-datepicker__time-name':
        {
          width: '43px',
        },
    },
  }),
)

const CustomDatePicker: React.FC<DatepickerProps> = ({
  name,
  label,
  control,
  setValue,
  setError,
  clearErrors,
  required,
  minSelectableTime,
  minSelectableDate,
  showTimeSelectOnly,
  showFromText,
  showUntilText,
  onChange,
  minDate = new Date(),
  maxDate = null,
  dateFormat,
  showMonthYearPicker = false,
  readOnly = false,
  allowPastDates = false,
  clearable = false,
  ...rest
}) => {
  const t = useI18n()
  const getStartText = () => {
    if (showTimeSelectOnly) {
      if (showFromText) {
        return t('Start')
      } else if (showUntilText) {
        return t('Until')
      } else return ''
    } else return ''
  }

  return (
    <DatePickerWrapper readOnly={readOnly}>
      <Box className={`${showTimeSelectOnly ? 'time-picker' : ''}`} mb={10}>
        <Controller
          name={name}
          control={control}
          rules={{
            required: required ? validationMessages.required : false,
          }}
          render={({ field, fieldState }) => {
            return (
              <DatePicker
                disabled={readOnly}
                scrollableYearDropdown
                dropdownMode="select"
                showYearDropdown
                showMonthDropdown
                minDate={allowPastDates ? undefined : minDate}
                maxDate={maxDate}
                showTimeSelectOnly={showTimeSelectOnly}
                filterTime={(time) => {
                  if (minSelectableTime) {
                    const minSelectableTimeDate = new Date(minSelectableTime)
                    return time >= minSelectableTimeDate
                  } else return true
                }}
                filterDate={(date) => {
                  if (!minSelectableDate) return true
                  const minSelectableTimeDate = new Date(minSelectableDate)
                  return date >= minSelectableTimeDate
                }}
                selected={field.value}
                onChange={(date: Date) => {
                  onChange && onChange(date)
                  setValue(name, date)
                  if (!date && !clearable) {
                    setError(name, {
                      type: 'manual',
                      message: validationMessages.required,
                    })
                  } else {
                    clearErrors(name)
                  }
                }}
                showMonthYearPicker={showMonthYearPicker}
                dateFormat={dateFormat}
                onFocus={(e) => e.target.blur()}
                customInput={
                  <TextField
                    inputRef={field.ref}
                    fullWidth
                    label={label}
                    variant="outlined"
                    error={Boolean(fieldState?.error)}
                    helperText={fieldState?.error?.message}
                    InputProps={{
                      startAdornment: getStartText(),
                    }}
                  />
                }
                isClearable={clearable}
                {...rest}
              />
            )
          }}
        />
      </Box>
    </DatePickerWrapper>
  )
}

export default CustomDatePicker
