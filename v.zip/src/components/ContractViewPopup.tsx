import axiosInstance from '@/services/axiosInstance'
import CustomModal from './Modal'
import Image from 'next/image'
import { useEffect, useState } from 'react'

interface ContractPopupModal {
  open: boolean
  handleClose: () => void
  attachment: string
}

const ContractViewPopup = ({
  open,
  handleClose,
  attachment,
}: ContractPopupModal) => {
  const [attachmentURL, setAttachmentURL] = useState<string | null>(null)

  useEffect(() => {
    openFileInNewTab(attachment)
  }, [])

  const openFileInNewTab = async (file: string) => {
    const responseFromFileServer = await axiosInstance.post(
      '/api/attachment/get-attachment-link',
      { fileName: file },
    )

    let fileURLFromFileServer = ''
    if (responseFromFileServer.status === 200) {
      fileURLFromFileServer = responseFromFileServer.data.url
    }

    setAttachmentURL(fileURLFromFileServer)
  }
  return (
    <>
      <CustomModal
        open={open}
        onClose={handleClose}
        sx={{ height: '400px', width: '90%' }}
      >
        {attachmentURL !== null && (
          <Image
            src={attachmentURL}
            alt="Picture"
            fill={true}
            style={{ zIndex: '-1' }}
          />
        )}
      </CustomModal>
    </>
  )
}

export default ContractViewPopup
