import { Box, Grid, Typography } from '@mui/material'
import IconSwitcher from './Icons'
import moment from 'moment'
import { phasesOptions } from '@/utils/constants/common'

export interface IContractPosition {
  contractDetailId?: number
  positionTitle: string
  billFrom: Date
  billTo: Date
  hourlyFee: number
  duration: number
  phaseId: number
}

const ContractPosition: React.FC<IContractPosition> = ({
  positionTitle,
  billFrom,
  billTo,
  hourlyFee,
  duration,
  phaseId,
}) => {
  const formattedbillFrom = moment(billFrom).format('MM.DD.YYYY')
  const formattedbillTo = moment(billTo).format('MM.DD.YYYY')

  const matchingObject = phasesOptions.find((obj) => {
    if (obj.id === phaseId) {
      if (obj.kickOff === true) return 'Kick Off'
      if (obj.firstStep === true) return 'First Step'
      if (obj.setUp === true) return 'Setup'
      if (obj.studies === true) return 'Studies'
    }
  })

  const phaseString = matchingObject?.kickOff
    ? 'Kick Off'
    : matchingObject?.firstStep
      ? 'First Step'
      : matchingObject?.setUp
        ? 'Set Up'
        : matchingObject?.studies
          ? 'Studies'
          : 'N/A'

  return (
    <>
      <Box
        sx={{ border: '1px solid #000000', backgroundColor: '#FFFFFF' }}
        pt={12}
        pl={7}
        pb={11}
        pr={10}
      >
        <Grid container justifyContent="space-between">
          <Grid item xs={3}>
            <Typography sx={{ fontWeight: 700, fontSize: '20px' }}>
              {positionTitle}
            </Typography>
          </Grid>
          <Grid item xs={6}>
            <Grid container justifyContent="space-between">
              <Typography sx={{ fontWeight: 400, fontSize: '16px' }}>
                {formattedbillFrom} - {formattedbillTo}
              </Typography>
              <Typography sx={{ fontWeight: 400, fontSize: '16px' }}>
                15 Student
              </Typography>
              <Typography sx={{ fontWeight: 400, fontSize: '16px' }}>
                {phaseString}
              </Typography>
              <Typography sx={{ fontWeight: 400, fontSize: '16px' }}>
                {hourlyFee * duration} €
              </Typography>
              <IconSwitcher icon="redArrowDown" />
            </Grid>
          </Grid>
        </Grid>
      </Box>
    </>
  )
}

export default ContractPosition
