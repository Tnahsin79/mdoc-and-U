import { Box, Grid } from '@mui/material'
import React, { useEffect, useState } from 'react'
import { useForm } from 'react-hook-form'
import { RHFAutocompleteField } from './DropDown'
import axiosInstance from '@/services/axiosInstance'
import CustomButton from './Buttons/CustomButton'
import Toast from './Toast'

interface ICandidate {
  personId: number
  firstName: string
  lastName: string | null
  email: string
}

type AddCandidateProp = (candidate: ICandidate) => void

const AddCandidates: React.FC<{ addCandidateHandler: AddCandidateProp }> = ({
  addCandidateHandler,
}) => {
  const [candidates, setCandidates] = useState<any>([])
  const [serverError, setServerError] = useState<string>('')

  const methods = useForm<any>({
    mode: 'all',
    shouldFocusError: true,
  })
  const {
    handleSubmit,
    formState: { errors },
    control,
    watch,
    resetField,
  } = methods

  const candidateId = watch('candidateId')

  const getCandidates = async () => {
    const response = await axiosInstance.get('/api/candidate/candidate-list')
    setCandidates(response.data.candidateList)
  }

  const submitHandler = async (payload: { candidateId: number }) => {
    try {
      setServerError('')

      if (!payload.candidateId) {
        throw new Error('Please select candidate')
      }
      const candidateToSend = candidates.find(
        (cand: any) => cand.personId === candidateId,
      )
      resetField('candidateId')
      addCandidateHandler(candidateToSend)
    } catch (error: any) {
      let errorMessage = error.message

      setServerError(errorMessage)
    }
  }

  useEffect(() => {
    getCandidates()
  }, [])

  return (
    <>
      <Box
        component="form"
        onSubmit={handleSubmit(submitHandler)}
        autoComplete="off"
        width={'50%'}
      >
        <Grid
          container
          spacing={10}
          sx={{ justifyContent: 'center', alignItems: 'center' }}
        >
          <Grid xs={6} item>
            <RHFAutocompleteField
              control={control}
              options={candidates?.map((item: any) => {
                return {
                  id: item.personId,
                  label: item.firstName + ' ' + item.lastName,
                }
              })}
              name="candidateId"
              label={''}
            />
          </Grid>

          <Grid xs={3} marginTop="-11px" item>
            <CustomButton
              label
              labelText="Add"
              variant="contained"
              type="submit"
            />
          </Grid>
        </Grid>
      </Box>
      {serverError !== '' ? (
        <Toast message={serverError} severity="error" />
      ) : null}
    </>
  )
}

export default AddCandidates
