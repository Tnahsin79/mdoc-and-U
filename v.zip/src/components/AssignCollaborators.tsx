import { Box, Grid, Typography } from '@mui/material'
import React from 'react'
import { useFormContext } from 'react-hook-form'

import Button from '@/components/Buttons/CustomButton'
import { RHFAutocompleteField } from './DropDown'
import InputField from './InputField'
import CustomModal from './Modal'
import CustomRadioGroup from './RadioGroup'
import { IList } from '@/interface/common'
import { useScopedI18n } from '../../locales/client'

interface IAssignCollaboratorsProps {
  open: boolean
  handleClose: () => void
  suitableCollaborators: any
  phases: IList
  subjectAreas: IList
  readOnly?: boolean
  attendeesId?: any
}

const AssignCollaborators = ({
  open,
  handleClose,
  suitableCollaborators,
  phases,
  subjectAreas,
  readOnly = false,
  attendeesId,
}: IAssignCollaboratorsProps) => {
  const tScoped = useScopedI18n('event')
  const { control, trigger, getValues } = useFormContext()
  const values = getValues()

  const onSave = async () => {
    const isValid = await trigger('suitableCollaboratorId')
    if (isValid) {
      handleClose()
    } else {
      return
    }
  }

  const modifiedAttendeesId = attendeesId?.map(
    (item: any) => +item.split('_')[1].toString(),
  )

  return (
    <>
      <CustomModal open={open} onClose={handleClose}>
        <Typography
          variant="h6"
          component="h2"
          mb={10}
          sx={{ fontWeight: 700, fontSize: '28px', color: '#E40422' }}
        >
          {tScoped('Assign Collaborators')}
        </Typography>

        <Box>
          <Grid item xs={12} md={6} justifyContent="center" alignItems="center">
            <CustomRadioGroup
              disabled
              name="phaseId"
              row
              required
              label={tScoped('Phase (Not Editable)')}
              control={control}
              options={phases?.map((item) => {
                return {
                  value: item.listId.toString(),
                  label: item.listValue,
                }
              })}
            />
          </Grid>
          <InputField
            control={control}
            name="subjectAreaId"
            label={tScoped('Subject Area (Not Editable)')}
            disabled
            fullWidth
            value={
              subjectAreas?.filter(
                (item) => item?.listId === values?.subjectAreaId,
              )?.[0]?.listValue
            }
          />
          <InputField
            control={control}
            name="subjectModule"
            label={tScoped('Module (Not Editable)')}
            disabled
            fullWidth
          />

          <RHFAutocompleteField
            required={!readOnly}
            control={control}
            options={suitableCollaborators?.collaborators
              ?.filter(
                (item: any) => !modifiedAttendeesId?.includes(item.personId),
              )
              ?.sort((a: any, b: any) => {
                return a?.role?.localeCompare(b.role)
              })
              .map((item: any) => {
                return {
                  id: item.personId,
                  label: `${item.firstName}${
                    item.lastName ? ' ' + item.lastName : ''
                  }`,
                  type: item.role,
                }
              })}
            name="suitableCollaboratorId"
            label={tScoped('Suitable Collaborator')}
            readOnly={readOnly}
          />
          <Grid
            container
            justifyContent="flex-end"
            alignItems="center"
            marginY={10}
          >
            <Button
              label
              icon
              labelText={tScoped('Save')}
              iconName="save"
              onClick={onSave}
            />
          </Grid>
        </Box>
      </CustomModal>
    </>
  )
}

export default AssignCollaborators
