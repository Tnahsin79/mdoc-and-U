import { Box, Grid, Typography } from '@mui/material'
import CustomModal from '../Modal'
import { RHFAutocompleteField } from '../DropDown'
import { FieldErrors, SubmitHandler, useForm } from 'react-hook-form'
import InputField from '../InputField'
import { RHFTextArea } from '../TextArea'
import CustomButton from '../Buttons/CustomButton'
import { useContext, useEffect, useState } from 'react'
import { Person } from '@prisma/client'
import axiosInstance from '@/services/axiosInstance'
import { validationMessages } from '@/validators/messages'
import { EmployeeNewMessageForm } from '@/interface/communication'
import { UserContext } from '@/contexts/userContext'
import AddAttachment from '../Buttons/AddAttachment'
import { errorMessages } from '@/utils/errorMessages'
import { AxiosError } from 'axios'
import Toast from '../Toast'
import { useScopedI18n } from '../../../locales/client'
import { successMessages } from '@/utils/successMessages'

interface INewPhoneNoteProps {
  open: boolean
  handleClose: () => void
}

interface INewPhoneNote {
  person: number | undefined
  topic: string
  template: string
  note: string
}

const options = [
  {
    listId: '1',
    listValue: 'Dummy',
  },
  {
    listId: '2',
    listValue: 'Dummy2',
  },
  {
    listId: '3',
    listValue: 'Dummy3',
  },
  {
    listId: '4',
    listValue: 'No Template',
  },
]

const NewPhoneNote = ({ open, handleClose }: INewPhoneNoteProps) => {
  const tScoped = useScopedI18n('communication')

  const [persons, setPersons] = useState<Person[] | []>([])
  const [fileUploading, setFileUploading] = useState<boolean>(false)

  const newMessageData = {
    template: '4',
    person: undefined,
    topic: '',
    note: '',
  }

  const {
    control,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<INewPhoneNote>({
    mode: 'all',
    values: newMessageData,
    shouldFocusError: true,
  })

  const { user } = useContext(UserContext)

  const [serverError, setServerError] = useState<string>('')
  const [successMessage, setSuccessMessage] = useState<string>('')
  const [currentFiles, setCurrentFiles] = useState<FileList | null>(null)
  const [modalOpen, setModalOpen] = useState<boolean>(false)

  const uploadFileHandler = async () => {
    try {
      const formData = new FormData()
      if (currentFiles) {
        formData.append('file', currentFiles[0])
        const responseFromFileServer = await axiosInstance.post(
          '/api/upload',
          formData,
        )

        if (responseFromFileServer && responseFromFileServer.status === 201) {
          setFileUploading(false)
          return responseFromFileServer?.data.responseData[0].fileName ?? ''
        } else {
          throw new Error(errorMessages.FAILED_TO_UPLOAD_ATTACHMENT)
        }
      }
    } catch (error) {
      const errorMessage =
        error instanceof AxiosError
          ? error.response?.data?.error
          : errorMessages.DEFAULT_ERROR

      setServerError(errorMessage)
    } finally {
      setCurrentFiles(null)
    }
  }

  const getPersonList = async () => {
    const personsFromApi = await axiosInstance.get('/api/person/list')
    const filteredPersonsFromApi = personsFromApi.data.persons.filter(
      (person: Person) => person.email !== user?.email,
    )
    setPersons(filteredPersonsFromApi)
  }

  useEffect(() => {
    if (open) {
      getPersonList()
      setModalOpen(true)
    } else {
      setModalOpen(false)
    }
  }, [open])

  useEffect(() => {
    if (modalOpen) {
      getPersonList()
    }
  }, [modalOpen])

  const newPhoneNoteHandler: SubmitHandler<INewPhoneNote> = async (payload) => {
    try {
      const fileName = await uploadFileHandler()

      const data = {
        subject: payload.topic,
        body: payload.note,
        recipients: [payload.person],
        isNote: true,
        attachment: fileName ?? '',
      }

      const response = await axiosInstance.post(
        '/api/communication/employee/create',
        data,
      )

      if (response.status === 200) {
        setSuccessMessage(successMessages.successfullySavedNote)
        reset()
        handleClose()
      }
    } catch (error) {
      setServerError(errorMessages.COULD_NOT_SAVE_NOTE)
    }
  }

  return (
    <>
      <CustomModal open={open} onClose={handleClose}>
        <Box
          component="form"
          autoComplete="off"
          onSubmit={handleSubmit(newPhoneNoteHandler)}
        >
          <Typography
            variant="h6"
            component="h2"
            mb={10}
            sx={{ fontWeight: 700, fontSize: '28px', color: '#E40422' }}
          >
            {tScoped('New Phone Note')}
          </Typography>

          <Box>
            <RHFAutocompleteField
              options={persons?.map((item) => {
                return {
                  id: item.personId,
                  label: {
                    firstName: item.firstName,
                    lastName: item.lastName || '',
                    email: item.email,
                    role: item.role,
                  },
                }
              })}
              name="person"
              required
              label={tScoped('Person')}
              control={control}
            />
            <RHFAutocompleteField
              options={options?.map((item) => {
                return {
                  id: item.listId,
                  label: item.listValue,
                }
              })}
              name="template"
              label={tScoped('Template')}
              control={control}
            />
            <InputField
              label={tScoped('Topic')}
              name="topic"
              control={control}
              fullWidth
              rules={{
                required: {
                  value: true,
                  message: validationMessages.required,
                },
              }}
              error={!!(errors as FieldErrors<EmployeeNewMessageForm>).topic}
              helperText={
                (errors as FieldErrors<EmployeeNewMessageForm>).topic?.message
              }
            />

            <Box sx={{ marginBottom: '20px' }}>
              <RHFTextArea
                label={tScoped('Note')}
                name="note"
                control={control}
                required
              />
            </Box>
            <Grid container spacing={10}>
              <Grid item>
                <AddAttachment
                  labelText={tScoped('Attach Document')}
                  sx={{ marginBottom: '20px' }}
                  currentFiles={currentFiles}
                  fileUploading={fileUploading}
                  setCurrentFiles={setCurrentFiles}
                  multiple={false}
                />
              </Grid>
            </Grid>
            <Grid container justifyContent="flex-end">
              <CustomButton
                label
                labelText={tScoped('Discard')}
                onClick={() => {
                  handleClose()
                  reset()
                }}
              />
              <CustomButton
                icon
                label
                labelText={tScoped('Save')}
                iconName="check"
                type="submit"
                sx={{ marginLeft: '20px' }}
              />
            </Grid>
          </Box>
        </Box>
      </CustomModal>
      {successMessage !== '' ? (
        <Toast message={successMessage} severity="success" />
      ) : null}
      {serverError !== '' ? (
        <Toast message={serverError} severity="error" />
      ) : null}
    </>
  )
}

export default NewPhoneNote
