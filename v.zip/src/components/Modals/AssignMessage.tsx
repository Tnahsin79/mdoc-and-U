import React, { useContext, useEffect, useState } from 'react'
import { Box, Grid, Typography } from '@mui/material'
import { Person } from '@prisma/client'
import { useForm } from 'react-hook-form'

import CustomModal from '../Modal'
import { RHFAutocompleteField } from '../DropDown'
import axiosInstance from '@/services/axiosInstance'
import { UserContext } from '@/contexts/userContext'
import CustomButton from '../Buttons/CustomButton'
import { useScopedI18n } from '../../../locales/client'
import { errorMessages } from '@/utils/errorMessages'

interface AssignMessageProps {
  open: boolean
  handleClose: () => void
  communicationId: number | null
  onAssignSuccess: () => void
  setToastData: ({
    type,
    message,
  }: {
    type: 'success' | 'error' | undefined
    message: string
  }) => void
}

const AssignMessage = ({
  open,
  handleClose,
  communicationId,
  onAssignSuccess,
  setToastData,
}: AssignMessageProps) => {
  const tScoped = useScopedI18n('communication')
  const [persons, setPersons] = useState<Person[] | []>([])
  const [loading, setLoading] = useState(false)
  const { user } = useContext(UserContext)

  const getPersonList = async () => {
    const personsFromApi = await axiosInstance.post('/api/person/list', {
      role: 'Employee',
    })
    const filteredPersonsFromApi = personsFromApi.data.persons.filter(
      (person: Person) => person.email !== user?.email,
    )

    setPersons([
      ...filteredPersonsFromApi,
      {
        personId: 'allCandidates',
        firstName: tScoped('All Candidates'),
      },
      {
        personId: 'allCollaborators',
        firstName: tScoped('All Collaborators'),
      },
    ])
  }

  useEffect(() => {
    getPersonList()
  }, [])

  const { control, handleSubmit, reset } = useForm({
    mode: 'all',
    shouldFocusError: true,
  })

  const onAssign = handleSubmit(async (data) => {
    setLoading(true)

    try {
      const response = await axiosInstance.post('/api/communication/assign', {
        personId: data.person,
        communicationId: communicationId,
      })

      setToastData({
        type: 'success',
        message: response.data.message,
      })

      handleClose()
      reset()
    } catch (error: any) {
      setToastData({
        type: 'error',
        message: error?.message || errorMessages.DEFAULT_ERROR,
      })
    } finally {
      setLoading(false)
    }
    onAssignSuccess()
  })

  return (
    <>
      <CustomModal
        open={open}
        onClose={() => {
          handleClose()
          reset()
        }}
        sx={{
          height: '35%',
        }}
      >
        <Box>
          <Typography
            variant="h6"
            component="h2"
            mb={10}
            sx={{ fontWeight: 700, fontSize: '28px', color: '#E40422' }}
          >
            {tScoped('Assign non-assigned message to an account')}
          </Typography>
          <Box component="form" autoComplete="off" onSubmit={onAssign}>
            <RHFAutocompleteField
              options={persons?.map((item) => {
                return {
                  id: item.personId,
                  label: {
                    firstName: item.firstName,
                    lastName: item.lastName || '',
                    email: item.email || '',
                    role: item.role || '',
                  },
                }
              })}
              name="person"
              label={tScoped('Person')}
              control={control}
              required
            />
            <Grid container justifyContent="flex-end" mt={20}>
              <CustomButton
                label
                labelText={tScoped('Discard')}
                onClick={() => {
                  handleClose()
                  reset()
                }}
              />
              <CustomButton
                label
                labelText={tScoped('Assign')}
                variant="contained"
                sx={{ marginLeft: '20px' }}
                type="submit"
                loading={loading}
              />
            </Grid>
          </Box>
        </Box>
      </CustomModal>
    </>
  )
}

export default AssignMessage
