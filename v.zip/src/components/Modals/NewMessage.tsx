'use client'
import { Box, Grid, Typography } from '@mui/material'
import React, { useContext, useEffect, useState } from 'react'

import InputField from '../InputField'
import CustomModal from '../Modal'
import { RHFAutocompleteField } from '../DropDown'
import CustomButton from '../Buttons/CustomButton'
import { FieldErrors, SubmitHandler, useForm } from 'react-hook-form'
import { RHFTextArea } from '../TextArea'
import axiosInstance from '@/services/axiosInstance'
import { validationMessages } from '@/validators/messages'
import { Person } from '.prisma/client'
import { removeDuplicates } from '@/utils/removeDuplicatesFromArray'
import {
  CandidateNewMessageForm,
  CollaboratorNewMessageForm,
  EmployeeNewMessageForm,
  IMailData,
} from '@/interface/communication'
import { UserContext } from '@/contexts/userContext'
import AddAttachment from '../Buttons/AddAttachment'
import { errorMessages } from '@/utils/errorMessages'
import { AxiosError } from 'axios'
import Toast from '../Toast'
import { useScopedI18n } from '../../../locales/client'
import { successMessages } from '@/utils/successMessages'

interface INewMessageProps {
  open: boolean
  handleClose: () => void
  role: 'Candidate' | 'Employee' | 'Collaborator'
  replyToMail?: IMailData
  preDecidedRecipients?: number[]
}

export interface NewMessageForm {
  recipients: number[]
  template: number
  topic: string
  message: string
}

type MessageForm =
  | EmployeeNewMessageForm
  | CollaboratorNewMessageForm
  | CandidateNewMessageForm

const options = [
  {
    listId: '1',
    listValue: 'Dummy',
  },
  {
    listId: '2',
    listValue: 'Dummy2',
  },
  {
    listId: '3',
    listValue: 'Dummy3',
  },
  {
    listId: '4',
    listValue: 'No Template',
  },
]

const NewMessage = ({
  open,
  handleClose,
  role = 'Candidate',
  replyToMail,
  preDecidedRecipients = [],
}: INewMessageProps) => {
  const tScoped = useScopedI18n('communication')

  const topicPopulate = () => {
    if (replyToMail) {
      if (
        replyToMail.subject[0] === 'R' &&
        replyToMail.subject[1] === 'e' &&
        replyToMail.subject[2] === ':'
      ) {
        return replyToMail.subject
      } else {
        return `Re: ${replyToMail.subject}`
      }
    } else {
      return ''
    }
  }

  const replyTopic = replyToMail ? topicPopulate() : ''

  const newMessageData = {
    recipients:
      (role === 'Employee' || role === 'Collaborator') && replyToMail
        ? [replyToMail.senderId]
        : preDecidedRecipients.length > 0 ? [...preDecidedRecipients] : [],
    recipient:
      role === 'Candidate' && replyToMail ? replyToMail.senderId : null,
    message: '',
    subject: replyTopic,
    template: '4',
    reference: replyTopic,
    topic: replyTopic,
  }

  const {
    control,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<MessageForm>({
    mode: 'all',
    values: newMessageData,
    shouldFocusError: true,
  })

  const { user } = useContext(UserContext)

  const [persons, setPersons] = useState<Person[] | []>([])
  const [serverError, setServerError] = useState<string>('')
  const [successMessage, setSuccessMessage] = useState<string>('')
  const [fileUploading, setFileUploading] = useState<boolean>(false)
  const [currentFiles, setCurrentFiles] = useState<FileList | null>(null)
  const [modalOpen, setModalOpen] = useState<boolean>(false)

  const uploadFileHandler = async () => {
    try {
      const formData = new FormData()
      if (currentFiles) {
        formData.append('file', currentFiles[0])
        const responseFromFileServer = await axiosInstance.post(
          '/api/upload',
          formData,
        )

        if (responseFromFileServer && responseFromFileServer.status === 201) {
          setFileUploading(false)
          return responseFromFileServer?.data.responseData[0].fileName ?? ''
        } else {
          throw new Error(errorMessages.FAILED_TO_UPLOAD_ATTACHMENT)
        }
      }
    } catch (error) {
      const errorMessage =
        error instanceof AxiosError
          ? error.response?.data?.error
          : errorMessages.DEFAULT_ERROR

      setServerError(errorMessage)
    } finally {
      setCurrentFiles(null)
    }
  }

  const getPersonList = async () => {
    if (role === 'Employee') {
      const personsFromApi = await axiosInstance.post('/api/person/list', {
        role: 'Employee',
      })
      const filteredPersonsFromApi = personsFromApi.data.persons.filter(
        (person: Person) => person.email !== user?.email,
      )

      setPersons([
        ...filteredPersonsFromApi,
        {
          personId: 'allCandidates',
          firstName: 'All Candidates',
        },
        {
          personId: 'allCollaborators',
          firstName: 'All Collaborators',
        },
      ])
    } else if (role === 'Collaborator') {
      const personsFromApi = await axiosInstance.post('/api/person/list', {
        role: 'Collaborator',
      })
      const filteredPersonsFromApi = personsFromApi.data.persons.filter(
        (person: Person) => person.email !== user?.email,
      )

      setPersons(filteredPersonsFromApi)
    } else if (role === 'Candidate') {
      const personsFromApi = await axiosInstance.post('/api/person/list', {
        role: 'Candidate',
      })
      const filteredPersonsFromApi = personsFromApi.data.persons.filter(
        (person: Person) => person.email !== user?.email,
      )

      setPersons(filteredPersonsFromApi)
    }
  }

  useEffect(() => {
    if (open) {
      getPersonList()
      setModalOpen(true)
    } else {
      setModalOpen(false)
    }
  }, [open])

  useEffect(() => {
    if (modalOpen) {
      getPersonList()
    }
  }, [modalOpen])

  const employeeHandler: SubmitHandler<MessageForm> = async (payload) => {
    try {
      let allCandidates = []
      let allCollaborators = []
      let filteredRecipients: (number | string)[] = []

      if (
        (payload as EmployeeNewMessageForm).recipients.includes('allCandidates')
      ) {
        allCandidates = [
          ...persons
            .filter((person) => person.role === 'Candidate')
            .map((candidate) => candidate.personId),
        ]

        filteredRecipients = [
          ...filteredRecipients,
          ...(payload as EmployeeNewMessageForm).recipients.concat(
            allCandidates,
          ),
        ]
      }

      if (
        (payload as EmployeeNewMessageForm).recipients.includes(
          'allCollaborators',
        )
      ) {
        allCollaborators = persons
          .filter((person) => person.role === 'Collaborator')
          .map((candidate) => candidate.personId)

        filteredRecipients = [
          ...filteredRecipients,
          ...(payload as EmployeeNewMessageForm).recipients.concat(
            allCollaborators,
          ),
        ]
      } else {
        filteredRecipients = [
          ...filteredRecipients,
          ...(payload as EmployeeNewMessageForm).recipients,
        ]
      }
      const uniqueRecipients = removeDuplicates(filteredRecipients).filter(
        (recipient) => {
          if (
            recipient !== 'allCollaborators' &&
            recipient !== 'allCandidates'
          ) {
            return recipient
          }
        },
      )

      const fileName = await uploadFileHandler()

      const data = {
        recipients: uniqueRecipients,
        body: payload.message,
        isNote: false,
        subject: (payload as EmployeeNewMessageForm).topic,
        attachment: fileName ?? '',
      }

      const response = await axiosInstance.post(
        '/api/communication/employee/create',
        data,
      )

      if (response.status === 200) {
        setSuccessMessage(successMessages.successfullySentMail)
        handleClose()
        reset()
      }
    } catch (error) {
      setServerError(errorMessages.COULD_NOT_SEND_MESSAGE)
    }
  }

  const candidateHandler: SubmitHandler<MessageForm> = async (payload) => {
    try {
      const fileName = await uploadFileHandler()

      const data = {
        recipient: (payload as CandidateNewMessageForm).recipient,
        body: payload.message,
        subject: (payload as CandidateNewMessageForm).subject,
        attachment: fileName ?? '',
      }

      const response = await axiosInstance.post(
        '/api/communication/candidate/create',
        data,
      )

      if (response.status === 200) {
        setSuccessMessage(successMessages.successfullySentMail)
        handleClose()
        reset()
      }
    } catch (error) {
      setServerError(errorMessages.COULD_NOT_SEND_MESSAGE)
    }
  }

  const collaboratorHandler: SubmitHandler<MessageForm> = async (payload) => {
    try {
      const fileName = await uploadFileHandler()

      const data = {
        recipients: (payload as CollaboratorNewMessageForm).recipients,
        body: payload.message,
        subject: (payload as CollaboratorNewMessageForm).reference,
        attachment: fileName ?? '',
      }

      const response = await axiosInstance.post(
        '/api/communication/collaborator/create',
        data,
      )

      if (response.status === 200) {
        setSuccessMessage(successMessages.successfullySentMail)
        handleClose()
        reset()
      }
    } catch (error) {
      setServerError(errorMessages.COULD_NOT_SEND_MESSAGE)
    }
  }

  return (
    <>
      <CustomModal open={open} onClose={handleClose}>
        <Box>
          <Typography
            variant="h6"
            component="h2"
            mb={10}
            sx={{ fontWeight: 700, fontSize: '28px', color: '#E40422' }}
          >
            {replyToMail ? tScoped('Reply') : tScoped('New Message')}
          </Typography>

          {role === 'Employee' && (
            <Box
              component="form"
              autoComplete="off"
              onSubmit={handleSubmit(employeeHandler)}
            >
              <RHFAutocompleteField
                options={persons?.map((item) => {
                  return {
                    id: item.personId,
                    label: {
                      firstName: item.firstName,
                      lastName: item.lastName || '',
                      email: item.email || '',
                      role: item.role || '',
                    },
                  }
                })}
                name="recipients"
                required
                label={tScoped('Recipients')}
                control={control}
                multiple
                readOnly={replyToMail ? true : false}
              />
              <RHFAutocompleteField
                options={options?.map((item) => {
                  return {
                    id: item.listId,
                    label: item.listValue,
                  }
                })}
                name="template"
                required
                label={tScoped('Template')}
                control={control}
              />
              <InputField
                label={tScoped('Topic')}
                name="topic"
                control={control}
                fullWidth
                rules={{
                  required: {
                    value: true,
                    message: validationMessages.required,
                  },
                }}
                error={!!(errors as FieldErrors<EmployeeNewMessageForm>).topic}
                helperText={
                  (errors as FieldErrors<EmployeeNewMessageForm>).topic?.message
                }
              />

              <Box sx={{ marginBottom: '20px' }}>
                <RHFTextArea
                  label={tScoped('Message')}
                  name="message"
                  control={control}
                  required
                />
              </Box>
              <Grid container spacing={10} justifyContent="space-between">
                <Grid item>
                  <AddAttachment
                    labelText={tScoped('Attach Document')}
                    sx={{ marginBottom: '20px' }}
                    currentFiles={currentFiles}
                    fileUploading={fileUploading}
                    setCurrentFiles={setCurrentFiles}
                    multiple={false}
                  />
                </Grid>
              </Grid>

              <Grid container justifyContent="flex-end">
                <CustomButton
                  label
                  labelText={tScoped('Discard')}
                  onClick={() => {
                    handleClose()
                    reset()
                  }}
                />
                <CustomButton
                  label
                  labelText={tScoped('Send')}
                  variant="contained"
                  type="submit"
                  sx={{ marginLeft: '20px' }}
                />
              </Grid>
            </Box>
          )}

          {role === 'Collaborator' && (
            <Box
              component="form"
              autoComplete="off"
              onSubmit={handleSubmit(collaboratorHandler)}
            >
              <RHFAutocompleteField
                options={persons?.map((item) => {
                  return {
                    id: item.personId,
                    label:
                      item.firstName +
                      ' ' +
                      (item.lastName ? item.lastName : ''),
                  }
                })}
                name="recipients"
                required
                label={tScoped('Receiving')}
                control={control}
                multiple
                readOnly={replyToMail ? true : false}
              />
              <InputField
                label={tScoped('Reference')}
                name="reference"
                control={control}
                fullWidth
                rules={{
                  required: {
                    value: true,
                    message: validationMessages.required,
                  },
                }}
                error={
                  !!(errors as FieldErrors<CollaboratorNewMessageForm>)
                    .reference
                }
                helperText={
                  (errors as FieldErrors<CollaboratorNewMessageForm>).reference
                    ?.message
                }
              />

              <Box sx={{ marginBottom: '20px' }}>
                <RHFTextArea
                  label={tScoped('Message')}
                  name="message"
                  control={control}
                  required
                />
              </Box>
              <Grid container spacing={10} justifyContent="space-between">
                <Grid item>
                  <AddAttachment
                    labelText={tScoped('Attach Document')}
                    currentFiles={currentFiles}
                    fileUploading={fileUploading}
                    setCurrentFiles={setCurrentFiles}
                    multiple={false}
                    sx={{ marginBottom: '20px' }}
                  />
                </Grid>
              </Grid>
              <Grid container justifyContent="flex-end">
                <CustomButton
                  label
                  labelText={tScoped('Discard')}
                  onClick={() => {
                    handleClose()
                    reset()
                  }}
                />
                <CustomButton
                  label
                  labelText={tScoped('Send')}
                  variant="contained"
                  type="submit"
                  sx={{ marginLeft: '20px' }}
                />
              </Grid>
            </Box>
          )}

          {role === 'Candidate' && (
            <Box
              component="form"
              autoComplete="off"
              onSubmit={handleSubmit(candidateHandler)}
            >
              <RHFAutocompleteField
                options={persons?.map((item) => {
                  return {
                    id: item.personId,
                    label: {
                      firstName: item.firstName,
                      lastName: item.lastName || '',
                      email: item.email,
                      role: item.role,
                    },
                  }
                })}
                name="recipient"
                required
                label={tScoped('Recipient')}
                control={control}
                readOnly={replyToMail ? true : false}
              />
              <InputField
                label={tScoped('Subject')}
                name="subject"
                control={control}
                fullWidth
                rules={{
                  required: {
                    value: true,
                    message: validationMessages.required,
                  },
                }}
                error={
                  !!(errors as FieldErrors<CandidateNewMessageForm>).subject
                }
                helperText={
                  (errors as FieldErrors<CandidateNewMessageForm>).subject
                    ?.message
                }
              />

              <Box sx={{ marginBottom: '20px' }}>
                <RHFTextArea
                  label={tScoped('Message')}
                  name="message"
                  control={control}
                  required
                />
              </Box>
              <Grid container spacing={10} justifyContent="space-between">
                <Grid item>
                  <AddAttachment
                    labelText={tScoped('Attach Document')}
                    sx={{ marginBottom: '20px' }}
                    currentFiles={currentFiles}
                    fileUploading={fileUploading}
                    setCurrentFiles={setCurrentFiles}
                    multiple={false}
                  />
                </Grid>
              </Grid>

              <Grid container justifyContent="flex-end">
                <CustomButton
                  label
                  labelText={tScoped('Discard')}
                  onClick={() => {
                    handleClose()
                    reset()
                  }}
                />
                <CustomButton
                  label
                  labelText={tScoped('Send')}
                  variant="contained"
                  type="submit"
                  sx={{ marginLeft: '20px' }}
                />
              </Grid>
            </Box>
          )}
        </Box>
      </CustomModal>

      {successMessage !== '' ? (
        <Toast message={successMessage} severity="success" />
      ) : null}

      {serverError !== '' ? (
        <Toast message={serverError} severity="error" />
      ) : null}
    </>
  )
}

export default NewMessage
