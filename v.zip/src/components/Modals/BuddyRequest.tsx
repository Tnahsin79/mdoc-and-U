import React, { useContext, useEffect, useState } from 'react'
import CustomModal from '../Modal'
import { Box, Grid, InputLabel, Typography } from '@mui/material'
import { RHFAutocompleteField } from '../DropDown'
import CustomDatePicker from '../DatePicker'
import { useScopedI18n } from '../../../locales/client'
import { RHFTextArea } from '../TextArea'
import { FieldErrors, SubmitHandler, useForm } from 'react-hook-form'
import Toast from '../Toast'
import axiosInstance from '@/services/axiosInstance'
import { Person } from '@prisma/client'
import { UserContext } from '@/contexts/userContext'
import CustomButton from '../Buttons/CustomButton'
import moment from 'moment'
import { successMessages } from '@/utils/successMessages'
import { errorMessages } from '@/utils/errorMessages'
import AddAttachment from '../Buttons/AddAttachment'
import { AxiosError } from 'axios'

interface INewMessageProps {
  open: boolean
  handleClose: () => void
  //   role: 'Candidate' | 'Employee' | 'Collaborator'
  //   replyToMail?: IMailData
  //   preDecidedRecipients?: number[]
}

interface IBuddyProps {
  fromDate: Date
  untilDate: Date
  message?: string
  recipients: number[]
}

const BuddyRequest: React.FC<INewMessageProps> = ({ open, handleClose }) => {
  const tScoped = useScopedI18n('communication')
  const [successMessage, setSuccessMessage] = useState<string>('')
  const [serverError, setServerError] = useState<string>('')
  const [persons, setPersons] = useState<Person[] | []>([])
  const [currentFiles, setCurrentFiles] = useState<FileList | null>(null)
  const [fileUploading, setFileUploading] = useState<boolean>(false)

  const { user } = useContext(UserContext)

  const {
    control,
    handleSubmit,
    reset,
    formState: { errors },
    clearErrors,
    setError,
    setValue,
  } = useForm<any>({
    mode: 'all',
    shouldFocusError: true,
  })

  const getPersonList = async () => {
    try {
    } catch (error: any) {
      setServerError(`${error.message}`)
    }
    const personsFromApi = await axiosInstance.get(
      `/api/person/list?allCollaborators=true`,
    )
    const filteredPersonsFromApi = personsFromApi.data.persons.filter(
      (person: Person) => person.email !== user?.email,
    )
    setPersons(filteredPersonsFromApi)
  }

  useEffect(() => {
    getPersonList()
  }, [])

  const uploadFileHandler = async () => {
    try {
      const formData = new FormData()
      if (currentFiles) {
        formData.append('file', currentFiles[0])
        const responseFromFileServer = await axiosInstance.post(
          '/api/upload',
          formData,
        )

        if (responseFromFileServer && responseFromFileServer.status === 201) {
          setFileUploading(false)
          return responseFromFileServer?.data.responseData[0].fileName ?? ''
        } else {
          throw new Error(errorMessages.FAILED_TO_UPLOAD_ATTACHMENT)
        }
      }
    } catch (error) {
      const errorMessage =
        error instanceof AxiosError
          ? error.response?.data?.error
          : errorMessages.DEFAULT_ERROR

      setServerError(errorMessage)
    } finally {
      setCurrentFiles(null)
    }
  }


  const buddyRequestHandler: SubmitHandler<IBuddyProps> = async (payload) => {
    try {

      const fileName = await uploadFileHandler()

      const data = {
        recipients: payload.recipients,
        body: payload.message,
        isNote: false,
        isBuddyRequest: true,
        subject: `Bereitschaft zur Mitwirkung als Patin/Pate im Zeitraum von ${moment(
          (payload as IBuddyProps).fromDate,
        )} bis ${moment((payload as IBuddyProps).untilDate)}`,
        fromDate: payload.fromDate,
        untilDate: payload.untilDate,
        attachment: fileName ?? '',
      }

      const response = await axiosInstance.post(
        '/api/communication/employee/create',
        data,
      )

      if (response.status === 200) {
        setSuccessMessage(successMessages.successfullySentMail)
        handleClose()
        reset()
      }
    } catch (error) {
      setServerError(errorMessages.COULD_NOT_SEND_MESSAGE)
    }
  }

  return (
    <>
      <CustomModal open={open} onClose={handleClose}>
        <Box>
          <Typography
            variant="h6"
            component="h2"
            mb={10}
            sx={{ fontWeight: 700, fontSize: '28px', color: '#E40422' }}
          >
            {/* {replyToMail ? tScoped('Reply') : tScoped('New Message')} */}
            Buddy Request
          </Typography>

          <Box
            component="form"
            autoComplete="off"
            onSubmit={handleSubmit(buddyRequestHandler)}
          >
            <RHFAutocompleteField
              options={persons?.map((item) => {
                return {
                  id: item.personId,
                  label: {
                    firstName: item.firstName,
                    lastName: item.lastName || '',
                    email: item.email || '',
                    role: item.role || '',
                  },
                }
              })}
              name="recipients"
              required
              label={tScoped('Recipients')}
              control={control}
              multiple
            />

            <InputLabel>{tScoped('From')}</InputLabel>
            <CustomDatePicker
              name="fromDate"
              control={control}
              setValue={setValue}
              clearErrors={clearErrors}
              setError={setError}
              dateFormat="dd/MM/yyyy"
              allowPastDates
              clearable
            />

            <InputLabel>{tScoped('Until')}</InputLabel>
            <CustomDatePicker
              name="untilDate"
              control={control}
              setValue={setValue}
              clearErrors={clearErrors}
              setError={setError}
              dateFormat="dd/MM/yyyy"
              allowPastDates
              clearable
            />

            <Box sx={{ marginBottom: '20px' }}>
              <RHFTextArea
                label={tScoped('Message')}
                name="message"
                control={control}
              />
            </Box>

            <Grid container spacing={10} justifyContent="space-between">
                <Grid item>
                  <AddAttachment
                    labelText={tScoped('Attach Document')}
                    sx={{ marginBottom: '20px' }}
                    currentFiles={currentFiles}
                    fileUploading={fileUploading}
                    setCurrentFiles={setCurrentFiles}
                    multiple={false}
                  />
                </Grid>
              </Grid>

            <Grid container justifyContent="flex-end">
              <CustomButton
                label
                labelText={tScoped('Discard')}
                onClick={() => {
                  handleClose()
                  reset()
                }}
              />
              <CustomButton
                label
                labelText={tScoped('Send Buddy Request')}
                variant="contained"
                type="submit"
                sx={{ marginLeft: '20px' }}
              />
            </Grid>
          </Box>
        </Box>
      </CustomModal>

      {successMessage !== '' ? (
        <Toast message={successMessage} severity="success" />
      ) : null}

      {serverError !== '' ? (
        <Toast message={serverError} severity="error" />
      ) : null}
    </>
  )
}

export default BuddyRequest
