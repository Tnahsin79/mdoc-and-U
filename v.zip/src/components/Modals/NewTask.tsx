'use client'
import { Box, FormLabel, Grid, Typography } from '@mui/material'
import CustomModal from '../Modal'
import { RHFAutocompleteField } from '../DropDown'
import InputField from '../InputField'
import CustomDatePicker from '../DatePicker'
import { RHFTextArea } from '../TextArea'
import AddAttachment from '../Buttons/AddAttachment'
import CustomButton from '../Buttons/CustomButton'
import { useScopedI18n } from '../../../locales/client'
import { errorMessages } from '@/utils/errorMessages'
import { AxiosError, AxiosResponse } from 'axios'
import { ITask } from '@/interface/common'
import axiosInstance from '@/services/axiosInstance'
import { validationMessages } from '@/validators/messages'
import { useForm } from 'react-hook-form'
import { useContext, useEffect, useState } from 'react'
import { Role, TaskType } from '@prisma/client'
import Toast from '../Toast'
import { successMessages } from '@/utils/successMessages'
import { IMailData } from '@/interface/communication'
import { UserContext } from '@/contexts/userContext'

interface INewTaskProps {
  open: boolean
  handleClose: () => void
  selectedMessage: IMailData | null
  myEmail: string
}

const NewTask = ({
  open,
  handleClose,
  selectedMessage,
  myEmail,
}: INewTaskProps) => {
  const tScoped = useScopedI18n('dashboard')

  const { user } = useContext(UserContext)

  const [taskCreated, setTaskCreated] = useState<boolean>(false)
  const [serverError, setServerError] = useState<string>('')
  const [currentFiles, setCurrentFiles] = useState<FileList | null>(null)
  const [fileUploading, setFileUploading] = useState<boolean>(false)
  const [assignees, setAssignees] = useState<
    {
      id: number | string
      label:
        | string
        | {
            firstName: string
            lastName: string
            email: string
            role: Role
          }
    }[]
  >([])

  const getAssignee = async (email: string) => {
    try {
      const response = await axiosInstance.post(
        '/api/task/create-task-person',
        {
          email: email,
        },
      )

      if (response.status === 200) {
        setAssignees([
          {
            id: response.data.person.personId,
            label: {
              firstName: response.data.person.firstName,
              lastName: response.data.person.lastName || '',
              email: response.data.person.email || '',
              role: response.data.person.role || '',
            },
          },
          {
            id: response.data.ownDetail.personId,
            label: {
              firstName: response.data.ownDetail.firstName,
              lastName: response.data.ownDetail.lastName || '',
              email: response.data.ownDetail.email || '',
              role: response.data.ownDetail.role || '',
            },
          },

        ])
      }
      setValue('assignees', response.data.person.personId)
    } catch (error) {
      setServerError(`${error}`)
    }
  }

  const {
    control,
    handleSubmit,
    formState: { errors },
    setValue,
    clearErrors,
    reset,
    setError,
  } = useForm<ITask>({
    mode: 'all',
    defaultValues: {
      title: '',
      assignees: assignees.length > 0 ? [+assignees[0]?.id] : [],
      type: undefined,
      dueDate: undefined,
      note: '',
    },
    shouldFocusError: true,
  })

  useEffect(() => {
    if (myEmail === selectedMessage?.recipient.email) {
      getAssignee(selectedMessage?.sender?.email as string)
    } else if (myEmail === selectedMessage?.sender?.email) {
      getAssignee(selectedMessage?.recipient?.email as string)
    }
  }, [open])

  const createTaskHandler = async (payload: ITask) => {
    setTaskCreated(false)
    setServerError('')
    try {
      let response: AxiosResponse | null = null

      try {
        const formData = new FormData()
        if (currentFiles) {
          for (let i = 0; i < currentFiles.length; i++) {
            formData.append('file', currentFiles[i])
          }
          response = await axiosInstance.post('/api/upload', formData)

          if (response && response.status === 201) {
            setFileUploading(false)
          } else {
            throw new Error(errorMessages.FAILED_TO_UPLOAD_ATTACHMENT)
          }
        }
      } catch (error) {
        const errorMessage =
          error instanceof AxiosError
            ? error.response?.data?.error
            : errorMessages.DEFAULT_ERROR

        setServerError(errorMessage)
      }

      await axiosInstance.post('/api/task/create/', {
        ...payload,
        ownerId: user?.personId,
        assignees: [payload.assignees],
        attachments:
          response && Array.isArray(response.data.responseData)
            ? response.data.responseData.map(
                (file: { fileURLs: string; fileName: string }) => file.fileName,
              )
            : [],
      })
      setTaskCreated(true)
      setCurrentFiles(null)
      reset()
      handleClose()
    } catch (error) {
      const errorMessage =
        error instanceof AxiosError
          ? error.response?.data?.error
          : errorMessages.DEFAULT_ERROR

      setServerError(errorMessage)
    }
  }

  return (
    <>
      <CustomModal
        open={open}
        onClose={() => {
          reset()
          handleClose()
        }}
        sx={{ width: '800px' }}
      >
        <Box
          component="form"
          autoComplete="off"
          onSubmit={handleSubmit(createTaskHandler)}
        >
          <Typography variant="h2" mb={15}>
            {tScoped('Create New Task')}
          </Typography>

          <Grid container mb={10}>
            <Grid item xs={12}>
              <RHFAutocompleteField
                control={control}
                name="assignees"
                label={tScoped('Assignees')}
                options={assignees}
                required
              />
            </Grid>

            <Grid item xs={12}>
              <FormLabel>{tScoped('Type')}</FormLabel>
              <RHFAutocompleteField
                control={control}
                name="type"
                label=""
                options={Object.keys(TaskType).map((key) => ({
                  id: key,
                  label: key,
                }))}
                required
              />
            </Grid>

            <Grid item xs={12}>
              <InputField
                control={control}
                name="title"
                label={tScoped('Title')}
                fullWidth
                rules={{
                  required: {
                    value: true,
                    message: validationMessages.required,
                  },
                }}
                error={!!errors.title}
                helperText={errors.title?.message}
              />
            </Grid>

            <Grid item xs={12}>
              <FormLabel sx={{ display: 'block' }}>
                {tScoped('Due Date')}
              </FormLabel>
              <CustomDatePicker
                name="dueDate"
                label=""
                control={control}
                setValue={setValue}
                clearErrors={clearErrors}
                setError={setError}
                dateFormat="dd/MM/yyyy"
                required
              />
            </Grid>

            <Grid item xs={12}>
              <RHFTextArea
                name="note"
                label={tScoped('Note')}
                control={control}
              />
            </Grid>
          </Grid>

          <Grid container justifyContent="space-between" gap={10}>
            <Grid item xs={12}>
              <AddAttachment
                currentFiles={currentFiles}
                fileUploading={fileUploading}
                setCurrentFiles={setCurrentFiles}
                sx={{ marginBottom: '20px' }}
              />
            </Grid>
          </Grid>

          <Grid container justifyContent="flex-end" gap={10}>
            <CustomButton
              label={true}
              labelText={tScoped('Discard')}
              icon={false}
              onClick={handleClose}
            />
            <CustomButton
              label={true}
              labelText={tScoped('Create')}
              icon={false}
              variant="contained"
              type="submit"
            />
          </Grid>
        </Box>
      </CustomModal>
      {serverError !== '' ? (
        <Toast message={serverError} severity="error" />
      ) : null}

      {taskCreated ? (
        <Toast message={successMessages.taskCreated} severity="success" />
      ) : null}
    </>
  )
}

export default NewTask
