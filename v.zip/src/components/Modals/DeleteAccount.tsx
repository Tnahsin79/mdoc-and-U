import { Box, Grid, Typography } from '@mui/material'
import CustomModal from '../Modal'
import CustomButton from '../Buttons/CustomButton'
import { useI18n, useScopedI18n } from '../../../locales/client'

interface IDeleteAccount {
  open: boolean
  onClose: () => void
  onDelete: () => void
}

const DeleteAccount = ({ open, onClose, onDelete }: IDeleteAccount) => {
  const t = useI18n()
  const tScoped = useScopedI18n('delete')
  return (
    <CustomModal open={open} onClose={onClose}>
      <Typography
        variant="h6"
        component="h2"
        mb={10}
        sx={{ fontWeight: 700, fontSize: '28px', color: '#E40422' }}
      >
        {t('Delete Account')}
      </Typography>

      <Typography variant="h6" mb={10}>
        {tScoped(
          'This account is going to be deleted and the user will no longer be able to access this account.',
        )}
      </Typography>

      <Typography variant="h6" mb={10}>
        {tScoped('Note: Employees cannot retrieve this account later.')}
      </Typography>

      <Box>
        <Grid container spacing={10} justifyContent="center">
          <Grid item>
            <CustomButton
              label
              labelText={t('Cancel')}
              sx={{ minWidth: '200px' }}
              onClick={onClose}
            />
          </Grid>

          <Grid item>
            <CustomButton
              label
              labelText={t('Delete')}
              sx={{ minWidth: '200px' }}
              variant="contained"
              onClick={onDelete}
            />
          </Grid>
        </Grid>
      </Box>
    </CustomModal>
  )
}

export default DeleteAccount
