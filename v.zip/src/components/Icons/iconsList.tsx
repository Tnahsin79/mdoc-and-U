import Icon1 from './IconComponentsList/Icon1'
import Icon2 from './IconComponentsList/Icon2'
import Icon3 from './IconComponentsList/Icon3'
import Icon4 from './IconComponentsList/Icon4'
import Icon5 from './IconComponentsList/Icon5'
import Icon6 from './IconComponentsList/Icon6'
import Icon7 from './IconComponentsList/Icon7'
import Icon8 from './IconComponentsList/Icon8'
import Icon9 from './IconComponentsList/Icon9'
import Icon10 from './IconComponentsList/Icon10'
import Icon11 from './IconComponentsList/Icon11'
import Icon12 from './IconComponentsList/Icon12'
import Icon13 from './IconComponentsList/Icon13'
import Icon14 from './IconComponentsList/Icon14'
import Icon15 from './IconComponentsList/Icon15'
import Icon16 from './IconComponentsList/Icon16'
import Icon17 from './IconComponentsList/Icon17'
import Icon18 from './IconComponentsList/Icon18'
import Icon19 from './IconComponentsList/Icon19'
import ArrowRight from './IconComponentsList/ArrowRight'
import ArrowDown from './IconComponentsList/ArrowDown'
import Upload from './IconComponentsList/Upload'
import Download from './IconComponentsList/Download'
import Check from './IconComponentsList/Check'
import Compare from './IconComponentsList/Compare'
import Plus from './IconComponentsList/Plus'
import People from './IconComponentsList/People'
import Search from './IconComponentsList/Search'
import Attach from './IconComponentsList/Attach'
import FolderAdd from './IconComponentsList/FolderAdd'
import CheckboxChecked from './IconComponentsList/CheckboxChecked'
import CheckboxUnchecked from './IconComponentsList/CheckboxUnchecked'
import SwitchChecked from './IconComponentsList/SwitchChecked'
import SwitchUnchecked from './IconComponentsList/SwitchUnchecked'
import RadioChecked from './IconComponentsList/RadioChecked'
import RadioUnchecked from './IconComponentsList/RadioUnchecked'
import Bin2 from './IconComponentsList/Bin2'
import RedArrowDown from './IconComponentsList/RedArrowDown'
import PhasesOneChecked from './IconComponentsList/PhasesOneChecked'
import PhaseTwoUnchecked from './IconComponentsList/PhaseTwoUnchecked'
import PhaseThreeUnchecked from './IconComponentsList/PhaseThreeUnchecked'
import PhaseFourUnchecked from './IconComponentsList/PhaseFourUnchecked'
import SuccessToastIcon from './IconComponentsList/successToastIcon'
import InfoToastIcon from './IconComponentsList/infoToastIcon'
import ErrorToastIcon from './IconComponentsList/errorToastIcon'
import WarningToastIcon from './IconComponentsList/warningToastIcon'
import ArrowMatching from './IconComponentsList/ArrowMatching'
import Edit from './IconComponentsList/Edit'

import Save from './IconComponentsList/Save'
import RedArrowRight from './IconComponentsList/RedArrowRight'
import Print from './IconComponentsList/Print'
import RedFolder from './IconComponentsList/RedFolder'
import RedMessage from './IconComponentsList/RedMessage'
import RedDownload from './IconComponentsList/RedDownload'
import RedUpload from './IconComponentsList/RedUpload'
import Close from './IconComponentsList/Close'
import ArrowLeft from './IconComponentsList/ArrowLeft'
import Reload from './IconComponentsList/Reload'

import PauseCircleOutlineIcon from '@mui/icons-material/PauseCircleOutline';
import Attachment from './IconComponentsList/Attachment'
export interface iconProps {
  icon: keyof typeof icons
  onClick?: () => void
}

export type Icon = keyof typeof icons

export const icons = {
  Icon1: <Icon1 />,
  Icon2: <Icon2 />,
  Icon3: <Icon3 />,
  Icon4: <Icon4 />,
  Icon5: <Icon5 />,
  Icon6: <Icon6 />,
  Icon7: <Icon7 />,
  Icon8: <Icon8 />,
  Icon9: <Icon9 />,
  Icon10: <Icon10 />,
  Icon11: <Icon11 />,
  Icon12: <Icon12 />,
  Icon13: <Icon13 />,
  Icon14: <Icon14 />,
  Icon15: <Icon15 />,
  Icon16: <Icon16 />,
  Icon17: <Icon17 />,
  Icon18: <Icon18 />,
  Icon19: <Icon19 />,
  switchChecked: <SwitchChecked />,
  switchUnchecked: <SwitchUnchecked />,
  ArrowMatching: <ArrowMatching />,
  
  attachment: <Attachment />,

  // White Icons
  arrowRight: <ArrowRight />,
  arrowLeft: <ArrowLeft />,
  arrowDown: <ArrowDown />,
  upload: <Upload />,
  download: <Download />,
  check: <Check />,
  compare: <Compare />,
  plus: <Plus />,
  people: <People />,
  search: <Search />,
  attach: <Attach />,
  folderAdd: <FolderAdd />,
  checkboxChecked: <CheckboxChecked />,
  checkboxUnchecked: <CheckboxUnchecked />,
  radioChecked: <RadioChecked />,
  radioUnchecked: <RadioUnchecked />,
  bin2: <Bin2 />,
  redArrowDown: <RedArrowDown />,
  phasesOneChecked: <PhasesOneChecked />,
  phaseTwoUnchecked: <PhaseTwoUnchecked />,
  phaseThreeUnchecked: <PhaseThreeUnchecked />,
  phaseFourUnchecked: <PhaseFourUnchecked />,
  edit: <Edit />,
  reload: <Reload />,

  //Toast Icons
  successToast: <SuccessToastIcon />,
  infoToast: <InfoToastIcon />,
  errorToast: <ErrorToastIcon />,
  warningToast: <WarningToastIcon />,
  save: <Save />,
  print: <Print />,

  //Red Icons
  redArrowRight: <RedArrowRight />,
  redFolder: <RedFolder />,
  redMessage: <RedMessage />,
  redDownload: <RedDownload />,
  redUpload: <RedUpload />,
  close: <Close />,

  onLeave: <PauseCircleOutlineIcon fontSize='large'/>, 
}
