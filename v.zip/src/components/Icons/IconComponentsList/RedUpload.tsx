const RedUpload = () => {
  return (
    <>
      <svg
        width="27"
        height="28"
        viewBox="0 0 27 28"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <g clipPath="url(#clip0_295_4762)">
          <path
            d="M17.55 13.9611V22.0611H9.45V13.9611H2.7L13.5 3.16113L24.3 13.9611H17.55ZM0 24.7611H27V27.4611H0V24.7611Z"
            fill="#E40422"
          />
        </g>
        <defs>
          <clipPath id="clip0_295_4762">
            <rect
              width="27"
              height="27"
              fill="white"
              transform="translate(0 0.460938)"
            />
          </clipPath>
        </defs>
      </svg>
    </>
  )
}

export default RedUpload
