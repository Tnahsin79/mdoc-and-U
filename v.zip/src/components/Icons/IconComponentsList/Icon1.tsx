'use client'
const Icon1 = () => {
  return (
    <>
      <svg
        width="27"
        height="20"
        viewBox="0 0 27 20"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <g clipPath="url(#clip0_98_17)">
          <mask
            id="mask0_98_17"
            mask-type="luminance"
            maskUnits="userSpaceOnUse"
            x="0"
            y="0"
            width="27"
            height="20"
          >
            <path
              d="M26.2099 0.720001H0.609924V19.06H26.2099V0.720001Z"
              fill="white"
            />
          </mask>
          <g mask="url(#mask0_98_17)">
            <path
              d="M26.0599 1.77L25.1599 0.870001C24.9599 0.670001 24.6399 0.670001 24.4399 0.870001L9.24993 16.05C9.14993 16.15 8.98993 16.15 8.88993 16.05L2.38993 9.54C2.18993 9.34 1.86993 9.34 1.66993 9.54L0.769934 10.44C0.569934 10.64 0.569934 10.96 0.769934 11.16L8.35993 18.75C8.75993 19.15 9.40993 19.15 9.80993 18.75L26.0599 2.5C26.2599 2.3 26.2599 1.98 26.0599 1.78"
              fill="#1D1D1B"
            />
          </g>
        </g>
        <defs>
          <clipPath id="clip0_98_17">
            <rect
              width="25.6"
              height="18.34"
              fill="white"
              transform="translate(0.609924 0.720001)"
            />
          </clipPath>
        </defs>
      </svg>
    </>
  )
}

export default Icon1
