const SwitchChecked = () => {
  return (
    <svg
      width="46"
      height="24"
      viewBox="0 0 46 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <rect x="23" y="1.79317" width="22" height="21" fill="#E40422" />
      <rect x="0.5" y="1.29317" width="45" height="22" stroke="black" />
    </svg>
  )
}

export default SwitchChecked
