import { Box } from '@mui/material'

const InfoToastIcon = () => {
  return (
    <Box
      sx={{
        borderRadius: '50%',
        backgroundColor: '#5458F7',
        width: '77px',
        height: '77px',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
      }}
    >
      <svg
        width="49"
        height="49"
        viewBox="0 0 49 49"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          d="M24.2002 37.2618L24.2002 21.2685"
          stroke="white"
          strokeWidth="3.5"
          strokeLinecap="square"
          strokeLinejoin="round"
        />
        <path
          d="M24.2002 11.0248H24.2202"
          stroke="white"
          strokeWidth="3.5"
          strokeLinecap="square"
          strokeLinejoin="round"
        />
      </svg>
    </Box>
  )
}

export default InfoToastIcon
