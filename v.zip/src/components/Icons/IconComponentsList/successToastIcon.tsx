import { Box } from '@mui/material'

const SuccessToastIcon = () => {
  return (
    <>
      <Box
        sx={{
          borderRadius: '50%',
          backgroundColor: '#00cc99',
          width: '77px',
          height: '77px',
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
        }}
      >
        <svg
          width="49"
          height="49"
          viewBox="0 0 49 49"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            d="M40.4342 14.0879L20.022 34.5001L8.8418 23.3202"
            stroke="white"
            strokeWidth="3.5"
            strokeLinecap="square"
            strokeLinejoin="round"
          />
        </svg>
      </Box>
    </>
  )
}

export default SuccessToastIcon
