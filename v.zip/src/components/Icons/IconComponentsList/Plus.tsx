const Plus = () => {
  return (
    <>
      <svg
        width="24"
        height="25"
        viewBox="0 0 24 25"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          fillRule="evenodd"
          clipRule="evenodd"
          d="M22 14.4598H13.6667V22.7932H10.3333V14.4598H2V11.1265H10.3333V2.79318H13.6667V11.1265H22V14.4598Z"
          fill="white"
        />
      </svg>
    </>
  )
}

export default Plus
