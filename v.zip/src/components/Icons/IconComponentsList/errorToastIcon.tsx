import { Box } from '@mui/material'

const ErrorToastIcon = () => {
  return (
    <Box
      sx={{
        borderRadius: '50%',
        backgroundColor: '#E40422',
        width: '77px',
        height: '77px',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
      }}
    >
      <svg
        width="49"
        height="49"
        viewBox="0 0 49 49"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          d="M36.2002 12.5001L12.2002 36.5001"
          stroke="white"
          strokeWidth="3.5"
          strokeLinecap="square"
          strokeLinejoin="round"
        />
        <path
          d="M12.2002 12.5001L36.2002 36.5001"
          stroke="white"
          strokeWidth="3.5"
          strokeLinecap="square"
          strokeLinejoin="round"
        />
      </svg>
    </Box>
  )
}

export default ErrorToastIcon
