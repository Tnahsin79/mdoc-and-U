const CheckboxUnchecked = () => {
  return (
    <svg
      width="24"
      height="25"
      viewBox="0 0 24 25"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <rect x="0.5" y="1.29317" width="23" height="23" stroke="black" />
    </svg>
  )
}

export default CheckboxUnchecked
