const Download = () => {
  return (
    <>
      <svg
        width="24"
        height="25"
        viewBox="0 0 24 25"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          d="M8.85 13.8432L8.85 7.54317L15.15 7.54317L15.15 13.8432L20.4 13.8432L12 22.2432L3.6 13.8432L8.85 13.8432ZM22.5 5.44317L1.5 5.44317L1.5 3.34317L22.5 3.34317L22.5 5.44317Z"
          fill="white"
        />
      </svg>
    </>
  )
}

export default Download
