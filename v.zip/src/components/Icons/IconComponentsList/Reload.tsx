import * as React from 'react'
import { SVGProps } from 'react'

const Reload = (props: SVGProps<SVGSVGElement>) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width={24}
    height={25}
    viewBox="0 0 24 25"
    fill="none"
    {...props}
  >
    <path
      d="M18.78 6.18a9.6 9.6 0 1 0 2.1 10.38h-2.664a7.2 7.2 0 1 1-1.2-8.663L13.2 11.76h8.4v-8.4l-2.82 2.82Z"
      fill="#fff"
    />
  </svg>
)
export default Reload
