const FolderAdd = () => {
  return (
    <>
      <svg
        width="24"
        height="25"
        viewBox="0 0 24 25"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <g clipPath="url(#clip0_213_151)">
          <path
            d="M-1 4.99319C-1 3.56319 0.17 2.39319 1.6 2.39319H10.7L13.3 4.99319H22.4C23.8361 4.99319 25 6.15712 25 7.59319V20.5932C25 22.0293 23.8361 23.1932 22.4 23.1932H1.6C0.163933 23.1932 -1 22.0293 -1 20.5932V4.99319ZM1.6 7.59319V20.5932H22.4V7.59319H1.6ZM10.7 12.7932V10.1932H13.3V12.7932H15.9V15.3932H13.3V17.9932H10.7V15.3932H8.1V12.7932H10.7Z"
            fill="white"
          />
        </g>
        <defs>
          <clipPath id="clip0_213_151">
            <rect
              width="24"
              height="24"
              fill="white"
              transform="translate(0 24.7932) rotate(-90)"
            />
          </clipPath>
        </defs>
      </svg>
    </>
  )
}

export default FolderAdd
