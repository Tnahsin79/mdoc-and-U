const Compare = () => {
  return (
    <>
      <svg
        width="24"
        height="25"
        viewBox="0 0 24 25"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <g clipPath="url(#clip0_213_137)">
          <mask
            id="mask0_213_137"
            mask-type="luminance"
            maskUnits="userSpaceOnUse"
            x="-3"
            y="-3"
            width="30"
            height="31"
          >
            <path d="M-3 -2.20683H27V27.7932H-3V-2.20683Z" fill="white" />
          </mask>
          <g mask="url(#mask0_213_137)">
            <path
              d="M8.2625 15.2932H-0.5V17.7932H8.2625V21.5432L13.25 16.5432L8.2625 11.5432V15.2932ZM15.7375 14.0432V10.2932H24.5V7.79317H15.7375V4.04317L10.75 9.04317L15.7375 14.0432Z"
              fill="white"
            />
          </g>
        </g>
        <defs>
          <clipPath id="clip0_213_137">
            <rect
              width="24"
              height="24"
              fill="white"
              transform="translate(0 24.7932) rotate(-90)"
            />
          </clipPath>
        </defs>
      </svg>
    </>
  )
}

export default Compare
