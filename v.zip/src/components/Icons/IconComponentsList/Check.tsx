const Check = () => {
  return (
    <>
      <svg
        width="24"
        height="25"
        viewBox="0 0 24 25"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <g clipPath="url(#clip0_213_135)">
          <path
            d="M8.31182 21.032L0.836813 13.557C0.387729 13.1079 0.387729 12.3798 0.836813 11.9307L2.46312 10.3043C2.91221 9.85517 3.64039 9.85517 4.08947 10.3043L9.125 15.3398L19.9105 4.5543C20.3596 4.10521 21.0878 4.10521 21.5369 4.5543L23.1632 6.18065C23.6123 6.62973 23.6123 7.35787 23.1632 7.807L9.93817 21.0321C9.48905 21.4811 8.76091 21.4811 8.31182 21.032Z"
            fill="white"
          />
        </g>
        <defs>
          <clipPath id="clip0_213_135">
            <rect
              width="24"
              height="24"
              fill="white"
              transform="translate(0 24.7932) rotate(-90)"
            />
          </clipPath>
        </defs>
      </svg>
    </>
  )
}

export default Check
