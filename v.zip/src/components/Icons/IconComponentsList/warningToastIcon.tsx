import { Box } from '@mui/material'

const WarningToastIcon = () => {
  return (
    <>
      <Box
        sx={{
          borderRadius: '50%',
          backgroundColor: '#F2C94D',
          width: '77px',
          height: '77px',
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
        }}
      >
        <svg
          width="49"
          height="49"
          viewBox="0 0 49 49"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            d="M24.2197 10.5909L24.2197 26.5842"
            stroke="white"
            strokeWidth="3.5"
            strokeLinecap="square"
            strokeLinejoin="round"
          />
          <path
            d="M24.2197 36.8278L24.1997 36.8278"
            stroke="white"
            strokeWidth="3.5"
            strokeLinecap="square"
            strokeLinejoin="round"
          />
        </svg>
      </Box>
    </>
  )
}

export default WarningToastIcon
