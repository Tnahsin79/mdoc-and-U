const Close = () => {
  return (
    <>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="25"
        height="26"
        viewBox="0 0 25 26"
        fill="none"
      >
        <path
          d="M12.5 11.1932L3.6613 2.35449L1.8938 4.12199L10.7325 12.9607L1.8938 21.7995L3.6613 23.567L12.5 14.7282L21.3388 23.567L23.1063 21.7995L14.2675 12.9607L23.1063 4.12199L21.3388 2.35449L12.5 11.1932Z"
          fill="#E40422"
        />
      </svg>
    </>
  )
}
export default Close
