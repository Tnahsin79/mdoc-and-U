'use client'

const Upload = () => {
  return (
    <>
      <svg
        width="24"
        height="25"
        viewBox="0 0 24 25"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          d="M15.15 11.7432V18.0432H8.85V11.7432H3.6L12 3.34317L20.4 11.7432H15.15ZM1.5 20.1432H22.5V22.2432H1.5V20.1432Z"
          fill="white"
        />
      </svg>
    </>
  )
}

export default Upload
