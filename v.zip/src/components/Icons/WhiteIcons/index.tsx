import styled from '@emotion/styled'
import IconSwitcher from '../'
import { iconProps } from '../iconsList'

const StyledDiv = styled('div')({
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  backgroundColor: '#E40422',
  height: '44px',
  width: '44px',
  border: 'none',
})

const StyledIconSwitcher = styled(IconSwitcher)({})

const WhiteIconSwitcher = ({ icon }: iconProps) => {
  return (
    <StyledDiv>
      <StyledIconSwitcher icon={icon} />
    </StyledDiv>
  )
}

export default WhiteIconSwitcher
