import { iconProps, icons } from './iconsList'

const IconSwitcher = ({ icon }: iconProps) => {
  const SelectedIcon = icons[icon]

  return <>{SelectedIcon}</>
}

export default IconSwitcher
