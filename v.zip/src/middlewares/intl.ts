import { createI18nMiddleware } from 'next-international/middleware'
import {
  NextFetchEvent,
  NextMiddleware,
  NextRequest,
  NextResponse,
} from 'next/server'

const I18nMiddleware = createI18nMiddleware({
  locales: ['en', 'de'],
  defaultLocale: 'de',
  urlMappingStrategy: 'rewrite',
  resolveLocaleFromRequest: () => 'de',
})

export function withI18n(middleware: NextMiddleware): NextMiddleware {
  return async (request: NextRequest, event: NextFetchEvent) => {
    const response = I18nMiddleware(request)
    if (
      response instanceof NextResponse &&
      !request.nextUrl.pathname.includes('/api/') &&
      !request.nextUrl.pathname.includes('/de/') &&
      !request.nextUrl.pathname.includes('/assets/')
    ) {
      return response
    }
    return middleware(request, event)
  }
}
