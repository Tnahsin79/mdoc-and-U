const accessList: { [key: string]: { method: string; path: string }[] } = {
  Candidate: [
    { method: 'POST', path: '/api/candidate/getCandidateId' },
    { method: 'POST', path: '/api/attachment/get-attachment-link' },
    {
      method: 'GET',
      path: '/api/communication/assign',
    },
    {
      method: 'GET',
      path: '/api/room/seed-data',
    },
    {
      method: 'GET',
      path: '/api/get-emails',
    },
    {
      method: 'GET',
      path: '/history/[...segments]',
    },
    {
      method: 'POST',
      path: '/api/history',
    },
    {
      method: 'GET',
      path: '/assets/sample-file.csv',
    },
    {
      method: 'POST',
      path: '/api/auth/signout',
    },
    {
      method: 'POST',
      path: '/api/list',
    },
    //correctData
    {
      method: 'POST',
      path: '/api/candidate/correct-data/[candidateId]',
    },
    //person
    {
      method: 'POST',
      path: '/api/person/list',
    },
    {
      method: 'GET',
      path: '/api/person/list',
    },
    //communication
    {
      method: 'POST',
      path: '/api/communication/read',
    },
    {
      method: 'POST',
      path: '/api/communication/candidate/list',
    },
    {
      method: 'POST',
      path: '/api/communication/candidate/create',
    },
    {
      method: 'GET',
      path: '/communication-candidate',
    },
    // event
    {
      method: 'GET',
      path: '/api/event/get-candidates/[...segments]',
    },
    {
      method: 'GET',
      path: '/api/event/get-attendees',
    },
    {
      method: 'GET',
      path: '/api/event/get-collaborators',
    },
    {
      method: 'GET',
      path: '/event/create',
    },
    {
      method: 'POST',
      path: '/api/event/create',
    },
    {
      method: 'GET',
      path: '/event',
    },
    {
      method: 'POST',
      path: '/api/event/event-list',
    },
    {
      method: 'GET',
      path: '/event/edit/[...segments]',
    },
    {
      method: 'GET',
      path: '/api/event/[...segments]',
    },
    {
      method: 'POST',
      path: '/api/event/[...segments]',
    },
    {
      method: 'PUT',
      path: '/api/event/edit',
    },
    // Candidate
    {
      method: 'GET',
      path: '/candidate/dashboard',
    },
    {
      method: 'GET',
      path: '/candidate/candidate-data/[...segments]',
    },
    {
      method: 'PUT',
      path: '/api/candidate/deactivate-account',
    },
    {
      method: 'POST',
      path: '/api/candidate/candidate-list',
    },
    {
      method: 'GET',
      path: '/api/candidate/[...segments]',
    },
    {
      method: 'POST',
      path: '/api/candidate/[...segments]',
    },
    {
      method: 'POST',
      path: '/api/candidate/mass-import',
    },
    // upload
    {
      method: 'POST',
      path: '/api/upload',
    },
    // school
    {
      method: 'POST',
      path: '/api/school',
    },
    // Task
    {
      method: 'GET',
      path: '/task',
    },
    {
      method: 'GET',
      path: '/task/[...segments]',
    },
    {
      method: 'POST',
      path: '/api/task',
    },
    {
      method: 'POST',
      path: '/api/person/list',
    },
    {
      method: 'POST',
      path: '/api/task/assignees-list',
    },
    {
      method: 'GET',
      path: '/api/task/[...segments]',
    },
    {
      method: 'POST',
      path: '/api/task/create',
    },
    {
      method: 'PUT',
      path: '/api/task/[...segments]',
    },
    {
      method: 'POST',
      path: '/api/task/invalid-data',
    },
  ],
  Collaborator: [
    {method: 'POST', path: '/api/buddy-request'},
    {method: 'GET', path: '/api/buddy-request'},
    { method: 'POST', path: '/api/event/collaborator-update' },
    { method: 'GET', path: '/api/candidate/candidate-list' },
    { method: 'GET', path: '/api/room' },
    { method: 'POST', path: '/api/attachment/get-attachment-link' },
    {
      method: 'GET',
      path: '/api/communication/assign',
    },
    {
      method: 'GET',
      path: '/api/room/seed-data',
    },
    {
      method: 'GET',
      path: '/api/get-emails',
    },
    {
      method: 'GET',
      path: '/history/[...segments]',
    },
    {
      method: 'POST',
      path: '/api/history',
    },
    {
      method: 'GET',
      path: '/assets/sample-file.csv',
    },
    {
      method: 'POST',
      path: '/api/auth/signout',
    },
    {
      method: 'POST',
      path: '/api/task/create',
    },
    {
      method: 'POST',
      path: '/api/list',
    },
    //correctData
    {
      method: 'POST',
      path: '/api/collaborator/correct-data/[collaboratorId]',
    },
    //person
    {
      method: 'GET',
      path: '/api/person/list',
    },
    //communication
    {
      method: 'POST',
      path: '/api/communication/read',
    },
    {
      method: 'POST',
      path: '/api/communication/collaborator/list',
    },
    {
      method: 'POST',
      path: '/api/communication/collaborator/create',
    },
    {
      method: 'GET',
      path: '/communication-collaborator',
    },
    // event
    {
      method: 'GET',
      path: '/api/event/get-candidates/[...segments]',
    },

    {
      method: 'GET',
      path: '/api/event/get-attendees',
    },
    {
      method: 'GET',
      path: '/api/event/get-collaborators',
    },
    {
      method: 'GET',
      path: '/event/create',
    },
    {
      method: 'POST',
      path: '/api/event/create',
    },
    {
      method: 'GET',
      path: '/event',
    },
    {
      method: 'POST',
      path: '/api/event/event-list',
    },
    {
      method: 'GET',
      path: '/event/edit/[...segments]',
    },
    {
      method: 'GET',
      path: '/api/event/[...segments]',
    },
    {
      method: 'POST',
      path: '/api/event/[...segments]',
    },
    {
      method: 'PUT',
      path: '/api/event/edit',
    },
    // Collaborator
    {
      method: 'PUT',
      path: '/api/collaborator/deactivate-account',
    },
    {
      method: 'POST',
      path: '/api/collaborator/match-list',
    },
    {
      method: 'GET',
      path: '/collaborator/match-list/[...segments]',
    },
    {
      method: 'GET',
      path: '/collaborator',
    },
    {
      method: 'GET',
      path: '/collaborator/dashboard',
    },
    {
      method: 'GET',
      path: '/collaborator/collaborator-data/[...segments]',
    },
    {
      method: 'GET',
      path: '/api/collaborator/[...segments]',
    },
    {
      method: 'POST',
      path: '/api/collaborator/[...segments]',
    },
    {
      method: 'POST',
      path: '/api/school',
    },
    {
      method: 'POST',
      path: '/api/list/moduleList',
    },
    {
      method: 'POST',
      path: '/api/list/subjectAreaList',
    },
    {
      method: 'GET',
      path: '/api/list/seed-data/collaborator/add-collaborators',
    },
    {
      method: 'PUT',
      path: '/api/collaborator/event',
    },
    {
      method: 'POST',
      path: '/api/collaborator/event',
    },
    {
      method: 'DELETE',
      path: '/api/collaborator/event',
    },
    {
      method: 'GET',
      path: '/collaborator/confirm-participants/[...segments]',
    },
    // Contract
    {
      method: 'GET',
      path: '/contract',
    },
    {
      method: 'GET',
      path: '/contract/create',
    },
    {
      method: 'POST',
      path: '/api/contract/create',
    },
    {
      method: 'POST',
      path: '/api/contract/list',
    },
    // Invoice
    {
      method: 'GET',
      path: '/collaborator/invoices',
    },
    {
      method: 'GET',
      path: '/api/invoices',
    },
    {
      method: 'POST',
      path: '/api/invoices',
    },
    // Task
    {
      method: 'GET',
      path: '/task',
    },
    {
      method: 'GET',
      path: '/task/[...segments]',
    },
    {
      method: 'POST',
      path: '/api/task',
    },
    {
      method: 'POST',
      path: '/api/person/list',
    },
    {
      method: 'POST',
      path: '/api/task/assignees-list',
    },
    {
      method: 'GET',
      path: '/api/task/[...segments]',
    },
    {
      method: 'PUT',
      path: '/api/task/[...segments]',
    },
    // upload
    {
      method: 'POST',
      path: '/api/upload',
    },
    {
      method: 'GET',
      path: '/api/upload',
    },
    {
      method: 'POST',
      path: '/api/task/invalid-data',
    },
  ],
  Employee: [
    {
      method: 'POST',
      path: '/api/employees',
    },
    {
      method: 'POST',
      path: '/api/employees/employees/[...segments]',
    },
    {
      method: 'POST',
      path: '/api/attachment/get-attachment-link',
    },
    {
      method: 'GET',
      path: '/api/communication/assign',
    },
    {
      method: 'GET',
      path: '/api/room/seed-data',
    },
    {
      method: 'GET',
      path: '/api/get-emails',
    },
    {
      method: 'GET',
      path: '/history/[...segments]',
    },
    {
      method: 'POST',
      path: '/api/history',
    },
    {
      method: 'GET',
      path: '/assets/sample-file.csv',
    },
    {
      method: 'GET',
      path: '/dashboard',
    },
    //person
    {
      method: 'GET',
      path: '/api/person/list',
    },
    // communication
    {
      method: 'POST',
      path: '/api/communication/read',
    },
    {
      method: 'POST',
      path: '/api/communication/employee/list',
    },
    {
      method: 'POST',
      path: '/api/communication/employee/create',
    },
    {
      method: 'GET',
      path: '/communication-employee',
    },
    {
      method: 'GET',
      path: '/communication-employee/non-assigned-messages',
    },
    {
      method: 'POST',
      path: '/api/communication/employee/list',
    },
    {
      method: 'GET',
      path: '/api/person/list',
    },
    // privilege
    {
      method: 'GET',
      path: '/api/list/seed-data',
    },
    {
      method: 'POST',
      path: '/api/send-set-password-mail',
    },
    {
      method: 'POST',
      path: '/api/auth/signout',
    },
    {
      method: 'POST',
      path: '/api/list',
    },
    // event
    {
      method: 'GET',
      path: '/api/event/get-candidates/[...segments]',
    },

    {
      method: 'GET',
      path: '/api/event/get-attendees',
    },
    {
      method: 'GET',
      path: '/api/event/get-collaborators',
    },
    {
      method: 'GET',
      path: '/event/create',
    },
    {
      method: 'POST',
      path: '/api/event/create',
    },
    {
      method: 'GET',
      path: '/event',
    },
    {
      method: 'POST',
      path: '/api/event/event-list',
    },
    {
      method: 'GET',
      path: '/event/edit/[...segments]',
    },
    {
      method: 'GET',
      path: '/api/event/[...segments]',
    },
    {
      method: 'POST',
      path: '/api/event/[...segments]',
    },
    {
      method: 'PUT',
      path: '/api/event/edit',
    },
    // Collaborator
    {
      method: 'PUT',
      path: '/api/collaborator/deactivate-account',
    },
    {
      method: 'GET',
      path: '/collaborator',
    },
    {
      method: 'GET',
      path: '/collaborator/collaborator-list',
    },
    {
      method: 'GET',
      path: '/collaborator/create-collaborator',
    },
    {
      method: 'POST',
      path: '/api/collaborator/collaborator-list',
    },
    {
      method: 'GET',
      path: '/collaborator/collaborator-data/[...segments]',
    },
    {
      method: 'GET',
      path: '/api/collaborator/[...segments]',
    },
    {
      method: 'POST',
      path: '/api/collaborator/create',
    },
    // Candidate
    {
      method: 'GET',
      path: '/candidate',
    },
    {
      method: 'GET',
      path: '/candidate/dashboard',
    },
    {
      method: 'GET',
      path: '/candidate/mass-import',
    },
    {
      method: 'GET',
      path: '/candidate/candidate-data/[...segments]',
    },
    {
      method: 'PUT',
      path: '/api/candidate/deactivate-account',
    },
    {
      method: 'GET',
      path: '/candidate/create',
    },
    {
      method: 'POST',
      path: '/api/candidate/candidate-list',
    },
    {
      method: 'GET',
      path: '/api/candidate/[...segments]',
    },
    {
      method: 'POST',
      path: '/api/candidate/[...segments]',
    },
    {
      method: 'POST',
      path: '/api/candidate/mass-import',
    },
    {
      method: 'POST',
      path: '/api/candidate/create-candidate',
    },
    // School
    {
      method: 'GET',
      path: '/school',
    },
    {
      method: 'GET',
      path: '/school/create-school',
    },
    {
      method: 'GET',
      path: '/school/create-school',
    },
    {
      method: 'GET',
      path: '/school/edit/[...segments]',
    },
    {
      method: 'POST',
      path: '/api/school',
    },
    {
      method: 'POST',
      path: '/api/school/create',
    },
    {
      method: 'POST',
      path: '/api/school/[...segments]',
    },
    {
      method: 'GET',
      path: '/api/school/[...segments]',
    },
    // Mentor
    {
      method: 'GET',
      path: '/candidate/match-mentors',
    },
    {
      method: 'POST',
      path: '/api/match-mentors',
    },
    {
      method: 'PUT',
      path: '/api/match-mentors',
    },
    {
      method: 'GET',
      path: '/api/match-mentors/[...segments]',
    },
    {
      method: 'POST',
      path: '/api/match-mentors/auto-match/[...segments]',
    },
    {
      method: 'GET',
      path: '/api/list/seed-data/collaborator/add-collaborators',
    },
    // invoices
    {
      method: 'GET',
      path: '/collaborator/invoices',
    },
    {
      method: 'GET',
      path: '/api/invoices',
    },
    // Task
    {
      method: 'GET',
      path: '/task',
    },
    {
      method: 'GET',
      path: '/task/[...segments]',
    },
    {
      method: 'GET',
      path: '/api/task',
    },
    {
      method: 'POST',
      path: '/api/task',
    },
    {
      method: 'GET',
      path: '/api/task/[...segments]',
    },
    {
      method: 'PUT',
      path: '/api/task/[...segments]',
    },
    {
      method: 'GET',
      path: '/api/person/list',
    },
    {
      method: 'POST',
      path: '/api/task/assignees-list',
    },
    // upload
    {
      method: 'POST',
      path: '/api/upload',
    },
  ],
}

export { accessList }
