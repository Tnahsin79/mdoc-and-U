import jwt from 'jsonwebtoken'
import { NextFetchEvent, NextMiddleware, NextResponse } from 'next/server'
import { Role } from '@prisma/client'

import { errorMessages } from '@/utils/errorMessages'
import { NextRequest } from 'next/server'
import { unprotectedApiRoutes } from '@/utils/constants/backend'
import { unprotectedFrontendRoutes } from '@/utils/constants/frontend'
import { accessList } from './accessList'

export function withACL(middleware: NextMiddleware) {
  return async (request: NextRequest, event: NextFetchEvent) => {
    const { url, method, headers } = request
    const pathname = new URL(url).pathname

    const accessToken = request.cookies.get('accessToken')?.value || ''

    const decoded = jwt.decode(accessToken) as jwt.JwtPayload
    const role = decoded?.role

    const skipRoute =
      unprotectedApiRoutes.includes(pathname) ||
      unprotectedFrontendRoutes.includes(pathname)

    const isAllowed = accessList[role]?.some((item) => {
      if (item.path === pathname && item.method === method) {
        return true
      }
      if (item.path.endsWith('/[...segments]') && item.method === method) {
        const dynamicPath = item.path.replace('[...segments]', '')
        return pathname.startsWith(dynamicPath)
      }
      return false
    })
    if (isAllowed || skipRoute || role === 'Employee') {
      return middleware(request, event)
    } else if (pathname.includes('api')) {
      return NextResponse.json(
        {
          error: errorMessages.INSUFFICIENT_PERMISSION,
        },
        { status: 401 },
      )
    } else {
      const protocol = headers.get('x-forwarded-proto') || 'http'
      const host = headers.get('host')
      const baseURL = `${protocol}://${host}`
      const redirectURL = `${protocol}://${host}/dashboard`
      if (url === redirectURL) {
        return new Response('', {
          status: 302,
          headers: {
            Location:
              role === Role.Candidate
                ? `${baseURL}/candidate/dashboard`
                : `${baseURL}/collaborator/dashboard`,
          },
        })
      }
    }
  }
}
