import jwt from 'jsonwebtoken'

import { errorMessages } from '@/utils/errorMessages'
import {
  NextResponse,
  type NextFetchEvent,
  type NextMiddleware,
  type NextRequest,
} from 'next/server'
import { unprotectedApiRoutes } from '@/utils/constants/backend'
import { unprotectedFrontendRoutes } from '@/utils/constants/frontend'

export function withAuth(middleware: NextMiddleware) {
  return async (request: NextRequest, event: NextFetchEvent) => {
    const { url, headers } = request
    const protocol = headers.get('x-forwarded-proto') || 'http'
    const host = headers.get('host')
    const baseURL = `${protocol}://${host}`
    const pathname = new URL(url).pathname

    if (
      unprotectedFrontendRoutes.includes(pathname) ||
      unprotectedApiRoutes.includes(pathname)
    ) {
      return middleware(request, event)
    }

    const accessToken = request.cookies.get('accessToken')?.value
    if (!accessToken) {
      return new Response('', {
        status: 302,
        headers: {
          Location: `${baseURL}/login`,
        },
      })
    }

    const decoded = jwt.decode(accessToken) as jwt.JwtPayload

    try {
      if (
        !decoded ||
        typeof decoded === 'string' ||
        !(typeof decoded === 'object' && 'exp' in decoded)
      ) {
        throw new Error(errorMessages.INVALID_TOKEN)
      }

      const currentTimestamp = Math.floor(Date.now() / 1000)

      if (decoded.exp && decoded.exp <= currentTimestamp) {
        throw new Error(errorMessages.INVALID_TOKEN)
      } else {
        return middleware(request, event)
      }
    } catch (error) {
      if (pathname.includes('api')) {
        return NextResponse.json(
          {
            error: errorMessages.UNAUTHORIZED,
          },
          { status: 401 },
        )
      } else {
        const redirectURL = `${protocol}://${host}/login`
        return new Response('', {
          status: 302,
          headers: {
            Location: redirectURL,
          },
        })
      }
    }
  }
}
