export type ICreateEventRequestBody = {
  templateId?: number
  subjectAreaId: number
  subjectModule: string
  eventTypeId: number
  phaseId: number
  title: string
  minParticipants: number
  maxParticipants: number
  description: string
  eventManner: string
  accessLink?: string
  eventStatus: number
  reason?: string | null
  bookedFrom: string
  bookedTo?: string
  startTime: string
  endTime: string
  eventRepeatId?: number | null
  lmsLink?: string
  locationId?: number | null
  barrierFreeAccess?: boolean | null
  suitableRoomId?: number | null
  equipmentId: number[]
  suitableCollaboratorId: number
  attendeesId: string[]
  eventKey: string
}

export type IEditEventRequestBody = ICreateEventRequestBody & {
  eventId: number
}

export interface ICreateEventPage {
  templateId: string
  subjectAreaId: number
  subjectModule: string
  phaseId: number | string
  eventTypeId: number
  title: string
  minParticipants: number
  maxParticipants: number
  lmsLink: string
  description: string
  reason?: string
  isEventRepeats: boolean
  startTime: Date | undefined
  endTime: Date | undefined
  bookedFrom: Date | undefined
  bookedTo: Date | undefined
  eventAccessMethod: string
  accessLink: string
  eventRepeats: string
  eventManner: string
  eventStatus: string
  equipmentId: string[]
  excludeBerlinHolidays?: boolean
  locationId: string
  suitableRoomId: string
  suitableCollaboratorId: number
  eventRepeatId?: number | string | null
  attendeesId: string[]
  eventKey: string
  barrierFreeAccess: boolean | null
}

export interface IEditEventPage {
  templateId: number
  subjectAreaId: number
  subjectModule: string
  phaseId: string | number
  eventTypeId: number
  title: string
  minParticipants: string
  maxParticipants: string
  lmsLink: string
  description: string
  reason?: string
  isEventRepeats: boolean
  startTime: Date | undefined
  endTime: Date | undefined
  bookedFrom: Date | undefined
  bookedTo: Date | undefined
  eventAccessMethod: string
  accessLink?: string | null
  eventRepeatId?: number | string | null
  eventManner: string
  eventStatus: string | null
  equipmentId: string[] | number[]
  excludeBerlinHolidays?: boolean
  locationId?: number | null
  suitableRoomId: string | number | null
  suitableCollaboratorId: number
  attendeesId: string[]
  barrierFreeAccess: boolean | null
  eventKey: string
}
export interface IListValueMap {
  template: string[]
  subjectArea: string[]
  eventType: string[]
  location: string[]
  equipment: string[]
  suitableRooms: string[]
  suitableCollaborators: string[]
  attendees: string[]
  schoolType: string[]
  teachingPosition: string[]
  longerAbsenceReason: string[]
  yearGroup: string[]
  subject: string[]
  title: string[]
  person: string[]
  appellation: string[]
  gender: string[]
  phase: string[]
  eventStatus: string[]
  eventRepeats: string[]
  kickOffGroup: string[]
  firstRecognisedSubject: string[]
  secondRecognisedSubject: string[]
  thirdRecognisedSubject: string[]
  firstSubjectToBeStudied: string[]
  secondSubjectToBeStudied: string[]
  subjectChangeFrom: string[]
  subjectChangeTo: string[]
  contractType: string[]
  jobTitle: string[]
  collaboratorSchoolRole: string[]
  studiesGroupSubjectA: string[]
  studiesGroupSubjectB: string[]
  businessType: string[]
  startSubjectA: string[]
  startSubjectB: string[]
  yesOrNo: string[]
}
