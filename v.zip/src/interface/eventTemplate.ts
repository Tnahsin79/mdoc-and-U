import { CollaboratorOrigin } from '@prisma/client'

export type ICreateEventTemplateRequestBody = {
  templateName: string
  subjectAreaId?: number
  subjectModule?: string
  eventTypeId?: number
  phaseId?: number
  minParticipants?: number
  maxParticipants?: number
  description?: string
  collaboratorOrigin?: CollaboratorOrigin
  eventKey?: string
}

export type IEditEventTemplateRequestBody = ICreateEventTemplateRequestBody & {
  templateId: number
}

export interface ICreateEditEventTemplatePage {
  templateName: string
  subjectAreaId?: number
  subjectModule?: string
  eventTypeId?: number
  phaseId?: number
  minParticipants?: number
  maxParticipants?: number
  description?: string
  collaboratorOrigin?: CollaboratorOrigin
  eventKey?: string
  eventDuration?: string
}
