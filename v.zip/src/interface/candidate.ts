export interface IMassImportCandidate {
  Appellation: number
  Title?: number
  'First name': string
  'Last name': string
  personId: number
  'Street and House No': string
  City: string
  'Postal code': bigint
  'Phone number': bigint
  Email: string
  'Longer absence reason'?: number
  'From date'?: string
  'Until date'?: string
  School: string
  'Start school year': string
  'Year group'?: number
  'KickOff group?': number
  'Start of contract': number
  'Teaching position': number
  'First recognised subject': number
  'Second recognised subject'?: number
  'Third recognised subject'?: number
  'First subject to be studied'?: number
  'Second subject to be studied'?: number
  'Subject change from'?: number
  'Subject change to'?: number
  Comments?: string
  phaseRequiredId: number
  'Kick-Off': boolean
  'First-Steps': boolean
  'Set-Up': boolean
  Studies: boolean
  'bbVD-start'?: any
}
