import { Role } from '@prisma/client'

export type PersonCreateInput = {
  email: string
  firstName: string
  password: string
  role: Role
  subjectAdmin: boolean
  subjectSupervision: boolean
  householdAdmin: boolean
  departmentLead: boolean
}

export interface IPersonValues {
  Employee: {
    email: string
    firstName: string
    password: string
  }
  Collaborator: {
    email: string
    firstName: string
    password: string
  }
  Candidate: {
    email: string
    firstName: string
    password: string
  }
}
