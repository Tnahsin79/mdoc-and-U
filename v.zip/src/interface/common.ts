import { createSchoolInterface } from '@/app/[locale]/school/create-school/page'
import { Person, Role, Task } from '@prisma/client'

export interface IListItem {
  listId: number
  listType: string
  listValue: string
  isActive: boolean
}

export type IList = IListItem[]
export interface OptionInterface {
  id: string | number
  label:
    | string
    | {
        firstName: string
        lastName: string
        email: string
        role: Role
      }
}

export interface PersonOption {
  id: number
  person: Pick<Person, 'firstName' | 'lastName' | 'email' | 'role'>
}

export interface ISchoolInterface extends createSchoolInterface {
  schoolId: number
}

export type AlertColor = 'success' | 'info' | 'warning' | 'error'

export interface ICollaborator {
  collaboratorId: number
  person: {
    personId: number
    firstName: string
    lastName: string
    isActive: boolean
    email: string
    phoneNumber: string
  }
  phasePreferenceId?: number
  pinNo: number
  schoolTypeId: number
  collaboratorSchoolRole: string
  jobTitle: number
  onClick?: () => void
}

export type ICollaboratorList = ICollaborator[]

export interface ICollaboratorPerson {
  personId: number
  firstName: string
  lastName: string
}

export type ICollaboratorPersonList = ICollaboratorPerson[]

export interface IContractDetail {
  contractDetailId: number
  contractId: number
  positionTitle: string
  duration: number
  hourlyFee: number
  phaseId: number
  billFrom: Date
  billTo: Date
}

export interface IPosition {
  contractId: number
  personId: number
  contractTypeId: number
  contractDetail: IContractDetail[]
}

export interface IToastData {
  type: 'success' | 'info' | 'warning' | 'error' | undefined
  message: string
}

export type Operator =
  | 'equals'
  | 'in'
  | 'notIn'
  | 'lt'
  | 'lte'
  | 'gt'
  | 'gte'
  | 'not'
  | 'contains'
  | 'startsWith'
  | 'endsWith'

export interface Condition {
  [key: string]:
    | { [key in Operator]?: string | Date | boolean | number[] | number }
    | boolean
}

export interface Query {
  AND: Condition[]
}

export interface QueryConditions {
  OR?: {
    AND?: {
      startTime?: {
        lte?: Date;
        lt?: Date;
        gte?: Date;
      };
      endTime?: {
        gt?: Date;
        gte?: Date;
        lt?: Date;
        lte?: Date;
      };
    }[];
  }[];
} 

export interface IContractPositionState {
  contractDetailId: number
  positionTitle: string
  billFrom: Date
  billTo: Date
  hourlyFee: number
  duration: number
  phaseId: number
  contractDetail: IContractDetail[]
}

export interface ITask extends Omit<Task, 'task_id' | 'attachment'> {
  assignees: ('All Collaborator' | 'All Candidate' | number)[]
  attachments: {
    url: string
    fileName: string
    attachment: string
  }[]
  creator: {
    firstName: string
    lastName: string
  }
}
