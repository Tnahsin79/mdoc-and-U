export interface IListValueMap {
  role: string[]
  federalState: string[]
  berlinSchool: string[]
  jobTitle: string[]
}
