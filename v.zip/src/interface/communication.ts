import { BuddyRequest, Communication } from '@prisma/client'

export interface IMailData extends Communication {
  sender: ICommunicationPerson | null
  recipient: ICommunicationPerson
  buddyRequest: Pick<BuddyRequest, 'availableId' | 'howFarDistance' | 'howManyToSupport' | 'schoolTypesIds' | 'isSubmitted'> | null 
}

interface ICommunicationPerson {
  email: string
  firstName: string
  lastName: string | null
}

export interface IModalData {
  type: string
  open: boolean
}

export interface Checked {
  received: boolean
  sent: boolean
  new: boolean
}

export interface EmployeeNewMessageForm {
  recipients: (number | string)[] | any
  topic: string
  message: string
  template: number
}

export interface CollaboratorNewMessageForm {
  recipients: (number | string)[] | any
  reference: string
  message: string
}

export interface CandidateNewMessageForm {
  recipient: number
  subject: string
  message: string
}
