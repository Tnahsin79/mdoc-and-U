'use client'
import { createTheme, ThemeOptions } from '@mui/material/styles'
import { NextFont } from 'next/dist/compiled/@next/font'
import localFont from 'next/font/local'

const BerlinTypeOffice: NextFont = localFont({
  src: [
    {
      path: '../../public/fonts/Office/BerlinTypeOffice-Regular.ttf',
      weight: '400',
    },
    {
      path: '../../public/fonts/Office/BerlinTypeOffice-Bold.ttf',
      weight: '700',
    },
  ],
})

const themeOptions: ThemeOptions = {
  palette: {
    primary: {
      main: '#e40422',
    },
    secondary: {
      main: '#000',
    },
    text: {
      primary: '#000',
    },
    common: {
      white: '#fff',
    },
  },

  shape: {
    borderRadius: 0,
  },

  spacing: 2,

  components: {
    MuiFormControl: {
      styleOverrides: {
        root: {
          marginBottom: '20px',
        },
      },
    },

    MuiInputBase: {
      styleOverrides: {
        root: {
          height: '44px',
          background: '#fff',

          '& .MuiInputBase-input.MuiOutlinedInput-input': {
            padding: '9.5px 14px',
          },

          '& fieldset': {
            borderColor: '#000',
          },

          '&.Mui-focused fieldset.MuiOutlinedInput-notchedOutline': {
            borderColor: 'grey',
          },
        },
      },
    },

    MuiFormLabel: {
      styleOverrides: {
        root: {
          color: '#000',
          marginBottom: '10px',
        },
      },
    },

    MuiFormHelperText: {
      styleOverrides: {
        root: {
          marginLeft: '0',
        },
      },
    },

    MuiCheckbox: {
      styleOverrides: {
        root: {
          color: '#000',
        },
      },
    },

    MuiAutocomplete: {
      styleOverrides: {
        paper: {
          boxShadow: '3px 4px 4px 3px rgba(0, 0, 0, 0.15)',
        },

        listbox: {
          padding: '13px 15px',
          '& .MuiAutocomplete-option': {
            borderBottom: '1px solid #D1D1D1',
            padding: '15px 0 ',
          },
        },

        root: {
          '& .MuiInputBase-root.MuiOutlinedInput-root': {
            padding: '0px 44px 0px 0px',
            '& .MuiInputBase-input': {
              minWidth: '50px',
              width: 'unset',
              flex: 1,
            },

            '& .MuiAutocomplete-tag': {
              background: '#FBDBD4',
              color: '#000',
              height: '33px',
              gap: '10px',

              '& .MuiChip-deleteIcon': {
                color: '#E40422',
              },
            },
            '& .MuiAutocomplete-endAdornment': {
              borderLeft: '1px solid #000 !important',
              borderBottom: '1px solid #000 !important',
              height: '44px',
              '& .MuiAutocomplete-clearIndicator ': {
                position: 'absolute',
                right: '44px',
                background: 'transparent',
              },
            },
          },
          '&.Mui-focused fieldset.MuiOutlinedInput-notchedOutline': {
            border: '1px solid #000',
          },
        },
      },
    },

    MuiButton: {
      styleOverrides: {
        root: {
          height: '44px',
          textTransform: 'none',
          fontSize: '16px',
          fontWeight: '700',
          justifyContent: 'center',
          color: '#fff',
          minWidth: '79px',

          '& .MuiButton-endIcon': {
            height: '44px',
            width: '44px',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            background: '#E40422',
            margin: 0,
            position: 'absolute',
            right: '-1px',
            border: '1px solid #000',
          },
        },

        outlined: {
          padding: '0.7rem 1.5rem',
          borderColor: '#E40422',
          backgroundColor: '#FFFFFF',
          color: '#000',

          '&:hover': {
            background: '#FBDBD4',
            borderColor: '#E40422',
            '& .MuiButton-endIcon': {
              background: '#FE182A',
            },
          },

          '&:focus': {
            borderColor: '#FBDBD4',
            background: '#FBDBD4',
            '& .MuiButton-endIcon': {
              background: '#BC031A',
              borderColor: '#BC031A',
            },
          },

          '&.Mui-disabled': {
            color: '#FDB3A6',

            '& .MuiButton-endIcon': {
              background: '#FDB3A6',
              borderColor: '#FDB3A6',
            },
          },
        },

        contained: {
          padding: '0.7rem 1.5rem',

          '&:hover': {
            background: '#FE182A',
            borderColor: '#FE182A',
          },

          '&:focus': {
            borderColor: '#BC031A',
            background: '#BC031A',
          },

          '&.Mui-disabled': {
            color: '#FDB3A6',
            background: '#FBDBD4',
            borderColor: '#FBDBD4',
          },
        },

        text: {
          height: 'unset',
          padding: '0px',
          lineHeight: 'normal',
          '&:hover': {
            border: 'none',
            background: 'none',
            color: '#E40422',
          },
        },

        outlinedSizeSmall: {
          height: 'unset',
          border: 'none',
          padding: '0px',
          color: '#000',
          fontSize: '15px',
          fontWeight: '400',
          minWidth: 'unset',

          '&:hover': {
            border: 'none',
            background: 'none',
            color: '#E40422',
          },
        },
      },
    },

    MuiIconButton: {
      styleOverrides: {
        root: {
          height: '44px',
          width: '44px',
          background: '#E40422',
          borderRadius: '0px',

          '&:hover': {
            background: '#FE182A',
          },

          '&:focus': {
            background: '#BC031A',
          },

          '&.Mui-disabled': {
            background: '#FDB3A6',
          },
        },
      },
    },

    MuiListItem: {
      styleOverrides: {
        root: {
          fontSize: '16px',
          fontWeight: '400',
        },
      },
    },

    MuiTable: {
      styleOverrides: {
        root: {
          borderCollapse: 'separate',
          borderSpacing: ' 0 7px',
          '& .MuiTypography-h4': {
            fontSize: '16px',
            fontWeight: '700',
            color: '#E40422',
          },

          '& .MuiTypography-h5': {
            fontSize: '20px',
            fontWeight: '700',
            color: '#000',
          },

          '& .MuiTypography-h6': {
            fontSize: '16px',
            fontWeight: '400',
            color: '#000',
          },
        },
      },
    },

    MuiTableRow: {
      styleOverrides: {
        root: {
          height: '72px',
          background: '#fff',
        },
      },
    },

    MuiTableCell: {
      styleOverrides: {
        root: {
          borderTop: '1px solid #000 ',
          borderBottom: '1px solid #000 ',
          padding: '10px 20px',

          '&:last-child': {
            borderRight: '1px solid #000 ',
            paddingRight: '15px',
          },

          '&:first-child': {
            borderLeft: '1px solid #000 ',
            paddingLeft: '15px',
          },
        },
      },
    },

    MuiChip: {
      styleOverrides: {
        root: {
          borderRadius: '0px',
          fontSize: '16px',
          fontWeight: '700',
          color: '#fff',
          padding: '5px 10px',
          width: 'fit-content',

          '& .MuiChip-label': {
            padding: '0px',
            lineHeight: 'normal',
          },
        },
      },
    },

    MuiSwitch: {
      styleOverrides: {
        root: {
          padding: '0',
          marginRight: '12px',
          height: '24px',
          width: '47px',
          border: '1px solid #000',
          '& .MuiButtonBase-root': {
            padding: '0',
            '& .MuiSwitch-thumb': {
              borderRadius: 0,
              height: '23px',
              width: '23px',
              backgroundColor: '#999999',
            },

            '&.Mui-checked': {
              transform: 'translateX(23px)',
              '& .MuiSwitch-thumb': {
                backgroundColor: '#e40422',
              },

              '+.MuiSwitch-track': {
                backgroundColor: '#fff',
                opacity: 1,
              },
            },
          },
          '& .MuiSwitch-track': {
            borderRadius: 0,
            backgroundColor: '#fff',
            opacity: 1,
          },
        },
      },
    },

    MuiSnackbar: {
      styleOverrides: {
        root: {
          padding: 0,
          width: '536px',
          height: '127px',
          boxSizing: 'border-box',
          paddingy: '40px',
          paddingx: '25px',
          '& .MuiAlert-icon': {
            marginRight: '30px',
          },
          '& .MuiAlert-action': {
            height: '100%',
            display: 'flex',
            alignItems: 'flex-start',
          },
        },
      },
    },

    MuiPagination: {
      styleOverrides: {
        root: {
          display: 'flex',
          justifyContent: 'center',

          '& .MuiPagination-ul': {
            border: '1px solid #000',
            '& li': {
              borderRight: '1px solid #000',
              '&:last-child': {
                borderRight: 'none',
              },
              '& button': {
                margin: 0,
                minHeight: '44px',
                minWidth: '44px',
                padding: '11px 20px',
                color: '#000',
                fontFamily: BerlinTypeOffice.style.fontFamily,
                fontSize: '16px',
                fontWeight: '700',

                '&.Mui-selected': {
                  color: '#E40422',
                  background: 'none',
                },

                '&.MuiPaginationItem-previousNext': {
                  background: '#E40422',
                  padding: 0,
                },
              },
            },
          },
        },
      },
    },
  },

  typography: {
    h1: {
      color: '#495057',
      fontSize: '48px',
      fontWeight: '700',
      marginBottom: '50px',
    },

    h2: {
      color: '#E40422',
      fontSize: '28px',
      fontWeight: '700',
      marginBottom: '30px',
    },

    h3: {
      color: '#000',
      fontSize: '20px',
      fontWeight: '700',
    },

    h6: {
      fontSize: '16px',
      fontWeight: '700',
      color: '#000',
    },

    subtitle1: {
      color: '#495057',
      fontSize: '20px',
      fontWeight: '700',
    },

    fontFamily: BerlinTypeOffice.style.fontFamily,
  },
}

const theme = createTheme(themeOptions)

export default theme
