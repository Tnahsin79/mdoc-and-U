import TasksComponent from '@/components/Tasks'

const Tasks = () => {
  return <TasksComponent />
}

export default Tasks
