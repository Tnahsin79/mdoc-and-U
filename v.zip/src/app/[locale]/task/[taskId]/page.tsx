'use client'
import moment from 'moment'
import Toast from '@/components/Toast'
import CustomModal from '@/components/Modal'
import IconSwitcher from '@/components/Icons'
import InputField from '@/components/InputField'
import axiosInstance from '@/services/axiosInstance'
import CustomDatePicker from '@/components/DatePicker'
import CustomButton from '@/components/Buttons/CustomButton'
import ContractViewPopup from '@/components/ContractViewPopup'
import AddAttachment from '@/components/Buttons/AddAttachment'

import { AxiosError } from 'axios'
import { ITask } from '@/interface/common'
import { RHFTextArea } from '@/components/TextArea'
import { errorMessages } from '@/utils/errorMessages'
import { useParams, useRouter } from 'next/navigation'
import { IModalData } from '@/interface/communication'
import { Person, Role, TaskType } from '@prisma/client'
import { successMessages } from '@/utils/successMessages'
import { validationMessages } from '@/validators/messages'
import { FC, useContext, useEffect, useState } from 'react'
import { RHFAutocompleteField } from '@/components/DropDown'
import {
  Box,
  Grid,
  Typography,
  Chip as MUIChip,
  FormLabel,
} from '@mui/material'
import { useForm } from 'react-hook-form'
import { UserContext } from '@/contexts/userContext'
import { useScopedI18n } from '../../../../../locales/client'
import { specialAssigneesList } from '@/utils/constants/common'

const Chip: FC<{ type?: TaskType; done?: boolean }> = ({ type }) => {
  const tScoped = useScopedI18n('dashboard')
  if (type === TaskType.Document) {
    return (
      <MUIChip label={tScoped('Document')} sx={{ background: '#0443E4' }} />
    )
  } else if (type === TaskType.Event) {
    return <MUIChip label={tScoped('Event')} sx={{ background: '#009231' }} />
  } else if (type === TaskType.Message) {
    return <MUIChip label={tScoped('Message')} sx={{ background: '#DB7600' }} />
  } else if (type === TaskType.Data) {
    return <MUIChip label={tScoped('Data')} sx={{ background: '#999999' }} />
  } else {
    return (
      <MUIChip label={type ?? tScoped('Done')} sx={{ background: '#009231' }} />
    )
  }
}

const TaskDetails = () => {
  const tScoped = useScopedI18n('dashboard')
  const router = useRouter()
  const { taskId }: { taskId: string } = useParams()
  const [task, setTask] = useState<ITask | null>(null)
  const [openModal, setOpenModal] = useState<boolean>(false)
  const [serverError, setServerError] = useState<string>('')
  const [taskUpdated, setTaskUpdated] = useState<boolean>(false)

  const [modalData, setModalData] = useState<IModalData>({
    open: false,
    type: '',
  })
  const handleClose = () => {
    setModalData({ type: '', open: false })
  }

  const [assignees, setAssignees] = useState<
    { id: number | string; label: string }[]
  >([])

  const [fileUploading] = useState<boolean>(false)
  const [currentFiles, setCurrentFiles] = useState<FileList | null>(null)
  const [uploadedAttachments, setUploadedAttachments] = useState<
    { url: string; fileName: string }[]
  >([])

  const {
    control,
    formState: { errors },
    setValue,
    clearErrors,
    setError,
    handleSubmit,
  } = useForm<ITask>({
    mode: 'all',
    defaultValues: {
      title: '',
      assignees: [],
      type: undefined,
      dueDate: undefined,
      note: '',
    },
    shouldFocusError: true,
  })

  const { user } = useContext(UserContext)

  const getAllAssignees = async () => {
    const response = await axiosInstance.post('/api/task/assignees-list', {
      role: user?.role,
      id:
        user?.role === Role.Collaborator ? user.collaboratorId : user?.personId,
    })

    let assignees = []
    if (response.data.persons.length !== 0) {
      assignees = response.data.persons.map((person: Person) => ({
        id: person.personId,
        label: `${person.firstName} ${person.lastName ?? ''}`,
      }))
    }

    if (user?.role === Role.Employee) {
      specialAssigneesList.forEach((value) =>
        assignees.unshift({ id: value, label: value }),
      )
    }

    setAssignees(assignees)
  }

  const getTaskDetails = async () => {
    setServerError('')
    try {
      const response = await axiosInstance(`/api/task/${taskId}`)
      await getAllAssignees()
      const task = response.data.task

      setTask(task)
      setUploadedAttachments(task.attachments)
      setValue('title', task.title)
      setValue('dueDate', new Date(task?.dueDate) ?? '')
      setValue('note', task?.note ?? '')
      setValue('type', task.type)
      setValue('assignees', task.assigneeId)
    } catch (error) {
      const errorMessage =
        error instanceof AxiosError
          ? error.response?.data?.error
          : errorMessages.DEFAULT_ERROR

      setServerError(errorMessage)
    }
  }

  useEffect(() => {
    getTaskDetails()
  }, [])

  const markAsDoneHandler = async (done: boolean) => {
    setTaskUpdated(false)
    setServerError('')
    try {
      const response = await axiosInstance.put(`/api/task/${taskId}`, {
        ...task,
        done,
        changeDoneStatus: true,
      })
      if (response.status === 200) {
        getTaskDetails()
        setTaskUpdated(true)
      }
    } catch (error) {
      const errorMessage =
        error instanceof AxiosError
          ? error.response?.data?.error
          : errorMessages.DEFAULT_ERROR

      setServerError(errorMessage)
    }
  }

  const taskUpdateHandler = async (payload: ITask) => {
    setTaskUpdated(false)
    setServerError('')
    try {
      const response = await axiosInstance.put(`/api/task/${taskId}`, payload)
      if (response.status === 200) {
        getTaskDetails()
        setTaskUpdated(true)
        setOpenModal(false)
      }
    } catch (error) {
      const errorMessage =
        error instanceof AxiosError
          ? error.response?.data?.error
          : errorMessages.DEFAULT_ERROR

      setServerError(errorMessage)
    }
  }

  const handleDownloadClick = async () => {
    if (task && task.attachments && task.attachments.length > 0) {
      const file = task.attachments[0].attachment

      const response = await axiosInstance.post(
        `/api/attachment/get-attachment-link`,
        { fileName: file, responseType: 'arraybuffer' },
      )

      if (response.status === 200) {
        const blob = new Blob([response.data])

        const url = window.URL.createObjectURL(blob)

        const link = document.createElement('a')
        link.href = url
        link.download = file

        document.body.appendChild(link)

        link.click()

        document.body.removeChild(link)
        window.URL.revokeObjectURL(url)
      }
    }
  }

  return (
    <>
      {task?.attachments && task?.attachments.length > 0 ? (
        <ContractViewPopup
          open={modalData.type === 'contractDetail' && modalData.open}
          handleClose={handleClose}
          attachment={task.attachments[0].fileName}
        />
      ) : null}
      <Grid container justifyContent="space-between" mb={25}>
        <Grid item display="flex" alignItems="flex-end" gap={10}>
          <Typography variant="h1" mb={0}>
            {tScoped('Task')} {taskId}
          </Typography>
          {task?.creator ? (
            <Typography variant="subtitle1">
              ({tScoped('Assigned By')} {task?.creator.firstName}{' '}
              {task?.creator.lastName ?? ''})
            </Typography>
          ) : null}
        </Grid>
        <Grid item>
          <CustomButton
            icon
            label
            labelText={tScoped('Back')}
            iconName="arrowLeft"
            onClick={() => router.back()}
          />
        </Grid>
      </Grid>

      <Box
        sx={{
          border: '1px solid black',
          backgroundColor: '#FFFFFF',
          padding: '20px',
          display: 'flex',
          flexDirection: 'column',
          gap: '20px',
        }}
      >
        <Grid container alignItems="center">
          <Grid item xs={6} container flexDirection="column">
            <Grid item>
              <Typography
                sx={{
                  fontWeight: 700,
                  fontSize: '20px',
                  textTransform: 'capitalize',
                }}
              >
                {task?.title}
              </Typography>
            </Grid>
            <Grid item>
              <Typography sx={{ fontWeight: 400, fontSize: '16px' }}>
                {task?.note}
              </Typography>
            </Grid>
          </Grid>
          <Grid
            item
            xs={6}
            container
            justifyContent="flex-end"
            alignItems="center"
            gap="40px"
          >
            {task?.done ? <Chip done={task?.done} /> : null}
            <Chip type={task?.type} />
            <Grid item>
              <Typography sx={{ fontWeight: 400, fontSize: '16px' }}>
                till {moment(task?.dueDate).format('DD.MM.YYYY') ?? ''}
              </Typography>
            </Grid>
          </Grid>
        </Grid>

        <Grid container>
          {task?.attachments && task.attachments.length > 0 ? (
            <Grid
              item
              xs={4}
              container
              onClick={() =>
                setModalData({ type: 'contractDetail', open: true })
              }
              gap="12px"
            >
              <IconSwitcher icon="redFolder" />
              <Typography sx={{ fontWeight: 400, fontSize: '16px' }}>
                Open Contract
              </Typography>
            </Grid>
          ) : null}
        </Grid>
        {task?.attachments && task.attachments.length > 0 ? (
          <Grid container gap="12px" onClick={handleDownloadClick}>
            <IconSwitcher icon="redDownload" />
            <Typography sx={{ fontWeight: 400, fontSize: '16px' }}>
              Download Contract
            </Typography>
          </Grid>
        ) : null}
        <Grid container justifyContent="space-around" alignItems="center">
          <Grid item xs={12} container justifyContent="flex-end" gap={10}>
            {user?.personId === task?.creatorId ? (
              <CustomButton
                icon
                label
                labelText={tScoped('Edit')}
                iconName="check"
                onClick={() => setOpenModal(true)}
              />
            ) : null}
            <CustomButton
              icon
              label
              labelText={
                task?.done
                  ? tScoped('Mark as not done')
                  : tScoped('Mark as done')
              }
              iconName="check"
              onClick={() => markAsDoneHandler(!task?.done)}
            />
          </Grid>
        </Grid>
      </Box>

      <CustomModal
        open={openModal}
        onClose={() => setOpenModal(false)}
        sx={{ width: '800px' }}
      >
        <Box
          component="form"
          autoComplete="off"
          onSubmit={handleSubmit(taskUpdateHandler)}
        >
          <Typography variant="h2" mb={15}>
            {tScoped('Update Task')}
          </Typography>

          <Grid container mb={10}>
            <Grid item xs={12}>
              <RHFAutocompleteField
                control={control}
                name="assignees"
                label={tScoped('Assignees')}
                options={assignees}
                required
              />
            </Grid>

            <Grid item xs={12}>
              <FormLabel>{tScoped('Type')}</FormLabel>
              <RHFAutocompleteField
                control={control}
                name="type"
                label=""
                options={Object.keys(TaskType).map((key) => ({
                  id: key,
                  label: key,
                }))}
                required
              />
            </Grid>

            <Grid item xs={12}>
              <InputField
                control={control}
                name="title"
                label={tScoped('Title')}
                fullWidth
                rules={{
                  required: {
                    value: true,
                    message: validationMessages.required,
                  },
                }}
                error={!!errors.title}
                helperText={errors.title?.message}
              />
            </Grid>

            <Grid item xs={12}>
              <FormLabel sx={{ display: 'block' }}>
                {tScoped('Due Date')}
              </FormLabel>
              <CustomDatePicker
                name="dueDate"
                label=""
                control={control}
                setValue={setValue}
                clearErrors={clearErrors}
                setError={setError}
                dateFormat="dd/MM/yyyy"
                required
              />
            </Grid>

            <Grid item xs={12}>
              <RHFTextArea
                name="note"
                label={tScoped('Note')}
                control={control}
              />
            </Grid>
          </Grid>

          <Grid container justifyContent="space-between" gap={10} mb={11}>
            <Grid item xs={12}>
              <AddAttachment
                sx={{ marginRight: 'auto' }}
                currentFiles={currentFiles}
                fileUploading={fileUploading}
                setCurrentFiles={setCurrentFiles}
                uploadedAttachments={uploadedAttachments}
              />
            </Grid>
          </Grid>

          <Grid container justifyContent="flex-end" gap={10}>
            <CustomButton
              label={true}
              labelText={tScoped('Discard')}
              icon={false}
              onClick={() => {
                setOpenModal(false)
              }}
            />
            <CustomButton
              label={true}
              labelText={tScoped('Update')}
              icon={false}
              variant="contained"
              type="submit"
            />
          </Grid>
        </Box>
      </CustomModal>

      {serverError !== '' ? (
        <Toast message={serverError} severity="error" />
      ) : null}

      {taskUpdated ? (
        <Toast message={successMessages.taskUpdated} severity="success" />
      ) : null}
    </>
  )
}

export default TaskDetails
