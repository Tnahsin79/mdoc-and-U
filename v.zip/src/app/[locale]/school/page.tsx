'use client'

import { AxiosError } from 'axios'
import { School } from '@prisma/client'
import { useRouter } from 'next/navigation'
import { useContext, useEffect, useState } from 'react'
import { UserContext, useUser } from '@/contexts/userContext'
import { errorMessages } from '@/utils/errorMessages'
import { paginationLimit } from '@/utils/constants/common'
import { useScopedI18n } from '../../../../locales/client'
import { frontendRoutes } from '@/utils/constants/frontend'
import {
  Grid,
  InputAdornment,
  Table,
  TableBody,
  TableContainer,
  TextField,
  Typography,
} from '@mui/material'

import Link from 'next/link'
import Toast from '@/components/Toast'
import Pagination from '@/components/Pagination'
import axiosInstance from '@/services/axiosInstance'
import CustomButton from '@/components/Buttons/CustomButton'
import SchoolTableRow from '@/components/TableRows/SchoolTableRows'
import IconSwitcher from '@/components/Icons'
import getUserRoles from '@/utils/getUserRoles'

const School = () => {
  const tScoped = useScopedI18n('school.School Table')
  const tDashboardScoped = useScopedI18n('dashboard')
  const router = useRouter()
  const { pagination, setPagination } = useContext(UserContext)
  const [page, setPage] = useState<number>(pagination.school)
  const [search, setSearch] = useState<string>('')
  const [totalRecords, setTotalRecords] = useState<number>(0)
  const [schoolList, setSchoolList] = useState<School[]>([])
  const [serverError, setServerError] = useState<string>('')

  const onPageChangeHandler = async (
    _: React.ChangeEvent<unknown>,
    value: number,
  ) => {
    setPagination((pre) => ({
      ...pre,
      school: value,
    }))
    setPage(value)
  }

  useEffect(() => {
    getSchoolList()
  }, [page, search])

  const getSchoolList = async () => {
    try {
      const response = await axiosInstance.post('/api/school', {
        page,
        search,
      })
      setSchoolList(response.data.schoolList)
      setTotalRecords(response.data.totalRecords)
    } catch (error) {
      const errorMessage =
        error instanceof AxiosError
          ? error.response?.data?.error
          : errorMessages.DEFAULT_ERROR

      setServerError(errorMessage)
    }
  }

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearch(e.target.value)
    setPage(1)
  }

  const user = useUser()
  const userRoles = getUserRoles(user)
  const anyChangePermissionFunction = (userRoles: string[]) => {
    return (userRoles.includes('subjectAdmin') || userRoles.includes('subjectSupervision'))
  }
  const anyChangePermission: boolean = anyChangePermissionFunction(userRoles)

  return (
    <>
      <Grid container justifyContent="space-between" mb={25}>
        <Grid item display="flex" alignItems="flex-end" gap={10}>
          <Typography variant="h1" mb={0}>
            {tScoped('School Table')}
          </Typography>
        </Grid>
        <Grid item>
          <CustomButton
            icon
            label
            labelText={tDashboardScoped('Back')}
            iconName="arrowLeft"
            onClick={() => router.back()}
          />
        </Grid>
      </Grid>

      <Grid container justifyContent="flex-end" gap={10} mb={9.5}>
        {anyChangePermission && <Link href={frontendRoutes.school.create}>
          <CustomButton
            label={true}
            labelText={tScoped('New School')}
            icon={true}
            iconName="plus"
          />
        </Link>}
        <TextField
          name="search"
          type="search"
          placeholder={tScoped('Search')}
          value={search}
          InputProps={{
            endAdornment: (
              <InputAdornment
                position="end"
                sx={{
                  cursor: 'pointer',
                  background: '#e40422',
                  height: '100%',
                  marginRight: '-14px',
                  maxHeight: '100%',
                  paddingInline: '10px',
                }}
              >
                <IconSwitcher icon={'search'} />
              </InputAdornment>
            ),
          }}
          onChange={handleSearch}
        />
      </Grid>

      <TableContainer>
        <Table sx={{ minWidth: '744px', marginBottom: '25px' }}>
          <TableBody>
            {schoolList.map((school) => (
              <SchoolTableRow
                key={school.schoolId}
                school={school}
                onClick={() => {
                  router.push(
                    `${frontendRoutes.school.edit}/${school.schoolId}`,
                  )
                }}
              />
            ))}
          </TableBody>
        </Table>
        {totalRecords > paginationLimit ? (
          <Pagination
            count={Math.ceil(totalRecords / paginationLimit)}
            page={page}
            onChange={onPageChangeHandler}
          />
        ) : null}
      </TableContainer>

      {serverError !== '' ? (
        <Toast message={serverError} severity="error" />
      ) : null}
    </>
  )
}

export default School
