'use client'

import { AxiosError } from 'axios'
import { List, School } from '@prisma/client'
import { useRouter } from 'next/navigation'
import { validators } from '@/validators'
import { useEffect, useState } from 'react'
import { errorMessages } from '@/utils/errorMessages'
import { Box, Grid, Typography } from '@mui/material'
import { SubmitHandler, useForm } from 'react-hook-form'
import { successMessages } from '@/utils/successMessages'
import { validationMessages } from '@/validators/messages'
import { IList, OptionInterface } from '@/interface/common'
import { frontendRoutes } from '@/utils/constants/frontend'
import { PLZ } from '@/utils/constants/berlin_district_PLZ'
import { RHFAutocompleteField } from '@/components/DropDown'
import { useScopedI18n } from '../../../../../locales/client'

import Toast from '@/components/Toast'
import InputField from '@/components/InputField'
import axiosInstance from '@/services/axiosInstance'
import CustomButton from '@/components/Buttons/CustomButton'

export interface createSchoolInterface extends Omit<School, 'schoolId'> {
  schoolType?: OptionInterface
}

const CreateSchool = () => {
  const tScoped = useScopedI18n('school.School Data')
  const tDashboardScoped = useScopedI18n('dashboard')
  const [serverError, setServerError] = useState<string>('')
  const [schoolCreated, setSchoolCreated] = useState<boolean>(false)
  const [schoolTypes, setSchoolTypes] = useState<IList>([])
  const [submitLoading, setSubmitLoading] = useState<boolean>(false)
  const router = useRouter()

  const getAllLists = async () => {
    const listsFromApi = await axiosInstance.post('/api/list', {
      listTypes: ['schoolType'],
    })

    setSchoolTypes(
      listsFromApi.data.data.schoolType.filter(
        (item: List) =>
          !['Tempelhof-Schöneberg', 'Lichtenberg'].includes(item.listValue),
      ),
    )
  }

  useEffect(() => {
    getAllLists()
  }, [])

  const {
    control,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm<createSchoolInterface>({
    mode: 'all',
    defaultValues: {
      BSN: '',
      emailAddress: '',
      faxNumber: '',
      phoneNumber: '',
      postalCode: '',
      schoolName: '',
      schoolTypeId: undefined,
      city: '',
      streetAndHouseNo: '',
      website: '',
    },
    shouldFocusError: true,
  })

  const discardHandler = () => {
    reset()
    router.push('/school')
  }

  const createSchoolHandler: SubmitHandler<createSchoolInterface> = async (
    payload,
  ) => {
    delete payload?.schoolType

    setSubmitLoading(true)

    try {
      const response = await axiosInstance.post('/api/school/create', {
        ...payload,
        postalCode: payload.postalCode.replace(/\D/g, ''),
      })
      if (response.status === 201) {
        setSubmitLoading(false)
        setSchoolCreated(true)
        reset()
        router.push(frontendRoutes.school.list)
      }
    } catch (error) {
      const errorMessage =
        error instanceof AxiosError
          ? error.response?.data?.error
          : errorMessages.DEFAULT_ERROR
      setSubmitLoading(false)
      setServerError(errorMessage)
    }
  }

  return (
    <>
      <Box component="form" onSubmit={handleSubmit(createSchoolHandler)}>
        <Grid container justifyContent="space-between" mb={25}>
          <Grid item display="flex" alignItems="flex-end" gap={10}>
            <Typography variant="h1" mb={0}>
              {tScoped('Create School')}
            </Typography>
          </Grid>
          <Grid item>
            <CustomButton
              icon
              label
              labelText={tDashboardScoped('Back')}
              iconName="arrowLeft"
              onClick={() => router.back()}
            />
          </Grid>
        </Grid>

        <Box>
          <Grid container spacing={10}>
            <Grid item xs={6}>
              <InputField
                label={tScoped('BSN')}
                fullWidth
                name="BSN"
                control={control}
                rules={{
                  required: {
                    value: true,
                    message: validationMessages.required,
                  },
                }}
                error={!!errors.BSN}
                helperText={errors.BSN?.message}
              />
            </Grid>
          </Grid>
        </Box>

        <Typography variant="h2" mb={10}>
          {tScoped('School Type')}
        </Typography>

        <Box>
          <Grid container spacing={10}>
            <Grid item xs={6}>
              <RHFAutocompleteField
                control={control}
                label={tScoped('Type')}
                name="schoolTypeId"
                options={schoolTypes?.map((item) => {
                  return {
                    id: item.listId,
                    label: item.listValue,
                  }
                })}
                required
              />
            </Grid>
          </Grid>
        </Box>

        <Typography variant="h2" mb={10}>
          {tScoped('General Information')}
        </Typography>

        <Grid container columnSpacing={10} mb={15}>
          <Grid item xs={6}>
            <InputField
              label={tScoped('School Name')}
              fullWidth
              name="schoolName"
              control={control}
              rules={{
                required: {
                  value: true,
                  message: validationMessages.required,
                },
              }}
              error={!!errors.schoolName}
              helperText={errors.schoolName?.message}
            />
          </Grid>
          <Grid item xs={6}>
            <InputField
              fullWidth
              label={tScoped('Street and House No')}
              name="streetAndHouseNo"
              control={control}
              rules={{
                required: {
                  value: true,
                  message: validationMessages.required,
                },
              }}
              error={!!errors.streetAndHouseNo}
              helperText={errors.streetAndHouseNo?.message}
            />
          </Grid>

          <Grid item xs={6}>
            <InputField
              fullWidth
              label={tScoped('City')}
              name="city"
              control={control}
              rules={{
                required: {
                  value: true,
                  message: validationMessages.required,
                },
              }}
              error={!!errors.city}
              helperText={errors.city?.message}
            />
          </Grid>

          <Grid item xs={6}>
            <RHFAutocompleteField
              control={control}
              options={PLZ?.map((item: { PLZ: string; District: string }) => {
                return {
                  id: `${item.District} (${item.PLZ})`,
                  label: `${item.District} (${item.PLZ})`,
                }
              })}
              name="postalCode"
              required
              label={tScoped('Postal Code')}
            />
          </Grid>

          <Grid item xs={6}>
            <InputField
              fullWidth
              label={tScoped('Phone Number')}
              name="phoneNumber"
              control={control}
              rules={{
                required: {
                  value: true,
                  message: validationMessages.required,
                },
                pattern: {
                  value: validators.phoneNumber,
                  message: validationMessages.validPhone,
                },
              }}
              error={!!errors.phoneNumber}
              helperText={errors.phoneNumber?.message}
            />
          </Grid>

          <Grid item xs={6}>
            <InputField
              fullWidth
              label={tScoped('Fax Number')}
              name="faxNumber"
              control={control}
            />
          </Grid>
          <Grid item xs={6}>
            <InputField
              fullWidth
              label={tScoped('E-mail Address')}
              name="emailAddress"
              control={control}
              rules={{
                required: {
                  value: true,
                  message: validationMessages.required,
                },
                pattern: {
                  value: validators.email,
                  message: validationMessages.validEmail,
                },
              }}
              error={!!errors.emailAddress}
              helperText={errors.emailAddress?.message}
            />
          </Grid>

          <Grid item xs={6}>
            <InputField
              fullWidth
              label={tScoped('Website')}
              name="website"
              control={control}
            />
          </Grid>
        </Grid>

        <Box mb={50}>
          <Grid container spacing={10}>
            <Grid item xs={6} container sx={{ justifyContent: 'end' }}>
              <CustomButton
                label
                labelText={tScoped('Discard')}
                sx={{ width: '200px' }}
                onClick={() => discardHandler()}
              />
            </Grid>
            <Grid item xs={6}>
              <CustomButton
                label
                labelText={tScoped('Save')}
                sx={{ width: '200px' }}
                variant="contained"
                type="submit"
                loading={submitLoading}
              />
            </Grid>
          </Grid>
        </Box>
      </Box>
      {serverError !== '' ? (
        <Toast
          message={serverError}
          severity="error"
          setServerError={setServerError}
        />
      ) : null}
      {schoolCreated ? (
        <Toast message={successMessages.schoolCreated} severity="success" />
      ) : null}
    </>
  )
}

export default CreateSchool
