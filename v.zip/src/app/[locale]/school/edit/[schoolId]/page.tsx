'use client'

import { AxiosError } from 'axios'
import { List, School } from '@prisma/client'
import { validators } from '@/validators'
import { useEffect, useState } from 'react'
import { Box, Grid, Typography } from '@mui/material'
import { errorMessages } from '@/utils/errorMessages'
import { useParams, useRouter } from 'next/navigation'
import { SubmitHandler, useForm } from 'react-hook-form'
import { successMessages } from '@/utils/successMessages'
import { validationMessages } from '@/validators/messages'
import { IList, OptionInterface } from '@/interface/common'
import { PLZ } from '@/utils/constants/berlin_district_PLZ'
import { frontendRoutes } from '@/utils/constants/frontend'
import { RHFAutocompleteField } from '@/components/DropDown'
import { useScopedI18n, useI18n } from '../../../../../../locales/client'

import Toast from '@/components/Toast'
import InputField from '@/components/InputField'
import axiosInstance from '@/services/axiosInstance'
import CustomButton from '@/components/Buttons/CustomButton'
import { useUser } from '@/contexts/userContext'
import getUserRoles from '@/utils/getUserRoles'

export interface updateSchoolInterface extends Omit<School, 'schoolId'> {
  schoolType?: OptionInterface
}

const CreateSchool = () => {
  const t = useI18n()
  const tScoped = useScopedI18n('school.School Data')
  const tDashboardScoped = useScopedI18n('dashboard')
  const router = useRouter()
  const { schoolId }: { schoolId: string } = useParams()

  const [schoolData, setSchoolData] = useState<School>()
  const [serverError, setServerError] = useState<string>('')
  const [schoolUpdated, setSchoolUpdated] = useState<boolean>(false)
  const [schoolTypes, setSchoolTypes] = useState<IList>([])

  const getSchoolData = async () => {
    try {
      const schoolData = await axiosInstance.get(`/api/school/${schoolId}`)
      setSchoolData(schoolData.data.school)
    } catch (error) {
      const errorMessage =
        error instanceof AxiosError
          ? error.response?.data?.error
          : errorMessages.DEFAULT_ERROR
      setServerError(errorMessage)
    }
  }

  const getAllLists = async () => {
    const listsFromApi = await axiosInstance.post('/api/list', {
      listTypes: ['schoolType'],
    })

    setSchoolTypes(
      listsFromApi.data.data.schoolType.filter(
        (item: List) =>
          !['Tempelhof-Schöneberg', 'Lichtenberg'].includes(item.listValue),
      ),
    )
  }

  useEffect(() => {
    getAllLists()
    getSchoolData()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const {
    control,
    handleSubmit,
    formState: { errors, isDirty },
    reset,
  } = useForm<updateSchoolInterface>({
    defaultValues: {
      BSN: '',
      emailAddress: '',
      faxNumber: '',
      phoneNumber: '',
      postalCode: '',
      schoolName: '',
      schoolTypeId: undefined,
      city: '',
      streetAndHouseNo: '',
      website: '',
    },
    values: schoolData,
    mode: 'all',
    shouldFocusError: true,
  })

  const updateSchoolHandler: SubmitHandler<updateSchoolInterface> = async (
    payload,
  ) => {
    delete payload?.schoolType
    if (!isDirty) {
      setSchoolUpdated(true)
      return setTimeout(() => {
        router.push(frontendRoutes.school.list)
      }, 1000)
    }

    try {
      const response = await axiosInstance.post(
        `/api/school/${schoolId}`,
        payload,
      )
      if (response.status === 200) {
        setSchoolUpdated(true)
        reset()
        setTimeout(() => {
          router.push(frontendRoutes.school.list)
        }, 1000)
      }
    } catch (error) {
      const errorMessage =
        error instanceof AxiosError
          ? error.response?.data?.error
          : errorMessages.DEFAULT_ERROR

      setServerError(errorMessage)
    }
  }
  const user = useUser()
  const userRoles = getUserRoles(user)
  const anyChangePermissionFunction = (userRoles: string[]) => {
    return (userRoles.includes('subjectAdmin') || userRoles.includes('subjectSupervision'))
  }
  const anyChangePermission: boolean = anyChangePermissionFunction(userRoles)

  return (
    <>
      <Box component="form" onSubmit={handleSubmit(updateSchoolHandler)}>
        <Grid container justifyContent="space-between" mb={25}>
          <Grid item display="flex" alignItems="flex-end" gap={10}>
            <Typography variant="h1" mb={0}>
              {t('school.School Table.Update School')}
            </Typography>
          </Grid>
          <Grid item>
            <CustomButton
              icon
              label
              labelText={tDashboardScoped('Back')}
              iconName="arrowLeft"
              onClick={() => router.back()}
            />
          </Grid>
        </Grid>

        <Box>
          <Grid container spacing={10}>
            <Grid item xs={6}>
              <InputField
                label={tScoped('BSN')}
                fullWidth
                name="BSN"
                control={control}
                rules={{
                  required: {
                    value: true,
                    message: validationMessages.required,
                  },
                }}
                error={!!errors.BSN}
                helperText={errors.BSN?.message}
              />
            </Grid>
          </Grid>
        </Box>

        <Typography variant="h2" mb={10}>
          {tScoped('School Type')}
        </Typography>

        <Box>
          <Grid container spacing={10}>
            <Grid item xs={6}>
              <RHFAutocompleteField
                control={control}
                label={tScoped('Type')}
                name="schoolTypeId"
                options={schoolTypes?.map((item) => {
                  return {
                    id: item.listId,
                    label: item.listValue,
                  }
                })}
                required
                defaultValue={schoolData?.schoolTypeId}
              />
            </Grid>
          </Grid>
        </Box>

        <Typography variant="h2" mb={10}>
          {tScoped('General Information')}
        </Typography>

        <Grid container columnSpacing={10} mb={15}>
          <Grid item xs={6}>
            <InputField
              label={tScoped('School Name')}
              fullWidth
              name="schoolName"
              control={control}
              rules={{
                required: {
                  value: true,
                  message: validationMessages.required,
                },
              }}
              error={!!errors.schoolName}
              helperText={errors.schoolName?.message}
            />
          </Grid>
          <Grid item xs={6}>
            <InputField
              fullWidth
              label={tScoped('Street and House No')}
              name="streetAndHouseNo"
              control={control}
              rules={{
                required: {
                  value: true,
                  message: validationMessages.required,
                },
              }}
              error={!!errors.streetAndHouseNo}
              helperText={errors.streetAndHouseNo?.message}
            />
          </Grid>

          <Grid item xs={6}>
            <InputField
              fullWidth
              label={tScoped('City')}
              name="city"
              control={control}
              rules={{
                required: {
                  value: true,
                  message: validationMessages.required,
                },
              }}
              error={!!errors.city}
              helperText={errors.city?.message}
            />
          </Grid>

          <Grid item xs={6}>
            <RHFAutocompleteField
              control={control}
              options={PLZ?.map((item: { PLZ: string; District: string }) => {
                return {
                  id: `${item.PLZ}`,
                  label: `${item.District} (${item.PLZ})`,
                }
              })}
              name="postalCode"
              required
              label={tScoped('Postal Code')}
            />
          </Grid>

          <Grid item xs={6}>
            <InputField
              fullWidth
              label={tScoped('Phone Number')}
              name="phoneNumber"
              control={control}
              rules={{
                required: {
                  value: true,
                  message: validationMessages.required,
                },
                pattern: {
                  value: validators.phoneNumber,
                  message: validationMessages.validPhone,
                },
              }}
              error={!!errors.phoneNumber}
              helperText={errors.phoneNumber?.message}
            />
          </Grid>

          <Grid item xs={6}>
            <InputField
              fullWidth
              label="Fax Number"
              name="faxNumber"
              control={control}
            />
          </Grid>
          <Grid item xs={6}>
            <InputField
              fullWidth
              label={tScoped('E-mail Address')}
              name="emailAddress"
              control={control}
              rules={{
                required: {
                  value: true,
                  message: validationMessages.required,
                },
                pattern: {
                  value: validators.email,
                  message: validationMessages.validEmail,
                },
              }}
              error={!!errors.emailAddress}
              helperText={errors.emailAddress?.message}
            />
          </Grid>

          <Grid item xs={6}>
            <InputField
              fullWidth
              label={tScoped('Website')}
              name="website"
              control={control}
            />
          </Grid>
        </Grid>

        <Box>
          <Grid container spacing={10} justifyContent="center" mb={25}>
            <Grid item>
              <CustomButton
                label
                labelText={tScoped('Discard')}
                sx={{ minWidth: '200px' }}
                onClick={() => {
                  router.push(frontendRoutes.school.list)
                }}
                disabled={!anyChangePermission}
              />
            </Grid>

            <Grid item>
              <CustomButton
                type="submit"
                label
                labelText={tScoped('Save')}
                sx={{ minWidth: '200px' }}
                variant="contained"
                disabled={!anyChangePermission}
              />
            </Grid>
          </Grid>
        </Box>
      </Box>
      {serverError !== '' ? (
        <Toast message={serverError} severity="error" />
      ) : null}
      {schoolUpdated ? (
        <Toast message={successMessages.schoolUpdated} severity="success" />
      ) : null}
    </>
  )
}

export default CreateSchool
