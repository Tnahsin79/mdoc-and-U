'use client'

import moment from 'moment'
import Toast from '@/components/Toast'
import InputField from '@/components/InputField'
import axiosInstance from '@/services/axiosInstance'
import Button from '@/components/Buttons/CustomButton'
import CustomDatePicker from '@/components/DatePicker'
import CustomCheckbox from '@/components/Buttons/CustomCheckbox'

import { AxiosError, AxiosResponse } from 'axios'
import { Candidate, Person, Role } from '@prisma/client'
import { useParams, useRouter } from 'next/navigation'
import { useContext, useEffect, useState } from 'react'
import { errorMessages } from '@/utils/errorMessages'
import { Box, Grid, InputLabel, Typography } from '@mui/material'
import { SubmitHandler, useForm } from 'react-hook-form'
import { successMessages } from '@/utils/successMessages'
import { validationMessages } from '@/validators/messages'
import { RHFAutocompleteField } from '@/components/DropDown'
import { IList, ISchoolInterface } from '@/interface/common'
import { phasesOptions } from '@/utils/constants/common'
import DeactivateAccount from '@/components/DeactivateAccount'
import { UserContext } from '@/contexts/userContext'
import CustomButton from '@/components/Buttons/CustomButton'
import AddAttachment from '@/components/Buttons/AddAttachment'
import { frontendRoutes } from '@/utils/constants/frontend'
import DeleteAccount from '@/components/Modals/DeleteAccount'
import { useScopedI18n } from '../../../../../../locales/client'
import getUserRoles from '@/utils/getUserRoles'
import { RHFTextArea } from '@/components/TextArea'

export interface ICreateCandidate extends Omit<Candidate, 'document'>, Person {
  phasePreference: {
    kickOff: boolean
    firstStep: boolean
    setUp: boolean
    studies: boolean
  }
  document: {
    url: string
    fileName: string
  } | null
}

const CreateCandidate: React.FC = () => {
  const tScoped = useScopedI18n('candidate')
  const tDashboardScoped = useScopedI18n('dashboard')
  const router = useRouter()
  const { user } = useContext(UserContext)
  const { candidateId }: { candidateId: string } = useParams()
  const isEmployee = user?.role === Role.Employee
  const isCandidate = user?.role === Role.Candidate

  const [candidateData, setCandidateData] = useState<ICreateCandidate>()
  const [candidateUpdated, setCandidateUpdated] = useState<boolean>(false)
  const [employeeInformed, setEmployeeInformed] = useState<boolean>(false)
  const [kickOffs, setKickOffs] = useState<IList>([])
  const [yearGroups, setYearGroups] = useState<IList>([])
  const [serverError, setServerError] = useState<string>('')
  const [appellations, setAppellations] = useState<IList>([])
  const [teachingPositions, setTeachingPositions] = useState<IList>([])
  const [schoolList, setSchoolList] = useState<ISchoolInterface[]>([])
  const [schoolEmail, setSchoolEmail] = useState<string>('')
  const [schoolPhone, setSchoolPhone] = useState<string>('')
  const [longerAbsenceReasons, setLongerAbsenceReasons] = useState<IList>([])
  const [deactivateAccountModal, setDeactivateAccountModal] =
    useState<boolean>(false)
  const [isDeactivated, setIsDeactivated] = useState<boolean>(false)

  const [deleteModal, setDeleteModal] = useState<boolean>(false)
  const [candidateDeleted, setCandidateDeleted] = useState<boolean>(false)

  const [submitLoading, setSubmitLoading] = useState<boolean>(false)
  const [firstRecognisedSubjects, setFirstRecognisedSubjects] = useState<IList>(
    [],
  )
  const [secondRecognisedSubjects, setSecondRecognisedSubjects] =
    useState<IList>([])
  const [thirdRecognisedSubjects, setThirdRecognisedSubjects] = useState<IList>(
    [],
  )
  const [firstSubjectToBeStudied, setFirstSubjectToBeStudied] = useState<IList>(
    [],
  )
  const [secondSubjectToBeStudied, setSecondSubjectToBeStudied] =
    useState<IList>([])
  const [subjectChangeFrom, setSubjectChangeFrom] = useState<IList>([])
  const [subjectChangeTo, setSubjectChangeTo] = useState<IList>([])
  const [currentFile, setCurrentFile] = useState<FileList | null>(null)
  const [fileUploading, setFileUploading] = useState<boolean>(false)
  const [correctData, setCorrectData] = useState<boolean>(true)
  const [uploadedAttachments, setUploadedAttachments] = useState<{
    url: string
    fileName: string
  } | null>(null)

  const [vocationalId, setVocationalId] = useState<number | null>(null)

  const [studiesGroupSubjectA, setStudiesGroupSubjectA] = useState<IList>([])
  const [studiesGroupSubjectB, setStudiesGroupSubjectB] = useState<IList>([])

  const [startSubjectA, setStartSubjectA] = useState<IList>([])
  const [startSubjectB, setStartSubjectB] = useState<IList>([])

  const {
    handleSubmit,
    formState: { errors },
    control,
    clearErrors,
    setValue,
    setError,
    watch,
    reset,
    resetField,
  } = useForm<ICreateCandidate>({
    mode: 'all',
    values: candidateData,
    shouldFocusError: true,
  })

  const fromDate = watch('fromDate')
  const schoolId = watch('schoolId')
  const longerAbsenceReasonId = watch('longerAbsenceReasonId')
  const teachingPositionId = watch('teachingPositionId')

  useEffect(() => {
    if (teachingPositions.length) {
      const vocational = teachingPositions.filter(
        (teachingPosition) =>
          teachingPosition.listValue === 'Lehramt an Beruflichen Schulen',
      )
      setVocationalId(vocational[0].listId)
    }
  }, [teachingPositions])

  useEffect(() => {
    setTimeout(() => {
      if (candidateUpdated) {
        setCandidateUpdated(false)
      }
    }, 1000)
  }, [candidateUpdated])

  useEffect(() => {
    if (!longerAbsenceReasonId) {
      resetField('fromDate')
      resetField('untilDate')
    }
  }, [longerAbsenceReasonId])

  useEffect(() => {
    const fetchData = async () => {
      try {
        await Promise.all([getAllLists(), getSchoolLists(), getCandidateData()])
      } catch (error) {
        const errorMessage =
          error instanceof AxiosError
            ? error.response?.data?.error
            : errorMessages.DEFAULT_ERROR

        setServerError(errorMessage)
      }
    }
    fetchData()
  }, [])

  useEffect(() => {
    if (schoolList && schoolList.length > 0) {
      const selectedSchoolDetails = schoolList.find(
        (school) => school.schoolId === schoolId,
      )
      if (selectedSchoolDetails) {
        setSchoolEmail(selectedSchoolDetails.emailAddress)
        setSchoolPhone(selectedSchoolDetails.phoneNumber)
      }
    }
  }, [schoolId, schoolList])

  const getAllLists = async () => {
    const listsFromApi = await axiosInstance.post('/api/list', {
      listTypes: [
        'teachingPosition',
        'longerAbsenceReason',
        'yearGroup',
        'phase',
        'kickOffGroup',
        'schoolType',
        'person',
        'appellation',
        'gender',
        'firstRecognisedSubject',
        'secondRecognisedSubject',
        'thirdRecognisedSubject',
        'firstSubjectToBeStudied',
        'secondSubjectToBeStudied',
        'subjectChangeFrom',
        'subjectChangeTo',
        'studiesGroupSubjectA',
        'studiesGroupSubjectB',
        'startSubjectA',
        'startSubjectB',
      ],
    })

    setKickOffs(listsFromApi.data.data.kickOffGroup)
    setYearGroups(listsFromApi.data.data.yearGroup)
    setAppellations(listsFromApi.data.data.appellation)
    setTeachingPositions(listsFromApi.data.data.teachingPosition)
    setLongerAbsenceReasons(listsFromApi.data.data.longerAbsenceReason)
    setFirstRecognisedSubjects(listsFromApi.data.data.firstRecognisedSubject)
    setSecondRecognisedSubjects(listsFromApi.data.data.secondRecognisedSubject)
    setThirdRecognisedSubjects(listsFromApi.data.data.thirdRecognisedSubject)
    setFirstSubjectToBeStudied(listsFromApi.data.data.firstSubjectToBeStudied)
    setSecondSubjectToBeStudied(listsFromApi.data.data.secondSubjectToBeStudied)
    setSubjectChangeFrom(listsFromApi.data.data.subjectChangeFrom)
    setSubjectChangeTo(listsFromApi.data.data.subjectChangeTo)
    setStudiesGroupSubjectA(listsFromApi.data.data.studiesGroupSubjectA)
    setStudiesGroupSubjectB(listsFromApi.data.data.studiesGroupSubjectB)
    setStartSubjectA(listsFromApi.data.data.startSubjectA)
    setStartSubjectB(listsFromApi.data.data.startSubjectB)
  }

  const getSchoolLists = async () => {
    const schoolListFromApi = await axiosInstance.post('/api/school', {
      all: true,
    })
    setSchoolList(schoolListFromApi.data.schoolList)
  }

  const selectedPhases = watch('phasePreference')
  const onCheckBoxChangeHandler = async (checked?: boolean) => {
    if (
      !Object.values(selectedPhases).some((value) => {
        if (typeof value === 'boolean') {
          return value === true
        }
      })
    ) {
      clearErrors('phasePreference')
    }

    if (checked) {
      clearErrors('phasePreference')
    }

    if (!checked) {
      setServerError('Select Phase')
    }
  }

  const getCandidateData = async () => {
    const response = await axiosInstance.get(`/api/candidate/${candidateId}`)

    const candidateData = response.data.candidate

    setIsDeactivated(!candidateData.isActive)
    setCandidateData({
      ...candidateData,
      fromDate: candidateData.fromDate
        ? new Date(candidateData.fromDate)
        : null,
      untilDate: candidateData.untilDate
        ? new Date(candidateData.untilDate)
        : null,
      startOfContract: candidateData.startOfContract
        ? new Date(candidateData.startOfContract)
        : null,
      phasePreference: phasesOptions.find(
        (phase) => phase.id === candidateData.phaseRequiredId,
      ),
      bbvdStart: candidateData.bbvdStart
        ? new Date(candidateData.bbvdStart)
        : null,
      recognisedSubject: candidateData.recognisedSubject,
      bbstStart: candidateData.bbstStart
        ? new Date(candidateData.bbstStart)
        : null,
      studiesGroupSubjectAId: candidateData.studiesGroupSubjectAId,
      studiesGroupSubjectBId: candidateData.studiesGroupSubjectBId,
    })
    setCorrectData(candidateData.correct)
    setUploadedAttachments(candidateData?.document ?? null)
  }

  useEffect(() => {
    if (currentFile) {
      setUploadedAttachments(null)
    }
  }, [currentFile])

  const updateCandidateHandler: SubmitHandler<ICreateCandidate> = async (
    payload,
  ) => {
    try {
      if (
        payload.longerAbsenceReasonId &&
        !payload.fromDate &&
        !payload.untilDate
      ) {
        setError(
          'fromDate',
          { type: 'custom', message: 'Enter From Date' },
          { shouldFocus: true },
        )
        setError(
          'untilDate',
          { type: 'custom', message: 'Enter Until Date' },
          { shouldFocus: true },
        )
        throw new Error('Enter From Date and Until Date')
      }

      let responseFromFileServer: AxiosResponse | null = null
      if (currentFile !== null) {
        setFileUploading(true)
        const formData = new FormData()
        formData.append('file', currentFile[0])
        responseFromFileServer = await axiosInstance.post(
          '/api/upload',
          formData,
        )
        if (responseFromFileServer && responseFromFileServer.status === 201) {
          setFileUploading(false)
        }
      }
      setSubmitLoading(true)

      const updatedCandidatePayload = {
        appellationId: payload.appellationId ?? null,
        title: payload.title,
        firstName: payload.firstName,
        lastName: payload.lastName,
        streetAndHouseNo: payload.streetAndHouseNo,
        city: payload.city,
        postalCode: payload.postalCode,
        phoneNumber: payload.phoneNumber,
        email: payload.email.toLowerCase(),
        longerAbsenceReasonId: payload.longerAbsenceReasonId ?? null,
        fromDate: payload.fromDate
          ? moment(payload.fromDate, 'dd/MM/yyyy').toDate()
          : null,
        untilDate: payload.untilDate
          ? moment(payload.untilDate, 'dd/MM/yyyy').toDate()
          : null,
        startOfContract: payload.startOfContract
          ? moment(payload.startOfContract, 'dd/MM/yyyy').toDate()
          : undefined,
        schoolId: payload.schoolId,
        phaseRequiredId: phasesOptions.find(
          (phase) =>
            phase.firstStep === payload.phasePreference.firstStep &&
            phase.kickOff === payload.phasePreference.kickOff &&
            phase.setUp === payload.phasePreference.setUp &&
            phase.studies === payload.phasePreference.studies,
        )?.id,
        bbvdStart: payload.bbvdStart
          ? moment(payload.bbvdStart, 'dd/MM/yyyy').toDate()
          : null,
        startSchoolYear: payload.startSchoolYear,
        yearGroupId: payload.yearGroupId ?? null,
        kickOffGroupId: payload.kickOffGroupId ?? null,
        teachingPositionId: payload.teachingPositionId,
        firstRecognisedSubjectId: payload.firstRecognisedSubjectId,
        secondRecognisedSubjectId: payload.secondRecognisedSubjectId ?? null,
        thirdRecognisedSubjectId: payload.thirdRecognisedSubjectId ?? null,
        firstSubjectToBeStudiedId: payload.firstSubjectToBeStudiedId ?? null,
        secondSubjectToBeStudiedId: payload.secondSubjectToBeStudiedId ?? null,
        subjectChangeFromId: payload.subjectChangeFromId ?? null,
        subjectChangeToId: payload.subjectChangeToId ?? null,
        recognisedSubject: payload.recognisedSubject ?? null,
        studiesGroupSubjectAId: payload.studiesGroupSubjectAId ?? null,
        studiesGroupSubjectBId: payload.studiesGroupSubjectBId ?? null,
        startSubjectAId: payload.startSubjectAId ?? null,
        startSubjectBId: payload.startSubjectBId ?? null,
        document:
          currentFile && !uploadedAttachments
            ? responseFromFileServer?.data.responseData[0].fileName
            : !currentFile && !uploadedAttachments
              ? ''
              : candidateData?.document?.fileName,
      }

      const response = await axiosInstance.post(
        `/api/candidate/${candidateId}`,
        updatedCandidatePayload,
      )

      if (response.status === 200) {
        setSubmitLoading(false)
        setCandidateUpdated(true)
        correctDataHandlerEmployee()
        setTimeout(() => {
          if (user?.role === Role.Candidate) {
            router.replace(frontendRoutes.candidate.dashboard)
          } else {
            router.replace(frontendRoutes.dashboard)
          }
        }, 1500)
      }
    } catch (error) {
      setSubmitLoading(false)
      let errorMessage = errorMessages.DEFAULT_ERROR

      if (error instanceof AxiosError) {
        if (error.response?.status === 409) {
          errorMessage =
            error.response.data?.message || errorMessages.DUPLICATE_EMAIL
        } else if (error.response?.status === 400) {
          errorMessage = errorMessages.DEFAULT_ERROR
        } else if (error.response?.status === 404) {
          errorMessage = errorMessages.NO_DATA_FOUND
        }
        // Add more conditions for different error status codes if needed
      }

      setServerError(errorMessage)
    }
  }

  const minSelectableDate = fromDate
    ? moment(fromDate).add(0, 'days').toDate()
    : undefined

  const handleDeleteAccountModalOpen = async () => {
    setDeleteModal(true)
  }

  const handleDeleteAccountModalClose = async () => {
    setDeleteModal(false)
  }

  const deleteAccount = async () => {
    try {
      const response = await axiosInstance.post(
        `/api/candidate/delete-candidate/${candidateId}`,
        {
          candidateId: +candidateId,
        },
      )

      if (response.status === 200) {
        setCandidateDeleted(true)
        setTimeout(() => {
          router.replace(frontendRoutes.candidate.list)
        }, 1000)
      }
    } catch (error) {
      const errorMessage =
        error instanceof AxiosError
          ? error.response?.data?.error
          : errorMessages.DEFAULT_ERROR

      setServerError(errorMessage)
    } finally {
      setDeactivateAccountModal(false)
    }
  }

  const onDeactivateAccount = async () => {
    setDeactivateAccountModal(true)
  }

  const deactivateAccount = async () => {
    try {
      const response = await axiosInstance.put(
        `/api/candidate/deactivate-account`,
        {
          candidateId: +candidateId,
          isActive: isDeactivated,
        },
      )
      if (response.status === 201) {
        setCandidateUpdated(true)
        setIsDeactivated(!isDeactivated)
      }
    } catch (error) {
      const errorMessage =
        error instanceof AxiosError
          ? error.response?.data?.error
          : errorMessages.DEFAULT_ERROR

      setServerError(errorMessage)
    } finally {
      setDeactivateAccountModal(false)
    }
  }

  const handleDeactivateAccountClose = () => {
    setDeactivateAccountModal(false)
  }

  const discardHandler = () => {
    reset()
    if (isCandidate) {
      router.push(frontendRoutes.candidate.dashboard)
    } else {
      router.push(frontendRoutes.candidate.list)
    }
  }

  const invalidCandidateDataHandler = async () => {
    setServerError('')
    try {
      await axiosInstance.post('/api/task/invalid-data', {
        assigneeId: user?.personId,
      })
      setEmployeeInformed(true)
    } catch (error) {
      const errorMessage =
        error instanceof AxiosError
          ? error.response?.data?.error
          : errorMessages.DEFAULT_ERROR

      setServerError(errorMessage)
    } finally {
      router.push(frontendRoutes.candidate.dashboard)
    }
  }

  const correctDataHandlerCandidate = async () => {
    try {
      const response = await axiosInstance.post(
        `/api/candidate/correct-data/${candidateId}`,
        {
          correct: true,
        },
      )

      if (response.status === 200) {
        setCorrectData(response.data.correct)
      }
    } catch (error) {}
  }

  const correctDataHandlerEmployee = async () => {
    try {
      const response = await axiosInstance.post(
        `/api/candidate/correct-data/${candidateId}`,
        {
          correct: false,
        },
      )

      if (response.status === 200) {
        setCorrectData(response.data.correct)
      }
    } catch (error) {}
  }

  const userRoles = getUserRoles(user)

  const canDelete = (userRoles: string[]) => {
    return userRoles.includes('subjectAdmin')
  }
  const deletePermission: boolean = canDelete(userRoles)

  const anyChangePermissionFunction = (userRoles: string[]) => {
    return (
      userRoles.includes('subjectAdmin') ||
      userRoles.includes('subjectSupervision')
    )
  }

  const anyChangePermission: boolean = anyChangePermissionFunction(userRoles)

  return (
    <>
      <DeactivateAccount
        open={deactivateAccountModal}
        onClose={handleDeactivateAccountClose}
        onDeactivate={deactivateAccount}
        confirmLabel={
          isDeactivated
            ? tScoped('Reactivate Account')
            : tScoped('Deactivate Account')
        }
        isDeactivated={isDeactivated}
      />
      <DeleteAccount
        open={deleteModal}
        onClose={handleDeleteAccountModalClose}
        onDelete={deleteAccount}
      />
      <Box component="form" onSubmit={handleSubmit(updateCandidateHandler)}>
        <Grid container justifyContent="space-between" mb={25}>
          <Grid item display="flex" alignItems="flex-end" gap={10}>
            <Typography variant="h1" mb={0}>
              {tScoped('Data Check')}
            </Typography>
          </Grid>
          <Grid item>
            <CustomButton
              icon
              label
              labelText={tDashboardScoped('Back')}
              iconName="arrowLeft"
              onClick={() => router.back()}
            />
          </Grid>
        </Grid>
        <Box sx={{ display: 'flex' }}>
          <Typography variant="h2" mb={15}>
            {tScoped('Master Data')}
          </Typography>

          <Box
            sx={{
              marginLeft: 'auto',
            }}
          >
            {user?.role === Role.Employee &&
            deletePermission &&
            anyChangePermission ? (
              <CustomButton
                label
                labelText={tScoped('Delete')}
                sx={{ width: '200px' }}
                variant="contained"
                onClick={handleDeleteAccountModalOpen}
              />
            ) : null}

            {user?.role === Role.Employee && anyChangePermission ? (
              <Button
                sx={{
                  ml: '20px',
                }}
                label
                labelText={
                  user?.role === Role.Employee
                    ? isDeactivated
                      ? tScoped('Reactivate Account')
                      : tScoped('Deactivate Account')
                    : isDeactivated
                      ? tScoped('Deactivated')
                      : tScoped('Deactivate Account')
                }
                onClick={onDeactivateAccount}
                disabled={isDeactivated && user?.role !== Role.Employee}
              ></Button>
            ) : null}
            <Button
              sx={{
                ml: '20px',
              }}
              icon
              label
              labelText={tScoped('History')}
              onClick={() => router.push(`/history/${candidateData?.personId}`)}
            />
          </Box>
        </Box>

        <Box mb={7}>
          <Grid container spacing={10}>
            <Grid item xs={3}>
              <RHFAutocompleteField
                control={control}
                options={appellations?.map((item) => {
                  return {
                    id: item.listId,
                    label: item.listValue,
                  }
                })}
                name="appellationId"
                label={tScoped('Appellation')}
                readOnly={!isEmployee}
              />
            </Grid>
            <Grid item xs={3}>
              <InputField
                control={control}
                name="title"
                label={tScoped('Title')}
                readOnly={!isEmployee}
              />
            </Grid>
          </Grid>
        </Box>

        <Box mb={10}>
          <Grid container spacing={10}>
            <Grid item xs={6}>
              <InputField
                label={tScoped('First Name')}
                control={control}
                name="firstName"
                rules={{
                  required: {
                    value: true,
                    message: validationMessages.required,
                  },
                }}
                error={!!errors?.firstName}
                helperText={errors?.firstName?.message}
                fullWidth
                readOnly={!isEmployee}
              />
            </Grid>
            <Grid item xs={6}>
              <InputField
                label={tScoped('Last Name')}
                control={control}
                name="lastName"
                rules={{
                  required: {
                    value: true,
                    message: validationMessages.required,
                  },
                }}
                error={!!errors?.lastName}
                helperText={errors?.lastName?.message}
                fullWidth
                readOnly={!isEmployee}
              />
            </Grid>
          </Grid>
        </Box>

        <Box mb={10}>
          <Grid container spacing={10}>
            <Grid item xs={6}>
              <InputField
                label={tScoped('Street & House Number')}
                control={control}
                name="streetAndHouseNo"
                error={!!errors.streetAndHouseNo}
                helperText={errors.streetAndHouseNo?.message}
                fullWidth
              />
            </Grid>
            <Grid item xs={6}>
              <InputField
                label={tScoped('Postal Code')}
                control={control}
                name="postalCode"
                error={!!errors?.postalCode}
                helperText={errors?.postalCode?.message}
                fullWidth
              />
            </Grid>
          </Grid>
        </Box>

        <Box mb={10}>
          <Grid container spacing={10}>
            <Grid item xs={6}>
              <InputField
                label={tScoped('City')}
                control={control}
                name="city"
                error={!!errors.city}
                helperText={errors.city?.message}
                fullWidth
              />
            </Grid>
            <Grid item xs={6}>
              <InputField
                label={tScoped('Email')}
                name="email"
                control={control}
                error={!!errors?.email}
                helperText={errors?.email?.message}
                fullWidth
                rules={{
                  required: {
                    value: true,
                    message: 'Required and Should be Unique',
                  },
                }}
                readOnly={!isEmployee}
              />
            </Grid>
          </Grid>
        </Box>

        <Box mb={10}>
          <Grid container spacing={10}>
            <Grid item xs={6}>
              <InputField
                label={tScoped('Phone Number')}
                name="phoneNumber"
                control={control}
                error={!!errors?.phoneNumber}
                helperText={errors?.phoneNumber?.message}
                fullWidth
              />
            </Grid>
          </Grid>
        </Box>

        <Box mb={10}>
          <Grid container spacing={10}>
            <Grid item xs={6}>
              <RHFAutocompleteField
                control={control}
                options={longerAbsenceReasons?.map((item) => {
                  return {
                    id: item.listId,
                    label: item.listValue,
                  }
                })}
                name="longerAbsenceReasonId"
                label={tScoped('Longer Absence')}
                readOnly={!isEmployee}
              />
            </Grid>
          </Grid>
        </Box>

        {longerAbsenceReasonId && (
          <Box mb={25}>
            <Grid container spacing={10}>
              <Grid item xs={6} alignItems="center">
                <InputLabel>{tScoped('From')}</InputLabel>
                <CustomDatePicker
                  name="fromDate"
                  control={control}
                  setValue={setValue}
                  clearErrors={clearErrors}
                  setError={setError}
                  dateFormat="dd/MM/yyyy"
                  readOnly={!isEmployee}
                  allowPastDates
                  clearable
                />
              </Grid>
              <Grid item xs={6}>
                <InputLabel>{tScoped('Until')}</InputLabel>
                <CustomDatePicker
                  name="untilDate"
                  control={control}
                  setValue={setValue}
                  clearErrors={clearErrors}
                  setError={setError}
                  dateFormat="dd/MM/yyyy"
                  minSelectableDate={minSelectableDate}
                  readOnly={!isEmployee}
                  allowPastDates
                  clearable
                />
              </Grid>
              <Grid item></Grid>
            </Grid>
          </Box>
        )}

        <Typography variant="h2" mb={15}>
          {tScoped('School Data')}
        </Typography>

        <Box mb={25}>
          <Grid container spacing={10} sx={{ alignItems: 'center' }}>
            <Grid item xs={6}>
              <RHFAutocompleteField
                label={tScoped('School Name')}
                name="schoolId"
                required
                options={schoolList?.map((item) => {
                  return {
                    id: item.schoolId,
                    label: `${item.schoolName} (${item.BSN})`,
                  }
                })}
                control={control}
                readOnly={!isEmployee}
              />
            </Grid>

            {schoolEmail && (
              <Grid item xs={3} sx={{ marginTop: '20px' }}>
                <Typography>{tScoped('E-mail Address')}</Typography>
                <Typography sx={{ fontWeight: 700 }}>{schoolEmail}</Typography>
              </Grid>
            )}
            {schoolPhone && (
              <Grid item xs={3} sx={{ marginTop: '20px' }}>
                <Typography>{tScoped('Phone Number')}</Typography>
                <Typography sx={{ fontWeight: 700 }}>{schoolPhone}</Typography>
              </Grid>
            )}
          </Grid>
        </Box>

        <Typography variant="h2" mb={15}>
          {tScoped('Training Details')}
        </Typography>

        <Box mb={10}>
          <Grid container spacing={10}>
            <Grid item xs={6} container alignItems="center">
              <Grid container>
                <Grid item xs={3}>
                  <CustomCheckbox
                    label={tScoped('KICK-OFF')}
                    control={control}
                    name="phasePreference.kickOff"
                    readOnly={!isEmployee}
                    onChange={onCheckBoxChangeHandler}
                  />
                </Grid>
                <Grid item xs={3}>
                  <CustomCheckbox
                    label={tScoped('FIRST STEPS')}
                    control={control}
                    readOnly={!isEmployee}
                    name="phasePreference.firstStep"
                    onChange={onCheckBoxChangeHandler}
                  />
                </Grid>
                <Grid item xs={3}>
                  <CustomCheckbox
                    label={tScoped('SETUP')}
                    control={control}
                    name="phasePreference.setUp"
                    readOnly={!isEmployee}
                    onChange={onCheckBoxChangeHandler}
                  />
                </Grid>
                <Grid item xs={3}>
                  <CustomCheckbox
                    label={tScoped('STUDIES')}
                    control={control}
                    name="phasePreference.studies"
                    readOnly={!isEmployee}
                    onChange={onCheckBoxChangeHandler}
                  />
                </Grid>
              </Grid>
            </Grid>

            <Grid item xs={6}>
              <InputLabel>{tScoped('bbVD-start')}</InputLabel>
              <CustomDatePicker
                name="bbvdStart"
                control={control}
                setValue={setValue}
                clearErrors={clearErrors}
                setError={setError}
                dateFormat="dd/MM/yyyy"
                allowPastDates
                required
                readOnly={!isEmployee}
              />
            </Grid>
          </Grid>
        </Box>

        <Box mb={10}>
          <Grid container spacing={10}>
            <Grid item xs={6}>
              <InputLabel>{tScoped('bbST-start')}</InputLabel>
              <CustomDatePicker
                name="bbstStart"
                control={control}
                setValue={setValue}
                clearErrors={clearErrors}
                setError={setError}
                dateFormat="dd/MM/yyyy"
                allowPastDates
                readOnly={!isEmployee}
              />
            </Grid>
            <Grid item xs={6}>
              <InputField
                label={tScoped('Start School Year')}
                name="startSchoolYear"
                control={control}
                fullWidth
                rules={{
                  required: {
                    value: true,
                    message: validationMessages.required,
                  },
                }}
                readOnly={!isEmployee}
              />
            </Grid>
          </Grid>
        </Box>

        <Box mb={10}>
          <Grid container spacing={10}>
            <Grid item xs={6}>
              <RHFAutocompleteField
                label={tScoped('Year Group')}
                name="yearGroupId"
                control={control}
                options={yearGroups?.map((item) => {
                  return {
                    id: item.listId,
                    label: item.listValue,
                  }
                })}
                readOnly={!isEmployee}
              />
            </Grid>
            <Grid item xs={6}>
              <RHFAutocompleteField
                label={tScoped('Kick Off Group')}
                name="kickOffGroupId"
                control={control}
                options={kickOffs?.map((item) => {
                  return {
                    id: item.listId,
                    label: item.listValue,
                  }
                })}
                readOnly={!isEmployee}
              />
            </Grid>
          </Grid>
        </Box>

        <Box mb={25}>
          <Grid container spacing={10}>
            <Grid item xs={6}>
              <InputLabel>{tScoped('Start of Contract')}</InputLabel>
              <CustomDatePicker
                name="startOfContract"
                control={control}
                setValue={setValue}
                clearErrors={clearErrors}
                setError={setError}
                dateFormat="dd/MM/yyyy"
                allowPastDates
                readOnly={!isEmployee}
              />
            </Grid>
          </Grid>
        </Box>

        <Typography variant="h2" mb={15}>
          {tScoped('Study Information')}
        </Typography>

        <Box mb={10}>
          <Grid container spacing={10}>
            <Grid item xs={6}>
              <RHFAutocompleteField
                name="teachingPositionId"
                label={tScoped('Teaching Position')}
                options={teachingPositions?.map((item) => {
                  return {
                    id: item.listId,
                    label: item.listValue,
                  }
                })}
                control={control}
                required
              />
            </Grid>
            {teachingPositionId !== vocationalId && (
              <Grid item xs={6}>
                <RHFAutocompleteField
                  label={tScoped('1. recognised subject')}
                  name="firstRecognisedSubjectId"
                  options={firstRecognisedSubjects?.map((item) => {
                    return {
                      id: item.listId,
                      label: item.listValue,
                    }
                  })}
                  control={control}
                  required
                  readOnly={!isEmployee}
                />
              </Grid>
            )}
            {teachingPositionId === vocationalId && (
              <Grid item xs={6}>
                <InputField
                  label={tScoped('Recognised Subject')}
                  control={control}
                  name="recognisedSubject"
                  rules={{
                    required: {
                      value: true,
                      message: validationMessages.required,
                    },
                  }}
                  error={!!errors.recognisedSubject}
                  helperText={errors.recognisedSubject?.message}
                  fullWidth
                  readOnly={!isEmployee}
                />
              </Grid>
            )}
          </Grid>
        </Box>

        {teachingPositionId !== vocationalId && (
          <Box mb={10}>
            <Grid container spacing={10}>
              <Grid item xs={6}>
                <RHFAutocompleteField
                  label={tScoped('2. recognised subject')}
                  name="secondRecognisedSubjectId"
                  options={secondRecognisedSubjects?.map((item) => {
                    return {
                      id: item.listId,
                      label: item.listValue,
                    }
                  })}
                  control={control}
                  readOnly={!isEmployee}
                />
              </Grid>
              <Grid item xs={6}>
                <RHFAutocompleteField
                  label={tScoped('3. recognised subject')}
                  name="thirdRecognisedSubjectId"
                  options={thirdRecognisedSubjects?.map((item) => {
                    return {
                      id: item.listId,
                      label: item.listValue,
                    }
                  })}
                  control={control}
                  readOnly={!isEmployee}
                />
              </Grid>
            </Grid>
          </Box>
        )}

        <Box mb={10}>
          <Grid container spacing={10}>
            <Grid item xs={6}>
              <RHFAutocompleteField
                label={tScoped('1. Subject to be studied')}
                name="firstSubjectToBeStudiedId"
                options={firstSubjectToBeStudied?.map((item) => {
                  return {
                    id: item.listId,
                    label: item.listValue,
                  }
                })}
                control={control}
                readOnly={!isEmployee}
              />
            </Grid>
            <Grid item xs={6}>
              <RHFAutocompleteField
                label={tScoped('2. Subject to be studied')}
                name="secondSubjectToBeStudiedId"
                options={secondSubjectToBeStudied?.map((item) => {
                  return {
                    id: item.listId,
                    label: item.listValue,
                  }
                })}
                control={control}
              />
            </Grid>
          </Grid>
        </Box>

        <Box mb={10}>
          <Grid container spacing={10}>
            <Grid item xs={6}>
              <RHFAutocompleteField
                label={tScoped('Start Subject A')}
                name="startSubjectAId"
                options={startSubjectA?.map((item) => {
                  return {
                    id: item.listId,
                    label: item.listValue,
                  }
                })}
                control={control}
                readOnly={!isEmployee}
              />
            </Grid>
            <Grid item xs={6}>
              <RHFAutocompleteField
                label={tScoped('Start Subject B')}
                name="startSubjectBId"
                options={startSubjectB?.map((item) => {
                  return {
                    id: item.listId,
                    label: item.listValue,
                  }
                })}
                control={control}
              />
            </Grid>
          </Grid>
        </Box>

        <Box mb={10}>
          <Grid container spacing={10}>
            <Grid item xs={6}>
              <RHFAutocompleteField
                label={tScoped('Studies Group Subject A')}
                name="studiesGroupSubjectAId"
                options={studiesGroupSubjectA?.map((item) => {
                  return {
                    id: item.listId,
                    label: item.listValue,
                  }
                })}
                control={control}
              />
            </Grid>
            <Grid item xs={6}>
              <RHFAutocompleteField
                label={tScoped('Studies Group Subject B')}
                name="studiesGroupSubjectBId"
                options={studiesGroupSubjectB?.map((item) => {
                  return {
                    id: item.listId,
                    label: item.listValue,
                  }
                })}
                control={control}
              />
            </Grid>
          </Grid>
        </Box>

        <Box mb={10}>
          <Grid container spacing={10}>
            <Grid item xs={6}>
              <RHFAutocompleteField
                label={tScoped('Subject change from')}
                name="subjectChangeFromId"
                options={subjectChangeFrom?.map((item) => {
                  return {
                    id: item.listId,
                    label: item.listValue,
                  }
                })}
                control={control}
                readOnly={!isEmployee}
              />
            </Grid>
            <Grid item xs={6}>
              <RHFAutocompleteField
                label={tScoped('Subject change to')}
                name="subjectChangeToId"
                options={subjectChangeTo?.map((item) => {
                  return {
                    id: item.listId,
                    label: item.listValue,
                  }
                })}
                control={control}
                readOnly={!isEmployee}
              />
            </Grid>
          </Grid>
        </Box>

        {isEmployee && (
          <Box mb={25}>
            <Grid item xs={12}>
              <RHFTextArea
                label={tScoped('Comments')}
                control={control}
                name="comments"
              />
            </Grid>
          </Box>
        )}

        {isEmployee && !user.householdAdmin && !user.departmentLead && (
          <Box mb={25}>
            <Grid container spacing={0}>
              <AddAttachment
                sx={{ marginRight: 'auto' }}
                currentFiles={currentFile}
                fileUploading={fileUploading}
                setCurrentFiles={setCurrentFile}
                uploadedAttachments={
                  uploadedAttachments ? [uploadedAttachments] : []
                }
                setUploadedAttachments={setUploadedAttachments}
                labelText={tScoped('Upload Document')}
                iconName="upload"
              />
            </Grid>
          </Box>
        )}

        {!correctData && isCandidate && (
          <>
            <Typography variant="h2" textAlign="center">
              {tScoped('Is your data correct?')}
            </Typography>
            <Box>
              <Grid container spacing={10} justifyContent="center" mb={25}>
                <Grid item>
                  <Button
                    label
                    labelText={tScoped('No')}
                    sx={{ minWidth: '200px' }}
                    onClick={invalidCandidateDataHandler}
                  />
                </Grid>

                <Grid item>
                  <Button
                    label
                    labelText={tScoped('Yes')}
                    sx={{ minWidth: '200px' }}
                    variant="contained"
                    onClick={correctDataHandlerCandidate}
                  />
                </Grid>
              </Grid>
            </Box>
          </>
        )}
        {
          <Box mb={25}>
            <Grid container spacing={10}>
              <Grid item xs={6} container sx={{ justifyContent: 'end' }}>
                <CustomButton
                  label
                  labelText={tScoped('Discard')}
                  sx={{ width: '200px' }}
                  disabled={
                    isCandidate ? false : anyChangePermission ? false : true
                  }
                  onClick={() => discardHandler()}
                />
              </Grid>
              <Grid item xs={6}>
                <CustomButton
                  label
                  labelText={tScoped('Save')}
                  sx={{ width: '200px' }}
                  variant="contained"
                  type="submit"
                  disabled={
                    isCandidate ? false : anyChangePermission ? false : true
                  }
                  loading={submitLoading}
                />
              </Grid>
            </Grid>
          </Box>
        }
      </Box>

      {serverError !== '' ? (
        <Toast message={serverError} severity="error" />
      ) : null}
      {candidateUpdated ? (
        <Toast message={successMessages.candidateUpdated} severity="success" />
      ) : null}
      {employeeInformed ? (
        <Toast
          message={successMessages.candidateMarkedInvalidData}
          severity="success"
        />
      ) : null}
      {candidateDeleted ? (
        <Toast
          message={successMessages.candidateDeleteSuccess}
          severity="success"
        />
      ) : null}
    </>
  )
}

export default CreateCandidate
