'use client'

import { useContext, useEffect, useState } from 'react'
import { Grid, Typography } from '@mui/material'

import CustomButton from '@/components/Buttons/CustomButton'
import { useRouter } from 'next/navigation'
import { UserContext } from '@/contexts/userContext'
import { frontendRoutes } from '@/utils/constants/frontend'
import TasksComponent from '@/components/Tasks'
import { useI18n, useScopedI18n } from '../../../../../locales/client'
import axiosInstance from '@/services/axiosInstance'

const Candidate = () => {
  const t = useI18n()
  const tScoped = useScopedI18n('candidate')
  const [userName, setUserName] = useState<string>('')
  const router = useRouter()
  const { user } = useContext(UserContext)

  const [candidateId, setCandidateId] = useState<number | null>(null)

  const getCandidateId = async () => {
    const response = await axiosInstance.post(`/api/candidate/getCandidateId`)
    setCandidateId(response.data.candidateId)
  }

  useEffect(() => {
    if (user) {
      getCandidateId()
    }
  }, [user])

  useEffect(() => {
    if (user?.firstName) {
      setUserName(`${user?.firstName} ${user?.lastName ?? ''}`)
    }
  }, [])

  return (
    <>
      <Typography variant="h1" mb={10} sx={{ textTransform: 'capitalize' }}>
        {t('hello')} {userName}
      </Typography>

      <Typography variant="h2" mb={10}>
        {tScoped('Overview')}
      </Typography>

      <Grid container spacing={8} mb={50}>
        <Grid item xs={4} md={3}>
          <CustomButton
            label={true}
            labelText={tScoped('Master Data')}
            icon={true}
            fullWidth
            onClick={() =>
              router.push(`${frontendRoutes.candidate.data}/${candidateId}`)
            }
          />
        </Grid>

        <Grid item xs={4} md={3}>
          <CustomButton
            label={true}
            labelText={tScoped('Communication')}
            icon={true}
            fullWidth
            onClick={() => router.push('/communication-candidate')}
          />
        </Grid>

        <Grid item xs={4} md={3}>
          <CustomButton
            label={true}
            labelText={tScoped('History')}
            icon={true}
            fullWidth
            onClick={() => router.push(`/history/${user?.personId}`)}
          />
        </Grid>
      </Grid>

      <TasksComponent isDashboard={true} />
    </>
  )
}

export default Candidate
