'use client'
import { ICreateCandidate } from '@/app/api/candidate/create-candidate/route'
import AddAttachment from '@/components/Buttons/AddAttachment'
import CustomButton from '@/components/Buttons/CustomButton'
import CustomCheckbox from '@/components/Buttons/CustomCheckbox'
import CustomDatePicker from '@/components/DatePicker'
import { RHFAutocompleteField } from '@/components/DropDown'
import InputField from '@/components/InputField'
import { RHFTextArea } from '@/components/TextArea'
import Toast from '@/components/Toast'
import { IList, ISchoolInterface, IToastData } from '@/interface/common'
import axiosInstance from '@/services/axiosInstance'
import { phasesOptions } from '@/utils/constants'
import { errorMessages } from '@/utils/errorMessages'
import { successMessages } from '@/utils/successMessages'
import { validators } from '@/validators'
import { validationMessages } from '@/validators/messages'
import {
  Box,
  FormHelperText,
  Grid,
  InputLabel,
  LinearProgress,
  Typography,
} from '@mui/material'
import { AxiosError, AxiosResponse } from 'axios'
import moment from 'moment'
import { useRouter } from 'next/navigation'
import { useEffect, useState } from 'react'
import { SubmitHandler, useForm } from 'react-hook-form'
import { useScopedI18n } from '../../../../../locales/client'

const CreateCandidate: React.FC = () => {
  const tScoped = useScopedI18n('candidate')
  const tDashboardScoped = useScopedI18n('dashboard')
  const [appellations, setAppellations] = useState<IList>([])
  const [longerAbsenceReasons, setLongerAbsenceReasons] = useState<IList>([])
  const [teachingPositions, setTeachingPositions] = useState<IList>([])
  const [yearGroups, setYearGroups] = useState<IList>([])
  const [kickOffs, setKickOffs] = useState<IList>([])
  const [schoolList, setSchoolList] = useState<ISchoolInterface[]>([])
  const [serverError, setServerError] = useState<string>('')
  const [candidateCreated, setCandidateCreated] = useState<boolean>(false)
  const [loading, setLoading] = useState<boolean>(false)
  const [toastData, setToastData] = useState<IToastData>({
    type: undefined,
    message: '',
  })
  const [submitLoading, setSubmitLoading] = useState<boolean>(false)

  const [schoolEmail, setSchoolEmail] = useState<string>('')
  const [schoolPhone, setSchoolPhone] = useState<string>('')

  const [currentFiles, setCurrentFiles] = useState<FileList | null>(null)
  const [fileUploading, setFileUploading] = useState<boolean>(false)

  const [firstRecognisedSubjects, setFirstRecognisedSubjects] = useState<IList>(
    [],
  )
  const [secondRecognisedSubjects, setSecondRecognisedSubjects] =
    useState<IList>([])
  const [thirdRecognisedSubjects, setThirdRecognisedSubjects] = useState<IList>(
    [],
  )
  const [firstSubjectToBeStudied, setFirstSubjectToBeStudied] = useState<IList>(
    [],
  )
  const [secondSubjectToBeStudied, setSecondSubjectToBeStudied] =
    useState<IList>([])
  const [subjectChangeFrom, setSubjectChangeFrom] = useState<IList>([])
  const [subjectChangeTo, setSubjectChangeTo] = useState<IList>([])
  const [studiesGroupSubjectA, setStudiesGroupSubjectA] = useState<IList>([])
  const [studiesGroupSubjectB, setStudiesGroupSubjectB] = useState<IList>([])
  const [startSubjectA, setStartSubjectA] = useState<IList>([])
  const [startSubjectB, setStartSubjectB] = useState<IList>([])
  const [vocationalId, setVocationalId] = useState<number | null>(null)

  const router = useRouter()

  const methods = useForm<ICreateCandidate>({
    mode: 'all',
    shouldFocusError: true,
  })
  const {
    handleSubmit,
    formState: { errors },
    control,
    clearErrors,
    setValue,
    setError,
    watch,
    reset,
    resetField,
  } = methods

  const fromDate = watch('fromDate')
  const longerAbsenceReasonId = watch('longerAbsenceReasonId')
  const selectedSchool = watch('schoolId')

  const teachingPositionId = watch('teachingPositionId')

  useEffect(() => {
    if (teachingPositions.length) {
      const vocational = teachingPositions.filter(
        (teachingPosition) =>
          teachingPosition.listValue === 'Lehramt an Beruflichen Schulen',
      )
      setVocationalId(vocational[0].listId)
    }
  }, [teachingPositions])

  const getAllLists = async () => {
    try {
      const listsFromApi = await axiosInstance.post('/api/list', {
        listTypes: [
          'teachingPosition',
          'longerAbsenceReason',
          'yearGroup',
          'phase',
          'kickOffGroup',
          'subject',
          'schoolType',
          'person',
          'appellation',
          'gender',
          'firstRecognisedSubject',
          'secondRecognisedSubject',
          'thirdRecognisedSubject',
          'firstSubjectToBeStudied',
          'secondSubjectToBeStudied',
          'subjectChangeFrom',
          'subjectChangeTo',
          'studiesGroupSubjectA',
          'studiesGroupSubjectB',
          'startSubjectA',
          'startSubjectB',
        ],
      })

      setKickOffs(listsFromApi.data.data.kickOffGroup)
      setYearGroups(listsFromApi.data.data.yearGroup)
      setAppellations(listsFromApi.data.data.appellation)
      setTeachingPositions(listsFromApi.data.data.teachingPosition)
      setLongerAbsenceReasons(listsFromApi.data.data.longerAbsenceReason)
      setFirstRecognisedSubjects(listsFromApi.data.data.firstRecognisedSubject)
      setSecondRecognisedSubjects(
        listsFromApi.data.data.secondRecognisedSubject,
      )
      setThirdRecognisedSubjects(listsFromApi.data.data.thirdRecognisedSubject)
      setFirstSubjectToBeStudied(listsFromApi.data.data.firstSubjectToBeStudied)
      setSecondSubjectToBeStudied(
        listsFromApi.data.data.secondSubjectToBeStudied,
      )
      setSubjectChangeFrom(listsFromApi.data.data.subjectChangeFrom)
      setSubjectChangeTo(listsFromApi.data.data.subjectChangeTo)
      setStudiesGroupSubjectA(listsFromApi.data.data.studiesGroupSubjectA)
      setStudiesGroupSubjectB(listsFromApi.data.data.studiesGroupSubjectB)
      setStartSubjectA(listsFromApi.data.data.startSubjectA)
      setStartSubjectB(listsFromApi.data.data.startSubjectB)
    } catch (error) {
      if (error instanceof Error) {
        setToastData({
          type: 'error',
          message: error?.message || errorMessages.DEFAULT_ERROR,
        })
      }
    }
  }

  const getSchoolLists = async () => {
    const schoolListFromApi = await axiosInstance.post('/api/school', {
      all: true,
    })
    setSchoolList(schoolListFromApi.data.schoolList)
  }

  useEffect(() => {
    try {
      getAllLists()
      getSchoolLists()
    } catch (error) {
      if (error instanceof Error) {
        setToastData({
          type: 'error',
          message: error?.message || errorMessages.DEFAULT_ERROR,
        })
      }
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    setTimeout(() => {
      setToastData({
        type: undefined,
        message: '',
      })
    }, 5000)
  }, [JSON.stringify(toastData)])

  useEffect(() => {
    if (!longerAbsenceReasonId) {
      resetField('fromDate')
      resetField('untilDate')
    }
  }, [longerAbsenceReasonId])

  useEffect(() => {
    if (selectedSchool) {
      const selectedSchoolDetails = schoolList.find(
        (school) => school.schoolId === selectedSchool,
      )
      if (selectedSchoolDetails) {
        setSchoolEmail(selectedSchoolDetails.emailAddress)
        setSchoolPhone(selectedSchoolDetails.phoneNumber)
      }
    }
  }, [selectedSchool])

  const createCandidateHandler: SubmitHandler<ICreateCandidate> = async (
    payload,
  ) => {
    try {
      setServerError('')
      if (
        payload.longerAbsenceReasonId &&
        !payload.fromDate &&
        !payload.untilDate
      ) {
        setError(
          'fromDate',
          { type: 'custom', message: 'Enter From Date' },
          { shouldFocus: true },
        )
        setError(
          'untilDate',
          { type: 'custom', message: 'Enter Until Date' },
          { shouldFocus: true },
        )
        throw new Error('Enter From Date and Until Date')
      }

      let responseFromFileServer: AxiosResponse | null = null

      const formData = new FormData()
      if (currentFiles) {
        setFileUploading(true)
        formData.append('file', currentFiles[0])
        responseFromFileServer = await axiosInstance.post(
          '/api/upload',
          formData,
        )

        if (responseFromFileServer && responseFromFileServer.status === 201) {
          setFileUploading(false)
        } else {
          throw new Error(errorMessages.FAILED_TO_UPLOAD_ATTACHMENT)
        }
      }

      if (
        !Object.values(payload.phasePreference).some((value) => value === true)
      ) {
        setSubmitLoading(false)
        setError('phasePreference', {
          message: 'Select at lease one preference',
        })
        setServerError('Select Atleast One Phase')
        return
      }
      const data = {
        ...payload,
        fromDate: payload.fromDate
          ? moment(payload.fromDate, 'DD/MM/YYYY').toDate()
          : null,
        phaseRequiredId: phasesOptions.find(
          (phase) =>
            phase.firstStep === payload.phasePreference.firstStep &&
            phase.kickOff === payload.phasePreference.kickOff &&
            phase.setUp === payload.phasePreference.setUp &&
            phase.studies === payload.phasePreference.studies,
        )?.id,
        document: responseFromFileServer?.data.responseData[0].fileName ?? '',
      }

      const response = await axiosInstance.post(
        '/api/candidate/create-candidate',
        {
          data,
        },
      )

      if (response.status === 201) {
        setCandidateCreated(true)
        reset()
        router.replace('/candidate')
      }
    } catch (error) {
      console.log(error, 'Eroror')
      setSubmitLoading(false)
      let errorMessage = errorMessages.DEFAULT_ERROR

      if (error instanceof AxiosError) {
        if (error.response?.status === 409) {
          errorMessage =
            error.response.data?.message || errorMessages.DUPLICATE_EMAIL
        } else if (error.response?.status === 400) {
          errorMessage = errorMessages.DEFAULT_ERROR
        } else if (error.response?.status === 404) {
          errorMessage = errorMessages.NO_DATA_FOUND
        }
        // Add more conditions for different error status codes if needed
      }

      setServerError(errorMessage)
    }
  }

  const discardHandler = () => {
    reset()
    router.push('/candidate')
  }

  const onCheckBoxChangeHandler = async (checked?: boolean) => {
    const selectedPhases = watch('phasePreference')

    if (!Object.values(selectedPhases).some((value) => value === true)) {
      clearErrors('phasePreference')
    }

    if (checked) {
      clearErrors('phasePreference')
    }

    if (!checked) {
      setServerError('Select Phase')
    }
  }

  const minSelectableDate = fromDate
    ? moment(fromDate).add(0, 'days').toDate()
    : undefined

  if (loading) {
    return (
      <Box
        sx={{
          position: 'fixed',
          top: 0,
          left: 0,
          width: '100%',
          zIndex: 9999,
        }}
      >
        <LinearProgress />
      </Box>
    )
  }

  return (
    <>
      <Box
        component="form"
        onSubmit={handleSubmit(createCandidateHandler)}
        autoComplete="off"
      >
        <Grid container justifyContent="space-between" mb={25}>
          <Grid item display="flex" alignItems="flex-end" gap={10}>
            <Typography variant="h1" mb={0}>
            {tScoped('Create Candidate')}
            </Typography>
          </Grid>
          <Grid item>
            <CustomButton
              icon
              label
              labelText={tDashboardScoped('Back')}
              iconName="arrowLeft"
              onClick={() => router.back()}
            />
          </Grid>
        </Grid>
        <Typography variant="h2" mb={15}>
          {tScoped('Master Data')}
        </Typography>

        <Box mb={7}>
          <Grid container spacing={10}>
            <Grid item xs={3}>
              <RHFAutocompleteField
                control={control}
                options={appellations?.map((item) => {
                  return {
                    id: item.listId,
                    label: item.listValue,
                  }
                })}
                name="appellationId"
                label={tScoped('Appellation')}
              />
            </Grid>
            <Grid item xs={3}>
              <InputField
                control={control}
                name="title"
                label={tScoped('Title')}
              />
            </Grid>
          </Grid>
        </Box>

        <Box mb={10}>
          <Grid container spacing={10}>
            <Grid item xs={6}>
              <InputField
                label={tScoped('First Name')}
                control={control}
                name="firstName"
                rules={{
                  required: {
                    value: true,
                    message: validationMessages.required,
                  },
                }}
                error={!!errors.firstName}
                helperText={errors.firstName?.message}
                fullWidth
              />
            </Grid>
            <Grid item xs={6}>
              <InputField
                label={tScoped('Last Name')}
                control={control}
                name="lastName"
                rules={{
                  required: {
                    value: true,
                    message: validationMessages.required,
                  },
                }}
                error={!!errors.lastName}
                helperText={errors.lastName?.message}
                fullWidth
              />
            </Grid>
          </Grid>
        </Box>

        <Box mb={10}>
          <Grid container spacing={10}>
            <Grid item xs={6}>
              <InputField
                label={tScoped('Street & House Number')}
                control={control}
                name="streetAndHouseNo"
                error={!!errors.streetAndHouseNo}
                helperText={errors.streetAndHouseNo?.message}
                fullWidth
              />
            </Grid>
            <Grid item xs={6}>
              <InputField
                label={tScoped('Postal Code')}
                control={control}
                name="postalCode"
                rules={{
                  pattern: {
                    value: validators.number,
                    message: validationMessages.onlyNumbers,
                  },
                }}
                error={!!errors.postalCode}
                helperText={errors.postalCode?.message}
                fullWidth
              />
            </Grid>
          </Grid>
        </Box>

        <Box mb={10}>
          <Grid container spacing={10}>
            <Grid item xs={6}>
              <InputField
                label={tScoped('City')}
                control={control}
                name="city"
                error={!!errors.city}
                helperText={errors.city?.message}
                fullWidth
              />
            </Grid>
            <Grid item xs={6}>
              <InputField
                label={tScoped('Email')}
                name="email"
                control={control}
                rules={{
                  required: {
                    value: true,
                    message: 'Required and Should be Unique',
                  },
                  pattern: {
                    value: validators.email,
                    message: validationMessages.validEmail,
                  },
                }}
                error={!!errors.email}
                helperText={errors.email?.message}
                fullWidth
              />
            </Grid>
          </Grid>
        </Box>

        <Box mb={10}>
          <Grid container spacing={10}>
            <Grid item xs={6}>
              <InputField
                label={tScoped('Phone Number')}
                name="phoneNumber"
                control={control}
                rules={{
                  pattern: {
                    value: validators.phoneNumber,
                    message: validationMessages.onlyNumbers,
                  },
                }}
                error={!!errors.phoneNumber}
                helperText={errors.phoneNumber?.message}
                fullWidth
              />
            </Grid>
          </Grid>
        </Box>

        <Box mb={10}>
          <Grid container spacing={10}>
            <Grid item xs={6}>
              <RHFAutocompleteField
                control={control}
                options={longerAbsenceReasons?.map((item) => {
                  return {
                    id: item.listId,
                    label: item.listValue,
                  }
                })}
                name="longerAbsenceReasonId"
                label={tScoped('Longer Absence')}
              />
            </Grid>
          </Grid>
        </Box>

        {longerAbsenceReasonId && (
          <Box mb={25}>
            <Grid container spacing={10}>
              <Grid item xs={6} alignItems="center">
                <InputLabel>{tScoped('From')}</InputLabel>
                <CustomDatePicker
                  name="fromDate"
                  control={control}
                  setValue={setValue}
                  clearErrors={clearErrors}
                  setError={setError}
                  dateFormat="dd/MM/yyyy"
                  allowPastDates
                  clearable
                />
              </Grid>
              <Grid item xs={6}>
                <InputLabel>{tScoped('Until')}</InputLabel>
                <CustomDatePicker
                  name="untilDate"
                  control={control}
                  setValue={setValue}
                  clearErrors={clearErrors}
                  setError={setError}
                  dateFormat="dd/MM/yyyy"
                  minSelectableDate={minSelectableDate}
                  allowPastDates
                  clearable
                />
              </Grid>
              <Grid item></Grid>
            </Grid>
          </Box>
        )}

        <Typography variant="h2" mb={15}>
          {tScoped('School Data')}
        </Typography>

        <Box mb={25}>
          <Grid container spacing={10} sx={{ alignItems: 'center' }}>
            <Grid item xs={6}>
              <RHFAutocompleteField
                label={tScoped('School Name')}
                name="schoolId"
                required
                options={schoolList?.map((item) => {
                  return {
                    id: item.schoolId,
                    label: `${item.schoolName} (${item.BSN})`,
                  }
                })}
                control={control}
              />
            </Grid>

            {schoolEmail && (
              <Grid item xs={3} sx={{ marginTop: '20px' }}>
                <Typography>{tScoped('E-mail Address')}</Typography>
                <Typography sx={{ fontWeight: 700 }}>{schoolEmail}</Typography>
              </Grid>
            )}
            {schoolPhone && (
              <Grid item xs={3} sx={{ marginTop: '20px' }}>
                <Typography>{tScoped('Phone Number')}</Typography>
                <Typography sx={{ fontWeight: 700 }}>{schoolPhone}</Typography>
              </Grid>
            )}
          </Grid>
        </Box>

        <Typography variant="h2" mb={15}>
          {tScoped('Training Details')}
        </Typography>

        <Box mb={10}>
          <Grid container spacing={10}>
            <Grid item xs={6} container alignItems="center">
              <Grid container>
                <Grid item xs={3}>
                  <CustomCheckbox
                    label={tScoped('KICK-OFF')}
                    control={control}
                    name="phasePreference.kickOff"
                    onChange={onCheckBoxChangeHandler}
                  />
                </Grid>
                <Grid item xs={3}>
                  <CustomCheckbox
                    label={tScoped('FIRST STEPS')}
                    control={control}
                    name="phasePreference.firstStep"
                    onChange={onCheckBoxChangeHandler}
                  />
                </Grid>
                <Grid item xs={3}>
                  <CustomCheckbox
                    label={tScoped('SETUP')}
                    control={control}
                    name="phasePreference.setUp"
                    onChange={onCheckBoxChangeHandler}
                  />
                </Grid>
                <Grid item xs={3}>
                  <CustomCheckbox
                    label={tScoped('STUDIES')}
                    control={control}
                    name="phasePreference.studies"
                    onChange={onCheckBoxChangeHandler}
                  />
                </Grid>
                {errors.phasePreference ? (
                  <FormHelperText error>
                    {errors.phasePreference.message}
                  </FormHelperText>
                ) : null}
              </Grid>
            </Grid>

            <Grid item xs={6}>
              <InputLabel>{tScoped('bbVD-start')}</InputLabel>
              <CustomDatePicker
                name="bbvdStart"
                control={control}
                setValue={setValue}
                clearErrors={clearErrors}
                setError={setError}
                dateFormat="dd/MM/yyyy"
                allowPastDates
                required
              />
            </Grid>
          </Grid>
        </Box>

        <Box mb={10}>
          <Grid container spacing={10}>
            <Grid item xs={6}>
              <InputLabel>{tScoped('bbST-start')}</InputLabel>
              <CustomDatePicker
                name="bbstStart"
                control={control}
                setValue={setValue}
                clearErrors={clearErrors}
                setError={setError}
                dateFormat="dd/MM/yyyy"
                allowPastDates
              />
            </Grid>
            <Grid item xs={6}>
              <InputField
                label={tScoped('Start School Year')}
                name="startSchoolYear"
                control={control}
                fullWidth
                rules={{
                  required: {
                    value: true,
                    message: validationMessages.required,
                  },
                  pattern: {
                    value: validators.numericAndSlash,
                    message: 'Please Enter a valid Year',
                  },
                }}
                error={!!errors.startSchoolYear}
                helperText={errors.startSchoolYear?.message}
              />
              {/* <RHFAutocompleteField
                label={tScoped('Year Group')}
                name="yearGroupId"
                control={control}
                options={yearGroups?.map((item) => {
                  return {
                    id: item.listId,
                    label: item.listValue,
                  }
                })}
              /> */}
            </Grid>
          </Grid>
        </Box>

        <Box mb={10}>
          <Grid container spacing={10}>
            <Grid item xs={6}>
              <RHFAutocompleteField
                label={tScoped('Year Group')}
                name="yearGroupId"
                control={control}
                options={yearGroups?.map((item) => {
                  return {
                    id: item.listId,
                    label: item.listValue,
                  }
                })}
              />
              {/* <RHFAutocompleteField
                label={tScoped('Kick Off Group')}
                name="kickOffGroupId"
                control={control}
                options={kickOffs?.map((item) => {
                  return {
                    id: item.listId,
                    label: item.listValue,
                  }
                })}
              /> */}
            </Grid>
            <Grid item xs={6}>
              <RHFAutocompleteField
                label={tScoped('Kick Off Group')}
                name="kickOffGroupId"
                control={control}
                options={kickOffs?.map((item) => {
                  return {
                    id: item.listId,
                    label: item.listValue,
                  }
                })}
              />
              {/* <InputLabel>{tScoped('Start of Contract')}</InputLabel>
              <CustomDatePicker
                name="startOfContract"
                control={control}
                setValue={setValue}
                clearErrors={clearErrors}
                setError={setError}
                dateFormat="dd/MM/yyyy"
                allowPastDates
              /> */}
            </Grid>
          </Grid>
        </Box>

        <Box mb={25}>
          <Grid container spacing={10}>
            <Grid item xs={6}>
              <InputLabel>{tScoped('Start of Contract')}</InputLabel>
              <CustomDatePicker
                name="startOfContract"
                control={control}
                setValue={setValue}
                clearErrors={clearErrors}
                setError={setError}
                dateFormat="dd/MM/yyyy"
                allowPastDates
              />
            </Grid>
          </Grid>
        </Box>

        <Typography variant="h2" mb={15}>
          Study Information
        </Typography>

        <Box mb={10}>
          <Grid container spacing={10}>
            <Grid item xs={6}>
              <RHFAutocompleteField
                name="teachingPositionId"
                label={tScoped('Teaching Position')}
                options={teachingPositions?.map((item) => {
                  return {
                    id: item.listId,
                    label: item.listValue,
                  }
                })}
                control={control}
                required
              />
            </Grid>
            {teachingPositionId !== vocationalId && (
              <Grid item xs={6}>
                <RHFAutocompleteField
                  label={tScoped('1. recognised subject')}
                  name="firstRecognisedSubjectId"
                  options={firstRecognisedSubjects?.map((item) => {
                    return {
                      id: item.listId,
                      label: item.listValue,
                    }
                  })}
                  control={control}
                  required
                />
              </Grid>
            )}
            {teachingPositionId === vocationalId && (
              <Grid item xs={6}>
                <InputField
                  label={tScoped('Recognised Subject')}
                  control={control}
                  name="recognisedSubject"
                  rules={{
                    required: {
                      value: true,
                      message: validationMessages.required,
                    },
                  }}
                  error={!!errors.firstName}
                  helperText={errors.firstName?.message}
                  fullWidth
                />
              </Grid>
            )}
          </Grid>
        </Box>

        {teachingPositionId !== vocationalId && (
          <Box mb={10}>
            <Grid container spacing={10}>
              <Grid item xs={6}>
                <RHFAutocompleteField
                  label={tScoped('2. recognised subject')}
                  name="secondRecognisedSubjectId"
                  options={secondRecognisedSubjects?.map((item) => {
                    return {
                      id: item.listId,
                      label: item.listValue,
                    }
                  })}
                  control={control}
                />
              </Grid>
              <Grid item xs={6}>
                <RHFAutocompleteField
                  label={tScoped('3. recognised subject')}
                  name="thirdRecognisedSubjectId"
                  options={thirdRecognisedSubjects?.map((item) => {
                    return {
                      id: item.listId,
                      label: item.listValue,
                    }
                  })}
                  control={control}
                />
              </Grid>
            </Grid>
          </Box>
        )}

        <Box mb={10}>
          <Grid container spacing={10}>
            <Grid item xs={6}>
              <RHFAutocompleteField
                label={tScoped('1. Subject to be studied')}
                name="firstSubjectToBeStudiedId"
                options={firstSubjectToBeStudied?.map((item) => {
                  return {
                    id: item.listId,
                    label: item.listValue,
                  }
                })}
                control={control}
              />
            </Grid>
            <Grid item xs={6}>
              <RHFAutocompleteField
                label={tScoped('2. Subject to be studied')}
                name="secondSubjectToBeStudiedId"
                options={secondSubjectToBeStudied?.map((item) => {
                  return {
                    id: item.listId,
                    label: item.listValue,
                  }
                })}
                control={control}
              />
            </Grid>
          </Grid>
        </Box>

        <Box mb={10}>
          <Grid container spacing={10}>
            <Grid item xs={6}>
              <RHFAutocompleteField
                label={tScoped('Start Subject A')}
                name="startSubjectAId"
                options={startSubjectA?.map((item) => {
                  return {
                    id: item.listId,
                    label: item.listValue,
                  }
                })}
                control={control}
              />
            </Grid>
            <Grid item xs={6}>
              <RHFAutocompleteField
                label={tScoped('Start Subject B')}
                name="startSubjectBId"
                options={startSubjectB?.map((item) => {
                  return {
                    id: item.listId,
                    label: item.listValue,
                  }
                })}
                control={control}
              />
            </Grid>
          </Grid>
        </Box>

        <Box mb={10}>
          <Grid container spacing={10}>
            <Grid item xs={6}>
              <RHFAutocompleteField
                label={tScoped('Studies Group Subject A')}
                name="studiesGroupSubjectAId"
                options={studiesGroupSubjectA?.map((item) => {
                  return {
                    id: item.listId,
                    label: item.listValue,
                  }
                })}
                control={control}
              />
            </Grid>
            <Grid item xs={6}>
              <RHFAutocompleteField
                label={tScoped('Studies Group Subject B')}
                name="studiesGroupSubjectBId"
                options={studiesGroupSubjectB?.map((item) => {
                  return {
                    id: item.listId,
                    label: item.listValue,
                  }
                })}
                control={control}
              />
            </Grid>
          </Grid>
        </Box>

        <Box mb={10}>
          <Grid container spacing={10}>
            <Grid item xs={6}>
              <RHFAutocompleteField
                label={tScoped('Subject change from')}
                name="subjectChangeFromId"
                options={subjectChangeFrom?.map((item) => {
                  return {
                    id: item.listId,
                    label: item.listValue,
                  }
                })}
                control={control}
              />
            </Grid>
            <Grid item xs={6}>
              <RHFAutocompleteField
                label={tScoped('Subject change to')}
                name="subjectChangeToId"
                options={subjectChangeTo?.map((item) => {
                  return {
                    id: item.listId,
                    label: item.listValue,
                  }
                })}
                control={control}
              />
            </Grid>
          </Grid>
        </Box>

        <Box mb={25}>
          <Grid item xs={12}>
            <RHFTextArea
              label={tScoped('Comments')}
              control={control}
              name="comments"
            />
          </Grid>
        </Box>

        <Typography variant="h2" mb={15}>
          {tScoped('Documents')}
        </Typography>

        <Box mb={25}>
          <Grid container spacing={0}>
            <AddAttachment
              sx={{ marginRight: 'auto' }}
              currentFiles={currentFiles}
              fileUploading={fileUploading}
              setCurrentFiles={setCurrentFiles}
              labelText={tScoped('Upload Document')}
              iconName="upload"
            />
          </Grid>
        </Box>

        <Box mb={50}>
          <Grid container spacing={10}>
            <Grid item xs={6} container sx={{ justifyContent: 'end' }}>
              <CustomButton
                label
                labelText={tScoped('Discard')}
                sx={{ width: '200px' }}
                onClick={() => discardHandler()}
              />
            </Grid>
            <Grid item xs={6}>
              <CustomButton
                label
                labelText={tScoped('Save')}
                sx={{ width: '200px' }}
                variant="contained"
                type="submit"
                loading={submitLoading}
              />
            </Grid>
          </Grid>
        </Box>
      </Box>
      {serverError !== '' ? (
        <Toast message={serverError} severity="error" />
      ) : null}
      {candidateCreated ? (
        <Toast message={successMessages.candidateCreated} severity="success" />
      ) : null}
    </>
  )
}

export default CreateCandidate
