'use client'
import Link from 'next/link'
import Filter from '@/components/Filter'
import IconSwitcher from '@/components/Icons'
import Pagination from '@/components/Pagination'
import axiosInstance from '@/services/axiosInstance'
import Button from '@/components/Buttons/CustomButton'
import CandidateTableRow from '@/components/TableRows/CandidateTableRow'

import { paginationLimit } from '@/utils/constants/common'
import {
  Box,
  Grid,
  InputAdornment,
  Table,
  TableBody,
  TableContainer,
  TextField,
  Typography,
} from '@mui/material'
import { AxiosError } from 'axios'
import { useRouter } from 'next/navigation'
import { UserContext, useUser } from '@/contexts/userContext'
import { Condition, Query } from '@/interface/common'
import { errorMessages } from '@/utils/errorMessages'
import { ChangeEvent, useContext, useEffect, useState } from 'react'
import {
  CANDIDATE_CHART_COLUMNS,
  frontendRoutes,
} from '@/utils/constants/frontend'
import Toast from '@/components/Toast'
import { useScopedI18n } from '../../../../locales/client'
import moment from 'moment'
import getUserRoles from '@/utils/getUserRoles'
import SwitchButton from '@/components/Buttons/SwitchButton'
import CustomButton from '@/components/Buttons/CustomButton'
import { IModalData } from '@/interface/communication'
import NewMessage from '@/components/Modals/NewMessage'
import { phasesOptions } from '@/utils/constants'

interface ICandidateList {
  candidateId: number
  startSchoolYear: number
  fromDate: string
  untilDate: string
  person: {
    firstName: string
    lastName: string
    isActive: boolean
    email: string
    personId: number
  }
  phaseRequiredId: number
  school: {
    schoolName: string
    schoolType: {
      listValue: string
    }
    BSN: string
  }
  yearGroup: {
    listValue: string
  }
  kickOffGroup: {
    listValue: string
  }
  firstSubjectToBeStudied: {
    listValue: string
  }
  secondSubjectToBeStudied: {
    listValue: string
  }
  startSubjectA: {
    listValue: string
  }
  startSubjectB: {
    listValue: string
  }
  studiesGroupSubjectA: {
    listValue: string
  }
  studiesGroupSubjectB: {
    listValue: string
  }
}

interface PhaseFilterProps {
  kickOff: boolean | undefined
  firstSteps: boolean | undefined
  setUp: boolean | undefined
  studies: boolean | undefined
}

const CandidateList = () => {
  const tScoped = useScopedI18n('candidate')
  const router = useRouter()
  const { pagination, setPagination } = useContext(UserContext)
  const [page, setPage] = useState<number>(pagination.candidate)
  const [candidateList, setCandidateList] = useState<ICandidateList[]>([])
  const [totalRecords, setTotalRecords] = useState<number>(0)
  const [serverError, setServerError] = useState<string>('')

  const [filterQuery, setFilterQuery] = useState<Query | null>(null)
  const [searchQuery, setSearchQuery] = useState<string>('')
  const [debouncedSearchQuery, setDebouncedSearchQuery] = useState<string>('')
  const [searchText, setSearchText] = useState<string>('')
  const [onlyActive, setOnlyActive] = useState<boolean>(true)

  const [modalData, setModalData] = useState<IModalData>({
    open: false,
    type: '',
  })

  const [candidateRecipients, setCandidateRecipients] = useState<number[] | []>(
    [],
  )

  const [phaseFilterState, setPhaseFilterState] = useState<PhaseFilterProps>({
    kickOff: undefined,
    firstSteps: undefined,
    setUp: undefined,
    studies: undefined,
  })

  const user = useUser()
  const isAdminOrLead = user?.householdAdmin || user?.departmentLead

  const onPageChangeHandler = async (
    _: React.ChangeEvent<unknown>,
    value: number,
  ) => {
    setPagination((pre) => ({
      ...pre,
      candidate: value,
    }))
    setPage(value)
  }

  useEffect(() => {
    // handleRadioFilter('onlyActive', { target: { checked: onlyActive } }  as ChangeEvent<HTMLInputElement>)
    setFilterQuery({ AND: [{ isActive: { equals: true } }] })
  }, [])

  useEffect(() => {
    getCandidateList()
  }, [page, debouncedSearchQuery, filterQuery])

  useEffect(() => {
    const timerId = setTimeout(() => {
      setDebouncedSearchQuery(searchQuery)
    }, 500)

    return () => {
      clearTimeout(timerId)
    }
  }, [searchQuery])

  useEffect(() => {
    if (candidateList.length > 0) {
      const candidateRecipientsArray = candidateList.map(
        (candidate) => candidate.person.personId,
      )
      setCandidateRecipients(candidateRecipientsArray)
    }
  }, [candidateList])


  const getCandidateList = async () => {
    try {
      const response = await axiosInstance.post(
        '/api/candidate/candidate-list',
        { page, search: searchQuery, filterQuery },
      )
      setCandidateList(response.data.candidateList)
      setTotalRecords(response.data.totalRecords)
    } catch (error) {
      const errorMessage =
        error instanceof AxiosError
          ? error.response?.data?.error
          : errorMessages.DEFAULT_ERROR

      setServerError(errorMessage)
    }
  }

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value
    setSearchText(value)
    setSearchQuery(value)
    setPage(1);
  }

  const phaseFilter = ({
    kickOff = undefined,
    firstSteps = undefined,
    setUp = undefined,
    studies = undefined,
  }: PhaseFilterProps): number[] => {
    const matchingIds = []

    for (const option of phasesOptions) {
      if (
        (kickOff === undefined || option.kickOff === kickOff) &&
        (firstSteps === undefined || option.firstStep === firstSteps) &&
        (setUp === undefined || option.setUp === setUp) &&
        (studies === undefined || option.studies === studies)
      ) {
        matchingIds.push(option.id)
      }
    }

    return matchingIds
  }

  function getValueIfExists(
    phaseQueries: Condition[],
    key: string,
  ): boolean | undefined {
    const phaseQuery = phaseQueries.find((q) =>
      Object.keys(q)[0].startsWith(key),
    )
    return phaseQuery
      ? typeof phaseQuery[key] === 'boolean'
        ? (phaseQuery[key] as boolean)
        : undefined
      : undefined
  }

  const handleFilter = (filterQuery: Query) => {
    const schoolQuery: Condition = {}
    const otherQuery: Condition[] = []

    filterQuery.AND.forEach((query) => {
      const key = Object.keys(query)[0]
      const value = query[key]

      if (key.startsWith('schoolName') || key.startsWith('schoolType')) {
        ;(schoolQuery.school as Object) = {
          ...(schoolQuery.school as Object),
          [key]: key.startsWith('schoolType')
            ? { listValue: { ...(value as Object) } }
            : value,
        }
      } else if (key.startsWith('startSchoolYear')) {
        otherQuery.push({ startSchoolYear: value })
      } else if (
        ['kickOff', 'firstSteps', 'setUp', 'studies'].some((prefix) =>
          key.startsWith(prefix),
        )
      ) {
        const phaseQueries = filterQuery.AND.filter(
          (q) =>
            Object.keys(q)[0].startsWith('kickOff') ||
            Object.keys(q)[0].startsWith('firstSteps') ||
            Object.keys(q)[0].startsWith('setUp') ||
            Object.keys(q)[0].startsWith('studies'),
        )

        const data = {
          kickOff: getValueIfExists(phaseQueries, 'kickOff'),
          firstSteps: getValueIfExists(phaseQueries, 'firstSteps'),
          setUp: getValueIfExists(phaseQueries, 'setUp'),
          studies: getValueIfExists(phaseQueries, 'studies'),
        }

        setPhaseFilterState(data)

        const phaseRequiredIds = phaseFilter(phaseFilterState)
        const existingPhaseRequiredIdIndex = otherQuery.findIndex(
          (item) => item.phaseRequiredId,
        )

        if (existingPhaseRequiredIdIndex !== -1) {
          otherQuery[existingPhaseRequiredIdIndex].phaseRequiredId = {
            in: phaseRequiredIds,
          }
        } else {
          otherQuery.push({ phaseRequiredId: { in: phaseRequiredIds } })
        }
      } else {
        otherQuery.push({
          [key]: { listValue: { ...(value as Object) } },
        } as unknown as Condition)
      }
    })

    filterQuery.AND = [schoolQuery, ...otherQuery]
    setFilterQuery(filterQuery)
  }

  const handleRadioFilter = (
    name: string,
    e: ChangeEvent<HTMLInputElement>,
  ) => {
    if (name === 'onlyActive') {
      setOnlyActive(e.target.checked)
      setFilterQuery((prevFilterQuery) => {
        const updatedFilterQuery = prevFilterQuery
          ? { ...prevFilterQuery }
          : { AND: [] }
        if (e.target.checked) {
          updatedFilterQuery.AND = updatedFilterQuery.AND
            ? [...updatedFilterQuery.AND, { isActive: { equals: true } }]
            : [{ isActive: { equals: true } }]
        } else {
          updatedFilterQuery.AND = updatedFilterQuery.AND
            ? updatedFilterQuery.AND.filter(
                (condition) => !('isActive' in condition),
              )
            : []
        }
        return updatedFilterQuery
      })
    }
  }

  const today = moment()
  const oneWeekAhead = moment(today).add(7, 'days')

  const userRoles = getUserRoles(user)
  const anyChangePermissionFunction = (userRoles: string[]) => {
    return (
      userRoles.includes('subjectAdmin') ||
      userRoles.includes('subjectSupervision')
    )
  }
  const anyChangePermission: boolean = anyChangePermissionFunction(userRoles)

  const handleClose = () => {
    setModalData({ type: '', open: false })
  }

  return (
    <>
      <NewMessage
        open={modalData.type === 'message' && modalData.open}
        handleClose={handleClose}
        role="Employee"
        preDecidedRecipients={candidateRecipients}
      />
      <Box width="100%">
        <Typography variant="h1" mb={7}>
          {tScoped('Candidate Chart')}
        </Typography>

        <Box mb={6}>
          <Grid container spacing={5} justifyContent="flex-end">
            <Grid
              item
              sx={{
                display: 'flex',
                alignItems: 'center',
                marginRight: '10px',
              }}
            >
              <Filter
                columns={CANDIDATE_CHART_COLUMNS}
                handleFilter={handleFilter}
                defaultValues={{
                  column: 'dueDate',
                  operator: 'lte',
                  value: moment(oneWeekAhead).toISOString(),
                }}
              />
            </Grid>
            <Grid
              item
              sx={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <SwitchButton
                label={tScoped('Only Active')}
                name="onlyActive"
                handleChange={(e) => handleRadioFilter('onlyActive', e)}
                checked={onlyActive}
              />
            </Grid>

            <Grid item>
              <CustomButton
                icon
                label
                labelText={tScoped('New Message')}
                iconName="plus"
                onClick={() => {
                  setModalData({
                    open: true,
                    type: 'message',
                  })
                }}
              />
            </Grid>

            {anyChangePermission && (
              <>
                <Grid item>
                  <Button
                    label
                    icon
                    labelText={tScoped('Mass Import')}
                    iconName="compare"
                    onClick={() =>
                      router.push(frontendRoutes.candidate.massImport)
                    }
                  />
                </Grid>
                <Grid item>
                  <Link href={frontendRoutes.candidate.create}>
                    <Button
                      label
                      icon
                      labelText={tScoped('New Candidate')}
                      iconName="plus"
                    />
                  </Link>
                </Grid>
                <Grid item>
                  <Button
                    label
                    icon
                    labelText={tScoped('Match Mentor')}
                    iconName="people"
                    onClick={() =>
                      router.push(frontendRoutes.candidate.matchMentors)
                    }
                  />
                </Grid>
              </>
            )}
            <Grid item>
              <TextField
                name="search"
                type="search"
                value={searchText}
                placeholder={tScoped('Search')}
                InputProps={{
                  endAdornment: (
                    <InputAdornment
                      position="end"
                      sx={{
                        cursor: 'pointer',
                        background: '#e40422',
                        height: '100%',
                        marginRight: '-14px',
                        maxHeight: '100%',
                        paddingInline: '10px',
                      }}
                    >
                      <IconSwitcher icon={'search'} />
                    </InputAdornment>
                  ),
                }}
                onChange={handleSearch}
              />
            </Grid>
          </Grid>
        </Box>
        <TableContainer sx={{ overflowX: 'unset' }}>
          <Table
            sx={{ minWidth: 'unset', maxWidth: '100%', marginBottom: '25px' }}
          >
            <TableBody>
              {candidateList?.map((candidate) => (
                <CandidateTableRow
                  key={candidate.candidateId}
                  candidate={candidate}
                />
              ))}
            </TableBody>
          </Table>
          {totalRecords > paginationLimit ? (
            <Pagination
              count={Math.ceil(totalRecords / paginationLimit)}
              page={page}
              onChange={onPageChangeHandler}
            />
          ) : null}
        </TableContainer>

        {serverError !== '' ? (
          <Toast message={serverError} severity="error" />
        ) : null}
      </Box>
    </>
  )
}

export default CandidateList
