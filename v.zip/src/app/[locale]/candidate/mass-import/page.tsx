'use client'
import React, { useEffect, useState } from 'react'
import CustomButton from '@/components/Buttons/CustomButton'
import { Box, Grid, Typography } from '@mui/material'
import csvParser from 'csv-parser'
import { DataGrid, GridColDef, GridRowSelectionModel } from '@mui/x-data-grid'
import { AxiosError } from 'axios'
import { useRouter } from 'next/navigation'

import axiosInstance from '@/services/axiosInstance'
import { errorMessages } from '@/utils/errorMessages'
import Toast from '@/components/Toast'
import MassImportModal from '@/components/MassImportModal'
import { useScopedI18n } from '../../../../../locales/client'

interface IToastData {
  type: 'success' | 'info' | 'warning' | 'error' | undefined
  message: string
}

interface IimportFailedData {
  error: string
  data: string[]
}

const MassImport = () => {
  const tScoped = useScopedI18n('massImportCandidate')
  const tDashboardScoped = useScopedI18n('dashboard')
  const router = useRouter()
  const [csvData, setCsvData] = useState<File | null>(null)
  const [csvRows, setCsvRows] = useState<string[]>([])
  const [selectedRows, setSelectedRows] = useState<GridRowSelectionModel>([])
  const [submitLoading, setSubmitLoading] = useState<boolean>(false)
  const [importFailedModal, setImportFailedModal] = useState<boolean>(false)
  const [importFailedData, setImportFailedData] = useState<IimportFailedData>({
    error: '',
    data: [''],
  })
  const [toastData, setToastData] = useState<IToastData>({
    type: undefined,
    message: '',
  })

  useEffect(() => {
    setTimeout(() => {
      setToastData({
        type: undefined,
        message: '',
      })
    }, 5000)
  }, [JSON.stringify(toastData)])

  const getSelectedRowData = () => {
    return csvRows.filter((row, index) =>
      selectedRows.includes(index.toString()),
    )
  }

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      setCsvData(file)

      const reader = new FileReader()
      const results: string[] = []
      reader.onload = (e) => {
        if (e?.target?.result) {
          const content = e.target.result?.toString()
          const parser = csvParser()

          parser
            .on('data', (data) => results.push(data))
            .on('end', () => {
              setCsvRows(results)
            })

          parser.write(content)
          parser.end()
        }
      }

      reader.readAsText(file)
      event.target.files = null
    }
  }

  const columns: GridColDef[] = csvRows[0]
    ? Object.keys(csvRows[0]).map((header) => ({
        field: header,
        headerName: header,
        width: 200,
        sortable: false,
      }))
    : []

  const handleRowSelectionChange = (selectionModel: GridRowSelectionModel) => {
    setSelectedRows(selectionModel)
  }

  const handleImport = () => {
    setSubmitLoading(true)
    const selectedRowData = getSelectedRowData()
    axiosInstance
      .post('/api/candidate/mass-import', selectedRowData)
      .then((response) => {
        if (response.status === 201) {
          setToastData({ type: 'success', message: response.data.message })
          setSelectedRows([])
          router.push('/candidate')
        } else {
          setToastData({
            type: 'error',
            message: errorMessages.DEFAULT_ERROR,
          })
          setImportFailedModal(true)
        }
      })
      .catch((error) => {
        if (error.response.status !== 409) {
          setToastData({
            type: 'error',
            message:
              error instanceof AxiosError
                ? error.response?.data?.error
                : errorMessages.DEFAULT_ERROR,
          })
        } else {
          setImportFailedModal(true)
          setImportFailedData(error.response.data)
        }
      })
      .finally(() => {
        setSubmitLoading(false)
      })
  }

  const handleImportFailed = () => {
    setImportFailedModal(false)
  }

  const handleCancel = () => {
    setCsvRows([])
    setCsvData(null)

    const fileInput = document.getElementById('file') as HTMLInputElement
    if (fileInput) {
      fileInput.value = ''
    }
  }

  return (
    <>
      <MassImportModal
        importFailedModal={importFailedModal}
        handleImportFailed={handleImportFailed}
        importFailedData={importFailedData}
      />
      <Box sx={{ display: 'flex', flexDirection: 'column', minHeight: '80vh' }}>
        {toastData.message !== '' ? (
          <Toast message={toastData.message} severity={toastData.type} />
        ) : null}
        <Box display="flex" flexDirection="column" flexGrow={1} pb={3} pt={3}>
          <Grid container justifyContent="space-between" mb={10}>
            <Grid item display="flex" alignItems="flex-end" gap={10}>
              <Typography variant="h1" mb={0}>
                {tScoped('Mass Import')}
              </Typography>
            </Grid>
            <Grid item>
              <CustomButton
                icon
                label
                labelText={tDashboardScoped('Back')}
                iconName="arrowLeft"
                onClick={() => router.back()}
              />
            </Grid>
          </Grid>

          <Grid container spacing={10} alignItems="center">
            <Grid item>
              <label>
                <CustomButton
                  label
                  icon
                  iconName="upload"
                  labelText={tScoped('Upload CSV')}
                  onClick={() => {
                    setCsvRows([])
                    setCsvData(null)
                    document?.getElementById('file')?.click()
                  }}
                />
                <input
                  type="file"
                  name="file"
                  id="file"
                  accept=".csv"
                  style={{ display: 'none' }}
                  onChange={handleFileUpload}
                />
              </label>
            </Grid>

            {csvData?.name && (
              <Grid item>
                <Typography variant="h3" color="primary">
                  {csvData?.name}
                </Typography>
              </Grid>
            )}

            <Grid item sx={{ marginLeft: 'auto' }}>
              <a href="/assets/sample-file.csv" download>
                <CustomButton
                  label
                  icon
                  labelText={tScoped('Download sample file')}
                  iconName="download"
                  sx={{ width: '100%' }}
                />
              </a>
            </Grid>
          </Grid>

          {csvRows?.length > 0 && (
            <Typography variant="h3" color="primary" mt={20}>
              {csvRows?.length} {tScoped('Records')}
            </Typography>
          )}

          <Box flexGrow={1} mt={10}>
            {csvRows && csvData && (
              <DataGrid
                rows={csvRows}
                columns={columns}
                checkboxSelection
                disableColumnFilter
                disableColumnMenu
                disableColumnSelector
                disableDensitySelector
                getRowId={(row) => csvRows.indexOf(row).toString()}
                onRowSelectionModelChange={handleRowSelectionChange}
                rowSelectionModel={selectedRows}
                sx={{
                  height: '500px',
                  '.MuiDataGrid-columnHeaderTitle': {
                    fontWeight: 'bold',
                  },
                  '.MuiTablePagination-actions': {
                    '.MuiButtonBase-root': {
                      background: '#fff',
                    },
                    '.Mui-disabled': {
                      background: '#f4f4f4',
                    },
                  },
                }}
              />
            )}
          </Box>

          <Box display="flex" justifyContent="center" mb={3} mt={20}>
            <Grid container item xs={6} spacing={20}>
              <Grid item xs={6}>
                <CustomButton
                  label
                  labelText={tScoped('Cancel')}
                  type="submit"
                  sx={{ width: '100%' }}
                  disabled={!csvData}
                  onClick={handleCancel}
                />
              </Grid>

              <Grid item xs={6}>
                <CustomButton
                  label
                  labelText={tScoped('Import')}
                  type="submit"
                  loading={submitLoading}
                  sx={{ width: '100%' }}
                  disabled={!csvData || !selectedRows.length}
                  onClick={handleImport}
                />
              </Grid>
            </Grid>
          </Box>
        </Box>
      </Box>
    </>
  )
}

export default MassImport
