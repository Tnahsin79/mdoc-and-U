'use client'
import {
  Typography,
  Grid,
  Radio,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow as MUITableRow,
} from '@mui/material'

import { AxiosError } from 'axios'
import { styled } from '@mui/system'
import { useContext, useEffect, useState } from 'react'
import { paginationLimit } from '@/utils/constants'
import { errorMessages } from '@/utils/errorMessages'

import Toast from '@/components/Toast'
import CustomModal from '@/components/Modal'
import Pagination from '@/components/Pagination'
import axiosInstance from '@/services/axiosInstance'
import CustomButton from '@/components/Buttons/CustomButton'
import MatchingListItem from '@/components/List/MatchingListItem'
import { successMessages } from '@/utils/successMessages'
import { useRouter } from 'next/navigation'
import { frontendRoutes } from '@/utils/constants/frontend'
import { useScopedI18n } from '../../../../../locales/client'
import { CandidatesMatchedToMentorsContext } from '@/contexts/useCandidatesMatchedToMentors'

const TableRow = styled(MUITableRow)({
  height: '30px',
  '& .MuiTableCell-root': {
    borderTop: 'none',
    borderLeft: '1px solid #000',
    padding: '10px',
    '&:first-child': {
      borderLeft: 'none',
    },
    '&:last-child': {
      borderRight: 'none',
    },
    '& .MuiRadio-roo': {
      padding: 0,
    },
  },
})

interface CandidateListInterface {
  candidateId: number
  mentor_id?: number | null
  city: string
  person: {
    firstName: string
    lastName: string | null
    postalCode: string | null
  }
  mentor: {
    collaboratorId: number | null
    person: {
      firstName: string
      lastName: string
    }
    city: string
    postalCode: string
  } | null
  school: {
    city: string
    postalCode: string
  }
}

interface MentorInterface {
  collaboratorId: number
  firstName: string
  lastName: string
  firstRecognisedSubjectId: number
  streetAndHouseNo: string
  city: string
  postalCode: string
  BSN: string
  subject: string
  subjectValue: string
}

const MatchMentors = () => {
  const tScoped = useScopedI18n('candidate')
  const tDashboardScoped = useScopedI18n('dashboard')
  const router = useRouter()
  const [page, setPage] = useState<number>(1)
  const [serverError, setServerError] = useState<string>('')
  const [totalRecords, setTotalRecords] = useState<number>(0)
  const [openFindMatch, setOpenFindMatch] = useState<boolean>(false)
  const [mentorList, setMentorList] = useState<MentorInterface[]>([])
  const [selectedMentor, setSelectedMentor] = useState<{
    collaboratorId: number
    city: string
    postalCode: string
    firstName: string
    lastName: string
  } | null>(null)
  const [matchingSuccessful, setMatchingSuccessful] = useState<boolean>(false)

  const [originalCandidate, setOriginalCandidate] = useState<
    CandidateListInterface[] | null
  >(null)
  const [selectedCandidate, setSelectedCandidate] = useState<number | null>(
    null,
  )
  const [candidateList, setCandidateList] = useState<CandidateListInterface[]>(
    [],
  )

  const {
    candidatesMatchedToMentors,
    setCandidatesMatchedToMentors,
    setSingleCandidatesMatchedToMentors,
    singleCandidatesMatchedToMentors,
  } = useContext(CandidatesMatchedToMentorsContext)

  useEffect(() => {
    if (singleCandidatesMatchedToMentors) {
      const candidate = Object.keys(singleCandidatesMatchedToMentors)
      const updatedCandidates = candidateList.find(
        (cand) => cand.candidateId === +candidate[0],
      )
      if (updatedCandidates) {
        updatedCandidates.mentor = {
          collaboratorId: selectedMentor?.collaboratorId ?? null,
          person: {
            firstName: selectedMentor?.firstName ?? '',
            lastName: selectedMentor?.lastName ?? '',
          },
          postalCode: selectedMentor?.postalCode.toString() ?? '',
          city: selectedMentor?.city ?? '',
        }
      }

      const upd = candidateList.map((candidate) => {
        if (candidate?.candidateId === updatedCandidates?.candidateId) {
          return updatedCandidates
        } else {
          return candidate
        }
      })
      setCandidateList(upd)
    }
    setSelectedMentor(null)
  }, [singleCandidatesMatchedToMentors])

  const getCandidateList = async () => {
    try {
      setServerError('')
      const response = await axiosInstance.post(`/api/match-mentors`, {
        page,
      })
      if (candidatesMatchedToMentors !== null) {
        const updatedCandidateList = await Promise.all(
          response.data.candidateList.map(
            async (candidate: CandidateListInterface) => {
              if (
                Object.keys(candidatesMatchedToMentors)
                  .map((item) => +item)
                  .includes(candidate.candidateId)
              ) {
                if(candidatesMatchedToMentors[candidate.candidateId]) {
                  const mentor = await axiosInstance.get(
                    `/api/collaborator/${
                      candidatesMatchedToMentors[candidate.candidateId]
                    }?matchMentor=true`,
                  )
                  candidate.mentor = mentor.data.collaborator
                }
              }
              return candidate
            },
          ),
        )

        setCandidateList(updatedCandidateList)
        setOriginalCandidate(response.data.candidateList)
        setTotalRecords(response.data.totalRecords)
      } else {
        setCandidateList(response.data.candidateList)
        setOriginalCandidate(response.data.candidateList)
        setTotalRecords(response.data.totalRecords)
      }
    } catch (error) {
      const errorMessage =
        error instanceof AxiosError
          ? error.response?.data?.error
          : errorMessages.DEFAULT_ERROR

      setServerError(errorMessage)
    }
  }

  useEffect(() => {
    getCandidateList()
  }, [page])

  const autoMatchHandler = async () => {
    try {
      setServerError('')
      setMatchingSuccessful(false)
      const response = await axiosInstance.post(
        `/api/match-mentors/auto-match/${page}`,
      )
      setCandidateList(response.data.candidateList)
      setMatchingSuccessful(true)
    } catch (error) {
      const errorMessage =
        error instanceof AxiosError
          ? error.response?.data?.error
          : errorMessages.DEFAULT_ERROR

      setServerError(errorMessage)
    }
  }

  const onModalSaveHandler = () => {
    if (!selectedCandidate || !selectedMentor) {
      return
    }
    setCandidateList((pre) =>
      pre.map((candidate) => {
        if (selectedCandidate === candidate.candidateId) {
          candidate.mentor_id = selectedMentor.collaboratorId
        }

        return candidate
      }),
    )

    setCandidatesMatchedToMentors((pre) => {
      return pre
        ? { ...pre, [selectedCandidate]: selectedMentor.collaboratorId }
        : { [selectedCandidate]: selectedMentor.collaboratorId }
    })
    setSingleCandidatesMatchedToMentors({
      [selectedCandidate]: selectedMentor.collaboratorId,
    })
    setOpenFindMatch(false)
  }

  const modalOpenHandler = async (candidateId: number) => {
    setSelectedCandidate(candidateId)
    try {
      const data = await axiosInstance.get(`/api/match-mentors/${candidateId}`)
      setMentorList(data.data.mentorsList)

      setOpenFindMatch(true)
    } catch (error) {
      const errorMessage =
        error instanceof AxiosError
          ? error.response?.data?.error
          : errorMessages.DEFAULT_ERROR

      setServerError(errorMessage)
    }
  }

  const deleteMentorHandler = (candidateId: number) => {
    if (!candidateId) {
      return
    }

    setCandidateList((pre) =>
      pre.map((candidate) => {
        if (candidateId === candidate.candidateId) {
          candidate.mentor_id = null
          candidate.mentor = null
        }

        return candidate
      }),
    )
    setCandidatesMatchedToMentors((pre) => {
      return pre ? { ...pre, [candidateId]: null } : { [candidateId]: null }
    })
  }

  const onSubmitHandler = async () => {
    setServerError('')
    setMatchingSuccessful(false)
    try {
      if (candidatesMatchedToMentors === null) {
        throw new Error(errorMessages.NOTHING_TO_AUTOMATcH)
      }

      await axiosInstance.put(`/api/match-mentors`, candidatesMatchedToMentors)
      setMatchingSuccessful(true)
      router.push(frontendRoutes.candidate.list)
    } catch (error) {
      const errorMessage =
        error instanceof AxiosError
          ? error.response?.data?.error
          : error instanceof Error
            ? error.message
            : errorMessages.DEFAULT_ERROR

      setServerError(errorMessage)
    }
  }

  return (
    <>
      <Grid container justifyContent="space-between" mb={25}>
        <Grid item display="flex" alignItems="flex-end" gap={10}>
          <Typography variant="h1" mb={0}>
            {tScoped('Match Mentor')}
          </Typography>
        </Grid>
        <Grid item>
          <CustomButton
            icon
            label
            labelText={tDashboardScoped('Back')}
            iconName="arrowLeft"
            onClick={() => router.back()}
          />
        </Grid>
      </Grid>

      <Grid container justifyContent="flex-end" gap={10} mb={20}>
        <CustomButton
          label={true}
          labelText={tScoped('Auto Match')}
          icon={true}
          onClick={autoMatchHandler}
        />
      </Grid>

      <Grid container justifyContent="space-around" gap={10} mb={10}>
        <Typography variant="h2">{tScoped('Candidates')}</Typography>
        <Typography variant="h2">{tScoped('Mentors')}</Typography>
      </Grid>

      <Grid mb={50}>
        {candidateList?.map((candidate) => {
          let selectedMentor = null
          if (candidate?.mentor) {
            selectedMentor = {
              collaboratorId: candidate?.mentor.collaboratorId,
              city: candidate?.mentor.city || '',
              postalCode: candidate?.mentor.postalCode || '',
              firstName: candidate?.mentor.person.firstName,
              lastName: candidate?.mentor.person.lastName,
            }
          } else {
            selectedMentor = mentorList?.find(
              (currentMentor) =>
                currentMentor.collaboratorId === candidate?.mentor_id,
            )
          }

          return (
            <MatchingListItem
              key={candidate?.candidateId}
              candidate={{
                firstName: candidate?.person?.firstName,
                lastName: candidate?.person?.lastName,
                school: {
                  city: candidate?.school?.city,
                  postalCode: candidate?.school?.postalCode,
                },
              }}
              mentor={selectedMentor}
              modalOpenHandler={() => modalOpenHandler(candidate?.candidateId)}
              deleteMentorHandler={() =>
                deleteMentorHandler(candidate?.candidateId)
              }
            />
          )
        })}
      </Grid>

      {totalRecords > paginationLimit ? (
        <Pagination
          count={Math.ceil(totalRecords / paginationLimit)}
          page={page}
          onChange={(e, page) => setPage(page)}
          sx={{ marginBottom: '50px' }}
        />
      ) : null}

      <Grid container columnSpacing={10}>
        <Grid item xs={6}>
          <CustomButton
            label={true}
            labelText={tScoped('Discard new matches')}
            icon={false}
            fullWidth
            onClick={() => {
              if (originalCandidate) {
                setCandidatesMatchedToMentors(null)
                setCandidateList(originalCandidate)
              }
              router.push(frontendRoutes.candidate.list)
            }}
          />
        </Grid>
        <Grid item xs={6}>
          <CustomButton
            label={true}
            labelText={tScoped('Save')}
            icon={false}
            fullWidth
            onClick={onSubmitHandler}
            variant="contained"
          />
        </Grid>
      </Grid>

      <CustomModal open={openFindMatch} onClose={() => setOpenFindMatch(false)}>
        <Typography variant="h2">{tScoped('Matching')}</Typography>
        <TableContainer>
          <Table
            sx={{
              minWidth: '744px',
              marginBottom: '25px',
              borderSpacing: 0,
              overflow: 'scroll',
            }}
          >
            <TableHead>
              <TableRow>
                <TableCell></TableCell>
                <TableCell>{tScoped('Full Name')}</TableCell>
                <TableCell>{tScoped('Subject')}</TableCell>
                <TableCell>{tScoped('Subject Area')}</TableCell>
                <TableCell>{tScoped('BSN')}</TableCell>
                <TableCell>{tScoped('Address')}</TableCell>
              </TableRow>
            </TableHead>

            <TableBody>
              {mentorList.map(
                ({
                  firstName,
                  lastName,
                  collaboratorId,
                  BSN,
                  postalCode,
                  city,
                  subject,
                  subjectValue,
                  streetAndHouseNo,
                }) => (
                  <TableRow key={collaboratorId}>
                    <TableCell>
                      <Radio
                        checked={
                          collaboratorId === selectedMentor?.collaboratorId
                        }
                        onChange={() =>
                          setSelectedMentor({
                            collaboratorId: collaboratorId,
                            city: city,
                            postalCode: postalCode,
                            firstName: firstName,
                            lastName: lastName,
                          })
                        }
                      />
                    </TableCell>
                    <TableCell>
                      {firstName} {lastName}
                    </TableCell>
                    <TableCell>{subject}</TableCell>
                    <TableCell>{subjectValue}</TableCell>
                    <TableCell>{BSN}</TableCell>
                    <TableCell>
                      {streetAndHouseNo}, {postalCode} {city}
                    </TableCell>
                  </TableRow>
                ),
              )}
            </TableBody>
          </Table>
          <Grid container justifyContent="flex-end">
            <CustomButton
              label
              labelText={tScoped('Save')}
              icon
              iconName="check"
              onClick={onModalSaveHandler}
            />
          </Grid>
        </TableContainer>
      </CustomModal>

      {serverError !== '' ? (
        <Toast message={serverError} severity="error" />
      ) : null}
      {matchingSuccessful ? (
        <Toast message={successMessages.candidateMatched} severity="success" />
      ) : null}
    </>
  )
}

export default MatchMentors
