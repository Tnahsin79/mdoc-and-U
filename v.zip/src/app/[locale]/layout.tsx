'use client'

import { ReactElement } from 'react'

export default function SubLayout({ children }: { children: ReactElement }) {
  return children
}
