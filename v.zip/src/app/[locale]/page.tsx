'use client'
import axiosInstance from '@/services/axiosInstance'
import { CandidateRoutes, CollaboratorRoutes, routes } from '@/utils/constants'
import { LinearProgress } from '@mui/material'
import { useRouter } from 'next/navigation'
import React, { useEffect } from 'react'

const Home = () => {
  const router = useRouter()

  const getRoleHomeRoute = async () => {
    const res = await axiosInstance.get('/api/auth/me')

    if (res.status === 200) {
      if (res.data.person.role === 'Candidate') {
        router.push(CandidateRoutes.dashboard)
      } else if (res.data.person.role === 'Employee') {
        router.push(routes.dashboard)
      } else if (res.data.person.role === 'Collaborator') {
        router.push(CollaboratorRoutes.dashboard)
      }
    }
  }

  useEffect(() => {
    getRoleHomeRoute()
  })

  return <><LinearProgress /></>
}

export default Home
