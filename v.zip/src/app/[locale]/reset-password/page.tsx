'use client'
import { Box, InputLabel, TextField, Typography, Grid } from '@mui/material'
import { useEffect, useState } from 'react'
import { AxiosError } from 'axios'
import { useRouter, useSearchParams } from 'next/navigation'
import { useForm, SubmitHandler } from 'react-hook-form'

import axiosInstance from '@/services/axiosInstance'
import CustomButton from '@/components/Buttons/CustomButton'
import { validators } from '@/validators'
import { errorMessages } from '@/utils/errorMessages'
import Toast from '@/components/Toast'
import { frontendRoutes } from '@/utils/constants/frontend'
import { useScopedI18n } from '../../../../locales/client'

interface ResetPasswordPageInterface {
  password: string
  confirmPassword: string
}

interface IToastData {
  type: 'success' | 'info' | 'warning' | 'error' | undefined
  message: string
}

const ResetPassword = () => {
  const tScoped = useScopedI18n('resetPassword')
  const tDashboardScoped = useScopedI18n('dashboard')
  const router = useRouter()
  const [toastData, setToastData] = useState<IToastData>({
    type: undefined,
    message: '',
  })
  const searchParams = useSearchParams()
  const token = searchParams.get('token')

  const {
    register,
    handleSubmit,
    watch,
    formState: { errors },
  } = useForm<ResetPasswordPageInterface>({
    shouldFocusError: true,
  })

  const password = watch('password')

  useEffect(() => {
    setTimeout(() => {
      setToastData({
        type: undefined,
        message: '',
      })
    }, 5000)
  }, [toastData.message])

  const ResetPasswordHandler: SubmitHandler<
    ResetPasswordPageInterface
  > = async (data) => {
    const payload = {
      token: token,
      newPassword: data.password,
    }
    try {
      const response = await axiosInstance.post(
        '/api/auth/reset-password',
        payload,
      )

      if (response.statusText === 'OK') {
        setToastData({ type: 'success', message: response.data.message })
        router.replace(frontendRoutes.login)
      }
    } catch (error) {
      const errorMessage =
        error instanceof AxiosError
          ? error.response?.data?.error
          : errorMessages.DEFAULT_ERROR
      setToastData({ type: 'error', message: errorMessage })
    }
  }
  return (
    <>
      <Grid container justifyContent="space-between" mb={13.2}>
        <Grid item display="flex" alignItems="flex-end" gap={10}>
          <Typography variant="h1" mb={0}>
            {tScoped('Set Password')}
          </Typography>
        </Grid>
        <Grid item>
          <CustomButton
            icon
            label
            labelText={tDashboardScoped('Back')}
            iconName="arrowLeft"
            onClick={() => router.back()}
          />
        </Grid>
      </Grid>

      <Typography variant="subtitle1" marginBottom={18}>
        {tScoped('Please enter your password')}
      </Typography>

      <Box component="form" onSubmit={handleSubmit(ResetPasswordHandler)}>
        <Grid
          sx={{
            display: 'grid',
            gridTemplateColumns: { sm: '1fr 1fr' },
            gap: 10,
          }}
        >
          <Box>
            <InputLabel htmlFor="password">{tScoped('Password')}</InputLabel>
            <TextField
              id="password"
              type="password"
              fullWidth
              {...register('password', {
                required: {
                  value: true,
                  message: tScoped('Password is required'),
                },
                minLength: {
                  value: 8,
                  message: tScoped(
                    'Password must be at least 8 characters long.',
                  ),
                },

                pattern: {
                  value: validators.password,
                  message: tScoped(
                    'Password must contain at least one uppercase letter, one lowercase letter, one number, and one special character',
                  ),
                },
              })}
              error={!!errors.password}
              helperText={errors.password?.message}
            />
          </Box>

          <Box>
            <InputLabel htmlFor="confirmPassword">
              {tScoped('Confirm Password')}
            </InputLabel>
            <TextField
              id="confirmPassword"
              type="password"
              fullWidth
              {...register('confirmPassword', {
                required: {
                  value: true,
                  message: tScoped('Confirm Password is required'),
                },
                validate: (value) =>
                  value === password ||
                  tScoped('Confirm Password Should be same as Password'),
              })}
              error={!!errors.confirmPassword}
              helperText={errors.confirmPassword?.message}
            />
          </Box>
        </Grid>

        {toastData.message && (
          <Toast message={toastData.message} severity={toastData.type} />
        )}

        <Grid
          container
          justifyContent="center"
          alignItems="center"
          gap={10}
          pt={20}
        >
          <CustomButton
            variant="contained"
            type="submit"
            sx={{ width: '250px' }}
            label={true}
            labelText={tScoped('Reset Password')}
          />
        </Grid>
      </Box>
    </>
  )
}

export default ResetPassword
