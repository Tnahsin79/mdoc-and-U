'use client'
import { Typography, Grid } from '@mui/material'
import CustomButton from '@/components/Buttons/CustomButton'
import { useRouter } from 'next/navigation'
import { useScopedI18n } from '../../../../locales/client'

const page = () => {
  const tDashboardScoped = useScopedI18n('dashboard')
  const router = useRouter()
  return (
    <>
      <Grid container justifyContent="space-between" mb={25}>
        <Grid item display="flex" alignItems="flex-end" gap={10}>
          <Typography variant="h1" mb={0}>
            Contracts
          </Typography>
        </Grid>
        <Grid item>
          <CustomButton
            icon
            label
            labelText={tDashboardScoped('Back')}
            iconName="arrowLeft"
            onClick={() => router.back()}
          />
        </Grid>
      </Grid>
    </>
  )
}

export default page
