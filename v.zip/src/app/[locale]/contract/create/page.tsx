'use client'
import { ICreateContract } from '@/app/api/contract/create/route'
import CustomButton from '@/components/Buttons/CustomButton'
import CustomCheckbox from '@/components/Buttons/CustomCheckbox'
import ContractPosition, {
  IContractPosition,
} from '@/components/ContractPosition'
import CustomDatePicker from '@/components/DatePicker'
import { RHFAutocompleteField } from '@/components/DropDown'
import InputField from '@/components/InputField'
import Toast from '@/components/Toast'
import {
  ICollaboratorPersonList,
  IContractDetail,
  IContractPositionState,
  IList,
  IToastData,
} from '@/interface/common'
import axiosInstance from '@/services/axiosInstance'
import { errorMessages } from '@/utils/errorMessages'
import { validationMessages } from '@/validators/messages'
import { Box, Grid, Typography } from '@mui/material'
import { AxiosError } from 'axios'
import moment from 'moment'
import { useRouter } from 'next/navigation'
import { useEffect, useState } from 'react'
import { SubmitHandler, useForm } from 'react-hook-form'
import { useScopedI18n } from '../../../../../locales/client'

const CreateContract: React.FC = () => {
  const tScoped = useScopedI18n('contract')
  const tDashboardScoped = useScopedI18n('dashboard')
  const [newPositionForm, setNewPositionForm] = useState<boolean>(false)
  const [durationState, setDurationState] = useState<number>(0)
  const [hourlyFeeState, setHourlyFeeState] = useState<number>(0)
  const [collaboratorPersons, setCollaboratorPersons] =
    useState<ICollaboratorPersonList>([])
  const [contractTypes, setContractTypes] = useState<IList>([])
  const [position, setPosition] = useState<IContractPositionState | null>(null)
  const methods = useForm<ICreateContract>({
    mode: 'all',
    shouldFocusError: true,
  })
  const [toastData, setToastData] = useState<IToastData>({
    type: undefined,
    message: '',
  })
  const [total, setTotal] = useState<number>(0)
  const [submitLoading, setSubmitLoading] = useState<boolean>(false)

  const router = useRouter()

  const {
    handleSubmit,
    formState: { errors },
    control,
    clearErrors,
    setValue,
    setError,
    watch,
    reset,
  } = methods

  const billedFrom = watch('billFrom')
  const hourlyFee = watch('hourlyFee')
  const duration = watch('duration')
  const personId = watch('personId')
  const contractTypeId = watch('contractTypeId')

  useEffect(() => {
    if (submitLoading === true) {
      setTimeout(() => {
        setSubmitLoading(false)
      }, 3000)
    }
  }, [submitLoading])

  useEffect(() => {
    if (position) {
      const t = position.contractDetail.reduce(
        (acc: number, curr: IContractDetail) => {
          return curr.hourlyFee * curr.duration + acc
        },
        0,
      )
      setTotal(t)
    }
  }, [position])

  useEffect(() => {
    setTimeout(() => {
      setToastData({
        type: undefined,
        message: '',
      })
    }, 5000)
  }, [JSON.stringify(toastData)])

  useEffect(() => {
    if (duration) {
      setDurationState(duration)
    }

    if (hourlyFee) {
      setHourlyFeeState(hourlyFee)
    }
  }, [duration, hourlyFee])

  useEffect(() => {
    setTotal(0)
    if (personId && contractTypeId) {
      getAllPositions(personId, contractTypeId)
    }
  }, [personId, contractTypeId, newPositionForm])

  useEffect(() => {
    getAllLists()
  }, [])

  const getAllLists = async () => {
    setTotal(0)

    const listsFromApi = await axiosInstance.post('/api/list', {
      listTypes: ['contractType'],
    })

    const collaborators = await axiosInstance.post(
      '/api/collaborator/collaborator-list',
      {
        page: 1,
      },
    )
    const persons = collaborators.data.collaboratorList.map(
      (collaborator: {
        collaboratorId: number
        person: {
          personId: number
          firstName: string
          lastName: string
        }
      }) => {
        return collaborator.person
      },
    )

    setCollaboratorPersons(persons)
    setContractTypes(listsFromApi.data.data.contractType)
  }

  const minSelectableDate = billedFrom
    ? moment(billedFrom).add(0, 'days').toDate()
    : undefined

  const CreateContractHandler: SubmitHandler<ICreateContract> = async (
    payload,
  ) => {
    try {
      const data = {
        ...payload,
      }

      if (
        data.phasePreference.kickOff &&
        data.phasePreference.firstStep &&
        data.phasePreference.setUp &&
        data.phasePreference.studies
      ) {
        setToastData({
          type: 'error',
          message: 'Please Choose Phase',
        })
        return
      }

      setSubmitLoading(true)

      const response = await axiosInstance.post('/api/contract/create', {
        data,
      })

      if (response.status === 201) {
        setToastData({ type: 'success', message: response.data.message })
        reset({
          positionTitle: '',
          billFrom: undefined,
          billTo: undefined,
          hourlyFee: undefined,
          duration: undefined,
          phasePreference: {
            kickOff: false,
            firstStep: false,
            setUp: false,
            studies: false,
          },
          personId: personId,
          contractTypeId: contractTypeId,
        })
        setValue('hourlyFee', 0)
        setValue('duration', 0)
        setDurationState(0)
        setHourlyFeeState(0)
        setSubmitLoading(false)
        setNewPositionForm(false)
      }
    } catch (error) {
      setToastData({
        type: 'error',
        message:
          error instanceof AxiosError
            ? error.response?.data?.error
            : errorMessages.DEFAULT_ERROR,
      })
    }
  }

  const getAllPositions = async (personId: number, contractTypeId: number) => {
    const data = {
      personId: personId,
      contract_type_id: contractTypeId,
    }

    const response = await axiosInstance.post('/api/contract/list', { data })

    setPosition(response.data.positionsList)
  }

  const discardHandler = () => {
    reset()
    router.push('/contract')
  }

  return (
    <>
      {toastData.message !== '' ? (
        <Toast message={toastData.message} severity={toastData.type} />
      ) : null}
      <Box
        component="form"
        onSubmit={handleSubmit(CreateContractHandler)}
        autoComplete="off"
      >
        <Grid container justifyContent="space-between" mb={25}>
          <Grid item display="flex" alignItems="flex-end" gap={10}>
            <Typography variant="h1" mb={0}>
              {tScoped('Create Contract')}
            </Typography>
          </Grid>
          <Grid item>
            <CustomButton
              icon
              label
              labelText={tDashboardScoped('Back')}
              iconName="arrowLeft"
              onClick={() => router.back()}
            />
          </Grid>
        </Grid>

        <Box mb={25}>
          <Grid container spacing={10}>
            <Grid item xs={6}>
              <RHFAutocompleteField
                control={control}
                options={collaboratorPersons?.map((item) => {
                  return {
                    id: item.personId,
                    label:
                      item.firstName +
                      ' ' +
                      (item.lastName ? item.lastName : ''),
                  }
                })}
                name="personId"
                required
                label={tScoped('Persons')}
              />
            </Grid>
          </Grid>
        </Box>

        <Typography variant="h2" mb={15}>
          {tScoped('Contract Templates')}
        </Typography>

        <Box mb={25}>
          <Grid container spacing={10}>
            <Grid item xs={6}>
              <RHFAutocompleteField
                control={control}
                options={contractTypes?.map((item) => {
                  return {
                    id: item.listId,
                    label: item.listValue,
                  }
                })}
                name="contractTypeId"
                required
                label={tScoped('Contract Types')}
              />
            </Grid>
          </Grid>
        </Box>

        <Typography variant="h2" mb={15}>
          {tScoped('Position')}
        </Typography>

        <Box mb={10}>
          <Grid container spacing={10}>
            <Grid item xs={2} sx={{ whiteSpace: 'nowrap' }}>
              <CustomButton
                label
                icon
                iconName="plus"
                labelText={tScoped('New Position')}
                onClick={() => setNewPositionForm(true)}
              />
            </Grid>
          </Grid>
        </Box>

        {newPositionForm && (
          <Box
            mb={10}
            sx={{ border: '1px solid #000000' }}
            pl={7}
            pt={11}
            pr={7}
            pb={12.5}
          >
            <Grid container spacing={10}>
              <Grid item xs={6}>
                <InputField
                  label={tScoped('Position')}
                  name="positionTitle"
                  fullWidth
                  control={control}
                  rules={{
                    required: {
                      value: true,
                      message: validationMessages.required,
                    },
                  }}
                  error={!!errors.positionTitle}
                  helperText={errors.positionTitle?.message}
                />
              </Grid>
              <Grid item xs={6}>
                <InputField
                  label={tScoped('Duration')}
                  name="duration"
                  fullWidth
                  control={control}
                  rules={{
                    required: {
                      value: true,
                      message: validationMessages.required,
                    },
                  }}
                  error={!!errors.duration}
                  helperText={errors.duration?.message}
                />
              </Grid>
            </Grid>

            <Grid container spacing={10}>
              <Grid item xs={6}>
                <InputField
                  label={tScoped('Hourly Fee')}
                  name="hourlyFee"
                  fullWidth
                  control={control}
                  rules={{
                    required: {
                      value: true,
                      message: validationMessages.required,
                    },
                  }}
                  error={!!errors.hourlyFee}
                  helperText={errors.hourlyFee?.message}
                />
              </Grid>
              <Grid item xs={6} marginTop="33px">
                <CustomDatePicker
                  name="billFrom"
                  label={tScoped('Billed From')}
                  control={control}
                  setValue={setValue}
                  clearErrors={clearErrors}
                  setError={setError}
                  required
                  dateFormat="dd/MM/yyyy"
                  minSelectableDate={billedFrom}
                />
              </Grid>
            </Grid>

            <Box mb={10}>
              <Grid container spacing={10}>
                <Grid item xs={6} marginTop="33px">
                  <CustomDatePicker
                    name="billTo"
                    label={tScoped('Billed To')}
                    control={control}
                    setValue={setValue}
                    clearErrors={clearErrors}
                    setError={setError}
                    required
                    dateFormat="dd/MM/yyyy"
                    minSelectableDate={minSelectableDate}
                  />
                </Grid>
                <Grid item xs={6} container alignItems="center">
                  <Grid container>
                    <Grid item xs={3}>
                      <CustomCheckbox
                        label={tScoped('Kick-Off')}
                        name="phasePreference.kickOff"
                        control={control}
                      />
                    </Grid>
                    <Grid item xs={3}>
                      <CustomCheckbox
                        label={tScoped('First-Steps')}
                        name="phasePreference.firstStep"
                        control={control}
                      />
                    </Grid>
                    <Grid item xs={3}>
                      <CustomCheckbox
                        label={tScoped('Set-Up')}
                        name="phasePreference.setUp"
                        control={control}
                      />
                    </Grid>
                    <Grid item xs={3}>
                      <CustomCheckbox
                        label={tScoped('Studies')}
                        name="phasePreference.studies"
                        control={control}
                      />
                    </Grid>
                  </Grid>
                </Grid>
              </Grid>
            </Box>

            <Box sx={{ display: 'flex' }}>
              <Grid container direction="row">
                <Grid item>
                  <Typography sx={{ fontWeight: 400, fontSize: '16px' }}>
                    {tScoped('Total Fee')}
                  </Typography>
                  <Typography
                    sx={{ fontWeight: 700, fontSize: '20px', color: '#000000' }}
                  >
                    {durationState ? durationState : '0'} x{' '}
                    {hourlyFeeState ? hourlyFeeState : '0'} € ={' '}
                    {durationState * hourlyFeeState
                      ? durationState * hourlyFeeState
                      : '0'}{' '}
                    €
                  </Typography>
                </Grid>
              </Grid>
              <Grid container direction="row-reverse" spacing={10}>
                <Grid item>
                  <CustomButton
                    label
                    labelText={tScoped('Save')}
                    variant="contained"
                    type="submit"
                    loading={submitLoading}
                  />
                </Grid>
                <Grid item>
                  <CustomButton label labelText="Delete" onClick={() => {}} />
                </Grid>
                <Grid item>
                  <CustomButton
                    label
                    labelText={tScoped('Cancel')}
                    onClick={() => {
                      setNewPositionForm(false)
                    }}
                  />
                </Grid>
              </Grid>
            </Box>
          </Box>
        )}

        {position?.contractDetail?.map((ele: IContractPosition) => {
          return (
            <Box mb={10} key={ele.contractDetailId}>
              <ContractPosition
                positionTitle={ele.positionTitle}
                billFrom={ele.billFrom}
                billTo={ele.billTo}
                hourlyFee={ele.hourlyFee}
                duration={ele.duration}
                phaseId={ele.phaseId}
              />
            </Box>
          )
        })}

        <Box mb={25}>
          <Grid container paddingRight={11} justifyContent="flex-end">
            <Typography sx={{ fontWeight: 700, fontSize: '20px' }}>
              {tScoped('Total amount of all positions')}
            </Typography>
          </Grid>
          <Grid container justifyContent="flex-end">
            {' '}
            <Typography
              sx={{ fontWeight: 700, fontSize: '20px', color: '#E40422' }}
            >
              {total} €
            </Typography>{' '}
          </Grid>
        </Box>

        <Box>
          <Grid container spacing={10}>
            <Grid item xs={6} container sx={{ justifyContent: 'end' }}>
              <CustomButton
                label
                labelText={tScoped('Discard')}
                sx={{ width: '200px' }}
                onClick={() => discardHandler()}
              />
            </Grid>
            <Grid item xs={6}>
              <CustomButton
                label
                labelText={tScoped('Save')}
                sx={{ width: '200px' }}
                variant="contained"
              />
            </Grid>
          </Grid>
        </Box>
      </Box>
    </>
  )
}

export default CreateContract
