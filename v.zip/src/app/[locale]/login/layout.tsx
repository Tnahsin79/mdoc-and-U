import { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'TTMP | Login',
  description: 'Employee Login page',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return children
}
