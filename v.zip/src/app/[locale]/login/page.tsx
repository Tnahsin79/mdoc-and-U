'use client'
import {
  Box,
  InputLabel,
  TextField,
  Typography,
  Checkbox,
  FormControlLabel,
  Grid,
  FormHelperText,
} from '@mui/material'
import { useContext, useState } from 'react'
import { AxiosError } from 'axios'
import { useRouter } from 'next/navigation'
import { useForm, SubmitHandler } from 'react-hook-form'
import Link from 'next/link'

import axiosInstance from '@/services/axiosInstance'
import CustomButton from '@/components/Buttons/CustomButton'
import { CandidateRoutes, CollaboratorRoutes, routes } from '@/utils/constants'
import { errorMessages } from '@/utils/errorMessages'
import { validators } from '@/validators'
import { UserContext } from '@/contexts/userContext'
import { useScopedI18n } from '../../../../locales/client'

interface LoginPageInterface {
  email: string
  password: string
  rememberMe?: boolean
}

const Login = () => {
  const tScoped = useScopedI18n('login')
  const router = useRouter()
  const [serverError, setServerError] = useState<string>('')
  const { setUser } = useContext(UserContext)

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<LoginPageInterface>({
    shouldFocusError: true,
  })

  const loginHandler: SubmitHandler<LoginPageInterface> = async (payload) => {
    try {
      const response = await axiosInstance.post('/api/auth/login', payload)
      setUser(response?.data?.person)

      if (
        response.statusText === 'OK' &&
        response.data.person.role === 'Candidate'
      ) {
        router.push(CandidateRoutes.dashboard)
      } else if (
        response.statusText === 'OK' &&
        response.data.person.role === 'Employee'
      ) {
        router.push(routes.dashboard)
      } else if (
        response.statusText === 'OK' &&
        response.data.person.role === 'Collaborator'
      ) {
        router.push(CollaboratorRoutes.dashboard)
      }
    } catch (error) {
      const errorMessage =
        error instanceof AxiosError
          ? error.response?.data?.error
          : errorMessages.DEFAULT_ERROR
      setServerError(errorMessage)
    }
  }
  return (
    <>
      <Typography variant="h1" marginBottom={13.2}>
        {tScoped('Welcome to TTMP')}
      </Typography>

      <Typography variant="subtitle1" marginBottom={18}>
        {tScoped('Please enter your account details to login')}
      </Typography>

      <Box component="form" onSubmit={handleSubmit(loginHandler)}>
        <Grid
          sx={{
            display: 'grid',
            gridTemplateColumns: { sm: '1fr 1fr' },
            gap: 10,
          }}
        >
          <div>
            <InputLabel htmlFor="email">{tScoped('Email')}</InputLabel>
            <TextField
              id="email"
              fullWidth
              {...register('email', {
                required: {
                  value: true,
                  message: tScoped('Email is required.'),
                },
                pattern: {
                  value: validators.email,
                  message: tScoped('Enter a valid email.'),
                },
              })}
              error={!!errors.email}
              helperText={errors.email?.message}
            />
          </div>

          <div>
            <InputLabel htmlFor="password">{tScoped('Password')}</InputLabel>
            <TextField
              id="password"
              type="password"
              fullWidth
              {...register('password', {
                required: {
                  value: true,
                  message: tScoped('Password is required.'),
                },
                minLength: {
                  value: 8,
                  message: tScoped(
                    'Password must be at least 8 characters long.',
                  ),
                },

                pattern: {
                  value: validators.password,
                  message: tScoped(
                    'Password must contain at least one uppercase letter, one lowercase letter, one number, and one special character',
                  ),
                },
              })}
              error={!!errors.password}
              helperText={errors.password?.message}
            />
          </div>
        </Grid>

        {serverError === '' ? null : (
          <FormHelperText error>{serverError}</FormHelperText>
        )}

        <Box
          sx={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            marginBottom: '56px',
            color: '#000000',
          }}
        >
          <FormControlLabel
            control={<Checkbox {...register('rememberMe')} defaultChecked />}
            label={tScoped('Remember me')}
          />

          <Link href={routes.forgotPassword}>
            <Typography variant="subtitle2" color="black">
              {tScoped('Forgot Password?')}
            </Typography>
          </Link>
        </Box>

        <Grid container justifyContent="center" alignItems="center" gap={10}>
          <CustomButton
            variant="contained"
            type="submit"
            sx={{ width: '200px' }}
            label={true}
            labelText={tScoped('Login')}
          />
        </Grid>
      </Box>
    </>
  )
}

export default Login
