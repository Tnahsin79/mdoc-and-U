'use client'

import { Box, InputLabel, TextField, Typography, Grid } from '@mui/material'
import { useEffect, useState } from 'react'
import { useForm, SubmitHandler } from 'react-hook-form'
import { useRouter } from 'next/navigation'

import axiosInstance from '@/services/axiosInstance'
import CustomButton from '@/components/Buttons/CustomButton'
import { validators } from '@/validators'
import { errorMessages } from '@/utils/errorMessages'
import Toast from '@/components/Toast'
import { frontendRoutes } from '@/utils/constants/frontend'
import { useScopedI18n } from '../../../../locales/client'

interface ForgotPasswordPageInterface {
  email: string
}

interface IToastData {
  type: 'success' | 'info' | 'warning' | 'error' | undefined
  message: string
}

const ForgotPassword = () => {
  const tScoped = useScopedI18n('forgotPassword')
  const router = useRouter()
  const [toastData, setToastData] = useState<IToastData>({
    type: undefined,
    message: '',
  })

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<ForgotPasswordPageInterface>({
    shouldFocusError: true,
  })

  useEffect(() => {
    setTimeout(() => {
      setToastData({
        type: undefined,
        message: '',
      })
    }, 5000)
  }, [toastData.message])

  const ForgotPasswordHandler: SubmitHandler<
    ForgotPasswordPageInterface
  > = async (data) => {
    const payload = {
      email: data.email,
    }
    try {
      const response = await axiosInstance.post(
        '/api/auth/forgot-password',
        payload,
      )

      if (response.statusText === 'OK') {
        setToastData({ type: 'success', message: response.data.message })
      }
    } catch (error: any) {
      if (error.response.status === 406) {
        return setToastData({
          type: 'success',
          message: error.response?.data?.error,
        })
      } else {
        setToastData({ type: 'error', message: errorMessages.DEFAULT_ERROR })
      }
    }
  }
  return (
    <>
      <Typography variant="h1" marginBottom={13.2}>
        {tScoped('Forgot Password')}
      </Typography>

      <Typography variant="subtitle1" marginBottom={18}>
        {tScoped('Please enter your Email')}
      </Typography>

      <Box component="form" onSubmit={handleSubmit(ForgotPasswordHandler)}>
        <Box sx={{ maxWidth: '50%', margin: '0 auto' }}>
          <InputLabel htmlFor="email">{tScoped('Email')}</InputLabel>
          <TextField
            id="email"
            fullWidth
            {...register('email', {
              required: { value: true, message: '' },
              pattern: {
                value: validators.email,
                message: tScoped('Enter a valid email.'),
              },
            })}
            error={!!errors.email}
            helperText={errors.email?.message}
          />
        </Box>

        {toastData.message && (
          <Toast message={toastData.message} severity={toastData.type} />
        )}

        <Grid
          container
          justifyContent="center"
          alignItems="center"
          gap={10}
          pt={20}
        >
          <CustomButton
            sx={{ width: '200px' }}
            label={true}
            labelText={tScoped('Discard')}
            onClick={() => router.push(frontendRoutes.login)}
          />

          <CustomButton
            variant="contained"
            type="submit"
            sx={{ width: '200px' }}
            label={true}
            labelText={tScoped('Submit')}
          />
        </Grid>
      </Box>
    </>
  )
}

export default ForgotPassword
