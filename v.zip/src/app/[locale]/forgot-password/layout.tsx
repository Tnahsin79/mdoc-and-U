import { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'TTMP | Forgot Password',
  description: 'Forgot Password page',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return children
}
