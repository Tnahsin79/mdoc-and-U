import { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'TTMP | Signup',
  description: 'Employee Sing up page',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return children
}
