'use client'

import { useState } from 'react'
import { AxiosError } from 'axios'
import { validators } from '@/validators'
import { useRouter } from 'next/navigation'
import { landingPage } from '@/utils/constants/frontend'
import { errorMessages } from '@/utils/errorMessages'
import { useForm, SubmitHandler } from 'react-hook-form'
import {
  Box,
  InputLabel,
  TextField,
  Typography,
  Grid,
  FormHelperText,
} from '@mui/material'

import Link from 'next/link'
import axiosInstance from '@/services/axiosInstance'
import CustomButton from '@/components/Buttons/CustomButton'

interface SignupPageInterface {
  email: string
  fullName: string
  password: string
  confirmPassword: string
}

const Signup = () => {
  const router = useRouter()
  const {
    register,
    handleSubmit,
    watch,
    formState: { errors },
    reset,
  } = useForm<SignupPageInterface>({
    shouldFocusError: true,
  })

  const [serverError, setServerError] = useState<string>('')

  const createAccountHandler: SubmitHandler<SignupPageInterface> = async (
    payload,
  ) => {
    try {
      const response = await axiosInstance.post('/api/auth/signup', payload)

      if (response.statusText === 'Created') {
        reset()
        router.push(landingPage)
      }
    } catch (error) {
      const errorMessage =
        error instanceof AxiosError
          ? error.response?.data?.error
          : errorMessages.DEFAULT_ERROR
      setServerError(errorMessage)
    }
  }

  return (
    <>
      <Typography variant="h1" marginBottom={13.2}>
        Create Account
      </Typography>

      <Typography variant="subtitle1" marginBottom={18}>
        Please enter your details to create account
      </Typography>

      <Box component="form" onSubmit={handleSubmit(createAccountHandler)}>
        <Grid
          sx={{
            display: 'grid',
            gridTemplateColumns: { sm: '1fr 1fr' },
            gap: 10,
          }}
        >
          <div>
            <InputLabel htmlFor="email">Email</InputLabel>
            <TextField
              id="email"
              type="email"
              fullWidth
              {...register('email', {
                required: { value: true, message: 'Email is required.' },
                pattern: {
                  value: validators.email,
                  message: 'Enter a valid email.',
                },
              })}
              error={!!errors.email}
              helperText={errors.email?.message}
            />
          </div>

          <div>
            <InputLabel htmlFor="fullName">Full Name</InputLabel>
            <TextField
              id="fullName"
              type="text"
              fullWidth
              {...register('fullName', {
                required: { value: true, message: 'Full Name is required.' },
                pattern: {
                  value: validators.fullName,
                  message: 'Enter a valid full name.',
                },
              })}
              error={!!errors.fullName}
              helperText={errors.fullName?.message}
            />
          </div>
        </Grid>

        <Grid
          sx={{
            display: 'grid',
            gridTemplateColumns: { sm: '1fr 1fr' },
            gap: 10,
          }}
          mb={40}
        >
          <div>
            <InputLabel htmlFor="password">Password</InputLabel>
            <TextField
              id="password"
              type="password"
              fullWidth
              {...register('password', {
                required: { value: true, message: 'Password is required' },
                minLength: {
                  value: 8,
                  message: 'Password must be at least 8 characters long.',
                },

                pattern: {
                  value: validators.password,
                  message:
                    'Password must contain at least one uppercase letter, one lowercase letter, one number, and one special character',
                },
              })}
              error={!!errors.password}
              helperText={errors.password?.message}
            />

            {serverError === '' ? null : (
              <FormHelperText error>{serverError}</FormHelperText>
            )}
          </div>

          <div>
            <InputLabel htmlFor="confirmPassword">Confirm Password</InputLabel>
            <TextField
              id="confirmPassword"
              type="password"
              fullWidth
              {...register('confirmPassword', {
                required: {
                  value: true,
                  message: 'Confirm Password is required',
                },
                validate: (val: string) => {
                  if (watch('password') != val) {
                    return 'Your passwords do no match'
                  }

                  return undefined
                },
              })}
              error={!!errors.confirmPassword}
              helperText={errors.confirmPassword?.message}
            />
          </div>
        </Grid>

        <Grid container justifyContent="center" alignItems="center" mb={11.25}>
          <CustomButton
            variant="outlined"
            type="submit"
            sx={{ width: '590px' }}
            label={true}
            labelText="Create Account"
            fullWidth
          />
        </Grid>

        <Typography align="center">
          Already have an account?{' '}
          <Link href="/login" style={{ fontWeight: '700', color: '#000' }}>
            Login
          </Link>
        </Typography>
      </Box>
    </>
  )
}

export default Signup
