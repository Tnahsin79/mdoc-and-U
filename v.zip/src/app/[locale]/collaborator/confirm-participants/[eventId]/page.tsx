/* eslint-disable react/no-deprecated */
'use client'
import { useContext, useEffect, useRef, useState } from 'react'
import moment from 'moment'
import { Box, Grid, LinearProgress, Typography } from '@mui/material'
import { FormProvider, SubmitHandler, useForm } from 'react-hook-form'
import {
  Event,
  EventCollaborator,
  EventCollaboratorAttendees,
  EventTemplate,
  List,
  Person,
  Role,
  Rooms,
} from '@prisma/client'
import { useParams, useRouter } from 'next/navigation'
import { AxiosError } from 'axios'
import ReactDOM from 'react-dom'

import Button from '@/components/Buttons/CustomButton'
import CustomButton from '@/components/Buttons/CustomButton'
import { RHFAutocompleteField } from '@/components/DropDown'
import InputField from '@/components/InputField'
import { RHFTextArea } from '@/components/TextArea'
import CustomDatePicker from '@/components/DatePicker'
import AssignRoom from '@/components/AssignRoom'
import axiosInstance from '@/services/axiosInstance'
import { errorMessages } from '@/utils/errorMessages'
import AssignCollaborators from '@/components/AssignCollaborators'
import AssignAttendees from '@/components/AssignAttendess'
import CustomRadioGroup from '@/components/RadioGroup'
import { EVENT_ACCESS_TYPE, frontendRoutes } from '@/utils/constants/frontend'
import Toast from '@/components/Toast'
import { IList } from '@/interface/common'
import { IEditEventPage } from '@/interface/event'
import { berlinHolidays } from '@/utils/constants/frontend'
import { UserContext } from '@/contexts/userContext'
import CandidatePrintView from '@/components/CandidatePrintView'
import { convertArrayOfObjectsToCSV } from '@/utils/arrayToCsv'
import { useScopedI18n } from '../../../../../../locales/client'
import { Edit } from '@mui/icons-material'

interface IModalData {
  type: string
  open: boolean
}

interface IToastData {
  type: 'success' | 'info' | 'warning' | 'error' | undefined
  message: string
}

type IListItem = {
  list: {
    listType: string
    listId: number
    listValue: string
  }
}

type ExtendedEvent = Event & {
  equipmentId?: IListItem[]
  suitableCollaborators: Person[]
  attendees: Person[]
}

const ConfirmParticipants = () => {
  const tScoped = useScopedI18n('event')
  const tDashboardScoped = useScopedI18n('dashboard')
  const iframeRef = useRef<HTMLIFrameElement>(null)
  const { user } = useContext(UserContext)
  const { eventId }: { eventId: string } = useParams()
  const router = useRouter()
  const [modalData, setModalData] = useState<IModalData>({
    open: false,
    type: '',
  })
  const [templates, setTemplates] = useState<EventTemplate[]>([
    {
      templateId: undefined!,
      templateName: 'No template',
      collaboratorOrigin: null,
      description: '',
      eventDuration: null,
      eventKey: '',
      eventTypeId: null,
      maxParticipants: null,
      minParticipants: null,
      subjectAreaId: null,
      subjectModule: null,
      phaseId: null,
      isActive: true,
    },
  ])
  const [subjectAreas, setSubjectAreas] = useState<IList>([])
  const [eventTypes, setEventTypes] = useState<IList>([])
  const [locations, setLocations] = useState<IList>([])
  const [equipments, setEquipments] = useState<IList>([])
  const [suitableCollaborators, setSuitableCollaborators] = useState<any>([])
  const [suitableRooms, setSuitableRooms] = useState<Rooms[] | []>([])
  const [loading, setLoading] = useState<boolean>(true)
  const [eventStatus, setEventStatus] = useState<IList>([])
  const [eventRepeats, setEventRepeats] = useState<IList>([])
  const [phases, setPhases] = useState<IList>([])
  const [attendees, setAttendees] = useState<any>({})
  const [submitLoading, setSubmitLoading] = useState<boolean>(false)
  const [toastData, setToastData] = useState<IToastData>({
    type: undefined,
    message: '',
  })
  const [candidates, setCandidates] = useState()
  const [isRequestCancelled, setIsRequestCancelled] = useState<boolean | null>(
    null,
  )
  const [isRequestConfirmed, setIsRequestConfirmed] = useState<boolean | null>(
    null,
  )
  const [eventData, setEventData] = useState<ExtendedEvent | null>(null)
  const [selectedCandidateData, setSelectedCandidateData] =
    useState<EventCollaboratorAttendees[]>()
  const [confirmationRequestData, setConfirmationRequestData] =
    useState<EventCollaborator>()
  const [
    isCollaboratorAndFirstStepsAndPlanned,
    setIsCollaboratorAndFirstStepsAndPlanned,
  ] = useState<boolean>(false)

  const [collaboratorsAsAttendees, setCollaboratorsAsAttendees] = useState<
    { collaboratorId: number }[]
  >([])

  const EditEventHandler = async () => {
    try {
      const data = {
        description: description,
        bookedFrom: bookedFrom,
        startTime: startTime,
        endTime: endTime,
      }

      const res = await axiosInstance.post('/api/event/collaborator-update', {
        eventId: eventId,
        ...data,
      })
    } catch (error) {
      setToastData({
        type: 'error',
        message:
          error instanceof AxiosError
            ? error.response?.data?.error
            : errorMessages.DEFAULT_ERROR,
      })
    }
  }

  const methods = useForm<IEditEventPage>({
    mode: 'all',
    defaultValues: {
      eventStatus: '',
      equipmentId: [],
      phaseId: undefined,
    },
    shouldFocusError: true,
  })

  const {
    control,
    watch,
    setValue,
    clearErrors,
    setError,
    reset,
    handleSubmit,
  } = methods

  const endTime = watch('endTime')
  const description = watch('description')
  const isEventRepeats = watch('isEventRepeats')
  const startTime = watch('startTime')
  const bookedFrom = watch('bookedFrom')
  const eventAccessMethod = watch('eventManner')
  const excludeBerlinHolidays = watch('excludeBerlinHolidays')
  const locationId = watch('locationId')
  const suitableCollaboratorId = watch('suitableCollaboratorId')
  const attendeesId = watch('attendeesId')
  const eventStatusFormValue = watch('eventStatus')
  const cancelledEventStatusId = eventStatus.filter(
    (item) => item.listValue === 'Cancelled',
  )[0]?.listId

  const candidateCsvHeaders = {
    personId: 'Person ID',
    firstName: 'First Name',
    lastName: 'Last Name',
    email: 'Email',
    role: 'Role',
  }

  useEffect(() => {
    getFormData()
  }, [])

  useEffect(() => {
    setTimeout(() => {
      setToastData({
        type: undefined,
        message: '',
      })
    }, 5000)
  }, [JSON.stringify(toastData)])

  useEffect(() => {
    if (eventData && eventData?.eventId) {
      const candidateParticipants = eventData?.attendees?.map(
        (attendee: any) => `${attendee.moduleName}_${attendee.attendeeId}`,
      )

      const collaboratorParticipants = collaboratorsAsAttendees.map(
        (attendee: any) => `Collaborator_${attendee.collaboratorId}`,
      )

      reset({
        templateId: eventData.templateId ?? undefined,
        subjectAreaId: eventData.subjectAreaId,
        subjectModule: eventData.subjectModule,
        phaseId: eventData.phaseId.toString(),
        eventTypeId: eventData.eventTypeId,
        title: eventData.title,
        minParticipants: eventData.minParticipants.toString(),
        maxParticipants: eventData.maxParticipants.toString(),
        lmsLink: eventData.lmsLink ?? '',
        description: eventData.description ?? '',
        reason: eventData.reason ?? '',
        accessLink: eventData.accessLink,
        eventRepeatId: eventData?.eventRepeatId?.toString(),
        eventManner: eventData.eventManner,
        eventStatus: eventData.eventStatusId.toString(),
        equipmentId: eventData?.equipmentId
          ?.map((item) => item.list)
          .map((list) => list.listId),
        excludeBerlinHolidays: false,
        locationId: eventData?.locationId,
        suitableRoomId: eventData.suitableRoomsId,
        suitableCollaboratorId: eventData.suitableCollaboratorId,
        attendeesId: [...candidateParticipants, ...collaboratorParticipants],
        bookedFrom: eventData.bookedFrom
          ? new Date(eventData.bookedFrom)
          : undefined,
        bookedTo: eventData.bookedTo ? new Date(eventData.bookedTo) : undefined,
        startTime: new Date(eventData.startTime),
        endTime: new Date(eventData.endTime),
        isEventRepeats: !!eventData?.eventRepeatId,
        barrierFreeAccess: eventData.barrierFreeAccess,
      })

      const plannedId = eventStatus.find(
        (status) => status.listValue === 'geplant',
      )?.listId
      const firstStepsPhaseId = phases
        .find((status) => status.listValue === 'FIRST-STEPS')
        ?.listId.toString()
      const cond =
        eventStatusFormValue === plannedId?.toString() &&
        eventData?.phaseId.toString() === firstStepsPhaseId
      setIsCollaboratorAndFirstStepsAndPlanned(cond)
    }
  }, [eventData])

  const minSelectableTime = startTime
    ? moment(startTime).add(1, 'minutes').toDate()
    : undefined

  const minSelectableDate = bookedFrom
    ? moment(bookedFrom).add(0, 'days').toDate()
    : undefined

  const handleModals = (data: IModalData) => {
    setModalData(data)
  }

  const handleClose = () => {
    setModalData({ type: '', open: false })
  }

  const getFormData = async () => {
    try {
      const payload = {
        listTypes: [
          'template',
          'subjectArea',
          'eventType',
          'location',
          'equipment',
          'suitableRooms',
          'suitableCollaborators',
          'eventStatus',
          'eventRepeats',
          'phase',
          'attendees',
        ],
      }
      const getEventsData = axiosInstance.get(`/api/event/${eventId}`)
      const getListData = axiosInstance.post('/api/list', payload)
      const getAttendeesData = axiosInstance.get('/api/event/get-attendees')
      const getCollaboratorsData = axiosInstance.get(
        '/api/event/get-collaborators',
      )
      const getCandidates = axiosInstance.get(
        `/api/event/get-candidates/${eventId}`,
      )
      const getSelectedCandidateData = axiosInstance.get(
        `/api/collaborator/match-list/${eventId}`,
      )

      const getConfirmationRequestData = axiosInstance.get(
        `/api/collaborator/event?eventId=${eventId}&collaboratorId=${user?.personId}`,
      )
      const getTemplates = axiosInstance.post('/api/event/template', {
        all: true,
        isListInEvent: true,
      })

      const [
        suitableRooms,
        dropdownItemData,
        eventsData,
        attendeesData,
        collaboratorsData,
        candidatesData,
        selectedCandidateData,
        confirmationRequestData,
        templatesData,
      ] = await Promise.all([
        axiosInstance.get('/api/room'),
        getListData,
        getEventsData,
        getAttendeesData,
        getCollaboratorsData,
        getCandidates,
        getSelectedCandidateData,
        getConfirmationRequestData,
        getTemplates,
      ])

      setTemplates([...templates, ...templatesData.data.templateList])
      setSubjectAreas(dropdownItemData.data.data.subjectArea)
      setEventTypes(dropdownItemData.data.data.eventType)
      setLocations(dropdownItemData.data.data.location)
      setEquipments(dropdownItemData.data.data.equipment)
      setSuitableRooms(suitableRooms.data.rooms)
      setSuitableCollaborators(collaboratorsData.data)
      setEventStatus(
        dropdownItemData.data.data.eventStatus.filter(
          (item: List) => !['gehalten', 'abgesagt'].includes(item.listValue),
        ),
      )
      setEventRepeats(dropdownItemData.data.data.eventRepeats)
      setPhases(dropdownItemData.data.data.phase)
      setEventData(eventsData.data.event)
      setAttendees(attendeesData.data)
      setCandidates(candidatesData.data.candidates)
      setSelectedCandidateData(selectedCandidateData.data.data)
      setConfirmationRequestData(confirmationRequestData.data.data)

      const collsAsParticipants = eventsData.data.collaboratorsAsAttendees
      setCollaboratorsAsAttendees(collsAsParticipants)
    } catch (error: unknown) {
      if (error instanceof Error) {
        setToastData({
          type: 'error',
          message: error?.message || errorMessages.DEFAULT_ERROR,
        })
      }
    } finally {
      setLoading(false)
    }
  }

  const cancelEventParticipation = () => {
    setIsRequestCancelled(true)
    const payload = {
      eventId: +eventId,
      collaboratorId: user?.personId,
      isConfirmed: false,
    }
    axiosInstance
      .post('/api/collaborator/event', payload)
      .then((response) => {
        if (response.status === 201) {
        } else {
          setToastData({
            type: 'error',
            message: errorMessages.DEFAULT_ERROR,
          })
        }
      })
      .catch((error) => {
        setToastData({
          type: 'error',
          message:
            error instanceof AxiosError
              ? error.response?.data?.error
              : errorMessages.DEFAULT_ERROR,
        })
      })
  }

  const confirmEventParticipation = () => {
    setSubmitLoading(true)
    setIsRequestConfirmed(true)

    const payload = {
      eventId: +eventId,
      collaboratorId: user?.personId,
      isConfirmed: true,
    }
    axiosInstance
      .post('/api/collaborator/event', payload)
      .then((response) => {
        if (response.status === 201) {
        } else {
          setToastData({
            type: 'error',
            message: errorMessages.DEFAULT_ERROR,
          })
        }
      })
      .catch((error) => {
        setToastData({
          type: 'error',
          message:
            error instanceof AxiosError
              ? error.response?.data?.error
              : errorMessages.DEFAULT_ERROR,
        })
      })
      .finally(() => {
        setSubmitLoading(false)
      })
  }

  const cancelParticipation = () => {
    setIsRequestCancelled(true)
  }

  const handlePrint = () => {
    const iframeElem = iframeRef.current
    if (!iframeElem) return

    const iframeDoc =
      iframeElem.contentDocument || iframeElem.contentWindow?.document
    if (!iframeDoc) return

    ReactDOM.render(
      <CandidatePrintView candidates={candidates} />,
      iframeDoc.body,
    )

    iframeElem.contentWindow?.print()
  }

  const downloadCSV = (candidatesData: any) => {
    const link = document.createElement('a')
    let csv = convertArrayOfObjectsToCSV(candidatesData, candidateCsvHeaders)
    if (csv == null) return

    const filename = 'list-of-participants.csv'

    if (!csv.match(/^data:text\/csv/i)) {
      csv = 'data:text/csv;charset=utf-8,' + csv
    }

    link.setAttribute('href', encodeURI(csv))
    link.setAttribute('download', filename)
    link.click()
  }

  if (loading) {
    return (
      <Box
        sx={{
          position: 'fixed',
          top: 0,
          left: 0,
          width: '100%',
          zIndex: 9999,
        }}
      >
        <LinearProgress />
      </Box>
    )
  }

  return (
    <>
      <iframe
        ref={iframeRef}
        style={{ display: 'none' }}
        title="print"
      ></iframe>

      {toastData.message !== '' ? (
        <Toast message={toastData.message} severity={toastData.type} />
      ) : null}

      <FormProvider {...methods}>
        <AssignRoom
          open={modalData.type === 'room' && modalData.open}
          handleClose={handleClose}
          locations={locations}
          equipments={equipments}
          suitableRooms={suitableRooms}
          readOnly
        />

        <AssignCollaborators
          open={modalData.type === 'collaborators' && modalData.open}
          handleClose={handleClose}
          suitableCollaborators={suitableCollaborators}
          phases={phases}
          subjectAreas={subjectAreas}
          readOnly
        />

        <AssignAttendees
          open={modalData.type === 'attendees' && modalData.open}
          handleClose={handleClose}
          phases={phases}
          attendees={attendees}
          subjectAreas={subjectAreas}
          readOnly
        />

        <Box>
          <Grid container justifyContent="space-between" mb={25}>
            <Grid item display="flex" alignItems="flex-end" gap={10}>
              <Typography variant="h1" mb={0}>
                {tScoped('Event Participation Confirm/Cancel')}
              </Typography>
            </Grid>
            <Grid item>
              <CustomButton
                icon
                label
                labelText={tDashboardScoped('Back')}
                iconName="arrowLeft"
                onClick={() => router.back()}
              />
            </Grid>
          </Grid>

          <Box mb={25}>
            <Grid container spacing={10}>
              <Grid item xs={12} md={6}>
                <RHFAutocompleteField
                  control={control}
                  options={templates?.map((item) => {
                    return {
                      id: item.templateId,
                      label: item.templateName,
                    }
                  })}
                  name="templateId"
                  label={tScoped('Template')}
                  readOnly
                />
              </Grid>
            </Grid>
          </Box>

          <Typography variant="h2">{tScoped('General Information')}</Typography>

          <Grid container spacing={10}>
            <Grid item xs={12} sm={6}>
              <RHFAutocompleteField
                control={control}
                options={subjectAreas?.map((item) => {
                  return {
                    id: item.listId,
                    label: item.listValue,
                  }
                })}
                name="subjectAreaId"
                label={tScoped('Subject Area')}
                readOnly
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <InputField
                control={control}
                name="subjectModule"
                label={tScoped('Subject Module')}
                fullWidth
                readOnly
              />
            </Grid>
            <Grid
              item
              xs={12}
              md={6}
              justifyContent="center"
              alignItems="center"
            >
              <CustomRadioGroup
                name="phaseId"
                row
                label={tScoped('Phase')}
                control={control}
                options={phases?.map((item) => {
                  return {
                    value: item.listId.toString(),
                    label: item.listValue,
                  }
                })}
                disabled
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <RHFAutocompleteField
                control={control}
                options={eventTypes?.map((item) => {
                  return {
                    id: item.listId,
                    label: item.listValue,
                  }
                })}
                name="eventTypeId"
                label={tScoped('Event Type')}
                readOnly
              />
            </Grid>

            <Grid item xs={12} md={6}>
              <InputField
                control={control}
                name="title"
                label={tScoped('Event Title')}
                fullWidth
                readOnly
              />
            </Grid>
            <Grid item xs={12} md={6}></Grid>
            <Grid item xs={12} md={6}>
              <InputField
                control={control}
                name="minParticipants"
                label={tScoped('Min Attendees')}
                fullWidth
                readOnly
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <InputField
                control={control}
                name="maxParticipants"
                label={tScoped('Max Attendees')}
                fullWidth
                readOnly
              />
            </Grid>
            <Grid item xs={12}>
              <RHFTextArea
                control={control}
                name="description"
                label={tScoped('Description')}
                readOnly={!isCollaboratorAndFirstStepsAndPlanned}
              />
            </Grid>
            <Grid
              item
              xs={12}
              md={6}
              justifyContent="center"
              alignItems="center"
            >
              <CustomRadioGroup
                name="eventManner"
                row
                label={tScoped('Access Method')}
                control={control}
                options={EVENT_ACCESS_TYPE.map((item) => {
                  return {
                    value: item,
                    label: item,
                  }
                })}
                disabled
              />
            </Grid>
            <Grid
              item
              xs={12}
              md={6}
              justifyContent="center"
              alignItems="center"
            >
              <InputField
                control={control}
                name="accessLink"
                label={tScoped('Access Link')}
                fullWidth
                readOnly
              />
            </Grid>
          </Grid>

          <Box mt={25} mb={15}>
            <Typography variant="h2">{tScoped('Event Status')}</Typography>
            <Grid container spacing={10}>
              <Grid item xs={12}>
                <CustomRadioGroup
                  name="eventStatus"
                  row
                  label={tScoped('Event Status')}
                  control={control}
                  options={eventStatus?.map((item) => {
                    return {
                      value: item?.listId.toString(),
                      label: item?.listValue,
                    }
                  })}
                  disabled
                />
              </Grid>
              {cancelledEventStatusId === +eventStatusFormValue! && (
                <Grid item xs={12}>
                  <RHFTextArea
                    control={control}
                    name="reason"
                    label={tScoped('Reason')}
                    readOnly
                  />
                </Grid>
              )}
            </Grid>
          </Box>

          <Box mt={25} mb={15}>
            <Typography variant="h2">{tScoped('Event Times')}</Typography>
            <Grid container spacing={10}>
              <Grid item xs={6}>
                <CustomDatePicker
                  name="bookedFrom"
                  label={tScoped('Date')}
                  control={control}
                  setValue={setValue}
                  clearErrors={clearErrors}
                  setError={setError}
                  dateFormat="dd/MM/yyyy"
                  readOnly={!isCollaboratorAndFirstStepsAndPlanned}
                />
              </Grid>
              <Grid
                item
                xs={6}
                sx={{
                  display: 'flex',
                  flexDirection: 'column',
                  justifyContent: 'flex-start',
                  alignItems: 'flex-end',
                }}
              ></Grid>
              <Grid item xs={6}>
                <CustomDatePicker
                  readOnly={!isCollaboratorAndFirstStepsAndPlanned}
                  name="startTime"
                  label={tScoped('Start')}
                  control={control}
                  setValue={setValue}
                  clearErrors={clearErrors}
                  setError={setError}
                  showTimeSelect
                  showTimeSelectOnly
                  timeCaption="Time"
                  dateFormat="h:mm aa"
                  timeIntervals={15}
                  showFromText
                />
              </Grid>
              <Grid item xs={6}>
                <CustomDatePicker
                  readOnly={!isCollaboratorAndFirstStepsAndPlanned}
                  name="endTime"
                  label={tScoped('End')}
                  control={control}
                  setValue={setValue}
                  clearErrors={clearErrors}
                  setError={setError}
                  showTimeSelect
                  showTimeSelectOnly
                  timeCaption="Time"
                  dateFormat="h:mm aa"
                  timeIntervals={15}
                  minSelectableTime={minSelectableTime}
                  showUntilText
                />
              </Grid>
            </Grid>
          </Box>

          {isEventRepeats && (
            <>
              <Typography variant="h2">{tScoped('Event Series')}</Typography>

              <Box mb={25}>
                <Grid container spacing={10}>
                  <Grid item xs={6}>
                    <RHFAutocompleteField
                      control={control}
                      options={eventRepeats?.map((item) => ({
                        id: item?.listId.toString(),
                        label: item?.listValue,
                      }))}
                      name="eventRepeatId"
                      label={tScoped('Event Repeats')}
                      readOnly
                    />
                  </Grid>
                </Grid>
              </Box>

              <Box>
                <Grid container spacing={10}>
                  <Grid item xs={6}>
                    <CustomDatePicker
                      readOnly
                      name="bookedTo"
                      label={tScoped('End Date')}
                      control={control}
                      setValue={setValue}
                      clearErrors={clearErrors}
                      setError={setError}
                      minSelectableDate={minSelectableDate}
                      dateFormat="dd/MM/yyyy"
                      excludeDates={
                        excludeBerlinHolidays
                          ? berlinHolidays.map((date) => new Date(date))
                          : []
                      }
                    />
                  </Grid>
                </Grid>
              </Box>
            </>
          )}

          <Grid container spacing={{ xs: '10px', md: '30px' }}>
            {eventAccessMethod !== 'Online' && (
              <Grid item xs={12} sm={6} md={3}>
                <Box>
                  <Typography variant="h2">{tScoped('Rooms')}</Typography>
                  <Button
                    label
                    icon
                    sx={{
                      width: '100%',
                      background: locationId ? '#FBDBD4' : '',
                      '& .MuiButton-endIcon': {
                        marginLeft: 'auto',
                      },
                    }}
                    labelText={tScoped('Assign Rooms')}
                    iconName="plus"
                    onClick={() => handleModals({ type: 'room', open: true })}
                  />
                </Box>
              </Grid>
            )}
            <Grid item xs={12} sm={6} md={3}>
              <Box>
                <Typography variant="h2">{tScoped('Collaborators')}</Typography>
                <Button
                  label
                  icon
                  labelText={tScoped('Assign Collaborators')}
                  iconName="plus"
                  onClick={() =>
                    handleModals({ type: 'collaborators', open: true })
                  }
                  sx={{
                    width: '100%',
                    background: suitableCollaboratorId ? '#FBDBD4' : '',
                    '& .MuiButton-endIcon': {
                      marginLeft: 'auto',
                    },
                  }}
                />
              </Box>
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <Box>
                <Typography variant="h2">{tScoped('Attendees')}</Typography>
                <Button
                  label
                  icon
                  labelText={tScoped('Assign Attendees')}
                  iconName="plus"
                  onClick={() =>
                    handleModals({ type: 'attendees', open: true })
                  }
                  sx={{
                    width: '100%',
                    background: attendeesId ? '#FBDBD4' : '',
                    '& .MuiButton-endIcon': {
                      marginLeft: 'auto',
                    },
                  }}
                />
              </Box>
            </Grid>
          </Grid>

          <Box mt={25} mb={30}>
            <Typography variant="h2">{tScoped('Link')}</Typography>
            <Grid container spacing={10}>
              <Grid item xs={6}>
                <InputField
                  control={control}
                  name="lmsLink"
                  label={tScoped('LMS Link')}
                  fullWidth
                  readOnly
                />
              </Grid>
            </Grid>
          </Box>

          {/* {(isRequestConfirmed || confirmationRequestData?.isConfirmed) && ( */}
          {eventData?.suitableCollaboratorId === user?.personId && (
            <>
              <Typography variant="h2">List of Participants</Typography>

              <Grid container spacing={{ xs: '10px', md: '30px' }}>
                <Grid item xs={12} sm={6} md={3}>
                  <Box>
                    <Button
                      label
                      icon
                      sx={{
                        width: '100%',
                        '& .MuiButton-endIcon': {
                          marginLeft: 'auto',
                        },
                      }}
                      labelText={tScoped('Match Lists')}
                      iconName="compare"
                      onClick={() =>
                        router.push(`/collaborator/match-list/${eventId}`)
                      }
                    />
                  </Box>
                </Grid>
                <Grid item xs={12} sm={6} md={3}>
                  <Box>
                    <Button
                      label
                      icon
                      labelText={tScoped('Download List')}
                      iconName="download"
                      sx={{
                        width: '100%',
                        '& .MuiButton-endIcon': {
                          marginLeft: 'auto',
                        },
                      }}
                      onClick={() => downloadCSV(candidates)}
                    />
                  </Box>
                </Grid>
                <Grid item xs={12} sm={6} md={3}>
                  <Box>
                    <Button
                      label
                      icon
                      labelText={tScoped('Print List')}
                      iconName="print"
                      sx={{
                        width: '100%',
                        '& .MuiButton-endIcon': {
                          marginLeft: 'auto',
                        },
                      }}
                      onClick={handlePrint}
                    />
                  </Box>
                </Grid>
              </Grid>
            </>
          )}
          {/* )} */}

          {/* {(selectedCandidateData?.length === 0 ||
            !selectedCandidateData?.length ||
            (!confirmationRequestData?.eventId &&
              !isRequestConfirmed &&
              !isRequestCancelled)) && (
            <>
              <Typography variant="h2" textAlign="center" mt={15}>
                {tScoped('Do you want to confirm the request?')}
              </Typography>

              <Box>
                <Grid container spacing={10} justifyContent="center" mb={25}>
                  <Grid item>
                    <Button
                      label
                      labelText={tScoped('No')}
                      sx={{ minWidth: '200px' }}
                      onClick={() => cancelEventParticipation()}
                      disabled={submitLoading}
                    />
                  </Grid>

                  <Grid item>
                    <Button
                      label
                      labelText={tScoped('Yes')}
                      sx={{ minWidth: '200px' }}
                      variant="contained"
                      onClick={() => confirmEventParticipation()}
                      disabled={submitLoading}
                    />
                  </Grid>
                </Grid>
              </Box>
            </>
          )} */}
          {/* {((isRequestConfirmed && !isRequestCancelled) ||
            confirmationRequestData?.eventId) && ( */}
          {eventData?.suitableCollaboratorId === user?.personId && (
            <>
              {/* <Box display="flex" justifyContent="center" mb={30}>
                <Grid container spacing={10} justifyContent="center">
                  <Grid item>
                    <Button
                      label
                      labelText={tScoped('Save')}
                      onClick={EditEventHandler}
                      variant="contained"
                      loading={submitLoading}
                    />
                  </Grid>
                </Grid>
              </Box> */}
              <Box
                display="flex"
                justifyContent="center"
                alignItems="center"
                mt={50}
              >
                <Grid container item xs={6}>
                  <Button
                    label
                    labelText={tScoped('Save')}
                    onClick={EditEventHandler}
                    variant="contained"
                    loading={submitLoading}
                    sx={{ width: '100%' }}
                  />
                </Grid>
              </Box>
              <Box
                display="flex"
                justifyContent="center"
                alignItems="center"
                mb={3}
                mt={10}
              >
                <Grid container item xs={6}>
                  <Button
                    label
                    labelText={tScoped('Cancel Participation')}
                    type="submit"
                    onClick={() => cancelParticipation()}
                    sx={{ width: '100%' }}
                    disabled={submitLoading}
                  />
                </Grid>
              </Box>
            </>
          )}
        </Box>
      </FormProvider>
    </>
  )
}

export default ConfirmParticipants
