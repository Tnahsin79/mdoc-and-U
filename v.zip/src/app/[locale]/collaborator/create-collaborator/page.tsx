'use client'

import Toast from '@/components/Toast'
import InputField from '@/components/InputField'
import axiosInstance from '@/services/axiosInstance'
import CustomDatePicker from '@/components/DatePicker'
import CustomButton from '@/components/Buttons/CustomButton'
import AddAttachment from '@/components/Buttons/AddAttachment'

import { AxiosError, AxiosResponse } from 'axios'
import { validators } from '@/validators'
import { IList } from '@/interface/common'
import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { errorMessages } from '@/utils/errorMessages'
import { Collaborator, Person } from '@prisma/client'
import { SubmitHandler, useForm } from 'react-hook-form'
import { validationMessages } from '@/validators/messages'
import { RHFAutocompleteField } from '@/components/DropDown'
import { frontendRoutes } from '@/utils/constants/frontend'
import { useScopedI18n } from '../../../../../locales/client'
import { Box, Grid, InputLabel, Typography } from '@mui/material'

interface CreateCollaboratorsInterface extends Person, Collaborator {}

const CreateCollaborators = () => {
  const tScoped = useScopedI18n('collaborators.createCollaborators')
  const tDashboardScoped = useScopedI18n('dashboard')
  const router = useRouter()

  const {
    handleSubmit,
    formState: { errors },
    control,
    clearErrors,
    setValue,
    setError,
  } = useForm<CreateCollaboratorsInterface>({
    mode: 'all',
    defaultValues: {
      appellationId: undefined,
      dob: undefined,
      email: '',
      firstName: '',
      lastName: '',
      phoneNumber: '',
      title: '',
    },
    shouldFocusError: true,
  })
  const [appellationOptions, setAppellationOptions] = useState<IList>([])
  const [serverError, setServerError] = useState<string>('')
  const [fileUploading, setFileUploading] = useState<boolean>(false)
  const [currentFiles, setCurrentFiles] = useState<FileList | null>(null)

  const createCollaboratorsHandler: SubmitHandler<
    CreateCollaboratorsInterface
  > = async (payload) => {
    setServerError('')
    let responseFromFileServer: AxiosResponse | null = null

    const formData = new FormData()
    if (currentFiles) {
      setFileUploading(true)
      formData.append('file', currentFiles[0])
      responseFromFileServer = await axiosInstance.post('/api/upload', formData)

      if (responseFromFileServer && responseFromFileServer.status === 201) {
        setFileUploading(false)
      } else {
        throw new Error(errorMessages.FAILED_TO_UPLOAD_ATTACHMENT)
      }
    }

    try {
      const response = await axiosInstance.post('/api/collaborator/create', {
        ...payload,
        attachment: responseFromFileServer?.data.responseData[0].fileName ?? '',
      })

      if (response.statusText === 'Created') {
        router.push(frontendRoutes.collaborator.list)
      }
    } catch (error) {
      const errorMessage =
        error instanceof AxiosError
          ? error.response?.data?.error
          : errorMessages.DEFAULT_ERROR
      setServerError(errorMessage)
    }
  }

  const getAllLists = async () => {
    const listData = await axiosInstance.post('/api/list', {
      listTypes: ['appellation', 'title'],
    })

    const { appellation } = listData.data.data
    setAppellationOptions(appellation)
  }

  useEffect(() => {
    getAllLists()
  }, [])

  return (
    <Box component="form" onSubmit={handleSubmit(createCollaboratorsHandler)}>
      <Grid container justifyContent="space-between" mb={25}>
        <Grid item display="flex" alignItems="flex-end" gap={10}>
          <Typography variant="h1" mb={0}>
            {tScoped('Create Collaborators')}
          </Typography>
        </Grid>
        <Grid item>
          <CustomButton
            icon
            label
            labelText={tDashboardScoped('Back')}
            iconName="arrowLeft"
            onClick={() => router.back()}
          />
        </Grid>
      </Grid>

      <Typography variant="h2" mb={15}>
        {tScoped('Master Data')}
      </Typography>

      <Grid container columnSpacing={10}>
        <Grid item xs={3}>
          <RHFAutocompleteField
            label={tScoped('Appellation')}
            control={control}
            name="appellationId"
            options={appellationOptions?.map((item) => {
              return {
                id: item.listId,
                label: item.listValue,
              }
            })}
          />
        </Grid>
        <Grid item xs={3}>
          <InputField control={control} name="title" label={tScoped('Title')} />
        </Grid>

        <Grid item xs={6}>
          <InputLabel>{tScoped('Date of Birth')}</InputLabel>
          <CustomDatePicker
            name="dob"
            control={control}
            setValue={setValue}
            clearErrors={clearErrors}
            setError={setError}
            dateFormat="dd/MM/yyyy"
            minDate={null}
            maxDate={new Date()}
          />
        </Grid>

        <Grid item xs={6}>
          <InputField
            control={control}
            name="firstName"
            label={tScoped('First Name')}
            fullWidth
            rules={{
              required: {
                value: true,
                message: validationMessages.required,
              },
            }}
            error={!!errors.firstName}
            helperText={errors.firstName?.message}
          />
        </Grid>

        <Grid item xs={6}>
          <InputField
            control={control}
            name="lastName"
            label={tScoped('Last Name')}
            fullWidth
            rules={{
              required: {
                value: true,
                message: validationMessages.required,
              },
            }}
            error={!!errors.lastName}
            helperText={errors.lastName?.message}
          />
        </Grid>

        <Grid item xs={6}>
          <InputField
            control={control}
            name="phoneNumber"
            label={tScoped('Phone Number')}
            fullWidth
            rules={{
              pattern: {
                value: validators.phoneNumber,
                message: validationMessages.validPhone,
              },
            }}
            error={!!errors.phoneNumber}
            helperText={errors.phoneNumber?.message}
          />
        </Grid>

        <Grid item xs={6} mb={25}>
          <InputField
            control={control}
            name="email"
            label={tScoped('E-mail Address')}
            fullWidth
            rules={{
              required: {
                value: true,
                message: validationMessages.required,
              },
              pattern: {
                value: validators.email,
                message: validationMessages.validEmail,
              },
            }}
            error={!!errors.email}
            helperText={errors.email?.message}
          />
        </Grid>

        <Grid item xs={6} mb={25}>
          <Typography variant="h2" mb={15}>
            {tScoped('Documents')}
          </Typography>
          <AddAttachment
            labelText={tScoped('Upload Document')}
            currentFiles={currentFiles}
            fileUploading={fileUploading}
            setCurrentFiles={setCurrentFiles}
          />
        </Grid>
      </Grid>

      <Grid container justifyContent="center" gap={10}>
        <CustomButton
          label={true}
          labelText={tScoped('Discard')}
          icon={false}
          type="reset"
          sx={{ minWidth: '200px' }}
          onClick={() => {
            router.push(frontendRoutes.collaborator.list)
          }}
        />
        <CustomButton
          type="submit"
          label={true}
          labelText={tScoped('Save')}
          icon={false}
          variant="contained"
          sx={{ minWidth: '200px' }}
        />
      </Grid>

      {serverError !== '' ? (
        <Toast message={serverError} severity="error" />
      ) : null}
    </Box>
  )
}

export default CreateCollaborators
