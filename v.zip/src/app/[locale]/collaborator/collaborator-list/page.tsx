'use client'

import { AxiosError } from 'axios'
// import { debounce } from '@/utils/debounce'
import { UserContext } from '@/contexts/userContext'
import { frontendRoutes } from '@/utils/constants/frontend'
import { useContext, useEffect, useState } from 'react'
import { paginationLimit } from '@/utils/constants/common'
import { errorMessages } from '@/utils/errorMessages'
import { ICollaboratorList } from '@/interface/common'
import { useRouter } from 'next/navigation'
import {
  Grid,
  InputAdornment,
  Table,
  TableBody,
  TableContainer,
  TextField,
  Typography,
} from '@mui/material'

import Link from 'next/link'
import Toast from '@/components/Toast'
import Pagination from '@/components/Pagination'
import axiosInstance from '@/services/axiosInstance'
import CustomButton from '@/components/Buttons/CustomButton'
import CollaboratorTableRow from '@/components/TableRows/CollaboratorRow'
import IconSwitcher from '@/components/Icons'
import { useScopedI18n } from '../../../../../locales/client'
import getUserRoles from '@/utils/getUserRoles'
import { IModalData } from '@/interface/communication'
import NewMessage from '@/components/Modals/NewMessage'

const CollaboratorsList = () => {
  const tScoped = useScopedI18n('collaborators')
  const tDashboardScoped = useScopedI18n('dashboard')
  const { pagination, setPagination } = useContext(UserContext)
  const [page, setPage] = useState<number>(pagination.collaborator)
  const [totalRecords, setTotalRecords] = useState<number>(0)
  const [collaboratorList, setCollaboratorList] = useState<ICollaboratorList>(
    [],
  )

  const [collaboratorRecipients, setCollaboratorRecipients] = useState<
    number[] | []
  >([])

  const [serverError, setServerError] = useState<string>('')
  const [searchText, setSearchText] = useState<string | null>(null)

  const [modalData, setModalData] = useState<IModalData>({
    open: false,
    type: '',
  })

  const { user } = useContext(UserContext)

  const onPageChangeHandler = async (
    _: React.ChangeEvent<unknown>,
    value: number,
  ) => {
    setPagination((pre) => ({
      ...pre,
      collaborator: value,
    }))
    setPage(value)
  }

  useEffect(() => {
    getCollaboratorList()
  }, [page, searchText])

  const getCollaboratorList = async () => {
    try {
      const response = await axiosInstance.post(
        '/api/collaborator/collaborator-list',
        { page, search: searchText },
      )
      setCollaboratorList(response.data.collaboratorList)
      setTotalRecords(response.data.totalRecords)
    } catch (error) {
      const errorMessage =
        error instanceof AxiosError
          ? error.response?.data?.error
          : errorMessages.DEFAULT_ERROR

      setServerError(errorMessage)
    }
  }

  useEffect(() => {
    if (collaboratorList.length > 0) {
      const collaboratorRecipientsNumbered = collaboratorList.map(
        (collaborator) => collaborator.person.personId,
      )
      setCollaboratorRecipients(collaboratorRecipientsNumbered)
    }
  }, [collaboratorList])

  // const debouncedCollaboratorList = debounce(getCollaboratorList, 500)

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value
    setSearchText(value)
    // debouncedCollaboratorList(value)
    setPage(1)
  }

  const userRoles = getUserRoles(user)
  const anyChangePermissionFunction = (userRoles: string[]) => {
    return (
      userRoles.includes('subjectAdmin') ||
      userRoles.includes('subjectSupervision')
    )
  }
  const anyChangePermission: boolean = anyChangePermissionFunction(userRoles)

  const handleClose = () => {
    setModalData({ type: '', open: false })
  }

  const router = useRouter()

  return (
    <>
      <NewMessage
        open={modalData.type === 'message' && modalData.open}
        handleClose={handleClose}
        role="Employee"
        preDecidedRecipients={collaboratorRecipients}
      />
      <Grid container justifyContent="space-between" mb={25}>
        <Grid item display="flex" alignItems="flex-end" gap={10}>
          <Typography variant="h1" mb={0}>
            {tScoped('Collaborators Chart')}
          </Typography>
        </Grid>
        <Grid item>
          <CustomButton
            icon
            label
            labelText={tDashboardScoped('Back')}
            iconName="arrowLeft"
            onClick={() => router.back()}
          />
        </Grid>
      </Grid>

      <Grid container justifyContent="flex-end" gap={10} mb={5}>
        {anyChangePermission && (
          <Link href={frontendRoutes.collaborator.create}>
            <CustomButton
              label={true}
              labelText={tScoped('New Collaborator')}
              icon={true}
              iconName="plus"
            />
          </Link>
        )}
        <Grid item>
          <CustomButton
            icon
            label
            labelText={tScoped('New Message')}
            iconName="plus"
            onClick={() => {
              setModalData({
                open: true,
                type: 'message',
              })
            }}
          />
        </Grid>
        <TextField
          name="search"
          type="search"
          value={searchText ? searchText : ''}
          placeholder={tScoped('Search')}
          InputProps={{
            endAdornment: (
              <InputAdornment
                position="end"
                sx={{
                  cursor: 'pointer',
                  background: '#e40422',
                  height: '100%',
                  marginRight: '-14px',
                  maxHeight: '100%',
                  paddingInline: '10px',
                }}
              >
                <IconSwitcher icon={'search'} />
              </InputAdornment>
            ),
          }}
          onChange={handleSearch}
        />
      </Grid>

      <TableContainer>
        <Table sx={{ minWidth: '744px' }}>
          <TableBody>
            {collaboratorList.map((collaborator) => (
              <CollaboratorTableRow
                key={collaborator.collaboratorId}
                collaboratorId={collaborator.collaboratorId}
                person={collaborator.person}
                phasePreferenceId={collaborator.phasePreferenceId}
                pinNo={collaborator.pinNo}
                schoolTypeId={collaborator.schoolTypeId}
                collaboratorSchoolRole={collaborator.collaboratorSchoolRole}
                jobTitle={collaborator.jobTitle}
              />
            ))}
          </TableBody>
        </Table>

        {totalRecords > paginationLimit ? (
          <Pagination
            count={Math.ceil(totalRecords / paginationLimit)}
            page={page}
            onChange={onPageChangeHandler}
          />
        ) : null}
      </TableContainer>

      {serverError !== '' ? (
        <Toast message={serverError} severity="error" />
      ) : null}
    </>
  )
}

export default CollaboratorsList
