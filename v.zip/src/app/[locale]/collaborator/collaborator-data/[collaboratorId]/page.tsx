'use client'

import Toast from '@/components/Toast'
import InputField from '@/components/InputField'
import axiosInstance from '@/services/axiosInstance'
import CustomDatePicker from '@/components/DatePicker'
import Button from '@/components/Buttons/CustomButton'
import CustomRadioGroup from '@/components/RadioGroup'
import CustomButton from '@/components/Buttons/CustomButton'
import FEDERAL_STATES from '@/utils/constants/FederalStates'
import DeactivateAccount from '@/components/DeactivateAccount'
import AddAttachment from '@/components/Buttons/AddAttachment'
import DeleteAccount from '@/components/Modals/DeleteAccount'
import CustomCheckbox from '@/components/Buttons/CustomCheckbox'
import { AxiosError, AxiosResponse } from 'axios'
import { validators } from '@/validators'
import { RHFTextArea } from '@/components/TextArea'
import { UserContext } from '@/contexts/userContext'
import { errorMessages } from '@/utils/errorMessages'
import { useParams, useRouter } from 'next/navigation'
import { SubmitHandler, useForm } from 'react-hook-form'
import { successMessages } from '@/utils/successMessages'
import { validationMessages } from '@/validators/messages'
import { IList, OptionInterface } from '@/interface/common'
import { frontendRoutes } from '@/utils/constants/frontend'
import { RHFAutocompleteField } from '@/components/DropDown'
import { useScopedI18n } from '../../../../../../locales/client'
import { useContext, useEffect, useState } from 'react'
import {
  PIN_NO_CONSTRAINTS,
  phasesOptions,
} from '@/utils/constants/common'
import {
  Collaborator,
  Modules,
  Person,
  School,
  SubjectArea,
  Role,
  List,
} from '@prisma/client'
import {
  Box,
  FormHelperText,
  FormLabel,
  Grid,
  InputLabel,
  Typography,
} from '@mui/material'
import getUserRoles from '@/utils/getUserRoles'

export interface InterfacePhasePreference {
  kickOff: boolean
  firstStep: boolean
  setUp: boolean
  studies: boolean
}
interface InterfaceCollaboratorData
  extends Omit<Collaborator, 'attachment'>,
    Person {
  phasePreference: InterfacePhasePreference
  modules: number[]
  subjectArea: number[]
  school: number[]
  collaboratorSchoolRole: number[]
  attachment: {
    url: string
    fileName: string
  } | null
}

const CollaboratorData = () => {
  const tScoped = useScopedI18n('collaborators.collaboratorData')
  const tDashboardScoped = useScopedI18n('dashboard')
  const router = useRouter()
  const { user } = useContext(UserContext)
  const isEmployee = user?.role === Role.Employee
  const isCollaborator = user?.role === Role.Collaborator
  let { collaboratorId }: { collaboratorId: string } = useParams()

  const [collaboratorSchoolRole, setCollaboratorSchoolRole] = useState<IList>(
    [],
  )
  const [appellations, setAppellations] = useState<IList>([])
  const [berlinSchool, setBerlinSchool] = useState<School[]>([])
  const [schoolType, setSchoolType] = useState<IList>([])
  const [firstRecognisedSubject, setFirstRecognisedSubject] = useState<IList>(
    [],
  )
  const [secondRecognisedSubject, setSecondRecognisedSubject] = useState<IList>(
    [],
  )
  const [thirdRecognisedSubject, setThirdRecognisedSubject] = useState<IList>(
    [],
  )

  const [businessType, setBusinessType] = useState<IList>([])

  const [serverError, setServerError] = useState<string>('')
  const [collaboratorUpdated, setCollaboratorUpdated] = useState<boolean>(false)

  const [collaboratorData, setCollaboratorData] =
    useState<InterfaceCollaboratorData>()

  const [deactivateAccountModal, setDeactivateAccountModal] =
    useState<boolean>(false)

  const [isDeactivated, setIsDeactivated] = useState<boolean>(false)

  const [deleteModal, setDeleteModal] = useState<boolean>(false)
  const [collaboratorDeleted, setCollaboratorDeleted] = useState<boolean>(false)
  const [fileUploading, setFileUploading] = useState<boolean>(false)
  const [currentFiles, setCurrentFiles] = useState<FileList | null>(null)
  const [uploadedAttachments, setUploadedAttachments] = useState<{
    url: string
    fileName: string
  } | null>(null)
  const [schoolInBerlin, setSchoolInBerlin] = useState<boolean>(false)

  useEffect(() => {
    if (currentFiles) {
      setUploadedAttachments(null)
    }
  }, [currentFiles])

  const getSchoolList = async () => {
    const schools = await axiosInstance.post('/api/school', { all: true })
    setBerlinSchool(schools.data.schoolList)
  }
  const getAllLists = async () => {
    const listsFromApi = await axiosInstance.post('/api/list', {
      listTypes: [
        'appellation',
        'role',
        'schoolType',
        'firstRecognisedSubject',
        'secondRecognisedSubject',
        'thirdRecognisedSubject',
        'collaboratorSchoolRole',
        'businessType',
      ],
    })
    setAppellations(listsFromApi.data.data.appellation)
    setCollaboratorSchoolRole(listsFromApi.data.data.collaboratorSchoolRole)
    setSchoolType(
      listsFromApi.data.data.schoolType.filter(
        (item: List) =>
          !['Tempelhof-Schöneberg', 'Lichtenberg'].includes(item.listValue),
      ),
    )
    setFirstRecognisedSubject(listsFromApi.data.data.firstRecognisedSubject)
    setSecondRecognisedSubject(listsFromApi.data.data.secondRecognisedSubject)
    setThirdRecognisedSubject(listsFromApi.data.data.thirdRecognisedSubject)
    setBusinessType(listsFromApi.data.data.businessType)
  }

  const getCollaboratorData = async () => {
    const response = await axiosInstance.get(
      `/api/collaborator/${collaboratorId}`,
    )
    const collaborator = response.data.collaborator
    setIsDeactivated(!collaborator.isActive)
    setCollaboratorData({
      ...collaborator,
      dob: collaborator.dob ? new Date(collaborator.dob) : null,
      lastActiveTeachingYear:
        collaborator.lastActiveTeachingYear &&
        new Date(collaborator.lastActiveTeachingYear),
      retiredSince:
        collaborator.retiredSince && new Date(collaborator.retiredSince),
      phasePreference: phasesOptions.find(
        (phase) => phase.id === collaborator.phasePreferenceId,
      ),
      modules: collaborator.modules.map(
        (module: { moduleId: number }) => module.moduleId,
      ),
      subjectArea: collaborator.subjectArea.map(
        (subjectArea: { subjectAreaId: number }) => subjectArea.subjectAreaId,
      ),
      workedAsATeacher:
        collaborator.workedAsATeacher === true ? 'true' : 'false',
      iban: collaborator.iban ? formatBankAccountNumber(collaborator.iban) : '',
      school: collaborator.school.map(
        (school: { schoolId: number }) => school.schoolId,
      ),
      collaboratorSchoolRole: collaborator.collaboratorSchoolRole.map(
        (role: { roleId: number }) => role.roleId,
      ),
      businessTypeId: collaborator.businessTypeId,
    })

    setUploadedAttachments(collaborator?.attachment)

    if (collaborator.phasePreferenceId < 16) {
      onCheckBoxChangeHandler(
        undefined,
        undefined,
        phasesOptions.find(
          (phase) => phase.id === collaborator.phasePreferenceId,
        ),
      )
      setShowModules(true)
    }

    if (collaborator.subjectArea.length > 0) {
      setShowSubjectArea(true)
      onModuleSelectHandler()
    }
  }

  useEffect(() => {
    if (user?.role === Role.Collaborator) {
      collaboratorId = `${user.collaboratorId}`
      router.replace(`/collaborator/collaborator-data/${collaboratorId}`)
    }
    const fetchData = async () => {
      try {
        await Promise.all([
          getAllLists(),
          getCollaboratorData(),
          getSchoolList(),
        ])
      } catch (error) {
        const errorMessage =
          error instanceof AxiosError
            ? error.response?.data?.error
            : errorMessages.DEFAULT_ERROR
        setServerError(errorMessage)
      }
    }
    fetchData()
  }, [])

  const {
    handleSubmit,
    formState: { errors },
    control,
    clearErrors,
    setValue,
    setError,
    watch,
  } = useForm<InterfaceCollaboratorData>({
    mode: 'all',
    values: collaboratorData,
    shouldFocusError: true,
  })

  const workedAsATeacher = watch('workedAsATeacher')

  const lastActiveTeachingYear = watch('lastActiveTeachingYear')
  const retiredSince = watch('retiredSince')

  const stillTeaching = watch('stillTeaching')

  const federalStateId = watch('federalStateId')

  useEffect(() => {
    const fed = FEDERAL_STATES.find((state) => state.id === federalStateId)
    if (fed && fed.name === 'Berlin') {
      setSchoolInBerlin(true)
    } else {
      setSchoolInBerlin(false)
    }
  }, [federalStateId])

  const updateCollaboratorHandler: SubmitHandler<
    InterfaceCollaboratorData
  > = async (payload) => {
    if (
      collaboratorData?.invited &&
      !Object.values(payload.phasePreference).some((value) => value === true)
    ) {
      setError('phasePreference', { message: 'Select at lease one preference' })
      return
    }

    try {
      setFileUploading(true)
      let responseFromFileServer: AxiosResponse | null = null

      const formData = new FormData()
      if (currentFiles) {
        formData.append('file', currentFiles[0])
        responseFromFileServer = await axiosInstance.post(
          '/api/upload',
          formData,
        )

        if (responseFromFileServer && responseFromFileServer.status === 201) {
          setFileUploading(false)
        } else {
          throw new Error(errorMessages.FAILED_TO_UPLOAD_ATTACHMENT)
        }
      }

      const response = await axiosInstance.post(
        `/api/collaborator/${collaboratorId}`,
        {
          ...payload,
          workedAsATeacher:
            typeof payload.workedAsATeacher === 'string'
              ? payload.workedAsATeacher === 'true'
              : payload.workedAsATeacher,
          ...(collaboratorData?.invited
            ? {
                phasePreferenceId: phasesOptions.find(
                  (phase) =>
                    phase.firstStep === payload.phasePreference.firstStep &&
                    phase.kickOff === payload.phasePreference.kickOff &&
                    phase.setUp === payload.phasePreference.setUp &&
                    phase.studies === payload.phasePreference.studies,
                )?.id,
              }
            : {}),
          iban: unFormatBankAccountNumber(`${payload.iban}`),
          attachment:
            currentFiles && !uploadedAttachments
              ? responseFromFileServer?.data.responseData[0].fileName
              : !currentFiles && !uploadedAttachments
                ? ''
                : collaboratorData?.attachment?.fileName,
          businessTypeId: payload.businessTypeId,
        },
      )
      if (response.status === 200) {
        setCollaboratorUpdated(true)
        router.push(frontendRoutes.dashboard)
      }
    } catch (error) {
      const errorMessage =
        error instanceof AxiosError
          ? error.response?.data?.error
          : errorMessages.DEFAULT_ERROR
      setServerError(errorMessage)
    }
  }

  const [showModules, setShowModules] = useState<boolean>(false)
  const [moduleList, setModuleList] = useState<Modules[]>([])
  const [showSubjectArea, setShowSubjectArea] = useState<boolean>(false)
  const [subjectAreaList, setSubjectAreaList] = useState<SubjectArea[]>([])
  const [employeeInformed, setEmployeeInformed] = useState<boolean>(false)

  const onCheckBoxChangeHandler = async (
    checked?: boolean,
    name?: string,
    phasePreference?: InterfacePhasePreference,
  ) => {
    const selectedPhases = watch('phasePreference')

    let latestPhase = selectedPhases
    if (phasePreference) {
      latestPhase = phasePreference
    }

    if (name) {
      const fieldName = name.split('.')[1]
      latestPhase = { ...selectedPhases, [fieldName]: checked }
    }

    if (checked) {
      clearErrors('phasePreference')
    }

    if (checked !== undefined && name !== undefined) {
      setValue('subjectArea', [])
      setValue('modules', [])
      setShowSubjectArea(false)
    }

    if (Object.values(latestPhase).some((value) => value === true)) {
      setShowModules(true)
      try {
        const phases = []

        for (const [key, value] of Object.entries(latestPhase)) {
          if (value === true) {
            phases.push(key)
          }
        }
        const res = await axiosInstance.post('/api/list/moduleList/', {
          phases,
        })
        setModuleList(res.data.data)
      } catch (error) {
        const errorMessage =
          error instanceof AxiosError
            ? error.response?.data?.error
            : errorMessages.DEFAULT_ERROR
        setServerError(errorMessage)
      }
    } else {
      setShowModules(false)
    }
  }

  const onModuleSelectHandler = async (values?: OptionInterface[]) => {
    if (values?.length === 0) {
      setShowSubjectArea(false)
      return
    }
    setShowSubjectArea(true)

    try {
      const res = await axiosInstance.post('/api/list/subjectAreaList/', {
        moduleIds: values,
      })
      setSubjectAreaList(res.data.data)
    } catch (error) {
      const errorMessage =
        error instanceof AxiosError
          ? error.response?.data?.error
          : errorMessages.DEFAULT_ERROR
      setServerError(errorMessage)
    }
  }

  const userRoles = getUserRoles(user)
  const canViewBankDetails = (userRoles: string[]) => {
    return userRoles.includes('householdAdmin')
  }
  const bankDetailsPermission: boolean = canViewBankDetails(userRoles)

  const canDelete = (userRoles: string[]) => {
    return userRoles.includes('subjectAdmin')
  }
  const deletePermission: boolean = canDelete(userRoles)

  const anyChangePermissionFunction = (userRoles: string[]) => {
    return (
      userRoles.includes('subjectAdmin') ||
      userRoles.includes('subjectSupervision')
    )
  }
  const anyChangePermission: boolean = anyChangePermissionFunction(userRoles)

  const handleDeleteAccountModalOpen = async () => {
    setDeleteModal(true)
  }

  const handleDeleteAccountModalClose = async () => {
    setDeleteModal(false)
  }

  const deleteAccount = async () => {
    try {
      const response = await axiosInstance.post(
        `/api/collaborator/delete-collaborator/${collaboratorId}`,
        {
          collaboratorId: +collaboratorId,
        },
      )

      if (response.status === 200) {
        setCollaboratorDeleted(true)
        setTimeout(() => {
          router.replace('/collaborator/collaborator-list')
        }, 1000)
      }
    } catch (error) {
      const errorMessage =
        error instanceof AxiosError
          ? error.response?.data?.error
          : errorMessages.DEFAULT_ERROR
      setServerError(errorMessage)
    } finally {
      setDeactivateAccountModal(false)
    }
  }

  const onDeactivateAccount = async () => {
    setDeactivateAccountModal(true)
  }

  const deactivateAccount = async () => {
    try {
      const response = await axiosInstance.put(
        `/api/collaborator/deactivate-account`,
        {
          collaboratorId: +collaboratorId,
          isActive: isDeactivated,
        },
      )
      if (response.status === 201) {
        setCollaboratorUpdated(true)
        setIsDeactivated(!isDeactivated)
      }
    } catch (error) {
      const errorMessage =
        error instanceof AxiosError
          ? error.response?.data?.error
          : errorMessages.DEFAULT_ERROR
      setServerError(errorMessage)
    } finally {
      setDeactivateAccountModal(false)
    }
  }

  const handleDeactivateAccountClose = () => {
    setDeactivateAccountModal(false)
  }

  function formatBankAccountNumber(accountNumber: string) {
    const strippedNumber = accountNumber.replace(/\s/g, '')
    const spacePattern = /(\w{4})(?=\w)/g
    const formattedNumber = strippedNumber.replace(spacePattern, '$1 ')
    return formattedNumber
  }

  function unFormatBankAccountNumber(formattedAccountNumber: string) {
    return formattedAccountNumber.replace(/\s/g, '')
  }

  const iban = watch('iban')

  useEffect(() => {
    if (iban) {
      setValue('iban', formatBankAccountNumber(iban))
    }
  }, [iban])

  useEffect(() => {
    setTimeout(() => {
      if (collaboratorUpdated) {
        setCollaboratorUpdated(false)
      }
    }, 1000)
  }, [collaboratorUpdated])

  return (
    <>
      <DeactivateAccount
        open={deactivateAccountModal}
        onClose={handleDeactivateAccountClose}
        onDeactivate={deactivateAccount}
        confirmLabel={isDeactivated ? 'Reactivate' : 'Deactivate'}
        isDeactivated={isDeactivated}
      />
      <DeleteAccount
        open={deleteModal}
        onClose={handleDeleteAccountModalClose}
        onDelete={deleteAccount}
      />

      <Box component="form" onSubmit={handleSubmit(updateCollaboratorHandler)}>
        <Grid container justifyContent="space-between" mb={25}>
          <Grid item display="flex" alignItems="flex-end" gap={10}>
            <Typography variant="h1" mb={0}>
              {user?.role === Role.Employee
                ? tScoped('Data')
                : tScoped('My Data')}
            </Typography>
          </Grid>
          <Grid item>
            <CustomButton
              icon
              label
              labelText={tDashboardScoped('Back')}
              iconName="arrowLeft"
              onClick={() => router.back()}
            />
          </Grid>
        </Grid>

        {user?.role === Role.Employee ? (
          <Grid container columnSpacing={10} mb={25}>
            <Grid item xs={3}>
              <InputField
                control={control}
                name="pinNo"
                label={tScoped('PIN Number')}
                fullWidth
                rules={{
                  required: {
                    value: true,
                    message: validationMessages.required,
                  },
                  max: {
                    value: PIN_NO_CONSTRAINTS.max,
                    message: errorMessages.INVALID_PIN_NO,
                  },
                  min: {
                    value: PIN_NO_CONSTRAINTS.min,
                    message: errorMessages.INVALID_PIN_NO,
                  },
                }}
                error={!!errors.pinNo}
                helperText={errors.pinNo?.message}
                defaultValue={0}
              />
            </Grid>
          </Grid>
        ) : (
          <>
            <Typography>{tScoped('PIN Number')}</Typography>
            <Typography variant="h3" mb={25}>
              {collaboratorData?.pinNo}
            </Typography>
          </>
        )}

        <Box sx={{ display: 'flex' }}>
          <Typography variant="h2" mb={15}>
            {tScoped('Master Data')}
          </Typography>

          <div style={{ marginLeft: 'auto' }}>
            {user?.role === Role.Employee ? (
              <>
                {deletePermission && anyChangePermission && (
                  <CustomButton
                    label
                    labelText={tScoped('Delete')}
                    sx={{ width: '200px', marginLeft: 'auto' }}
                    variant="contained"
                    onClick={handleDeleteAccountModalOpen}
                  />
                )}

                {anyChangePermission && (
                  <Button
                    label
                    labelText={
                      user?.role === Role.Employee
                        ? isDeactivated
                          ? tScoped('Reactivate Account')
                          : tScoped('Deactivate Account')
                        : isDeactivated
                          ? tScoped('Deactivated')
                          : tScoped('Deactivate Account')
                    }
                    sx={{
                      ml: '20px',
                    }}
                    onClick={onDeactivateAccount}
                  ></Button>
                )}
              </>
            ) : null}

            <Button
              sx={{
                ml: '20px',
              }}
              icon
              label
              labelText={tScoped('History')}
              onClick={() =>
                router.push(`/history/${collaboratorData?.personId}`)
              }
            />
          </div>
        </Box>

        <Box mb={25}>
          <Grid container columnSpacing={10}>
            <Grid item xs={3}>
              <RHFAutocompleteField
                control={control}
                options={appellations?.map((item) => {
                  return {
                    id: item.listId,
                    label: item.listValue,
                  }
                })}
                name="appellationId"
                label={tScoped('Appellation')}
              />
            </Grid>
            <Grid item xs={3}>
              <InputField
                control={control}
                name="title"
                label={tScoped('Title')}
                defaultValue={''}
              />
            </Grid>

            <Grid item xs={6} alignItems="center">
              <InputLabel>{tScoped('Date of Birth')}</InputLabel>
              <CustomDatePicker
                name="dob"
                control={control}
                setValue={setValue}
                clearErrors={clearErrors}
                setError={setError}
                dateFormat="dd/MM/yyyy"
                maxDate={new Date()}
                minDate={null}
                required
              />
            </Grid>

            <Grid item xs={6}>
              <InputField
                control={control}
                name="firstName"
                label={tScoped('First Name')}
                fullWidth
                defaultValue=""
                rules={{
                  required: {
                    value: true,
                    message: validationMessages.required,
                  },
                }}
                error={!!errors.firstName}
                helperText={errors.firstName?.message}
                required
              />
            </Grid>

            <Grid item xs={6}>
              <InputField
                control={control}
                name="lastName"
                label={tScoped('Last Name')}
                defaultValue=""
                fullWidth
                rules={{
                  required: {
                    value: true,
                    message: validationMessages.required,
                  },
                }}
                error={!!errors.lastName}
                helperText={errors.lastName?.message}
                required
              />
            </Grid>

            <Grid item xs={6}>
              <InputField
                control={control}
                name="phoneNumber"
                label={tScoped('Phone Number')}
                fullWidth
                rules={{
                  pattern: {
                    value: validators.phoneNumber,
                    message: validationMessages.validPhone,
                  },
                }}
                error={!!errors.phoneNumber}
                helperText={errors.phoneNumber?.message}
                defaultValue=""
                required
              />
            </Grid>

            <Grid item xs={6}>
              <InputField
                control={control}
                name="email"
                label={tScoped('E-mail Address')}
                fullWidth
                rules={{
                  required: {
                    value: true,
                    message: validationMessages.required,
                  },
                  pattern: {
                    value: validators.email,
                    message: validationMessages.validEmail,
                  },
                }}
                error={!!errors.email}
                helperText={errors.email?.message}
                defaultValue=""
              />
            </Grid>

            <Grid item xs={6}>
              <InputField
                name="streetAndHouseNo"
                label={tScoped('Street and House no')}
                fullWidth
                rules={{
                  required: {
                    value: true,
                    message: validationMessages.required,
                  }
                }}
                control={control}
                error={!!errors.streetAndHouseNo}
                helperText={errors.streetAndHouseNo?.message}
              />
            </Grid>
            <Grid item xs={6}>
              <InputField
                label={tScoped('Postal Code')}
                fullWidth
                rules={{
                  required: {
                    value: true,
                    message: validationMessages.required,
                  }
                }}
                control={control}
                name="postalCode"
                error={!!errors.postalCode}
                helperText={errors.postalCode?.message}
              />
            </Grid>
            <Grid item xs={6}>
              <InputField
                label={tScoped('City')}
                fullWidth
                rules={{
                  required: {
                    value: true,
                    message: validationMessages.required,
                  }
                }}
                control={control}
                name="city"
                error={!!errors.city}
                helperText={errors.city?.message}
              />
            </Grid>


          </Grid>
        </Box>

        <Typography variant="h2" mb={15}>
          {tScoped('Professional Career and Qualification')}
        </Typography>

        <Box mb={25}>
          <Grid container columnSpacing={10}>
            <Grid item xs={6}>
              <FormLabel sx={{ marginTop: '5px', display: 'block' }}>
                {tScoped('Retired/ pensioned since?')}
              </FormLabel>
            </Grid>

            <Grid item xs={3}>
              <CustomDatePicker
                name="retiredSince"
                label=""
                control={control}
                setValue={setValue}
                clearErrors={clearErrors}
                setError={setError}
                minDate={null}
                maxDate={new Date()}
                dateFormat="MM/yyyy"
                showMonthYearPicker
                onChange={() => setValue('retired', false)}
              />
            </Grid>
            <Grid item xs={3}>
              <CustomCheckbox
                control={control}
                name="retired"
                style={{ margin: 0 }}
                label={tScoped('Not Retired')}
                required={!retiredSince}
                defaultValue={
                  collaboratorData?.retired === false ? false : true
                }
                onChange={(checked) =>
                  checked && setValue('retiredSince', null)
                }
              />
            </Grid>
          </Grid>
          <CustomRadioGroup
            name="workedAsATeacher"
            row
            required
            label={tScoped('Have you worked as a teacher before?')}
            control={control}
            direction="horizontal"
            options={[
              { value: 'true', label: tScoped('Yes') },
              { value: 'false', label: tScoped('No') },
            ]}
          />

          {String(workedAsATeacher) === 'true' ? (
            <>
              <Typography variant="h3" mb={15}>
                {tScoped('School Service Details')}
              </Typography>
              <RHFAutocompleteField
                control={control}
                options={collaboratorSchoolRole?.map((item) => {
                  return {
                    id: item.listId,
                    label: item.listValue,
                  }
                })}
                name="collaboratorSchoolRole"
                required
                label={tScoped('What role did you serve in?')}
                direction="horizontal"
                multiple
              />

              <RHFAutocompleteField
                control={control}
                options={FEDERAL_STATES?.map((item) => {
                  return {
                    id: item.id,
                    label: item.name,
                  }
                })}
                name="federalStateId"
                required
                label={tScoped('Which Federal State?')}
                direction="horizontal"
              />

              <RHFAutocompleteField
                control={control}
                options={berlinSchool?.map((item) => {
                  return {
                    id: item.schoolId,
                    label: item.schoolName,
                  }
                })}
                name="school"
                required={schoolInBerlin}
                label={tScoped('If in Berlin - in which schools?')}
                direction="horizontal"
                multiple
              />

              <RHFAutocompleteField
                control={control}
                options={schoolType?.map((item) => {
                  return {
                    id: item.listId,
                    label: item.listValue,
                  }
                })}
                name="schoolTypeId"
                required
                label={tScoped('In what type of school did you work?')}
                direction="horizontal"
              />

              <RHFAutocompleteField
                control={control}
                options={firstRecognisedSubject?.map((item) => {
                  return {
                    id: item.listId,
                    label: item.listValue,
                  }
                })}
                name="firstRecognisedSubjectId"
                required
                label={`1. ${tScoped('Recognized Subject')}`}
                direction="horizontal"
              />

              <RHFAutocompleteField
                control={control}
                options={secondRecognisedSubject?.map((item) => {
                  return {
                    id: item.listId,
                    label: item.listValue,
                  }
                })}
                name="secondRecognisedSubjectId"
                label={`2. ${tScoped('Recognized Subject')}`}
                direction="horizontal"
              />

              <RHFAutocompleteField
                control={control}
                options={thirdRecognisedSubject?.map((item) => {
                  return {
                    id: item.listId,
                    label: item.listValue,
                  }
                })}
                name="thirdRecognisedSubjectId"
                label={`3. ${tScoped('Recognized Subject')}`}
                direction="horizontal"
              />

              <Grid container columnSpacing={10}>
                <Grid item xs={6}>
                  <FormLabel sx={{ marginTop: '5px', display: 'block' }}>
                    {tScoped(
                      'Since when have you been out of active teaching?',
                    )}
                  </FormLabel>
                </Grid>

                <Grid item xs={3}>
                  <CustomDatePicker
                    name="lastActiveTeachingYear"
                    label=""
                    control={control}
                    setValue={setValue}
                    clearErrors={clearErrors}
                    setError={setError}
                    required={!stillTeaching}
                    minDate={null}
                    maxDate={new Date()}
                    dateFormat="MM/yyyy"
                    showMonthYearPicker
                    onChange={() => setValue('stillTeaching', false)}
                  />
                </Grid>
                <Grid item xs={3}>
                  <CustomCheckbox
                    control={control}
                    name="stillTeaching"
                    style={{ margin: 0 }}
                    label={tScoped('Still active')}
                    required={!lastActiveTeachingYear}
                    defaultValue={true}
                    onChange={(checked) =>
                      checked && setValue('lastActiveTeachingYear', null)
                    }
                  />
                </Grid>
              </Grid>
            </>
          ) : (
            <></>
          )}

          <InputField
            control={control}
            name="otherQualification"
            label={tScoped('Other Qualifications')}
            defaultValue=""
            direction="horizontal"
          />

          <Typography variant="h3" mb={15} mt={5}>
            {tScoped('Details of other employment activity')}
          </Typography>

          <InputField
            control={control}
            name="jobTitle"
            label={tScoped('Job Title')}
            defaultValue=""
            direction="horizontal"
          />

          <InputField
            control={control}
            name="firstActivityField"
            label={`1. ${tScoped('Activity Field')}`}
            direction="horizontal"
            defaultValue=""
          />

          <InputField
            control={control}
            name="secondActivityField"
            label={`2. ${tScoped('Activity Field')}`}
            direction="horizontal"
            defaultValue=""
          />

          <InputField
            control={control}
            name="thirdActivityField"
            label={`3. ${tScoped('Activity Field')}`}
            direction="horizontal"
            defaultValue=""
          />

          <RHFTextArea
            control={control}
            name="contactPointWithSchool"
            label={tScoped('My contact points with school')}
            defaultValue=""
            direction="horizontal"
            sx={{ marginBottom: '20px' }}
          />
        </Box>
        {collaboratorData?.invited && (
          <>
            <Typography variant="h2" mb={15}>
              {tScoped('Preferences')}
            </Typography>

            <Box mb={25}>
              <Grid container spacing={10}>
                <Grid item xs={6} container alignItems="center">
                  <Grid container>
                    <Grid item xs={12}>
                      <InputLabel>{tScoped('Phases')}</InputLabel>
                    </Grid>
                    <Grid item xs={3}>
                      <CustomCheckbox
                        label="Kick-Off"
                        control={control}
                        name="phasePreference.kickOff"
                        onChange={onCheckBoxChangeHandler}
                        defaultValue={false}
                      />
                    </Grid>
                    <Grid item xs={3}>
                      <CustomCheckbox
                        label="First-Steps"
                        control={control}
                        name="phasePreference.firstStep"
                        onChange={onCheckBoxChangeHandler}
                        defaultValue={false}
                      />
                    </Grid>
                    <Grid item xs={3}>
                      <CustomCheckbox
                        label="Set-Up"
                        control={control}
                        name="phasePreference.setUp"
                        onChange={onCheckBoxChangeHandler}
                        defaultValue={false}
                      />
                    </Grid>
                    <Grid item xs={3}>
                      <CustomCheckbox
                        label="Studies"
                        control={control}
                        name="phasePreference.studies"
                        onChange={onCheckBoxChangeHandler}
                        defaultValue={false}
                      />
                    </Grid>
                  </Grid>
                  {errors.phasePreference ? (
                    <FormHelperText error>
                      {errors?.phasePreference?.message}
                    </FormHelperText>
                  ) : null}
                </Grid>

                {showModules ? (
                  <Grid item xs={6}>
                    <RHFAutocompleteField
                      control={control}
                      options={moduleList?.map((item) => {
                        return {
                          id: item.moduleId,
                          label: item.moduleValue,
                        }
                      })}
                      name="modules"
                      required
                      label={tScoped('Modules')}
                      multiple
                      onSelect={onModuleSelectHandler}
                    />
                  </Grid>
                ) : null}

                {showModules && showSubjectArea ? (
                  <Grid item xs={6}>
                    <RHFAutocompleteField
                      control={control}
                      options={subjectAreaList?.map((item) => {
                        return {
                          id: item.subjectAreaId,
                          label: item.subjectValue,
                        }
                      })}
                      name="subjectArea"
                      required
                      label={tScoped('Subject Area')}
                      multiple
                    />
                  </Grid>
                ) : null}
              </Grid>
            </Box>

            <>
              <Typography variant="h2" mb={15}>
                {tScoped('Others')}
              </Typography>

              <Box mb={25}>
                <Grid container spacing={10} mb={2}>
                  <Grid item xs={3}>
                    <CustomCheckbox
                      control={control}
                      label={tScoped('Competence Team KickOff')}
                      name="competenceTeamKickOff"
                      defaultValue={false}
                    />
                  </Grid>

                  <Grid item xs={3}>
                    <CustomCheckbox
                      control={control}
                      label={tScoped('Competence Team FirstSteps')}
                      name="competenceTeamFirstSteps"
                      defaultValue={false}
                    />
                  </Grid>
                </Grid>

                <Grid container spacing={10}>
                  {isEmployee && (
                    <>
                      <Grid item xs={3}>
                        <CustomCheckbox
                          control={control}
                          label={tScoped('Police Conduct Certificate')}
                          name="policeConductCertificate"
                          defaultValue={false}
                        />
                      </Grid>
                    </>
                  )}
                  {isEmployee && (
                    <>
                      {' '}
                      <Grid item xs={3}>
                        <CustomCheckbox
                          control={control}
                          label={tScoped('Vaccinated Measles')}
                          name="vaccinatedMeasles"
                          defaultValue={false}
                        />
                      </Grid>
                    </>
                  )}
                </Grid>

                <Grid container spacing={10}>
                  {isEmployee && (
                    <>
                      <Grid item xs={3}>
                        <CustomCheckbox
                          control={control}
                          label={tScoped('First Strike')}
                          name="firstStrike"
                          defaultValue={false}
                        />
                      </Grid>

                      <Grid item xs={3}>
                        <CustomCheckbox
                          control={control}
                          label={tScoped('Second Strike')}
                          name="secondStrike"
                          defaultValue={false}
                        />
                      </Grid>

                      <Grid item xs={3}>
                        <CustomCheckbox
                          control={control}
                          label={tScoped('Third Strike')}
                          name="thirdStrike"
                          defaultValue={false}
                        />
                      </Grid>

                      <Grid item xs={12}>
                        <RHFTextArea
                          control={control}
                          label={tScoped('Comments')}
                          name="comment"
                        />
                      </Grid>
                    </>
                  )}
                </Grid>
              </Box>
            </>

            <Typography variant="h2" mb={15}>
              {tScoped('Business Data')}
            </Typography>

            <Box mb={25}>
              <Grid container columnSpacing={10}>
                <Grid item xs={6}>
                  <InputField
                    control={control}
                    name="companyName"
                    label={tScoped('Company Name')}
                    fullWidth
                    defaultValue=""
                    rules={{
                      required: {
                        value: true,
                        message: validationMessages.required,
                      },
                    }}
                    error={!!errors.companyName}
                    helperText={errors.companyName?.message}
                  />
                </Grid>

                {bankDetailsPermission ? (
                  <Grid item xs={6}>
                    <InputField
                      control={control}
                      name="accountHolder"
                      label={tScoped('Account Holder')}
                      fullWidth
                      defaultValue=""
                      rules={{
                        required: {
                          value: true,
                          message: validationMessages.required,
                        },
                      }}
                      error={!!errors.accountHolder}
                      helperText={errors.accountHolder?.message}
                    />
                  </Grid>
                ) : null}

                {bankDetailsPermission ? (
                  <Grid item xs={6}>
                    <InputField
                      control={control}
                      name="iban"
                      label="IBAN"
                      fullWidth
                      defaultValue=""
                      rules={{
                        required: {
                          value: true,
                          message: validationMessages.required,
                        },
                        pattern: {
                          value: validators.iban,
                          message: validationMessages.iban,
                        },
                      }}
                      error={!!errors.iban}
                      helperText={errors.iban?.message}
                    />
                  </Grid>
                ) : null}

                {bankDetailsPermission ? (
                  <Grid item xs={6}>
                    <InputField
                      control={control}
                      name="bic"
                      label="BIC"
                      defaultValue=""
                      fullWidth
                      rules={{
                        required: {
                          value: true,
                          message: validationMessages.required,
                        },
                      }}
                      error={!!errors.bic}
                      helperText={errors.bic?.message}
                    />
                  </Grid>
                ) : null}

                <Grid item xs={6}>
                  <InputField
                    control={control}
                    name="taxId"
                    label={tScoped('Tax ID')}
                    defaultValue=""
                    fullWidth
                  />
                </Grid>

                <Grid item xs={6}>
                  <InputField
                    control={control}
                    name="assignedTaxOffice"
                    label={tScoped('Assigned Tax Office')}
                    defaultValue=""
                    fullWidth
                  />
                </Grid>

                <Grid item xs={6}>
                  <RHFAutocompleteField
                    control={control}
                    options={businessType?.map((item) => {
                      return {
                        id: item.listId,
                        label: item.listValue,
                      }
                    })}
                    name="businessTypeId"
                    required
                    label={tScoped('Business Type')}
                  />
                </Grid>

                <Grid
                  item
                  xs={6}
                  sx={{ display: 'flex', alignItems: 'center' }}
                >
                  <CustomCheckbox
                    control={control}
                    name="vat"
                    label="Umsatzsteuer (USt.)"
                    defaultValue={false}
                  />
                </Grid>
              </Grid>

              {!user?.householdAdmin && !user?.departmentLead && (
                <AddAttachment
                  sx={{ marginTop: '24px' }}
                  labelText={tScoped('Upload Document')}
                  currentFiles={currentFiles}
                  fileUploading={fileUploading}
                  setCurrentFiles={setCurrentFiles}
                  uploadedAttachments={
                    uploadedAttachments
                      ? [
                          uploadedAttachments as {
                            url: string
                            fileName: string
                          },
                        ]
                      : []
                  }
                  setUploadedAttachments={setUploadedAttachments}
                />
              )}
            </Box>
          </>
        )}

        {isCollaborator && (
          <Box>
            <Grid container spacing={10} justifyContent="center" mb={25}>
              <Grid item>
                <CustomButton
                  label
                  labelText={tScoped('Discard')}
                  sx={{ minWidth: '200px' }}
                  onClick={() => {
                    router.push(frontendRoutes.collaborator.list)
                  }}
                  // disabled={!anyChangePermission} #TBD
                />
              </Grid>

              <Grid item>
                <CustomButton
                  type="submit"
                  label
                  labelText={tScoped('Save')}
                  sx={{ minWidth: '200px' }}
                  variant="contained"
                  // disabled={!anyChangePermission} #TBD
                />
              </Grid>
            </Grid>
          </Box>
        )}
      </Box>

      {employeeInformed ? (
        <Toast
          message={successMessages.collaboratorMarkedInvalidData}
          severity="success"
        />
      ) : null}

      {serverError !== '' ? (
        <Toast message={serverError} severity="error" />
      ) : null}

      {collaboratorUpdated ? (
        <Toast
          message={successMessages.collaboratorUpdated}
          severity="success"
        />
      ) : null}
      {collaboratorDeleted ? (
        <Toast
          message={successMessages.collaboratorDeletedSuccess}
          severity="success"
        />
      ) : null}
    </>
  )
}

export default CollaboratorData
