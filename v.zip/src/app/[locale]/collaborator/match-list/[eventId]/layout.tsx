import { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'TTMP | Match List of Participants',
  description: 'Match List of Participants',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return children
}
