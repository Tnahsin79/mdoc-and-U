'use client'

import { Box, Grid, LinearProgress, Typography } from '@mui/material'
import React, { useEffect, useState } from 'react'
import { useForm } from 'react-hook-form'
import { useParams, useRouter } from 'next/navigation'
import { AxiosError, AxiosResponse } from 'axios'

import CustomCheckbox from '@/components/Buttons/CustomCheckbox'
import Button from '@/components/Buttons/CustomButton'
import CustomButton from '@/components/Buttons/CustomButton'
import axiosInstance from '@/services/axiosInstance'
import { errorMessages } from '@/utils/errorMessages'
import Toast from '@/components/Toast'
import AddCandidates from '@/components/AddCandidates'
import { useScopedI18n } from '../../../../../../locales/client'
import AddAttachment from '@/components/Buttons/AddAttachment'

interface IToastData {
  type: 'success' | 'info' | 'warning' | 'error' | undefined
  message: string
}
interface ICandidate {
  personId: number
  firstName: string
  lastName: string | null
  email: string
  present?: boolean
}

const MatchList = () => {
  const tDashboardScoped = useScopedI18n('dashboard')
  const router = useRouter()
  const { eventId }: { eventId: string } = useParams()
  const [loading, setLoading] = useState<boolean>(false)
  const [candidateLoading, setCandidateLoading] = useState<boolean>(true)
  const [candidates, setCandidates] = useState<ICandidate[]>([])
  const { control, watch, setValue } = useForm({
    shouldFocusError: true,
  })
  const [newCandidates, setNewCandidates] = useState<ICandidate[]>([])
  const [toastData, setToastData] = useState<IToastData>({
    type: undefined,
    message: '',
  })
  const [currentFile, setCurrentFile] = useState<FileList | null>(null)
  const [uploadedAttachments, setUploadedAttachments] = useState<{
    url: string
    fileName: string
  } | null>(null)
  const [fileUploading, setFileUploading] = useState<boolean>(false)
  const [eventParticipantsAttachmentData, setEventParticipantAttachmentData] =
    useState<any>('')

  const values = watch()

  useEffect(() => {
    getMatchListParticipants()
  }, [])

  useEffect(() => {
    setTimeout(() => {
      setToastData({
        type: undefined,
        message: '',
      })
    }, 5000)
  }, [JSON.stringify(toastData)])

  const getEventParticipantsAttachment = async () => {
    const res = await axiosInstance.get(`/api/event/${eventId}`)
    if (res.data.event.participantsAttachment) {
      const responseFromFileServerAttachment = await axiosInstance.post(
        '/api/attachment/get-attachment-link',
        {
          fileName: res.data.event.participantsAttachment,
        },
      )

      setUploadedAttachments({
        url: responseFromFileServerAttachment.data.url,
        fileName: res.data.event.participantsAttachment,
      })
    }
  }

  useEffect(() => {
    getEventParticipantsAttachment()
  }, [])

  const getMatchListParticipants = () => {
    axiosInstance
      .get(`/api/event/get-candidates/${eventId}`)
      .then((response) => {
        if (response.status === 200) {
          const uniqueCandidates: ICandidate[] =
            response.data.candidates.reduce(
              (acc: ICandidate[], current: ICandidate) => {
                const x = acc.find((item) => item.email === current.email)
                if (!x) {
                  return acc.concat([current])
                } else {
                  return acc
                }
              },
              [],
            )
          uniqueCandidates.forEach((candidate) => {
            setValue(`${candidate.personId}`, candidate.present)
          })

          // uniqueCandidates.map((candidate) => values[candidate.personId] = candidate.present)
          setCandidates(uniqueCandidates)
        } else {
          setToastData({
            type: 'error',
            message: errorMessages.DEFAULT_ERROR,
          })
        }
      })
      .catch((error) => {
        setToastData({
          type: 'error',
          message:
            error instanceof AxiosError
              ? error.response?.data?.error
              : errorMessages.DEFAULT_ERROR,
        })
      })
      .finally(() => {
        setCandidateLoading(false)
      })
  }

  useEffect(() => {
    if (currentFile) {
      setUploadedAttachments(null)
    }
  }, [currentFile])

  const addCandidateHandler = (candidate: ICandidate) => {
    setNewCandidates((prev) => [...prev, candidate])
    const cands = [...candidates, candidate]
    const uniqueCandidates: ICandidate[] = cands.reduce(
      (acc: ICandidate[], current: ICandidate) => {
        const x = acc.find((item) => item.email === current.email)
        if (!x) {
          return acc.concat([current])
        } else {
          return acc
        }
      },
      [],
    )
    setCandidates(uniqueCandidates)
  }

  const handleMatchList = async () => {
    setLoading(true)

    let responseFromFileServer: AxiosResponse | null = null
    if (currentFile !== null) {
      setFileUploading(true)
      const formData = new FormData()
      formData.append('file', currentFile[0])
      responseFromFileServer = await axiosInstance.post('/api/upload', formData)
      if (responseFromFileServer && responseFromFileServer.status === 201) {
        const res = await axiosInstance.post(`/api/event/${eventId}`, {
          attachment: responseFromFileServer.data.responseData[0].fileName,
        })
        setFileUploading(false)
      }
    }

    if (newCandidates.length > 0) {
      const res = await axiosInstance.post('/api/collaborator/add-attendees', {
        eventId: +eventId,
        attendees: newCandidates,
      })
    }

    const payload = {
      eventId: +eventId,
      candidates: Object.keys(values)
        .filter((key) => values[key])
        .map(Number),
    }

    axiosInstance
      .post('/api/collaborator/match-list', payload)
      .then((response) => {
        if (response.status === 201) {
          setToastData({
            type: 'success',
            message: response.data.message,
          })
          router.push('/collaborator/dashboard')
        } else {
          setToastData({
            type: 'error',
            message: errorMessages.DEFAULT_ERROR,
          })
        }
      })
      .catch((error) => {
        setToastData({
          type: 'error',
          message:
            error instanceof AxiosError
              ? error.response?.data?.error
              : errorMessages.DEFAULT_ERROR,
        })
      })
      .finally(() => {
        setLoading(false)
      })
  }

  if (candidateLoading) {
    return (
      <Box
        sx={{
          position: 'fixed',
          top: 0,
          left: 0,
          width: '100%',
          zIndex: 9999,
        }}
      >
        <LinearProgress />
      </Box>
    )
  }

  return (
    <>
      {toastData.message !== '' ? (
        <Toast message={toastData.message} severity={toastData.type} />
      ) : null}
      <Box>
        <Grid container justifyContent="space-between" mb={25}>
          <Grid item display="flex" alignItems="flex-end" gap={10}>
            <Typography variant="h1" mb={0}>
              Match List of Participants
            </Typography>
          </Grid>
          <Grid item>
            <CustomButton
              icon
              label
              labelText={tDashboardScoped('Back')}
              iconName="arrowLeft"
              onClick={() => router.back()}
            />
          </Grid>
        </Grid>
        <Typography variant="h2">Uploaded List of Participants</Typography>
        <Typography variant="h2">Confirm Participants</Typography>

        <Grid
          container
          spacing={10}
          sx={{ marginLeft: '5px', marginBottom: '100px' }}
        >
          {candidates?.map((candidate, index) => {
            return (
              <Grid key={index} xs={12} md={6}>
                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                  <CustomCheckbox
                    label="Present"
                    value={candidate.personId}
                    name={candidate.personId.toString()}
                    control={control}
                  />
                  <Box
                    sx={{
                      border: '1px solid black',
                      padding: '5px',
                      margin: '10px',
                      width: '70%',
                    }}
                  >{`${candidate.firstName} ${candidate.lastName ?? ''}`}</Box>
                </Box>
              </Grid>
            )
          })}
        </Grid>

        <Grid
          container
          flexDirection="column"
          spacing={10}
          justifyContent="flex-start"
          mb={50}
        >
          <AddCandidates addCandidateHandler={addCandidateHandler} />
          <AddAttachment
            sx={{ marginRight: 'auto', marginLeft: '77px' }}
            currentFiles={currentFile}
            fileUploading={fileUploading}
            setCurrentFiles={setCurrentFile}
            uploadedAttachments={
              uploadedAttachments ? [uploadedAttachments] : []
            }
            setUploadedAttachments={setUploadedAttachments}
            labelText={tDashboardScoped('Upload Document')}
            iconName="upload"
          />
        </Grid>
        <Box>
          <Grid container spacing={10} justifyContent="center" mb={25}>
            <Grid item>
              <Button
                label
                labelText="Discard"
                sx={{ minWidth: '200px' }}
                onClick={() => router.back()}
              />
            </Grid>

            <Grid item>
              <Button
                label
                labelText="Save"
                sx={{ minWidth: '200px' }}
                variant="contained"
                onClick={handleMatchList}
                disabled={!Object.values(values).includes(true)}
                loading={loading}
              />
            </Grid>
          </Grid>
        </Box>
      </Box>
    </>
  )
}

export default MatchList
