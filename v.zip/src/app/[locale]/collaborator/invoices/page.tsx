'use client'
import Toast from '@/components/Toast'
import CustomModal from '@/components/Modal'
import Pagination from '@/components/Pagination'
import InputField from '@/components/InputField'
import axiosInstance from '@/services/axiosInstance'
import CustomButton from '@/components/Buttons/CustomButton'
import AddAttachment from '@/components/Buttons/AddAttachment'
import CollaboratorBillRow from '@/components/TableRows/CollaboratorBillRow'
import { useRouter } from 'next/navigation'

import { Bill } from '@prisma/client'
import { useForm } from 'react-hook-form'
import { useEffect, useState } from 'react'
import { AxiosError, AxiosResponse } from 'axios'
import { RHFTextArea } from '@/components/TextArea'
import { errorMessages } from '@/utils/errorMessages'
import { successMessages } from '@/utils/successMessages'
import { paginationLimit } from '@/utils/constants/common'
import { validationMessages } from '@/validators/messages'
import { useScopedI18n } from '../../../../../locales/client'
import {
  Box,
  Grid,
  Table,
  TableBody,
  TableContainer,
  Typography,
} from '@mui/material'

interface IBill extends Omit<Bill, 'attachment'> {
  attachment: { url: string; fileName: string }
}

const CollaboratorInvoices = () => {
  const tScoped = useScopedI18n('invoices')
  const tDashboardScoped = useScopedI18n('dashboard')
  const [bills, setBills] = useState<IBill[]>([])
  const [page, setPage] = useState<number>(1)
  const [viewMode, setViewMode] = useState<boolean>(false)
  const [openModal, setOpenModal] = useState<boolean>(false)
  const [serverError, setServerError] = useState<string>('')
  const [isEmployee, setIsEmployee] = useState<boolean>(true)
  const [totalRecords, setTotalRecords] = useState<number>(0)
  const [invoiceCreated, setInvoiceCreated] = useState<boolean>(false)
  const [fileUploading, setFileUploading] = useState<boolean>(false)
  const [currentFiles, setCurrentFiles] = useState<FileList | null>(null)
  const [uploadedAttachments, setUploadedAttachments] = useState<{
    url: string
    fileName: string
  } | null>(null)

  const {
    control,
    handleSubmit,
    formState: { errors },
    setValue,
  } = useForm<Omit<Bill, 'bill_id'>>({
    mode: 'all',
    defaultValues: {
      title: '',
      amount: '',
      comment: '',
    },
    shouldFocusError: true,
  })

  const uploadBillHandler = async (payload: Omit<Bill, 'bill_id'>) => {
    setServerError('')
    setInvoiceCreated(false)
    setFileUploading(true)
    try {
      let response: AxiosResponse | null = null

      const formData = new FormData()
      if (currentFiles) {
        formData.append('file', currentFiles[0])
        response = await axiosInstance.post('/api/upload', formData)

        if (response && response.status === 201) {
          setFileUploading(false)
        } else {
          throw new Error(errorMessages.FAILED_TO_UPLOAD_ATTACHMENT)
        }
      }
      await axiosInstance.post('/api/invoices', {
        ...payload,
        attachment: response?.data.responseData[0].fileName ?? '',
      })
      setInvoiceCreated(true)
      closeBillHandler()
      await getBills()
    } catch (error) {
      const errorMessage =
        error instanceof AxiosError
          ? error.response?.data?.error
          : errorMessages.DEFAULT_ERROR

      setServerError(errorMessage)
    }
  }

  const getBills = async () => {
    setServerError('')
    try {
      const response = await axiosInstance.get(`/api/invoices?${page}`)
      setBills(response.data.bills)
      setTotalRecords(response.data.totalRecords)
      setIsEmployee(response.data.isEmployee)
    } catch (error) {
      const errorMessage =
        error instanceof AxiosError
          ? error.response?.data?.error
          : errorMessages.DEFAULT_ERROR

      setServerError(errorMessage)
    }
  }

  const openFileInNewTab = async (file: string) => {
    const responseFromFileServer = await axiosInstance.post(
      '/api/attachment/get-attachment-link',
      { fileName: file },
    )

    let fileURLFromFileServer = ''
    if (responseFromFileServer.status === 200) {
      fileURLFromFileServer = responseFromFileServer.data.url
    }

    window.open(fileURLFromFileServer, '_blank')
  }

  useEffect(() => {
    getBills()
  }, [page])

  const openBillHandler = (billId: number) => {
    const selectedBill = bills.find((bill) => bill.billId === billId)
    if (!selectedBill) {
      return
    }
    setUploadedAttachments(selectedBill.attachment)
    setValue('amount', selectedBill.amount)
    setValue('comment', selectedBill.comment)
    setValue('title', selectedBill.title)
    setOpenModal(true)
  }

  const closeBillHandler = () => {
    setValue('amount', '')
    setValue('comment', '')
    setValue('title', '')
    setOpenModal(false)
  }

  const router = useRouter()

  return (
    <>
      <Box>
        <Grid container justifyContent="space-between" mb={10}>
          <Grid item display="flex" alignItems="flex-end" gap={10}>
            <Typography variant="h1" mb={0}>
              {isEmployee ? tScoped('Bills') : tScoped('My Bills')}
            </Typography>
          </Grid>
          <Grid item>
            <CustomButton
              icon
              label
              labelText={tDashboardScoped('Back')}
              iconName="arrowLeft"
              onClick={() => router.back()}
            />
          </Grid>
        </Grid>

        {isEmployee ? null : (
          <Grid container justifyContent="space-between" mb={10}>
            <Typography variant="h2">{tScoped('Bills')}</Typography>
            <CustomButton
              icon
              label
              labelText={tScoped('Upload Bill')}
              iconName="plus"
              onClick={() => {
                setOpenModal(true)
                setViewMode(false)
              }}
            />
          </Grid>
        )}

        <TableContainer>
          <Table sx={{ minWidth: '744px', marginBottom: '25px' }}>
            <TableBody>
              {bills?.map((bill) => (
                <CollaboratorBillRow
                  key={bill.billId}
                  bill={bill}
                  onClickHandler={(billId) => {
                    openBillHandler(billId)
                    setViewMode(true)
                  }}
                />
              ))}
            </TableBody>
          </Table>

          {totalRecords > paginationLimit ? (
            <Pagination
              count={Math.ceil(totalRecords / paginationLimit)}
              page={page}
              onChange={(_, page) => setPage(page)}
            />
          ) : null}
        </TableContainer>
      </Box>

      <CustomModal open={openModal} onClose={closeBillHandler}>
        <Box
          component="form"
          autoComplete="off"
          onSubmit={handleSubmit(uploadBillHandler)}
        >
          <Typography variant="h2" mb={15}>
            {viewMode ? tScoped('Bills') : tScoped('Upload Bill')}
          </Typography>

          <Grid container spacing={10} mb={10}>
            <Grid item xs={12}>
              <InputField
                label={tScoped('Bill Title')}
                control={control}
                name="title"
                rules={{
                  required: {
                    value: true,
                    message: validationMessages.required,
                  },
                }}
                error={!!errors.title}
                helperText={errors.title?.message}
                fullWidth
                disabled={viewMode}
              />
              <InputField
                label={tScoped('Amount')}
                control={control}
                name="amount"
                type="number"
                rules={{
                  required: {
                    value: true,
                    message: validationMessages.required,
                  },
                }}
                error={!!errors.amount}
                helperText={errors.amount?.message}
                fullWidth
                disabled={viewMode}
              />
              <RHFTextArea
                label={tScoped('Comment')}
                control={control}
                name="comment"
                disabled={viewMode}
              />
            </Grid>
          </Grid>

          {viewMode ? (
            <>
              {uploadedAttachments ? (
                <Grid>
                  <Grid
                    item
                    onClick={
                      () => openFileInNewTab(uploadedAttachments.fileName)
                      // window.open(uploadedAttachments?.url, '_blank')
                    }
                  >
                    {uploadedAttachments?.fileName}
                  </Grid>
                </Grid>
              ) : null}
            </>
          ) : (
            <Grid container spacing={10} justifyContent="flex-end">
              <Grid
                item
                container
                xs={12}
                spacing={10}
                justifyContent="flex-end"
              >
                <Grid item>
                  <AddAttachment
                    currentFiles={currentFiles}
                    fileUploading={fileUploading}
                    setCurrentFiles={setCurrentFiles}
                  />
                </Grid>
                <Grid item>
                  <CustomButton
                    label
                    labelText={tScoped('Discard')}
                    onClick={closeBillHandler}
                  />
                </Grid>
                <Grid item>
                  <CustomButton
                    label
                    labelText={tScoped('Save')}
                    type="submit"
                    variant="contained"
                  />
                </Grid>
              </Grid>
            </Grid>
          )}
        </Box>
      </CustomModal>

      {serverError !== '' ? (
        <Toast message={serverError} severity="error" />
      ) : null}

      {invoiceCreated ? (
        <Toast message={successMessages.invoiceCreated} severity="success" />
      ) : null}
    </>
  )
}

export default CollaboratorInvoices
