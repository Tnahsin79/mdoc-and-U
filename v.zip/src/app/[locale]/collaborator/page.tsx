const Collaborators = () => {
  return <div>Collaborator</div>
}

export default Collaborators
