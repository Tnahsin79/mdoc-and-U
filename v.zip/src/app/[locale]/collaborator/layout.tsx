import { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'TTMP | Collaborator Dashboard',
  description: 'Collaborator Dashboard',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return children
}
