'use client'

import { UserContext } from '@/contexts/userContext'
import { errorMessages } from '@/utils/errorMessages'
import { ChangeEvent, Fragment, useContext, useEffect, useState } from 'react'
import { Grid, Table, TableBody, Typography, Alert } from '@mui/material'
import { collaboratorProtectedRoutes } from '@/utils/constants/frontend'

import Link from 'next/link'
import moment from 'moment'
import Toast from '@/components/Toast'
import axiosInstance from '@/services/axiosInstance'
import CustomButton from '@/components/Buttons/CustomButton'
import EventTableRow from '@/components/TableRows/EventTableRow'
import TasksComponent from '@/components/Tasks'
import { useRouter } from 'next/navigation'
import { CategorizedEventsMap, NewEvent } from '../../event/page'
import { useI18n, useScopedI18n } from '../../../../../locales/client'
import SwitchButton from '@/components/Buttons/SwitchButton'

interface ICollaboratorDashboardRoutes {
  path: string
  disabled: boolean
  label: 'My Collaboration Data' | 'Communication' | 'My Invoices' | 'History'
}

const CollaboratorDashboard = () => {
  const t = useI18n()
  const router = useRouter()
  const tScoped = useScopedI18n('dashboard')
  const { user } = useContext(UserContext)
  const [userName, setUserName] = useState<string>('')
  const [serverError, setServerError] = useState<string>('')
  const [profileCompleted, setProfileCompleted] = useState<boolean>(true)
  const [categorizedByDateEvents, setCategorizedByDateEvents] =
    useState<CategorizedEventsMap>({})

  const [remainingParticipation, setRemainingParticipation] =
    useState<boolean>(false)

  const [events, setEvents] = useState<NewEvent[] | []>([])

  useEffect(() => {
    if (!user) return
    setUserName(`${user?.firstName ?? ''} ${user?.lastName ?? ''}`)
    getEventListHandler()
  }, [remainingParticipation])

  const handleRadioFilter = (
    name: string,
    e: ChangeEvent<HTMLInputElement>,
  ) => {
    const selected = e.target.checked

    if (name === 'remainingParticipation') {
      setRemainingParticipation(selected)
    }
  }

  const eventCategorizer = (newEvents: NewEvent[]) => {
    const categorizedEventsMap: CategorizedEventsMap = {}
    newEvents.forEach((event) => {
      const eventDate = moment(
        event.bookedFrom.toString().split('T')[0],
      ).format('dddd, DD.MM.YYYY')
      if (categorizedEventsMap[`${eventDate}`]) {
        categorizedEventsMap[`${eventDate}`].push(event)
      } else {
        categorizedEventsMap[`${eventDate}`] = [event]
      }
    })

    setCategorizedByDateEvents({ ...categorizedEventsMap })
  }

  const getEventListHandler = async () => {
    try {
      const response = await axiosInstance.post('/api/event/event-list', {
        page: 1,
        suitableCollaboratorId: user?.personId,
        remainingParticipation: remainingParticipation,
      })
      const constructedEvents = [...response.data.eventList]
      const fiveEvents = constructedEvents.filter((event, index) => index < 5)
      setEvents(fiveEvents)
    } catch (error) {
      setServerError(errorMessages.DEFAULT_ERROR)
    }
  }

  const getProfileStatus = async () => {
    try {
      const response = await axiosInstance.get(
        `/api/collaborator/${user?.collaboratorId}?profileStatus=true`,
      )
      // remove this console.log
      setProfileCompleted(response.data.collaborator.profileCompleted)
    } catch (error) {
      setServerError(errorMessages.DEFAULT_ERROR)
    }
  }

  useEffect(() => {
    if (user?.collaboratorId) {
      getProfileStatus()
    }
  }, [user?.collaboratorId])

  useEffect(() => {
    if (events.length) {
      eventCategorizer(events)
    }
  }, [events])

  return (
    <>
      {!profileCompleted ? (
        <Alert variant="outlined" severity="warning">
          {tScoped('Please update your cooperation details')}
        </Alert>
      ) : null}
      <Typography
        variant="h1"
        mb={10}
        mt={10}
        sx={{ textTransform: 'capitalize' }}
      >
        {t('hello')} {userName}
      </Typography>
      <Typography variant="h2" mb={10}>
        {tScoped('Overview')}
      </Typography>
      <Grid container spacing={8} mb={50}>
        {collaboratorProtectedRoutes(
          user?.collaboratorId ?? undefined,
          user?.personId,
        ).map(({ path, disabled, label }: ICollaboratorDashboardRoutes) => (
          <Grid item xs={4} md={3} key={path}>
            <Link href={path} className={disabled ? 'disabled' : ''}>
              <CustomButton
                label={true}
                labelText={tScoped(label)}
                icon={true}
                fullWidth
                disabled={disabled}
              />
            </Link>
          </Grid>
        ))}
      </Grid>
      <TasksComponent isDashboard={true} />
      <Grid
        container
        sx={{ alignItems: 'center', justifyContent: 'space-between' }}
      >
        <Grid item xs={3}>
          <Typography variant="h2">{tScoped('Events')}</Typography>
        </Grid>
        <Grid
          item
          sx={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <SwitchButton
            label={tScoped('Participation Not Completed')}
            name="remainingParticipation"
            handleChange={(e) => handleRadioFilter('remainingParticipation', e)}
            checked={remainingParticipation}
          />
        </Grid>
      </Grid>
      {Object.keys(categorizedByDateEvents).map((date, index) => (
        <Fragment key={index}>
          <Typography variant="h5" sx={{ fontWeight: 700, fontSize: '20px' }}>
            {date}
          </Typography>
          <Table sx={{ marginBottom: '25px' }}>
            <TableBody>
              {categorizedByDateEvents[`${date}`].map((event, index) => (
                <EventTableRow key={index} event={event} phase={event.phase} />
              ))}
            </TableBody>
          </Table>
        </Fragment>
      ))}
      <Grid container justifyContent="flex-end" mb={65}>
        <Grid item>
          {' '}
          <CustomButton
            onClick={() => router.push('/event')}
            icon
            label
            labelText={tScoped('Show More')}
          />
        </Grid>
      </Grid>
      {serverError !== '' ? (
        <Toast message={serverError} severity="error" />
      ) : null}
    </>
  )
}

export default CollaboratorDashboard
