'use client'
import IconSwitcher from '@/components/Icons'
import Pagination from '@/components/Pagination'
import NewMessage from '@/components/Modals/NewMessage'
import axiosInstance from '@/services/axiosInstance'
import MessageRow from '@/components/TableRows/MessageRow'
import SwitchButton from '@/components/Buttons/SwitchButton'
import CustomButton from '@/components/Buttons/CustomButton'
import { useRouter } from 'next/navigation'
// import { debounce } from '@/utils/debounce'
import { useEffect, useRef, useState } from 'react'
import { paginationLimit } from '@/utils/constants'
import {
  Box,
  Grid,
  InputAdornment,
  LinearProgress,
  TextField,
  Typography,
} from '@mui/material'
import { Checked, IMailData, IModalData } from '@/interface/communication'
import { useScopedI18n } from '../../../../locales/client'
import { IList } from '@/interface/common'
import { List } from '@prisma/client'

const CollaboratorCommunicationHome = () => {
  const router = useRouter()
  const mounted = useRef(false)
  const tScoped = useScopedI18n('communication')
  const tDashboardScoped = useScopedI18n('dashboard')
  const [loading, setLoading] = useState<boolean>(false)
  const [modalData, setModalData] = useState<IModalData>({
    open: false,
    type: '',
  })
  const [myEmail, setMyEmail] = useState<string | null>(null)
  const [totalRecords, setTotalRecords] = useState<number>(0)
  const [filteredList, setFilteredList] = useState<IMailData[] | []>([])
  const [checked, setChecked] = useState<Checked>({
    received: false,
    sent: false,
    new: false,
  })
  const [page, setPage] = useState<number>(1)
  const [replyToMail, setReplyToMail] = useState<IMailData | undefined>(
    undefined,
  )
  const [searchText, setSearchText] = useState<string | null>(null)

  const [yesOrNo, setYesOrNo] = useState<IList>([])
  const [schoolType, setSchoolType] = useState<IList>([])

  const getAllLists = async () => {
    const listsFromApi = await axiosInstance.post('/api/list', {
      listTypes: ['schoolType', 'yesOrNo'],
    })

    setYesOrNo(listsFromApi.data.data.yesOrNo)
    setSchoolType(
      listsFromApi.data.data.schoolType.filter(
        (item: List) =>
          !['Tempelhof-Schöneberg', 'Lichtenberg', 'nicht gesetzt'].includes(
            item.listValue,
          ),
      ),
    )
  }

  const onPageChangeHandler = async (
    _: React.ChangeEvent<unknown>,
    value: number,
  ) => {
    setPage(value)
  }

  useEffect(() => {
    getMailList()
  }, [checked, page, searchText])

  useEffect(() => {
    mounted.current = true
    getAllLists()
  }, [])

  const handleReply = (mail: IMailData) => {
    setReplyToMail(mail)
    setModalData({
      open: true,
      type: 'message',
    })
  }

  const handleClose = () => {
    setReplyToMail(undefined)
    setModalData({ type: '', open: false })
    getMailList()
  }

  const getMailList = async () => {
    setLoading(true)
    const response = await axiosInstance.post(
      '/api/communication/collaborator/list',
      {
        page: page,
        checked,
        search: searchText,
      },
    )
    setLoading(false)
    setMyEmail(response.data.ownMail)
    setFilteredList(response.data.mailList)
    setTotalRecords(response.data.totalRecords)
  }

  // const debouncedMailList = debounce(getMailList, 500)

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value
    setSearchText(value)
    // debouncedMailList(value)
    setPage(1)
  }

  if (loading && !mounted.current) {
    return (
      <Box
        sx={{
          position: 'fixed',
          top: 0,
          left: 0,
          width: '100%',
          zIndex: 9999,
        }}
      >
        <LinearProgress />
      </Box>
    )
  }

  return (
    <>
      <NewMessage
        open={modalData.type === 'message' && modalData.open}
        handleClose={handleClose}
        role="Collaborator"
        replyToMail={replyToMail}
      />

      <Grid container justifyContent="space-between" mb={25}>
        <Grid item display="flex" alignItems="flex-end" gap={10}>
          <Typography variant="h1" mb={0}>
            {tScoped('Communication')}
          </Typography>
        </Grid>
        <Grid item>
          <CustomButton
            icon
            label
            labelText={tDashboardScoped('Back')}
            iconName="arrowLeft"
            onClick={() => router.back()}
          />
        </Grid>
      </Grid>

      <Grid
        container
        justifyContent="flex-end"
        alignItems="center"
        mb={10}
        spacing={10}
      >
        <Grid item>
          <SwitchButton
            label={tScoped('Received')}
            name="received"
            checked={checked.received}
            handleChange={() => {
              setChecked({
                ...checked,
                received: !checked.received,
              })
            }}
          />
        </Grid>
        <Grid item>
          <SwitchButton
            label={tScoped('Sent')}
            name="sent"
            checked={checked.sent}
            handleChange={() => {
              setChecked({
                ...checked,
                sent: !checked.sent,
              })
            }}
          />
        </Grid>
        <Grid item>
          <SwitchButton
            label={tScoped('New Messages Only')}
            name="newMessagesOnly"
            checked={checked.new}
            handleChange={() => {
              setChecked({
                ...checked,
                new: !checked.new,
              })
            }}
          />
        </Grid>

        <Grid item>
          <TextField
            sx={{ marginBottom: 0 }}
            name="search"
            type="search"
            value={searchText ? searchText : ''}
            placeholder={tScoped('Search')}
            InputProps={{
              endAdornment: (
                <InputAdornment
                  position="end"
                  sx={{
                    cursor: 'pointer',
                    background: '#e40422',
                    height: '100%',
                    marginRight: '-14px',
                    maxHeight: '100%',
                    paddingInline: '10px',
                  }}
                >
                  <IconSwitcher icon={'search'} />
                </InputAdornment>
              ),
            }}
            onChange={handleSearch}
          />
        </Grid>

        <Grid item>
          <CustomButton
            label
            labelText={tScoped('New Message')}
            icon
            iconName="plus"
            onClick={() => {
              setModalData({
                open: true,
                type: 'message',
              })
            }}
          />
        </Grid>
      </Grid>

      <Box>
        {filteredList.map((msg) => {
          return msg.isBuddyRequest ? (
            <MessageRow
              key={msg.communicationId}
              preposition={myEmail === msg.recipient.email ? 'From' : 'To'}
              sender={
                msg.sender
                  ? msg.sender
                  : { email: '', firstName: '', lastName: '' }
              }
              recipient={msg.recipient}
              topic={msg.subject}
              date={msg.timeStamp.toString()}
              message={msg.body}
              role="Collaborator"
              read={msg.read}
              id={msg.communicationId}
              onReply={() => handleReply(msg)}
              isNote={msg.isNote}
              attachment={msg.attachment ?? ''}
              isBuddyRequest={msg.isBuddyRequest}
              yesOrNo={yesOrNo}
              schoolType={schoolType}
              availableId={msg.buddyRequest?.availableId}
              howFarDistance={msg.buddyRequest?.howFarDistance}
              howManyToSupport={msg.buddyRequest?.howManyToSupport}
              schoolTypesIds={msg.buddyRequest?.schoolTypesIds}
              isSubmitted={msg.buddyRequest?.isSubmitted}
            />
          ) : (
            <MessageRow
              key={msg.communicationId}
              preposition={myEmail === msg.recipient.email ? 'From' : 'To'}
              sender={
                msg.sender
                  ? msg.sender
                  : { email: '', firstName: '', lastName: '' }
              }
              recipient={msg.recipient}
              topic={msg.subject}
              date={msg.timeStamp.toString()}
              message={msg.body}
              role="Collaborator"
              read={msg.read}
              id={msg.communicationId}
              onReply={() => handleReply(msg)}
              isNote={msg.isNote}
              attachment={msg.attachment ?? ''}
            />
          )
        })}
      </Box>
      {totalRecords > paginationLimit ? (
        <Pagination
          count={Math.ceil(totalRecords / paginationLimit)}
          page={page}
          onChange={onPageChangeHandler}
        />
      ) : null}
    </>
  )
}

export default CollaboratorCommunicationHome
