'use client'
import {
  Box,
  Grid,
  Table,
  TableBody,
  TableContainer,
  Typography,
} from '@mui/material'
import Pagination from '@/components/Pagination'
import React, { useContext, useEffect, useState } from 'react'
import { useScopedI18n } from '../../../../locales/client'
import axiosInstance from '@/services/axiosInstance'
import { paginationLimit } from '@/utils/constants'
import { UserContext } from '@/contexts/userContext'
import Toast from '@/components/Toast'
import EmployeeTableRow, {
  IEmployee,
} from '@/components/TableRows/EmployeeTableRow'
import { useRouter } from 'next/navigation'
import { AxiosError } from 'axios'
import { errorMessages } from '@/utils/errorMessages'
import Link from 'next/link'
import CustomButton from '@/components/Buttons/CustomButton'
import getUserRoles from '@/utils/getUserRoles'

const page = () => {
  const tScoped = useScopedI18n('dashboard')

  const [totalRecords, setTotalRecords] = useState<number>(0)
  const [page, setPage] = useState<number>(1)
  const [serverError, setServerError] = useState<string>('')
  const [employeesList, setEmployeesList] = useState<IEmployee[]>([])
  const { user } = useContext(UserContext)

  const onPageChangeHandler = async (
    _: React.ChangeEvent<unknown>,
    value: number,
  ) => {
    setPage(value)
  }

  useEffect(() => {
    getEmployees()
  }, [page])

  const getEmployees = async () => {
    try {
      const response = await axiosInstance.post('/api/employees', {
        page: page,
      })

      setEmployeesList(response.data.employeeList)
      setTotalRecords(response.data.totalRecords)
    } catch (error) {
      const errorMessage =
        error instanceof AxiosError
          ? error.response?.data?.error
          : errorMessages.DEFAULT_ERROR

      setServerError(errorMessage)
    }
  }

  const userRoles = getUserRoles(user)

  const canCreateEmployee = (userRoles: string[]) => {
    return userRoles.includes('subjectAdmin')
  }
  const createPermission = canCreateEmployee(userRoles)
  const router = useRouter()

  return (
    <Box width="100%">
      <Grid container justifyContent="space-between" mb={8}>
        <Grid item display="flex" alignItems="flex-end" gap={10}>
          <Typography variant="h1" mb={0}>
            {tScoped('Employees')}
          </Typography>
        </Grid>
        <Grid item>
          <CustomButton
            icon
            label
            labelText={tScoped('Back')}
            iconName="arrowLeft"
            onClick={() => router.back()}
          />
        </Grid>
      </Grid>

      {createPermission && (
        <Grid container justifyContent="flex-end" gap={10} mb={10}>
          <Link href={'/employees/create'}>
            <CustomButton
              label={true}
              labelText={tScoped('New Employee')}
              icon={true}
              iconName="plus"
            />
          </Link>
        </Grid>
      )}

      <TableContainer>
        <Table sx={{ minWidth: '744px', marginBottom: '25px' }}>
          <TableBody>
            {employeesList &&
              employeesList.map((employee) => (
                <EmployeeTableRow key={employee.personId} employee={employee} />
              ))}
          </TableBody>
        </Table>
      </TableContainer>
      {totalRecords > paginationLimit ? (
        <Pagination
          count={Math.ceil(totalRecords / paginationLimit)}
          page={page}
          onChange={onPageChangeHandler}
        />
      ) : null}

      {serverError !== '' ? (
        <Toast message={serverError} severity="error" />
      ) : null}
    </Box>
  )
}

export default page
