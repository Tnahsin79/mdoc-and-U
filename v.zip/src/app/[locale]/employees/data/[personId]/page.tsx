'use client'
import InputField from '@/components/InputField'
import { Box, Grid, Typography } from '@mui/material'
import { useParams, useRouter } from 'next/navigation'
import React, { useEffect, useState } from 'react'
import { useForm } from 'react-hook-form'
import { useScopedI18n } from '../../../../../../locales/client'
import CustomCheckbox from '@/components/Buttons/CustomCheckbox'
import CustomButton from '@/components/Buttons/CustomButton'
import Toast from '@/components/Toast'
import { validationMessages } from '@/validators/messages'
import axiosInstance from '@/services/axiosInstance'
import { AxiosError } from 'axios'
import { errorMessages } from '@/utils/errorMessages'
import { successMessages } from '@/utils/successMessages'
import { useUser } from '@/contexts/userContext'
import { Role } from '@prisma/client'
import DeleteAccount from '@/components/Modals/DeleteAccount'
import getUserRoles from '@/utils/getUserRoles'

interface EmployeeData {
  firstName: string
  lastName: string
  email: string
  subjectAdmin: boolean
  subjectSupervision: boolean
  householdAdmin: boolean
  departmentLead: boolean
}

const page = () => {
  const { personId } = useParams()
  const router = useRouter()
  const tScoped = useScopedI18n('dashboard')
  const [serverError, setServerError] = useState<string>('')
  const [employeeData, setEmployeeData] = useState<EmployeeData | null>(null)
  const [employeeUpdated, setEmployeeUpdated] = useState<boolean>(false)
  const [submitLoading, setSubmitLoading] = useState<boolean>(false)
  const [deleteModal, setDeleteModal] = useState<boolean>(false)
  const [employeeDeleted, setEmployeeDeleted] = useState<boolean>(false)

  const user = useUser()

  const handleEmployeeUpdate = async (payload: any) => {
    try {
      setServerError('')
      setSubmitLoading(true)

      if (
        !subjectAdmin &&
        !subjectSupervision &&
        !householdAdmin &&
        !departmentLead
      ) {
        throw new Error(errorMessages.SELECT_ATLEAST_ONE_ROLE)
      } else {
        const response = await axiosInstance.post(
          `/api/employees/${personId}`,
          {
            ...payload,
          },
        )

        if (response.status === 200) {
          setEmployeeUpdated(true)
          setTimeout(() => {
            router.push('/employees')
          }, 2000)
        }
      }
    } catch (error) {
      setSubmitLoading(false)
      let errorMessage = errorMessages.DEFAULT_ERROR

      if (error instanceof AxiosError) {
        if (error.response?.status === 409) {
          errorMessage =
            error.response.data?.message || errorMessages.DUPLICATE_EMAIL
        } else if (error.response?.status === 400) {
          errorMessage = errorMessages.DEFAULT_ERROR
        } else if (error.response?.status === 404) {
          errorMessage = errorMessages.NO_DATA_FOUND
        }
      }

      setServerError(errorMessage)
    }
  }

  const getEmployeeData = async () => {
    try {
      const response = await axiosInstance.get(`/api/employees/${personId}`)
      setEmployeeData(response.data.employee)
    } catch (error) {
      const errorMessage =
        error instanceof AxiosError
          ? error.response?.data?.error
          : errorMessages.DEFAULT_ERROR

      setServerError(errorMessage)
    }
  }

  useEffect(() => {
    getEmployeeData()
  }, [])

  const {
    handleSubmit,
    formState: { errors },
    control,
    reset,
    watch,
  } = useForm<any>({
    mode: 'all',
    values: {
      firstName: employeeData?.firstName,
      lastName: employeeData?.lastName,
      email: employeeData?.email,
      subjectAdmin: employeeData?.subjectAdmin,
      subjectSupervision: employeeData?.subjectSupervision,
      householdAdmin: employeeData?.householdAdmin,
      departmentLead: employeeData?.departmentLead,
    },
    shouldFocusError: true,
  })

  const subjectAdmin = watch('subjectAdmin')
  const subjectSupervision = watch('subjectSupervision')
  const householdAdmin = watch('householdAdmin')
  const departmentLead = watch('departmentLead')

  const handleDeleteAccountModalOpen = async () => {
    setDeleteModal(true)
  }

  const handleDeleteAccountModalClose = async () => {
    setDeleteModal(false)
  }

  const deleteAccount = async () => {
    try {
      const response = await axiosInstance.post(
        `/api/employees/delete/${personId}`,
        {
          personId: +personId,
        },
      )

      if (response.status === 200) {
        setEmployeeUpdated(true)
        setEmployeeDeleted(true)
        setTimeout(() => {
          router.replace('/employees')
        }, 1000)
      }
    } catch (error) {
      const errorMessage =
        error instanceof AxiosError
          ? error.response?.data?.error
          : errorMessages.DEFAULT_ERROR

      setServerError(errorMessage)
    }
  }

  const discardHandler = () => {
    reset()
    router.push('/employees')
  }

  const userRoles = getUserRoles(user)

  const canCreateEmployee = (userRoles: string[]) => {
    return userRoles.includes('subjectAdmin')
  }
  const createOrDeletePermission = canCreateEmployee(userRoles)

  return (
    <>
      <DeleteAccount
        open={deleteModal}
        onClose={handleDeleteAccountModalClose}
        onDelete={deleteAccount}
      />
      <Box
        component="form"
        onSubmit={handleSubmit(handleEmployeeUpdate)}
        autoComplete="off"
      >
        <Grid container justifyContent="space-between" mb={25}>
          <Grid item display="flex" alignItems="flex-end" gap={10}>
            <Typography variant="h1" mb={0}>
              {tScoped('Edit Employee')}
            </Typography>
          </Grid>
          <Grid item>
            <CustomButton
              icon
              label
              labelText={tScoped('Back')}
              iconName="arrowLeft"
              onClick={() => router.back()}
            />
          </Grid>
        </Grid>

        <Box sx={{ display: 'flex' }}>
          <Typography variant="h2" mb={15}>
            {tScoped('Data')}
          </Typography>

          <Box
            sx={{
              marginLeft: 'auto',
            }}
          >
            {user?.role === Role.Employee && createOrDeletePermission ? (
              <CustomButton
                label
                labelText={tScoped('Delete')}
                sx={{ width: '200px' }}
                variant="contained"
                onClick={handleDeleteAccountModalOpen}
              />
            ) : null}
          </Box>
        </Box>

        <Grid container columnSpacing={10} mb={15}>
          <Grid item xs={6}>
            <InputField
              control={control}
              name="firstName"
              label={tScoped('First Name')}
              fullWidth
              rules={{
                required: {
                  value: true,
                  message: validationMessages.required,
                },
              }}
              error={!!errors.firstName}
              helperText={errors.firstName?.message as string}
            />
          </Grid>

          <Grid item xs={6}>
            <InputField
              control={control}
              name="lastName"
              label={tScoped('Last Name')}
              fullWidth
              rules={{
                required: {
                  value: true,
                  message: validationMessages.required,
                },
              }}
              error={!!errors.lastName}
              helperText={errors.lastName?.message as string}
            />
          </Grid>

          <Grid item xs={6}>
            <InputField
              control={control}
              name="email"
              label={tScoped('E-mail Address')}
              fullWidth
              rules={{
                required: {
                  value: true,
                  message: validationMessages.required,
                },
              }}
              error={!!errors.email}
              helperText={errors.email?.message as string}
            />
          </Grid>
        </Grid>

        <Typography variant="h2" mb={15}>
          {tScoped('Role')}
        </Typography>

        <Grid container columnSpacing={10}>
          <Grid item xs={12} container>
            <CustomCheckbox
              control={control}
              label="Fachliche Administration"
              name="subjectAdmin"
            />
          </Grid>
          <Grid item xs={12} container>
            <CustomCheckbox
              control={control}
              label="Fachbetreuung Quereinstieg"
              name="subjectSupervision"
            />
          </Grid>
          <Grid item xs={12} container>
            <CustomCheckbox
              control={control}
              label="Sachbearbeitung Haushalt"
              name="householdAdmin"
            />
          </Grid>
          <Grid item xs={12} container>
            <CustomCheckbox
              control={control}
              label="Referatsleitung"
              name="departmentLead"
            />
          </Grid>
        </Grid>

        <Grid container justifyContent="center" gap={10}>
          <CustomButton
            label={true}
            labelText={tScoped('Discard')}
            icon={false}
            disabled={!createOrDeletePermission}
            type="reset"
            sx={{ minWidth: '200px' }}
            onClick={() => discardHandler()}
          />
          <CustomButton
            label={true}
            labelText={tScoped('Save')}
            type="submit"
            disabled={!createOrDeletePermission}
            icon={false}
            variant="contained"
            sx={{ minWidth: '200px' }}
            loading={submitLoading}
          />
        </Grid>
        {employeeUpdated ? (
          <Toast message={successMessages.success} severity="success" />
        ) : null}
        {serverError !== '' ? (
          <Toast message={serverError} severity="error" />
        ) : null}
      </Box>
    </>
  )
}

export default page
