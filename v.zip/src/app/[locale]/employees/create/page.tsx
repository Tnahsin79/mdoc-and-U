'use client'
import InputField from '@/components/InputField'
import { validationMessages } from '@/validators/messages'
import { Box, Grid, Typography } from '@mui/material'
import React, { useContext, useEffect, useState } from 'react'
import { useForm } from 'react-hook-form'
import { useScopedI18n } from '../../../../../locales/client'
import Toast from '@/components/Toast'
import CustomButton from '@/components/Buttons/CustomButton'
import CustomCheckbox from '@/components/Buttons/CustomCheckbox'
import axiosInstance from '@/services/axiosInstance'
import { successMessages } from '@/utils/successMessages'
import { useRouter } from 'next/navigation'
import { UserContext } from '@/contexts/userContext'
import { errorMessages } from '@/utils/errorMessages'
import { AxiosError } from 'axios'

const CreateEmployee = () => {
  const tScoped = useScopedI18n('dashboard')

  const [serverError, setServerError] = useState<string>('')
  const [employeeCreated, setEmployeeCreated] = useState<boolean>(false)
  const router = useRouter()
  const [submitLoading, setSubmitLoading] = useState<boolean>(false)

  const { user } = useContext(UserContext)

  const {
    handleSubmit,
    formState: { errors },
    control,
    watch,
    reset,
  } = useForm<any>({
    mode: 'all',
    defaultValues: {
      firstName: '',
      lastName: '',
      email: '',
    },
    shouldFocusError: true,
  })

  const subjectAdmin = watch('subjectAdmin')
  const subjectSupervision = watch('subjectSupervision')
  const householdAdmin = watch('householdAdmin')
  const departmentLead = watch('departmentLead')

  useEffect(() => {
    console.log(errors, 'Errors')
  })

  const handleEmployeeSubmit = async (payload: any) => {
    try {
      setServerError('')
      setSubmitLoading(true)

      if (
        !subjectAdmin &&
        !subjectSupervision &&
        !householdAdmin &&
        !departmentLead
      ) {
        throw new Error(errorMessages.SELECT_ATLEAST_ONE_ROLE)
      } else {
        const response = await axiosInstance.post('/api/employees/create', {
          ...payload,
        })

        if (response.status === 201) {
          setEmployeeCreated(true)
          setTimeout(() => {
            router.push('/employees')
          }, 2000)
        }
      }
    } catch (error) {
      setSubmitLoading(false)
      let errorMessage = errorMessages.DEFAULT_ERROR

      if (error instanceof AxiosError) {
        if (error.response?.status === 409) {
          errorMessage =
            error.response.data?.message || errorMessages.DUPLICATE_EMAIL
        } else if (error.response?.status === 400) {
          errorMessage = errorMessages.DEFAULT_ERROR
        } else if (error.response?.status === 404) {
          errorMessage = errorMessages.NO_DATA_FOUND
        }
      }

      setServerError(errorMessage)
    }
  }

  const discardHandler = () => {
    reset()
    router.push('/employees')
  }

  return (
    <Box
      component="form"
      onSubmit={handleSubmit(handleEmployeeSubmit)}
      autoComplete="off"
    >
      <Grid container justifyContent="space-between" mb={25}>
        <Grid item display="flex" alignItems="flex-end" gap={10}>
          <Typography variant="h1" mb={0}>
            {tScoped('Create Employee')}
          </Typography>
        </Grid>
        <Grid item>
          <CustomButton
            icon
            label
            labelText={tScoped('Back')}
            iconName="arrowLeft"
            onClick={() => router.back()}
          />
        </Grid>
      </Grid>

      <Typography variant="h2" mb={15}>
        {tScoped('Data')}
      </Typography>

      <Grid container columnSpacing={10} mb={15}>
        <Grid item xs={6}>
          <InputField
            control={control}
            name="firstName"
            label={tScoped('First Name')}
            fullWidth
            rules={{
              required: {
                value: true,
                message: validationMessages.required,
              },
            }}
            error={!!errors.firstName}
            helperText={errors.firstName?.message as string}
          />
        </Grid>

        <Grid item xs={6}>
          <InputField
            control={control}
            name="lastName"
            label={tScoped('Last Name')}
            fullWidth
            rules={{
              required: {
                value: true,
                message: validationMessages.required,
              },
            }}
            error={!!errors.lastName}
            helperText={errors.lastName?.message as string}
          />
        </Grid>

        <Grid item xs={6}>
          <InputField
            control={control}
            name="email"
            label={tScoped('E-mail Address')}
            fullWidth
            rules={{
              required: {
                value: true,
                message: validationMessages.required,
              },
            }}
            error={!!errors.email}
            helperText={errors.email?.message as string}
          />
        </Grid>
      </Grid>

      <Typography variant="h2" mb={15}>
        {tScoped('Role')}
      </Typography>

      <Grid container columnSpacing={10}>
        <Grid item xs={12} container>
          <CustomCheckbox
            control={control}
            label="Fachliche Administration"
            name="subjectAdmin"
          />
        </Grid>
        <Grid item xs={12} container>
          <CustomCheckbox
            control={control}
            label="Fachbetreuung Quereinstieg"
            name="subjectSupervision"
          />
        </Grid>
        <Grid item xs={12} container>
          <CustomCheckbox
            control={control}
            label="Sachbearbeitung Haushalt"
            name="householdAdmin"
          />
        </Grid>
        <Grid item xs={12} container>
          <CustomCheckbox
            control={control}
            label="Referatsleitung"
            name="departmentLead"
          />
        </Grid>
      </Grid>

      <Grid container justifyContent="center" gap={10}>
        <CustomButton
          label={true}
          labelText={tScoped('Discard')}
          icon={false}
          disabled={!user?.subjectAdmin || !user?.subjectSupervision}
          type="reset"
          sx={{ minWidth: '200px' }}
          onClick={() => discardHandler()}
        />
        <CustomButton
          label={true}
          type="submit"
          labelText={tScoped('Save')}
          icon={false}
          disabled={!user?.subjectAdmin || !user?.subjectSupervision}
          variant="contained"
          sx={{ minWidth: '200px' }}
          loading={submitLoading}
        />
      </Grid>
      {employeeCreated ? (
        <Toast message={successMessages.accountCreated} severity="success" />
      ) : null}

      {serverError !== '' ? (
        <Toast message={serverError} severity="error" />
      ) : null}
    </Box>
  )
}

export default CreateEmployee
