'use client'
import IconSwitcher from '@/components/Icons'
import NewMessage from '@/components/Modals/NewMessage'
import Pagination from '@/components/Pagination'
import NewPhoneNote from '@/components/Modals/NewPhoneNote'
import axiosInstance from '@/services/axiosInstance'
import CustomButton from '@/components/Buttons/CustomButton'
import SwitchButton from '@/components/Buttons/SwitchButton'
import MessageRow from '@/components/TableRows/MessageRow'

import { useRouter } from 'next/navigation'
import { useEffect, useRef, useState } from 'react'
// import { debounce } from '@/utils/debounce'
import { paginationLimit } from '@/utils/constants'
import { Checked, IMailData, IModalData } from '@/interface/communication'
import {
  Box,
  Grid,
  InputAdornment,
  LinearProgress,
  TextField,
  Typography,
} from '@mui/material'
import NewTask from '@/components/Modals/NewTask'
import { useScopedI18n } from '../../../../locales/client'
import BuddyRequest from '@/components/Modals/BuddyRequest'

const CommunicationHome = () => {
  const mounted = useRef(false)
  const tScoped = useScopedI18n('communication')
  const tDashboardScoped = useScopedI18n('dashboard')
  const [loading, setLoading] = useState<boolean>(false)
  const [modalData, setModalData] = useState<IModalData>({
    open: false,
    type: '',
  })
  const [myEmail, setMyEmail] = useState<string | null>(null)
  const [totalRecords, setTotalRecords] = useState<number>(0)
  const [filteredList, setFilteredList] = useState<IMailData[] | []>([])
  const [checked, setChecked] = useState<Checked>({
    received: false,
    sent: false,
    new: false,
  })
  const [page, setPage] = useState<number>(1)
  const [replyToMail, setReplyToMail] = useState<IMailData | undefined>(
    undefined,
  )
  const [searchText, setSearchText] = useState<string | null>(null)

  const router = useRouter()

  useEffect(() => {
    getMailList()
  }, [checked, page, searchText])

  useEffect(() => {
    mounted.current = true
  }, [])

  const onPageChangeHandler = async (
    _: React.ChangeEvent<unknown>,
    value: number,
  ) => {
    setPage(value)
  }

  const handleReply = (mail: IMailData) => {
    setReplyToMail(mail)
    setModalData({
      open: true,
      type: 'message',
    })
  }

  const handleClose = () => {
    setReplyToMail(undefined)
    setModalData({ type: '', open: false })
    getMailList()
  }

  const getMailList = async () => {
    setLoading(true)
    const response = await axiosInstance.post(
      '/api/communication/employee/list',
      {
        page: page,
        checked,
        search: searchText,
      },
    )
    setLoading(false)
    setMyEmail(response.data.ownMail)
    setFilteredList(response.data.mailList)
    setTotalRecords(response.data.totalRecords)
  }

  // const debouncedMailList = debounce(getMailList, 5000)

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value
    setSearchText(value)
    // debouncedMailList()
    setPage(1)
  }

  const [selectedMessage, setSelectedMessage] = useState<IMailData | null>(null)

  if (loading && !mounted.current) {
    return (
      <Box
        sx={{
          position: 'fixed',
          top: 0,
          left: 0,
          width: '100%',
          zIndex: 9999,
        }}
      >
        <LinearProgress />
      </Box>
    )
  }

  return (
    <>
      <NewTask
        open={modalData.type === 'task' && modalData.open}
        handleClose={handleClose}
        selectedMessage={selectedMessage}
        myEmail={myEmail as string}
      />
      <NewMessage
        open={modalData.type === 'message' && modalData.open}
        handleClose={handleClose}
        role="Employee"
        replyToMail={replyToMail}
      />
      <BuddyRequest
        open={modalData.type === 'buddyRequest' && modalData.open}
        handleClose={handleClose}
      />

      <NewPhoneNote
        open={modalData.type === 'phoneNote' && modalData.open}
        handleClose={handleClose}
      />

      <Grid container justifyContent="space-between" mb={25}>
        <Grid item display="flex" alignItems="flex-end" gap={10}>
          <Typography variant="h1" mb={0}>
            {tScoped('Communication')}
          </Typography>
        </Grid>
        <Grid item>
          <CustomButton
            icon
            label
            labelText={tDashboardScoped('Back')}
            iconName="arrowLeft"
            onClick={() => router.back()}
          />
        </Grid>
      </Grid>

      <Grid container spacing={10} mb={25} justifyContent="flex-end">
        <Grid item>
          <TextField
            name="search"
            type="search"
            value={searchText ? searchText : ''}
            placeholder={tScoped('Search')}
            InputProps={{
              endAdornment: (
                <InputAdornment
                  position="end"
                  sx={{
                    cursor: 'pointer',
                    background: '#e40422',
                    height: '100%',
                    marginRight: '-14px',
                    maxHeight: '100%',
                    paddingInline: '10px',
                  }}
                >
                  <IconSwitcher icon={'search'} />
                </InputAdornment>
              ),
            }}
            onChange={handleSearch}
          />
        </Grid>
        <Grid item>
          <CustomButton
            icon
            label
            labelText={tScoped('New Buddy Request')}
            iconName="plus"
            onClick={() =>
              setModalData({
                open: true,
                type: 'buddyRequest',
              })
            }
          />
        </Grid>
        <Grid item>
          <CustomButton
            icon
            label
            labelText={tScoped('New Phone Note')}
            iconName="plus"
            onClick={() =>
              setModalData({
                open: true,
                type: 'phoneNote',
              })
            }
          />
        </Grid>
        <Grid item>
          <CustomButton
            icon
            label
            labelText={tScoped('New Message')}
            iconName="plus"
            onClick={() => {
              setModalData({
                open: true,
                type: 'message',
              })
            }}
          />
        </Grid>
        <Grid item>
          <CustomButton
            icon
            label
            labelText={tScoped('Non-assigned Messages')}
            iconName="arrowRight"
            onClick={() =>
              router.push('/communication-employee/non-assigned-messages')
            }
          />
        </Grid>
      </Grid>

      <Grid container justifyContent="space-around">
        <Grid item xs={6}>
          <Typography variant="h2">{tScoped('Inbox')}</Typography>
        </Grid>
        <Grid
          item
          xs={6}
          container
          justifyContent="flex-end"
          alignItems="center"
          spacing={30}
          sx={{ marginBottom: '15px' }}
        >
          <Grid item xs={4}>
            <SwitchButton
              label={tScoped('Receive')}
              name="receive"
              checked={checked.received}
              handleChange={() => {
                setChecked({
                  ...checked,
                  received: !checked.received,
                })
              }}
            />
          </Grid>
          <Grid item xs={4}>
            <SwitchButton
              label={tScoped('Sent')}
              name="sent"
              checked={checked.sent}
              handleChange={() => {
                setChecked({
                  ...checked,
                  sent: !checked.sent,
                })
              }}
            />
          </Grid>
          <Grid item xs={4}>
            <SwitchButton
              label={tScoped('Only New Messages')}
              name="collaborators"
              checked={checked.new}
              handleChange={() => {
                setChecked({
                  ...checked,
                  new: !checked.new,
                })
              }}
            />
          </Grid>
        </Grid>
      </Grid>
      <Box sx={{ minWidth: '744px' }}>
        {filteredList.map((msg) => (
          <MessageRow
            key={msg.communicationId}
            preposition={myEmail === msg.recipient.email ? 'From' : 'To'}
            sender={
              msg.sender
                ? msg.sender
                : { email: '', firstName: '', lastName: '' }
            }
            recipient={msg.recipient}
            topic={msg.subject}
            date={msg.timeStamp.toString()}
            message={msg.body}
            role="Employee"
            read={msg.read}
            id={msg.communicationId}
            onReply={() => handleReply(msg)}
            isNote={msg.isNote}
            attachment={msg.attachment ?? ''}
            openTaskModal={() => {
              setSelectedMessage(msg)
              setModalData({
                open: true,
                type: 'task',
              })
            }}
          />
        ))}
      </Box>

      {totalRecords > paginationLimit ? (
        <Pagination
          count={Math.ceil(totalRecords / paginationLimit)}
          page={page}
          onChange={onPageChangeHandler}
        />
      ) : null}
    </>
  )
}

export default CommunicationHome
