'use client'
import CustomButton from '@/components/Buttons/CustomButton'
import MessageRow from '@/components/TableRows/MessageRow'
import { Checked, IMailData } from '@/interface/communication'
import axiosInstance from '@/services/axiosInstance'
import { Box, Grid, Typography } from '@mui/material'
import { useEffect, useState } from 'react'
import { useScopedI18n } from '../../../../../locales/client'
import AssignMessage from '@/components/Modals/AssignMessage'
import Toast from '@/components/Toast'
import Pagination from '@/components/Pagination'
import { IToastData } from '@/interface/common'
import { useRouter } from 'next/navigation'
import { paginationLimit } from '@/utils/constants'

interface IModalData {
  type: string
  open: boolean
  communicationId: number | null
}

const NonAssigned = () => {
  const tScoped = useScopedI18n('communication')
  const tDashboardScoped = useScopedI18n('dashboard')
  const [loading, setLoading] = useState<boolean>(false)
  const [fetchMailBtnLoading, setFetchMailBtnLoading] = useState<boolean>(false)
  const [filteredList, setFilteredList] = useState<IMailData[] | []>([])
  const [totalRecords, setTotalRecords] = useState<number>(0)
  const [page, setPage] = useState<number>(1)
  const [checked, setChecked] = useState<Checked>({
    received: false,
    sent: false,
    new: false,
  })
  const [myEmail, setMyEmail] = useState<string | null>(null)
  const [modalData, setModalData] = useState<IModalData>({
    open: false,
    type: '',
    communicationId: null,
  })
  const [toastData, setToastData] = useState<IToastData>({
    type: undefined,
    message: '',
  })

  useEffect(() => {
    setTimeout(() => {
      setToastData({
        type: undefined,
        message: '',
      })
    }, 5000)
  }, [JSON.stringify(toastData)])

  const getMailList = async () => {
    setLoading(true)
    const response = await axiosInstance.post(
      '/api/communication/employee/list',
      {
        page: page,
        checked,
        isNotAssigned: true,
      },
    )
    setLoading(false)
    setMyEmail(response.data.ownMail)
    setFilteredList(response.data.mailList)
    setTotalRecords(response.data.totalRecords)
  }

  const getMailListBtn = async () => {
    setFetchMailBtnLoading(true)
    const response = await axiosInstance.post(
      '/api/communication/employee/list',
      {
        page: page,
        checked,
        isNotAssigned: true,
      },
    )
    setFetchMailBtnLoading(false)
    setMyEmail(response.data.ownMail)
    setFilteredList(response.data.mailList)
  }

  const handleAssign = (communicationId: number) => {
    setModalData({
      open: true,
      type: 'assign',
      communicationId: communicationId,
    })
  }

  const handleClose = () => {
    setModalData({
      open: false,
      type: '',
      communicationId: null,
    })
  }

  useEffect(() => {
    getMailList()
    setChecked({ ...checked })
  }, [page])

  const onPageChangeHandler = async (
    _: React.ChangeEvent<unknown>,
    value: number,
  ) => {
    setPage(value)
  }

  const router = useRouter()

  if (loading) {
    return (
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
        }}
      >
        Fetching mails...
      </Box>
    )
  }

  return (
    <>
      {toastData.message !== '' ? (
        <Toast message={toastData.message} severity={toastData.type} />
      ) : null}

      <AssignMessage
        open={modalData.open && modalData.type === 'assign'}
        handleClose={handleClose}
        communicationId={modalData.communicationId}
        onAssignSuccess={() => getMailList()}
        setToastData={setToastData}
      />
      <Grid container justifyContent="space-between" mb={25}>
        <Grid item display="flex" alignItems="flex-end" gap={10}>
          <Typography variant="h1" mb={0}>
            {tScoped('Non Assigned Messages')}
          </Typography>
        </Grid>
        <Grid item>
          <CustomButton
            icon
            label
            labelText={tDashboardScoped('Back')}
            iconName="arrowLeft"
            onClick={() => router.back()}
          />
        </Grid>
      </Grid>

      <Grid container justifyContent="space-around">
        <Grid item xs={6}>
          <Typography variant="h2">{tScoped('Inbox')}</Typography>
        </Grid>
        <Grid item xs={6} container justifyContent="flex-end">
          <CustomButton
            loading={fetchMailBtnLoading}
            label
            labelText={tScoped('Reload')}
            onClick={() => getMailListBtn()}
            icon
            iconName="reload"
          />
        </Grid>
      </Grid>

      <Box>
        {filteredList.map((msg) => (
          <MessageRow
            key={msg.communicationId}
            preposition={myEmail === msg.recipient.email ? 'From' : 'To'}
            sender={
              msg.sender
                ? msg.sender
                : { email: '', firstName: '', lastName: '' }
            }
            recipient={msg.recipient}
            topic={msg.subject}
            date={msg.timeStamp.toString()}
            message={msg.body}
            role="Employee"
            read={msg.read}
            id={msg.communicationId}
            isNote={msg.isNote}
            attachment={msg.attachment ?? ''}
            nonAssigned={true}
            onAssign={() => handleAssign(msg.communicationId)}
          />
        ))}
      </Box>
      {totalRecords > paginationLimit ? (
        <Pagination
          count={Math.ceil(totalRecords / paginationLimit)}
          page={page}
          onChange={onPageChangeHandler}
        />
      ) : null}
    </>
  )
}

export default NonAssigned
