import { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'TTMP | Communication',
  description: 'Communication Employee',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return children
}
