'use client'

import { Box, Grid, Typography } from '@mui/material'
import React, { ChangeEvent, useContext, useEffect, useState } from 'react'
import { useParams, useRouter } from 'next/navigation'

import CustomButton from '@/components/Buttons/CustomButton'
import SwitchButton from '@/components/Buttons/SwitchButton'
import axiosInstance from '@/services/axiosInstance'
import { History } from '@prisma/client'
import HistoryTableRow from '@/components/TableRows/HistoryRow'
import { historyActionReferences, paginationLimit } from '@/utils/constants'
import Pagination from '@/components/Pagination'
import { convertArrayOfObjectsToCSV } from '@/utils/arrayToCsv'
import { useScopedI18n } from '../../../../../locales/client'
import { UserContext } from '@/contexts/userContext'

const History = () => {
  const router = useRouter()
  const tScoped = useScopedI18n('history')
  const tDashboardScoped = useScopedI18n('dashboard')
  const params = useParams()
  const [historyList, setHistoryList] = useState<History[] | []>([])
  const [totalRecords, setTotalRecords] = useState<number>(0)
  const personId: number = +params?.personId
  const [page, setPage] = useState<number>(1)
  const [filters, setFilters] = useState<string[]>([])
  const { user } = useContext(UserContext)

  useEffect(() => {
    getHistoryList()
  }, [filters])

  const getHistoryList = async () => {
    const payload: any = {
      personId,
      page,
      filters,
    }

    const response = await axiosInstance.post(`/api/history`, payload)
    setHistoryList(
      response.data.historyList.filter((item: History) => {
        if (
          !(
            ['Candidate', 'Collaborator'].includes(user?.role || '') &&
            item.actionReference === 'Note'
          )
        ) {
          return item
        }
      }),
    )
    setTotalRecords(response.data.totalRecords)
  }

  const onPageChangeHandler = async (
    _: React.ChangeEvent<unknown>,
    value: number,
  ) => {
    setPage(value)
  }

  const handleFilter = (name: string, e: ChangeEvent<HTMLInputElement>) => {
    if (e.target.checked) {
      setFilters((pre) => [...pre, name])
    } else if (!e.target.checked) {
      setFilters((pre) => pre.filter((val) => val !== name))
    }
  }

  const historyCsvHeaders = {
    actionType: 'Action Type',
    actionDetail: 'Action Detail',
    actionReference: 'History Type',
    createdAt: 'Created At',
  }

  const downloadCSV = () => {
    const link = document.createElement('a')
    const payload = historyList?.map((history) => ({
      ...history,
      createdAt: new Date(history.createdAt).toLocaleString(),
    }))

    let csv = convertArrayOfObjectsToCSV(payload, historyCsvHeaders)
    if (csv == null) return

    const filename = 'list-of-history.csv'

    if (!csv.match(/^data:text\/csv/i)) {
      csv = 'data:text/csv;charset=utf-8,' + csv
    }

    link.setAttribute('href', encodeURI(csv))
    link.setAttribute('download', filename)
    link.click()
  }

  return (
    <>
      <Grid container justifyContent="space-between" mb={25}>
        <Grid item display="flex" alignItems="flex-end" gap={10}>
          <Typography variant="h1" mb={0}>
            {tScoped('History')}
          </Typography>
        </Grid>
        <Grid item>
          <CustomButton
            icon
            label
            labelText={tDashboardScoped('Back')}
            iconName="arrowLeft"
            onClick={() => router.back()}
          />
        </Grid>
      </Grid>

      <Grid
        container
        spacing={10}
        mb={25}
        justifyContent="flex-end"
        alignItems="center"
      >
        <Grid item>
          <SwitchButton
            label={tScoped('Messages')}
            name="Messages"
            handleChange={(e) =>
              handleFilter(historyActionReferences.Messages, e)
            }
          />
        </Grid>
        <Grid item>
          <SwitchButton
            label={tScoped('Tasks')}
            name="Tasks"
            handleChange={(e) => handleFilter(historyActionReferences.Tasks, e)}
          />
        </Grid>
        <Grid item>
          <SwitchButton label={tScoped('Actions')} name="Actions" />
        </Grid>
        <Grid item>
          <CustomButton
            icon
            label
            labelText={tScoped('Download as CSV')}
            iconName="download"
            onClick={downloadCSV}
          />
        </Grid>
      </Grid>

      <Box>
        {historyList.length > 0 &&
          historyList?.map((history) => (
            <Box key={history?.historyId} my={5}>
              <HistoryTableRow
                actionType={history?.actionType}
                actionDetail={history?.actionDetail}
                actionReference={history?.actionReference}
                createdAt={history?.createdAt}
              />
            </Box>
          ))}
      </Box>
      {totalRecords > paginationLimit ? (
        <Pagination
          count={Math.ceil(totalRecords / paginationLimit)}
          page={page}
          onChange={onPageChangeHandler}
        />
      ) : null}
    </>
  )
}

export default History
