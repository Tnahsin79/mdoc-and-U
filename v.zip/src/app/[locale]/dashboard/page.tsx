'use client'

import { styled } from '@mui/system'
import { UserContext } from '@/contexts/userContext'
import { useContext, useEffect, useState } from 'react'
import { Grid, Typography } from '@mui/material'
import { protectedFrontendRoutes } from '@/utils/constants/frontend'

import NextLink from 'next/link'
import CustomButton from '@/components/Buttons/CustomButton'

import TasksComponent from '@/components/Tasks'
import { useI18n, useScopedI18n } from '../../../../locales/client'
import getUserRoles from '@/utils/getUserRoles'

const Link = styled(NextLink)({
  flex: 1,
  '&.disabled': {
    pointerEvents: 'none',
    cursor: 'not-allowed',
  },
})
interface IProtectedFrontendRoutes {
  path: string
  disabled: boolean
  label:
    | 'Events'
    | 'Candidates'
    | 'Collaborators'
    | 'Communication'
    | 'Schools'
    | 'Employees'
}

const Employee = () => {
  const { user } = useContext(UserContext)
  const [userName, setUserName] = useState<string>('')
  const t = useI18n()
  const tScoped = useScopedI18n('dashboard')


  const [filteredFrontendRoutes, setFilteredFrontendRoutes] = useState<
    IProtectedFrontendRoutes[]
  >([])


  const userRoles = getUserRoles(user)

  const canSeeEmployeeList = (userRoles: string[]) => {
    return (userRoles.includes('subjectAdmin') || userRoles.includes('departmentLead'))
  }

  const employeeListViewPermission = canSeeEmployeeList(userRoles)

  useEffect(() => {
    setUserName(`${user?.firstName} ${user?.lastName ?? ''}`)
    let filteredRoutes = protectedFrontendRoutes.filter((route) => {
      return employeeListViewPermission || route.path !== '/employees'
    }) as IProtectedFrontendRoutes[]
    setFilteredFrontendRoutes(filteredRoutes)
  }, [])

  return (
    <>
      <Typography variant="h1" mb={10} sx={{ textTransform: 'capitalize' }}>
        {t('hello')} {userName}
      </Typography>

      <Typography variant="h2" mb={10}>
        {tScoped('Overview')}
      </Typography>

      <Grid container spacing={8} mb={50}>
        {filteredFrontendRoutes?.map(
          ({ path, disabled, label }: IProtectedFrontendRoutes) => (
            <Grid item xs={4} md={3} key={path}>
              <Link href={path} className={disabled ? 'disabled' : ''}>
                <CustomButton
                  label={true}
                  labelText={tScoped(label)}
                  icon={true}
                  fullWidth
                  disabled={disabled}
                />
              </Link>
            </Grid>
          ),
        )}
      </Grid>

      <TasksComponent isDashboard={true} />
    </>
  )
}

export default Employee
