'use client'
import { useEffect, useState } from 'react'
import moment from 'moment'
import { Box, Grid, LinearProgress, Typography } from '@mui/material'
import { FormProvider, SubmitHandler, useForm } from 'react-hook-form'
import { AxiosError } from 'axios'
import { useRouter } from 'next/navigation'
import { EventTemplate, List, Rooms } from '@prisma/client'

import Button from '@/components/Buttons/CustomButton'
import CustomCheckbox from '@/components/Buttons/CustomCheckbox'
import { RHFAutocompleteField } from '@/components/DropDown'
import InputField from '@/components/InputField'
import { RHFTextArea } from '@/components/TextArea'
import { validationMessages } from '@/validators/messages'
import SwitchButton from '@/components/Buttons/SwitchButton'
import CustomDatePicker from '@/components/DatePicker'
import AssignRoom from '@/components/AssignRoom'
import axiosInstance from '@/services/axiosInstance'
import { errorMessages } from '@/utils/errorMessages'
import AssignCollaborators from '@/components/AssignCollaborators'
import AssignAttendees from '@/components/AssignAttendess'
import CustomRadioGroup from '@/components/RadioGroup'
import { EVENT_ACCESS_TYPE } from '@/utils/constants/frontend'
import { validators } from '@/validators'
import Toast from '@/components/Toast'
import { IList } from '@/interface/common'
import { ICreateEventPage } from '@/interface/event'
import { berlinHolidays, frontendRoutes } from '@/utils/constants/frontend'
import { useScopedI18n } from '../../../../../locales/client'

interface IModalData {
  type: string
  open: boolean
}

interface IToastData {
  type: 'success' | 'info' | 'warning' | 'error' | undefined
  message: string
}

const CreateEvent = () => {
  const tScoped = useScopedI18n('event')
  const tDashboardScoped = useScopedI18n('dashboard')
  const router = useRouter()
  const [eventDurationGap, setEventDurationGap] = useState<number>(1)
  const [modalData, setModalData] = useState<IModalData>({
    open: false,
    type: '',
  })
  const [templates, setTemplates] = useState<EventTemplate[]>([
    {
      templateId: undefined!,
      templateName: 'No template',
      collaboratorOrigin: null,
      description: '',
      eventDuration: null,
      eventKey: '',
      eventTypeId: null,
      maxParticipants: null,
      minParticipants: null,
      subjectAreaId: null,
      subjectModule: null,
      phaseId: null,
      isActive: true,
    },
  ])
  const [subjectAreas, setSubjectAreas] = useState<IList>([])
  const [eventTypes, setEventTypes] = useState<IList>([])
  const [locations, setLocations] = useState<IList>([])
  const [equipments, setEquipments] = useState<IList>([])
  const [suitableCollaborators, setSuitableCollaborators] = useState<any>([])
  const [suitableRooms, setSuitableRooms] = useState<Rooms[] | []>([])
  const [loading, setLoading] = useState<boolean>(true)
  const [eventStatus, setEventStatus] = useState<IList>([])
  const [eventRepeats, setEventRepeats] = useState<IList>([])
  const [phases, setPhases] = useState<IList>([])
  const [attendees, setAttendees] = useState<any>({})
  const [submitLoading, setSubmitLoading] = useState<boolean>(false)
  const [toastData, setToastData] = useState<IToastData>({
    type: undefined,
    message: '',
  })
  const [roomData, setRoomData] = useState<Rooms[]>()

  const methods = useForm<ICreateEventPage>({
    mode: 'all',
    defaultValues: {
      eventStatus: '',
      equipmentId: [],
      phaseId: undefined,
    },
    shouldFocusError: true,
  })

  const {
    handleSubmit,
    formState: { errors },
    control,
    watch,
    setValue,
    clearErrors,
    setError,
    reset,
  } = methods

  const isEventRepeats = watch('isEventRepeats')
  const startTime = watch('startTime')
  const endTime = watch('endTime')
  const bookedFrom = watch('bookedFrom')
  const bookedTo = watch('bookedTo')
  const eventAccessMethod = watch('eventManner')
  const excludeBerlinHolidays = watch('excludeBerlinHolidays')
  const minParticipants = watch('minParticipants')
  const locationId = watch('locationId')
  const suitableCollaboratorId = watch('suitableCollaboratorId')
  const attendeesId = watch('attendeesId')
  const eventStatusFormValue = watch('eventStatus')
  const templateId = watch('templateId')
  const maxAttendees = watch('maxParticipants')
  const barrierFreeAccess = watch('barrierFreeAccess')
  const equipmentId = watch('equipmentId')
  const suitableRoomId = watch('suitableRoomId')

  const cancelledEventStatusId = eventStatus.filter(
    (item) => item.listValue === 'Cancelled',
  )[0]?.listId

  const selectedTemplate = templates?.filter(
    (template) => template?.templateId === +templateId,
  )[0]

  useEffect(() => {
    const selectedTemplate = templates?.filter(
      (template) => template?.templateId === +templateId,
    )[0]

    if (selectedTemplate?.eventKey) {
      setValue('eventKey', selectedTemplate.eventKey)
    }

    if (selectedTemplate?.subjectAreaId) {
      setValue('subjectAreaId', selectedTemplate.subjectAreaId)
    }
    if (selectedTemplate?.subjectModule) {
      setValue('subjectModule', selectedTemplate.subjectModule)
    }
    if (selectedTemplate?.phaseId) {
      setValue('phaseId', selectedTemplate.phaseId.toString())
    }
    if (selectedTemplate?.eventTypeId) {
      setValue('eventTypeId', selectedTemplate.eventTypeId)
    }
    if (selectedTemplate?.minParticipants) {
      setValue('minParticipants', selectedTemplate.minParticipants)
    }
    if (selectedTemplate?.maxParticipants) {
      setValue('maxParticipants', selectedTemplate.maxParticipants)
    }

    if (selectedTemplate?.description) {
      setValue('description', selectedTemplate.description)
    }

    if (selectedTemplate?.eventDuration) {
      setEventDurationGap(+selectedTemplate.eventDuration)
    }
  }, [templateId])

  useEffect(() => {
    getDropdownItems()
  }, [])

  useEffect(() => {
    setTimeout(() => {
      setToastData({
        type: undefined,
        message: '',
      })
    }, 5000)
  }, [JSON.stringify(toastData)])

  const getAvailabeRooms = async () => {
    const response = await axiosInstance.post('/api/room/is-available', { bookedFrom, bookedTo, startTime, endTime })
    setSuitableRooms(response.data.availableRooms)
  }

  useEffect( () => {
    if(bookedFrom !== undefined && startTime !== undefined && endTime !== undefined) {
      getAvailabeRooms()
    }
  }, [bookedFrom, bookedTo, startTime, endTime])

  const createEventHandler: SubmitHandler<ICreateEventPage> = (payload) => {
    if (payload.eventManner !== 'Online') {
      if (
        !payload.locationId ||
        !payload.equipmentId ||
        !payload.suitableRoomId ||
        !payload.suitableCollaboratorId ||
        !payload.attendeesId
      ) {
        setToastData({
          type: 'error',
          message: 'Please fill out Room, Collaborators and Attendees data',
        })
        return false
      }
    } else {
      if (!payload.suitableCollaboratorId || !payload.attendeesId) {
        setToastData({
          type: 'error',
          message: 'Please fill out Collaborators and Attendees data',
        })
        return false
      }
    }
    setSubmitLoading(true)
    const data = {
      ...payload,
      minParticipants: +payload.minParticipants,
      maxParticipants: +payload.maxParticipants,
      eventStatus: +payload.eventStatus,
      startTime: moment(payload.startTime),
      endTime: moment(payload.endTime),
      phaseId: +payload.phaseId,
      attendeesId: payload.attendeesId,
    }
    delete data?.excludeBerlinHolidays

    data.eventRepeatId = payload?.eventRepeatId ? +payload.eventRepeatId : null
    axiosInstance
      .post('/api/event/create', data)
      .then((response) => {
        if (response.status === 201) {
          setToastData({ type: 'success', message: response.data.message })
          reset({
            templateId: '',
            subjectAreaId: undefined,
            subjectModule: '',
            phaseId: undefined,
            eventTypeId: undefined,
            title: '',
            minParticipants: undefined,
            maxParticipants: undefined,
            lmsLink: '',
            description: '',
            reason: '',
            isEventRepeats: false,
            startTime: undefined,
            endTime: undefined,
            bookedFrom: undefined,
            bookedTo: undefined,
            eventAccessMethod: '',
            accessLink: '',
            eventRepeatId: undefined,
            eventManner: '',
            eventStatus: '',
            equipmentId: [],
            excludeBerlinHolidays: false,
            attendeesId: undefined,
          })
          router.push(frontendRoutes.events.list)
        } else {
          setToastData({
            type: 'error',
            message: errorMessages.DEFAULT_ERROR,
          })
        }
      })
      .catch((error) => {
        setToastData({
          type: 'error',
          message:
            error instanceof AxiosError
              ? error.response?.data?.error
              : errorMessages.DEFAULT_ERROR,
        })
      })
      .finally(() => {
        setSubmitLoading(false)
      })
  }

  const minSelectableTime = startTime
    ? moment(startTime).add(eventDurationGap, 'minutes').toDate()
    : undefined

  const minSelectableDate = bookedFrom
    ? moment(bookedFrom).add(0, 'days').toDate()
    : undefined

  const handleModals = (data: IModalData) => {
    setModalData(data)
  }

  const handleClose = () => {
    setModalData({ type: '', open: false })
  }

  const getDropdownItems = async () => {
    try {
      const payload = {
        listTypes: [
          'subjectArea',
          'eventType',
          'location',
          'equipment',
          'suitableRooms',
          'suitableCollaborators',
          'eventStatus',
          'eventRepeats',
          'phase',
        ],
      }
      const [
        suitableRooms,
        dropdownItemData,
        attendeesData,
        collaboratorsData,
        templateListData,
        roomData,
      ] = await Promise.all([
        axiosInstance.get('/api/room'),
        axiosInstance.post('/api/list', payload),
        axiosInstance.get('/api/event/get-attendees'),
        axiosInstance.get('/api/event/get-collaborators'),
        axiosInstance.post('/api/event/template', {
          all: true,
          isListInEvent: true,
        }),
        axiosInstance.get('/api/room'),
      ])
      setTemplates([...templates, ...templateListData.data.templateList])
      setSubjectAreas(dropdownItemData.data.data.subjectArea)
      setEventTypes(dropdownItemData.data.data.eventType)
      setLocations(dropdownItemData.data.data.location)
      setEquipments(dropdownItemData.data.data.equipment)
      setSuitableRooms(suitableRooms.data.rooms)
      setSuitableCollaborators(collaboratorsData.data)
      setEventStatus(
        dropdownItemData.data.data.eventStatus.filter(
          (item: List) => !['gehalten', 'abgesagt'].includes(item.listValue),
        ),
      )
      setEventRepeats(dropdownItemData.data.data.eventRepeats)
      setPhases(dropdownItemData.data.data.phase)
      setAttendees(attendeesData.data)
      setRoomData(roomData.data.rooms)
    } catch (error: unknown) {
      if (error instanceof Error) {
        setToastData({
          type: 'error',
          message: error?.message || errorMessages.DEFAULT_ERROR,
        })
      }
    } finally {
      setLoading(false)
    }
  }

  function isToday(dateString: Date | undefined) {
    const parsedDate = moment(dateString)
    if (!parsedDate.isValid()) {
      return undefined
    }
    const today = moment()
    if (parsedDate.isSame(today, 'day')) {
      return new Date()
    } else {
      return undefined
    }
  }

  if (loading) {
    return (
      <Box
        sx={{
          position: 'fixed',
          top: 0,
          left: 0,
          width: '100%',
          zIndex: 9999,
        }}
      >
        <LinearProgress />
      </Box>
    )
  }

  return (
    <>
      {toastData.message !== '' ? (
        <Toast message={toastData.message} severity={toastData.type} />
      ) : null}

      <FormProvider {...methods}>
        <AssignRoom
          open={modalData.type === 'room' && modalData.open}
          handleClose={handleClose}
          locations={locations}
          equipments={equipments}
          suitableRooms={suitableRooms}
          roomData={roomData}
          maxAttendees={maxAttendees}
          barrierFreeAccess={barrierFreeAccess}
          locationId={locationId}
          equipmentId={equipmentId}
          suitableRoomId={suitableRoomId}
          clearSuitableRoomId={() => setValue('suitableRoomId', '')}
          loading={loading}
        />

        <AssignCollaborators
          open={modalData.type === 'collaborators' && modalData.open}
          handleClose={handleClose}
          suitableCollaborators={suitableCollaborators}
          phases={phases}
          subjectAreas={subjectAreas}
          attendeesId={attendeesId}
        />

        <AssignAttendees
          open={modalData.type === 'attendees' && modalData.open}
          handleClose={handleClose}
          phases={phases}
          attendees={attendees}
          subjectAreas={subjectAreas}
          suitableCollaboratorId={+suitableCollaboratorId}
        />

        <Box
          component="form"
          onSubmit={handleSubmit(createEventHandler)}
          autoComplete="off"
        >
          <Grid container justifyContent="space-between" mb={25}>
            <Grid item display="flex" alignItems="flex-end" gap={10}>
              <Typography variant="h1" mb={0}>
                {tScoped('Create Event')}
              </Typography>
            </Grid>
            <Grid item>
              <Button
                icon
                label
                labelText={tDashboardScoped('Back')}
                iconName="arrowLeft"
                onClick={() => router.back()}
              />
            </Grid>
          </Grid>

          <Box mb={25}>
            <Grid container spacing={10}>
              <Grid item xs={12} md={6}>
                <RHFAutocompleteField
                  control={control}
                  options={templates?.map((item) => {
                    return {
                      id: item.templateId,
                      label: item.templateName,
                    }
                  })}
                  name="templateId"
                  label={tScoped('Template')}
                />
              </Grid>

              <Grid item xs={12} sm={6}>
                <InputField
                  control={control}
                  name="eventKey"
                  label={tScoped('Event Key')}
                  fullWidth
                  readOnly={!!selectedTemplate?.eventKey}
                />
              </Grid>
            </Grid>
          </Box>

          <Typography variant="h2">{tScoped('General Information')}</Typography>

          <Grid container spacing={10}>
            <Grid item xs={12} sm={6}>
              <RHFAutocompleteField
                control={control}
                options={subjectAreas?.map((item) => {
                  return {
                    id: item.listId,
                    label: item.listValue,
                  }
                })}
                name="subjectAreaId"
                required
                label={tScoped('Subject Area')}
                readOnly={!!selectedTemplate?.subjectAreaId}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <InputField
                control={control}
                name="subjectModule"
                label={tScoped('Subject Module')}
                fullWidth
                rules={{
                  required: {
                    value: true,
                    message: validationMessages.required,
                  },
                }}
                error={!!errors.subjectModule}
                helperText={errors.subjectModule?.message}
                readOnly={!!selectedTemplate?.subjectModule}
              />
            </Grid>
            <Grid
              item
              xs={12}
              md={6}
              justifyContent="center"
              alignItems="center"
            >
              <CustomRadioGroup
                name="phaseId"
                row
                required
                label={tScoped('Phase')}
                control={control}
                readOnly={!!selectedTemplate?.phaseId}
                options={phases?.map((item) => {
                  return {
                    value: item.listId.toString(),
                    label: item.listValue,
                  }
                })}
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <RHFAutocompleteField
                control={control}
                options={eventTypes?.map((item) => {
                  return {
                    id: item.listId,
                    label: item.listValue,
                  }
                })}
                name="eventTypeId"
                required
                label={tScoped('Event Type')}
                readOnly={!!selectedTemplate?.eventTypeId}
              />
            </Grid>

            <Grid item xs={12} md={6}>
              <InputField
                control={control}
                name="title"
                label={tScoped('Event Title')}
                fullWidth
                rules={{
                  required: {
                    value: true,
                    message: validationMessages.required,
                  },
                }}
                error={!!errors.title}
                helperText={errors.title?.message}
              />
            </Grid>
            <Grid item xs={12} md={6}></Grid>
            <Grid item xs={12} md={6}>
              <InputField
                control={control}
                name="minParticipants"
                label={tScoped('Min Attendees')}
                fullWidth
                rules={{
                  required: {
                    value: true,
                    message: validationMessages.required,
                  },
                  pattern: {
                    value: validators.number,
                    message: validationMessages.onlyNumbers,
                  },
                  valueAsNumber: true,
                }}
                error={!!errors.minParticipants}
                helperText={errors.minParticipants?.message}
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <InputField
                control={control}
                name="maxParticipants"
                label={tScoped('Max Attendees')}
                fullWidth
                rules={{
                  required: {
                    value: true,
                    message: validationMessages.required,
                  },
                  pattern: {
                    value: validators.number,
                    message: validationMessages.onlyNumbers,
                  },
                  min: {
                    value: minParticipants,
                    message: tScoped(
                      'This field should be greater than Min Attendees',
                    ),
                  },
                  valueAsNumber: true,
                }}
                error={!!errors.maxParticipants}
                helperText={errors.maxParticipants?.message}
              />
            </Grid>
            <Grid item xs={12}>
              <RHFTextArea
                control={control}
                name="description"
                label={tScoped('Description')}
                readOnly={!!selectedTemplate?.description}
              />
            </Grid>
            <Grid
              item
              xs={12}
              md={6}
              justifyContent="center"
              alignItems="center"
            >
              <CustomRadioGroup
                name="eventManner"
                row
                required
                label={tScoped('Access Method')}
                control={control}
                options={EVENT_ACCESS_TYPE.map((item) => {
                  return {
                    value: item,
                    label: item,
                  }
                })}
              />
            </Grid>
            <Grid
              item
              xs={12}
              md={6}
              justifyContent="center"
              alignItems="center"
            >
              <InputField
                control={control}
                name="accessLink"
                label={tScoped('Access Link')}
                fullWidth
                rules={{
                  required: {
                    value: eventAccessMethod === 'Online' ? true : false,
                    message: validationMessages.required,
                  },
                  pattern: {
                    value: validators.link,
                    message: validationMessages.validLink,
                  },
                }}
                error={!!errors.accessLink}
                helperText={errors.accessLink?.message}
              />
            </Grid>
          </Grid>

          <Box mt={25} mb={15}>
            <Typography variant="h2">{tScoped('Event Status')}</Typography>
            <Grid container spacing={10}>
              <Grid item xs={12}>
                <CustomRadioGroup
                  name="eventStatus"
                  row
                  required
                  label={tScoped('Event Status')}
                  control={control}
                  options={eventStatus?.map((item) => {
                    return {
                      value: item?.listId.toString(),
                      label: item?.listValue,
                    }
                  })}
                />
              </Grid>
              {cancelledEventStatusId === +eventStatusFormValue && (
                <Grid item xs={12}>
                  <RHFTextArea
                    control={control}
                    name="reason"
                    label={tScoped('Reason')}
                    required
                  />
                </Grid>
              )}
            </Grid>
          </Box>

          <Box mt={25} mb={15}>
            <Typography variant="h2">{tScoped('Event Times')}</Typography>
            <Grid container spacing={10}>
              <Grid item xs={6}>
                <CustomDatePicker
                  name="bookedFrom"
                  label={tScoped('Date')}
                  control={control}
                  setValue={setValue}
                  clearErrors={clearErrors}
                  setError={setError}
                  required
                  dateFormat="dd/MM/yyyy"
                  onChange={(e) => {
                    if (isEventRepeats) {
                      setValue(
                        'bookedTo',
                        e ? moment(e).add(0, 'days').toDate() : undefined,
                      )
                    }
                  }}
                />
              </Grid>
              <Grid
                item
                xs={6}
                sx={{
                  display: 'flex',
                  flexDirection: 'column',
                  justifyContent: 'flex-start',
                  alignItems: 'flex-end',
                }}
              >
                <SwitchButton
                  label={tScoped('Event Repeat')}
                  control={control}
                  name="isEventRepeats"
                  handleChange={(e) => {
                    if (!e.target.checked) {
                      setValue('bookedTo', undefined)
                      setValue('eventRepeatId', undefined)
                    }
                  }}
                />
              </Grid>
              <Grid item xs={6}>
                <CustomDatePicker
                  name="startTime"
                  label={tScoped('Start')}
                  control={control}
                  setValue={setValue}
                  clearErrors={clearErrors}
                  setError={setError}
                  required
                  showTimeSelect
                  showTimeSelectOnly
                  timeCaption="Time"
                  dateFormat="h:mm aa"
                  timeIntervals={15}
                  showFromText
                  minSelectableTime={isToday(bookedFrom)}
                  onChange={(e) => {
                    setValue(
                      'endTime',
                      e
                        ? moment(e).add(eventDurationGap, 'minutes').toDate()
                        : undefined,
                    )
                  }}
                />
              </Grid>
              <Grid item xs={6}>
                <CustomDatePicker
                  name="endTime"
                  label={tScoped('End')}
                  control={control}
                  setValue={setValue}
                  clearErrors={clearErrors}
                  setError={setError}
                  required
                  showTimeSelect
                  showTimeSelectOnly
                  timeCaption="Time"
                  dateFormat="h:mm aa"
                  timeIntervals={15}
                  minSelectableTime={minSelectableTime}
                  showUntilText
                />
              </Grid>
            </Grid>
          </Box>

          {isEventRepeats && (
            <>
              <Typography variant="h2">{tScoped('Event Series')}</Typography>

              <Box mb={25}>
                <Grid container spacing={10}>
                  <Grid item xs={6}>
                    <RHFAutocompleteField
                      control={control}
                      options={eventRepeats?.map((item) => ({
                        id: item?.listId.toString(),
                        label: item?.listValue,
                      }))}
                      name="eventRepeatId"
                      required
                      label={tScoped('Event Repeats')}
                    />
                  </Grid>
                </Grid>
              </Box>

              <Box>
                <Grid container spacing={10}>
                  <Grid item xs={6}>
                    <CustomDatePicker
                      name="bookedTo"
                      label={tScoped('End Date')}
                      control={control}
                      setValue={setValue}
                      clearErrors={clearErrors}
                      setError={setError}
                      required
                      minSelectableDate={minSelectableDate}
                      dateFormat="dd/MM/yyyy"
                      excludeDates={
                        excludeBerlinHolidays
                          ? berlinHolidays.map((date) => new Date(date))
                          : []
                      }
                    />
                  </Grid>
                  <Grid item xs={6} alignItems="center">
                    <CustomCheckbox
                      label={tScoped(
                        'Exclude Berlin school holidays and public holidays',
                      )}
                      control={control}
                      name="excludeBerlinHolidays"
                    />
                  </Grid>
                </Grid>
              </Box>
            </>
          )}

          <Grid container spacing={{ xs: '10px', md: '30px' }}>
            {eventAccessMethod !== 'Online' && (
              <Grid item xs={12} sm={6} md={3}>
                <Box>
                  <Typography variant="h2">{tScoped('Rooms')}</Typography>
                  <Button
                    label
                    icon
                    sx={{
                      width: '100%',
                      background: locationId ? '#FBDBD4' : '',
                      '& .MuiButton-endIcon': {
                        marginLeft: 'auto',
                      },
                    }}
                    labelText={tScoped('Assign Rooms')}
                    iconName="plus"
                    onClick={() => handleModals({ type: 'room', open: true })}
                  />
                </Box>
              </Grid>
            )}
            <Grid item xs={12} sm={6} md={3}>
              <Box>
                <Typography variant="h2">{tScoped('Collaborators')}</Typography>
                <Button
                  label
                  icon
                  labelText={tScoped('Assign Collaborators')}
                  iconName="plus"
                  onClick={() =>
                    handleModals({ type: 'collaborators', open: true })
                  }
                  sx={{
                    width: '100%',
                    background: suitableCollaboratorId ? '#FBDBD4' : '',
                    '& .MuiButton-endIcon': {
                      marginLeft: 'auto',
                    },
                  }}
                />
              </Box>
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <Box>
                <Typography variant="h2">{tScoped('Attendees')}</Typography>
                <Button
                  label
                  icon
                  labelText={tScoped('Assign attendees')}
                  iconName="plus"
                  onClick={() =>
                    handleModals({ type: 'attendees', open: true })
                  }
                  sx={{
                    width: '100%',
                    background: attendeesId ? '#FBDBD4' : '',
                    '& .MuiButton-endIcon': {
                      marginLeft: 'auto',
                    },
                  }}
                />
              </Box>
            </Grid>
          </Grid>

          <Box mt={25} mb={30}>
            <Typography variant="h2">{tScoped('Link')}</Typography>
            <Grid container spacing={10}>
              <Grid item xs={6}>
                <InputField
                  control={control}
                  name="lmsLink"
                  label={tScoped('LMS Link')}
                  fullWidth
                  rules={{
                    pattern: {
                      value: validators.link,
                      message: validationMessages.validLink,
                    },
                  }}
                  error={!!errors.lmsLink}
                  helperText={errors.lmsLink?.message}
                />
              </Grid>
            </Grid>
          </Box>

          <Box display="flex" justifyContent="center" mb={30}>
            <Grid container spacing={10} justifyContent="center">
              <Grid item>
                <Button
                  label
                  labelText={tScoped('Discard')}
                  onClick={() => router.push(frontendRoutes.events.list)}
                />
              </Grid>

              <Grid item>
                <Button
                  label
                  labelText={tScoped('Save')}
                  type="submit"
                  variant="contained"
                  loading={submitLoading}
                />
              </Grid>
            </Grid>
          </Box>
        </Box>
      </FormProvider>
    </>
  )
}

export default CreateEvent
