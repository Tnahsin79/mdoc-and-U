'use client'
import CustomButton from '@/components/Buttons/CustomButton'
import SwitchButton from '@/components/Buttons/SwitchButton'
import EventTableRow from '@/components/TableRows/EventTableRow'
import axiosInstance from '@/services/axiosInstance'
import { paginationLimit } from '@/utils/constants/common'
import { frontendRoutes } from '@/utils/constants/frontend'
paginationLimit
import {
  Box,
  Grid,
  InputAdornment,
  Table,
  TableBody,
  TextField,
  Typography,
} from '@mui/material'
import Pagination from '@/components/Pagination'
import { Event } from '@prisma/client'
import moment from 'moment'
import 'moment/locale/de'
import Link from 'next/link'
import React, { ChangeEvent, useEffect, useState } from 'react'
import IconSwitcher from '@/components/Icons'
// import { debounce } from '@/utils/debounce'
import { useScopedI18n } from '../../../../locales/client'
import getUserRoles from '@/utils/getUserRoles'
import { useUser } from '@/contexts/userContext'
import { useRouter } from 'next/navigation'

export interface CategorizedEventsMap {
  [bookedFrom: string]: NewEvent[]
}

export interface NewEvent extends Event {
  phase: {
    listId: number
    listType: string
    listValue: string
    isActive: boolean
  }
  suitableRooms: {
    listId: number
    listType: string
    listValue: string
    isActive: boolean
  }
  location: {
    listId: number
    listType: string
    listValue: string
    isActive: boolean
  }
}

const CandidateList = () => {
  const router = useRouter()
  const tScoped = useScopedI18n('event')
  const tDashboardScoped = useScopedI18n('dashboard')
  const [page, setPage] = useState<number>(1)
  const [totalRecords, setTotalRecords] = useState<number>(0)

  const [futureEvents, setFutureEvent] = useState<boolean>(false)

  const [categorizedByDateEvents, setCategorizedByDateEvents] =
    useState<CategorizedEventsMap>({})

  const [searchText, setSearchText] = useState<string | null>(null)

  const [remainingParticipation, setRemainingParticipation] =
    useState<boolean>(false)

  async function getEventListHandler(search?: string) {
    const response = await axiosInstance.post('/api/event/event-list', {
      page: page,
      search: searchText,
      futureEvents: futureEvents,
      candidateId: user?.personId,
      suitableCollaboratorId: user?.personId,
      remainingParticipation: remainingParticipation,
    })
    const constructedEvents = [...response.data.eventList]
    eventCategorizer(constructedEvents)
    setTotalRecords(response.data.totalRecords)
    return constructedEvents
  }

  useEffect(() => {
    getEventListHandler()
  }, [page, futureEvents, searchText, remainingParticipation])

  const eventCategorizer = (newEvents: NewEvent[]) => {
    const categorizedEventsMap: CategorizedEventsMap = {}
    newEvents.forEach((event) => {
      const eventDate = moment(event.bookedFrom.toString().split('T')[0])
        .locale('de')
        .format('dddd, DD.MM.YYYY')

      if (categorizedEventsMap[`${eventDate}`]) {
        categorizedEventsMap[`${eventDate}`].push(event)
      } else {
        categorizedEventsMap[`${eventDate}`] = [event]
      }
    })
    setCategorizedByDateEvents({ ...categorizedEventsMap })
  }

  const handleFutureEventsToggle = () => {
    setFutureEvent(!futureEvents)
    setPage(1)
  }

  const onPageChangeHandler = async (
    _: React.ChangeEvent<unknown>,
    value: number,
  ) => {
    setPage(value)
  }

  const handleRadioFilter = (
    name: string,
    e: ChangeEvent<HTMLInputElement>,
  ) => {
    const selected = e.target.checked

    if (name === 'remainingParticipation') {
      setRemainingParticipation(selected)
    }
  }

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value
    setSearchText(value)
    setPage(1)
  }

  const user = useUser()

  const userRoles = getUserRoles(user)
  const anyChangePermissionFunction = (userRoles: string[]) => {
    return (
      userRoles.includes('subjectAdmin') ||
      userRoles.includes('subjectSupervision')
    )
  }
  const anyChangePermission: boolean = anyChangePermissionFunction(userRoles)

  return (
    <>
      <Grid container justifyContent="space-between" mb={25}>
        <Grid item display="flex" alignItems="flex-end" gap={10}>
          <Typography variant="h1" mb={0}>
            {tScoped('Events')}
          </Typography>
        </Grid>
        <Grid item>
          <CustomButton
            icon
            label
            labelText={tDashboardScoped('Back')}
            iconName="arrowLeft"
            onClick={() => router.back()}
          />
        </Grid>
      </Grid>
      <Box mb={8}>
        <Grid container spacing={10} justifyContent="flex-end">
          <Grid item sx={{ display: 'flex', alignItems: 'center' }}>
            <Typography>{tScoped('Filter')}</Typography>
          </Grid>
          <Grid
            item
            sx={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            <SwitchButton
              label={tScoped('Only future events')}
              name="onlyFutureEvents"
              handleChange={handleFutureEventsToggle}
            />
          </Grid>
          <Grid
            item
            sx={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            <SwitchButton
              label={tDashboardScoped('Participation Not Completed')}
              name="remainingParticipation"
              handleChange={(e) =>
                handleRadioFilter('remainingParticipation', e)
              }
              checked={remainingParticipation}
            />
          </Grid>

          {anyChangePermission && (
            <>
              <Grid item>
                <Link href={frontendRoutes.events.template}>
                  <CustomButton
                    icon
                    label
                    labelText={tScoped('Event Templates')}
                  />
                </Link>
              </Grid>

              <Grid item>
                <Link href={frontendRoutes.events.create}>
                  <CustomButton
                    icon
                    label
                    labelText={tScoped('New Event')}
                    iconName="plus"
                  />
                </Link>
              </Grid>
            </>
          )}
          <Grid item>
            <TextField
              name="search"
              type="search"
              value={searchText}
              placeholder={tScoped('Search')}
              InputProps={{
                endAdornment: (
                  <InputAdornment
                    position="end"
                    sx={{
                      cursor: 'pointer',
                      background: '#e40422',
                      height: '100%',
                      marginRight: '-14px',
                      maxHeight: '100%',
                      paddingInline: '10px',
                    }}
                  >
                    <IconSwitcher icon={'search'} />
                  </InputAdornment>
                ),
              }}
              onChange={handleSearch}
            />
          </Grid>
        </Grid>
      </Box>
      {Object.keys(categorizedByDateEvents).map((date, index) => (
        <React.Fragment key={index}>
          <Typography variant="h5" sx={{ fontWeight: 700, fontSize: '20px' }}>
            {date}
          </Typography>
          <Table sx={{ marginBottom: '25px' }}>
            <TableBody>
              {categorizedByDateEvents[`${date}`].map((event, index) => (
                <EventTableRow key={index} event={event} phase={event.phase} />
              ))}
            </TableBody>
          </Table>
        </React.Fragment>
      ))}
      {totalRecords > paginationLimit ? (
        <Pagination
          count={Math.ceil(totalRecords / paginationLimit)}
          page={page}
          onChange={onPageChangeHandler}
        />
      ) : null}
    </>
  )
}

export default CandidateList
