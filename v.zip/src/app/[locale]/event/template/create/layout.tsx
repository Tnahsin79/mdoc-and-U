import { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'TTMP | Create Event Template',
  description: 'CreateEvent Template',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return children
}
