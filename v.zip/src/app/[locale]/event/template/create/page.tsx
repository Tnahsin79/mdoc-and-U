'use client'
import { useEffect, useState } from 'react'
import { Box, Grid, LinearProgress, Typography } from '@mui/material'
import { FormProvider, SubmitHandler, useForm } from 'react-hook-form'
import { AxiosError } from 'axios'
import { useRouter } from 'next/navigation'
import { CollaboratorOrigin } from '@prisma/client'

import Button from '@/components/Buttons/CustomButton'
import { RHFAutocompleteField } from '@/components/DropDown'
import InputField from '@/components/InputField'
import { RHFTextArea } from '@/components/TextArea'
import { validationMessages } from '@/validators/messages'
import axiosInstance from '@/services/axiosInstance'
import { errorMessages } from '@/utils/errorMessages'
import CustomRadioGroup from '@/components/RadioGroup'
import { validators } from '@/validators'
import Toast from '@/components/Toast'
import { IList } from '@/interface/common'
import { frontendRoutes } from '@/utils/constants/frontend'
import { ICreateEditEventTemplatePage } from '@/interface/eventTemplate'
import { useScopedI18n } from '../../../../../../locales/client'

interface IToastData {
  type: 'success' | 'info' | 'warning' | 'error' | undefined
  message: string
}

const CreateEventTemplate = () => {
  const tScoped = useScopedI18n('eventTemplate')
  const tDashboardScoped = useScopedI18n('dashboard')
  const router = useRouter()
  const [subjectAreas, setSubjectAreas] = useState<IList>([])
  const [eventTypes, setEventTypes] = useState<IList>([])
  const [loading, setLoading] = useState<boolean>(true)
  const [phases, setPhases] = useState<IList>([])
  const [submitLoading, setSubmitLoading] = useState<boolean>(false)
  const [toastData, setToastData] = useState<IToastData>({
    type: undefined,
    message: '',
  })
  const methods = useForm<ICreateEditEventTemplatePage>({
    mode: 'all',
    defaultValues: {},
    shouldFocusError: true,
  })

  const {
    handleSubmit,
    formState: { errors },
    control,
    watch,
    reset,
    setValue,
  } = methods

  const minParticipants = watch('minParticipants')
  const eventKey = watch('eventKey')
  const subjectArea = watch('subjectAreaId')
  const subjectModule = watch('subjectModule')
  const selectedSubjectAreaLabel =
    subjectAreas.find((item) => item.listId === subjectArea)?.listValue ||
    subjectArea

  useEffect(() => {
    if (!eventKey && !subjectArea && !subjectModule) {
      setValue('templateName', '')
    } else {
      const templateName = `${eventKey} ${
        subjectArea ? selectedSubjectAreaLabel : ''
      } ${subjectModule}`
      setValue('templateName', templateName)
    }
  }, [eventKey, subjectArea, subjectModule])

  useEffect(() => {
    getDropdownItems()
  }, [])

  useEffect(() => {
    setTimeout(() => {
      setToastData({
        type: undefined,
        message: '',
      })
    }, 5000)
  }, [JSON.stringify(toastData)])

  const createTemplateHandler: SubmitHandler<
    ICreateEditEventTemplatePage
  > = async (payload) => {
    setSubmitLoading(true)
    const data = {
      ...payload,
    }

    if (!!payload.phaseId) {
      data.phaseId = +payload.phaseId
    }

    data.maxParticipants = payload.maxParticipants
      ? +payload.maxParticipants
      : 0
    data.minParticipants = payload.minParticipants
      ? +payload.minParticipants
      : 0

    let subjectAreaPayload = payload.subjectAreaId

    if (payload.subjectAreaId && typeof payload.subjectAreaId === 'string') {
      const res = await axiosInstance.post('/api/list/create', {
        listType: 'subjectArea',
        listValue: payload.subjectAreaId,
      })
      subjectAreaPayload = res.data.list.listId
    }

    axiosInstance
      .post('/api/event/template/create', {
        ...data,
        subjectAreaId: subjectAreaPayload,
      })
      .then((response) => {
        if (response.status === 201) {
          setToastData({ type: 'success', message: response.data.message })
          reset({
            subjectAreaId: undefined,
            subjectModule: '',
            phaseId: undefined,
            eventTypeId: undefined,
            templateName: '',
            minParticipants: undefined,
            maxParticipants: undefined,
            description: '',
            collaboratorOrigin: undefined,
          })
          router.push(frontendRoutes.events.template)
        } else {
          setToastData({
            type: 'error',
            message: errorMessages.DEFAULT_ERROR,
          })
        }
      })

      .catch((error) => {
        setToastData({
          type: 'error',
          message:
            error instanceof AxiosError
              ? error.response?.data?.error
              : errorMessages.DEFAULT_ERROR,
        })
      })
      .finally(() => {
        setSubmitLoading(false)
      })
  }

  const getDropdownItems = async () => {
    try {
      const payload = {
        listTypes: ['subjectArea', 'eventType', 'phase'],
      }
      const [dropdownItemData] = await Promise.all([
        axiosInstance.post('/api/list', payload),
      ])
      setSubjectAreas(dropdownItemData.data.data.subjectArea)
      setEventTypes(dropdownItemData.data.data.eventType)
      setPhases(dropdownItemData.data.data.phase)
    } catch (error: unknown) {
      if (error instanceof Error) {
        setToastData({
          type: 'error',
          message: error?.message || errorMessages.DEFAULT_ERROR,
        })
      }
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <Box
        sx={{
          position: 'fixed',
          top: 0,
          left: 0,
          width: '100%',
          zIndex: 9999,
        }}
      >
        <LinearProgress />
      </Box>
    )
  }

  return (
    <>
      {toastData.message !== '' ? (
        <Toast message={toastData.message} severity={toastData.type} />
      ) : null}

      <FormProvider {...methods}>
        <Box
          component="form"
          onSubmit={handleSubmit(createTemplateHandler)}
          autoComplete="off"
        >
          <Grid container justifyContent="space-between" mb={25}>
            <Grid item display="flex" alignItems="flex-end" gap={10}>
              <Typography variant="h1" mb={0}>
                {tScoped('Create Event Template')}
              </Typography>
            </Grid>
            <Grid item>
              <Button
                icon
                label
                labelText={tDashboardScoped('Back')}
                iconName="arrowLeft"
                onClick={() => router.back()}
              />
            </Grid>
          </Grid>

          <Grid container spacing={10}>
            <Grid item xs={12} sm={6}>
              <InputField
                control={control}
                name="templateName"
                label={tScoped('Template Name')}
                readOnly
                fullWidth
              />
            </Grid>

            <Grid item xs={12} sm={6}>
              <InputField
                control={control}
                name="eventKey"
                label={tScoped('Event Key')}
                fullWidth
                rules={{
                  required: {
                    value: true,
                    message: validationMessages.required,
                  },
                }}
                error={!!errors.eventKey}
                helperText={errors.eventKey?.message}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <RHFAutocompleteField
                creatable
                control={control}
                options={subjectAreas?.map((item) => {
                  return {
                    id: item.listId,
                    label: item.listValue,
                  }
                })}
                name="subjectAreaId"
                label={tScoped('Subject Area')}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <InputField
                control={control}
                name="subjectModule"
                label={tScoped('Subject Module')}
                fullWidth
              />
            </Grid>
            <Grid
              item
              xs={12}
              md={6}
              justifyContent="center"
              alignItems="center"
            >
              <CustomRadioGroup
                name="phaseId"
                row
                label={tScoped('Phase')}
                control={control}
                options={phases?.map((item) => {
                  return {
                    value: item.listId.toString(),
                    label: item.listValue,
                  }
                })}
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <RHFAutocompleteField
                control={control}
                options={eventTypes?.map((item) => {
                  return {
                    id: item.listId,
                    label: item.listValue,
                  }
                })}
                name="eventTypeId"
                label={tScoped('Event Type')}
              />
            </Grid>

            <Grid item xs={12} md={6}>
              <InputField
                control={control}
                name="minParticipants"
                label={tScoped('Min Attendees')}
                fullWidth
                rules={{
                  pattern: {
                    value: validators.number,
                    message: validationMessages.onlyNumbers,
                  },
                  valueAsNumber: true,
                }}
                error={!!errors.minParticipants}
                helperText={errors.minParticipants?.message}
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <InputField
                control={control}
                name="maxParticipants"
                label={tScoped('Max Attendees')}
                fullWidth
                rules={{
                  pattern: {
                    value: validators.number,
                    message: validationMessages.onlyNumbers,
                  },
                  min: {
                    value: minParticipants,
                    message: tScoped(
                      'This field should be greater than Min Attendees',
                    ),
                  },
                  valueAsNumber: true,
                }}
                error={!!errors.maxParticipants}
                helperText={errors.maxParticipants?.message}
              />
            </Grid>

            <Grid item xs={12} md={6}>
              <RHFAutocompleteField
                control={control}
                dynamicOptionId
                options={[
                  {
                    id: CollaboratorOrigin.Internal,
                    label: 'Intern',
                  },
                  {
                    id: CollaboratorOrigin.External,
                    label: 'Extern',
                  },
                ]}
                name="collaboratorOrigin"
                label={tScoped('Collaborator origin')}
              />
            </Grid>

            <Grid item xs={12} md={6}>
              <InputField
                control={control}
                name="eventDuration"
                label={tScoped('Duration in minutes')}
                fullWidth
                rules={{
                  pattern: {
                    value: validators.number,
                    message: validationMessages.onlyNumbers,
                  },
                  min: {
                    value: 1,
                    message: tScoped(
                      'This field should be greater than 1 minute.',
                    ),
                  },
                  valueAsNumber: true,
                }}
                error={!!errors.eventDuration}
                helperText={errors.eventDuration?.message}
              />
            </Grid>

            <Grid item xs={12}>
              <RHFTextArea
                control={control}
                name="description"
                label={tScoped('Description')}
              />
            </Grid>
          </Grid>

          <Box display="flex" justifyContent="center" my={30}>
            <Grid container spacing={10} justifyContent="center">
              <Grid item>
                <Button
                  label
                  labelText={tScoped('Discard')}
                  onClick={() => router.push(frontendRoutes.events.template)}
                />
              </Grid>

              <Grid item>
                <Button
                  label
                  labelText={tScoped('Save')}
                  type="submit"
                  variant="contained"
                  loading={submitLoading}
                />
              </Grid>
            </Grid>
          </Box>
        </Box>
      </FormProvider>
    </>
  )
}

export default CreateEventTemplate
