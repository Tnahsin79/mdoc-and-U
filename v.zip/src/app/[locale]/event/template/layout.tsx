import { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'TTMP | Event Template',
  description: 'Event Template Dashboard',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return children
}
