'use client'

import { AxiosError } from 'axios'
import { EventTemplate } from '@prisma/client'
import { useEffect, useState } from 'react'

import {
  Box,
  Grid,
  InputAdornment,
  Table,
  TableBody,
  TableContainer,
  TextField,
  Typography,
} from '@mui/material'
import Link from 'next/link'
import { useRouter } from 'next/navigation'

import Toast from '@/components/Toast'
import Pagination from '@/components/Pagination'
import axiosInstance from '@/services/axiosInstance'
import CustomButton from '@/components/Buttons/CustomButton'
import { frontendRoutes } from '@/utils/constants/frontend'
import IconSwitcher from '@/components/Icons'
import { debounce } from '@/utils/debounce'
import { paginationLimit } from '@/utils/constants/common'
import { errorMessages } from '@/utils/errorMessages'
import EventTemplateTableRow from '@/components/EventTemplateTableRow'
import { useScopedI18n } from '../../../../../locales/client'

const EventTemplates = () => {
  const tScoped = useScopedI18n('eventTemplate')
  const tDashboardScoped = useScopedI18n('dashboard')
  const router = useRouter()
  const [page, setPage] = useState<number>(1)
  const [totalRecords, setTotalRecords] = useState<number>(0)
  const [templateList, setTemplateList] = useState<EventTemplate[]>([])
  const [serverError, setServerError] = useState<string>('')
  const [searchText, setSearchText] = useState<string | null>(null)

  const onPageChangeHandler = async (
    _: React.ChangeEvent<unknown>,
    value: number,
  ) => {
    setPage(value)
  }

  useEffect(() => {
    getTemplateList()
  }, [page])

  const getTemplateList = async (search?: string) => {
    try {
      const response = await axiosInstance.post('/api/event/template', {
        page,
        search,
      })
      setTemplateList(response.data.templateList)
      setTotalRecords(response.data.totalRecords)
    } catch (error) {
      const errorMessage =
        error instanceof AxiosError
          ? error.response?.data?.error
          : errorMessages.DEFAULT_ERROR

      setServerError(errorMessage)
    }
  }

  const debouncedSchoolList = debounce(getTemplateList, 500)

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value
    setSearchText(value)
    debouncedSchoolList(value)
  }

  return (
    <>
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          marginBottom: '25px',
        }}
      >
        <Typography variant="h1">{tScoped('Template Table')}</Typography>

        <CustomButton
          icon
          label
          labelText={tDashboardScoped('Back')}
          iconName="arrowLeft"
          onClick={() => router.back()}
        />
      </Box>

      <Grid container justifyContent="flex-end" gap={10} mb={9.5}>
        <Link href={frontendRoutes.events.templateCreate}>
          <CustomButton
            label={true}
            labelText={tScoped('New Template')}
            icon={true}
            iconName="plus"
          />
        </Link>
        <TextField
          name="search"
          type="search"
          value={searchText}
          placeholder={tScoped('Search')}
          InputProps={{
            endAdornment: (
              <InputAdornment
                position="end"
                sx={{
                  cursor: 'pointer',
                  background: '#e40422',
                  height: '100%',
                  marginRight: '-14px',
                  maxHeight: '100%',
                  paddingInline: '10px',
                }}
              >
                <IconSwitcher icon={'search'} />
              </InputAdornment>
            ),
          }}
          onChange={handleSearch}
        />
      </Grid>

      <TableContainer>
        <Table sx={{ minWidth: '744px', marginBottom: '25px' }}>
          <TableBody>
            {templateList.map((template) => (
              <EventTemplateTableRow
                key={template.templateId}
                template={template}
                onClick={() => {
                  router.push(
                    `${frontendRoutes.events.templateEdit}/${template.templateId}`,
                  )
                }}
              />
            ))}
          </TableBody>
        </Table>
        {totalRecords > paginationLimit ? (
          <Pagination
            count={Math.ceil(totalRecords / paginationLimit)}
            page={page}
            onChange={onPageChangeHandler}
          />
        ) : null}
      </TableContainer>

      {serverError !== '' ? (
        <Toast message={serverError} severity="error" />
      ) : null}
    </>
  )
}

export default EventTemplates
