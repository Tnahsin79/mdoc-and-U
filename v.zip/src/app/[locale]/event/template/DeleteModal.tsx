import React from 'react'
import CustomModal from '@/components/Modal'
import { Box, Grid, Typography } from '@mui/material'

import Button from '@/components/Buttons/CustomButton'
import { useScopedI18n } from '../../../../../locales/client'

interface IDeleteModalProps {
  open: boolean
  onClose: () => void
  onSave: () => void
}

const DeleteModal = ({ open, onClose, onSave }: IDeleteModalProps) => {
  const tScoped = useScopedI18n('eventTemplate')
  return (
    <CustomModal open={open} onClose={onClose}>
      <Typography
        variant="h6"
        component="h2"
        textAlign="center"
        mb={10}
        sx={{ fontWeight: 700, fontSize: '28px', color: '#E40422' }}
      >
        {tScoped('Delete Template')}
      </Typography>

      <Typography variant="subtitle1" textAlign="center">
        {tScoped('Are you sure you want to delete this template?')}
      </Typography>

      <Box>
        <Grid item xs={12} md={6} justifyContent="center" alignItems="center">
          <Grid
            container
            justifyContent="center"
            alignItems="center"
            marginY={10}
            gap={10}
          >
            <Button label labelText="Cancel" onClick={onClose} />

            <Button
              label
              icon
              labelText={tScoped('Save')}
              iconName="save"
              onClick={onSave}
            />
          </Grid>
        </Grid>
      </Box>
    </CustomModal>
  )
}

export default DeleteModal
