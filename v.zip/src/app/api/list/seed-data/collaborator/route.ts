import { NextResponse } from 'next/server'
import { PhaseName, PrismaClient } from '@prisma/client'
import { errorMessages } from '@/utils/errorMessages'
import { successMessages } from '@/utils/successMessages'

const db = new PrismaClient()

const phases: PhaseName[] = ['kickOff', 'firstStep', 'setUp', 'studies']

export async function GET() {
  try {
    const moduleEntries = phases.flatMap((phase) =>
      Array.from({ length: 5 }, (_, i) => ({
        moduleValue: `module${i + 1}`,
        phase,
      })),
    )

    await db.modules.createMany({
      data: moduleEntries,
    })

    const subjectAreaEntries = await createSubjectAreaEntries()
    await db.subjectArea.createMany({
      data: subjectAreaEntries,
    })

    return NextResponse.json(
      { message: successMessages.dataAdded },
      { status: 200 },
    )
  } catch (error) {
    return NextResponse.json(
      { error: errorMessages.DEFAULT_ERROR },
      { status: 500 },
    )
  }
}

async function createSubjectAreaEntries() {
  const modules = await db.modules.findMany()
  return modules.flatMap((module) => [
    { subjectValue: 'Subject1', moduleId: module.moduleId },
    { subjectValue: 'Subject2', moduleId: module.moduleId },
  ])
}
