import { db } from '@/lib/db'
import { errorMessages } from '@/utils/errorMessages'
import { NextResponse } from 'next/server'

export async function POST(req: Request) {
  const { phases } = await req.json()

  const modules = await db.modules.findMany({
    where: {
      phase: {
        in: phases,
      },
    },
  })

  try {
    return NextResponse.json({ data: modules }, { status: 200 })
  } catch (error) {
    return NextResponse.json(
      { error: errorMessages.DEFAULT_ERROR },
      { status: 500 },
    )
  }
}
