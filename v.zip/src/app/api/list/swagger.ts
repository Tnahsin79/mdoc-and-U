/**
 * @swagger
 * /api/list:
 *   post:
 *     tags:
 *       - List
 *     summary: Retrieve and group lists based on the provided list types
 *     description: Fetches and groups lists by list type based on the given list types.
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - listTypes
 *             properties:
 *               listTypes:
 *                 type: array
 *                 description: An array of list types to retrieve and group by.
 *                 items:
 *                   type: string
 *     responses:
 *       200:
 *         description: Lists fetched and grouped successfully.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 data:
 *                   type: object
 *                   additionalProperties:
 *                     type: array
 *                     items:
 *                       $ref: '#/components/schemas/List'
 *       400:
 *         description: Bad request (no data found or other issue).
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 error:
 *                   type: string
 *       500:
 *         description: Server error.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 error:
 *                   type: string
 * components:
 *   schemas:
 *     List:
 *       type: object
 *       properties:
 *         listId:
 *           type: integer
 *         listType:
 *           type: string
 *         listValue:
 *           type: string
 *         isActive:
 *           type: boolean
 */
