import { errorMessages } from '@/utils/errorMessages'
import { List, PrismaClient } from '@prisma/client'
import { NextResponse } from 'next/server'

type GroupedLists = {
  [key: string]: List[]
}
const db = new PrismaClient()

export async function POST(req: Request) {
  const { listTypes } = await req.json()

  if (!listTypes || !Array.isArray(listTypes) || listTypes.length === 0) {
    return NextResponse.json(
      { error: errorMessages.DEFAULT_ERROR },
      { status: 400 },
    )
  }

  try {
    const results = await db.list.findMany({
      where: {
        listType: { in: listTypes },
        isActive: true,
      },
    })

    if (!results || results.length === 0) {
      return NextResponse.json(
        { error: errorMessages.NO_DATA_FOUND },
        { status: 400 },
      )
    }

    const groupedResults: GroupedLists = results.reduce<GroupedLists>(
      (acc, curr) => {
        if (!acc[curr.listType]) {
          acc[curr.listType] = []
        }
        acc[curr.listType].push(curr)
        return acc
      },
      {},
    )

    return NextResponse.json({ data: groupedResults }, { status: 200 })
  } catch (error) {
    return NextResponse.json(
      { error: errorMessages.DEFAULT_ERROR },
      { status: 500 },
    )
  }
}
