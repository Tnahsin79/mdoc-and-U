import { NextResponse } from 'next/server'
import { PrismaClientKnownRequestError } from '@prisma/client/runtime/library'

import { db } from '@/lib/db'
import { errorMessages, prismaErrorCode } from '@/utils/errorMessages'
import { successMessages } from '@/utils/successMessages'

export async function POST(req: Request) {
  try {
    const body: any = await req.json()

    const list = await db.list.create({
      data: {
        listValue: body.listValue,
        listType: body.listType,
        isActive: true,
      },
    })

    return NextResponse.json(
      { message: successMessages.listDataAdded, list: list },
      { status: 201 },
    )
  } catch (error) {
    let errorMessage = errorMessages.DEFAULT_ERROR

    if (
      error instanceof PrismaClientKnownRequestError &&
      error.code === prismaErrorCode.UNIQUE_CONSTRAINT_FAILED
    ) {
      errorMessage = errorMessages.DUPLICATE_EVENT
    }

    return NextResponse.json({ error: errorMessage }, { status: 404 })
  }
}
