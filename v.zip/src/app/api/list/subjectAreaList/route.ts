import { db } from '@/lib/db'
import { errorMessages } from '@/utils/errorMessages'
import { NextResponse } from 'next/server'

export async function POST(req: Request) {
  const { moduleIds } = await req.json()

  const modules = await db.subjectArea.findMany({
    where: {
      moduleId: {
        in: moduleIds,
      },
    },
  })

  try {
    return NextResponse.json({ data: modules }, { status: 200 })
  } catch (error) {
    return NextResponse.json(
      { error: errorMessages.DEFAULT_ERROR },
      { status: 500 },
    )
  }
}
