import { IPersonValues, PersonCreateInput } from '@/interface/person'
import { db } from '@/lib/db'
import { errorMessages } from '@/utils/errorMessages'
import { successMessages } from '@/utils/successMessages'
import { Role } from '@prisma/client'
import bcrypt from 'bcrypt'
import { NextResponse } from 'next/server'
const PersonTypes: Role[] = ['Employee', 'Candidate', 'Collaborator']
const PersonValues: IPersonValues = {
  Employee: {
    email: 'employee@ttmp.com',
    password: 'Qw@12345',
    firstName: 'Employee',
  },
  Collaborator: {
    email: 'collaborator@ttmp.com',
    password: 'Qw@12345',
    firstName: 'Collaborator',
  },
  Candidate: {
    email: 'candidate@ttmp.com',
    password: 'Qw@12345',
    firstName: 'Candidate',
  },
}
export async function GET() {
  try {
    const saltRounds = process.env.HASH_SALT_ROUND || 10
    for (const person of PersonTypes) {
      const hashedPassword = await bcrypt.hash(
        PersonValues[person].password,
        +saltRounds,
      )
      const personCreateInput: PersonCreateInput = {
        email: PersonValues[person].email,
        firstName: PersonValues[person].firstName,
        password: hashedPassword,
        role: person,
        subjectAdmin: person === 'Employee',
        subjectSupervision: person === 'Employee',
        householdAdmin: person === 'Employee',
        departmentLead: person === 'Employee',
      }
      const newPerson = await db.person.create({
        data: personCreateInput,
      })
      if (newPerson.role === Role.Collaborator) {
        await db.collaborator.create({
          data: {
            personId: newPerson.personId,
            dob: new Date(),
            pinNo: 1001,
          },
        })
      }
    }
    return NextResponse.json(
      { message: successMessages.dataAdded },
      { status: 200 },
    )
  } catch (error) {
    return NextResponse.json(
      { error: errorMessages.DEFAULT_ERROR },
      { status: 500 },
    )
  }
}
