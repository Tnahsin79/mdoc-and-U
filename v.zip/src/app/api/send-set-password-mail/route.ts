import { NextResponse } from 'next/server'
import sendEmail from '@/utils/sendMail'
import crypto from 'crypto'
import { db } from '@/lib/db'
import { successMessages } from '@/utils/successMessages'
import { actionTemplate } from '@/utils/EmailTemplates/action'

interface ISendMailProps {
  email: string
}

export async function POST(req: Request) {
  try {
    const { email }: ISendMailProps = await req.json()

    const token = crypto.randomBytes(32).toString('hex')
    const tokenExpiration = new Date()
    tokenExpiration.setDate(tokenExpiration.getDate() + 3)

    await db.person.update({
      where: { email },
      data: {
        resetPasswordToken: token,
        resetPasswordTokenExpiry: tokenExpiration,
      },
    })

    const url =
      process.env.NODE_ENV !== 'production'
        ? `${process.env.APP_DEV_URL}/reset-password?token=${token}`
        : `${process.env.APP_PROD_URL}/reset-password?token=${token}`
    const text = successMessages.clickOnThisLinkToSetYourPassword
    const html = actionTemplate(url, text)    

    await sendEmail({
      to: email,
      subject: successMessages.verifyYourAccount,
      html: html,
    })

    return NextResponse.json(
      { message: successMessages.sendMailSuccess },
      { status: 201 },
    )
  } catch (error) {
    console.error('Error sending email:', error)
    return NextResponse.json(
      { error: (error as Error)?.message },
      { status: 400 },
    )
  }
}
