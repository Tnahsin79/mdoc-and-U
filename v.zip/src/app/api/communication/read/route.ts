import { db } from '@/lib/db'
import { errorMessages, prismaErrorCode } from '@/utils/errorMessages'
import { PrismaClientKnownRequestError } from '@prisma/client/runtime/library'
import { NextResponse } from 'next/server'

export async function POST(req: Request) {
  try {
    const body = await req.json()

    const { id } = body

    await db.communication.update({
      where: {
        communicationId: id,
      },
      data: {
        read: true,
      },
    })

    return NextResponse.json(
      {
        message: 'Successfully Updated the Mail As Read',
      },
      { status: 200 },
    )
  } catch (error) {
    console.error(error)

    if (
      error instanceof PrismaClientKnownRequestError &&
      error.code === prismaErrorCode.UNIQUE_CONSTRAINT_FAILED
    ) {
      return NextResponse.json({ error: 'Duplicate Data' }, { status: 400 })
    }

    return NextResponse.json(
      { error: errorMessages.DEFAULT_ERROR },
      { status: 500 },
    )
  }
}
