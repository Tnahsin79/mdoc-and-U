import { db } from '@/lib/db'
import { errorMessages, prismaErrorCode } from '@/utils/errorMessages'
import { successMessages } from '@/utils/successMessages'
import { PrismaClientKnownRequestError } from '@prisma/client/runtime/library'
import { NextResponse } from 'next/server'

export async function POST(req: Request) {
  try {
    const body = await req.json()

    const { personId, communicationId } = body

    await db.communication.update({
      where: {
        communicationId: communicationId,
      },
      data: {
        isNotAssigned: false,
        recipientId: personId,
      },
    })

    return NextResponse.json(
      {
        message: successMessages.successfullyAssignedTheMail,
      },
      { status: 200 },
    )
  } catch (error) {
    console.error(error)

    if (
      error instanceof PrismaClientKnownRequestError &&
      error.code === prismaErrorCode.UNIQUE_CONSTRAINT_FAILED
    ) {
      return NextResponse.json(
        { error: errorMessages.DUPLICATE_DATA },
        { status: 400 },
      )
    }

    return NextResponse.json(
      { error: errorMessages.DEFAULT_ERROR },
      { status: 500 },
    )
  }
}
