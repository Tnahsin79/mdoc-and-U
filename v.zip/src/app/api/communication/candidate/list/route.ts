import { db } from '@/lib/db'
import { cookies } from 'next/headers'
import { NextResponse } from 'next/server'
import { paginationLimit } from '@/utils/constants'
import { errorMessages, prismaErrorCode } from '@/utils/errorMessages'
import { sortByTimeStampDescending } from '@/utils/sortByTimeStampDescending'
import { PrismaClientKnownRequestError } from '@prisma/client/runtime/library'

import jwt, { JwtPayload } from 'jsonwebtoken'
import { IMailData } from '@/interface/communication'

export async function POST(req: Request) {
  try {
    const limit = paginationLimit
    const body = await req.json()
    const page = body?.page || 1
    const offset = (page - 1) * limit
    const searchQuery = body?.search || ''

    const { checked } = body

    let searchCondition = {}

    const searchFields = ['firstName', 'lastName', 'email']

    if (searchQuery) {
      const words = searchQuery.split(/\s+/)
      searchCondition = {
        AND: words.map((word: string) => ({
          OR: searchFields.flatMap((field: string) => [
            {
              OR: [
                {
                  sender: { [field]: { contains: word, mode: 'insensitive' } },
                },
                {
                  recipient: {
                    [field]: { contains: word, mode: 'insensitive' },
                  },
                },
                {
                  subject: { contains: word, mode: 'insensitive' },
                },
                {
                  body: { contains: word, mode: 'insensitive' },
                },
              ],
            },
          ]),
        })),
      }
    }

    const cookieStore = cookies()
    const accessToken = cookieStore.get('accessToken')?.value
    if (!accessToken) {
      throw new Error(errorMessages.INVALID_TOKEN)
    }

    const JWTSecretKey: string = process.env.JWT_SECRET_KEY || 'ttmp-project'
    const decodedAccessToken: string | JwtPayload = jwt.verify(
      accessToken,
      JWTSecretKey,
    )

    if (
      !(typeof decodedAccessToken === 'object' && 'email' in decodedAccessToken)
    ) {
      throw new Error(errorMessages.INVALID_TOKEN)
    } else {
      const person = await db.person.findFirst({
        where: {
          email: decodedAccessToken.email.toLowerCase(),
        },
      })

      if (!person) {
        throw new Error('Not Authorized')
      }

      let whereConditions: {
        senderId?: number
        recipientId?: number
      }[] = [
        {
          senderId: person.personId,
        },
        {
          recipientId: person.personId,
        },
      ]

      if (checked.sent && !checked.received) {
        whereConditions = [
          {
            senderId: person.personId,
          },
        ]
      }

      if (checked.received && !checked.sent) {
        whereConditions = [
          {
            recipientId: person.personId,
          },
        ]
      }

      if (checked.sent && checked.received) {
        whereConditions = [
          {
            senderId: person.personId,
          },
          {
            recipientId: person.personId,
          },
        ]
      }

      let mailList = await db.communication.findMany({
        where: {
          OR: whereConditions.length > 0 ? whereConditions : undefined,
          AND: checked.new
            ? {
                read: false,
                recipientId: person.personId,
                ...searchCondition,
                isNote: false,
              }
            : { ...searchCondition, isNote: false },
        },
        include: {
          sender: {
            select: {
              email: true,
              firstName: true,
              lastName: true,
            },
          },
          recipient: {
            select: {
              email: true,
              firstName: true,
              lastName: true,
            },
          },
          buddyRequest: {
            select: {
              availableId: true,
              howFarDistance: true,
              howManyToSupport: true,
              schoolTypesIds: true,
              isSubmitted: true,
            }
          },
        },
      })

      const totalRecords = await db.communication.count({
        where: {
          OR: whereConditions.length > 0 ? whereConditions : undefined,
          AND: checked.new
            ? {
                read: false,
                recipientId: person.personId,
                ...searchCondition,
                isNote: false,
              }
            : { ...searchCondition, isNote: false },
        },
      })

      mailList = sortByTimeStampDescending(mailList)

      const paginatedMailList = mailList.slice(offset, offset + limit)

      return NextResponse.json(
        {
          message: 'Successfully Fetched Communication Mails',
          mailList: paginatedMailList,
          ownMail: person.email,
          totalRecords,
        },
        { status: 200 },
      )
    }
  } catch (error) {
    console.error(error)

    if (
      error instanceof PrismaClientKnownRequestError &&
      error.code === prismaErrorCode.UNIQUE_CONSTRAINT_FAILED
    ) {
      return NextResponse.json({ error: 'Duplicate Data' }, { status: 400 })
    }

    return NextResponse.json(
      { error: errorMessages.DEFAULT_ERROR },
      { status: 500 },
    )
  }
}
