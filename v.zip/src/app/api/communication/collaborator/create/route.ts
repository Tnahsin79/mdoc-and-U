import { db } from '@/lib/db'
import { actionTemplate } from '@/utils/EmailTemplates/action'
import { errorMessages, prismaErrorCode } from '@/utils/errorMessages'
import { notificationMessages } from '@/utils/notificationMessages'
import sendEmail from '@/utils/sendMail'
import { Person } from '@prisma/client'
import { PrismaClientKnownRequestError } from '@prisma/client/runtime/library'
import jwt, { JwtPayload } from 'jsonwebtoken'
import { cookies } from 'next/headers'
import { NextResponse } from 'next/server'

interface transactionFunctionProps {
  data: Comm
  person: Person
}

function createCommunicationCollaborator({
  data,
  person,
}: transactionFunctionProps) {
  return db.$transaction(async (tx) => {
    for (let i = 0; i < data.recipients.length; i++) {
      const currDate = new Date()
      const communicationData = {
        subject: data.subject,
        body: data.body,
        recipientId: +data.recipients[i],
        senderId: person.personId,
        isNote: data.isNote,
        timeStamp: currDate,
        attachment: data.attachment,
      }
      await tx.communication.create({
        data: { ...communicationData },
      })
      const recipient = await tx.person.findFirst({
        where: {
          personId: +data.recipients[i],
        },
        select: {
          email: true,
        },
      })

      const url =
        process.env.APP_DEV_URL ?? process.env.APP_PROD_URL ?? 'localhost:3000'
      const text = notificationMessages.MessageReceivedMessage
      const html = actionTemplate(url, text)

      if (recipient) {
        await sendEmail({
          to: recipient.email,
          subject: `${notificationMessages.MessageReceivedTopic}`,
          html: html,
        })
      }
      await tx.history.create({
        data: {
          personId: +data.recipients[i],
          actionType: data.isNote ? 'New Note' : 'New Message',
          actionDetail: data.body,
          actionReference: 'Message',
        },
      })
    }
  })
}

export async function POST(req: Request) {
  try {
    const body = await req.json()

    const { ...data }: Comm = body

    const cookieStore = cookies()
    const accessToken = cookieStore.get('accessToken')?.value
    if (!accessToken) {
      throw new Error(errorMessages.INVALID_TOKEN)
    }

    const JWTSecretKey: string = process.env.JWT_SECRET_KEY || 'ttmp-project'
    const decodedAccessToken: string | JwtPayload = jwt.verify(
      accessToken,
      JWTSecretKey,
    )

    if (
      !(typeof decodedAccessToken === 'object' && 'email' in decodedAccessToken)
    ) {
      throw new Error(errorMessages.INVALID_TOKEN)
    } else {
      const person = await db.person.findFirst({
        where: {
          email: decodedAccessToken.email.toLowerCase(),
        },
      })

      if (!person) {
        throw new Error('Not Authorized')
      }

      await createCommunicationCollaborator({ data, person })

      return NextResponse.json(
        { message: 'Successfully Created Communication Mails' },
        { status: 200 },
      )
    }
  } catch (error) {
    console.error(error)

    if (
      error instanceof PrismaClientKnownRequestError &&
      error.code === prismaErrorCode.UNIQUE_CONSTRAINT_FAILED
    ) {
      return NextResponse.json({ error: 'Duplicate Data' }, { status: 400 })
    }

    return NextResponse.json(
      { error: errorMessages.DEFAULT_ERROR },
      { status: 500 },
    )
  }
}

interface Comm {
  recipients: number[]
  senderId: number
  body: string
  isNote: boolean
  subject: string
  attachment?: string
}
