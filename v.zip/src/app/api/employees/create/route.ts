import { cookies } from 'next/headers'
import jwt, { JwtPayload } from 'jsonwebtoken'
import { successMessages } from '../../../../utils/successMessages'
import { NextResponse } from 'next/server'
import { errorMessages } from '../../../../utils/errorMessages'
import { db } from '../../../../lib/db'
import { Role } from '@prisma/client'
import sendEmail from '@/utils/sendMail'
import crypto from 'crypto'
import { getUserDetails } from '@/utils/authUtils'
import { setYourPassword } from '@/utils/EmailTemplates/setYourPassword'

interface Employee {
  firstName: string
  lastName: string
  email: string
  subjectAdmin: boolean
  subjectSupervision: boolean
  householdAdmin: boolean
  departmentLead: boolean
}

function createEmployee({ body }: any) {
  return db.$transaction(async (tx) => {
    const {
      firstName,
      lastName,
      email,
      subjectAdmin,
      subjectSupervision,
      householdAdmin,
      departmentLead,
    }: Employee = body

    const cookieStore = cookies()
    const accessToken = cookieStore.get('accessToken')?.value
    if (!accessToken) {
      throw new Error(errorMessages.INVALID_TOKEN)
    }

    const JWTSecretKey: string = process.env.JWT_SECRET_KEY || 'ttmp-project'
    const decodedAccessToken: string | JwtPayload = jwt.verify(
      accessToken,
      JWTSecretKey,
    )

    if (
      !(typeof decodedAccessToken === 'object' && 'email' in decodedAccessToken)
    ) {
      throw new Error(errorMessages.INVALID_TOKEN)
    }

    const person = await tx.person.findFirst({
      where: {
        email: decodedAccessToken.email.toLowerCase(),
      },
    })

    if (!person) {
      throw new Error('Not Authorized')
    }

    const token = crypto.randomBytes(32).toString('hex')
    const tokenExpiration = new Date()
    tokenExpiration.setDate(tokenExpiration.getDate() + 3)

    await tx.person.create({
      data: {
        firstName,
        lastName,
        email: email.toLowerCase(),
        role: Role.Employee,
        subjectAdmin: subjectAdmin,
        subjectSupervision: subjectSupervision,
        householdAdmin: householdAdmin,
        departmentLead: departmentLead,
        resetPasswordToken: token,
        resetPasswordTokenExpiry: tokenExpiration,
      },
    })

    const url =
      process.env.NODE_ENV !== 'production'
        ? `${process.env.APP_DEV_URL}/reset-password?token=${token}`
        : `${process.env.APP_PROD_URL}/reset-password?token=${token}`

    const html = setYourPassword(url)    
    await sendEmail({
      to: email,
      subject: 'Verify your account',
      html: html,
    })
  })
}

export async function POST(req: Request) {
  try {
    const userDetails = getUserDetails()
    const createEmployeepermission = userDetails.roles.includes('subjectAdmin')

    if (!createEmployeepermission) {
      throw new Error('Not Authorized')
    }

    const body = await req.json()

    await createEmployee({ body })

    return NextResponse.json(
      {  message: successMessages.success },
      { status: 201 },
    )
  } catch (error) {
    let errorMessage = errorMessages.DEFAULT_ERROR

    if (error instanceof Error) {
      errorMessage = error.message
    }

    return NextResponse.json({ error: errorMessage }, { status: 400 })
  }
}
