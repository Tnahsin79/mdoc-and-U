import { db } from '@/lib/db'
import { getUserDetails } from '@/utils/authUtils'
import { paginationLimit } from '@/utils/constants'
import { errorMessages } from '@/utils/errorMessages'
import { successMessages } from '@/utils/successMessages'
import { Person, Role } from '@prisma/client'
import { NextResponse } from 'next/server'

export async function POST(req: Request) {
  try {

    const userDetails = getUserDetails()
    const canViewEmployeeList = userDetails.roles.includes('subjectAdmin') || userDetails.roles.includes('departmentLead')

    if(!canViewEmployeeList){
      throw new Error('Not Authorized')
    }

    const limit = paginationLimit
    const body = await req.json()
    const page = body?.page || 1
    const offset = (page - 1) * limit

    const totalRecords = await db.person.count({
      where: {
        role: Role.Employee,
      },
    })
    const response = await db.person.findMany({
      take: limit,
      skip: offset,
      where: {
        role: Role.Employee,
      },
      select: {
        firstName: true,
        lastName: true,
        email: true,
        personId: true,
      },
      orderBy: {
          lastName: 'asc', // or 'desc' for descending order
      },
    })
    return NextResponse.json(
      {
        message: successMessages.success,
        employeeList: response,
        totalRecords: totalRecords,
      },
      { status: 200 },
    )
  } catch (error) {
    console.log(error, 'Error')
    let errorMessage = errorMessages.DEFAULT_ERROR

    if (error instanceof Error) {
      errorMessage = error.message
    }

    return NextResponse.json({ error: error }, { status: 404 })
  }
}
