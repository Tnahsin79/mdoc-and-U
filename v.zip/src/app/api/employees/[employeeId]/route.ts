import { cookies } from 'next/headers'
import jwt, { JwtPayload } from 'jsonwebtoken'
import { successMessages } from '../../../../utils/successMessages'
import { NextResponse } from 'next/server'
import { errorMessages } from '../../../../utils/errorMessages'
import { db } from '../../../../lib/db'
import { getUserDetails } from '@/utils/authUtils'
interface contextProps {
  params: {
    employeeId: number
  }
}

interface Employee {
  firstName: string
  lastName: string
  email: string
  subjectAdmin: boolean
  subjectSupervision: boolean
  householdAdmin: boolean
  departmentLead: boolean
}

export async function GET(req: Request, context: contextProps) {
  try {
    const userDetails = getUserDetails()
    const canViewEmployeeList =
      userDetails.roles.includes('subjectAdmin') ||
      userDetails.roles.includes('departmentLead')

    if (!canViewEmployeeList) {
      throw new Error('Not Authorized')
    }

    const { params } = context
    const { employeeId } = params

    if (!employeeId) {
      throw new Error(errorMessages.NO_DATA_FOUND)
    }

    let person = undefined

    const cookieStore = cookies()
    const accessToken = cookieStore.get('accessToken')?.value
    if (!accessToken) {
      throw new Error(errorMessages.INVALID_TOKEN)
    }

    const JWTSecretKey: string = process.env.JWT_SECRET_KEY || 'ttmp-project'
    const decodedAccessToken: string | JwtPayload = jwt.verify(
      accessToken,
      JWTSecretKey,
    )

    if (
      !(typeof decodedAccessToken === 'object' && 'email' in decodedAccessToken)
    ) {
      throw new Error(errorMessages.INVALID_TOKEN)
    } else {
      person = await db.person.findFirst({
        where: {
          email: decodedAccessToken.email.toLowerCase(),
        },
      })

      if (!person) {
        throw new Error('Not Authorized')
      }
    }

    const employee = await db.person.findUnique({
      where: {
        personId: +employeeId,
      },
      select: {
        firstName: true,
        lastName: true,
        email: true,
        subjectAdmin: true,
        subjectSupervision: true,
        householdAdmin: true,
        departmentLead: true,
      },
    })

    return NextResponse.json(
      { employee: employee, message: successMessages.success },
      { status: 200 },
    )
  } catch (error) {
    let errorMessage = errorMessages.DEFAULT_ERROR

    if (error instanceof Error) {
      errorMessage = error.message
    }

    return NextResponse.json({ error: errorMessage }, { status: 404 })
  }
}

function updateEmployee({ body, context }: any) {
  return db.$transaction(async (tx) => {
    const {
      firstName,
      lastName,
      email,
      subjectAdmin,
      subjectSupervision,
      householdAdmin,
      departmentLead,
    } = body

    const { params } = context
    const { employeeId } = params

    if (!employeeId) {
      throw new Error(errorMessages.NO_DATA_FOUND)
    }

    let person = undefined

    const cookieStore = cookies()
    const accessToken = cookieStore.get('accessToken')?.value
    if (!accessToken) {
      throw new Error(errorMessages.INVALID_TOKEN)
    }

    const JWTSecretKey: string = process.env.JWT_SECRET_KEY || 'ttmp-project'
    const decodedAccessToken: string | JwtPayload = jwt.verify(
      accessToken,
      JWTSecretKey,
    )

    if (
      !(typeof decodedAccessToken === 'object' && 'email' in decodedAccessToken)
    ) {
      throw new Error(errorMessages.INVALID_TOKEN)
    } else {
      person = await db.person.findFirst({
        where: {
          email: decodedAccessToken.email.toLowerCase(),
        },
      })

      if (!person) {
        throw new Error('Not Authorized')
      }
    }

    await db.person.update({
      where: {
        email: email,
      },
      data: {
        firstName: firstName,
        lastName: lastName,
        subjectAdmin: subjectAdmin,
        subjectSupervision: subjectSupervision,
        householdAdmin: householdAdmin,
        departmentLead: departmentLead,
      },
    })
  })
}

export async function POST(req: Request, context: contextProps) {
  try {
    const userDetails = getUserDetails()
    const editEmployeePermission = userDetails.roles.includes('subjectAdmin')

    if (!editEmployeePermission) {
      throw new Error('Not Authorized')
    }

    const body = await req.json()

    await updateEmployee({ body, context })

    return NextResponse.json(
      { message: successMessages.success },
      { status: 200 },
    )
  } catch (error) {
    let errorMessage = errorMessages.DEFAULT_ERROR

    if (error instanceof Error) {
      errorMessage = error.message
    }

    return NextResponse.json({ error: errorMessage }, { status: 404 })
  }
}
