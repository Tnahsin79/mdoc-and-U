import { cookies } from 'next/headers'
import jwt, { JwtPayload } from 'jsonwebtoken'
import { successMessages } from '../../../../../utils/successMessages'
import { NextResponse } from 'next/server'
import { errorMessages } from '../../../../../utils/errorMessages'
import { db } from '../../../../../lib/db'
import { getUserDetails } from '@/utils/authUtils'
interface contextProps {
  params: {
    personId: number
  }
}

function deleteEmployee({ context }: any) {
  return db.$transaction(async (tx) => {
    const { params } = context
    const { personId } = params

    if (!personId) {
      throw new Error(errorMessages.NO_DATA_FOUND)
    }

    let person = undefined

    const cookieStore = cookies()
    const accessToken = cookieStore.get('accessToken')?.value
    if (!accessToken) {
      throw new Error(errorMessages.INVALID_TOKEN)
    }

    const JWTSecretKey: string = process.env.JWT_SECRET_KEY || 'ttmp-project'
    const decodedAccessToken: string | JwtPayload = jwt.verify(
      accessToken,
      JWTSecretKey,
    )

    if (
      !(typeof decodedAccessToken === 'object' && 'email' in decodedAccessToken)
    ) {
      throw new Error(errorMessages.INVALID_TOKEN)
    } else {
      person = await db.person.findFirst({
        where: {
          email: decodedAccessToken.email.toLowerCase(),
        },
      })

      if (!person) {
        throw new Error('Not Authorized')
      }
    }

    await db.person.delete({
      where: {
        personId: +personId,
      },
    })
  })
}

export async function POST(req: Request, context: contextProps) {
  try {
    const userDetails = getUserDetails()
    const deleteEmployeePermission = userDetails.roles.includes('subjectAdmin')

    if (!deleteEmployeePermission) {
      throw new Error('Not Authorized')
    }

    await deleteEmployee({context})

    return NextResponse.json(
      { message: successMessages.success },
      { status: 200 },
    )
  } catch (error) {
    console.log(error, 'Error')
    let errorMessage = errorMessages.DEFAULT_ERROR

    if (error instanceof Error) {
      errorMessage = error.message
    }

    return NextResponse.json({ error: errorMessage }, { status: 404 })
  }
}
