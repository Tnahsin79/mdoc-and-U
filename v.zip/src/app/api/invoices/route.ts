import { db } from '@/lib/db'
import { cookies } from 'next/headers'
import { NextResponse } from 'next/server'
import { Bill, Role } from '@prisma/client'
import jwt, { JwtPayload } from 'jsonwebtoken'
import { errorMessages } from '@/utils/errorMessages'
import { successMessages } from '@/utils/successMessages'
import { paginationLimit } from '@/utils/constants/common'

interface jsonwebtoken extends JwtPayload {
  email: string
  role: Role
}

const getEmailAddress = () => {
  const cookieStore = cookies()
  const accessToken = cookieStore.get('accessToken')?.value

  if (!accessToken) {
    throw new Error(errorMessages.INVALID_TOKEN)
  }

  const JWTSecretKey: string = process.env.JWT_SECRET_KEY || 'ttmp-project'

  const decodedAccessToken = jwt.verify(
    accessToken,
    JWTSecretKey,
  ) as jsonwebtoken

  return {
    email: decodedAccessToken.email.toLowerCase(),
    role: decodedAccessToken.role,
  }
}

export async function GET(req: Request) {
  const page: number = +req.url.split('?')[1] || 1
  const offset = (page - 1) * paginationLimit

  try {
    const user = getEmailAddress()

    const person = await db.person.findFirst({ where: { email: user.email } })

    let whereCondition = {}

    if (person?.role === Role.Employee) {
      whereCondition = {}
    } else {
      whereCondition = {
        collaborator: {
          person: {
            email: user.email,
          },
        },
      }
    }

    const response = (await db.bill.findMany({
      take: paginationLimit,
      skip: offset,
      where: whereCondition,
      include: {
        ...(user.role === Role.Employee && {
          collaborator: {
            select: {
              person: {
                select: {
                  firstName: true,
                  lastName: true,
                },
              },
            },
          },
        }),
      },
    })) as unknown as {
      collaborator: {
        person: {
          firstName: string
          lastName: string
        }
      }
      attachment: unknown
      amount: string
    }[]

    const cookieStore = cookies()
    const accessToken = cookieStore.get('accessToken')?.value
    if (!accessToken) {
      throw new Error(errorMessages.INVALID_TOKEN)
    }

    for (const bill of response) {
      if (bill.attachment) {
        bill.attachment = {
          url: '',
          fileName: bill.attachment,
        }
      }
    }

    const totalRecords = await db.bill.count()

    return NextResponse.json(
      {
        bills: response,
        totalRecords,
        isEmployee: user.role === Role.Employee,
        message: successMessages.success,
      },
      { status: 200 },
    )
  } catch (error) {
    const errorMessage =
      error instanceof Error ? error.message : errorMessages.DEFAULT_ERROR

    return NextResponse.json({ error: errorMessage }, { status: 401 })
  }
}

export async function POST(req: Request) {
  try {
    const user = getEmailAddress()
    const body = (await req.json()) as Omit<Bill, 'billId'>

    const person = await db.person.findUnique({
      where: {
        email: user.email,
        role: Role.Collaborator,
      },
      include: {
        collaborator: {
          select: {
            collaboratorId: true,
          },
        },
      },
    })

    if (!person || !person.collaborator?.collaboratorId) {
      throw new Error(errorMessages.UNAUTHORIZED)
    }

    body.collaboratorId = person.collaborator?.collaboratorId
    const response = await db.bill.create({
      data: body,
    })

    return NextResponse.json(
      {
        bills: { ...response, amount: response.amount.toString() },
        message: successMessages.success,
      },
      { status: 200 },
    )
  } catch (error) {
    const errorMessage =
      error instanceof Error ? error.message : errorMessages.DEFAULT_ERROR

    return NextResponse.json({ error: errorMessage }, { status: 400 })
  }
}
