import { db } from '@/lib/db'
import { NextResponse } from 'next/server'
import { errorMessages } from '@/utils/errorMessages'
import { successMessages } from '@/utils/successMessages'
import { paginationLimit } from '@/utils/constants/common'
import { getUserDetails } from '@/utils/authUtils'
import sendEmail from '@/utils/sendMail'
import { notificationMessages } from '@/utils/notificationMessages'
import { actionTemplate } from '@/utils/EmailTemplates/action'

interface contextProps {
  params: {
    page: string
  }
}

export async function POST(req: Request, context: contextProps) {
  try {
    const userDetails = getUserDetails()
    const matchMentorPermission =
      userDetails.roles.includes('subjectAdmin') ||
      userDetails.roles.includes('subjectSupervision')

    if (!matchMentorPermission) {
      throw new Error('Not Authorized')
    }

    const { params } = context
    const { page } = params
    const limit = paginationLimit
    const offset = (+page - 1) * limit

    const candidates = await db.candidate.findMany({
      take: limit,
      skip: offset,
      select: {
        candidateId: true,
        mentorId: true,
        comments: true,
        school: {
          select: {
            postalCode: true,
          },
        },
      },
      where: {
        isActive: true,
      },
    })

    const collaborators = await db.collaborator.findMany({
      where: {
        person: {
          isActive: true,
        },
        primaryAddress: true,
      },
      select: {
        collaboratorId: true,
        primaryAddress: true,
        postalCode: true,
        person: {
          select: {
            email: true,
          },
        },
      },
    })

    for (const candidate of candidates) {
      for (const collaborator of collaborators) {
        if (
          candidate.school?.postalCode &&
          collaborator.postalCode &&
          candidate.school.postalCode === collaborator.postalCode
        ) {
          const candidateUpdated = await db.candidate.update({
            where: { candidateId: candidate.candidateId },
            data: { mentorId: collaborator.collaboratorId },
            select: {
              person: {
                select: {
                  email: true,
                },
              },
            },
          })

          const url =
            process.env.APP_DEV_URL ??
            process.env.APP_PROD_URL ??
            'localhost:3000'

          const toCandidate = candidateUpdated.person.email
          const subjectForCandidate = notificationMessages.MatchedWithMentor
          const textForCandidate = notificationMessages.MatchedWithMentorText
          const htmlForCandidate = actionTemplate(url, textForCandidate)

          await sendEmail({
            to: toCandidate,
            subject: subjectForCandidate,
            html: htmlForCandidate,
          })

          const toCollaborator = collaborator.person.email
          const subjectForCollaborator = notificationMessages.MatchedWithCandidate
          const textForCollaborator = notificationMessages.MatchedWithCandidateText
          const htmlForCollaborator = actionTemplate(url, textForCollaborator)

          await sendEmail({
            to: toCollaborator,
            subject: subjectForCollaborator,
            html: htmlForCollaborator,
          })
        }
      }
    }

    const response = await db.candidate.findMany({
      take: limit,
      skip: offset,
      select: {
        candidateId: true,
        person: {
          select: {
            firstName: true,
            lastName: true,
            postalCode: true,
          },
        },
        school: {
          select: {
            city: true,
            postalCode: true,
          },
        },
        city: true,
        mentor: {
          select: {
            postalCode: true,
            city: true,
            person: {
              select: {
                firstName: true,
                lastName: true,
              },
            },
          },
        },
      },
      where: {
        person: {
          isActive: true,
        },
      },
    })

    // const responseAdjustedForBigInt = response.map((candidate) => {
    //   return {
    //     ...candidate,
    //     postalCode: candidate.person.postalCode?.toString(),
    //   }
    // })

    return NextResponse.json(
      {
        candidateList: response,
        message: successMessages.success,
      },
      { status: 200 },
    )
  } catch (error) {
    let errorMessage = errorMessages.DEFAULT_ERROR

    if (error instanceof Error) {
      errorMessage = error.message
    }

    return NextResponse.json({ error: errorMessage }, { status: 404 })
  }
}
