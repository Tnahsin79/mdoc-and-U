import { db } from '@/lib/db'
import { actionTemplate } from '@/utils/EmailTemplates/action'
import { getUserDetails } from '@/utils/authUtils'
import { paginationLimit } from '@/utils/constants/common'
import { errorMessages } from '@/utils/errorMessages'
import { notificationMessages } from '@/utils/notificationMessages'
import sendEmail from '@/utils/sendMail'
import { successMessages } from '@/utils/successMessages'
import { NextResponse } from 'next/server'

export async function POST(req: Request) {
  try {
    const userDetails = getUserDetails()
    const matchMentorPermission =
      userDetails.roles.includes('subjectAdmin') ||
      userDetails.roles.includes('subjectSupervision')

    if (!matchMentorPermission) {
      throw new Error('Not Authorized')
    }

    const limit = paginationLimit
    const body = await req.json()
    const page = body?.page || 1
    const offset = (page - 1) * limit
    const totalRecords = await db.candidate.count()

    const response = await db.candidate.findMany({
      take: limit,
      skip: offset,
      select: {
        school: {
          select: {
            city: true,
            postalCode: true,
          },
        },
        person: {
          select: {
            firstName: true,
            lastName: true,
            postalCode: true,
          },
        },
        city: true,
        candidateId: true,
        mentor: {
          select: {
            postalCode: true,
            city: true,
            person: {
              select: {
                firstName: true,
                lastName: true,
              },
            },
          },
        },
      },
      where: {
        person: {
          isActive: true,
        },
      },
    })

    const responseAdjustedForBigInt = response.map((candidate) => {
      return {
        ...candidate,
        postalCode: candidate.person.postalCode?.toString(),
      }
    })

    return NextResponse.json(
      {
        message: successMessages.success,
        candidateList: responseAdjustedForBigInt,
        totalRecords: totalRecords,
      },
      { status: 200 },
    )
  } catch (error) {
    let errorMessage = errorMessages.DEFAULT_ERROR

    if (error instanceof Error) {
      errorMessage = error.message
    }

    return NextResponse.json({ error: errorMessage }, { status: 404 })
  }
}

export async function PUT(req: Request) {
  try {
    const userDetails = getUserDetails()
    const matchMentorPermission =
      userDetails.roles.includes('subjectAdmin') ||
      userDetails.roles.includes('subjectSupervision')

    if (!matchMentorPermission) {
      throw new Error('Not Authorized')
    }

    const candidateMentorMap = await req.json()

    for (const candidateId in candidateMentorMap) {
      const mentorId = candidateMentorMap[candidateId]

      const candidateUpdated = await db.candidate.update({
        data: { mentorId: mentorId },
        where: { candidateId: +candidateId },
        select: {
          person: {
            select: {
              email: true,
            },
          },
        },
      })

      const collaborator = await db.collaborator.findFirst({
        where: {
          collaboratorId: +mentorId,
        },
        select: {
          person: {
            select: {
              email: true,
            },
          },
        },
      })

      if (collaborator) {
        const toCandidate = candidateUpdated.person.email
        const subjectForCandidate = notificationMessages.MatchedWithMentor
        const textForCandidate = notificationMessages.MatchedWithMentorText

        const url =
        process.env.APP_DEV_URL ?? process.env.APP_PROD_URL ?? 'localhost:3000'
        const htmlForCandidate = actionTemplate(url, textForCandidate)

        await sendEmail({
          to: toCandidate,
          subject: subjectForCandidate,
          html: htmlForCandidate,
        })

        const toCollaborator = collaborator.person.email
        const subjectForCollaborator = notificationMessages.MatchedWithCandidate
        const textForCollaborator = notificationMessages.MatchedWithCandidateText
        const htmlForCollaborator = actionTemplate(url, textForCollaborator)

        await sendEmail({
          to: toCollaborator,
          subject: subjectForCollaborator,
          html: htmlForCollaborator,
        })
      }
    }

    return NextResponse.json(
      {
        message: successMessages.success,
      },
      { status: 200 },
    )
  } catch (error) {
    let errorMessage = errorMessages.DEFAULT_ERROR

    if (error instanceof Error) {
      errorMessage = error.message
    }

    return NextResponse.json({ error: errorMessage }, { status: 404 })
  }
}
