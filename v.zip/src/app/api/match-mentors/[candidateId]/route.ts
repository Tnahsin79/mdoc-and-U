import { db } from '@/lib/db'
import { NextResponse } from 'next/server'
import { errorMessages } from '@/utils/errorMessages'
import { successMessages } from '@/utils/successMessages'
import { getUserDetails } from '@/utils/authUtils'

interface contextProps {
  params: {
    candidateId: string
  }
}

function flattenObject(obj: any) {
  const result: any = {}

  for (const key in obj) {
    if (obj.hasOwnProperty(key)) {
      if (typeof obj[key] === 'object') {
        Object.assign(result, flattenObject(obj[key]))
      } else if (typeof obj[key] === 'bigint') {
        result[key] = obj[key].toString()
      } else {
        result[key] = obj[key]
      }
    }
  }

  return result
}

const selectQuery = {
  collaboratorId: true,
  person: {
    select: {
      firstName: true,
      lastName: true,
    },
  },
  firstRecognisedSubjectId: true,
  streetAndHouseNo: true,
  city: true,
  postalCode: true,
  school: {
    select: {
      school: {
        select: {
          BSN: true,
        },
      },
    },
  },
  subjectArea: {
    select: {
      subjectArea: {
        select: {
          subjectValue: true,
        },
      },
    },
  },
}

export async function GET(req: Request, context: contextProps) {
  try {

    const userDetails = getUserDetails()
    const matchMentorPermission = userDetails.roles.includes('subjectAdmin') || userDetails.roles.includes('subjectSupervision')

    if(!matchMentorPermission){
      throw new Error('Not Authorized')
    }

    const { params } = context
    const { candidateId } = params

    if (!candidateId) {
      throw new Error(errorMessages.NO_DATA_FOUND)
    }

    const candidate = await db.candidate.findFirst({
      where: {
        candidateId: +candidateId,
      },
      select: {
        school: {
          select: {
            postalCode: true,
          },
        },
      },
    })

    let mentors = await db.collaborator.findMany({
      where: {
        person: {
          isActive: true,
        },
        postalCode: candidate?.school?.postalCode?.toString(),
      },
      select: selectQuery,
      take: 10,
    })
    if (mentors.length < 10) {
      const remainingMentors = await db.collaborator.findMany({
        select: selectQuery,
        where: {
          person: {
            isActive: true,
          },
          collaboratorId: {
            notIn: mentors.map((mentor) => mentor.collaboratorId),
          },
        },
        take: 10 - mentors.length,
        skip: Math.floor(
          Math.random() * Math.max(0,((await db.collaborator.count()) - 10)),
        ),
      })
      mentors = mentors.concat(remainingMentors)
    }

    if (!mentors) {
      throw new Error(errorMessages.NO_DATA_FOUND)
    }

    const mentorsWithSubject = []
    for (const mentor of mentors) {
      if (mentor.firstRecognisedSubjectId) {
        const res = await db.list.findUnique({
          where: {
            listId: mentor.firstRecognisedSubjectId,
          },
        })
        mentorsWithSubject.push({ ...mentor, subject: res?.listValue })
      }
    }

    return NextResponse.json(
      {
        mentorsList: mentorsWithSubject.map((mentor) => flattenObject(mentor)),
        message: successMessages.success,
      },
      { status: 200 },
    )
  } catch (error) {
    let errorMessage = errorMessages.DEFAULT_ERROR

    if (error instanceof Error) {
      errorMessage = error.message
    }

    return NextResponse.json({ error: errorMessage }, { status: 404 })
  }
}
