import { db } from '@/lib/db'
import { NextResponse } from 'next/server'
import { successMessages } from '@/utils/successMessages'
import { errorMessages, prismaErrorCode } from '@/utils/errorMessages'
import { PrismaClientKnownRequestError } from '@prisma/client/runtime/library'
import { deletedCollaboratorAccount } from '@/utils/constants/backend'
import { getUserDetails } from '@/utils/authUtils'

interface contextProps {
  params: {
    collaboratorId: number
  }
}

export async function POST(req: Request, context: contextProps) {
  try {
    const { params } = context
    const { collaboratorId } = params

    const userDetails = getUserDetails()
    const deletePermission = userDetails.roles.includes('subjectAdmin')

    if(!deletePermission){
      throw new Error('Not Authorized')
    }

    db.$transaction(async (tx) => {
      const person = await tx.person.findFirst({
        where: {
          collaborator: {
            collaboratorId: +collaboratorId,
          },
        },
      })

      let fallbackAccount = await db.collaborator.findFirst({
        where: {
          person: {
            email: deletedCollaboratorAccount,
          },
        },
      })

      if (!fallbackAccount) {
        const fallbackPersonAccount = await tx.person.create({
          data: {
            email: deletedCollaboratorAccount,
            firstName: 'Gelöschter Mitwirkender',
          },
        })

        fallbackAccount = await tx.collaborator.create({
          data: {
            personId: fallbackPersonAccount.personId,
            dob: new Date(),
            pinNo: 0,
          },
        })
      }

      await tx.collaboratorSchool.deleteMany({
        where: {
          collaboratorId: +collaboratorId,
        },
      })

      await tx.collaboratorSchoolRole.deleteMany({
        where: {
          collaboratorId: +collaboratorId,
        },
      })

      await tx.collaboratorModules.deleteMany({
        where: {
          collaboratorId: +collaboratorId,
        },
      })

      await tx.collaboratorSubjectArea.deleteMany({
        where: {
          collaboratorId: +collaboratorId,
        },
      })

      await tx.task.updateMany({
        where: {
          creatorId: person?.personId,
        },
        data: {
          creatorId: fallbackAccount.personId,
        },
      })

      await tx.task.updateMany({
        where: {
          assigneeId: person?.personId,
        },
        data: {
          assigneeId: fallbackAccount.personId,
        },
      })

      await tx.communication.updateMany({
        where: {
          senderId: person?.personId,
        },
        data: {
          senderId: fallbackAccount.personId,
        },
      })

      await tx.communication.updateMany({
        where: {
          recipientId: person?.personId,
        },
        data: {
          recipientId: fallbackAccount.personId,
        },
      })

      const { personId } = await tx.collaborator.delete({
        where: {
          collaboratorId: +collaboratorId,
        },
      })

      await tx.person.delete({
        where: {
          personId: personId,
        },
      })
    })

    return NextResponse.json(
      { message: successMessages.collaboratorDeletedSuccess },
      { status: 200 },
    )
  } catch (error) {
    let errorMessage = errorMessages.DEFAULT_ERROR

    if (
      error instanceof PrismaClientKnownRequestError &&
      error.code === prismaErrorCode.RECORD_NOT_FOUND
    ) {
      errorMessage = errorMessages.RECORD_NOT_FOUND
    } else if (error instanceof Error) {
      errorMessage = error.message
    }

    return NextResponse.json({ error: errorMessage }, { status: 404 })
  }
}
