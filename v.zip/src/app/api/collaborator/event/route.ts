import { db } from '@/lib/db'
import { NextResponse } from 'next/server'
import { successMessages } from '@/utils/successMessages'
import { errorMessages, prismaErrorCode } from '@/utils/errorMessages'
import { PrismaClientKnownRequestError } from '@prisma/client/runtime/library'
import { historyMessages } from '@/utils/historyMessages'

interface EventCollaboratorInput {
  eventId: number
  collaboratorId: number
  isConfirmed: boolean
}

export async function POST(req: Request) {
  try {
    const body: EventCollaboratorInput = await req.json()
    const { eventId, collaboratorId, isConfirmed } = body

    await db.eventCollaborator.create({
      data: {
        eventId,
        collaboratorId,
        isConfirmed,
      },
    })

    await db.history.create({
      data: {
        actionType: historyMessages.cancelledAttendance,
        actionDetail: historyMessages.collaboratorCancelledAttendance,
        actionReference: historyMessages.attendance,
        personId: collaboratorId,
      },
    })

    return NextResponse.json(
      { message: successMessages.requestSuccess },
      { status: 201 },
    )
  } catch (error) {
    let errorMessage = errorMessages.DEFAULT_ERROR

    if (
      error instanceof PrismaClientKnownRequestError &&
      error.code === prismaErrorCode.UNIQUE_CONSTRAINT_FAILED
    ) {
      errorMessage = errorMessages.DUPLICATE_EVENT_PARTICIPATION_REQUEST
    }

    return NextResponse.json({ error: errorMessage }, { status: 404 })
  }
}

export async function PUT(req: Request) {
  try {
    const body: EventCollaboratorInput = await req.json()
    const { eventId, collaboratorId, isConfirmed } = body

    await db.eventCollaborator.update({
      where: {
        eventId_collaboratorId: {
          eventId,
          collaboratorId,
        },
      },
      data: {
        isConfirmed,
      },
    })

    return NextResponse.json(
      { message: successMessages.requestSuccess },
      { status: 201 },
    )
  } catch (error) {
    let errorMessage = errorMessages.DEFAULT_ERROR

    if (
      error instanceof PrismaClientKnownRequestError &&
      error.code === prismaErrorCode.UNIQUE_CONSTRAINT_FAILED
    ) {
      errorMessage = errorMessages.DUPLICATE_EVENT
    }

    return NextResponse.json({ error: errorMessage }, { status: 404 })
  }
}

export async function DELETE(req: Request) {
  try {
    const url = new URL(req.url)

    const eventId = url.searchParams.get('eventId')
    const collaboratorId = url.searchParams.get('collaboratorId')

    if (!eventId || !collaboratorId) {
      throw new Error(errorMessages.NO_DATA_FOUND)
    }

    await db.eventCollaborator.delete({
      where: {
        eventId_collaboratorId: {
          eventId: +eventId,
          collaboratorId: +collaboratorId,
        },
      },
    })

    return NextResponse.json(
      { message: successMessages.requestSuccess },
      { status: 201 },
    )
  } catch (error) {
    let errorMessage = errorMessages.DEFAULT_ERROR

    if (
      error instanceof PrismaClientKnownRequestError &&
      error.code === prismaErrorCode.UNIQUE_CONSTRAINT_FAILED
    ) {
      errorMessage = errorMessages.DUPLICATE_EVENT
    }

    return NextResponse.json({ error: errorMessage }, { status: 404 })
  }
}

export async function GET(req: Request) {
  try {
    const url = new URL(req.url)

    const eventId = url.searchParams.get('eventId')
    const collaboratorId = url.searchParams.get('collaboratorId')

    if (!eventId || !collaboratorId) {
      throw new Error(errorMessages.NO_DATA_FOUND)
    }

    const eventCollaborator = await db.eventCollaborator.findUnique({
      where: {
        eventId_collaboratorId: {
          eventId: +eventId,
          collaboratorId: +collaboratorId,
        },
      },
    })

    return NextResponse.json(
      { message: successMessages.requestSuccess, data: eventCollaborator },
      { status: 201 },
    )
  } catch (error) {
    let errorMessage = errorMessages.DEFAULT_ERROR

    if (
      error instanceof PrismaClientKnownRequestError &&
      error.code === prismaErrorCode.UNIQUE_CONSTRAINT_FAILED
    ) {
      errorMessage = errorMessages.DUPLICATE_EVENT
    }

    return NextResponse.json({ error: errorMessage }, { status: 404 })
  }
}
