import { db } from '@/lib/db'
import { NextResponse } from 'next/server'
import { PIN_NO_CONSTRAINTS } from '@/utils/constants/common'
import { successMessages } from '@/utils/successMessages'
import { errorMessages, prismaErrorCode } from '@/utils/errorMessages'
import { Collaborator, Person, Role } from '@prisma/client'
import { PrismaClientKnownRequestError } from '@prisma/client/runtime/library'
import { getUserDetails } from '@/utils/authUtils'

interface contextProps {
  params: {
    collaboratorId: string
    profileStatus: boolean
  }
  queryParams: {
    matchMentor: boolean
  }
}

function flattenObject(obj: any, parentKey = '') {
  const result: any = {}

  for (const key in obj) {
    if (obj.hasOwnProperty(key)) {
      const newKey =
        parentKey && parentKey !== 'person' ? `${parentKey}_${key}` : key

      if (
        typeof obj[key] === 'object' &&
        !Array.isArray(obj[key]) &&
        !(obj[key] instanceof Date)
      ) {
        Object.assign(result, flattenObject(obj[key], key))
      } else if (typeof obj[key] === 'bigint') {
        result[newKey] = obj[key].toString()
      } else {
        result[newKey] = obj[key]
      }
    }
  }

  return result
}

function validateFields(data: InterfaceCollaboratorData) {
  if (!data.dob) {
    throw new Error('Date of Birth is required')
  }

  if (!data.email) {
    throw new Error('Email is required')
  }

  if (!data.firstName || !data.lastName) {
    throw new Error('First Name and Last name are required')
  }

  if (!data.phoneNumber) {
    throw new Error('Phone number is required')
  }

  if (data.workedAsATeacher) {
    if (
      !data.collaboratorSchoolRole ||
      !data.federalStateId ||
      !data.school ||
      !data.schoolTypeId ||
      !data.firstRecognisedSubjectId
    ) {
      if (data.stillTeaching) {
        if (data.lastActiveTeachingYear) {
          throw new Error(
            'Last Active Year is not required if Still Active as a teacher',
          )
        }
      }

      if (data.lastActiveTeachingYear) {
        if (data.stillTeaching) {
          throw new Error(
            'Still Active as a teacher is not required if Last Active Year teaching year is specified',
          )
        }
      }
      throw new Error(
        'School Service Details is Required if Worked as a Teacher Before',
      )
    }
  }
}

export async function GET(req: Request, context: contextProps) {
  try {
    const { params } = context
    const { collaboratorId } = params

    const { searchParams } = new URL(req.url)
    const matchMentor = searchParams.get('matchMentor')
      ? searchParams.get('matchMentor')
      : 'false'

    const profileStatus = searchParams.get('profileStatus')
      ? searchParams.get('profileStatus')
      : 'false'

    if (!collaboratorId) {
      throw new Error(errorMessages.NO_DATA_FOUND)
    }

    const userDetails = getUserDetails()
    const bankDetailsPermission =
      userDetails.roles.includes('householdAdmin') ||
      userDetails.role === Role.Collaborator

    if (profileStatus == 'true') {
      const collaborator = await db.collaborator.findUnique({
        where: {
          collaboratorId: +collaboratorId,
        },
        select: {
          profileCompleted: true,
        },
      })

      if (!collaborator) {
        throw new Error(errorMessages.NO_DATA_FOUND)
      }

      return NextResponse.json(
        {
          collaborator: collaborator,
        },
        { status: 200 },
      )
    }

    if (matchMentor === 'false') {
      const collaborator = await db.collaborator.findUnique({
        where: {
          collaboratorId: +collaboratorId,
        },
        select: {
          invited: true,
          phasePreferenceId: true,
          pinNo: true,
          companyName: true,
          workedAsATeacher: true,
          federalStateId: true,
          schoolTypeId: true,
          stillTeaching: true,
          lastActiveTeachingYear: true,
          firstRecognisedSubjectId: true,
          secondRecognisedSubjectId: true,
          thirdRecognisedSubjectId: true,
          retired: true,
          retiredSince: true,
          dob: true,
          accountHolder: bankDetailsPermission,
          bic: bankDetailsPermission,
          iban: bankDetailsPermission,
          businessTypeId: true,
          person: true,
          attachment: true,
          modules: {
            select: {
              moduleId: true,
            },
          },
          subjectArea: {
            select: {
              subjectAreaId: true,
            },
          },
          school: {
            select: {
              schoolId: true,
            },
          },
          collaboratorSchoolRole: {
            select: {
              roleId: true,
            },
          },
          jobTitle: true,
          otherQualification: true,
          firstActivityField: true,
          secondActivityField: true,
          thirdActivityField: true,
          contactPointWithSchool: true,
          streetAndHouseNo: true,
          city: true,
          postalCode: true,
        },
      })

      if (!collaborator) {
        throw new Error(errorMessages.NO_DATA_FOUND)
      }

      return NextResponse.json(
        {
          collaborator: {
            ...flattenObject(collaborator),
            attachment: collaborator.attachment
              ? {
                  url: '',
                  fileName: collaborator.attachment,
                }
              : null,
          },
        },
        { status: 200 },
      )
    } else if (matchMentor === 'true') {
      const collaborator = await db.collaborator.findUnique({
        where: {
          collaboratorId: +collaboratorId,
        },
        select: {
          collaboratorId: true,
          streetAndHouseNo: true,
          city: true,
          postalCode: true,
          person: {
            select: {
              firstName: true,
              lastName: true,
              postalCode: true,
            },
          },
        },
      })

      if (!collaborator) {
        throw new Error(errorMessages.NO_DATA_FOUND)
      }

      return NextResponse.json(
        {
          collaborator: collaborator,
        },
        { status: 200 },
      )
    }
  } catch (error) {
    let errorMessage = errorMessages.DEFAULT_ERROR

    if (error instanceof Error) {
      errorMessage = error.message
    }

    return NextResponse.json({ error: errorMessage }, { status: 404 })
  }
}

interface InterfaceCollaboratorData
  extends Collaborator,
    Omit<Person, 'postalCode'> {
  modules: number[]
  subjectArea: number[]
  school: number[]
  collaboratorSchoolRole: number[]
}

interface transactionFunctionProps {
  body: InterfaceCollaboratorData
  collaboratorId: string
}

function updateCollaboratorTransaction({
  body,
  collaboratorId,
}: transactionFunctionProps) {
  return db.$transaction(async (tx) => {
    const collaborator = await tx.collaborator.findFirst({
      where: {
        collaboratorId: +collaboratorId,
      },
      select: {
        invited: true,
      },
    })

    if (collaborator?.invited) {
      await tx.collaboratorModules.deleteMany({
        where: {
          collaborator: {
            collaboratorId: +collaboratorId,
          },
        },
      })

      body.modules.map(async (module) => {
        await tx.collaboratorModules.createMany({
          data: {
            collaboratorId: +collaboratorId,
            moduleId: module,
          },
        })
      })
    }

    if (collaborator?.invited) {
      await tx.collaboratorSubjectArea.deleteMany({
        where: {
          collaborator: {
            collaboratorId: +collaboratorId,
          },
        },
      })

      body.subjectArea.map(async (subjectArea) => {
        await tx.collaboratorSubjectArea.createMany({
          data: {
            collaboratorId: +collaboratorId,
            subjectAreaId: subjectArea,
          },
        })
      })
    }

    await tx.collaboratorSchool.deleteMany({
      where: {
        collaborator: {
          collaboratorId: +collaboratorId,
        },
      },
    })

    body.school.map(async (schoolId) => {
      await tx.collaboratorSchool.createMany({
        data: {
          collaboratorId: +collaboratorId,
          schoolId: +schoolId,
        },
      })
    })

    await tx.collaboratorSchoolRole.deleteMany({
      where: {
        collaborator: {
          collaboratorId: +collaboratorId,
        },
      },
    })

    body.collaboratorSchoolRole.map(async (roleId) => {
      await tx.collaboratorSchoolRole.createMany({
        data: {
          collaboratorId: +collaboratorId,
          roleId: +roleId,
        },
      })
    })

    await tx.history.create({
      data: {
        actionType: 'Master Data changed',
        actionDetail: 'Master Data changed',
        actionReference: 'Data',
        personId: body.personId,
      },
    })

    if (
      body.pinNo < PIN_NO_CONSTRAINTS.min ||
      body.pinNo > PIN_NO_CONSTRAINTS.max
    ) {
      throw new Error(errorMessages.INVALID_PIN_NO)
    }

    const updatedCollaborator = await tx.collaborator.update({
      where: {
        collaboratorId: +collaboratorId,
      },
      data: {
        dob: body.dob ? new Date(body.dob) : null,
        pinNo: +body.pinNo,
        workedAsATeacher: body.workedAsATeacher,
        federalStateId: body.federalStateId,
        schoolTypeId: body.schoolTypeId,
        firstRecognisedSubjectId: body.firstRecognisedSubjectId,
        secondRecognisedSubjectId: body.secondRecognisedSubjectId,
        thirdRecognisedSubjectId: body.thirdRecognisedSubjectId,
        lastActiveTeachingYear:
          body.lastActiveTeachingYear && new Date(body.lastActiveTeachingYear),
        stillTeaching: body.stillTeaching,
        jobTitle: body.jobTitle,
        firstActivityField: body.firstActivityField,
        secondActivityField: body.secondActivityField,
        thirdActivityField: body.thirdActivityField,
        retiredSince: body.retiredSince,
        retired: body.retired,
        contactPointWithSchool: body.contactPointWithSchool,
        otherQualification: body.otherQualification,
        ...(collaborator?.invited && { companyName: body.companyName }),
        ...(collaborator?.invited && { accountHolder: body.accountHolder }),
        ...(collaborator?.invited && { iban: body.iban }),
        ...(collaborator?.invited && { bic: body.bic }),
        ...(collaborator?.invited && { taxId: body.taxId }),
        ...(collaborator?.invited && {
          assignedTaxOffice: body.assignedTaxOffice,
        }),
        ...(collaborator?.invited && { vat: body.vat }),
        ...(collaborator?.invited && {
          phasePreferenceId: body.phasePreferenceId,
        }),
        ...(collaborator?.invited && {
          policeConductCertificate: body.policeConductCertificate,
        }),
        ...(collaborator?.invited && {
          vaccinatedMeasles: body.vaccinatedMeasles,
        }),
        ...(collaborator?.invited && {
          competenceTeamKickOff: body.competenceTeamKickOff,
        }),
        ...(collaborator?.invited && {
          competenceTeamFirstSteps: body.competenceTeamFirstSteps,
        }),
        ...(collaborator?.invited && { firstStrike: body.firstStrike }),
        ...(collaborator?.invited && { secondStrike: body.secondStrike }),
        thirdStrike: body.thirdStrike,
        ...(collaborator?.invited && { comment: body.comment ?? null }),
        ...(collaborator?.invited && { attachment: body.attachment }),
        ...(collaborator?.invited && { businessTypeId: body.businessTypeId }),
        profileCompleted: true,
        streetAndHouseNo: body.streetAndHouseNo,
        city: body.city,
        postalCode: body.postalCode,
      },
    })

    await tx.person.update({
      where: {
        personId: updatedCollaborator.personId,
      },
      data: {
        appellationId: body.appellationId,
        title: body.title,
        firstName: body.firstName,
        lastName: body.lastName,
        phoneNumber: body.phoneNumber,
      },
    })
  })
}

export async function POST(req: Request, context: contextProps) {
  try {
    const userDetails = getUserDetails()
    const updateCollaboratorPermission =
      userDetails.roles.includes('subjectAdmin') ||
      userDetails.roles.includes('subjectSupervision') ||
      userDetails.role === Role.Collaborator

    if (!updateCollaboratorPermission) {
      throw new Error('Not Authorized')
    }

    const { params } = context
    const { collaboratorId } = params

    const body = (await req.json()) as InterfaceCollaboratorData

    const collaborator = await db.collaborator.findFirst({
      where: {
        collaboratorId: +collaboratorId,
      },
      select: {
        invited: true,
      },
    })

    validateFields(body)
    const updatedCollaborator = await updateCollaboratorTransaction({
      body,
      collaboratorId,
    })

    return NextResponse.json(
      { message: successMessages.success, collaborator: updatedCollaborator },
      { status: 200 },
    )
  } catch (error) {
    let errorMessage = errorMessages.DEFAULT_ERROR
    if (error instanceof PrismaClientKnownRequestError) {
      if (error.code === prismaErrorCode.RECORD_NOT_FOUND) {
        errorMessage = errorMessages.RECORD_NOT_FOUND
      } else if (error.code === prismaErrorCode.UNIQUE_CONSTRAINT_FAILED) {
        errorMessage = error.message
      }
    } else if (error instanceof Error) {
      errorMessage = error.message
    }

    return NextResponse.json({ error: errorMessage }, { status: 400 })
  }
}
