import { db } from '@/lib/db'
import { NextResponse } from 'next/server'
import { Collaborator, Person, Role, TaskType } from '@prisma/client'
import { successMessages } from '@/utils/successMessages'
import { errorMessages, prismaErrorCode } from '@/utils/errorMessages'
import { PrismaClientKnownRequestError } from '@prisma/client/runtime/library'
import { PIN_NO_CONSTRAINTS } from '@/utils/constants/common'
import crypto from 'crypto'
import sendEmail from '@/utils/sendMail'
import { historyMessages } from '@/utils/historyMessages'
import moment from 'moment'
import { getUserDetails } from '@/utils/authUtils'
import { taskMessages } from '@/utils/taskMessages'
import { setYourPassword } from '@/utils/EmailTemplates/setYourPassword'
import { actionTemplate } from '@/utils/EmailTemplates/action'

interface CreateCollaboratorsInterface extends Person, Collaborator {}

interface transactionFunctionProps {
  data: Omit<CreateCollaboratorsInterface, 'collaboratorId'>
  token: string
  tokenExpiration: Date
}

function generateRandomInRange(
  min: number,
  max: number,
  existingNumbers: number[],
): number {
  let randomNum: number
  do {
    randomNum = Math.floor(Math.random() * (max - min + 1)) + min
  } while (existingNumbers.includes(randomNum))

  return randomNum
}

function createCollaboratorHandler({
  data,
  token,
  tokenExpiration,
}: transactionFunctionProps) {
  return db.$transaction(async (tx) => {
    const { personId } = await tx.person.create({
      data: {
        email: data.email.toLowerCase(),
        firstName: data.firstName,
        lastName: data.lastName,
        phoneNumber: data.phoneNumber,
        title: data.title,
        appellationId: data.appellationId,
        role: Role.Collaborator,
        resetPasswordToken: token,
        resetPasswordTokenExpiry: tokenExpiration,
      },
    })

    const existingPinNo = await tx.collaborator.findMany({
      select: {
        pinNo: true,
      },
    })

    const formattedExistingPinNo = existingPinNo.map((pin) => pin.pinNo)
    const randomPinNo = generateRandomInRange(
      PIN_NO_CONSTRAINTS.min,
      PIN_NO_CONSTRAINTS.max,
      formattedExistingPinNo,
    )

    await tx.collaborator.create({
      data: {
        personId,
        dob: data.dob,
        pinNo: randomPinNo,
        attachment: data.attachment,
      },
    })

    const today = moment()
    const fourDaysAhead = moment(today).add(4, 'days').toISOString()
    const { email } = getUserDetails()

    const taskCreator = await tx.person.findUnique({ where: { email } })

    await tx.task.create({
      data: {
        dueDate: fourDaysAhead,
        note: 'Collaborator is Created Update the Data',
        title: 'Collaborator Data Updation',
        type: TaskType.Data,
        creatorId: taskCreator?.personId,
        assigneeId: taskCreator?.personId,
      },
    })
    const url = process.env.APP_DEV_URL ?? process.env.APP_PROD_URL ?? 'localhost:3000'
    const text = 'Instructions for Completing Profile Data'
    const html = actionTemplate(url, text)

    await sendEmail({
      to: data.email.toLowerCase(),
      subject: 'Create Your Password and Complete Profile Data',
      html: html,
    })

    await tx.history.create({
      data: {
        personId: personId,
        actionType: historyMessages.collaboratorCreated,
        actionDetail: historyMessages.collaboratorCreated,
        actionReference: historyMessages.create,
      },
    })
  })
}

export async function POST(req: Request) {
  try {

    const userDetails = getUserDetails()
    const createCollaboratorPermission = userDetails.roles.includes('subjectAdmin') || userDetails.roles.includes('subjectSupervision')

    if(!createCollaboratorPermission){
      throw new Error('Not Authorized')
    }

    const body: Omit<CreateCollaboratorsInterface, 'collaboratorId'> =
      await req.json()
    const { ...data } = body

    const token = crypto.randomBytes(32).toString('hex')
    const tokenExpiration = new Date()
    tokenExpiration.setDate(tokenExpiration.getDate() + 3)

    await createCollaboratorHandler({ data, token, tokenExpiration })

    const url =
      process.env.NODE_ENV !== 'production'
        ? `${process.env.APP_DEV_URL}/reset-password?token=${token}`
        : `${process.env.APP_PROD_URL}/reset-password?token=${token}`

    const html = setYourPassword(url)

    await sendEmail({
      to: data.email,
      subject: 'Verify your account',
      html: html,
    })

    return NextResponse.json(
      { message: successMessages.collaboratorCreated },
      { status: 201 },
    )
  } catch (error) {
    let errorMessage = errorMessages.DEFAULT_ERROR

    if (
      error instanceof PrismaClientKnownRequestError &&
      error.code === prismaErrorCode.UNIQUE_CONSTRAINT_FAILED
    ) {
      errorMessage = errorMessages.DUPLICATE_USER
    }

    return NextResponse.json({ error: errorMessage }, { status: 404 })
  }
}
