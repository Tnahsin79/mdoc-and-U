import { db } from '@/lib/db'
import { NextResponse } from 'next/server'
import { paginationLimit } from '@/utils/constants/common'
import { errorMessages } from '@/utils/errorMessages'
import { successMessages } from '@/utils/successMessages'
// import { deletedCollaboratorAccount } from '@/utils/constants/backend'
import { IListItem } from '@/interface/common'

function formatArrayToString(arr: Array<string>) {
  if (arr.length === 1) {
    return arr[0]
  } else if (arr.length !== 0) {
    return arr.join(', ')
  } else {
    return ''
  }
}

export async function POST(req: Request) {
  try {
    const limit = paginationLimit
    const body = await req.json()
    const page = body?.page || 1
    const offset = (page - 1) * limit
    const searchQuery = body?.search || ''

    let whereCondition = {}

    if (searchQuery) {
      const words = searchQuery.split(/\s+/)
      whereCondition = {
        person: {
          AND: words.map((word: string) => ({
            OR: [
              {
                firstName: {
                  contains: word,
                  mode: 'insensitive',
                },
              },
              {
                lastName: {
                  contains: word,
                  mode: 'insensitive',
                },
              },
            ],
          })),
        },
      }
    }

    const totalRecords = await db.collaborator.count({ where: whereCondition })

    const response = await db.collaborator.findMany({
      take: limit,
      skip: offset,
      orderBy: {
        collaboratorId: 'desc',
      },
      where: whereCondition,
      select: {
        pinNo: true,
        collaboratorId: true,
        schoolTypeId: true,
        collaboratorSchoolRole: true,
        jobTitle: true,
        workedAsATeacher: true,
        person: {
          select: {
            personId: true,
            firstName: true,
            lastName: true,
            isActive: true,
            email: true,
            phoneNumber: true,
          },
        },
        phasePreferenceId: true,
      },
    })

    const collaboratorSchoolRoles: any = await db.list.findMany({
      where: {
        listType: 'collaboratorSchoolRole',
        isActive: true,
      },
    })

    const roleMap = new Map(
      collaboratorSchoolRoles.map((role: any) => [role.listId, role.listValue]),
    )

    const schoolTypes: any = await db.list.findMany({
      where: {
        listType: 'schoolType',
        isActive: true,
      },
    })

    const schoolTypeMap = new Map(
      schoolTypes.map((type: IListItem) => [type.listId, type.listValue]),
    )

    let modified = response.map((collaborator: any) => {
      const listValue = schoolTypeMap.get(collaborator.schoolTypeId as number)

      let roles = collaborator.collaboratorSchoolRole.map(({ roleId }: {roleId: number}) => {
        return roleMap.get(roleId)
      })

      roles = formatArrayToString(roles)

      return {
        ...collaborator,
        schoolTypeId: listValue,
        collaboratorSchoolRole: roles,
      }
    })

    return NextResponse.json(
      {
        message: successMessages.success,
        // collaboratorList: response.filter(
        //   (collaborator: any) =>
        //     collaborator.person.email !== deletedCollaboratorAccount,
        // ),
        collaboratorList: modified,
        totalRecords,
      },
      { status: 200 },
    )
  } catch (error) {
    let errorMessage = errorMessages.DEFAULT_ERROR

    if (error instanceof Error) {
      errorMessage = error.message
    }

    return NextResponse.json({ error: errorMessage }, { status: 404 })
  }
}
