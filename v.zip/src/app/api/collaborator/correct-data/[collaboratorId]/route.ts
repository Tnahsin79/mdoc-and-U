import { db } from '@/lib/db'
import { errorMessages, prismaErrorCode } from '@/utils/errorMessages'
import { PrismaClientKnownRequestError } from '@prisma/client/runtime/library'
import { NextResponse } from 'next/server'

interface contextProps {
  params: {
    collaboratorId: string
  }
}

interface transactionFunctionProps {
  collaboratorId: string
  correct: boolean
}

function correctDataHandler({
  collaboratorId,
  correct,
}: transactionFunctionProps) {
  return db.$transaction(async (tx) => {
    const collaborator = await tx.collaborator.update({
      where: {
        collaboratorId: +collaboratorId,
      },
      data: {
        correct: correct,
      },
    })

    return collaborator
  })
}

export async function POST(req: Request, context: contextProps) {
  try {
    const body = await req.json()
    const { correct } = body

    const { params } = context

    const { collaboratorId } = params

    const collaborator = await correctDataHandler({ collaboratorId, correct })

    return NextResponse.json(
      {
        correct: collaborator.correct,
        message: 'Collaborator Data is Correct Verified Successfully',
      },
      { status: 200 },
    )
  } catch (error) {
    let errorMessage = errorMessages.DEFAULT_ERROR

    if (
      error instanceof PrismaClientKnownRequestError &&
      error.code === prismaErrorCode.RECORD_NOT_FOUND
    ) {
      errorMessage = errorMessages.RECORD_NOT_FOUND
    } else if (error instanceof Error) {
      errorMessage = error.message
    }

    return NextResponse.json({ error: errorMessage }, { status: 400 })
  }
}
