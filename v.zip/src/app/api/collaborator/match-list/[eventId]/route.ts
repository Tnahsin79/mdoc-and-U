import { db } from '@/lib/db'
import { errorMessages } from '@/utils/errorMessages'
import { NextResponse } from 'next/server'

interface IContextProps {
  params: {
    eventId: string
  }
}

export async function GET(req: Request, context: IContextProps) {
  try {
    const eventCandidates = await db.eventCollaboratorAttendees.findMany({
      where: {
        eventId: Number(context.params.eventId),
      },
    })
    return NextResponse.json({
      data: eventCandidates,
      status: 200,
    })
  } catch (error) {
    let errorMessage = errorMessages.DEFAULT_ERROR

    if (error instanceof Error) {
      errorMessage = error.message
    }

    return NextResponse.json({ error: errorMessage }, { status: 404 })
  }
}
