import { PrismaClientKnownRequestError } from '@prisma/client/runtime/library'
import { NextResponse } from 'next/server'

import { db } from '@/lib/db'
import { errorMessages, prismaErrorCode } from '@/utils/errorMessages'
import { successMessages } from '@/utils/successMessages'
import { historyMessages } from '@/utils/historyMessages'

interface contextProps {
  params: {
    eventId: number
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json()
    const { eventId, candidates } = body

    await db.eventCollaboratorAttendees.createMany({
      data: candidates?.map((candidate: number) => {
        return {
          eventId: eventId,
          candidateId: candidate,
        }
      }),
      skipDuplicates: true,
    })

    await db.history.createMany({
      data: candidates?.map((candidate: number) => {
        return {
          actionType: historyMessages.attendedEvent,
          actionDetail: historyMessages.attendedEvent,
          actionReference: historyMessages.event,
          personId: candidate,
        }
      }),
      skipDuplicates: true,
    })

    return NextResponse.json(
      { message: successMessages.matchListOfCandidate },
      { status: 201 },
    )
  } catch (error) {
    let errorMessage = errorMessages.DEFAULT_ERROR

    if (
      error instanceof PrismaClientKnownRequestError &&
      error.code === prismaErrorCode.RECORD_NOT_FOUND
    ) {
      errorMessage = errorMessages.RECORD_NOT_FOUND
    } else if (error instanceof Error) {
      errorMessage = error.message
    }

    return NextResponse.json({ error: errorMessage }, { status: 400 })
  }
}
