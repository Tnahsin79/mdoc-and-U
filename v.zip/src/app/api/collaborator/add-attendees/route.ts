import { db } from '@/lib/db'
import { errorMessages, prismaErrorCode } from '@/utils/errorMessages'
import { successMessages } from '@/utils/successMessages'
import { PrismaClientKnownRequestError } from '@prisma/client/runtime/library'
import { NextResponse } from 'next/server'

interface ICandidate {
    personId: number
    firstName: string
    lastName: string | null
    email: string
  }

export async function POST(req: Request) {
  try {
    const body = await req.json()
    const { eventId, attendees } = body

    const response = await Promise.all(
      attendees.map(
        async (attendee: ICandidate) =>
          await db.eventAttendees.create({
            data: {
              eventId: +eventId,
              attendeeId: +attendee.personId,
              moduleName: 'Candidate'
            },
          }),
      ),
    )

    return NextResponse.json({message: successMessages.success}, { status: 201 })
  } catch (error) {
    let errorMessage = errorMessages.DEFAULT_ERROR

    if (
      error instanceof PrismaClientKnownRequestError &&
      error.code === prismaErrorCode.UNIQUE_CONSTRAINT_FAILED
    ) {
      errorMessage = errorMessages.DUPLICATE_USER
    }

    return NextResponse.json({ error: errorMessage }, { status: 404 })
  }
}
