import { db } from '@/lib/db'
import { errorMessages, prismaErrorCode } from '@/utils/errorMessages'
import { successMessages } from '@/utils/successMessages'
import { PrismaClientKnownRequestError } from '@prisma/client/runtime/library'
import { NextResponse } from 'next/server'

export async function POST(req: Request) {
  try {
    const body = await req.json()
    const { actionType, actionDetail, actionReference, personId } = body

    await db.history.create({
      data: {
        actionType,
        actionDetail,
        actionReference,
        personId,
      },
    })

    return NextResponse.json(
      { message: successMessages.historyCreatedSuccessfully },
      { status: 201 },
    )
  } catch (error) {
    console.error(error)

    if (
      error instanceof PrismaClientKnownRequestError &&
      error.code === prismaErrorCode.UNIQUE_CONSTRAINT_FAILED
    ) {
      return NextResponse.json(
        { error: errorMessages.DUPLICATE_DATA },
        { status: 400 },
      )
    }

    return NextResponse.json(
      { error: errorMessages.DEFAULT_ERROR },
      { status: 500 },
    )
  }
}
