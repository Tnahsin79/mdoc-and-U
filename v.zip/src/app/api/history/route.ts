import { db } from '@/lib/db'
import { historyActionReferences, paginationLimit } from '@/utils/constants'
import { errorMessages } from '@/utils/errorMessages'
import { NextResponse } from 'next/server'

export async function POST(req: Request) {
  try {
    const limit = paginationLimit
    const body = await req.json()
    const page = body?.page || 1
    const personId = body?.personId
    const offset = (page - 1) * limit

    const { filters } = body

    const whereCondition: any = [
      {
        personId: personId,
      },
    ]

    if (filters.includes(historyActionReferences.Messages)) {
      whereCondition.push({
        actionReference: historyActionReferences.Messages,
      })
    }

    if (filters.includes(historyActionReferences.Courses)) {
      whereCondition.push({
        actionReference: historyActionReferences.Courses,
      })
    }
    if (filters.includes(historyActionReferences.Documents)) {
      whereCondition.push({
        actionReference: historyActionReferences.Documents,
      })
    }
    if (filters.includes(historyActionReferences.Tasks)) {
      whereCondition.push({
        actionReference: historyActionReferences.Tasks,
      })
    }

    const history = await db.history.findMany({
      take: limit,
      skip: offset,
      where: {
        AND: whereCondition,
      },
    })

    const totalRecords = await db.history.count({
      where: {
        AND: whereCondition,
      },
    })

    return NextResponse.json({
      historyList: history,
      totalRecords,
      status: 200,
    })
  } catch (error) {
    let errorMessage = errorMessages.DEFAULT_ERROR

    if (error instanceof Error) {
      errorMessage = error.message
    }

    return NextResponse.json({ error: errorMessage }, { status: 404 })
  }
}
