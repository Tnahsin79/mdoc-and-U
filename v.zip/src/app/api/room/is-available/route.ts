import { Query, QueryConditions } from '@/interface/common'
import { db } from '@/lib/db'
import { errorMessages } from '@/utils/errorMessages'
import { Rooms } from '@prisma/client'
import moment from 'moment'
import { NextResponse } from 'next/server'

async function getAvailableRooms(startTime: Date, endTime: Date) {
  const queryConditions: QueryConditions = {
    OR: [
      {
        AND: [
          { startTime: { lte: startTime } },
          { endTime: { gt: startTime } },
        ],
      },
      {
        AND: [{ startTime: { lt: endTime } }, { endTime: { gte: endTime } }],
      },
      {
        AND: [{ startTime: { gte: startTime } }, { endTime: { lte: endTime } }],
      },
    ],
  }

  const conflictingBookings = await db.roomBooking.findMany({
    where: queryConditions,
    select: {
      roomId: true,
    },
  })

  const conflictingRoomIds = conflictingBookings.map(
    (booking) => booking.roomId,
  )

  const availableRooms = await db.rooms.findMany({
    where: {
      NOT: {
        roomId: {
          in: conflictingRoomIds,
        },
      },
    },
  })

  return availableRooms
}

export async function POST(req: Request) {
  try {
    const body = await req.json()
    const { bookedFrom, bookedTo, startTime, endTime } = body

    let availableRooms: Rooms[] = []

    const startDate = moment(bookedFrom)
    const endDate = bookedTo ? moment(bookedTo) : startDate
    const numberOfDays = endDate.diff(startDate, 'days')

    for (let i = 0; i <= numberOfDays; i++) {
      const currentDate = moment(startDate).add(i, 'days')

      const currentStartTime = moment(currentDate).set({
        hour: moment(startTime).hours(),
        minute: moment(startTime).minutes(),
      })
      const currentEndTime = moment(currentDate).set({
        hour: moment(endTime).hours(),
        minute: moment(endTime).minutes(),
      })

      const response = await getAvailableRooms(
        currentStartTime.toDate(),
        currentEndTime.toDate(),
      )

      availableRooms = [...availableRooms, ...response]
    }

    const uniqueObjects = []
    const uniqueRoomIds: number[] = []

    for (const obj of availableRooms) {
      if (!uniqueRoomIds.includes(obj.roomId)) {
        uniqueRoomIds.push(obj.roomId)
        uniqueObjects.push(obj)
      }
    }

    return NextResponse.json(
      { message: 'Success', availableRooms: uniqueObjects },
      { status: 200 },
    )
  } catch (error) {
    let errorMessage = errorMessages.DEFAULT_ERROR

    if (error instanceof Error) {
      errorMessage = error.message
    }

    return NextResponse.json({ error: errorMessage }, { status: 404 })
  }
}
