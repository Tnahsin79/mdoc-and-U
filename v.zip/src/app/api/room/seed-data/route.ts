import { db } from '@/lib/db'
import { prismaErrorCode } from '@/utils/errorMessages'
import { PrismaClientKnownRequestError } from '@prisma/client/runtime/library'
import { NextResponse } from 'next/server'
import roomData from '../../../../../public/assets/room-list.json'

export async function GET() {
  try {
    const roomCount = await db.rooms.count()
    if (roomCount > 0) {
      return NextResponse.json(
        { message: 'Room data already exists. Seeding aborted.' },
        { status: 200 },
      )
    }

    roomData.map(async (room) => {
      await db.rooms.create({
        data: {
          locationName: room['Location Name'],
          roomName: room['Room Name'].toString(),
          maxAttendees: room['Max Attendees'],
          barrierFreeAccess:
            room['Barrier-free access needed'].toUpperCase() === 'TRUE',
          smartboard: room['Smartboard'].toUpperCase() === 'TRUE',
          beamer: room['Beamer'].toUpperCase() === 'TRUE',
          flipchart: room['Flipchart'].toUpperCase() === 'TRUE',
          whiteboard: room['Whiteboard'].toUpperCase() === 'TRUE',
          moderationskoffer: room['Moderationskoffer'].toUpperCase() === 'TRUE',
          dokumentenkamera: room['Dokumentenkamera'].toUpperCase() === 'TRUE',
          pinnwand: room['Pinnwand'].toUpperCase() === 'TRUE',
          tische: room['Tische'].toUpperCase() === 'TRUE',
          mikrofonHandsenderNumber: room['Mikrofon Handsender Anzahl'],
          mikrofonHeadsetNumber: room['Mikrofon Headset Anzahl'],
          beleuchtungsanlage:
            room['Beleuchtungsanlage'].toUpperCase() === 'TRUE',
          rednerpult: room['Rednerpult'].toUpperCase() === 'TRUE',
        },
      })
    })

    return NextResponse.json(
      { message: 'Successfully Seeded Rooms' },
      { status: 201 },
    )
  } catch (error: any) {
    if (
      error instanceof PrismaClientKnownRequestError &&
      error.code === prismaErrorCode.UNIQUE_CONSTRAINT_FAILED
    ) {
      return NextResponse.json({ error: error }, { status: 400 })
    }

    return NextResponse.json({ error: error }, { status: 500 })
  }
}
