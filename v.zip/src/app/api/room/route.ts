import { db } from '@/lib/db'
import { NextResponse } from 'next/server'
import { errorMessages } from '@/utils/errorMessages'
import { successMessages } from '@/utils/successMessages'

export async function GET() {
  try {
    const allRooms = await db.rooms.findMany({})

    return NextResponse.json(
      {
        rooms: allRooms,
        message: successMessages.success,
      },
      { status: 200 },
    )
  } catch (error) {
    let errorMessage = errorMessages.DEFAULT_ERROR

    if (error instanceof Error) {
      errorMessage = error.message
    }

    return NextResponse.json({ error: errorMessage }, { status: 404 })
  }
}
