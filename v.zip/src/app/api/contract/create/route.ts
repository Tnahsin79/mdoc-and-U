import { db } from '@/lib/db'
import { phasesOptions } from '@/utils/constants/common'
import { errorMessages, prismaErrorCode } from '@/utils/errorMessages'
import { historyMessages } from '@/utils/historyMessages'
import { Contract, ContractDetail } from '@prisma/client'
import { PrismaClientKnownRequestError } from '@prisma/client/runtime/library'
import { NextResponse } from 'next/server'

export interface ICreateContract extends Contract, ContractDetail {
  phasePreference: {
    kickOff: boolean
    firstStep: boolean
    setUp: boolean
    studies: boolean
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json()

    const {
      personId,
      contractTypeId,
      positionTitle,
      duration,
      hourlyFee,
      billFrom,
      billTo,
      phasePreference,
    }: ICreateContract = body.data

    const matchingObject: phase | undefined = phasesOptions.find((obj) => {
      if (
        obj.kickOff === phasePreference.kickOff &&
        obj.firstStep === phasePreference.firstStep &&
        obj.setUp === phasePreference.setUp &&
        obj.studies === phasePreference.studies
      ) {
        return obj
      }
    })

    const phaseId = matchingObject!.id

    let contract = await db.contract.findFirst({
      where: {
        personId: personId,
        contractTypeId: contractTypeId,
      },
    })

    if (!contract) {
      // If no contract is found, create a new one
      contract = await db.contract.create({
        data: {
          personId: personId,
          contractTypeId: contractTypeId,
        },
      })
    }

    await db.contractDetail.create({
      data: {
        contractId: contract.contractId,
        positionTitle: positionTitle,
        duration: +duration!,
        hourlyFee: +hourlyFee!,
        phaseId: phaseId,
        billFrom: billFrom,
        billTo: billTo,
      },
    })

    await db.history.create({
      data: {
        personId: personId,
        actionType: historyMessages.contractCreated,
        actionDetail: historyMessages.contractCreated,
        actionReference: historyMessages.contract,
      },
    })

    return NextResponse.json(
      { message: 'Successfully Created Contract' },
      { status: 201 },
    )
  } catch (error) {
    console.error(error)

    if (
      error instanceof PrismaClientKnownRequestError &&
      error.code === prismaErrorCode.UNIQUE_CONSTRAINT_FAILED
    ) {
      return NextResponse.json({ error: 'Duplicate Data' }, { status: 400 })
    }

    return NextResponse.json(
      { error: errorMessages.DEFAULT_ERROR },
      { status: 500 },
    )
  }
}

type phase = {
  id: number
  kickOff: boolean
  firstStep: boolean
  setUp: boolean
  studies: boolean
}
