import { db } from '@/lib/db'
import { getUserDetails } from '@/utils/authUtils'
import { errorMessages, prismaErrorCode } from '@/utils/errorMessages'
import { successMessages } from '@/utils/successMessages'
import { PrismaClientKnownRequestError } from '@prisma/client/runtime/library'
import { NextResponse } from 'next/server'

export async function POST(req: Request) {
  try {
    const body = await req.json()
    const {
      availableId,
      howFarDistance,
      howManyToSupport,
      schoolTypeIds,
      communicationId,
    } = body
    
    const user = getUserDetails()

    const collaborator = await db.person.findFirst({
      where: {
        email: user.email,
      },
      select: {
        personId: true,
      },
    })

    const buddyRequest = await db.communication.findFirst({
      where: {
        communicationId: communicationId,
      },
      select: {
        buddyRequestId: true,
      },
    })

    if (collaborator) {
      if (buddyRequest?.buddyRequestId) {
        const response = await db.buddyRequest.update({
          where: {
            id: buddyRequest?.buddyRequestId,
          },
          data: {
            mentorId: +collaborator.personId,
            availableId: +availableId,
            howFarDistance: +howFarDistance,
            howManyToSupport: +howManyToSupport,
            schoolTypesIds: schoolTypeIds,
          },
        })
      } else {
        const response = await db.buddyRequest.create({
          data: {
            mentorId: +collaborator.personId,
            availableId: +availableId,
            howFarDistance: +howFarDistance,
            howManyToSupport: +howManyToSupport,
            schoolTypesIds: schoolTypeIds,
            isSubmitted: true,
          },
        })
        await db.communication.update({
          where: {
            communicationId: +communicationId,
          },
          data: {
            buddyRequestId: +response.id,
          },
        })
      }
    } else {
      throw new Error(errorMessages.UNAUTHORIZED)
    }

    return NextResponse.json(
      { message: successMessages.success },
      { status: 201 },
    )
  } catch (error) {
    console.log(error, 'Error')
    let errorMessage = errorMessages.DEFAULT_ERROR

    if (
      error instanceof PrismaClientKnownRequestError &&
      error.code === prismaErrorCode.UNIQUE_CONSTRAINT_FAILED
    ) {
      errorMessage = errorMessages.DUPLICATE_USER
    }

    return NextResponse.json({ error: errorMessage }, { status: 404 })
  }
}

interface contextProps {
  params: {}
  queryParams: {
    communication: number
  }
}

export async function GET(req: Request, context: contextProps) {
  try {
    const { searchParams } = new URL(req.url)
    const communication = searchParams.get('communication')
      ? searchParams.get('communication')
      : 'false'

    if (communication === undefined || communication === null) {
      throw new Error('Communication query parameter is missing')
    } else {
      const response = await db.communication.findFirst({
        where: {
          communicationId: +communication,
        },
        select: {
          buddyRequest: {
            select: {
              availableId: true,
              howManyToSupport: true,
              howFarDistance: true,
              schoolTypesIds: true,
              isSubmitted: true,
            },
          },
        },
      })

      return NextResponse.json({ buddyRequest: response }, { status: 200 })
    }
  } catch (error) {
    console.log(error, 'Error')
    let errorMessage = errorMessages.DEFAULT_ERROR

    if (
      error instanceof PrismaClientKnownRequestError &&
      error.code === prismaErrorCode.UNIQUE_CONSTRAINT_FAILED
    ) {
      errorMessage = errorMessages.DUPLICATE_USER
    }

    return NextResponse.json({ error: errorMessage }, { status: 404 })
  }
}
