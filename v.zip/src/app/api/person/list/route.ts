import { db } from '@/lib/db'
import { NextResponse } from 'next/server'
import { errorMessages } from '@/utils/errorMessages'
import { cookies } from 'next/headers'
import jwt, { JwtPayload } from 'jsonwebtoken'
import { PanoramaSharp } from '@mui/icons-material'
import { Role } from '@prisma/client'

export async function POST(req: Request) {
  try {
    const body = await req.json()
    const role = body?.role || null

    let person = undefined

    const cookieStore = cookies()
    const accessToken = cookieStore.get('accessToken')?.value
    if (!accessToken) {
      throw new Error(errorMessages.INVALID_TOKEN)
    }

    const JWTSecretKey: string = process.env.JWT_SECRET_KEY || 'ttmp-project'
    const decodedAccessToken: string | JwtPayload = jwt.verify(
      accessToken,
      JWTSecretKey,
    )

    if (
      !(typeof decodedAccessToken === 'object' && 'email' in decodedAccessToken)
    ) {
      throw new Error(errorMessages.INVALID_TOKEN)
    } else {
      person = await db.person.findFirst({
        where: {
          email: decodedAccessToken.email.toLowerCase(),
        },
      })

      if (!person) {
        throw new Error('Not Authorized')
      }
    }

    if (role === 'Candidate') {
      const candidate = await db.candidate.findFirst({
        where: {
          person: {
            email: decodedAccessToken.email.toLowerCase(),
          },
        },
        include: {
          mentor: {
            include: {
              person: {
                select: {
                  email: true,
                  firstName: true,
                  lastName: true,
                  role: true,
                  personId: true,
                  isActive: true,
                },
              },
            },
          },
        },
      })

      const events = await db.eventAttendees.findMany({
        where: {
          attendeeId: candidate?.personId,
        },
        select: {
          eventId: true,
        },
      })

      let eventCollaborators: any[] = [] // eslint-disable-line

      const eventPromises = events.map(async (event) => {
        const suitableCollaborator = await db.event.findFirst({
          where: {
            eventId: event.eventId,
          },
          select: {
            suitableCollaboratorId: true,
          },
        })
        if (suitableCollaborator) {
          const person = await db.person.findFirst({
            where: {
              personId: suitableCollaborator.suitableCollaboratorId,
              isActive: true,
            },
            select: {
              email: true,
              firstName: true,
              lastName: true,
              role: true,
              personId: true,
              isActive: true,
            },
          })
          let existingPerson
          if (person) {
            existingPerson = eventCollaborators.find(
              (existing) => existing.personId === person.personId,
            )
          }

          if (!existingPerson) {
            eventCollaborators = [...eventCollaborators, person]
          }
        }
      })

      await Promise.all(eventPromises)

      const employeesForCandidate = await db.person.findFirst({
        where: {
          role: 'Employee',
          isActive: true,
        },
        select: {
          email: true,
          firstName: true,
          lastName: true,
          role: true,
          personId: true,
          isActive: true,
        },
      })

      if (
        candidate?.mentor &&
        candidate.mentor.person &&
        candidate.mentor.person.isActive
      ) {
        const mentorPerson = candidate.mentor.person

        const finalPersonList = [employeesForCandidate]
          ?.concat(mentorPerson)
          .concat(eventCollaborators)

        return NextResponse.json({ persons: finalPersonList }, { status: 200 })
      } else {
        const finalPersons = [...[employeesForCandidate], ...eventCollaborators]

        return NextResponse.json({ persons: finalPersons }, { status: 200 })
      }
    } else if (role === 'Collaborator') {
      const employees = await db.person.findMany({
        where: {
          role: 'Employee',
          isActive: true,
        },
      })

      const collaborator = await db.collaborator.findFirst({
        where: {
          person: {
            email: decodedAccessToken.email.toLowerCase(),
          },
        },
      })

      const personsInCandidateArray = await db.collaborator.findMany({
        where: {
          collaboratorId: collaborator?.collaboratorId,
        },
        select: {
          candidate: {
            select: {
              person: {
                select: {
                  personId: true,
                  firstName: true,
                  lastName: true,
                  email: true,
                  isActive: true,
                },
              },
            },
          },
        },
      })

      const autoMatchedCandidates = personsInCandidateArray.flatMap(
        (collaborator) =>
          collaborator.candidate.map((candidate) => {
            if (candidate.person.isActive) {
              return candidate.person
            }
          }),
      )

      const collaboratorEvents = await db.event.findMany({
        where: {
          suitableCollaboratorId: person?.personId,
        },
      })

      const eventAttendeesIds: number[] = []
      for (let i = 0; i < collaboratorEvents.length; i++) {
        const currentAttendees = await db.eventAttendees.findMany({
          where: {
            eventId: collaboratorEvents[i].eventId,
          },
          select: {
            attendeeId: true,
          },
        })

        currentAttendees.forEach((attendee) => {
          eventAttendeesIds.push(attendee.attendeeId)
        })
      }

      const eventAttendeePersons = await db.person.findMany({
        where: {
          personId: { in: eventAttendeesIds },
          isActive: true,
        },
      })

      const allPersons = [
        ...employees,
        ...eventAttendeePersons,
        ...autoMatchedCandidates,
      ]

      const uniquePersons = allPersons.filter(
        (person, index, self) =>
          index === self.findIndex((p) => p?.personId === person?.personId),
      ).filter((item) => item !== undefined)

      return NextResponse.json({ persons: uniquePersons }, { status: 200 })
    } else {
      const persons = await db.person.findMany({
        where: {
          isActive: true,
        },
        select: {
          firstName: true,
          lastName: true,
          email: true,
          role: true,
          personId: true,
          isActive: true,
        },
      })

      return NextResponse.json({ persons }, { status: 200 })
    }
  } catch (error) {
    let errorMessage = errorMessages.DEFAULT_ERROR

    if (error instanceof Error) {
      errorMessage = error.message
    }

    return NextResponse.json({ error: errorMessage }, { status: 404 })
  }
}

interface contextProps {
  queryParams: {
    allCollaborators: boolean
  }
}

export async function GET(req: Request, context: contextProps) {
  try {
    const { queryParams } = context
    const allCollaborators = { queryParams }

    

    if(allCollaborators){
      const persons = await db.person.findMany({
        where: {
          role: Role.Collaborator,
          isActive: true,
        },
        select: {
          firstName: true,
          lastName: true,
          email: true,
          role: true,
          personId: true,
        },
      })

      return NextResponse.json({ persons }, { status: 200 })

    }

    const persons = await db.person.findMany({
      where: {
        isActive: true,
      },
      select: {
        firstName: true,
        lastName: true,
        email: true,
        role: true,
        personId: true,
      },
    })

    return NextResponse.json({ persons }, { status: 200 })
  } catch (error) {
    let errorMessage = errorMessages.DEFAULT_ERROR

    if (error instanceof Error) {
      errorMessage = error.message
    }

    return NextResponse.json({ error: errorMessage }, { status: 404 })
  }
}
