import { successMessages } from '@/utils/successMessages'
import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { errorMessages, prismaErrorCode } from '@/utils/errorMessages'
import { School } from '@prisma/client'
import { PrismaClientKnownRequestError } from '@prisma/client/runtime/library'
import { getUserDetails } from '@/utils/authUtils'

export async function POST(req: Request) {
  try {

    const userDetails = getUserDetails()
    const createSchoolPermission = userDetails.roles.includes('subjectAdmin') || userDetails.roles.includes('subjectSupervision')

    if(!createSchoolPermission){
      throw new Error('Not Authorized')
    }

    const body: Omit<School, 'schoolId'> = await req.json()

    await db.school.create({ data: body })

    return NextResponse.json(
      { message: successMessages.success },
      { status: 201 },
    )
  } catch (error) {
    let errorMessage = errorMessages.DEFAULT_ERROR

    if (
      error instanceof PrismaClientKnownRequestError &&
      error.code === prismaErrorCode.UNIQUE_CONSTRAINT_FAILED
    ) {
      errorMessage = errorMessages.DUPLICATE_SCHOOL
    } else if (error instanceof Error) {
      errorMessage = error.message
    }

    return NextResponse.json({ error: errorMessage }, { status: 400 })
  }
}
