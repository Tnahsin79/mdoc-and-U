import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { errorMessages, prismaErrorCode } from '@/utils/errorMessages'
import { School } from '@prisma/client'
import { successMessages } from '@/utils/successMessages'
import { PrismaClientKnownRequestError } from '@prisma/client/runtime/library'
import { getUserDetails } from '@/utils/authUtils'

interface contextProps {
  params: {
    schoolId: string
  }
}

export async function GET(req: Request, context: contextProps) {
  try {
    const { params } = context
    const { schoolId } = params

    if (!schoolId) {
      throw new Error(errorMessages.NO_DATA_FOUND)
    }

    const school = await db.school.findUnique({
      where: {
        schoolId: +schoolId,
      },
    })

    if (!school) {
      throw new Error(errorMessages.NO_DATA_FOUND)
    }

    return NextResponse.json({ school: school }, { status: 200 })
  } catch (error) {
    let errorMessage = errorMessages.DEFAULT_ERROR

    if (error instanceof Error) {
      errorMessage = error.message
    }

    return NextResponse.json({ error: errorMessage }, { status: 404 })
  }
}

export async function POST(req: Request, context: contextProps) {
  try {

    const userDetails = getUserDetails()
    const editSchoolPermission = userDetails.roles.includes('subjectAdmin') || userDetails.roles.includes('subjectSupervision')

    if(!editSchoolPermission){
      throw new Error('Not Authorized')
    }

    const { params } = context
    const { schoolId } = params

    const body = (await req.json()) as School

    const updatedSchool = await db.school.update({
      where: {
        schoolId: +schoolId,
      },
      data: body,
    })

    return NextResponse.json(
      { message: successMessages.success, school: updatedSchool },
      { status: 200 },
    )
  } catch (error) {
    let errorMessage = errorMessages.DEFAULT_ERROR
    if (
      error instanceof PrismaClientKnownRequestError &&
      error.code === prismaErrorCode.RECORD_NOT_FOUND
    ) {
      errorMessage = errorMessages.RECORD_NOT_FOUND
    } else if (error instanceof Error) {
      errorMessage = error.message
    }

    return NextResponse.json({ error: errorMessage }, { status: 400 })
  }
}
