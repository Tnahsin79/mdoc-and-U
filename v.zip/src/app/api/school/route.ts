import { successMessages } from '@/utils/successMessages'
import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { errorMessages } from '@/utils/errorMessages'
import { paginationLimit } from '@/utils/constants/common'

export async function POST(req: Request) {
  try {
    const limit = paginationLimit
    const body = await req.json()
    const page = body?.page || 1
    const offset = (page - 1) * limit
    const searchQuery = body?.search || ''
    const all = body?.all || false

    let whereCondition = {}
    if (searchQuery) {
      whereCondition = {
        OR: [
          {
            BSN: {
              contains: searchQuery,
              mode: 'insensitive',
            },
          },
          {
            schoolName: {
              contains: searchQuery,
              mode: 'insensitive',
            },
          },
        ],
      }
    }

    const totalRecords = await db.school.count({ where: whereCondition })

    const response = await db.school.findMany({
      ...(!all && { take: limit }),
      ...(!all && { skip: offset }),
      where: whereCondition,
      orderBy: {
        schoolId: 'desc',
      },
    })

    return NextResponse.json(
      {
        message: successMessages.success,
        schoolList: response,
        totalRecords,
      },
      { status: 200 },
    )
  } catch (error) {
    let errorMessage = errorMessages.DEFAULT_ERROR

    if (error instanceof Error) {
      errorMessage = error.message
    }

    return NextResponse.json({ error: errorMessage }, { status: 404 })
  }
}
