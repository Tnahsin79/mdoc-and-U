import { db } from '@/lib/db'
import { prismaErrorCode } from '@/utils/errorMessages'
import { PrismaClientKnownRequestError } from '@prisma/client/runtime/library'
import { NextResponse } from 'next/server'
import schoolData from '../../../../../public/assets/school-list.json'

interface SchoolTypes {
  [key: string]: number
}

const errorFieldValues: string[] = []
const duplicateInputEmails: string[] = []
export async function GET() {
  try {
    const schoolCount = await db.school.count()
    if (schoolCount > 0) {
      return NextResponse.json(
        { message: 'School data already exists. Seeding aborted.' },
        { status: 200 },
      )
    }

    const schoolTypesFromListApi = await db.list.findMany({
      where: {
        listType: 'schoolType',
      },
    })

    const schoolTypes: SchoolTypes = {
      'Zweiter Bildungsweg': 1,
      'Berufliche Schule': 2,
      Grundschule: 3, // eslint-disable-line
      'Integrierte Sekundarschule': 4, // eslint-disable-line
      Gemeinschaftsschule: 5, // eslint-disable-line
      Förderzentrum: 6, // eslint-disable-line
      Gymnasium: 7, // eslint-disable-line
      // 'Tempelhof-Schöneberg': 8,
      // Lichtenberg: 9, // eslint-disable-line
      'Not Set': 10,
    }

    Object.keys(schoolTypes).forEach((schoolType) => {
      const foundType = schoolTypesFromListApi.find(
        (obj) => obj.listValue === schoolType,
      )
      if (foundType) {
        schoolTypes[schoolType as keyof SchoolTypes] = foundType.listId
      } else if (schoolType === '') {
        const notSetObj = schoolTypesFromListApi.find(
          (obj) => obj.listValue === 'Not Set',
        )
        schoolTypes[schoolType] = notSetObj?.listId || 68
      }
    })

    schoolData.map(async (school) => {
      await db.school.create({
        data: {
          BSN: school.BSN,
          schoolTypeId: schoolTypes[school.Schulart] ?? schoolTypes['Not Set'],
          schoolName: school.Name,
          streetAndHouseNo: school['Adresse'],
          city: 'Berlin',
          postalCode: `${school.PLZ}`,
          phoneNumber: school.Telefon,
          faxNumber: school.Fax,
          emailAddress: school['eMail'].toLowerCase(),
          website: school.Internet ?? '',
        },
      })
    })

    const school = await db.school.findFirst({
      where: {
        schoolId: {
          gt: 1,
        },
      },
    })

    const appellation = await db.list.findFirst({
      where: { listType: 'appellation' },
    })

    const person = await db.person.upsert({
      where: {
        email: 'candidate@ttmp.com',
      },
      update: {
        lastName: 'ttmp',
        postalCode: '12345',
        phoneNumber: '2345432345',
        appellationId: appellation?.listId || 117,
      },
      create: {
        firstName: 'candidate',
        lastName: 'ttmp',
        email: 'candidate@ttmp.com',
      },
    })

    const teachingPosition = await db.list.findFirst({
      where: { listType: 'teachingPosition' },
    })

    const yearGroup = await db.list.findFirst({
      where: { listType: 'yearGroup' },
    })

    const kickOffGroup = await db.list.findFirst({
      where: { listType: 'kickOffGroup' },
    })

    const firstRecognisedSubject = await db.list.findFirst({
      where: { listType: 'firstRecognisedSubject' },
    })

    const candidateData = {
      personId: person?.personId || 2,
      streetAndHouseNo: 'Street, 53',
      city: 'Berlin',
      teachingPositionId: teachingPosition?.listId || 67,
      startSchoolYear: '2000',
      yearGroupId: yearGroup?.listId || 73,
      phaseRequiredId: 1,
      kickOffGroupId: kickOffGroup?.listId || 77,
      firstRecognisedSubjectId: firstRecognisedSubject?.listId || 149,
      schoolId: school?.schoolId || 2,
      startOfContract: new Date(),
      bbvdStart: new Date(),
      document: '',
    }

    await db.candidate.create({
      data: candidateData,
    })

    return NextResponse.json(
      { message: 'Successfully Seeded Schools' },
      { status: 201 },
    )
  } catch (error: any) {
    if (
      error instanceof PrismaClientKnownRequestError &&
      error.code === prismaErrorCode.UNIQUE_CONSTRAINT_FAILED
    ) {
      return NextResponse.json({ error: error }, { status: 400 })
    }

    if (error.message.startsWith('Please')) {
      return NextResponse.json({ error: error }, { status: 400 })
    }

    if (error.message.startsWith('Field')) {
      return NextResponse.json(
        { error: error.message, data: errorFieldValues },
        { status: 409 },
      )
    }

    if (error.message.startsWith('Duplicate')) {
      return NextResponse.json(
        { error: error.message, data: duplicateInputEmails },
        { status: 409 },
      )
    }

    return NextResponse.json({ error: error }, { status: 500 })
  }
}
