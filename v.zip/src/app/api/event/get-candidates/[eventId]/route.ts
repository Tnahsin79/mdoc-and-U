import { Role } from '@prisma/client'
import { NextResponse } from 'next/server'

import { db } from '@/lib/db'
import { errorMessages } from '@/utils/errorMessages'
import { all } from 'axios'

interface contextProps {
  params: {
    eventId: string
  }
}

export async function GET(req: Request, context: contextProps) {
  try {
    const { params } = context
    const { eventId } = params

    if (!eventId) {
      return NextResponse.json(
        { error: errorMessages.EVENT_NOT_FOUND },
        { status: 400 },
      )
    }

    const allCandidatesList: {
      personId: number
      firstName: string
      lastName: string | null
      email: string
      role: Role
      present?: boolean
    }[] = []

    const eventAttendees = await db.eventAttendees.findMany({
      where: {
        eventId: +eventId,
      },
    })

    const attendeeIds = eventAttendees.map((item) => item.attendeeId)

    const res = await db.eventCollaboratorAttendees.findMany({
      where: {
        eventId: +eventId,
        candidateId: {in: attendeeIds}
      },
      select: {
        candidateId: true,
      }
    })
    const presentCandidates = res.map((candidate:any) => candidate.candidateId)

    // const markPresent = await Promise.all(eventAttendees.map((attendee) => {
    //   const res = await eventCollaboratorAttendees
    // }))

    for (let i = 0; i < eventAttendees.length; i++) {
      if (eventAttendees[i].moduleName === 'Group') {
        const groupList = await db.group.findMany({
          where: {
            groupId: eventAttendees[i].attendeeId,
          },
          select: {
            GroupAttendees: {
              include: {
                Candidate: {
                  select: {
                    personId: true,
                    firstName: true,
                    lastName: true,
                    email: true,
                    role: true,
                  },
                },
              },
            },
          },
        })
        const groupCandidateList = groupList[0]?.GroupAttendees?.map(
          (group) => group.Candidate,
        )
        allCandidatesList.push(...groupCandidateList)
      } else if (
        ['Collaborator', 'Candidate'].includes(eventAttendees[i].moduleName)
      ) {
        const personList = await db.person.findFirst({
          where: {
            personId: +eventAttendees[i].attendeeId,
            // isActive: true, #TBD
          },
          select: {
            personId: true,
            firstName: true,
            lastName: true,
            email: true,
            role: true,
          },
        })
        if(personList){
          allCandidatesList.push(personList)
        }
      }
    }
    const presentIncludedAllCandidates = allCandidatesList.map(candidate => {
      if(presentCandidates.includes(candidate.personId)){
        return {...candidate, present: true}
      } else {
        return {...candidate, present: false}
      }
    })

    if (presentIncludedAllCandidates.length === 0) {
      return NextResponse.json(
        { error: errorMessages.NO_CANDIDATES_FOUND },
        { status: 404 },
      )
    }

    return NextResponse.json({ candidates: presentIncludedAllCandidates }, { status: 200 })
  } catch (error) {
    return NextResponse.json(
      { error: errorMessages.DEFAULT_ERROR },
      { status: 500 },
    )
  }
}
