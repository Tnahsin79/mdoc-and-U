import { db } from '@/lib/db'
import { errorMessages, prismaErrorCode } from '@/utils/errorMessages'
import { successMessages } from '@/utils/successMessages'
import { PrismaClientKnownRequestError } from '@prisma/client/runtime/library'
import { NextResponse } from 'next/server'

export async function POST(req: Request) {
  try {
    const body = await req.json()
    const { eventId, description, bookedFrom, startTime, endTime } = body

    const response = await db.event.update({
      where: {
        eventId: +eventId,
      },
      data: {
        description: description,
        bookedFrom: bookedFrom,
        startTime: startTime,
        endTime: endTime,
      },
    })

    return NextResponse.json(
      { message: successMessages.eventUpdated },
      { status: 200 },
    )
  } catch (error) {
    let errorMessage = errorMessages.DEFAULT_ERROR
    if (error instanceof PrismaClientKnownRequestError) {
      if (error.code === prismaErrorCode.UNIQUE_CONSTRAINT_FAILED) {
        errorMessage = errorMessages.DUPLICATE_EVENT
      } else {
        errorMessage = error.message
      }
    }

    return NextResponse.json({ error: errorMessage }, { status: 500 })
  }
}
