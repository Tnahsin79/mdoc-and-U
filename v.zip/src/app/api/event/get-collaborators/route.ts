import { Role } from '@prisma/client'

import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { errorMessages } from '@/utils/errorMessages'

export async function GET() {
  try {
    const employeesAndCollaborators = await db.person.findMany({
      where: {
        OR: [
          {
            role: Role.Employee,
            isActive: true,
          },
          {
            role: Role.Collaborator,
            isActive: true,
          },
        ],
      },
      select: {
        personId: true,
        email: true,
        firstName: true,
        lastName: true,
        role: true,
        person: true,
      },
    })

    if (!employeesAndCollaborators) {
      return NextResponse.json(
        { error: errorMessages.COLLABORATORS_NOT_FOUND },
        { status: 404 },
      )
    }

    return NextResponse.json(
      { collaborators: employeesAndCollaborators },
      { status: 200 },
    )
  } catch (error) {
    return NextResponse.json(
      { error: errorMessages.DEFAULT_ERROR },
      { status: 500 },
    )
  }
}
