import { NextResponse } from 'next/server'
import { PrismaClientKnownRequestError } from '@prisma/client/runtime/library'

import { db } from '@/lib/db'
import { errorMessages, prismaErrorCode } from '@/utils/errorMessages'
import { successMessages } from '@/utils/successMessages'
import { ICreateEventRequestBody } from '@/interface/event'
import { createEventSchema } from '@/validators/schemas/event'
import { getUserDetails } from '@/utils/authUtils'
import sendEmail from '@/utils/sendMail'
import moment from 'moment'
import { actionTemplate } from '@/utils/EmailTemplates/action'

export async function POST(req: Request) {
  try {
    const userDetails = getUserDetails()
    const canCreateEvent =
      userDetails.roles.includes('subjectAdmin') ||
      userDetails.roles.includes('subjectSupervision')

    if (!canCreateEvent) {
      throw new Error('Not Authorized')
    }

    const parsed = createEventSchema.safeParse(await req.json())

    if (!parsed.success) {
      const errorMessage =
        parsed.error.issues[0]?.message || errorMessages.DEFAULT_ERROR
      return NextResponse.json({ error: errorMessage }, { status: 400 })
    }

    const body: ICreateEventRequestBody = parsed.data

    const {
      templateId,
      subjectAreaId,
      subjectModule,
      eventTypeId,
      phaseId,
      title,
      minParticipants,
      maxParticipants,
      description,
      eventManner,
      accessLink,
      eventStatus,
      reason,
      bookedFrom,
      bookedTo,
      startTime,
      endTime,
      eventRepeatId,
      lmsLink,
      locationId,
      barrierFreeAccess,
      suitableRoomId,
      equipmentId,
      suitableCollaboratorId,
      attendeesId,
      eventKey,
    } = body
    const newEvent = await db.event.create({
      data: {
        templateId: templateId ?? null,
        title: title,
        subjectAreaId: subjectAreaId,
        subjectModule,
        eventTypeId: eventTypeId,
        eventStatusId: eventStatus,
        reason: reason,
        phaseId: phaseId,
        eventManner,
        description: description,
        bookedFrom,
        bookedTo,
        startTime,
        endTime,
        eventRepeatId: eventRepeatId,
        minParticipants,
        maxParticipants,
        lmsLink,
        accessLink,
        locationId: locationId,
        barrierFreeAccess,
        suitableRoomsId: suitableRoomId,
        suitableCollaboratorId: suitableCollaboratorId,
        eventKey: eventKey,
      },
    })

    await db.eventAttendees.createMany({
      data: attendeesId?.map((item) => {
        const [type, id] = item.split('_')
        return {
          eventId: newEvent.eventId,
          attendeeId: +id,
          moduleName: type,
        }
      }),
    })

    const collaborator = await db.collaborator.findFirst({
      where: {
        person: {
          personId: +newEvent.suitableCollaboratorId,
        },
      },
      select: {
        person: {
          select: {
            email: true,
          },
        },
        invited: true,
        collaboratorId: true,
      },
    })

    if (collaborator && !collaborator?.invited) {
      await db.collaborator.update({
        where: {
          collaboratorId: +collaborator?.collaboratorId,
        },
        data: {
          invited: true,
        },
      })
    }

    const url =
      process.env.APP_DEV_URL ?? process.env.APP_PROD_URL ?? 'localhost:3000'
    const text = 'You have been Assigned to the Event, Event Details'
    const html = actionTemplate(url, text)

    if (collaborator) {
      await sendEmail({
        to: collaborator?.person.email,
        subject: 'Assigned to the Event',
        html: html,
      })
    }

    const candidateIds = attendeesId
      .map((item) => {
        const [type, id] = item.split('_')
        if (type === 'Candidate') {
          return +id
        }
      })
      .filter((item) => item !== undefined)
    if (candidateIds.length > 0) {
      const candidateEmails = await db.person.findMany({
        where: {
          personId: {
            in: candidateIds as number[],
          },
        },
        select: {
          email: true,
        },
      })
      await Promise.allSettled(
        candidateEmails.map((candidate) => {
          const url =
            process.env.APP_DEV_URL ??
            process.env.APP_PROD_URL ??
            'localhost:3000'
          const text = 'You have been Assigned to the Event, Event Details'
          const html = actionTemplate(url, text)

          sendEmail({
            to: candidate.email,
            subject: 'Assigned to the Event',
            html: html,
          })
        }),
      )
    }

    if (suitableRoomId) {
      const startDate = moment(bookedFrom)
      const endDate = bookedTo ? moment(bookedTo) : startDate
      const numberOfDays = endDate.diff(startDate, 'days')

      for (let i = 0; i <= numberOfDays; i++) {
        const currentDate = moment(startDate).add(i, 'days')

        await db.roomBooking.create({
          data: {
            roomId: suitableRoomId,
            startTime: moment(currentDate)
              .set({
                hour: moment(startTime).hours(),
                minute: moment(startTime).minutes(),
              })
              .toDate(),
            endTime: moment(currentDate)
              .set({
                hour: moment(endTime).hours(),
                minute: moment(endTime).minutes(),
              })
              .toDate(),
          },
        })
      }
    }

    if (equipmentId && equipmentId.length > 0) {
      for (const eqId of equipmentId) {
        await db.listEquipment.create({
          data: {
            eventId: newEvent.eventId,
            listId: eqId,
          },
        })
      }
    }

    return NextResponse.json(
      { message: successMessages.eventCreated },
      { status: 201 },
    )
  } catch (error) {
    let errorMessage = errorMessages.DEFAULT_ERROR

    if (
      error instanceof PrismaClientKnownRequestError &&
      error.code === prismaErrorCode.UNIQUE_CONSTRAINT_FAILED
    ) {
      errorMessage = errorMessages.DUPLICATE_EVENT
    }

    return NextResponse.json({ error: errorMessage }, { status: 404 })
  }
}
