/**
 * @swagger
 * /api/event:
 *   post:
 *     summary: Create a new event
 *     description: Endpoint to create a new event.
 *     tags:
 *      - Event
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               templateId:
 *                 type: number
 *               subjectAreaId:
 *                 type: number
 *               subjectModule:
 *                 type: string
 *               eventTypeId:
 *                 type: number
 *               phase:
 *                 type: string
 *               title:
 *                 type: string
 *               minParticipants:
 *                 type: number
 *               maxParticipants:
 *                 type: number
 *               description:
 *                 type: string
 *               eventManner:
 *                 type: string
 *               accessLink:
 *                 type: string
 *               eventStatus:
 *                 type: number
 *               reason:
 *                 type: string
 *               eventDate:
 *                 type: string
 *                 format: date
 *               bookedFrom:
 *                 type: string
 *                 format: date-time
 *               bookedTo:
 *                 type: string
 *                 format: date-time
 *               startTime:
 *                 type: string
 *                 format: time
 *               endTime:
 *                 type: string
 *                 format: time
 *               eventRepeats:
 *                 type: string
 *                 nullable: true
 *               lmsLink:
 *                 type: string
 *               locationId:
 *                 type: number
 *               barrierFreeAccess:
 *                 type: boolean
 *                 nullable: true
 *               suitableRoomId:
 *                 type: number
 *                 nullable: true
 *               equipmentId:
 *                 type: array
 *                 items:
 *                   type: number
 *               suitableCollaboratorId:
 *                 type: number
 *               attendees:
 *                 type: number
 *             required:
 *               - templateId
 *               - subjectAreaId
 *               - subjectModule
 *               - eventTypeId
 *               - phase
 *               - title
 *               - minParticipants
 *               - maxParticipants
 *               - description
 *               - eventManner
 *               - accessLink
 *               - eventStatus
 *               - reason
 *               - eventDate
 *               - bookedFrom
 *               - bookedTo
 *               - startTime
 *               - endTime
 *               - lmsLink
 *               - locationId
 *               - suitableCollaboratorId
 *               - attendees
 *     responses:
 *       201:
 *         description: Event created successfully
 *       400:
 *         description: Invalid input or missing parameters
 */
