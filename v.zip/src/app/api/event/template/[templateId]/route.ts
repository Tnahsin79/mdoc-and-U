import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { errorMessages } from '@/utils/errorMessages'

interface contextProps {
  params: {
    templateId: string
  }
}

export async function GET(req: Request, context: contextProps) {
  try {
    const { params } = context
    const { templateId } = params

    if (!templateId) {
      return NextResponse.json(
        { error: errorMessages.NO_DATA_FOUND },
        { status: 400 },
      )
    }

    const eventTemplate = await db.eventTemplate.findUnique({
      where: { templateId: +templateId },
    })

    if (!eventTemplate) {
      return NextResponse.json(
        { error: errorMessages.EVENT_TEMPLATE_NOT_FOUND },
        { status: 404 },
      )
    }

    return NextResponse.json({ template: eventTemplate }, { status: 200 })
  } catch (error) {
    return NextResponse.json(
      { error: errorMessages.DEFAULT_ERROR },
      { status: 500 },
    )
  }
}
