import { NextResponse } from 'next/server'
import { PrismaClientKnownRequestError } from '@prisma/client/runtime/library'

import { db } from '@/lib/db'
import { errorMessages, prismaErrorCode } from '@/utils/errorMessages'
import { successMessages } from '@/utils/successMessages'
import { getUserDetails } from '@/utils/authUtils'

export async function POST(req: Request) {
  try {

    const userDetails = getUserDetails()
    const canCreateEventTemplate = userDetails.roles.includes('subjectAdmin') || userDetails.roles.includes('subjectSupervision')

    if(!canCreateEventTemplate){
      throw new Error('Not Authorized')
    }

    const body: any = await req.json()

    const newTemplate = await db.eventTemplate.create({
      data: body,
    })

    return NextResponse.json(
      { message: successMessages.eventCreated, template: newTemplate },
      { status: 201 },
    )
  } catch (error) {
    let errorMessage = errorMessages.DEFAULT_ERROR

    if (
      error instanceof PrismaClientKnownRequestError &&
      error.code === prismaErrorCode.UNIQUE_CONSTRAINT_FAILED
    ) {
      errorMessage = errorMessages.DUPLICATE_EVENT
    }

    return NextResponse.json({ error: errorMessage }, { status: 404 })
  }
}
