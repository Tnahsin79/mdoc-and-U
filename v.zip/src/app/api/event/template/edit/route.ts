import { PrismaClientKnownRequestError } from '@prisma/client/runtime/library'
import { NextResponse } from 'next/server'

import { db } from '@/lib/db'
import { errorMessages, prismaErrorCode } from '@/utils/errorMessages'
import { successMessages } from '@/utils/successMessages'

export async function PUT(req: Request) {
  try {
    const body = await req.json()

    const existingEventTemplate = await db.eventTemplate.findUnique({
      where: { templateId: body.templateId },
    })

    if (!existingEventTemplate) {
      return NextResponse.json(
        { error: errorMessages.EVENT_TEMPLATE_NOT_FOUND },
        { status: 404 },
      )
    }

    await db.eventTemplate.update({
      where: { templateId: body.templateId },
      data: body,
    })

    return NextResponse.json(
      { message: successMessages.eventTemplateUpdated },
      { status: 200 },
    )
  } catch (error) {
    let errorMessage = errorMessages.DEFAULT_ERROR
    if (error instanceof PrismaClientKnownRequestError) {
      if (error.code === prismaErrorCode.UNIQUE_CONSTRAINT_FAILED) {
        errorMessage = errorMessages.DUPLICATE_EVENT
      } else {
        errorMessage = error.message
      }
    }

    return NextResponse.json({ error: errorMessage }, { status: 500 })
  }
}
