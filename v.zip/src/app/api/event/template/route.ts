import { NextResponse } from 'next/server'

import { successMessages } from '@/utils/successMessages'
import { db } from '@/lib/db'
import { errorMessages } from '@/utils/errorMessages'
import { paginationLimit } from '@/utils/constants/common'

export async function POST(req: Request) {
  try {
    const limit = paginationLimit
    const body = await req.json()
    const page = body?.page || 1
    const offset = (page - 1) * limit
    const searchQuery = body?.search || ''
    const all = body?.all || false
    const isListInEvent = body?.isListInEvent || false

    let whereCondition = {}
    if (searchQuery) {
      whereCondition = {
        templateName: {
          contains: searchQuery,
          mode: 'insensitive',
        },
      }
    }

    if (isListInEvent) {
      whereCondition = {
        ...whereCondition,
        isActive: true,
      }
    }

    const totalRecords = await db.eventTemplate.count()

    const response = await db.eventTemplate.findMany({
      ...(!all && { take: limit }),
      ...(!all && { skip: offset }),
      where: whereCondition,
    })

    return NextResponse.json(
      {
        message: successMessages.success,
        templateList: response,
        totalRecords,
      },
      { status: 200 },
    )
  } catch (error) {
    let errorMessage = errorMessages.DEFAULT_ERROR

    if (error instanceof Error) {
      errorMessage = error.message
    }

    return NextResponse.json({ error: errorMessage }, { status: 404 })
  }
}

export async function DELETE(req: Request) {
  try {
    const url = new URL(req.url)

    const templateId = url.searchParams.get('templateId')

    if (!templateId) {
      throw new Error(errorMessages.NO_DATA_FOUND)
    }

    await db.eventTemplate.delete({
      where: {
        templateId: +templateId,
      },
    })

    return NextResponse.json(
      { message: successMessages.requestSuccess },
      { status: 201 },
    )
  } catch (error) {
    return NextResponse.json(
      { error: errorMessages.DEFAULT_ERROR },
      { status: 404 },
    )
  }
}
