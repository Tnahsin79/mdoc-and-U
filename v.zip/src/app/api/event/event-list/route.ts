import { db } from '@/lib/db'
import { getUserDetails } from '@/utils/authUtils'
import { paginationLimit } from '@/utils/constants/common'
import { errorMessages } from '@/utils/errorMessages'
import { successMessages } from '@/utils/successMessages'
import { Role } from '@prisma/client'
import { NextRequest, NextResponse } from 'next/server'

export async function POST(req: NextRequest) {
  try {
    const limit = paginationLimit
    const body = await req.json()
    const page = body?.page || 1
    const searchQuery = body?.search || ''
    const futureEvents = body?.futureEvents || false
    const offset = (page - 1) * limit
    const suitableCollaboratorId = body.suitableCollaboratorId

    const remainingParticipation = body?.remainingParticipation

    const candId = body?.candidateId

    const user = getUserDetails()

    let whereCondition: any = {}

    const today = new Date().toISOString()

    if (searchQuery && futureEvents) {
      whereCondition = {
        title: {
          contains: searchQuery,
          mode: 'insensitive',
        },
        bookedFrom: {
          gt: today,
        },
      }
    } else if (futureEvents) {
      whereCondition = {
        bookedFrom: {
          gt: today,
        },
      }
    } else if (searchQuery) {
      whereCondition.title = {
        contains: searchQuery,
        mode: 'insensitive',
      }
    }

    if (user.role === Role.Collaborator) {
      whereCondition = {
        ...whereCondition,
        OR: [
          {
            EventCollaborator: {
              some: {
                collaboratorId: { equals: +suitableCollaboratorId },
              },
            },
          },
          {
            suitableCollaboratorId: {
              equals: +suitableCollaboratorId,
            },
          },
        ],
      }
    }

    if (user.role === Role.Candidate) {
      whereCondition = {
        ...whereCondition,
        EventAssignees: {
          some: {
            attendeeId: { equals: +candId },
          },
        },
      }
    }

    if (remainingParticipation) {
      whereCondition = {
        ...whereCondition,
        participantsAttachment: { equals: null}
      }
    }

    const totalRecords = await db.event.count({ where: whereCondition })

    const response = await db.event.findMany({
      include: {
        phase: true,
        suitableRooms: true,
        location: true,
        EventCollaborator: true,
      },
      where: whereCondition,
      take: limit,
      skip: offset,
      orderBy: {
        bookedFrom: 'asc',
      },
    })

    return NextResponse.json(
      { message: successMessages.success, eventList: response, totalRecords },
      { status: 200 },
    )
  } catch (error) {
    return NextResponse.json(
      { error: errorMessages.DEFAULT_ERROR },
      { status: 500 },
    )
  }
}
