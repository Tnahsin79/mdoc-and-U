/**
 * @swagger
 * /api/event/{eventId}:
 *   put:
 *     summary: Edit an existing event
 *     description: Endpoint to edit an existing event.
 *     tags:
 *      - Event
 *     parameters:
 *       - in: path
 *         name: eventId
 *         required: true
 *         description: ID of the event to be updated
 *         schema:
 *           type: integer
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               templateId:
 *                 type: number
 *               subjectAreaId:
 *                 type: number
 *               subjectModule:
 *                 type: string
 *               eventTypeId:
 *                 type: number
 *               phase:
 *                 type: string
 *               title:
 *                 type: string
 *               minParticipants:
 *                 type: number
 *               maxParticipants:
 *                 type: number
 *               description:
 *                 type: string
 *               eventManner:
 *                 type: string
 *               accessLink:
 *                 type: string
 *               eventStatus:
 *                 type: number
 *               reason:
 *                 type: string
 *               eventDate:
 *                 type: string
 *                 format: date
 *               bookedFrom:
 *                 type: string
 *                 format: date-time
 *               bookedTo:
 *                 type: string
 *                 format: date-time
 *               startTime:
 *                 type: string
 *                 format: time
 *               endTime:
 *                 type: string
 *                 format: time
 *               eventRepeats:
 *                 type: string
 *                 nullable: true
 *               lmsLink:
 *                 type: string
 *               locationId:
 *                 type: number
 *               barrierFreeAccess:
 *                 type: boolean
 *                 nullable: true
 *               suitableRoomId:
 *                 type: number
 *                 nullable: true
 *               equipmentId:
 *                 type: array
 *                 items:
 *                   type: number
 *               suitableCollaboratorId:
 *                 type: number
 *               attendees:
 *                 type: number
 *     responses:
 *       200:
 *         description: Event updated successfully
 *       400:
 *         description: Invalid input or missing parameters
 *       404:
 *         description: Event not found
 */
