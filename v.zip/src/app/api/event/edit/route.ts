import { PrismaClientKnownRequestError } from '@prisma/client/runtime/library'
import { NextResponse } from 'next/server'
import { Event } from '@prisma/client'

import { db } from '@/lib/db'
import { errorMessages, prismaErrorCode } from '@/utils/errorMessages'
import { successMessages } from '@/utils/successMessages'
import { IEditEventRequestBody } from '@/interface/event'
import { editEventSchema } from '@/validators/schemas/event'
import sendEmail from '@/utils/sendMail'
import { actionTemplate } from '@/utils/EmailTemplates/action'

export async function PUT(req: Request) {
  try {
    const parsed = editEventSchema.safeParse(await req.json())

    if (!parsed.success) {
      const errorMessage =
        parsed.error.issues[0]?.message || errorMessages.DEFAULT_ERROR
      return NextResponse.json({ error: errorMessage }, { status: 400 })
    }

    const body: IEditEventRequestBody = parsed.data

    const {
      templateId,
      subjectAreaId,
      subjectModule,
      eventTypeId,
      phaseId,
      title,
      minParticipants,
      maxParticipants,
      description,
      eventManner,
      accessLink,
      eventStatus,
      reason,
      bookedFrom,
      bookedTo,
      startTime,
      endTime,
      eventRepeatId,
      lmsLink,
      locationId,
      barrierFreeAccess,
      suitableRoomId,
      suitableCollaboratorId,
      attendeesId,
      eventId,
      equipmentId,
      eventKey,
    } = body

    const dataToBeUpdated: Omit<
      Event,
      'eventId' | 'createdAt' | 'participantsAttachment'
    > = {
      templateId: templateId ?? null,
      subjectAreaId: subjectAreaId,
      subjectModule,
      eventTypeId: eventTypeId,
      phaseId: phaseId,
      title: title,
      minParticipants,
      maxParticipants,
      description: description,
      eventManner,
      accessLink: accessLink ?? null,
      eventStatusId: eventStatus,
      reason: reason || '',
      bookedFrom,
      bookedTo: bookedTo ?? null,
      startTime,
      endTime,
      eventRepeatId: eventRepeatId ?? null,
      lmsLink: lmsLink ?? null,
      locationId: locationId ?? null,
      barrierFreeAccess: barrierFreeAccess ?? null,
      suitableRoomsId: suitableRoomId ?? null,
      suitableCollaboratorId: suitableCollaboratorId,
      eventKey: eventKey,
    }

    const existingEvent = await db.event.findUnique({
      where: { eventId: eventId },
      select: { equipmentId: true, suitableCollaboratorId: true },
    })

    if (!existingEvent) {
      return NextResponse.json(
        { error: errorMessages.EVENT_NOT_FOUND },
        { status: 404 },
      )
    }

    await db.eventAttendees.deleteMany({
      where: {
        eventId: eventId,
      },
    })

    await db.event.update({
      where: { eventId: eventId },
      data: dataToBeUpdated,
    })

    await db.eventAttendees.createMany({
      data: attendeesId?.map((item) => {
        const [type, id] = item.split('_')
        return {
          eventId: eventId,
          attendeeId: +id,
          moduleName: type,
        }
      }),
    })

    if (suitableCollaboratorId !== existingEvent.suitableCollaboratorId) {
      const collaborator = await db.person.findFirst({
        where: {
          personId: +suitableCollaboratorId,
        },
        select: {
          email: true,
        },
      })

      const url =
        process.env.APP_DEV_URL ?? process.env.APP_PROD_URL ?? 'localhost:3000'
      const text = 'You have been Assigned to the Event, Event Details'
      const html = actionTemplate(url, text)

      await sendEmail({
        to: collaborator?.email as string,
        subject: 'Assigned to the Event',
        html: html,
      })
    }

    const candidateIds = attendeesId
      .map((item) => {
        const [type, id] = item.split('_')
        if (type === 'Candidate') {
          return +id
        }
      })
      .filter((item) => item !== undefined)
    if (candidateIds.length > 0) {
      const candidateEmails = await db.person.findMany({
        where: {
          personId: {
            in: candidateIds as number[],
          },
        },
        select: {
          email: true,
        },
      })

      await Promise.allSettled(
        candidateEmails.map((candidate) => {
          const url =
            process.env.APP_DEV_URL ??
            process.env.APP_PROD_URL ??
            'localhost:3000'
          const text = 'You have been Assigned to the Event, Event Details'
          const html = actionTemplate(url, text)

          sendEmail({
            to: candidate.email,
            subject: 'Assigned to the Event',
            html: html,
          })
        }),
      )
    }

    const existingEquipmentIds = existingEvent.equipmentId.map(
      (equip) => equip.listId,
    )

    const equipmentToAdd =
      equipmentId?.length > 0
        ? equipmentId?.filter(
            (id: number) => !existingEquipmentIds.includes(id),
          )
        : []

    const equipmentToRemove =
      existingEquipmentIds?.length > 0
        ? existingEquipmentIds.filter((id: number) => !equipmentId.includes(id))
        : []

    for (const eqId of equipmentToRemove) {
      await db.listEquipment.delete({
        where: {
          eventId_listId: {
            eventId: eventId,
            listId: eqId,
          },
        },
      })
    }

    for (const eqId of equipmentToAdd) {
      await db.listEquipment.create({
        data: {
          eventId: eventId,
          listId: eqId,
        },
      })
    }

    return NextResponse.json(
      { message: successMessages.eventUpdated },
      { status: 200 },
    )
  } catch (error) {
    let errorMessage = errorMessages.DEFAULT_ERROR
    if (error instanceof PrismaClientKnownRequestError) {
      if (error.code === prismaErrorCode.UNIQUE_CONSTRAINT_FAILED) {
        errorMessage = errorMessages.DUPLICATE_EVENT
      } else {
        errorMessage = error.message
      }
    }

    return NextResponse.json({ error: errorMessage }, { status: 500 })
  }
}
