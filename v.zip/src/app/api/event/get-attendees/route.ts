import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { errorMessages } from '@/utils/errorMessages'
import { Role } from '@prisma/client'

export async function GET() {
  try {
    const group = await db.group.findMany({})
    const candidatesAndCollaborators = await db.person.findMany({
      where: {
        OR: [
          {
            role: Role.Candidate,
            isActive: true,
          },
          {
            role: Role.Collaborator,
            isActive: true,
          },
        ],
      },
      select: {
        personId: true,
        email: true,
        firstName: true,
        lastName: true,
        role: true,
      },
    })

    if (!group) {
      return NextResponse.json(
        { error: errorMessages.ATTENDEES_NOT_FOUND },
        { status: 404 },
      )
    }

    return NextResponse.json(
      { group: group, persons: candidatesAndCollaborators },
      { status: 200 },
    )
  } catch (error) {
    return NextResponse.json(
      { error: errorMessages.DEFAULT_ERROR },
      { status: 500 },
    )
  }
}
