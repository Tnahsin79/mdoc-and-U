import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { errorMessages } from '@/utils/errorMessages'
import { successMessages } from '@/utils/successMessages'

interface contextProps {
  params: {
    eventId: string
  }
}

export async function GET(req: Request, context: contextProps) {
  try {
    const { params } = context
    const { eventId } = params

    if (!eventId) {
      return NextResponse.json(
        { error: errorMessages.NO_DATA_FOUND },
        { status: 400 },
      )
    }

    const event = await db.event.findUnique({
      where: { eventId: +eventId },
      include: {
        equipmentId: {
          select: {
            list: {
              select: {
                listType: true,
                listId: true,
                listValue: true,
              },
            },
          },
        },
        template: true,
        subjectArea: true,
        eventType: true,
        location: true,
        suitableRooms: true,
        suitableCollaborators: true,
        eventRepeats: true,
        phase: true,
        eventStatus: true,
      },
    })

    const attendees = await db.eventAttendees.findMany({
      where: {
        eventId: +eventId,
      },
    })

    const collaboratorsAsAttendees = await db.eventCollaborator.findMany({
      where: {
        eventId: +eventId,
      },
      select: {
        collaboratorId: true,
      },
    })

    const presentStatus = await db.eventCollaboratorAttendees.findMany({
      where: {
        eventId: +eventId,
      },
      select: {
        Candidate: {
          select: {
            personId: true,
            firstName: true,
            lastName: true,
            email: true,
          },
        },
      },
    })

    if (!event) {
      return NextResponse.json(
        { error: errorMessages.EVENT_NOT_FOUND },
        { status: 404 },
      )
    }

    return NextResponse.json(
      {
        event: { ...event, attendees },
        presentStatus: presentStatus,
        collaboratorsAsAttendees: collaboratorsAsAttendees,
      },
      { status: 200 },
    )
  } catch (error) {
    return NextResponse.json(
      { error: errorMessages.DEFAULT_ERROR },
      { status: 500 },
    )
  }
}

export async function POST(req: Request, context: contextProps) {
  try {
    const { params } = context
    const { eventId } = params

    const body = await req.json()
    const { attachment } = body

    await db.event.update({
      where: {
        eventId: +eventId,
      },
      data: {
        participantsAttachment: attachment,
      },
    })

    return NextResponse.json(
      { message: successMessages.success },
      { status: 201 },
    )
  } catch (error) {
    return NextResponse.json(
      { error: errorMessages.DEFAULT_ERROR },
      { status: 500 },
    )
  }
}
