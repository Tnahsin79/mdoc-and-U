/**
 * @swagger
 * /api/event/{id}:
 *   get:
 *     summary: Retrieve a specific event by its ID.
 *     description: Returns detailed information about the event identified by the given ID.
 *     tags:
 *       - Event
 *     parameters:
 *       - in: path
 *         name: id
 *         schema:
 *           type: string
 *         required: true
 *         description: Unique identifier of the event.
 *     responses:
 *       200:
 *         description: Successful response with the event details.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Event'
 *       404:
 *         description: Event not found.
 */

/**
 * @swagger
 * components:
 *   schemas:
 *     Event:
 *       type: object
 *       properties:
 *         event:
 *           type: object
 *           properties:
 *             eventId:
 *               type: integer
 *             templateId:
 *               type: integer
 *             title:
 *               type: string
 *             subject_area_id:
 *               type: integer
 *             subject_module:
 *               type: string
 *             eventTypeId:
 *               type: integer
 *             eventStatusId:
 *               type: integer
 *             reason:
 *               type: string
 *             phase:
 *               type: string
 *             event_manner:
 *               type: string
 *             description:
 *               type: string
 *             booked_from:
 *               type: string
 *               format: date-time
 *             booked_to:
 *               type: string
 *               format: date-time
 *             start_time:
 *               type: string
 *               format: date-time
 *             end_time:
 *               type: string
 *               format: date-time
 *             event_repeats:
 *               type: string
 *               nullable: true
 *             min_participants:
 *               type: integer
 *             max_participants:
 *               type: integer
 *             lms_link:
 *               type: string
 *               format: uri
 *             access_link:
 *               type: string
 *               format: uri
 *             locationId:
 *               type: integer
 *               nullable: true
 *             barrier_free_access:
 *               type: boolean
 *               nullable: true
 *             suitableRoomsId:
 *               type: integer
 *               nullable: true
 *             suitable_collaborators_id:
 *               type: integer
 *             attendees:
 *               type: integer
 *             equipmentId:
 *               type: array
 *               items:
 *                 type: integer
 *             template:
 *               $ref: '#/components/schemas/ListType'
 *             subject_area:
 *               $ref: '#/components/schemas/ListType'
 *             event_type:
 *               $ref: '#/components/schemas/ListType'
 *             location:
 *               type: string
 *               nullable: true
 *             suitable_rooms:
 *               type: string
 *               nullable: true
 *             suitable_collaborators:
 *               $ref: '#/components/schemas/ListType'
 *     ListType:
 *       type: object
 *       properties:
 *         listId:
 *           type: integer
 *         listType:
 *           type: string
 *         listValue:
 *           type: string
 *         isActive:
 *           type: boolean
 *       required:
 *         - listId
 *         - listType
 *         - listValue
 *         - isActive
 */
