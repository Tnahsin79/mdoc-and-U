import jwt, { JwtPayload } from 'jsonwebtoken'

import { NextResponse } from 'next/server'
import { cookies } from 'next/headers'

import {
  generateAccessToken,
  generateRefreshToken,
  setAccessTokenCookie,
  setRefreshTokenCookie,
} from '@/utils/authUtils'
import { errorMessages } from '@/utils/errorMessages'
import { successMessages } from '@/utils/successMessages'

export async function GET() {
  try {
    const cookieStore = cookies()
    const refreshToken = cookieStore.get('refreshToken')?.value

    if (refreshToken === undefined) {
      throw new Error(errorMessages.INVALID_TOKEN)
    }

    const JWTSecretKey: string = process.env.JWT_SECRET_KEY || 'ttmp-project'
    const decoded: string | JwtPayload = jwt.verify(refreshToken, JWTSecretKey)

    if (!(typeof decoded === 'object' && 'email' in decoded)) {
      throw new Error(errorMessages.INVALID_TOKEN)
    } else {
      const accessToken = generateAccessToken(decoded.email, decoded.role, decoded.subjectAdmin, decoded.subjectSupervision, decoded.householdAdmin, decoded.departmentLead)
      const refreshToken = generateRefreshToken(decoded.email, decoded.role, decoded.subjectAdmin, decoded.subjectSupervision, decoded.householdAdmin, decoded.departmentLead)

      setAccessTokenCookie(accessToken)
      setRefreshTokenCookie(refreshToken)

      return NextResponse.json(
        {
          message: successMessages.refreshedToken,
        },
        { status: 200 },
      )
    }
  } catch (error) {
    const errorMessage =
      error instanceof Error ? error.message : errorMessages.DEFAULT_ERROR

    return NextResponse.json({ error: errorMessage }, { status: 500 })
  }
}
