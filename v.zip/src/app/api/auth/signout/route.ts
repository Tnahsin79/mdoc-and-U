import { cookies } from 'next/headers'
import { NextResponse } from 'next/server'
import { errorMessages } from '@/utils/errorMessages'
import { successMessages } from '@/utils/successMessages'

export async function POST() {
  try {
    cookies().set('refreshToken', '', {
      path: '/api/auth/refresh',
      httpOnly: true,
      maxAge: 0,
    })

    cookies().set('accessToken', '', {
      path: '/',
      httpOnly: false,
      maxAge: 0,
    })

    return NextResponse.json(
      {
        message: successMessages.loggedOut,
      },
      {
        status: 200,
      },
    )
  } catch (error) {
    const errorMessage =
      error instanceof Error ? error.message : errorMessages.DEFAULT_ERROR

    return NextResponse.json({ error: errorMessage }, { status: 404 })
  }
}
