import jwt, { JwtPayload } from 'jsonwebtoken'
import { cookies } from 'next/headers'
import { NextResponse } from 'next/server'
import { errorMessages } from '@/utils/errorMessages'
import { successMessages } from '@/utils/successMessages'
import { db } from '@/lib/db'

export async function GET() {
  try {
    const cookieStore = cookies()
    const accessToken = cookieStore.get('accessToken')?.value
    if (!accessToken) {
      throw new Error(errorMessages.INVALID_TOKEN)
    }

    const JWTSecretKey: string = process.env.JWT_SECRET_KEY || 'ttmp-project'
    const decodedAccessToken: string | JwtPayload = jwt.verify(
      accessToken,
      JWTSecretKey,
    )

    if (
      !(typeof decodedAccessToken === 'object' && 'email' in decodedAccessToken)
    ) {
      throw new Error(errorMessages.INVALID_TOKEN)
    } else {
      const person = await db.person.findFirst({
        where: {
          email: decodedAccessToken.email.toLowerCase(),
          isActive: true,
        },
        select: {
          role: true,
          personId: true,
          firstName: true,
          lastName: true,
          email: true,
          subjectAdmin: true,
          subjectSupervision: true,
          householdAdmin: true,
          departmentLead: true,
          collaborator: {
            select: {
              collaboratorId: true,
            },
          },
          person: {
            select: {
              candidateId: true,
            },
          },
        },
      })

      if (!person) {
        throw new Error(errorMessages.NOT_AUTHORIZED)
      }

      return NextResponse.json(
        {
          message: successMessages.success,
          person: {
            role: person.role,
            personId: person.personId,
            firstName: person.firstName,
            lastName: person.lastName,
            email: person.email,
            collaboratorId: person.collaborator?.collaboratorId,
            candidateId: person.person?.candidateId,
            subjectAdmin: person.subjectAdmin,
            subjectSupervision: person.subjectSupervision,
            householdAdmin: person.householdAdmin,
            departmentLead: person.departmentLead,
          },
        },
        { status: 200 },
      )
    }
  } catch (error) {
    const errorMessage =
      error instanceof Error ? error.message : errorMessages.UNAUTHORIZED

    return NextResponse.json({ error: errorMessage }, { status: 401 })
  }
}
