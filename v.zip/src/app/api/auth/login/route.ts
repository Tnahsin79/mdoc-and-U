import bcrypt from 'bcrypt'

import { db } from '@/lib/db'
import { NextResponse } from 'next/server'
import {
  generateAccessToken,
  generateRefreshToken,
  setAccessTokenCookie,
  setRefreshTokenCookie,
} from '@/utils/authUtils'
import { errorMessages } from '@/utils/errorMessages'
import { successMessages } from '@/utils/successMessages'

export async function POST(req: Request) {
  try {
    const body: { email: string; password: string; rememberMe: boolean } =
      await req.json()
    const { email, password, rememberMe } = body

    const person = await db.person.findUnique({
      where: { email: email.toLowerCase(), isActive: true },
      select: {
        role: true,
        personId: true,
        firstName: true,
        lastName: true,
        email: true,
        password: true,
        subjectAdmin: true,
        subjectSupervision: true,
        householdAdmin: true,
        departmentLead: true,
        collaborator: {
          select: {
            collaboratorId: true,
          },
        },
        person: {
          select: {
            candidateId: true,
          },
        },
      },
    })

    if (!person || !person.password) {
      throw new Error(errorMessages.INCORRECT_CREDENTIALS)
    }

    const verified = await bcrypt.compare(password, person.password)
    if (!verified) {
      throw new Error(errorMessages.INCORRECT_CREDENTIALS)
    }

    const accessToken = generateAccessToken(email, person.role, person.subjectAdmin, person.subjectSupervision, person.householdAdmin, person.departmentLead)
    setAccessTokenCookie(accessToken)

    if (rememberMe) {
      const refreshToken = generateRefreshToken(email, person.role, person.subjectAdmin, person.subjectSupervision, person.householdAdmin, person.departmentLead)
      setRefreshTokenCookie(refreshToken)
    }

    return NextResponse.json(
      {
        message: successMessages.loggedIn,
        person: {
          role: person.role,
          personId: person.personId,
          firstName: person.firstName,
          lastName: person.lastName,
          email: person.email,
          collaboratorId: person.collaborator?.collaboratorId,
          subjectAdmin: person.subjectAdmin,
          subjectSupervision: person.subjectSupervision,
          householdAdmin: person.householdAdmin,
          departmentLead: person.departmentLead,
        },
      },
      {
        status: 200,
      },
    )
  } catch (error) {
    const errorMessage =
      error instanceof Error ? error.message : errorMessages.DEFAULT_ERROR

    return NextResponse.json({ error: errorMessage }, { status: 404 })
  }
}
