import { NextResponse } from 'next/server'
import crypto from 'crypto'

import { db } from '@/lib/db'
import { errorMessages } from '@/utils/errorMessages'
import { successMessages } from '@/utils/successMessages'
import sendEmail from '@/utils/sendMail'
import { forgotPassword } from '@/utils/EmailTemplates/forgotPassword'

export async function POST(req: Request) {
  try {
    const body: { email: string } = await req.json()
    const { email } = body

    const person = await db.person.findUnique({
      where: { email: email, isActive: true },
    })

    if (!person) {
      throw new Error(errorMessages.IF_USER_EXISTS_WE_HAVE_SENT_YOU_MAIL)
    }

    const token = crypto.randomBytes(32).toString('hex')
    const tokenExpiration = new Date()
    tokenExpiration.setDate(tokenExpiration.getDate() + 3)

    await db.person.update({
      where: { email: email },
      data: {
        resetPasswordToken: token,
        resetPasswordTokenExpiry: tokenExpiration,
      },
    })

    const url =
      process.env.NODE_ENV !== 'production'
        ? `${process.env.APP_DEV_URL}/reset-password?token=${token}`
        : `${process.env.APP_PROD_URL}/reset-password?token=${token}`
    
    const html = forgotPassword(url)    

    await sendEmail({
      to: email,
      subject: `${successMessages.resetYourPassword}`,
      html: html
    })



    return NextResponse.json(
      {
        message: successMessages.forgotPasswordLinkSent,
        token: token,
        tokenExpiration: tokenExpiration,
        url: url,
      },
      { status: 200 },
    )
  } catch (error: any) {
    if (error.message === errorMessages.IF_USER_EXISTS_WE_HAVE_SENT_YOU_MAIL) {
      return NextResponse.json({ error: error.message }, { status: 406 })
    }
    const errorMessage =
      error instanceof Error ? error.message : errorMessages.DEFAULT_ERROR
    return NextResponse.json({ error: errorMessage }, { status: 404 })
  }
}
