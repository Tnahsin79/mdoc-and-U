import { NextResponse } from 'next/server'
import bcrypt from 'bcrypt'

import { db } from '@/lib/db'
import { errorMessages } from '@/utils/errorMessages'
import { successMessages } from '@/utils/successMessages'
import { saltRounds } from '@/utils/constants/common'

export async function POST(req: Request) {
  try {
    const body: { token: string; newPassword: string } = await req.json()
    const { token, newPassword } = body

    const person = await db.person.findFirst({
      where: { resetPasswordToken: token, isActive: true },
    })

    if (!person) {
      throw new Error(errorMessages.USER_NOT_FOUND)
    }

    const tokenExpired = new Date() > new Date(person.resetPasswordTokenExpiry!)

    if (tokenExpired) {
      throw new Error(errorMessages.INVALID_TOKEN)
    }

    const hashedPassword = await bcrypt.hash(newPassword, +saltRounds)

    await db.person.update({
      where: { email: person.email.toLowerCase() },
      data: { password: hashedPassword },
    })

    return NextResponse.json(
      { message: successMessages.passwordUpdated },
      { status: 200 },
    )
  } catch (error) {
    const errorMessage =
      error instanceof Error ? error.message : errorMessages.DEFAULT_ERROR
    return NextResponse.json({ error: errorMessage }, { status: 404 })
  }
}
