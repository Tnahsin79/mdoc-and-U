import { db } from '@/lib/db'
import { NextResponse } from 'next/server'
import { successMessages } from '@/utils/successMessages'
import { errorMessages, prismaErrorCode } from '@/utils/errorMessages'
import { PrismaClientKnownRequestError } from '@prisma/client/runtime/library'
import { Candidate, Person } from '@prisma/client'
import { cookies } from 'next/headers'
import jwt, { JwtPayload } from 'jsonwebtoken'
import { getUserDetails } from '@/utils/authUtils'

interface contextProps {
  params: {
    candidateId: string
  }
}

export interface IUpdateCandidate extends Candidate, Person {
  phasePreference: {
    kickOff: boolean
    firstStep: boolean
    setUp: boolean
    studies: boolean
  }
}

interface transactionFunctionProps {
  data: IUpdateCandidate
  person: Person
  candidateId: string
}

function updateCandidate({
  data,
  person,
  candidateId,
}: transactionFunctionProps) {
  return db.$transaction(async (tx) => {
    const updatedCandidate = await tx.candidate.update({
      where: {
        candidateId: +candidateId,
      },
      data: {
        streetAndHouseNo: data.streetAndHouseNo,
        city: data.city,
        yearGroupId: data.yearGroupId,
        teachingPositionId: data.teachingPositionId,
        startSchoolYear: data.startSchoolYear,
        phaseRequiredId: data.phaseRequiredId,
        kickOffGroupId: data.kickOffGroupId,
        longerAbsenceReasonId: data.longerAbsenceReasonId,
        firstRecognisedSubjectId: data.firstRecognisedSubjectId,
        secondRecognisedSubjectId: data.secondRecognisedSubjectId,
        thirdRecognisedSubjectId: data.thirdRecognisedSubjectId,
        firstSubjectToBeStudiedId: data.firstSubjectToBeStudiedId,
        secondSubjectToBeStudiedId: data.secondSubjectToBeStudiedId,
        subjectChangeFromId: data.subjectChangeFromId,
        subjectChangeToId: data.subjectChangeToId,
        schoolId: data.schoolId,
        untilDate: data.untilDate,
        fromDate: data.fromDate,
        startOfContract: data.startOfContract,
        bbvdStart: data.bbvdStart,
        bbstStart: data.bbstStart,
        recognisedSubject: data.recognisedSubject,
        document: data.document,
        studiesGroupSubjectAId: data.studiesGroupSubjectAId,
        studiesGroupSubjectBId: data.studiesGroupSubjectBId,
        startSubjectAId: data.startSubjectAId,
        startSubjectBId: data.startSubjectBId,
      },
    })

    const updatedPerson = await tx.person.update({
      where: {
        personId: updatedCandidate.personId,
      },
      data: {
        title: data.title ?? person.title,
        firstName: data.firstName,
        lastName: data.lastName,
        email: data.email.toLowerCase(),
        phoneNumber: data.phoneNumber,
        postalCode: data.postalCode,
        appellationId: data.appellationId,
      },
    })

    await tx.history.create({
      data: {
        actionType: 'Master Data changed',
        actionDetail: 'Master Data changed',
        actionReference: 'Data',
        personId: updatedCandidate.personId,
      },
    })

    return { updatedCandidate: updatedCandidate, updatedPerson: updatedPerson }
  })
}

function flattenObject(obj: any, parentKey = '') {
  const result: any = {}

  for (const key in obj) {
    if (obj.hasOwnProperty(key)) {
      const newKey =
        parentKey && parentKey !== 'person' ? `${parentKey}_${key}` : key

      if (
        typeof obj[key] === 'object' &&
        !Array.isArray(obj[key]) &&
        !(obj[key] instanceof Date)
      ) {
        Object.assign(result, flattenObject(obj[key], key))
      } else {
        result[newKey] = obj[key]
      }
    }
  }

  return result
}

export async function GET(req: Request, context: contextProps) {
  try {
    const { params } = context
    const { candidateId } = params

    if (!candidateId) {
      throw new Error(errorMessages.NO_DATA_FOUND)
    }

    const userDetails = getUserDetails()
    const canSeeComments = userDetails.role === 'Employee'

    const candidate = await db.candidate.findUnique({
      where: {
        candidateId: +candidateId,
      },
      select: {
        candidateId: true,
        person: true,
        streetAndHouseNo: true,
        houseNumber: true,
        city: true,
        longerAbsenceReasonId: true,
        teachingPositionId: true,
        startSchoolYear: true,
        yearGroupId: true,
        phaseRequiredId: true,
        kickOffGroupId: true,
        firstRecognisedSubjectId: true,
        secondRecognisedSubjectId: true,
        thirdRecognisedSubjectId: true,
        firstSubjectToBeStudiedId: true,
        secondSubjectToBeStudiedId: true,
        subjectChangeFromId: true,
        subjectChangeToId: true,
        document: true,
        comments: canSeeComments,
        schoolId: true,
        fromDate: true,
        untilDate: true,
        batch: true,
        batchId: true,
        startOfContract: true,
        mentor: true,
        mentorId: true,
        bbvdStart: true,
        bbstStart: true,
        correct: true,
        recognisedSubject: true,
        studiesGroupSubjectAId: true,
        studiesGroupSubjectBId: true,
        startSubjectAId: true,
        startSubjectBId: true,
      },
    })

    if (!candidate) {
      throw new Error(errorMessages.NO_DATA_FOUND)
    }

    return NextResponse.json(
      {
        candidate: {
          ...flattenObject(candidate),
          document: candidate.document
            ? {
                fileName: candidate.document,
              }
            : null,
        },
        message: successMessages.success,
      },
      { status: 200 },
    )
  } catch (error) {
    let errorMessage = errorMessages.DEFAULT_ERROR

    if (error instanceof Error) {
      errorMessage = error.message
    }

    return NextResponse.json({ error: errorMessage }, { status: 404 })
  }
}

export async function POST(req: Request, context: contextProps) {
  try {
    const userDetails = getUserDetails()
    const canEditCandidate =
      userDetails.roles.includes('subjectAdmin') ||
      userDetails.roles.includes('subjectSupervision') || 
      userDetails.role === 'Candidate'

    if (!canEditCandidate) {
      throw new Error('Not Authorized')
    }

    const { params } = context
    const { candidateId } = params

    const body = await req.json()

    let person = undefined

    const cookieStore = cookies()
    const accessToken = cookieStore.get('accessToken')?.value
    if (!accessToken) {
      throw new Error(errorMessages.INVALID_TOKEN)
    }

    const JWTSecretKey: string = process.env.JWT_SECRET_KEY || 'ttmp-project'
    const decodedAccessToken: string | JwtPayload = jwt.verify(
      accessToken,
      JWTSecretKey,
    )

    if (
      !(typeof decodedAccessToken === 'object' && 'email' in decodedAccessToken)
    ) {
      throw new Error(errorMessages.INVALID_TOKEN)
    } else {
      person = await db.person.findFirst({
        where: {
          email: decodedAccessToken.email.toLowerCase(),
        },
      })

      if (!person) {
        throw new Error('Not Authorized')
      }
    }

    const { ...data }: IUpdateCandidate = body

    const { updatedCandidate, updatedPerson } = await updateCandidate({
      data,
      person,
      candidateId,
    })

    return NextResponse.json(
      {
        message: successMessages.success,
        candidate: {
          ...updatedCandidate,
          person: {
            firstName: updatedPerson.firstName,
            lastName: updatedPerson.lastName,
            postalCode: updatedPerson.postalCode,
            phoneNumber: updatedPerson.phoneNumber,
            email: updatedPerson.email,
          },
        },
      },
      { status: 200 },
    )
  } catch (error) {
    let errorMessage = errorMessages.DEFAULT_ERROR

    if (
      error instanceof PrismaClientKnownRequestError &&
      error.code === prismaErrorCode.RECORD_NOT_FOUND
    ) {
      errorMessage = errorMessages.RECORD_NOT_FOUND
    } else if (error instanceof Error) {
      errorMessage = error.message
    }

    return NextResponse.json({ error: errorMessage }, { status: 400 })
  }
}
