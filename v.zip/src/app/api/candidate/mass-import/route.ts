import moment from 'moment'
import { NextResponse } from 'next/server'
import { PrismaClientKnownRequestError } from '@prisma/client/runtime/library'
import { Candidate } from '@prisma/client'
import { db } from '@/lib/db'
import { phasesOptions } from '@/utils/constants/common'
import { errorMessages, prismaErrorCode } from '@/utils/errorMessages'
import { IMassImportCandidate } from '@/interface/candidate'
import { successMessages } from '@/utils/successMessages'
import { getUserDetails } from '@/utils/authUtils'
const optionalFields = [
  'Title',
  'Longer absence reason',
  'From date',
  'Until date',
  'Second recognised subject',
  'Third recognised subject',
  'First subject to be studied',
  'Second subject to be studied',
  'Subject change from',
  'Subject change to',
  'Comments',
  'Year group',
  'KickOff group',
]

function validateCandidates(candidates: IMassImportCandidate[]) {
  const validCandidates: IMassImportCandidate[] = []
  let error = ''

  for (const candidate of candidates) {
    let isEmpty = true
    let hasEmptyField = false
    for (const [key, value] of Object.entries(candidate)) {
      if (
        value !== null &&
        value !== undefined &&
        value.toString().trim() !== '' &&
        !optionalFields.includes(key)
      ) {
        isEmpty = false
      } else if (
        (value === null ||
          value === undefined ||
          value.toString().trim() === '') &&
        !optionalFields.includes(key)
      ) {
        hasEmptyField = true
      }
    }
    if (isEmpty) {
      continue
    }
    if (hasEmptyField) {
      error = 'Some fields are missing in one of the rows.'
      return { valid: false, error }
    }
    validCandidates.push(candidate)
  }
  return { valid: true, validCandidates }
}

const toBoolean = (value: any, candidate: IMassImportCandidate) => {
  if (typeof value === 'string') {
    if (value.toLowerCase() === 'true') return true
    if (value.toLowerCase() === 'false') return false
    if (value === '0') return false
    if (value === '1') return true
  }
  if (typeof value === 'number') {
    if (value === 0) return false
    if (value === 1) return true
  }
  if (typeof value === 'boolean') return value
  throw new Error(
    `${errorMessages.INVALID_PHASE_FOR_CANDIDATE} : ${candidate['First name']} ${candidate['Last name']}`,
  )
}

function getPhaseRequiredId(
  candidate: IMassImportCandidate,
  phasesOptions: any,
) {
  for (const option of phasesOptions) {
    if (
      option.kickOff === toBoolean(candidate['Kick-Off'], candidate) &&
      option.firstStep === toBoolean(candidate['First-Steps'], candidate) &&
      option.setUp === toBoolean(candidate['Set-Up'], candidate) &&
      option.studies === toBoolean(candidate['Studies'], candidate)
    ) {
      return option.id
    }
  }
  return null
}

const keyMapping: { [candidateKey: string]: string } = {
  Title: 'title',
  Appellation: 'appellation',
  'Longer absence reason': 'longerAbsenceReason',
  'Teaching position': 'teachingPosition',
  'Year group': 'yearGroup',
  'KickOff group': 'kickOffGroup',
  'First recognised subject': 'firstRecognisedSubject',
  'Second recognised subject': 'secondRecognisedSubject',
  'Third recognised subject': 'thirdRecognisedSubject',
  'First subject to be studied': 'firstSubjectToBeStudied',
  'Second subject to be studied': 'secondSubjectToBeStudied',
  'Subject change from': 'subjectChangeFrom',
  'Subject change to': 'subjectChangeTo',
}

let errorFieldValues: string[] = []
let duplicateInputEmails: string[] = []

export async function POST(req: Request) {
  let validCandidates: any
  try {
    const userDetails = getUserDetails()
    const canMassImport =
      userDetails.roles.includes('subjectAdmin') ||
      userDetails.roles.includes('subejctSupervision')

    if (!canMassImport) {
      throw new Error('Not Authorized')
    }

    const body = await req.json()
    const candidates: IMassImportCandidate[] = body
    const candidatesToCreate: Omit<
      Candidate,
      | 'candidateId'
      | 'houseNumber'
      | 'recognisedSubject'
      | 'mentorId'
      | 'correct'
      | 'isActive'
    >[] = []

    if (candidates.length > 1500) {
      return NextResponse.json(
        { error: errorMessages.CANDIDATES_SHOULD_BE_LESS_THAN_1500 },
        { status: 400 },
      )
    }

    const validation = validateCandidates(candidates)

    if (!validation.valid) {
      return NextResponse.json(
        { error: validateCandidates(candidates).error },
        { status: 400 },
      )
    }

    validCandidates = validation.validCandidates

    if (validCandidates.length === 0) {
      return NextResponse.json(
        { error: errorMessages.INVALID_DATA },
        { status: 400 },
      )
    }

    const allListEntries = await db.list.findMany()
    const allSchoolEntries = await db.school.findMany()
    const allPersonEntries = await db.person.findMany({
      where: {
        isActive: true,
      },
    })
    const allPersonEmails = allPersonEntries.map((item) => item.email)

    const groupByListTableData = allListEntries.reduce((acc: any, item) => {
      if (!acc[item.listType]) {
        acc[item.listType] = {}
      }
      acc[item.listType][item.listValue] = item.listId
      return acc
    }, {})

    const validateFieldValue = (candidateKey: string, value: string) => {
      const keyForValidation = keyMapping[candidateKey]
      if (!keyForValidation) {
        throw new Error(`No mapping found for key: ${candidateKey}`)
      }
      if (
        (!groupByListTableData[keyForValidation] ||
          !groupByListTableData[keyForValidation][value]) &&
        !optionalFields.includes(candidateKey)
      ) {
        throw new Error(`${errorMessages.INVALID} ${candidateKey}: ${value}`)
      }
    }

    const allInputEmails = candidates.map((candidate) => candidate.Email)

    const duplicateEmails = allInputEmails.filter(
      (email, index, self) => self.indexOf(email) !== index,
    )

    duplicateInputEmails = duplicateEmails

    if (
      duplicateInputEmails &&
      duplicateInputEmails.length > 0 &&
      duplicateEmails[0] !== undefined
    ) {
      throw new Error(errorMessages.DUPLICATE_DATA)
    }

    const commonEmails: any = allPersonEmails.filter((email) =>
      allInputEmails.includes(email.toLowerCase()),
    )
    errorFieldValues = commonEmails

    if (
      commonEmails &&
      commonEmails.length > 0 &&
      commonEmails[0] !== undefined
    ) {
      throw new Error(errorMessages.FIELD_EMAIL_ALERADY_EXISTS)
    }
    await db.$transaction(async (tx) => {
      const newBatch = await tx.candidateBatch.create({
        data: {},
      })
      let phaseRequiredId
      for (const candidate of validCandidates) {
        try {
          Object.keys(keyMapping).forEach((candidateKey) => {
            const key = candidateKey as keyof typeof candidate
            return validateFieldValue(candidateKey, candidate[key] as any)
          })

          const schoolEntry = allSchoolEntries.find(
            (item) => item.BSN === candidate['School'],
          )
          const schoolId = schoolEntry?.schoolId
          if (!schoolId) {
            throw new Error(
              `${errorMessages.SCHOOL_NOT_FOUND_FOR_CANDIDATE}: ${candidate['First name']} ${candidate['Last name']}`,
            )
          }
          phaseRequiredId = getPhaseRequiredId(candidate, phasesOptions)
        } catch (error: any) {
          throw new Error(error.message)
        }
        const createdPerson = await tx.person.create({
          data: {
            title: candidate.Title ?? '',
            firstName: candidate['First name'],
            lastName: candidate['Last name'],
            email: candidate.Email.toLowerCase(),
            phoneNumber: candidate['Phone number']
              ? candidate['Phone number'].toString()
              : '',
            postalCode: candidate['Postal code']
              ? candidate['Postal code'].toString()
              : '',
            appellationId:
              +groupByListTableData.appellation[candidate.Appellation],
          },
        })
        const personIdFromApi = createdPerson.personId

        candidatesToCreate.push({
          batchId: newBatch.batchId,
          personId: personIdFromApi,
          streetAndHouseNo: candidate['Street and House No'],
          city: candidate.City,
          longerAbsenceReasonId: +groupByListTableData.longerAbsenceReason[
            candidate['Longer absence reason']
          ]
            ? +groupByListTableData.longerAbsenceReason[
                candidate['Longer absence reason']
              ]
            : null,
          teachingPositionId:
            +groupByListTableData.teachingPosition[
              candidate['Teaching position']
            ],
          startSchoolYear: candidate['Start school year'],
          yearGroupId: +groupByListTableData.yearGroup[candidate['Year group']],
          phaseRequiredId: phaseRequiredId,
          kickOffGroupId:
            +groupByListTableData.kickOffGroup[candidate['KickOff group']],
          firstRecognisedSubjectId:
            +groupByListTableData.firstRecognisedSubject[
              candidate['First recognised subject']
            ],
          secondRecognisedSubjectId: +groupByListTableData
            .secondRecognisedSubject[candidate['Second recognised subject']]
            ? +groupByListTableData.secondRecognisedSubject[
                candidate['Second recognised subject']
              ]
            : null,
          thirdRecognisedSubjectId: +groupByListTableData
            .thirdRecognisedSubject[candidate['Third recognised subject']]
            ? +groupByListTableData.thirdRecognisedSubject[
                candidate['Third recognised subject']
              ]
            : null,
          firstSubjectToBeStudiedId: +groupByListTableData
            .firstSubjectToBeStudied[candidate['First subject to be studied']]
            ? +groupByListTableData.firstSubjectToBeStudied[
                candidate['First subject to be studied']
              ]
            : null,
          secondSubjectToBeStudiedId: +groupByListTableData
            .secondSubjectToBeStudied[candidate['Second subject to be studied']]
            ? +groupByListTableData.secondSubjectToBeStudied[
                candidate['Second subject to be studied']
              ]
            : null,
          subjectChangeFromId: +groupByListTableData.subjectChangeFrom[
            candidate['Subject change from']
          ]
            ? +groupByListTableData.subjectChangeFrom[
                candidate['Subject change from']
              ]
            : null,
          subjectChangeToId: +groupByListTableData.subjectChangeTo[
            candidate['Subject change to']
          ]
            ? +groupByListTableData.subjectChangeTo[
                candidate['Subject change to']
              ]
            : null,
          comments: candidate.Comments ?? '',
          document: 'Document',
          schoolId: allSchoolEntries.filter(
            (item) => item.BSN === candidate['School'],
          )?.[0]?.schoolId,
          fromDate: null,
          untilDate: null,
          startOfContract: new Date(
            moment(candidate['Start of contract'], 'DD-MM-YYYY').toISOString(),
          ),
          bbvdStart: new Date(
            moment(candidate['bbVD-start'], 'DD-MM-YYYY').toISOString(),
          )
            ? new Date(
                moment(candidate['bbVD-start'], 'DD-MM-YYYY').toISOString(),
              )
            : null,
          bbstStart: new Date(
            moment(candidate['bbST-start'], 'DD-MM-YYYY').toISOString(),
          )
            ? new Date(
                moment(candidate['bbST-start'], 'DD-MM-YYYY').toISOString(),
              )
            : null,
          studiesGroupSubjectAId: +groupByListTableData.studiesGroupSubjectA[
            candidate['Studies Group Subject A']
          ]
            ? +groupByListTableData.studiesGroupSubjectA[
                candidate['Studies Group Subject A']
              ]
            : null,
          studiesGroupSubjectBId: +groupByListTableData.studiesGroupSubjectB[
            candidate['Studies Group Subject B']
          ]
            ? +groupByListTableData.studiesGroupSubjectB[
                candidate['Studies Group Subject B']
              ]
            : null,
          startSubjectAId:
            +groupByListTableData.startSubjectA[candidate['Start Subject A']] ??
            null,
          startSubjectBId:
            +groupByListTableData.startSubjectB[candidate['Start Subject B']] ??
            null,
        })
      }
      await tx.candidate.createMany({
        data: candidatesToCreate,
      })
    })
    return NextResponse.json(
      { message: successMessages.massImportSuccess },
      { status: 201 },
    )
  } catch (error: any) {
    if (
      error instanceof PrismaClientKnownRequestError &&
      error.code === prismaErrorCode.UNIQUE_CONSTRAINT_FAILED
    ) {
      return NextResponse.json(
        { error: errorMessages.INVALID_DATA },
        { status: 400 },
      )
    }

    if (error.message.startsWith('Please')) {
      return NextResponse.json({ error: error.message }, { status: 400 })
    }

    if (error.message.startsWith('Invalid')) {
      return NextResponse.json({ error: error.message }, { status: 400 })
    }

    if (error.message.startsWith('Field')) {
      return NextResponse.json(
        { error: error.message, data: errorFieldValues },
        { status: 409 },
      )
    }

    if (error.message.startsWith('Duplicate')) {
      return NextResponse.json(
        { error: error.message, data: duplicateInputEmails },
        { status: 409 },
      )
    }

    if (error.message.startsWith('School')) {
      return NextResponse.json({ error: error.message }, { status: 400 })
    }

    return NextResponse.json(
      { error: errorMessages.DEFAULT_ERROR },
      { status: 500 },
    )
  }
}
