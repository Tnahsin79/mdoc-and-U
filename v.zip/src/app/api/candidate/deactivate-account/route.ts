import { db } from '@/lib/db'
import { errorMessages, prismaErrorCode } from '@/utils/errorMessages'
import { successMessages } from '@/utils/successMessages'
import { PrismaClientKnownRequestError } from '@prisma/client/runtime/library'
import { NextResponse } from 'next/server'

interface transactionFunctionProps {
  candidateId: string
  isActive: boolean
}

function deactivateHandler({
  candidateId,
  isActive,
}: transactionFunctionProps) {
  return db.$transaction(async (tx) => {
    await tx.candidate.update({
      where: {
        candidateId: +candidateId,
      },
      data: {
        isActive: isActive,
        person: {
          update: {
            isActive: isActive,
          },
        },
      },
    })
  })
}

export async function PUT(req: Request) {
  try {
    const body = await req.json()
    const { candidateId, isActive } = body

    await deactivateHandler({ candidateId, isActive })

    return NextResponse.json(
      { message: successMessages.deactivateSuccess },
      { status: 201 },
    )
  } catch (error) {
    let errorMessage = errorMessages.DEFAULT_ERROR

    if (
      error instanceof PrismaClientKnownRequestError &&
      error.code === prismaErrorCode.RECORD_NOT_FOUND
    ) {
      errorMessage = errorMessages.RECORD_NOT_FOUND
    } else if (error instanceof Error) {
      errorMessage = error.message
    }

    return NextResponse.json({ error: errorMessage }, { status: 404 })
  }
}
