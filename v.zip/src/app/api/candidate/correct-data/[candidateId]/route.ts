import { db } from '@/lib/db'
import { errorMessages, prismaErrorCode } from '@/utils/errorMessages'
import { PrismaClientKnownRequestError } from '@prisma/client/runtime/library'
import { NextResponse } from 'next/server'

interface contextProps {
  params: {
    candidateId: string
  }
}

interface transactionFunctionProps {
  candidateId: string
  correct: boolean
}

function correctDataHandler({
  candidateId,
  correct,
}: transactionFunctionProps) {
  return db.$transaction(async (tx) => {
    const candidate = await tx.candidate.update({
      where: {
        candidateId: +candidateId,
      },
      data: {
        correct: correct,
      },
    })

    return candidate
  })
}

export async function POST(req: Request, context: contextProps) {
  try {
    const body = await req.json()
    const { correct } = body

    const { params } = context

    const { candidateId } = params

    const candidate = await correctDataHandler({ candidateId, correct })

    return NextResponse.json(
      {
        correct: candidate.correct,
        message: `Data is ${
          candidate.correct ? 'correct' : 'not correct'
        }, Updated Successfully`,
      },
      { status: 200 },
    )
  } catch (error) {
    let errorMessage = errorMessages.DEFAULT_ERROR

    if (
      error instanceof PrismaClientKnownRequestError &&
      error.code === prismaErrorCode.RECORD_NOT_FOUND
    ) {
      errorMessage = errorMessages.RECORD_NOT_FOUND
    } else if (error instanceof Error) {
      errorMessage = error.message
    }

    return NextResponse.json({ error: errorMessage }, { status: 400 })
  }
}
