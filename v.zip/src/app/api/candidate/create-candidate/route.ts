import { db } from '@/lib/db'
import { setYourPassword } from '@/utils/EmailTemplates/setYourPassword'
import { getUserDetails } from '@/utils/authUtils'
import { errorMessages, prismaErrorCode } from '@/utils/errorMessages'
import { historyMessages } from '@/utils/historyMessages'
import sendEmail from '@/utils/sendMail'
import { successMessages } from '@/utils/successMessages'
import { Candidate, Person } from '@prisma/client'
import { PrismaClientKnownRequestError } from '@prisma/client/runtime/library'
import crypto from 'crypto'
import { NextResponse } from 'next/server'

export interface ICreateCandidate extends Candidate, Person {
  phasePreference: {
    kickOff: boolean
    firstStep: boolean
    setUp: boolean
    studies: boolean
  }
}

interface transactionFunctionProps {
  data: ICreateCandidate
  token: string
  tokenExpiration: Date
}

const personIdIfCreated: number | null = null

function createCandidate({
  data,
  token,
  tokenExpiration,
}: transactionFunctionProps) {
  return db.$transaction(async (tx) => {
    const { personId } = await tx.person.create({
      data: {
        title: data.title ?? '',
        firstName: data.firstName,
        lastName: data.lastName ?? null,
        email: data.email.toLowerCase(),
        phoneNumber: data.phoneNumber ?? null,
        postalCode: data.postalCode ?? null,
        appellationId: data.appellationId ?? null,
        resetPasswordToken: token,
        resetPasswordTokenExpiry: tokenExpiration,
      },
    })

    await tx.candidate.create({
      data: {
        personId: personId,
        streetAndHouseNo: data.streetAndHouseNo,
        city: data.city,
        yearGroupId: data.yearGroupId,
        teachingPositionId: data.teachingPositionId,
        startSchoolYear: data.startSchoolYear,
        phaseRequiredId: data.phaseRequiredId,
        kickOffGroupId: data.kickOffGroupId,
        longerAbsenceReasonId: data.longerAbsenceReasonId,
        firstRecognisedSubjectId: data.firstRecognisedSubjectId,
        secondRecognisedSubjectId: data.secondRecognisedSubjectId,
        thirdRecognisedSubjectId: data.thirdRecognisedSubjectId,
        firstSubjectToBeStudiedId: data.firstSubjectToBeStudiedId,
        secondSubjectToBeStudiedId: data.secondSubjectToBeStudiedId,
        subjectChangeFromId: data.subjectChangeFromId,
        subjectChangeToId: data.subjectChangeToId,
        schoolId: data.schoolId,
        untilDate: data.untilDate,
        fromDate: data.fromDate,
        startOfContract: data.startOfContract,
        bbvdStart: data.bbvdStart,
        bbstStart: data.bbstStart,
        recognisedSubject: data.recognisedSubject,
        document: data.document,
        studiesGroupSubjectAId: data.studiesGroupSubjectAId,
        studiesGroupSubjectBId: data.studiesGroupSubjectBId,
        startSubjectAId: data.startSubjectAId,
        startSubjectBId: data.startSubjectBId,
      },
    })

    await tx.history.create({
      data: {
        personId: personId,
        actionType: historyMessages.candidateCreated,
        actionDetail: historyMessages.candidateCreated,
        actionReference: historyMessages.create,
      },
    })
  })
}

export async function POST(req: Request) {
  try {

    const userDetails = getUserDetails()
    const canCreateCandidate = userDetails.roles.includes('subjectAdmin') || userDetails.roles.includes('subjectSupervision')

    if(!canCreateCandidate){
      throw new Error('Not Authorized')
    }

    const body = await req.json()


    const { ...data }: ICreateCandidate = body.data

    const token = crypto.randomBytes(32).toString('hex')
    const tokenExpiration = new Date()
    tokenExpiration.setDate(tokenExpiration.getDate() + 3)

    await createCandidate({
      data: data,
      token: token,
      tokenExpiration: tokenExpiration,
    })

    const url =
      process.env.NODE_ENV !== 'production'
        ? `${process.env.APP_DEV_URL}/reset-password?token=${token}`
        : `${process.env.APP_PROD_URL}/reset-password?token=${token}`

    const html = setYourPassword(url)

    await sendEmail({
      to: data.email,
      subject: 'Verify your account',
      html: html,
    })

    return NextResponse.json(
      { message: successMessages.candidateCreated },
      { status: 201 },
    )
  } catch (error) {
    console.error(error)

    if (personIdIfCreated) {
      await db.person.delete({
        where: {
          personId: personIdIfCreated,
        },
      })
    }

    if (
      error instanceof PrismaClientKnownRequestError &&
      error.code === prismaErrorCode.UNIQUE_CONSTRAINT_FAILED
    ) {
      return NextResponse.json(
        { message: errorMessages.DUPLICATE_EMAIL },
        { status: 409 },
      )
    }

    return NextResponse.json(
      { error: errorMessages.DEFAULT_ERROR },
      { status: 500 },
    )
  }
}
