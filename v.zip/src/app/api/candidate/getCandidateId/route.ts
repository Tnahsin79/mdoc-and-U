import { db } from '@/lib/db'
import { errorMessages, prismaErrorCode } from '@/utils/errorMessages'
import { Candidate } from '@prisma/client'
import { PrismaClientKnownRequestError } from '@prisma/client/runtime/library'
import jwt, { JwtPayload } from 'jsonwebtoken'
import { cookies } from 'next/headers'
import { NextResponse } from 'next/server'

export async function POST(req: Request) {
  try {
    let person = undefined

    const cookieStore = cookies()
    const accessToken = cookieStore.get('accessToken')?.value
    if (!accessToken) {
      throw new Error(errorMessages.INVALID_TOKEN)
    }

    const JWTSecretKey: string = process.env.JWT_SECRET_KEY || 'ttmp-project'
    const decodedAccessToken: string | JwtPayload = jwt.verify(
      accessToken,
      JWTSecretKey,
    )

    if (
      !(typeof decodedAccessToken === 'object' && 'email' in decodedAccessToken)
    ) {
      throw new Error(errorMessages.INVALID_TOKEN)
    } else {
      person = await db.person.findFirst({
        where: {
          email: decodedAccessToken.email.toLowerCase(),
        },
      })

      if (!person) {
        throw new Error('Not Authorized')
      }

      const candidate = await db.candidate.findFirst({
        where: {
          personId: person.personId,
        }, 
        select: {
          candidateId: true,
        }
      })

      if (!candidate) {
        throw new Error('Candidate not found')
      }

      return NextResponse.json(
        { candidateId: candidate?.candidateId },
        { status: 200 },
      )
    }
  } catch (error) {
    let errorMessage = errorMessages.DEFAULT_ERROR

    if (
      error instanceof PrismaClientKnownRequestError &&
      error.code === prismaErrorCode.RECORD_NOT_FOUND
    ) {
      errorMessage = errorMessages.RECORD_NOT_FOUND
    } else if (error instanceof Error) {
      errorMessage = error.message
    }

    return NextResponse.json({ error: errorMessage }, { status: 400 })
  }
}
