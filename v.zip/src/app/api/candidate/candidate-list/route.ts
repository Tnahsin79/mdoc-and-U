import { Query } from '@/interface/common'
import { db } from '@/lib/db'
import { paginationLimit } from '@/utils/constants/common'
import { errorMessages } from '@/utils/errorMessages'
import { successMessages } from '@/utils/successMessages'
import { NextResponse } from 'next/server'

declare global {
  interface BigIntConstructor {
    toJSON: () => bigint
  }
}

export async function POST(req: Request) {
  try {
    const limit = paginationLimit
    const body = await req.json()
    const page = body?.page || 1
    const offset = (page - 1) * limit
    const searchQuery = body?.search || ''
    const filterQuery = body?.filterQuery || {
      AND: [{ isActive: { equals: true } }],
    }

    let whereCondition: any = {}
    if (searchQuery) {
      const words = searchQuery.split(/\s+/)
      whereCondition = {
        AND: [
          {
            person: {
              AND: words.map((word: string) => ({
                OR: [
                  {
                    firstName: {
                      contains: word,
                      mode: 'insensitive',
                    },
                  },
                  {
                    lastName: {
                      contains: word,
                      mode: 'insensitive',
                    },
                  },
                ],
              })),
            },
          },
        ],
      }
    }

    if (Object.keys(filterQuery).length > 0) {
      if(whereCondition.AND){
        whereCondition = {AND: [...whereCondition.AND, ...filterQuery.AND]}
      } else {
        whereCondition = { ...filterQuery }
      }
    }

    const totalRecords = await db.candidate.count({ where: whereCondition })

    const response: any = await db.candidate.findMany({
      take: limit,
      skip: offset,
      where: whereCondition,
      select: {
        candidateId: true,
        person: {
          select: {
            firstName: true,
            lastName: true,
            isActive: true,
            email: true,
            personId: true,
          },
        },
        phaseRequiredId: true,
        school: {
          select: {
            schoolName: true,
            schoolType: {
              select: {
                listValue: true,
              },
            },
            BSN: true,
          },
        },
        firstSubjectToBeStudied: {
          select: {
            listValue: true,
          }
        },
        secondSubjectToBeStudied: {
          select: {
            listValue: true,
          }
        },
        startSubjectA: {
          select: {
            listValue: true,
          },
        },
        startSubjectB: {
          select: {
            listValue: true,
          },
        },
        studiesGroupSubjectA: {
          select: {
            listValue: true,
          },
        },
        studiesGroupSubjectB: {
          select: {
            listValue: true,
          },
        },
        yearGroup: {
          select: {
            listValue: true,
          },
        },
        kickOffGroup: {
          select: {
            listValue: true,
          },
        },
        startSchoolYear: true,
        fromDate: true,
        untilDate: true,
      },
      orderBy: {
        person: {
          lastName: 'asc', // or 'desc' for descending order
        },
      },
    })

    return NextResponse.json(
      {
        message: successMessages.success,
        candidateList: response,
        totalRecords: totalRecords,
      },
      { status: 200 },
    )
  } catch (error) {
    let errorMessage = errorMessages.DEFAULT_ERROR

    if (error instanceof Error) {
      errorMessage = error.message
    }

    return NextResponse.json({ error: errorMessage }, { status: 404 })
  }
}

interface ICandidate {
  personId: number
  firstName: string
  lastName: string | null
  email: string
}

function flattenArrayOfObjects(arrayOfObjects: any) {
  return arrayOfObjects.map((obj:any) => {
    const {
      person: { personId, firstName, lastName, email }
    } = obj;

    return {
      personId,
      firstName,
      lastName,
      email
    };
  });
}

export async function GET() {
  try {
    const whereCondition = {
      AND: [{ isActive: { equals: true } }], // Assuming isActive filter is always applied
    };

    const totalRecords = await db.candidate.count({ where: whereCondition });

    const response: any = await db.candidate.findMany({
      where: whereCondition,
      select: {
        person: {
          select: {
            personId: true,
            firstName: true,
            lastName: true,
            email: true,
          }
        },
      },
      orderBy: {
        person: {
          firstName: 'asc', // or 'desc' for descending order
        },
      },
    });

    
    return NextResponse.json(
      {
        message: successMessages.success,
        candidateList: flattenArrayOfObjects(response),
        totalRecords: totalRecords,
      },
      { status: 200 },
    );
  } catch (error) {
    let errorMessage = errorMessages.DEFAULT_ERROR;

    if (error instanceof Error) {
      errorMessage = error.message;
    }

    return NextResponse.json({ error: errorMessage }, { status: 404 });
  }
}