import { db } from '@/lib/db'
import { getUserDetails } from '@/utils/authUtils'
import { errorMessages, prismaErrorCode } from '@/utils/errorMessages'
import { successMessages } from '@/utils/successMessages'
import { PrismaClientKnownRequestError } from '@prisma/client/runtime/library'
import { NextResponse } from 'next/server'

interface contextProps {
  params: {
    candidateId: number
  }
}

interface transactionFunctionProps {
  candidateId: number
}

function deleteHandler({ candidateId }: transactionFunctionProps) {
  return db.$transaction(async (tx) => {
    const { personId } = await tx.candidate.delete({
      where: {
        candidateId: +candidateId,
      },
    })

    await tx.person.delete({
      where: {
        personId: personId,
      },
    })
  })
}

export async function POST(req: Request, context: contextProps) {
  try {
    const { params } = context
    const { candidateId } = params

    const userDetails = getUserDetails()
    const deletePermission = userDetails.roles.includes('subjectAdmin')

    if(!deletePermission){
      throw new Error('Not Authorized')
    }

    await deleteHandler({ candidateId })

    return NextResponse.json(
      { message: successMessages.candidateDeleteSuccess },
      { status: 200 },
    )
  } catch (error) {
    let errorMessage = errorMessages.DEFAULT_ERROR

    if (
      error instanceof PrismaClientKnownRequestError &&
      error.code === prismaErrorCode.RECORD_NOT_FOUND
    ) {
      errorMessage = errorMessages.RECORD_NOT_FOUND
    } else if (error instanceof Error) {
      errorMessage = error.message
    }

    return NextResponse.json({ error: errorMessage }, { status: 404 })
  }
}
