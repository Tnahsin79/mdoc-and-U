import { errorMessages } from '@/utils/errorMessages'
import { cookies } from 'next/headers'
import { NextResponse } from 'next/server'

export async function POST(req: Request) {
  try {
    const { fileName } = await req.json()

    const cookieStore = cookies()
    const accessToken = cookieStore.get('accessToken')?.value
    if (!accessToken) {
      throw new Error(errorMessages.INVALID_TOKEN)
    }

    let fileURL = ''
    const responseFromFileServer = await fetch(
      `${process.env.FILE_SERVER_BASE_URL}/get-attachment-link?fileName=${fileName}`,
      {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      },
    )
    const body = await responseFromFileServer.json()
    fileURL = body.url

    return NextResponse.json(
      {
        url: fileURL,
      },
      { status: 200 },
    )
  } catch (error) {
    let errorMessage = errorMessages.DEFAULT_ERROR

    if (error instanceof Error) {
      errorMessage = error.message
    }

    return NextResponse.json({ error: errorMessage }, { status: 404 })
  }
}
