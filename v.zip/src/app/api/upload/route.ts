import { errorMessages } from '@/utils/errorMessages'
import { successMessages } from '@/utils/successMessages'
import { NextResponse } from 'next/server'
import { cookies } from 'next/headers'

export async function GET() {
  return NextResponse.json('hi')
}

export async function POST(req: Request) {
  try {
    const body = await req.formData()
    const files: File[] | null = body.getAll('file') as unknown as File[]
    if (!files || files.length === 0) {
      throw new Error('No files uploaded')
    }

    const cookieStore = cookies()
    const accessToken = cookieStore.get('accessToken')?.value
    if (!accessToken) {
      throw new Error(errorMessages.INVALID_TOKEN)
    }

    const formData = new FormData()
    files.forEach((file) => {
      formData.append('file', file)
    })

    const response = await fetch(`${process.env.FILE_SERVER_BASE_URL}/upload`, {
      body: formData,
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    })

    const responseData = await response.json()

    return NextResponse.json(
      {
        message: successMessages.success,
        responseData,
        fileServerURL: `${process.env.FILE_SERVER_BASE_URL}/upload`,
      },
      { status: 201 },
    )
  } catch (error) {
    let errorMessage = errorMessages.DEFAULT_ERROR

    if (error instanceof Error) {
      errorMessage = error.message
    }

    return NextResponse.json(
      {
        error: errorMessage,
      },
      { status: 401 },
    )
  }
}
