import { db } from '@/lib/db'
import { cookies } from 'next/headers'
import { TaskType } from '@prisma/client'
import { NextResponse } from 'next/server'
import { getUserDetails } from '@/utils/authUtils'
import { errorMessages } from '@/utils/errorMessages'
import { successMessages } from '@/utils/successMessages'
import { historyMessages } from '@/utils/historyMessages'

interface contextProps {
  params: {
    taskId: string
  }
}

export async function GET(req: Request, context: contextProps) {
  const { params } = context
  const { taskId } = params

  if (!taskId) {
    throw new Error(errorMessages.NO_DATA_FOUND)
  }

  const { email } = getUserDetails()
  const person = await db.person.findUnique({ where: { email } })

  try {
    const task: {
      taskId: number
      assigneeId: number | null
      type: TaskType
      title: string
      dueDate: Date
      note: string
      attachments: unknown
      creatorId: number | null
      creator: {
        firstName: string
        lastName: string | null
      } | null
    } | null = await db.task.findUnique({
      where: {
        taskId: +taskId,
        OR: [
          {
            assignee: {
              personId: person?.personId,
            },
          },
          {
            creator: {
              personId: person?.personId,
            },
          },
        ],
      },
      include: {
        creator: {
          select: {
            firstName: true,
            lastName: true,
          },
        },
        attachments: {
          where: {
            taskId: +taskId,
          },
          select: {
            attachment: true,
          },
        },
      },
    })

    if (!task) {
      throw new Error(errorMessages.TASK_NOT_FOUND)
    }

    const cookieStore = cookies()
    const accessToken = cookieStore.get('accessToken')?.value
    if (!accessToken) {
      throw new Error(errorMessages.INVALID_TOKEN)
    }

    return NextResponse.json(
      {
        task: task,
        message: successMessages.success,
      },
      { status: 200 },
    )
  } catch (error) {
    let errorMessage = errorMessages.DEFAULT_ERROR

    if (error instanceof Error) {
      errorMessage = error.message
    }

    return NextResponse.json({ error: errorMessage }, { status: 404 })
  }
}

export async function PUT(req: Request, context: contextProps) {
  const { params } = context
  const { taskId } = params
  const body = await req.json()

  if (!taskId) {
    throw new Error(errorMessages.NO_DATA_FOUND)
  }

  try {
    await db.task.update({
      where: {
        taskId: +taskId,
      },
      data: {
        done: body.done,
        assigneeId: body.assigneeId,
        dueDate: new Date(body.dueDate),
        note: body.note,
        title: body.title,
      },
    })

    if (body.changeDoneStatus) {
      const taskStatusText = body.done ? 'Done' : 'Not Done'

      const updatedTask = await db.task.findUnique({
        where: {
          taskId: +taskId,
        },
      })

      await db.history.create({
        data: {
          personId: body.assigneeId,
          actionType: historyMessages.taskStatusChanged,
          actionDetail: `${updatedTask?.title} ${historyMessages.taskStatusMovedTo} ${taskStatusText}`,
          actionReference: historyMessages.tasks,
        },
      })
    }

    return NextResponse.json(
      {
        message: successMessages.success,
      },
      { status: 200 },
    )
  } catch (error) {
    let errorMessage = errorMessages.DEFAULT_ERROR

    if (error instanceof Error) {
      errorMessage = error.message
    }

    return NextResponse.json({ error: errorMessage }, { status: 400 })
  }
}
