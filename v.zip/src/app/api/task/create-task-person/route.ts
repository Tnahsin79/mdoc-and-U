import { db } from '@/lib/db'
import { errorMessages } from '@/utils/errorMessages'
import jwt, { JwtPayload } from 'jsonwebtoken'
import { cookies } from 'next/headers'
import { NextResponse } from 'next/server'

export async function POST(req: Request) {
  try {
    const cookieStore = cookies()
    const accessToken = cookieStore.get('accessToken')?.value
    if (!accessToken) {
      throw new Error(errorMessages.INVALID_TOKEN)
    }

    const JWTSecretKey: string = process.env.JWT_SECRET_KEY || 'ttmp-project'
    const decodedAccessToken: string | JwtPayload = jwt.verify(
      accessToken,
      JWTSecretKey,
    )

    let ownDetail = null

    if (
      !(typeof decodedAccessToken === 'object' && 'email' in decodedAccessToken)
    ) {
      throw new Error(errorMessages.INVALID_TOKEN)
    } else {
       ownDetail = await db.person.findFirst({
        where: {
          email: decodedAccessToken.email.toLowerCase(),
          isActive: true,
        },
        select: {
          personId: true,
          firstName: true,
          lastName: true,
          email: true,
          role: true,
        }
      })

      if (!ownDetail) {
        throw new Error(errorMessages.NOT_AUTHORIZED)
      }
    }

    const body = await req.json()
    const { email } = body

    const person = await db.person.findFirst({
      where: {
        email: email,
      },
      select: {
        personId: true,
        firstName: true,
        lastName: true,
        email: true,
        role: true,
      }
    })

    return NextResponse.json(
      { person: person, ownDetail: ownDetail },
      { status: 200 },
    )
  } catch (error) {
    let errorMessage = errorMessages.DEFAULT_ERROR

    if (error instanceof Error) {
      errorMessage = error.message
    }

    return NextResponse.json({ error: errorMessage }, { status: 404 })
  }
}
