import { db } from '@/lib/db'
import { NextResponse } from 'next/server'
import { errorMessages } from '@/utils/errorMessages'
import { Role } from '@prisma/client'

export async function POST(req: Request) {
  const { role, id }: { role: Role; id: number } = await req.json()

  let where = {}
  if (role === Role.Collaborator) {
    const events = await db.event.findMany({
      where: {
        suitableCollaborators: {
          collaborator: {
            collaboratorId: id,
          },
        },
      },
      select: {
        eventId: true,
      },
    })

    const attendees = await db.eventAttendees.findMany({
      where: {
        eventId: {
          in: events.map((event) => event.eventId),
        },
      },
      select: {
        attendeeId: true,
      },
    })

    where = {
      OR: [
        {
          person: {
            mentorId: id,
          },
        },
        {
          collaborator: {
            collaboratorId: id,
          },
        },
        {
          personId: {
            in: attendees.map((val) => val.attendeeId),
          },
        },
      ],
    }
  } else if (role === Role.Candidate) {
    where = {
      personId: id,
    }
  }

  try {
    const persons = await db.person.findMany({
      select: {
        firstName: true,
        lastName: true,
        email: true,
        role: true,
        personId: true,
      },
      where: {
        ...where,
        AND: {
          isActive: true,
        },
      },
    })

    return NextResponse.json({ persons }, { status: 200 })
  } catch (error) {
    let errorMessage = errorMessages.DEFAULT_ERROR

    if (error instanceof Error) {
      errorMessage = error.message
    }

    return NextResponse.json({ error: errorMessage }, { status: 404 })
  }
}
