import { db } from '@/lib/db'
import { NextResponse } from 'next/server'
import { errorMessages } from '@/utils/errorMessages'
import { successMessages } from '@/utils/successMessages'
import { paginationLimit } from '@/utils/constants'

export async function POST(req: Request) {
  const body = await req.json()
  const page = body?.page || 1
  const offset = (page - 1) * paginationLimit


  try {
    const allTasks = await db.task.findMany({
      take: paginationLimit,
      skip: offset,
      orderBy: {
        dueDate: 'asc',
      },
      where: {
        OR: [
          {
            creatorId: body.personId,
          },
          {
            assigneeId: body.personId,
          },
        ],
        AND: body?.query?.AND ? body.query.AND : [],
      },
      select: {
        title: true,
        note: true,
        assignee: {
          select: {
            firstName: true,
            lastName: true,
          },
        },
        creator: {
          select: {
            firstName: true,
            lastName: true,
          },
        },
        type: true,
        dueDate: true,
        done: true,
        taskId: true,
        creatorId: true,
      },
    })

    const totalRecords = await db.task.count({
      where: {
        OR: [
          {
            creatorId: body.personId,
          },
          {
            assigneeId: body.personId,
          },
        ],
        AND: body?.query?.AND ? body.query.AND : [],
      },
    })

    return NextResponse.json(
      {
        tasks: allTasks,
        totalRecords: totalRecords,
        message: successMessages.success,
      },
      { status: 200 },
    )
  } catch (error) {
    let errorMessage = errorMessages.DEFAULT_ERROR

    if (error instanceof Error) {
      errorMessage = error.message
    }

    return NextResponse.json({ error: errorMessage }, { status: 404 })
  }
}
