import { db } from '@/lib/db'
import { errorMessages } from '@/utils/errorMessages'
import { successMessages } from '@/utils/successMessages'
import { Role } from '@prisma/client'
import moment from 'moment'
import { NextResponse } from 'next/server'

export async function POST(req: Request) {
  const data = await req.json()


  try {
    if (!data.assigneeId) {
      // throw new Error(errorMessages.USER_NOT_FOUND)
      throw new Error(`User not found ${data.assigneeId}`)
    }

    const user = await db.person.findFirst({
      where: {
          personId: data.assigneeId,
          isActive: true,
          // email: 'v@jy.com',

      },
    })


    const employee = await db.person.findFirst({
      where: {
        role: 'Employee',
      },
    })

    if (!user) {
      throw new Error(errorMessages.USER_NOT_FOUND)
    }

    const res = await db.task.create({
      data: {
        creatorId: data.assigneeId,
        title: `${user.firstName} incorrect Data`,
        dueDate: moment().add(1, 'months').toDate(),
        note: `${user.firstName} marked their master data as incorrect`,
        type: 'Data',
        assigneeId: employee?.personId,
      },
    })

    return NextResponse.json(
      {
        message: user.role === Role.Candidate ? successMessages.candidateMarkedInvalidData : successMessages.collaboratorMarkedInvalidData,
        res,
      },
      { status: 200 },
    )
  } catch (error) {
    const errorMessage =
      error instanceof Error ? error.message : errorMessages.DEFAULT_ERROR

    return NextResponse.json({ error: errorMessage }, { status: 400 })
  }
}
