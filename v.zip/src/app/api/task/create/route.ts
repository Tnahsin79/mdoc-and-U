import { db } from '@/lib/db'
import { NextResponse } from 'next/server'
import { getUserDetails } from '@/utils/authUtils'
import { Person, Role, Task } from '@prisma/client'
import { errorMessages } from '@/utils/errorMessages'
import { successMessages } from '@/utils/successMessages'
import { createTaskSchema } from '@/validators/schemas/task'
import { specialAssigneesList } from '@/utils/constants/common'
import { historyMessages } from '@/utils/historyMessages'
import sendEmail from '@/utils/sendMail'
import { taskMessages } from '@/utils/taskMessages'
import { actionTemplate } from '@/utils/EmailTemplates/action'

interface ITask extends Omit<Task, 'taskId' | 'creatorId' | 'assigneeId'> {
  assignees: ('All Candidate' | 'All Collaborator' | number)[]
  attachments: string[]
}

export async function POST(req: Request) {
  try {
    const data = await req.json()
    const parsed = createTaskSchema.safeParse({
      ...data,
      dueDate: new Date(data.dueDate),
    })

    if (!parsed.success) {
      const errorMessage =
        parsed.error.issues[0]?.message || errorMessages.DEFAULT_ERROR
      return NextResponse.json({ error: errorMessage }, { status: 400 })
    }

    const { email } = getUserDetails()

    const taskCreator = await db.person.findUnique({ where: { email } })

    if (!taskCreator) {
      throw new Error(errorMessages.USER_NOT_FOUND)
    }

    const body = parsed.data as ITask

    const specialAssignees = body.assignees.filter((item) =>
      specialAssigneesList.includes(`${item}`),
    ) as string[]

    const normalAssignees = body.assignees.filter(
      (item) => !specialAssigneesList.includes(`${item}`),
    ) as number[]

    let persons: Person[] = []

    for (const specialAssignee of specialAssignees) {
      const role = specialAssignee.split(' ')[1] as Role

      const personWithCurrentRole = await db.person.findMany({
        where: {
          role: role,
          isActive: true,
        },
      })

      persons = persons.concat(personWithCurrentRole)
    }

    for (const normalAssignee of normalAssignees) {
      const personWithCurrentId = await db.person.findMany({
        where: {
          AND: [
            { personId: normalAssignee },
            {
              personId: {
                notIn: persons.map((person) => person.personId),
              },
            },
            {
              isActive: true,
            },
          ],
        },
      })

      persons = persons.concat(personWithCurrentId)
    }

    for (const person of persons) {
      const newTask = await db.task.create({
        data: {
          dueDate: body.dueDate,
          note: body.note.toLowerCase(),
          title: body.title.toLowerCase(),
          type: body.type,
          creatorId: taskCreator.personId,
          assigneeId: person.personId,
        },
      })

      for (const attachment of body.attachments) {
        await db.attachment.createMany({
          data: {
            attachment: attachment,
            taskId: newTask.taskId,
          },
        })
      }

      const url =
            process.env.APP_DEV_URL ??
            process.env.APP_PROD_URL ??
            'localhost:3000'

      const text = taskMessages.taskCreated      
      const html = actionTemplate(url, text)      

      await sendEmail({
        to: person.email,
        subject: `${taskMessages.taskAssignedToYou}`,
        html: html,
      })

      await db.history.create({
        data: {
          actionType: historyMessages.taskAssigned,
          actionDetail: data.title,
          actionReference: historyMessages.tasks,
          personId: person.personId,
        },
      })
    }

    return NextResponse.json(
      { message: successMessages.success },
      { status: 200 },
    )
  } catch (error) {
    let errorMessage = errorMessages.DEFAULT_ERROR

    if (error instanceof Error) {
      errorMessage = error.message
    }

    return NextResponse.json({ error: errorMessage }, { status: 404 })
  }
}
