'use client'
import CustomButton from '@/components/Buttons/CustomButton'
import { UserContext } from '@/contexts/userContext'
import { Box, Grid, Typography } from '@mui/material'
import { Role } from '@prisma/client'
import { useRouter } from 'next/navigation'
import { useContext } from 'react'
import { useScopedI18n } from '../../locales/client'

export default function NotFound() {
  const tScoped = useScopedI18n('dashboard')
  const router = useRouter()

  const { user } = useContext(UserContext)
  const isEmployee = user?.role === Role.Employee
  const isCandidate = user?.role === Role.Candidate

  const routeToHome = () => {
    if (isEmployee && !isCandidate) {
      router.replace('/dashboard')
    } else if (!isEmployee && isCandidate) {
      router.replace('/candidate')
    } else {
      router.replace('/collaborator/dashboard')
    }
  }

  return (
    <Box
      sx={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: '234px',
      }}
    >
      <Grid>
        <Grid>
          <Typography
            variant="h1"
            sx={{
              fontSize: '96px',
              fontWeight: '700',
              margin: 'unset',
              marginLeft: '10px',
              marginRight: '10px',
            }}
          >
            404
          </Typography>
        </Grid>
        <Grid>
          <Typography
            variant="h1"
            sx={{
              fontSize: '20px',
              fontWeight: '700',
              marginBottom: '10px',
              marginLeft: '11px',
              marginRight: '10px',
            }}
          >
            {tScoped('Page Not Found')}
          </Typography>
        </Grid>
        <Grid>
          <CustomButton
            label
            labelText={tScoped('Back to home page')}
            variant="contained"
            onClick={routeToHome}
          />
        </Grid>
      </Grid>
    </Box>
  )
}
