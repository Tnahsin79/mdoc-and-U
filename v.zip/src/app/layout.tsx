import { LinearProgress } from '@mui/material'
import { I18nProviderClient } from '../../locales/client'
import './globals.css'
import IsMobileView from '@/components/MobileView'

export const metadata = {
  title: 'TTMP Project',
  description: 'It is an application tracking tool for the TTMP project.',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="de">
      <body>
        {/* TODO: you can change the default locale to any locale you want here  */}
        <I18nProviderClient locale={'de'} fallback={<p><LinearProgress /></p>}>
          <IsMobileView>{children}</IsMobileView>
        </I18nProviderClient>
      </body>
    </html>
  )
}
