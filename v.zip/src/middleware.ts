import { chain } from '@/middlewares/chain'
import { withAuth } from './middlewares/auth'
import { withACL } from './middlewares/acl'
import { withI18n } from './middlewares/intl'

export default chain([withAuth, withACL, withI18n])

export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon.ico).*)'],
}
