'use client'
import { Person } from '@prisma/client'
import React, { createContext, useState, ReactNode, useContext } from 'react'

interface IPerson extends Person {
  collaboratorId: number | null
  candidateId: number | null
}

interface UserContextValue {
  user: IPerson | null
  setUser: React.Dispatch<React.SetStateAction<IPerson | null>>
  pagination: {
    candidate: number
    collaborator: number
    school: number
  }
  setPagination: React.Dispatch<
    React.SetStateAction<{
      candidate: number
      collaborator: number
      school: number
    }>
  >
}

interface UserProviderProps {
  children: ReactNode
}

const defaultContextValue: UserContextValue = {
  user: null,
  setUser: () => {},
  pagination: {
    candidate: 1,
    collaborator: 1,
    school: 1,
  },
  setPagination: () => {},
}

export const UserContext = createContext<UserContextValue>(defaultContextValue)

export const UserProvider: React.FC<UserProviderProps> = ({ children }) => {
  const [user, setUser] = useState<IPerson | null>(null)
  const [pagination, setPagination] = useState({
    candidate: 1,
    collaborator: 1,
    school: 1,
  })

  return (
    <UserContext.Provider value={{ user, setUser, pagination, setPagination }}>
      {children}
    </UserContext.Provider>
  )
}

export const useUser = (): IPerson | null => {
  const { user } = useContext<UserContextValue>(UserContext);
  return user;
};