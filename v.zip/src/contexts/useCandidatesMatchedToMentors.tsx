import {
  createContext,
  Dispatch,
  ReactNode,
  SetStateAction,
  useState,
} from 'react'

interface IMatchingProviderProps {
  children: ReactNode
}

interface IMatchingProps {
  candidatesMatchedToMentors: { [key: number]: number | null } | null
  setCandidatesMatchedToMentors: Dispatch<
    SetStateAction<{ [key: number]: number | null } | null>
  >
  singleCandidatesMatchedToMentors: {
    [key: number]: number | null
  } | null
  setSingleCandidatesMatchedToMentors: Dispatch<
    SetStateAction<{
      [key: number]: number | null
    } | null>
  >
}

export type MatchMentorState = { [key: number]: number | null } | null

const defaultContextValue: MatchMentorState = null

export const CandidatesMatchedToMentorsContext = createContext<IMatchingProps>({
  candidatesMatchedToMentors: defaultContextValue,
  setCandidatesMatchedToMentors: () => {},
  singleCandidatesMatchedToMentors: defaultContextValue,
  setSingleCandidatesMatchedToMentors: () => {},
})

export const CandidatesMatchedToMentorsProvider: React.FC<
  IMatchingProviderProps
> = ({ children }) => {
  const [candidatesMatchedToMentors, setCandidatesMatchedToMentors] =
    useState<MatchMentorState>(null)

  const [
    singleCandidatesMatchedToMentors,
    setSingleCandidatesMatchedToMentors,
  ] = useState<{
    [key: number]: number | null
  } | null>(null)

  return (
    <CandidatesMatchedToMentorsContext.Provider
      value={{
        candidatesMatchedToMentors,
        setCandidatesMatchedToMentors,
        singleCandidatesMatchedToMentors,
        setSingleCandidatesMatchedToMentors,
      }}
    >
      {children}
    </CandidatesMatchedToMentorsContext.Provider>
  )
}
