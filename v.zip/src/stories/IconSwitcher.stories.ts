import type { Meta, StoryObj } from '@storybook/react'
import IconSwitcher from '../components/Icons/index'

const meta = {
  title: 'TTMP/IconSwitcher',
  component: IconSwitcher,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
} satisfies Meta<typeof IconSwitcher>

export default meta
type Story = StoryObj<typeof meta>

export const Icon1: Story = {
  args: {
    icon: 'Icon1',
  },
}

export const Icon2: Story = {
  args: {
    icon: 'Icon2',
  },
}

export const Icon3: Story = {
  args: {
    icon: 'Icon3',
  },
}

export const Icon4: Story = {
  args: {
    icon: 'Icon4',
  },
}

export const Icon5: Story = {
  args: {
    icon: 'Icon5',
  },
}

export const Icon6: Story = {
  args: {
    icon: 'Icon6',
  },
}

export const Icon7: Story = {
  args: {
    icon: 'Icon7',
  },
}

export const Icon8: Story = {
  args: {
    icon: 'Icon8',
  },
}

export const Icon9: Story = {
  args: {
    icon: 'Icon9',
  },
}

export const Icon10: Story = {
  args: {
    icon: 'Icon10',
  },
}

export const Icon11: Story = {
  args: {
    icon: 'Icon11',
  },
}

export const Icon12: Story = {
  args: {
    icon: 'Icon12',
  },
}

export const Icon13: Story = {
  args: {
    icon: 'Icon13',
  },
}

export const Icon14: Story = {
  args: {
    icon: 'Icon14',
  },
}

export const Icon15: Story = {
  args: {
    icon: 'Icon15',
  },
}

export const Icon16: Story = {
  args: {
    icon: 'Icon16',
  },
}

export const Icon17: Story = {
  args: {
    icon: 'Icon17',
  },
}

export const Icon18: Story = {
  args: {
    icon: 'Icon18',
  },
}

export const Icon19: Story = {
  args: {
    icon: 'Icon19',
  },
}

export const CheckboxChecked: Story = {
  args: {
    icon: 'checkboxChecked',
  },
}

export const CheckboxUnchecked: Story = {
  args: {
    icon: 'checkboxUnchecked',
  },
}

export const RadioChecked: Story = {
  args: {
    icon: 'radioChecked',
  },
}

export const RadioUnchecked: Story = {
  args: {
    icon: 'radioUnchecked',
  },
}
