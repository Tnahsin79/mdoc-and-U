import type { Meta, StoryObj } from '@storybook/react'
import TaskTableRow from '../components/TableRows/TaskTableRow'

const meta = {
  title: 'TTMP/TaskTableRow',
  component: TaskTableRow,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
} satisfies Meta<typeof TaskTableRow>

export default meta
type Story = StoryObj<typeof meta>

export const Primary: Story = {
  args: {
    task: {
      dueDate: new Date(),
      note: 'Note',
      taskId: 1,
      title: 'Title',
      type: 'Data',
      attachments: [
        {
          fileName: '',
          url: '',
        },
      ],
      done: false,
      creatorId: 1,
      assigneeId: 1,
    },
  },
}
