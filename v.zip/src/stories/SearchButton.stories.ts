import type { Meta, StoryObj } from '@storybook/react'
import CustomSearchButton from '../components/Buttons/SearchButton'

const meta = {
  title: 'TTMP/CustomSearchButton',
  component: CustomSearchButton,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
} satisfies Meta<typeof CustomSearchButton>

export default meta
type Story = StoryObj<typeof meta>

export const Primary: Story = {
  args: {},
}
