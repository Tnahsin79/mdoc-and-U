import type { Meta, StoryObj } from '@storybook/react'
import CandidateTableRow from '../components/TableRows/CandidateRow'

const meta = {
  title: 'TTMP/CandidateTableRow',
  component: CandidateTableRow,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
} satisfies Meta<typeof CandidateTableRow>

export default meta
type Story = StoryObj<typeof meta>

export const Default: Story = {}
