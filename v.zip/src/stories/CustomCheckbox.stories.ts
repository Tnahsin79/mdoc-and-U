import type { Meta, StoryObj } from '@storybook/react'

import CustomCheckbox from '../components/Buttons/CustomCheckbox'

const meta = {
  title: 'TTMP/CustomCheckbox',
  component: CustomCheckbox,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
} satisfies Meta<typeof CustomCheckbox>

export default meta
type Story = StoryObj<typeof meta>

export const NoLabel: Story = {
  args: {},
}

export const WithLabel: Story = {
  args: {
    label: 'Label',
  },
}
