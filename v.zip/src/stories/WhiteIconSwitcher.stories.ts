import WhiteIconSwitcher from '../components/Icons/WhiteIcons'
import type { Meta, StoryObj } from '@storybook/react'

const meta = {
  title: 'TTMP/WhiteIconSwitcher',
  component: WhiteIconSwitcher,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
} satisfies Meta<typeof WhiteIconSwitcher>

export default meta
type Story = StoryObj<typeof meta>

export const ArrowRight: Story = {
  args: {
    icon: 'arrowRight',
  },
}

export const ArrowDown: Story = {
  args: {
    icon: 'arrowDown',
  },
}

export const Upload: Story = {
  args: {
    icon: 'upload',
  },
}

export const Download: Story = {
  args: {
    icon: 'download',
  },
}

export const Check: Story = {
  args: {
    icon: 'check',
  },
}

export const Compare: Story = {
  args: {
    icon: 'compare',
  },
}

export const Plus: Story = {
  args: {
    icon: 'plus',
  },
}

export const People: Story = {
  args: {
    icon: 'people',
  },
}

export const Search: Story = {
  args: {
    icon: 'search',
  },
}

export const Attach: Story = {
  args: {
    icon: 'attach',
  },
}

export const FolderAdd: Story = {
  args: {
    icon: 'folderAdd',
  },
}
