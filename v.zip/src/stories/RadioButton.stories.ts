import { Meta, StoryObj } from '@storybook/react'

import RadioButton from '../components/Buttons/RadioButton'

const meta = {
  title: 'TTMP/RadioButton',
  component: RadioButton,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
} satisfies Meta<typeof RadioButton>

export default meta
type Story = StoryObj<typeof meta>

export const WithoutLabel: Story = {
  args: {},
}

export const WithLabel: Story = {
  args: {
    label: 'Label',
  },
}
