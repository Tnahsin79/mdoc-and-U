import { Meta, StoryObj } from '@storybook/react'

import CustomFlagButton from '../components/Buttons/FlagButton'

const meta = {
  title: 'TTMP/CustomFlagButton',
  component: CustomFlagButton,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
} satisfies Meta<typeof CustomFlagButton>

export default meta
type Story = StoryObj<typeof meta>

export const Primary: Story = {
  args: {},
}
