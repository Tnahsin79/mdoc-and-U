import type { Meta, StoryObj } from '@storybook/react'

import CustomButton from '../components/Buttons/CustomButton'

const meta = {
  title: 'TTMP/CustomButton',
  component: CustomButton,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
} satisfies Meta<typeof CustomButton>

export default meta
type Story = StoryObj<typeof meta>

export const IconButton: Story = {
  args: {
    label: false,
    icon: true,
    iconWithBg: true,
  },
}

export const Default: Story = {
  args: {
    label: true,
    icon: false,
    labelText: 'Label',
  },
}

export const ButtonWithIconAndLabel: Story = {
  args: {
    label: true,
    icon: true,
    labelText: 'Label',
  },
}
