import ProfileAddressRow from '../components/ProfileAddressRow'
import { Meta, StoryObj } from '@storybook/react'

const meta = {
  title: 'TTMP/ProfileAddressRow',
  component: ProfileAddressRow,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
} satisfies Meta<typeof ProfileAddressRow>

export default meta
type Story = StoryObj<typeof meta>

export const Primary: Story = {
  args: {
    primary: true,
  },
}

export const Secondary: Story = {}
