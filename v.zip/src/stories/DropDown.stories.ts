import DropDown from '../components/DropDown'
import type { Meta, StoryObj } from '@storybook/react'

// const topFilms = [
//   { label: '3 Idiots', value: 2009 },
//   { label: 'The Shawshank Redemption', value: 1994 },
//   { label: 'The Godfather', value: 1972 },
//   { label: 'The Godfather: Part II', value: 1974 },
//   { label: 'The Dark Knight', value: 2008 },
//   { label: '12 Angry Men', value: 1957 },
//   { label: "Schindler's List", value: 1993 },
//   { label: 'Pulp Fiction', value: 1994 },
//   { label: 'The Sting', value: 1973 },
//   { label: '2001: A Space Odyssey', value: 1968 },
//   { label: "Singin' in the Rain", value: 1952 },
//   { label: 'Toy Story', value: 1995 },
//   { label: 'Bicycle Thieves', value: 1948 },
//   { label: 'The Kid', value: 1921 },
//   { label: 'Monty Python and the Holy Grail', value: 1975 },
// ]

const meta = {
  title: 'TTMP/DropDown',
  component: DropDown,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
} satisfies Meta<typeof DropDown>

const schoolType = [
  { id: 65, label: 'Day School' },
  { id: 66, label: 'Boarding School' },
  { id: 67, label: 'Mid Day School' },
]

export default meta
type Story = StoryObj<typeof meta>

export const Primary: Story = {
  args: {
    label: 'Label',
    options: schoolType,
  },
}
