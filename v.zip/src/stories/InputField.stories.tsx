import { Meta, StoryObj } from '@storybook/react'

import InputField from '../components/InputField'

const meta = {
  title: 'TTMP/InputField',
  component: InputField,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
} satisfies Meta<typeof InputField>

export default meta
type Story = StoryObj<typeof meta>

export const WithoutPlaceholder: Story = {
  args: {
    label: 'Label',
    placeholder: '',
  },
}

export const WithPlaceholder: Story = {
  args: {
    label: 'Label',
    placeholder: 'Placeholder',
  },
}
