import type { Meta, StoryObj } from '@storybook/react'

import BerlinLogo from '../components/BerlinLogo'

const meta = {
  title: 'TTMP/BerlinLogo',
  component: BerlinLogo,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
} satisfies Meta<typeof BerlinLogo>

export default meta
type Story = StoryObj<typeof meta>

export const Primary: Story | unknown = {}
