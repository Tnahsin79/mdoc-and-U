import bcrypt from 'bcrypt'
import jwt, { JwtPayload } from 'jsonwebtoken'

import { Role } from '@prisma/client'
import { cookies } from 'next/headers'
import { errorMessages } from './errorMessages'
import {
  JWTSecretKey,
  accessTokenMaxAge,
  refreshTokenMaxAge,
  saltRounds,
} from './constants/common'
import getUserRoles from './getUserRoles'

interface jsonwebtoken extends JwtPayload {
  email: string
  role: Role
}

export async function hashPassword(password: string): Promise<string> {
  return await bcrypt.hash(password, +saltRounds)
}

export function generateAccessToken(
  email: string,
  role: Role = 'Employee',
  subjectAdmin: boolean,
  subjectSupervision: boolean,
  householdAdmin: boolean,
  departmentLead: boolean,
): string {
  return jwt.sign(
    {
      email,
      role,
      subjectAdmin,
      subjectSupervision,
      householdAdmin,
      departmentLead,
    },
    JWTSecretKey,
    {
      expiresIn: `${accessTokenMaxAge}s`,
    },
  )
}

export function generateRefreshToken(
  email: string,
  role: Role = 'Employee',
  subjectAdmin: boolean,
  subjectSupervision: boolean,
  householdAdmin: boolean,
  departmentLead: boolean,
): string {
  return jwt.sign(
    {
      email,
      role,
      subjectAdmin,
      subjectSupervision,
      householdAdmin,
      departmentLead,
    },
    JWTSecretKey,
    {
      expiresIn: `${refreshTokenMaxAge}s`,
    },
  )
}

export function setRefreshTokenCookie(refreshToken: string): void {
  cookies().set('refreshToken', refreshToken, {
    path: '/api/auth/refresh',
    httpOnly: true,
    maxAge: refreshTokenMaxAge,
  })
}

export function setAccessTokenCookie(accessToken: string): void {
  cookies().set('accessToken', accessToken, {
    path: '/',
    httpOnly: false,
    maxAge: accessTokenMaxAge,
  })
}

export const getUserDetails = () => {
  const cookieStore = cookies()
  const accessToken = cookieStore.get('accessToken')?.value

  if (!accessToken) {
    throw new Error(errorMessages.INVALID_TOKEN)
  }

  const JWTSecretKey: string = process.env.JWT_SECRET_KEY || 'ttmp-project'

  const decodedAccessToken = jwt.verify(
    accessToken,
    JWTSecretKey,
  ) as jsonwebtoken

  const roles = getUserRoles({
    subjectAdmin: decodedAccessToken.subjectAdmin,
    subjectSupervision: decodedAccessToken.subjectSupervision,
    householdAdmin: decodedAccessToken.householdAdmin,
    departmentLead: decodedAccessToken.departmentLead,
  })

  return {
    email: decodedAccessToken.email.toLowerCase(),
    role: decodedAccessToken.role,
    roles: roles,
  }
}
