

 const getUserRoles = (user: any) => {
  const roles = []

  if (user.subjectAdmin) {
    roles.push('subjectAdmin')
  }
  if (user.subjectSupervision) {
    roles.push('subjectSupervision')
  }
  if (user.departmentLead) {
    roles.push('departmentLead')
  }
  if (user.householdAdmin) {
    roles.push('householdAdmin')
  }

  return roles
}

export default getUserRoles
