export const taskMessages = {
  taskAssignedToYou: 'New task is assigned to you',
  taskCreated: 'New Task is Created',
}
