import { PIN_NO_CONSTRAINTS } from './constants/common'

export const errorMessages = {
  DEFAULT_ERROR: 'ein unbekannter Fehler ist aufgetreten',
  INVALID_TOKEN: 'ungültiger oder abgelaufener Token',
  EXPIRED_REFRESH_TOKEN: 'Login fehlgeschlagen',
  UNAUTHORIZED: 'nicht autorisiert',
  INCORRECT_CREDENTIALS:
    'Anmeldung fehlgeschlagen: Passwort oder Email-Adresse falsch',
  NO_REFRESH_TOKEN: 'kein Refresh-Token',
  DUPLICATE_USER: 'Ein User mit dieser Email-Adresse existiert bereits',
  DUPLICATE_EVENT: 'Ein Event mit diesen Daten existiert bereits',
  NO_DATA_FOUND: 'keine Daten gefunden',
  EVENT_NOT_FOUND: 'Event nicht gefunden',
  EVENT_TEMPLATE_NOT_FOUND: 'Event Template nicht gefunden',
  EMPTY_LIST: 'Eine Liste dieses Typs existiert nicht',
  RECORD_NOT_FOUND: 'Ein solcher Datensatz existiert nicht',
  DUPLICATE_SCHOOL: 'Eine Schule mit dieser BSN existiert bereits',
  USER_NOT_FOUND:
    'Kein User mit dieser Email-Adresse gefunden. Prüfen Sie Ihre Angaben und loggen Sie sich erneut ein',
  INSUFFICIENT_PERMISSION:
    'Sie haben nicht die nötigen Berechtigungen, um diese Aktion auszuführen.',
  DUPLICATE_EVENT_PARTICIPATION_REQUEST:
    'Eine Event-Zuordnung mit diesen Daten existiert bereits.',
  ATTENDEES_NOT_FOUND: 'Teilnehmer nicht gefunden',
  COLLABORATORS_NOT_FOUND: 'Mitwirkende nicht gefunden',
  NO_CANDIDATES_FOUND: 'Quereinsteigender nicht gefunden',
  FAILED_TO_UPLOAD_ATTACHMENT: 'Upload der Datei fehlgeschlagen',
  NOTHING_TO_AUTOMATcH:
    'Wählen Sie bitte mindestens einen Quereinsteigenden zum Matchen aus',
  INVALID_PIN_NO: `ungültige PIN-Nummer. Wählen Sie bitte eine Nummer zwischen ${PIN_NO_CONSTRAINTS.min} und ${PIN_NO_CONSTRAINTS.max}`,
  TASK_NOT_FOUND: 'Task nicht gefunden',
  DUPLICATE_EMAIL: 'Email-Adresse existiert bereits',
  CANDIDATE_NOT_CREATED: 'Quereinsteigender konnte nicht erstellt werden',
  CANDIDATES_SHOULD_BE_LESS_THAN_1500:
    'Die Zahl der Kandidaten sollte unter 1500 liegen',
  INVALID_DATA: 'Bitte geben Sie gültige Daten ein',
  INVALID: 'Ungültig',
  DUPLICATE_DATA: 'Doppelte Daten',
  FIELD_EMAIL_ALERADY_EXISTS:
    'Die Feld-E-Mail ist bereits in der Datenbank vorhanden',
  SCHOOL_NOT_FOUND_FOR_CANDIDATE: 'Schule für Kandidaten nicht gefunden',
  INVALID_PHASE_FOR_CANDIDATE: 'Ungültige Phasenoption für den Kandidaten',
  NOT_AUTHORIZED: 'Nicht berechtigt',
  DATA_ALEADY_EXISTS: 'Daten sind bereits vorhanden',
  IF_USER_EXISTS_WE_HAVE_SENT_YOU_MAIL:
    'Wenn Ihr Benutzer existiert, haben wir Ihnen einen Link zum Zurücksetzen des Passworts gesendet',
  COULD_NOT_SEND_MESSAGE: 'Nachricht konnte nicht gesendet werden',
  COULD_NOT_SAVE_NOTE: 'Notiz konnte nicht gespeichert werden',
  SELECT_ATLEAST_ONE_ROLE: 'Wählen Sie „Mindestens eine Rolle“ aus',
}

export const prismaErrorCode = {
  UNIQUE_CONSTRAINT_FAILED: 'P2002',
  RECORD_NOT_FOUND: 'P2025',
}
