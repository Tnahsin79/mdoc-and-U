import { IMailData } from '@/interface/communication'

export function sortByTimeStampDescending(mailList: IMailData[]) {
  const sortedList = mailList.sort((mailA, mailB) => {
    const timestampA = new Date(mailA.timeStamp).getTime()
    const timestampB = new Date(mailB.timeStamp).getTime()

    return timestampB - timestampA
  })

  return sortedList
}
