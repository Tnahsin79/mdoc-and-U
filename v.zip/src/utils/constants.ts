export const EVENT_ACCESS_TYPE = ['Online', 'Offline']
export const unprotectedRoutes = ['/login', '/signup']
export const FIND_NUMBER_REGEX = /\d+/

export const landingPage = '/dashboard'

//Routes For Event DashBoard Buttons
export const protectedRoutes = [
  { path: '/event', label: 'Events', disabled: false },
  { path: '/candidate/candidate-list', label: 'Candidates', disabled: false },
  {
    path: '/collaborator/collaborator-list',
    label: 'Collaborators',
    disabled: false,
  },
  { path: '/search', label: 'Search', disabled: true },
  { path: '/statistics', label: 'Statistics', disabled: true },
  { path: '/import', label: 'Import/Export', disabled: true },
  { path: '/communication', label: 'Communication', disabled: true },
  { path: '/school', label: 'Schools', disabled: false },
]

export const routes = {
  dashboard: '/dashboard',
  candidate: {
    list: 'candidate',
    create: '/candidate/create',
  },
  events: {
    create: '/event/create',
    list: '/event',
  },
  collaborator: {
    create: '/collaborator/create-collaborator',
  },
  school: {
    create: '/school/create-school',
    list: '/school',
    edit: '/school/edit',
  },
  forgotPassword: '/forgot-password',
}

export const CandidateRoutes = {
  dashboard: '/candidate/dashboard',
}

export const CollaboratorRoutes = {
  dashboard: '/collaborator/dashboard',
}

export const paginationLimit = 15

export const phasesOptions = [
  { id: 1, kickOff: true, firstStep: true, setUp: true, studies: true },
  { id: 2, kickOff: true, firstStep: true, setUp: true, studies: false },
  { id: 3, kickOff: true, firstStep: true, setUp: false, studies: true },
  { id: 4, kickOff: true, firstStep: true, setUp: false, studies: false },
  { id: 5, kickOff: true, firstStep: false, setUp: true, studies: true },
  { id: 6, kickOff: true, firstStep: false, setUp: true, studies: false },
  { id: 7, kickOff: true, firstStep: false, setUp: false, studies: true },
  { id: 8, kickOff: true, firstStep: false, setUp: false, studies: false },
  { id: 9, kickOff: false, firstStep: true, setUp: true, studies: true },
  { id: 10, kickOff: false, firstStep: true, setUp: true, studies: false },
  { id: 11, kickOff: false, firstStep: true, setUp: false, studies: true },
  { id: 12, kickOff: false, firstStep: true, setUp: false, studies: false },
  { id: 13, kickOff: false, firstStep: false, setUp: true, studies: true },
  { id: 14, kickOff: false, firstStep: false, setUp: true, studies: false },
  { id: 15, kickOff: false, firstStep: false, setUp: false, studies: true },
  { id: 16, kickOff: false, firstStep: false, setUp: false, studies: false },
]
export const berlinHolidays = [
  '2023-01-01',
  '2023-04-07',
  '2023-04-09',
  '2023-04-10',
  '2023-05-01',
  '2023-05-18',
  '2023-06-04',
  '2023-06-05',
  '2023-10-03',
  '2023-12-25',
  '2023-12-26',
]

export const historyActionReferences = {
  Messages: 'Messages',
  Courses: 'Courses',
  Documents: 'Documents',
  Tasks: 'Tasks',
}
