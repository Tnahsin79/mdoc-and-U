import Mailgun from 'mailgun-js'

interface ISendMail {
  to: string
  subject: string
  text?: string
  html: string
}

const sendEmail = ({ to, subject, html }: ISendMail) => {
  return new Promise((resolve, reject) => {
    const mailgun = Mailgun({
      apiKey: process.env.MAILGUN_API_KEY!,
      domain: process.env.MAILGUN_DOMAIN!,
    })

    const emailData = {
      from: 'TTMP Support <support@ttmp.com>',
      to: to,
      subject: subject,
      html: html,
    }

    mailgun.messages().send(emailData, (error, body) => {
      if (error) {
        console.log('mailgun.messages ~ error:', error)
        reject(error)
      } else {
        resolve(body)
        console.log('mailgun.messages ~ body:', body)
      }
    })
  })
}

export default sendEmail
