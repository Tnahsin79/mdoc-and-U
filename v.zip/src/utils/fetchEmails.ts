import Imap from 'imap'
import { simpleParser } from 'mailparser'
import { Role } from '@prisma/client'

import { db } from '@/lib/db'

interface IEmailData {
  from?: string
  to?: string
  subject?: string
  date?: Date
  text?: string
  body?: string
  uid?: number
}

function extractEmail(fullAddress: string) {
  const match = fullAddress.match(/<(.+?)>/)
  return match ? match[1] : fullAddress
}

const emails: any[] = []

const imapConfig = {
  user: process.env.TTMP_SUPPORT_EMAIL_ID ?? '',
  password: process.env.TTMP_SUPPORT_EMAIL_PASSWORD ?? '',
  host: 'imap.gmail.com',
  port: 993,
  tls: true,
  tlsOptions: { rejectUnauthorized: false },
}

function openInbox(
  imap: Imap,
  cb: {
    (err: any, box: any): void
    (error: Error, mailbox: Imap.Box): void
  },
) {
  imap.openBox('INBOX', false, cb)
}

function processEmails(imap: Imap) {
  return new Promise((resolve, reject) => {
    openInbox(imap, (err: any) => {
      if (err) {
        console.log(err)
        reject({
          isFetched: false,
          error: err,
        })
        return
      }

      imap.search(['UNSEEN'], (err, results) => {
        if (err) throw err
        if (!results || results.length === 0) {
          console.log('No unread emails found.')
          imap.end()
          resolve({
            isFetched: true,
            emails: [],
          })
          return
        }

        const f = imap.fetch(results, {
          bodies: ['HEADER.FIELDS (FROM TO SUBJECT DATE MESSAGE-ID)', ''],
          struct: true,
          markSeen: true,
        })

        f.on('message', (msg) => {
          let emailData: IEmailData = {}

          msg.on('body', (stream: any, info) => {
            simpleParser(stream, (err, mail) => {
              if (info.which === 'TEXT') {
                emailData.body = mail.text!
              } else {
                emailData = {
                  from: mail?.from?.text,
                  to: (mail as any)?.to?.text,
                  subject: mail?.subject,
                  date: mail?.date,
                  text: mail?.text,
                }
              }
            })
          })

          msg.once('attributes', (attrs) => {
            emailData.uid = attrs.uid
          })

          msg.once('end', async () => {
            if (emailData.from) {
              emails.push(emailData)
              const senderEmail = extractEmail(emailData.from)

              const person = await db.person.findUnique({
                where: { email: senderEmail },
              })

              const id = emailData?.uid ? +emailData.uid : 0
              let existingEmail: any = { communicationId: '1' }
              if (id !== 0) {
                existingEmail = await db.communication.findFirst({
                  where: { messageUuid: id },
                })
              }

              if (!existingEmail?.subject && id !== 0) {
                const supportMailId = await db.person.findUnique({
                  where: { email: 'employee@ttmp.com' },
                })

                if (person) {
                  if (
                    person.role === Role.Candidate ||
                    person.role === Role.Collaborator
                  ) {
                    const data = {
                      subject: emailData.subject || '',
                      body: emailData.text || '',
                      recipientId: supportMailId?.personId || 0,
                      senderId: person.personId,
                      timeStamp: emailData.date || new Date(),
                      messageUuid: emailData.uid ? +emailData.uid : 0,
                    }
                    await db.communication.create({ data })
                  }
                } else {
                  const data = {
                    subject: emailData.subject || '',
                    body: emailData.text || '',
                    recipientId: supportMailId?.personId || 0,
                    timeStamp: emailData.date || new Date(),
                    messageUuid: emailData.uid ? +emailData.uid : 0,
                    isNotAssigned: true,
                    unknownSenderMail: senderEmail,
                  }
                  await db.communication.create({ data })
                }
              }
            }
          })
        })

        f.once('error', (err) => console.log('Fetch error: ' + err))
        f.once('end', () => {
          resolve({
            isFetched: true,
            emails,
          })
          imap.end()
        })
      })
    })
  })
}

export const fetchEmails = async () => {
  const imap = new Imap(imapConfig)

  return new Promise((resolve, reject) => {
    imap.once('ready', async () => {
      try {
        await processEmails(imap)
        resolve({
          isFetched: true,
          emails,
        })
      } catch (err) {
        console.log('imap.once error:', err)
        reject({
          isFetched: false,
          error: err,
        })
      }
    })

    imap.once('end', () => {
      console.log('Connection closed.')
      imap.end()
      resolve({
        isFetched: true,
        emails,
      })
    })

    imap.once('error', (err: string) => {
      console.log('Connection error: ' + err)
      reject({
        isFetched: false,
        error: err,
      })
    })

    imap.connect()
  })
}
