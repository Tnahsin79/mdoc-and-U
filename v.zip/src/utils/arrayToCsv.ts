export const convertArrayOfObjectsToCSV = (array: any, headers: any) => {
  let result: string = ''

  result += Object.values(headers).join(',') + '\n'

  array.forEach((obj: any) => {
    let line = ''
    for (const key in headers) {
      if (line !== '') {
        line += ','
      }
      const value = obj[key] === null ? '' : obj[key]
      line += `"${value}"`
    }
    result += line + '\n'
  })

  return result
}
