export const notificationMessages = {
  MessageReceivedTopic: 'Message Received',
  MessageReceivedMessage: 'A New Message is Received in your Inbox',
  BuddyRequestTopic: 'Buddy Request Reveived',
  BuddyRequestMessage: 'You have received a New BUddy Request', 
  MatchedWithMentor: 'Matched with Mentor',
  MatchedWithMentorText: 'You have been matched with your mentor', 
  MatchedWithCandidate: 'Matched with Candidate',
  MatchedWithCandidateText: 'You have been matched with a Candidate',
}
