export const actionTemplate = (url: string, text: string) => {
    const temp = `<!DOCTYPE html>
      <html lang="en">
      <head>
          <meta charset="UTF-8" />
          <meta name="viewport" content="width=device-width, initial-scale=1.0" />
          <title>Email Template</title>
          <link
          href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap"
          rel="stylesheet"
          />
          <style type="text/css">
          @font-face {
              font-family: "BerlinTypeOffice-Bold";
              src: url("https://staging.quereinstieg.sdui-projects.de/assets/BerlinTypeOffice-Bold.ttf")
              format("truetype");
          }
          @font-face {
              font-family: "BerlinTypeOffice-Regular";
              src: url("https://staging.quereinstieg.sdui-projects.de/assets/BerlinTypeOffice-Regular.ttf")
              format("truetype");
          }
          .one {
              display: grid;
              place-items: center;
              width: 100%;
          }
  
          .main-container {
              width: 600px;
              display: grid;
              grid-template-rows: repeat(3, 1fr);
          }
  
          .header {
              color: #f5f7fb;
          }
  
          .message-container {
            font-family: "Roboto", sans-serif;
            font-weight: 700;
            font-size: 20px;
            height: 24px;
            text-align: center; /* Center horizontally */
            display: inline-block; /* Center horizontally */
            margin-top: 100px;
           }
  
          .mentor-name {
              font-family: "BerlinTypeOffice-Bold", sans-serif;
              margin-top: 40px;
              margin-bottom: 40px;
              display: table-cell;
              text-align: center; /* Center horizontally */
              line-height: 24px; /* Center vertically */
              height: 24px; /* Center vertically */
              font-weight: 700;
              color: #e40422;
              font-size: 28px;
          }
  
          .login-button {
              display: table-cell;
              text-align: center;
              vertical-align: middle;
          }
  
          .login-btn-inner {
              padding: auto;
              background-color: #e40422;
              color: #ffffff;
              display: inline-block;
              border: none;
              margin-bottom: 100px;
          }
  
          .footer {
              width: 100%;
              background-color: #ffffff;
              color: black;
          }
  
          .footer-content {
              padding: 30px;
          }
  
          .footer-text {
              text-decoration-color: black;
          }
  
          .image {
              position: absolute;
              width: 144px;
              height: 49.65px;
              left: 48px;
              top: 28.41px;
  
              background: url();
          }
          </style>
      </head>
      <body>
          <div class="one">
          <div class="main-container">
              <div class="header">
              <img
                  style="width: 144px; height: 49.65px; padding: 28px 0 28px 48px;"
                  src="https:\\staging.quereinstieg.sdui-projects.de/assets/images/Logo.png"
              />
              </div>
              <div class="message-container">
              ${text}
              </div>
              <div class="mentor-name"></div>
              <div class="login-button">
              <a href="${url}">
              <button class="login-btn-inner">
                <p style="font-weight: 700; font-size: 16px">Passwort zurücksetzen</p>
              </button>
            </a>
              </div>
              <div class="footer">
              <div class="footer-content">
                  <p class="footer-text">
                  Herzliche Grüße, <br />
                  StEPS Team <br /><br />
  
                  Senatsverwaltung für Bildung, Jugend und Familie <br />
                  Abteilung II <br />
                  II E 8 – Open Educational Resources; Aus-, Fort- und
                  Weiterbildungsdatenbank II E <br />
                  Bernhard-Weiß-Str. 6, 10178 Berlin <br />
                  Telefon: +49 (0)30 1111111 <br />
                  E-Mail: something@something.de <br />
                  Internet:
                  <a href="www.berlin.de/sen/bjf" target="_blank"
                      >www.berlin.de/sen/bjf</a
                  >
                  </p>
              </div>
              </div>
          </div>
          </div>
          <script>
            function openNewTab(url) {
              window.open(url, '_blank');
            }
          </script>
      </body>
      </html>
      `
  
    return temp
}