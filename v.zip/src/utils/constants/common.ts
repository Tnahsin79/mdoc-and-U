import { Role } from '@prisma/client'

export const JWTSecretKey: string = process.env.JWT_SECRET_KEY || 'ttmp-project'
export const refreshTokenMaxAge = 60 * 60 * 24 * 7 //* 7 days
export const accessTokenMaxAge = 60 * 60 * 24 * 1 //* 1 day
export const saltRounds = process.env.HASH_SALT_ROUND || 10

export const phasesOptions = [
  { id: 1, kickOff: true, firstStep: true, setUp: true, studies: true },
  { id: 2, kickOff: true, firstStep: true, setUp: true, studies: false },
  { id: 3, kickOff: true, firstStep: true, setUp: false, studies: true },
  { id: 4, kickOff: true, firstStep: true, setUp: false, studies: false },
  { id: 5, kickOff: true, firstStep: false, setUp: true, studies: true },
  { id: 6, kickOff: true, firstStep: false, setUp: true, studies: false },
  { id: 7, kickOff: true, firstStep: false, setUp: false, studies: true },
  { id: 8, kickOff: true, firstStep: false, setUp: false, studies: false },
  { id: 9, kickOff: false, firstStep: true, setUp: true, studies: true },
  { id: 10, kickOff: false, firstStep: true, setUp: true, studies: false },
  { id: 11, kickOff: false, firstStep: true, setUp: false, studies: true },
  { id: 12, kickOff: false, firstStep: true, setUp: false, studies: false },
  { id: 13, kickOff: false, firstStep: false, setUp: true, studies: true },
  { id: 14, kickOff: false, firstStep: false, setUp: true, studies: false },
  { id: 15, kickOff: false, firstStep: false, setUp: false, studies: true },
  { id: 16, kickOff: false, firstStep: false, setUp: false, studies: false },
]

export const schoolTypeValues: { [key: string]: string } = {
  Grundschule: "GS",
  "ISS Gymnasium": "ISS/Gym",
  "Berufliche Schulen": "BS",
  "Zweiter Bildungsweg": "Zweiter Bildungsweg",
  "Integrierte Sekundarschule": "Integrierte Sekundarschule",
  "Gemeinschaftsschule": "Gemeinschaftsschule",
  "Förderzentrum": "Förderzentrum",
  "Gymnasium": "Gymnasium",
  "nicht gesetzt": "nicht gesetzt"
};

export const addressCount = 3
export const paginationLimit = 15

export const specialAssigneesList = [
  `All ${Role.Candidate}`,
  `All ${Role.Collaborator}`,
]

export const MAX_TASK_COUNT = 10

export const PIN_NO_CONSTRAINTS = {
  min: 1001,
  max: 9999,
}
