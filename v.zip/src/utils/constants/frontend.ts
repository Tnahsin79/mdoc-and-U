import { TaskType } from '@prisma/client'

type FilterColumn = {
  columnName: string
  displayValue:
    | 'School Type'
    | 'School Name'
    | 'Year Group'
    | 'Type'
    | 'Title'
    | 'Due Date'
    | 'Note'
    | 'Kick Off Group'
    | 'Kick Off'
    | 'First Steps'
    | 'Setup'
    | 'Studies'
    | 'Start School Year'
  dataType: string  
  options?: string[] | undefined
}

export const unprotectedFrontendRoutes = [
  '/login',
  '/signup',
  '/reset-password',
  '/forgot-password',
  '/assets/svgs/Logo.svg',
  '/assets/images/Logo.png',
]

export const frontendRoutes = {
  login: '/login',
  dashboard: '/dashboard',
  candidate: {
    list: '/candidate',
    create: '/candidate/create',
    massImport: '/candidate/mass-import',
    matchMentors: '/candidate/match-mentors',
    data: '/candidate/candidate-data',
    dashboard: '/candidate/dashboard',
  },
  events: {
    create: '/event/create',
    list: '/event',
    template: '/event/template',
    templateEdit: '/event/template/edit',
    templateCreate: '/event/template/create',
  },
  collaborator: {
    create: '/collaborator/create-collaborator',
    list: '/collaborator/collaborator-list',
    edit: '/collaborator/collaborator-data',
  },
  school: {
    create: '/school/create-school',
    list: '/school',
    edit: '/school/edit',
  },
  task: {
    list: '/task',
  },
  employee: {
    data: '/employees/data',
  },
}

export const berlinHolidays = [
  '2023-01-01',
  '2023-04-07',
  '2023-04-09',
  '2023-04-10',
  '2023-05-01',
  '2023-05-18',
  '2023-06-04',
  '2023-06-05',
  '2023-10-03',
  '2023-12-25',
  '2023-12-26',
]
export interface IProtectedFrontendRoutes {
  path: string
  disabled: boolean
  label:
    | 'Events'
    | 'Candidates'
    | 'Collaborators'
    | 'Communication'
    | 'Schools'
    | 'Employees'
}

export const protectedFrontendRoutes: IProtectedFrontendRoutes[] = [
  { path: '/event', label: 'Events', disabled: false },
  { path: '/candidate', label: 'Candidates', disabled: false },
  {
    path: '/collaborator/collaborator-list',
    label: 'Collaborators',
    disabled: false,
  },
  //Commenting below two buttons as they are not functional yet
  // { path: '/statistics', label: 'Statistics', disabled: true },
  // { path: '/import', label: 'Import/Export', disabled: true },
  { path: '/communication-employee', label: 'Communication', disabled: false },
  { path: '/school', label: 'Schools', disabled: false },
  { path: '/employees', label: 'Employees', disabled: false },
]

interface ICollaboratorDashboardRoutes {
  path: string
  disabled: boolean
  label: 'My Collaboration Data' | 'Communication' | 'My Invoices' | 'History'
}

export const collaboratorProtectedRoutes: (
  collaboratorId?: number,
  personId?: number,
) => ICollaboratorDashboardRoutes[] = (
  collaboratorId: number | undefined,
  personId: number | undefined,
) => [
  {
    path: `/collaborator/collaborator-data/${collaboratorId}`,
    label: 'My Collaboration Data',
    disabled: false,
  },
  {
    path: '/communication-collaborator',
    label: 'Communication',
    disabled: false,
  },
  // {
  //   path: '/progress',
  //   label: 'Progress',
  //   disabled: true,
  // },
  {
    path: '/collaborator/invoices',
    label: 'My Invoices',
    disabled: false,
  },
  {
    path: `/history/${personId}`,
    label: 'History',
    disabled: false,
  },
]

export const taskRoutes = [
  {
    path: '/task',
  },
]

export const EVENT_ACCESS_TYPE = ['Online', 'Offline', 'Hybrid']

export const landingPage = '/dashboard'

export const TASK_COLUMNS: FilterColumn[] = [
  {
    columnName: 'type',
    displayValue: 'Type',
    dataType: 'enum',
    options: Object.keys(TaskType),
  },
  {
    columnName: 'title',
    displayValue: 'Title',
    dataType: 'string',
  },
  {
    columnName: 'dueDate',
    displayValue: 'Due Date',
    dataType: 'date',
  },
  {
    columnName: 'note',
    displayValue: 'Note',
    dataType: 'string',
  },
]

export const CANDIDATE_CHART_COLUMNS: FilterColumn[] = [
  {
    columnName: 'schoolType',
    displayValue: 'School Type',
    dataType: 'enum',
    options: [
      'Zweiter Bildungsweg',
      'Berufliche Schule',
      'Grundschule',
      'Integrierte Sekundarschule',
      'Gemeinschaftsschule',
      'Förderzentrum',
      'Gymnasium',
      // 'Tempelhof-Schöneberg',
      // 'Lichtenberg',
      'nicht gesetzt',
    ],
  },
  {
    columnName: 'schoolName',
    displayValue: 'School Name',
    dataType: 'string',
  },
  {
    columnName: 'yearGroup',
    displayValue: 'Year Group',
    dataType: 'enum',
    options: ['1', '2', '3', '4'],
  },
  {
    columnName: 'kickOff',
    displayValue: 'Kick Off',
    dataType: 'boolean',
  },
  {
    columnName: 'firstSteps',
    displayValue: 'First Steps',
    dataType: 'boolean',
  },
  { 
    columnName: 'setUp',
    displayValue: 'Setup',
    dataType: 'boolean',
  },
  {
    columnName: 'studies',
    displayValue: 'Studies',
    dataType: 'boolean',
  },
  {
    columnName: 'startSchoolYear',
    displayValue: 'Start School Year',
    dataType: 'string'
  }

]
