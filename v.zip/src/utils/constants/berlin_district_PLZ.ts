export const PLZ: { PLZ: string; District: string }[] = [
  {
    PLZ: '10585',
    District: 'Charlottenburg-Wilmersdorf',
  },
  {
    PLZ: '10587',
    District: 'Charlottenburg-Wilmersdorf',
  },
  {
    PLZ: '10589',
    District: 'Charlottenburg-Wilmersdorf',
  },
  {
    PLZ: '10623',
    District: 'Charlottenburg-Wilmersdorf',
  },
  {
    PLZ: '10625',
    District: 'Charlottenburg-Wilmersdorf',
  },
  {
    PLZ: '10627',
    District: 'Charlottenburg-Wilmersdorf',
  },
  {
    PLZ: '10629',
    District: 'Charlottenburg-Wilmersdorf',
  },
  {
    PLZ: '10707',
    District: 'Charlottenburg-Wilmersdorf',
  },
  {
    PLZ: '10709',
    District: 'Charlottenburg-Wilmersdorf',
  },
  {
    PLZ: '10711',
    District: 'Charlottenburg-Wilmersdorf',
  },
  {
    PLZ: '10719',
    District: 'Charlottenburg-Wilmersdorf',
  },
  {
    PLZ: '10789',
    District: 'Charlottenburg-Wilmersdorf',
  },
  {
    PLZ: '14050',
    District: 'Charlottenburg-Wilmersdorf',
  },
  {
    PLZ: '14055',
    District: 'Charlottenburg-Wilmersdorf',
  },
  {
    PLZ: '14057',
    District: 'Charlottenburg-Wilmersdorf',
  },
  {
    PLZ: '14059',
    District: 'Charlottenburg-Wilmersdorf',
  },
  {
    PLZ: '13627',
    District: 'Charlottenburg-Wilmersdorf',
  },
  {
    PLZ: '14193',
    District: 'Charlottenburg-Wilmersdorf',
  },
  {
    PLZ: '14199',
    District: 'Charlottenburg-Wilmersdorf',
  },
  {
    PLZ: '10713',
    District: 'Charlottenburg-Wilmersdorf',
  },
  {
    PLZ: '14197',
    District: 'Charlottenburg-Wilmersdorf',
  },
  {
    PLZ: '14052',
    District: 'Charlottenburg-Wilmersdorf',
  },
  {
    PLZ: '14053',
    District: 'Charlottenburg-Wilmersdorf',
  },
  {
    PLZ: '10715',
    District: 'Charlottenburg-Wilmersdorf',
  },
  {
    PLZ: '10717',
    District: 'Charlottenburg-Wilmersdorf',
  },
  {
    PLZ: '10779',
    District: 'Charlottenburg-Wilmersdorf',
  },
  {
    PLZ: '10243',
    District: 'Friedrichshain-Kreuzberg',
  },
  {
    PLZ: '10245',
    District: 'Friedrichshain-Kreuzberg',
  },
  {
    PLZ: '10247',
    District: 'Friedrichshain-Kreuzberg',
  },
  {
    PLZ: '10249',
    District: 'Friedrichshain-Kreuzberg',
  },
  {
    PLZ: '10961',
    District: 'Friedrichshain-Kreuzberg',
  },
  {
    PLZ: '10969',
    District: 'Friedrichshain-Kreuzberg',
  },
  {
    PLZ: '10963',
    District: 'Friedrichshain-Kreuzberg',
  },
  {
    PLZ: '10965',
    District: 'Friedrichshain-Kreuzberg',
  },
  {
    PLZ: '10967',
    District: 'Friedrichshain-Kreuzberg',
  },
  {
    PLZ: '10997',
    District: 'Friedrichshain-Kreuzberg',
  },
  {
    PLZ: '10999',
    District: 'Friedrichshain-Kreuzberg',
  },
  {
    PLZ: '13051',
    District: 'Lichtenberg Hohenschönhausen',
  },
  {
    PLZ: '13053',
    District: 'Lichtenberg Hohenschönhausen',
  },
  {
    PLZ: '13055',
    District: 'Lichtenberg Hohenschönhausen',
  },
  {
    PLZ: '13057',
    District: 'Lichtenberg Hohenschönhausen',
  },
  {
    PLZ: '10367',
    District: 'Lichtenberg Hohenschönhausen',
  },
  {
    PLZ: '10369',
    District: 'Lichtenberg Hohenschönhausen',
  },
  {
    PLZ: '10315',
    District: 'Lichtenberg Hohenschönhausen',
  },
  {
    PLZ: '10317',
    District: 'Lichtenberg Hohenschönhausen',
  },
  {
    PLZ: '10319',
    District: 'Lichtenberg Hohenschönhausen',
  },
  {
    PLZ: '10365',
    District: 'Lichtenberg Hohenschönhausen',
  },
  {
    PLZ: '10318',
    District: 'Lichtenberg Hohenschönhausen',
  },
  {
    PLZ: '13059',
    District: 'Lichtenberg Hohenschönhausen',
  },
  {
    PLZ: '12683',
    District: 'Marzahn-Hellersdorf',
  },
  {
    PLZ: '12685',
    District: 'Marzahn-Hellersdorf',
  },
  {
    PLZ: '12619',
    District: 'Marzahn-Hellersdorf',
  },
  {
    PLZ: '12621',
    District: 'Marzahn-Hellersdorf',
  },
  {
    PLZ: '12623',
    District: 'Marzahn-Hellersdorf',
  },
  {
    PLZ: '12627',
    District: 'Marzahn-Hellersdorf',
  },
  {
    PLZ: '12629',
    District: 'Marzahn-Hellersdorf',
  },
  {
    PLZ: '12679',
    District: 'Marzahn-Hellersdorf',
  },
  {
    PLZ: '12681',
    District: 'Marzahn-Hellersdorf',
  },
  {
    PLZ: '12687',
    District: 'Marzahn-Hellersdorf',
  },
  {
    PLZ: '12689',
    District: 'Marzahn-Hellersdorf',
  },
  {
    PLZ: '13347',
    District: 'Berlin Mitte',
  },
  {
    PLZ: '13353',
    District: 'Berlin Mitte',
  },
  {
    PLZ: '13355',
    District: 'Berlin Mitte',
  },
  {
    PLZ: '13357',
    District: 'Berlin Mitte',
  },
  {
    PLZ: '13359',
    District: 'Berlin Mitte',
  },
  {
    PLZ: '10555',
    District: 'Berlin Mitte',
  },
  {
    PLZ: '10557',
    District: 'Berlin Mitte',
  },
  {
    PLZ: '10115',
    District: 'Berlin Mitte',
  },
  {
    PLZ: '10117',
    District: 'Berlin Mitte',
  },
  {
    PLZ: '10119',
    District: 'Berlin Mitte',
  },
  {
    PLZ: '10178',
    District: 'Berlin Mitte',
  },
  {
    PLZ: '10179',
    District: 'Berlin Mitte',
  },
  {
    PLZ: '10551',
    District: 'Berlin Mitte',
  },
  {
    PLZ: '10553',
    District: 'Berlin Mitte',
  },
  {
    PLZ: '10559',
    District: 'Berlin Mitte',
  },
  {
    PLZ: '10785',
    District: 'Berlin Mitte',
  },
  {
    PLZ: '10787',
    District: 'Berlin Mitte',
  },
  {
    PLZ: '13349',
    District: 'Berlin Mitte',
  },
  {
    PLZ: '13351',
    District: 'Berlin Mitte',
  },
  {
    PLZ: '12051',
    District: 'Berlin Neukölln',
  },
  {
    PLZ: '12057',
    District: 'Berlin Neukölln',
  },
  {
    PLZ: '12347',
    District: 'Berlin Neukölln',
  },
  {
    PLZ: '12349',
    District: 'Berlin Neukölln',
  },
  {
    PLZ: '12351',
    District: 'Berlin Neukölln',
  },
  {
    PLZ: '12359',
    District: 'Berlin Neukölln',
  },
  {
    PLZ: '12353',
    District: 'Berlin Neukölln',
  },
  {
    PLZ: '12357',
    District: 'Berlin Neukölln',
  },
  {
    PLZ: '12043',
    District: 'Berlin Neukölln',
  },
  {
    PLZ: '12045',
    District: 'Berlin Neukölln',
  },
  {
    PLZ: '12047',
    District: 'Berlin Neukölln',
  },
  {
    PLZ: '12049',
    District: 'Berlin Neukölln',
  },
  {
    PLZ: '12053',
    District: 'Berlin Neukölln',
  },
  {
    PLZ: '12055',
    District: 'Berlin Neukölln',
  },
  {
    PLZ: '12059',
    District: 'Berlin Neukölln',
  },
  {
    PLZ: '12355',
    District: 'Berlin Neukölln',
  },
  {
    PLZ: '13125',
    District: 'Pankow',
  },
  {
    PLZ: '13129',
    District: 'Pankow',
  },
  {
    PLZ: '13127',
    District: 'Pankow',
  },
  {
    PLZ: '13158',
    District: 'Pankow',
  },
  {
    PLZ: '13159',
    District: 'Pankow',
  },
  {
    PLZ: '13156',
    District: 'Pankow',
  },
  {
    PLZ: '13086',
    District: 'Pankow',
  },
  {
    PLZ: '13088',
    District: 'Pankow',
  },
  {
    PLZ: '13089',
    District: 'Pankow',
  },
  {
    PLZ: '13187',
    District: 'Pankow',
  },
  {
    PLZ: '10439',
    District: 'Pankow',
  },
  {
    PLZ: '13189',
    District: 'Pankow',
  },
  {
    PLZ: '10405',
    District: 'Pankow',
  },
  {
    PLZ: '10407',
    District: 'Pankow',
  },
  {
    PLZ: '10409',
    District: 'Pankow',
  },
  {
    PLZ: '10435',
    District: 'Pankow',
  },
  {
    PLZ: '10437',
    District: 'Pankow',
  },
  {
    PLZ: '13403',
    District: 'Reinickendorf',
  },
  {
    PLZ: '13509',
    District: 'Reinickendorf',
  },
  {
    PLZ: '13465',
    District: 'Reinickendorf',
  },
  {
    PLZ: '13503',
    District: 'Reinickendorf',
  },
  {
    PLZ: '13505',
    District: 'Reinickendorf',
  },
  {
    PLZ: '13467',
    District: 'Reinickendorf',
  },
  {
    PLZ: '13435',
    District: 'Reinickendorf',
  },
  {
    PLZ: '13469',
    District: 'Reinickendorf',
  },
  {
    PLZ: '13439',
    District: 'Reinickendorf',
  },
  {
    PLZ: '13405',
    District: 'Reinickendorf',
  },
  {
    PLZ: '13407',
    District: 'Reinickendorf',
  },
  {
    PLZ: '13409',
    District: 'Reinickendorf',
  },
  {
    PLZ: '13437',
    District: 'Reinickendorf',
  },
  {
    PLZ: '13507',
    District: 'Reinickendorf',
  },
  {
    PLZ: '13583',
    District: 'Spandau',
  },
  {
    PLZ: '13585',
    District: 'Spandau',
  },
  {
    PLZ: '13589',
    District: 'Spandau',
  },
  {
    PLZ: '13591',
    District: 'Spandau',
  },
  {
    PLZ: '14089',
    District: 'Spandau',
  },
  {
    PLZ: '13587',
    District: 'Spandau',
  },
  {
    PLZ: '13597',
    District: 'Spandau',
  },
  {
    PLZ: '13599',
    District: 'Spandau',
  },
  {
    PLZ: '13629',
    District: 'Spandau',
  },
  {
    PLZ: '13581',
    District: 'Spandau',
  },
  {
    PLZ: '13593',
    District: 'Spandau',
  },
  {
    PLZ: '13595',
    District: 'Spandau',
  },
  {
    PLZ: '12203',
    District: 'Steglitz-Zehlendorf',
  },
  {
    PLZ: '14169',
    District: 'Steglitz-Zehlendorf',
  },
  {
    PLZ: '14195',
    District: 'Steglitz-Zehlendorf',
  },
  {
    PLZ: '12167',
    District: 'Steglitz-Zehlendorf',
  },
  {
    PLZ: '12209',
    District: 'Steglitz-Zehlendorf',
  },
  {
    PLZ: '12247',
    District: 'Steglitz-Zehlendorf',
  },
  {
    PLZ: '12249',
    District: 'Steglitz-Zehlendorf',
  },
  {
    PLZ: '12165',
    District: 'Steglitz-Zehlendorf',
  },
  {
    PLZ: '12205',
    District: 'Steglitz-Zehlendorf',
  },
  {
    PLZ: '12207',
    District: 'Steglitz-Zehlendorf',
  },
  {
    PLZ: '14167',
    District: 'Steglitz-Zehlendorf',
  },
  {
    PLZ: '14109',
    District: 'Steglitz-Zehlendorf',
  },
  {
    PLZ: '14129',
    District: 'Steglitz-Zehlendorf',
  },
  {
    PLZ: '14163',
    District: 'Steglitz-Zehlendorf',
  },
  {
    PLZ: '12163',
    District: 'Steglitz-Zehlendorf',
  },
  {
    PLZ: '12169',
    District: 'Steglitz-Zehlendorf',
  },
  {
    PLZ: '14165',
    District: 'Steglitz-Zehlendorf',
  },
  {
    PLZ: '10827',
    District: 'Tempelhof-Schöneberg',
  },
  {
    PLZ: '12159',
    District: 'Tempelhof-Schöneberg',
  },
  {
    PLZ: '12161',
    District: 'Tempelhof-Schöneberg',
  },
  {
    PLZ: '12107',
    District: 'Tempelhof-Schöneberg',
  },
  {
    PLZ: '12277',
    District: 'Tempelhof-Schöneberg',
  },
  {
    PLZ: '12305',
    District: 'Tempelhof-Schöneberg',
  },
  {
    PLZ: '12307',
    District: 'Tempelhof-Schöneberg',
  },
  {
    PLZ: '12309',
    District: 'Tempelhof-Schöneberg',
  },
  {
    PLZ: '12099',
    District: 'Tempelhof-Schöneberg',
  },
  {
    PLZ: '12105',
    District: 'Tempelhof-Schöneberg',
  },
  {
    PLZ: '12109',
    District: 'Tempelhof-Schöneberg',
  },
  {
    PLZ: '12103',
    District: 'Tempelhof-Schöneberg',
  },
  {
    PLZ: '12279',
    District: 'Tempelhof-Schöneberg',
  },
  {
    PLZ: '10777',
    District: 'Tempelhof-Schöneberg',
  },
  {
    PLZ: '10781',
    District: 'Tempelhof-Schöneberg',
  },
  {
    PLZ: '10783',
    District: 'Tempelhof-Schöneberg',
  },
  {
    PLZ: '10823',
    District: 'Tempelhof-Schöneberg',
  },
  {
    PLZ: '10825',
    District: 'Tempelhof-Schöneberg',
  },
  {
    PLZ: '10829',
    District: 'Tempelhof-Schöneberg',
  },
  {
    PLZ: '12101',
    District: 'Tempelhof-Schöneberg',
  },
  {
    PLZ: '12157',
    District: 'Tempelhof-Schöneberg',
  },
  {
    PLZ: '12439',
    District: 'Treptow-Köpenick',
  },
  {
    PLZ: '12487',
    District: 'Treptow-Köpenick',
  },
  {
    PLZ: '12489',
    District: 'Treptow-Köpenick',
  },
  {
    PLZ: '12435',
    District: 'Treptow-Köpenick',
  },
  {
    PLZ: '12524',
    District: 'Treptow-Köpenick',
  },
  {
    PLZ: '12526',
    District: 'Treptow-Köpenick',
  },
  {
    PLZ: '12437',
    District: 'Treptow-Köpenick',
  },
  {
    PLZ: '12587',
    District: 'Treptow-Köpenick',
  },
  {
    PLZ: '12527',
    District: 'Treptow-Köpenick',
  },
  {
    PLZ: '12555',
    District: 'Treptow-Köpenick',
  },
  {
    PLZ: '12557',
    District: 'Treptow-Köpenick',
  },
  {
    PLZ: '12559',
    District: 'Treptow-Köpenick',
  },
  {
    PLZ: '12459',
    District: 'Treptow-Köpenick',
  },
  {
    PLZ: '12589',
    District: 'Treptow-Köpenick',
  },
]
