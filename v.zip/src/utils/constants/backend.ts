export const unprotectedApiRoutes = [
  '/api/auth/refresh',
  '/api/auth/login',
  '/api/auth/me',
  '/api/auth/signup',
  '/api/list/seed-users',
  '/api/auth/forgot-password',
  '/api/auth/reset-password',
]

export const deletedCollaboratorAccount = 'deletedCollabortor@ttmp.com'
