export function debounce<F extends (...args: any[]) => void>(
  func: F,
  timeout: number = 300,
): (this: any, ...args: Parameters<F>) => void {
  let timer: NodeJS.Timeout | undefined
  return function (this: any, ...args: Parameters<F>) {
    clearTimeout(timer)
    timer = setTimeout(() => {
      func.apply(this, args)
    }, timeout)
  }
}
