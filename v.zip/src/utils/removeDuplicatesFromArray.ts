export function removeDuplicates<T>(arr: T[]): T[] {
  const uniqueArray: T[] = []
  const map: { [key: string]: boolean } = {}

  for (let i = 0; i < arr.length; i++) {
    if (!map.hasOwnProperty(String(arr[i]))) {
      map[String(arr[i])] = true
      uniqueArray.push(arr[i])
    }
  }

  return uniqueArray
}
