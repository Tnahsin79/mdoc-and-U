# TTMP Project

This is the fullstack repository for the TTMP Project. It is a confidential codebase and you should only have access to it after having signed an NDA.

## Env example

DB_HOST="postgres"
DB_PASSWORD="postgres"
DB_USER="postgres"
DB_NAME="ttmp"
DB_PORT=5432
DATABASE_URL=postgresql://postgres:postgres@localhost:5432/ttmp?schema=public
JWT_SECRET_KEY=ttmp-project
NODE_ENV=development
FILE_SERVER_BASE_URL='http://localhost:3001'

## Env example for file server 
PORT='3001'
JWT_SECRET_KEY='fdadfCDwAiAOkp0'
FILES_DESTINATION='../../files/'
FILE_SERVER_BASE_URL='http://localhost:3001'

## Local setup steps

1. Install postgresql and pgadmin4 in your system
2. setup above env file

## Installation Instructions

1. Make sure you have node v19.9
2. `npm i` (to install deps)
3. `npm run prisma:migrate:dev` (required only once and when updated the schema)
4. `npm run prisma:generate` (required only once)
5. `npm run storybook` (to run the storybook)
6. `npm run dev` (to run the dev)
7. `npm run build` (to make the production build)
8. `npm run start` (runs the produced build)

## Seeding the Database and Creating users

These steps ensure the database is populated with initial data and users can authenticate to access the application's functionalities:

1. Go to the /prisma folder and if there is a "migrations" folder delete it, if there is not ignore this step.
2. Run the command `npm run prisma:generate` to generate he latest Database.
3. Run the command `npm run prisma:migrate:dev` to migrate the Database (Might get a warning "All Data will be lost", Type "Y" and approve it).
4. Run the command `npm run prisma:studio` to see the database in you local on the web browser (This step is optional).

5. After completing the above steps we need to seed the database, first API we need to hit is `/api/list/seed-users` (Paste this infront of the base URL in the browser and press Enter, similarly with below given APIs also).

6. Now we have seeded basic users and now all other APIs will need authentication to access, so to get that we login with the Employee Account. For this go to the login page by typing `/login` in the browser and login with the credentials: email: `employee@ttmp.com`, password: `Qw@12345`. 
7. After logging in now you can hit other seeding APIs, hit `/api/list/seed-data/collaborator` then hit `/api/list/seed-data` to seed the list table.
8. After completing the above step, hit `/api/school/seed-schools` to seed the school table. 

9. After Completing the above steps all the seeding is completed and now you can run the project. Below are the credentials for the different type of accounts you can login with and test the functionalities: 

- Employee: 
    email: `employee@ttmp.com`
    password: `Qw@12345`

- Collaborator: 
    email: `collaborator@ttmp.com`
    password: `Qw@12345`

- Candidate: 
    email: `candidate@ttmp.com`
    password: `Qw@12345`
