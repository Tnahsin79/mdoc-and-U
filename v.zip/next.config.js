/** @type {import('next').NextConfig} */
const nextConfig = {
  compiler: {
    emotion: true,
  },
  eslint: {
    // Warning: This allows production builds to successfully complete even if
    // your project has ESLint errors.
    ignoreDuringBuilds: true,
  },
  // basePath:'/app'
  images: {
    domains: [
      'staging.quereinstieg.sdui-projects.de',
      '34.68.95.142',
      '34.68.95.142',
      'localhost',
      'ttmp.smartgeeks.io',
    ],
  },
}

module.exports = nextConfig
