import * as Sentry from "@sentry/nextjs";

if (process.env.NODE_ENV === 'production') {
    Sentry.init({
      dsn: "https://7946605ae07b36b4a330063a808622e8@o4506772330708992.ingest.sentry.io/4506772346109952",
      tracesSampleRate: 1.0,
    });
}
