#!/bin/bash

# Start up the Postgres container
# docker-compose up -d postgres

# # Wait for Postgres to become healthy
# echo "Waiting for Postgres to become healthy..."
# while [ "$(docker inspect --format='{{.State.Health.Status}}' postgres)" != "healthy" ]; do
#     sleep 30s
#     echo "Still waiting for Postgres to become healthy..."
# done
# echo "Postgres is now healthy."

# Now build and start the ttmp service
docker-compose up -d --build ttmp
