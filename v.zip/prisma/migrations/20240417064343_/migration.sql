-- DropIndex
DROP INDEX "unique_room_booking";
