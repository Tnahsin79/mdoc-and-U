/*
  Warnings:

  - Made the column `mentorId` on table `BuddyRequest` required. This step will fail if there are existing NULL values in that column.

*/
-- DropForeignKey
ALTER TABLE "BuddyRequest" DROP CONSTRAINT "BuddyRequest_mentorId_fkey";

-- AlterTable
ALTER TABLE "BuddyRequest" ALTER COLUMN "mentorId" SET NOT NULL;

-- AddForeignKey
ALTER TABLE "BuddyRequest" ADD CONSTRAINT "BuddyRequest_mentorId_fkey" FOREIGN KEY ("mentorId") REFERENCES "Person"("personId") ON DELETE RESTRICT ON UPDATE CASCADE;
