/*
  Warnings:

  - The primary key for the `BuddyRequestToSchoolType` table will be changed. If it partially fails, the table could be left without primary key constraint.

*/
-- DropForeignKey
ALTER TABLE "BuddyRequestToSchoolType" DROP CONSTRAINT "BuddyRequestToSchoolType_schoolTypeId_fkey";

-- AlterTable
ALTER TABLE "BuddyRequestToSchoolType" DROP CONSTRAINT "BuddyRequestToSchoolType_pkey",
ADD COLUMN     "id" SERIAL NOT NULL,
ALTER COLUMN "schoolTypeId" DROP NOT NULL,
ADD CONSTRAINT "BuddyRequestToSchoolType_pkey" PRIMARY KEY ("id");

-- AddForeignKey
ALTER TABLE "BuddyRequestToSchoolType" ADD CONSTRAINT "BuddyRequestToSchoolType_schoolTypeId_fkey" FOREIGN KEY ("schoolTypeId") REFERENCES "List"("listId") ON DELETE SET NULL ON UPDATE CASCADE;
