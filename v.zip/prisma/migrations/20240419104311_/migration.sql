-- AlterTable
ALTER TABLE "Collaborator" ADD COLUMN     "invited" BOOLEAN NOT NULL DEFAULT false;
