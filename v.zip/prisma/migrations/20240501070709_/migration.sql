-- CreateTable
CREATE TABLE "BuddyRequest" (
    "id" SERIAL NOT NULL,
    "mentorId" INTEGER,

    CONSTRAINT "BuddyRequest_pkey" PRIMARY KEY ("id")
);

-- AddForeignKey
ALTER TABLE "BuddyRequest" ADD CONSTRAINT "BuddyRequest_mentorId_fkey" FOREIGN KEY ("mentorId") REFERENCES "Collaborator"("collaboratorId") ON DELETE SET NULL ON UPDATE CASCADE;
