-- AlterTable
ALTER TABLE "Person" ADD COLUMN     "lastActivityTimestamp" TIMESTAMP(3);
