/*
  Warnings:

  - Added the required column `availableId` to the `BuddyRequest` table without a default value. This is not possible if the table is not empty.
  - Added the required column `howFarDistance` to the `BuddyRequest` table without a default value. This is not possible if the table is not empty.
  - Added the required column `howManyToSupport` to the `BuddyRequest` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "BuddyRequest" ADD COLUMN     "availableId" INTEGER NOT NULL,
ADD COLUMN     "howFarDistance" INTEGER NOT NULL,
ADD COLUMN     "howManyToSupport" INTEGER NOT NULL;

-- CreateTable
CREATE TABLE "BuddyRequestToSchoolType" (
    "buddyRequestId" INTEGER NOT NULL,
    "schoolTypeId" INTEGER NOT NULL,

    CONSTRAINT "BuddyRequestToSchoolType_pkey" PRIMARY KEY ("buddyRequestId","schoolTypeId")
);

-- AddForeignKey
ALTER TABLE "BuddyRequestToSchoolType" ADD CONSTRAINT "BuddyRequestToSchoolType_buddyRequestId_fkey" FOREIGN KEY ("buddyRequestId") REFERENCES "BuddyRequest"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "BuddyRequestToSchoolType" ADD CONSTRAINT "BuddyRequestToSchoolType_schoolTypeId_fkey" FOREIGN KEY ("schoolTypeId") REFERENCES "List"("listId") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "BuddyRequest" ADD CONSTRAINT "BuddyRequest_availableId_fkey" FOREIGN KEY ("availableId") REFERENCES "List"("listId") ON DELETE RESTRICT ON UPDATE CASCADE;
