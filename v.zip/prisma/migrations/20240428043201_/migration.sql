-- AlterTable
ALTER TABLE "Event" ADD COLUMN     "participantsAttachment" TEXT;
