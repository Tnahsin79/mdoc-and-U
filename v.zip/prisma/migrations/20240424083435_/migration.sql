-- AlterTable
ALTER TABLE "Collaborator" ADD COLUMN     "prpfileCompleted" BOOLEAN NOT NULL DEFAULT false;
