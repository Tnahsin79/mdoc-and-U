-- CreateEnum
CREATE TYPE "Role" AS ENUM ('Employee', 'Collaborator', 'Candidate');

-- CreateEnum
CREATE TYPE "PhaseName" AS ENUM ('kickOff', 'firstStep', 'setUp', 'studies');

-- CreateEnum
CREATE TYPE "TaskType" AS ENUM ('Event', 'Document', 'Data', 'Message');

-- CreateEnum
CREATE TYPE "CollaboratorOrigin" AS ENUM ('Internal', 'External');

-- CreateTable
CREATE TABLE "Event" (
    "eventId" SERIAL NOT NULL,
    "templateId" INTEGER,
    "title" TEXT NOT NULL,
    "subjectAreaId" INTEGER NOT NULL,
    "subjectModule" TEXT NOT NULL,
    "eventTypeId" INTEGER NOT NULL,
    "eventStatusId" INTEGER NOT NULL,
    "reason" TEXT,
    "phaseId" INTEGER NOT NULL,
    "eventManner" TEXT NOT NULL,
    "description" TEXT,
    "bookedFrom" TEXT NOT NULL,
    "bookedTo" TEXT,
    "startTime" TEXT NOT NULL,
    "endTime" TEXT NOT NULL,
    "eventRepeatId" INTEGER,
    "minParticipants" INTEGER NOT NULL,
    "maxParticipants" INTEGER NOT NULL,
    "lmsLink" TEXT,
    "accessLink" TEXT,
    "locationId" INTEGER,
    "barrierFreeAccess" BOOLEAN,
    "suitableRoomsId" INTEGER,
    "suitableCollaboratorId" INTEGER NOT NULL,
    "eventKey" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "Event_pkey" PRIMARY KEY ("eventId")
);

-- CreateTable
CREATE TABLE "ListEquipment" (
    "eventId" INTEGER NOT NULL,
    "listId" INTEGER NOT NULL,

    CONSTRAINT "ListEquipment_pkey" PRIMARY KEY ("eventId","listId")
);

-- CreateTable
CREATE TABLE "List" (
    "listId" SERIAL NOT NULL,
    "listType" TEXT NOT NULL,
    "listValue" TEXT NOT NULL,
    "isActive" BOOLEAN NOT NULL,

    CONSTRAINT "List_pkey" PRIMARY KEY ("listId")
);

-- CreateTable
CREATE TABLE "Phase" (
    "phaseId" SERIAL NOT NULL,
    "kickOff" BOOLEAN NOT NULL,
    "firstSteps" BOOLEAN NOT NULL,
    "setup" BOOLEAN NOT NULL,
    "studies" BOOLEAN NOT NULL,

    CONSTRAINT "Phase_pkey" PRIMARY KEY ("phaseId")
);

-- CreateTable
CREATE TABLE "Candidate" (
    "candidateId" SERIAL NOT NULL,
    "personId" INTEGER NOT NULL,
    "streetAndHouseNo" TEXT,
    "houseNumber" TEXT,
    "city" TEXT,
    "longerAbsenceReasonId" INTEGER,
    "teachingPositionId" INTEGER NOT NULL,
    "startSchoolYear" TEXT NOT NULL,
    "yearGroupId" INTEGER,
    "phaseRequiredId" INTEGER NOT NULL,
    "kickOffGroupId" INTEGER,
    "firstRecognisedSubjectId" INTEGER,
    "secondRecognisedSubjectId" INTEGER,
    "thirdRecognisedSubjectId" INTEGER,
    "firstSubjectToBeStudiedId" INTEGER,
    "secondSubjectToBeStudiedId" INTEGER,
    "subjectChangeFromId" INTEGER,
    "subjectChangeToId" INTEGER,
    "studiesGroupSubjectAId" INTEGER,
    "studiesGroupSubjectBId" INTEGER,
    "comments" TEXT,
    "document" TEXT NOT NULL,
    "schoolId" INTEGER NOT NULL,
    "fromDate" TIMESTAMP(3),
    "untilDate" TIMESTAMP(3),
    "batchId" INTEGER,
    "startOfContract" TIMESTAMP(3),
    "mentorId" INTEGER,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "bbvdStart" TIMESTAMP(3),
    "bbstStart" TIMESTAMP(3),
    "correct" BOOLEAN NOT NULL DEFAULT false,
    "recognisedSubject" TEXT,
    "startSubjectAId" INTEGER,
    "startSubjectBId" INTEGER,

    CONSTRAINT "Candidate_pkey" PRIMARY KEY ("candidateId")
);

-- CreateTable
CREATE TABLE "CandidateBatch" (
    "batchId" SERIAL NOT NULL,

    CONSTRAINT "CandidateBatch_pkey" PRIMARY KEY ("batchId")
);

-- CreateTable
CREATE TABLE "Person" (
    "personId" SERIAL NOT NULL,
    "title" TEXT,
    "firstName" TEXT NOT NULL,
    "lastName" TEXT,
    "email" TEXT NOT NULL,
    "phoneNumber" TEXT,
    "postalCode" TEXT,
    "appellationId" INTEGER,
    "password" TEXT,
    "role" "Role" NOT NULL DEFAULT 'Candidate',
    "resetPasswordToken" TEXT,
    "resetPasswordTokenExpiry" TIMESTAMP(3),
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "subjectAdmin" BOOLEAN NOT NULL DEFAULT false,
    "subjectSupervision" BOOLEAN NOT NULL DEFAULT false,
    "householdAdmin" BOOLEAN NOT NULL DEFAULT false,
    "departmentLead" BOOLEAN NOT NULL DEFAULT false,

    CONSTRAINT "Person_pkey" PRIMARY KEY ("personId")
);

-- CreateTable
CREATE TABLE "Employee" (
    "employeeId" SERIAL NOT NULL,
    "personId" INTEGER NOT NULL,
    "employeePermissionIds" INTEGER NOT NULL,
    "businessPhoneNumber" TEXT NOT NULL,
    "businessMobileNumber" TEXT NOT NULL,
    "businessEmail" TEXT NOT NULL,
    "assignedPhase" INTEGER NOT NULL
);

-- CreateTable
CREATE TABLE "School" (
    "schoolId" SERIAL NOT NULL,
    "BSN" TEXT NOT NULL,
    "schoolTypeId" INTEGER NOT NULL,
    "schoolName" TEXT NOT NULL,
    "streetAndHouseNo" TEXT NOT NULL,
    "city" TEXT NOT NULL,
    "postalCode" TEXT NOT NULL,
    "phoneNumber" TEXT NOT NULL,
    "faxNumber" TEXT,
    "emailAddress" TEXT NOT NULL,
    "website" TEXT NOT NULL,

    CONSTRAINT "School_pkey" PRIMARY KEY ("schoolId")
);

-- CreateTable
CREATE TABLE "CollaboratorSchool" (
    "schoolId" INTEGER NOT NULL,
    "collaboratorId" INTEGER NOT NULL,

    CONSTRAINT "CollaboratorSchool_pkey" PRIMARY KEY ("schoolId","collaboratorId")
);

-- CreateTable
CREATE TABLE "CollaboratorSchoolRole" (
    "roleId" INTEGER NOT NULL,
    "collaboratorId" INTEGER NOT NULL,

    CONSTRAINT "CollaboratorSchoolRole_pkey" PRIMARY KEY ("roleId","collaboratorId")
);

-- CreateTable
CREATE TABLE "CollaboratorAddress" (
    "collaboratorAddressId" SERIAL NOT NULL,
    "streetAndHouseNo" TEXT NOT NULL,
    "city" TEXT NOT NULL,
    "postalCode" TEXT NOT NULL,
    "primaryAddress" BOOLEAN NOT NULL,
    "collaboratorId" INTEGER NOT NULL,

    CONSTRAINT "CollaboratorAddress_pkey" PRIMARY KEY ("collaboratorAddressId")
);

-- CreateTable
CREATE TABLE "Collaborator" (
    "collaboratorId" SERIAL NOT NULL,
    "pinNo" INTEGER NOT NULL,
    "personId" INTEGER NOT NULL,
    "dob" TIMESTAMP(3),
    "workedAsATeacher" BOOLEAN,
    "federalStateId" INTEGER,
    "schoolTypeId" INTEGER,
    "firstRecognisedSubjectId" INTEGER,
    "secondRecognisedSubjectId" INTEGER,
    "thirdRecognisedSubjectId" INTEGER,
    "lastActiveTeachingYear" TIMESTAMP(3),
    "stillTeaching" BOOLEAN,
    "jobTitle" TEXT,
    "firstActivityField" TEXT,
    "secondActivityField" TEXT,
    "thirdActivityField" TEXT,
    "retired" BOOLEAN,
    "retiredSince" TIMESTAMP(3),
    "contactPointWithSchool" TEXT,
    "otherQualification" TEXT,
    "companyName" TEXT,
    "accountHolder" TEXT,
    "iban" TEXT,
    "bic" TEXT,
    "taxId" TEXT,
    "assignedTaxOffice" TEXT,
    "vat" BOOLEAN DEFAULT false,
    "phasePreferenceId" INTEGER,
    "policeConductCertificate" BOOLEAN DEFAULT false,
    "vaccinatedMeasles" BOOLEAN DEFAULT false,
    "competenceTeamKickOff" BOOLEAN DEFAULT false,
    "competenceTeamFirstSteps" BOOLEAN DEFAULT false,
    "firstStrike" BOOLEAN DEFAULT false,
    "secondStrike" BOOLEAN DEFAULT false,
    "thirdStrike" BOOLEAN DEFAULT false,
    "comment" TEXT,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "correct" BOOLEAN NOT NULL DEFAULT false,
    "attachment" TEXT,
    "businessTypeId" INTEGER,

    CONSTRAINT "Collaborator_pkey" PRIMARY KEY ("collaboratorId")
);

-- CreateTable
CREATE TABLE "CollaboratorModules" (
    "id" SERIAL NOT NULL,
    "collaboratorId" INTEGER NOT NULL,
    "moduleId" INTEGER NOT NULL,

    CONSTRAINT "CollaboratorModules_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Modules" (
    "moduleId" SERIAL NOT NULL,
    "moduleValue" TEXT NOT NULL,
    "phase" "PhaseName" NOT NULL,

    CONSTRAINT "Modules_pkey" PRIMARY KEY ("moduleId")
);

-- CreateTable
CREATE TABLE "CollaboratorSubjectArea" (
    "id" SERIAL NOT NULL,
    "collaboratorId" INTEGER NOT NULL,
    "subjectAreaId" INTEGER NOT NULL,

    CONSTRAINT "CollaboratorSubjectArea_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "SubjectArea" (
    "subjectAreaId" SERIAL NOT NULL,
    "subjectValue" TEXT NOT NULL,
    "moduleId" INTEGER NOT NULL,

    CONSTRAINT "SubjectArea_pkey" PRIMARY KEY ("subjectAreaId")
);

-- CreateTable
CREATE TABLE "Contract" (
    "contractId" SERIAL NOT NULL,
    "personId" INTEGER NOT NULL,
    "contractTypeId" INTEGER NOT NULL,

    CONSTRAINT "Contract_pkey" PRIMARY KEY ("contractId")
);

-- CreateTable
CREATE TABLE "ContractDetail" (
    "contractDetailId" SERIAL NOT NULL,
    "contractId" INTEGER NOT NULL,
    "positionTitle" TEXT NOT NULL,
    "duration" INTEGER NOT NULL,
    "hourlyFee" INTEGER NOT NULL,
    "phaseId" INTEGER NOT NULL,
    "billFrom" TIMESTAMP(3) NOT NULL,
    "billTo" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "ContractDetail_pkey" PRIMARY KEY ("contractDetailId")
);

-- CreateTable
CREATE TABLE "Communication" (
    "communicationId" SERIAL NOT NULL,
    "subject" TEXT NOT NULL,
    "body" TEXT NOT NULL,
    "recipientId" INTEGER NOT NULL,
    "senderId" INTEGER,
    "isNote" BOOLEAN NOT NULL DEFAULT false,
    "timeStamp" TIMESTAMP(3) NOT NULL,
    "read" BOOLEAN NOT NULL DEFAULT false,
    "messageUuid" INTEGER,
    "isNotAssigned" BOOLEAN NOT NULL DEFAULT false,
    "unknownSenderMail" TEXT,
    "attachment" TEXT,

    CONSTRAINT "Communication_pkey" PRIMARY KEY ("communicationId")
);

-- CreateTable
CREATE TABLE "Bill" (
    "billId" SERIAL NOT NULL,
    "title" TEXT NOT NULL,
    "amount" TEXT NOT NULL,
    "comment" TEXT NOT NULL,
    "collaboratorId" INTEGER NOT NULL,
    "date" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "attachment" TEXT,
    "paid" BOOLEAN NOT NULL DEFAULT false,

    CONSTRAINT "Bill_pkey" PRIMARY KEY ("billId")
);

-- CreateTable
CREATE TABLE "EventCollaborator" (
    "eventId" INTEGER NOT NULL,
    "collaboratorId" INTEGER NOT NULL,
    "isConfirmed" BOOLEAN NOT NULL DEFAULT false,

    CONSTRAINT "EventCollaborator_pkey" PRIMARY KEY ("eventId","collaboratorId")
);

-- CreateTable
CREATE TABLE "Group" (
    "groupId" SERIAL NOT NULL,
    "name" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "Group_pkey" PRIMARY KEY ("groupId")
);

-- CreateTable
CREATE TABLE "GroupAttendees" (
    "groupAttendeesId" SERIAL NOT NULL,
    "groupId" INTEGER NOT NULL,
    "candidateId" INTEGER NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "GroupAttendees_pkey" PRIMARY KEY ("groupAttendeesId")
);

-- CreateTable
CREATE TABLE "EventCollaboratorAttendees" (
    "eventCollaboratorAttendeesId" SERIAL NOT NULL,
    "eventId" INTEGER NOT NULL,
    "candidateId" INTEGER NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "EventCollaboratorAttendees_pkey" PRIMARY KEY ("eventCollaboratorAttendeesId")
);

-- CreateTable
CREATE TABLE "EventAttendees" (
    "eventAttendeesId" SERIAL NOT NULL,
    "eventId" INTEGER NOT NULL,
    "attendeeId" INTEGER NOT NULL,
    "moduleName" TEXT NOT NULL,

    CONSTRAINT "EventAttendees_pkey" PRIMARY KEY ("eventAttendeesId")
);

-- CreateTable
CREATE TABLE "Attachment" (
    "attachmentId" SERIAL NOT NULL,
    "attachment" TEXT,
    "taskId" INTEGER,

    CONSTRAINT "Attachment_pkey" PRIMARY KEY ("attachmentId")
);

-- CreateTable
CREATE TABLE "Task" (
    "taskId" SERIAL NOT NULL,
    "assigneeId" INTEGER,
    "type" "TaskType" NOT NULL,
    "title" TEXT NOT NULL,
    "dueDate" TIMESTAMP(3) NOT NULL,
    "note" TEXT NOT NULL,
    "creatorId" INTEGER,
    "done" BOOLEAN NOT NULL DEFAULT false,

    CONSTRAINT "Task_pkey" PRIMARY KEY ("taskId")
);

-- CreateTable
CREATE TABLE "History" (
    "historyId" SERIAL NOT NULL,
    "actionType" TEXT NOT NULL,
    "actionDetail" TEXT NOT NULL,
    "actionReference" TEXT NOT NULL,
    "personId" INTEGER NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "History_pkey" PRIMARY KEY ("historyId")
);

-- CreateTable
CREATE TABLE "EventTemplate" (
    "templateId" SERIAL NOT NULL,
    "templateName" TEXT NOT NULL,
    "phaseId" INTEGER,
    "eventKey" TEXT,
    "subjectAreaId" INTEGER,
    "subjectModule" TEXT,
    "eventTypeId" INTEGER,
    "minParticipants" INTEGER,
    "maxParticipants" INTEGER,
    "eventDuration" TEXT,
    "description" TEXT,
    "collaboratorOrigin" "CollaboratorOrigin",
    "isActive" BOOLEAN NOT NULL DEFAULT true,

    CONSTRAINT "EventTemplate_pkey" PRIMARY KEY ("templateId")
);

-- CreateTable
CREATE TABLE "Rooms" (
    "roomId" SERIAL NOT NULL,
    "locationName" TEXT NOT NULL,
    "roomName" TEXT NOT NULL,
    "maxAttendees" INTEGER NOT NULL,
    "barrierFreeAccess" BOOLEAN NOT NULL,
    "smartboard" BOOLEAN NOT NULL,
    "beamer" BOOLEAN NOT NULL,
    "flipchart" BOOLEAN NOT NULL,
    "whiteboard" BOOLEAN NOT NULL,
    "moderationskoffer" BOOLEAN NOT NULL,
    "dokumentenkamera" BOOLEAN NOT NULL,
    "pinnwand" BOOLEAN NOT NULL,
    "tische" BOOLEAN NOT NULL,
    "mikrofonHandsenderNumber" INTEGER NOT NULL,
    "mikrofonHeadsetNumber" INTEGER NOT NULL,
    "beleuchtungsanlage" BOOLEAN NOT NULL,
    "rednerpult" BOOLEAN NOT NULL,

    CONSTRAINT "Rooms_pkey" PRIMARY KEY ("roomId")
);

-- CreateIndex
CREATE UNIQUE INDEX "Candidate_personId_key" ON "Candidate"("personId");

-- CreateIndex
CREATE UNIQUE INDEX "Person_email_key" ON "Person"("email");

-- CreateIndex
CREATE UNIQUE INDEX "Employee_employeeId_key" ON "Employee"("employeeId");

-- CreateIndex
CREATE UNIQUE INDEX "Employee_personId_key" ON "Employee"("personId");

-- CreateIndex
CREATE UNIQUE INDEX "Collaborator_pinNo_key" ON "Collaborator"("pinNo");

-- CreateIndex
CREATE UNIQUE INDEX "Collaborator_personId_key" ON "Collaborator"("personId");

-- CreateIndex
CREATE UNIQUE INDEX "Communication_messageUuid_senderId_key" ON "Communication"("messageUuid", "senderId");

-- CreateIndex
CREATE UNIQUE INDEX "EventCollaborator_eventId_key" ON "EventCollaborator"("eventId");

-- CreateIndex
CREATE UNIQUE INDEX "EventCollaboratorAttendees_eventId_candidateId_key" ON "EventCollaboratorAttendees"("eventId", "candidateId");

-- CreateIndex
CREATE INDEX "History_personId_idx" ON "History"("personId");

-- CreateIndex
CREATE INDEX "History_actionReference_idx" ON "History"("actionReference");

-- AddForeignKey
ALTER TABLE "Event" ADD CONSTRAINT "Event_templateId_fkey" FOREIGN KEY ("templateId") REFERENCES "EventTemplate"("templateId") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Event" ADD CONSTRAINT "Event_subjectAreaId_fkey" FOREIGN KEY ("subjectAreaId") REFERENCES "List"("listId") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Event" ADD CONSTRAINT "Event_eventTypeId_fkey" FOREIGN KEY ("eventTypeId") REFERENCES "List"("listId") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Event" ADD CONSTRAINT "Event_eventStatusId_fkey" FOREIGN KEY ("eventStatusId") REFERENCES "List"("listId") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Event" ADD CONSTRAINT "Event_phaseId_fkey" FOREIGN KEY ("phaseId") REFERENCES "List"("listId") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Event" ADD CONSTRAINT "Event_eventRepeatId_fkey" FOREIGN KEY ("eventRepeatId") REFERENCES "List"("listId") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Event" ADD CONSTRAINT "Event_locationId_fkey" FOREIGN KEY ("locationId") REFERENCES "List"("listId") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Event" ADD CONSTRAINT "Event_suitableRoomsId_fkey" FOREIGN KEY ("suitableRoomsId") REFERENCES "List"("listId") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Event" ADD CONSTRAINT "Event_suitableCollaboratorId_fkey" FOREIGN KEY ("suitableCollaboratorId") REFERENCES "Person"("personId") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ListEquipment" ADD CONSTRAINT "ListEquipment_eventId_fkey" FOREIGN KEY ("eventId") REFERENCES "Event"("eventId") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ListEquipment" ADD CONSTRAINT "ListEquipment_listId_fkey" FOREIGN KEY ("listId") REFERENCES "List"("listId") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Candidate" ADD CONSTRAINT "Candidate_personId_fkey" FOREIGN KEY ("personId") REFERENCES "Person"("personId") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Candidate" ADD CONSTRAINT "Candidate_longerAbsenceReasonId_fkey" FOREIGN KEY ("longerAbsenceReasonId") REFERENCES "List"("listId") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Candidate" ADD CONSTRAINT "Candidate_teachingPositionId_fkey" FOREIGN KEY ("teachingPositionId") REFERENCES "List"("listId") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Candidate" ADD CONSTRAINT "Candidate_yearGroupId_fkey" FOREIGN KEY ("yearGroupId") REFERENCES "List"("listId") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Candidate" ADD CONSTRAINT "Candidate_kickOffGroupId_fkey" FOREIGN KEY ("kickOffGroupId") REFERENCES "List"("listId") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Candidate" ADD CONSTRAINT "Candidate_firstRecognisedSubjectId_fkey" FOREIGN KEY ("firstRecognisedSubjectId") REFERENCES "List"("listId") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Candidate" ADD CONSTRAINT "Candidate_secondRecognisedSubjectId_fkey" FOREIGN KEY ("secondRecognisedSubjectId") REFERENCES "List"("listId") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Candidate" ADD CONSTRAINT "Candidate_thirdRecognisedSubjectId_fkey" FOREIGN KEY ("thirdRecognisedSubjectId") REFERENCES "List"("listId") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Candidate" ADD CONSTRAINT "Candidate_firstSubjectToBeStudiedId_fkey" FOREIGN KEY ("firstSubjectToBeStudiedId") REFERENCES "List"("listId") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Candidate" ADD CONSTRAINT "Candidate_secondSubjectToBeStudiedId_fkey" FOREIGN KEY ("secondSubjectToBeStudiedId") REFERENCES "List"("listId") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Candidate" ADD CONSTRAINT "Candidate_subjectChangeFromId_fkey" FOREIGN KEY ("subjectChangeFromId") REFERENCES "List"("listId") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Candidate" ADD CONSTRAINT "Candidate_subjectChangeToId_fkey" FOREIGN KEY ("subjectChangeToId") REFERENCES "List"("listId") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Candidate" ADD CONSTRAINT "Candidate_studiesGroupSubjectAId_fkey" FOREIGN KEY ("studiesGroupSubjectAId") REFERENCES "List"("listId") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Candidate" ADD CONSTRAINT "Candidate_studiesGroupSubjectBId_fkey" FOREIGN KEY ("studiesGroupSubjectBId") REFERENCES "List"("listId") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Candidate" ADD CONSTRAINT "Candidate_schoolId_fkey" FOREIGN KEY ("schoolId") REFERENCES "School"("schoolId") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Candidate" ADD CONSTRAINT "Candidate_batchId_fkey" FOREIGN KEY ("batchId") REFERENCES "CandidateBatch"("batchId") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Candidate" ADD CONSTRAINT "Candidate_mentorId_fkey" FOREIGN KEY ("mentorId") REFERENCES "Collaborator"("collaboratorId") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Candidate" ADD CONSTRAINT "Candidate_startSubjectAId_fkey" FOREIGN KEY ("startSubjectAId") REFERENCES "List"("listId") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Candidate" ADD CONSTRAINT "Candidate_startSubjectBId_fkey" FOREIGN KEY ("startSubjectBId") REFERENCES "List"("listId") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Person" ADD CONSTRAINT "Person_appellationId_fkey" FOREIGN KEY ("appellationId") REFERENCES "List"("listId") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Employee" ADD CONSTRAINT "Employee_personId_fkey" FOREIGN KEY ("personId") REFERENCES "Person"("personId") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Employee" ADD CONSTRAINT "Employee_employeePermissionIds_fkey" FOREIGN KEY ("employeePermissionIds") REFERENCES "List"("listId") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Employee" ADD CONSTRAINT "Employee_assignedPhase_fkey" FOREIGN KEY ("assignedPhase") REFERENCES "Phase"("phaseId") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "School" ADD CONSTRAINT "School_schoolTypeId_fkey" FOREIGN KEY ("schoolTypeId") REFERENCES "List"("listId") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "CollaboratorSchool" ADD CONSTRAINT "CollaboratorSchool_schoolId_fkey" FOREIGN KEY ("schoolId") REFERENCES "School"("schoolId") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "CollaboratorSchool" ADD CONSTRAINT "CollaboratorSchool_collaboratorId_fkey" FOREIGN KEY ("collaboratorId") REFERENCES "Collaborator"("collaboratorId") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "CollaboratorSchoolRole" ADD CONSTRAINT "CollaboratorSchoolRole_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES "List"("listId") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "CollaboratorSchoolRole" ADD CONSTRAINT "CollaboratorSchoolRole_collaboratorId_fkey" FOREIGN KEY ("collaboratorId") REFERENCES "Collaborator"("collaboratorId") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "CollaboratorAddress" ADD CONSTRAINT "CollaboratorAddress_collaboratorId_fkey" FOREIGN KEY ("collaboratorId") REFERENCES "Collaborator"("collaboratorId") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Collaborator" ADD CONSTRAINT "Collaborator_personId_fkey" FOREIGN KEY ("personId") REFERENCES "Person"("personId") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Collaborator" ADD CONSTRAINT "Collaborator_businessTypeId_fkey" FOREIGN KEY ("businessTypeId") REFERENCES "List"("listId") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "CollaboratorModules" ADD CONSTRAINT "CollaboratorModules_collaboratorId_fkey" FOREIGN KEY ("collaboratorId") REFERENCES "Collaborator"("collaboratorId") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "CollaboratorModules" ADD CONSTRAINT "CollaboratorModules_moduleId_fkey" FOREIGN KEY ("moduleId") REFERENCES "Modules"("moduleId") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "CollaboratorSubjectArea" ADD CONSTRAINT "CollaboratorSubjectArea_collaboratorId_fkey" FOREIGN KEY ("collaboratorId") REFERENCES "Collaborator"("collaboratorId") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "CollaboratorSubjectArea" ADD CONSTRAINT "CollaboratorSubjectArea_subjectAreaId_fkey" FOREIGN KEY ("subjectAreaId") REFERENCES "SubjectArea"("subjectAreaId") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "SubjectArea" ADD CONSTRAINT "SubjectArea_moduleId_fkey" FOREIGN KEY ("moduleId") REFERENCES "Modules"("moduleId") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Contract" ADD CONSTRAINT "Contract_personId_fkey" FOREIGN KEY ("personId") REFERENCES "Collaborator"("personId") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Contract" ADD CONSTRAINT "Contract_contractTypeId_fkey" FOREIGN KEY ("contractTypeId") REFERENCES "List"("listId") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ContractDetail" ADD CONSTRAINT "ContractDetail_contractId_fkey" FOREIGN KEY ("contractId") REFERENCES "Contract"("contractId") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Communication" ADD CONSTRAINT "Communication_recipientId_fkey" FOREIGN KEY ("recipientId") REFERENCES "Person"("personId") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Communication" ADD CONSTRAINT "Communication_senderId_fkey" FOREIGN KEY ("senderId") REFERENCES "Person"("personId") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Bill" ADD CONSTRAINT "Bill_collaboratorId_fkey" FOREIGN KEY ("collaboratorId") REFERENCES "Collaborator"("collaboratorId") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EventCollaborator" ADD CONSTRAINT "EventCollaborator_eventId_fkey" FOREIGN KEY ("eventId") REFERENCES "Event"("eventId") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EventCollaborator" ADD CONSTRAINT "EventCollaborator_collaboratorId_fkey" FOREIGN KEY ("collaboratorId") REFERENCES "Person"("personId") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "GroupAttendees" ADD CONSTRAINT "GroupAttendees_groupId_fkey" FOREIGN KEY ("groupId") REFERENCES "Group"("groupId") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "GroupAttendees" ADD CONSTRAINT "GroupAttendees_candidateId_fkey" FOREIGN KEY ("candidateId") REFERENCES "Person"("personId") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EventCollaboratorAttendees" ADD CONSTRAINT "EventCollaboratorAttendees_eventId_fkey" FOREIGN KEY ("eventId") REFERENCES "Event"("eventId") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EventCollaboratorAttendees" ADD CONSTRAINT "EventCollaboratorAttendees_candidateId_fkey" FOREIGN KEY ("candidateId") REFERENCES "Person"("personId") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EventAttendees" ADD CONSTRAINT "EventAttendees_eventId_fkey" FOREIGN KEY ("eventId") REFERENCES "Event"("eventId") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Attachment" ADD CONSTRAINT "Attachment_taskId_fkey" FOREIGN KEY ("taskId") REFERENCES "Task"("taskId") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Task" ADD CONSTRAINT "Task_assigneeId_fkey" FOREIGN KEY ("assigneeId") REFERENCES "Person"("personId") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Task" ADD CONSTRAINT "Task_creatorId_fkey" FOREIGN KEY ("creatorId") REFERENCES "Person"("personId") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EventTemplate" ADD CONSTRAINT "EventTemplate_phaseId_fkey" FOREIGN KEY ("phaseId") REFERENCES "List"("listId") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EventTemplate" ADD CONSTRAINT "EventTemplate_subjectAreaId_fkey" FOREIGN KEY ("subjectAreaId") REFERENCES "List"("listId") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EventTemplate" ADD CONSTRAINT "EventTemplate_eventTypeId_fkey" FOREIGN KEY ("eventTypeId") REFERENCES "List"("listId") ON DELETE SET NULL ON UPDATE CASCADE;
