/*
  Warnings:

  - You are about to drop the column `buddyRequestId` on the `Communication` table. All the data in the column will be lost.

*/
-- DropForeignKey
ALTER TABLE "Communication" DROP CONSTRAINT "Communication_buddyRequestId_fkey";

-- DropIndex
DROP INDEX "Communication_buddyRequestId_key";

-- AlterTable
ALTER TABLE "Communication" DROP COLUMN "buddyRequestId";
