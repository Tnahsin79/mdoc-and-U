/*
  Warnings:

  - A unique constraint covering the columns `[communicationId]` on the table `BuddyRequest` will be added. If there are existing duplicate values, this will fail.

*/
-- AlterTable
ALTER TABLE "BuddyRequest" ADD COLUMN     "communicationId" INTEGER;

-- CreateIndex
CREATE UNIQUE INDEX "BuddyRequest_communicationId_key" ON "BuddyRequest"("communicationId");

-- AddForeignKey
ALTER TABLE "BuddyRequest" ADD CONSTRAINT "BuddyRequest_communicationId_fkey" FOREIGN KEY ("communicationId") REFERENCES "Communication"("communicationId") ON DELETE SET NULL ON UPDATE CASCADE;
