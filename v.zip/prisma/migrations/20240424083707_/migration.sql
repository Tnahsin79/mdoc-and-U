/*
  Warnings:

  - You are about to drop the column `prpfileCompleted` on the `Collaborator` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "Collaborator" DROP COLUMN "prpfileCompleted",
ADD COLUMN     "profileCompleted" BOOLEAN NOT NULL DEFAULT false;
