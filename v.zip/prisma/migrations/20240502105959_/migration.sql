/*
  Warnings:

  - You are about to drop the `CollaboratorAddress` table. If the table is not empty, all the data it contains will be lost.

*/
-- DropForeignKey
ALTER TABLE "CollaboratorAddress" DROP CONSTRAINT "CollaboratorAddress_collaboratorId_fkey";

-- AlterTable
ALTER TABLE "Collaborator" ADD COLUMN     "city" TEXT NOT NULL DEFAULT '',
ADD COLUMN     "postalCode" TEXT DEFAULT '',
ADD COLUMN     "primaryAddress" BOOLEAN NOT NULL DEFAULT true,
ADD COLUMN     "streetAndHouseNo" TEXT NOT NULL DEFAULT '';

-- DropTable
DROP TABLE "CollaboratorAddress";
