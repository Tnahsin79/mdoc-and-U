-- AlterTable
ALTER TABLE "Communication" ALTER COLUMN "fromDate" DROP NOT NULL,
ALTER COLUMN "untilDate" DROP NOT NULL;
