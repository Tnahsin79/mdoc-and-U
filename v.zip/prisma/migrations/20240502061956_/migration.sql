/*
  Warnings:

  - You are about to drop the column `communicationId` on the `BuddyRequest` table. All the data in the column will be lost.
  - A unique constraint covering the columns `[buddyRequestId]` on the table `Communication` will be added. If there are existing duplicate values, this will fail.

*/
-- DropForeignKey
ALTER TABLE "BuddyRequest" DROP CONSTRAINT "BuddyRequest_communicationId_fkey";

-- DropIndex
DROP INDEX "BuddyRequest_communicationId_key";

-- AlterTable
ALTER TABLE "BuddyRequest" DROP COLUMN "communicationId";

-- AlterTable
ALTER TABLE "Communication" ADD COLUMN     "buddyRequestId" INTEGER;

-- CreateIndex
CREATE UNIQUE INDEX "Communication_buddyRequestId_key" ON "Communication"("buddyRequestId");

-- AddForeignKey
ALTER TABLE "Communication" ADD CONSTRAINT "Communication_buddyRequestId_fkey" FOREIGN KEY ("buddyRequestId") REFERENCES "BuddyRequest"("id") ON DELETE SET NULL ON UPDATE CASCADE;
