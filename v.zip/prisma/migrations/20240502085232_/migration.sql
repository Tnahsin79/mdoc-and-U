-- AlterTable
ALTER TABLE "BuddyRequest" ADD COLUMN     "isSubmitted" BOOLEAN NOT NULL DEFAULT false;
