/*
  Warnings:

  - Added the required column `fromDate` to the `Communication` table without a default value. This is not possible if the table is not empty.
  - Added the required column `untilDate` to the `Communication` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "Communication" ADD COLUMN     "fromDate" TIMESTAMP(3) NOT NULL,
ADD COLUMN     "isBuddyRequest" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "untilDate" TIMESTAMP(3) NOT NULL;
