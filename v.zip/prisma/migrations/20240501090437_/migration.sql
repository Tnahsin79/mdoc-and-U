-- DropForeignKey
ALTER TABLE "BuddyRequestToSchoolType" DROP CONSTRAINT "BuddyRequestToSchoolType_buddyRequestId_fkey";

-- AlterTable
ALTER TABLE "BuddyRequestToSchoolType" ALTER COLUMN "buddyRequestId" DROP NOT NULL;

-- AddForeignKey
ALTER TABLE "BuddyRequestToSchoolType" ADD CONSTRAINT "BuddyRequestToSchoolType_buddyRequestId_fkey" FOREIGN KEY ("buddyRequestId") REFERENCES "BuddyRequest"("id") ON DELETE SET NULL ON UPDATE CASCADE;
