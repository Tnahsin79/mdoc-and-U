/*
  Warnings:

  - A unique constraint covering the columns `[buddyRequestId]` on the table `Communication` will be added. If there are existing duplicate values, this will fail.

*/
-- AlterTable
ALTER TABLE "Communication" ADD COLUMN     "buddyRequestId" INTEGER;

-- CreateIndex
CREATE UNIQUE INDEX "Communication_buddyRequestId_key" ON "Communication"("buddyRequestId");

-- AddForeignKey
ALTER TABLE "Communication" ADD CONSTRAINT "Communication_buddyRequestId_fkey" FOREIGN KEY ("buddyRequestId") REFERENCES "BuddyRequest"("id") ON DELETE SET NULL ON UPDATE CASCADE;
