/*
  Warnings:

  - You are about to drop the `BuddyRequestToSchoolType` table. If the table is not empty, all the data it contains will be lost.

*/
-- DropForeignKey
ALTER TABLE "BuddyRequestToSchoolType" DROP CONSTRAINT "BuddyRequestToSchoolType_buddyRequestId_fkey";

-- DropForeignKey
ALTER TABLE "BuddyRequestToSchoolType" DROP CONSTRAINT "BuddyRequestToSchoolType_schoolTypeId_fkey";

-- AlterTable
ALTER TABLE "BuddyRequest" ADD COLUMN     "schoolTypesIds" INTEGER[];

-- DropTable
DROP TABLE "BuddyRequestToSchoolType";
